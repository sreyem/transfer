﻿Public Class mouseMeasurements


    ''' <summary>
    ''' lineLength
    ''' </summary>
    ''' <param name="p1">point1</param>
    ''' <param name="p2">point2</param>
    ''' <returns>length in pixels between p1 and p2</returns>
    ''' <remarks></remarks>
    Public Shared Function lineLength(ByVal p1 As Point, ByVal p2 As Point) As Single
        Dim r As Rectangle = normalizeRect(p1, p2)
        Return CSng(Math.Sqrt(r.Width ^ 2 + r.Height ^ 2))
    End Function

    ''' <summary>
    ''' </summary>
    ''' <param name="p1">point1</param>
    ''' <param name="p2">point2</param>
    ''' <returns>a rectangle encapsulating p1, p2</returns>
    ''' <remarks></remarks>
    Private Shared Function normalizeRect(ByVal p1 As Point, ByVal p2 As Point) As Rectangle

        Dim r As New Rectangle

        If p1.X < p2.X Then
            r.X = p1.X
            r.Width = p2.X - p1.X
        Else
            r.X = p2.X
            r.Width = p1.X - p2.X
        End If
        If p1.Y < p2.Y Then
            r.Y = p1.Y
            r.Height = p2.Y - p1.Y
        Else
            r.Y = p2.Y
            r.Height = p1.Y - p2.Y
        End If

        Return r

    End Function


    Public Class unitConverter

        ''' <summary>
        ''' pixelsToCM Function
        ''' </summary>
        ''' <param name="gr">the graphics object</param>
        ''' <param name="pixels">a length in pixels</param>
        ''' <returns>length in cm</returns>
        ''' <remarks></remarks>
        Public Shared Function pixelsToCM(ByVal gr As Graphics, ByVal pixels As Integer) As Decimal
            Return CDec((pixels / gr.DpiX) * 2.54)
        End Function

        ''' <summary>
        ''' CMToPixels Function
        ''' </summary>
        ''' <param name="gr">the graphics object</param>
        ''' <param name="CM">a length in cm</param>
        ''' <returns>length in pixels</returns>
        ''' <remarks></remarks>
        Public Shared Function CMToPixels(ByVal gr As Graphics, ByVal CM As Decimal) As Integer
            Return CInt((gr.DpiX / 2.54) * CM)
        End Function

        ''' <summary>
        ''' pixelsSquaredToCMSquared Function
        ''' </summary>
        ''' <param name="gr">the graphics object</param>
        ''' <param name="pixels">an area in pixels²</param>
        ''' <returns>area in cm²</returns>
        ''' <remarks></remarks>
        Public Shared Function pixelsSquaredToCMSquared(ByVal gr As Graphics, ByVal pixels As Decimal) As Decimal
            Return CDec(pixels * ((2.54 / gr.DpiX) ^ 2))
        End Function

    End Class


End Class
