﻿

'Imports System.Runtime.InteropServices
Imports mousetest.mouseMeasurements

Public Class Form1
    Public Sub New()

        ' Dieser Aufruf ist für den Designer erforderlich.
        InitializeComponent()

        ' Fügen Sie Initialisierungen nach dem InitializeComponent()-Aufruf hinzu.


        Timer1.Enabled = True
        Timer1.Start()

    End Sub

    Private Sub Form1_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove

        'Me.TextBox1.Text = e.X & " , " & e.Y

    End Sub

    Dim lastPoint As New Point(0, 0)
    Dim keyCounter As Integer = 0


    Private Sub Timer1_Tick_1(sender As Object, e As EventArgs) Handles Timer1.Tick

        Me.Text = MousePosition.ToString

        Dim actualPoint As New Point(x:=MousePosition.X, y:=MousePosition.Y)

        If lastPoint = New Point(0, 0) Then
            lastPoint = New Point(x:=MousePosition.X, y:=MousePosition.Y)
        Else
            TextBox2.Text = lineLength(p1:=actualPoint, p2:=lastPoint).ToString

            'Me.TextBox1.Text =
            '    unitConverter.pixelsToCM(
            '    gr:=My.Forms.Form1.CreateGraphics,
            '    pixels:=measurement.lineLength(p1:=New Point(10, 100), p2:=New Point(20, 100)))

            'Me.TextBox1.Text =
            '    unitConverter.pixelsToCM(
            '    gr:=My.Forms.Form1.CreateGraphics,
            '    pixels:=measurement.lineLength(p1:=actualPoint, p2:=lastPoint))

            lastPoint = actualPoint

        End If


    End Sub

    Dim pointA As New Point(0, 0)


    Private Sub Form1_DoubleClick(sender As Object, e As EventArgs) Handles Me.DoubleClick

        Dim pointB As New Point(x:=MousePosition.X, y:=MousePosition.Y)
        Dim out As New List(Of String)


        If pointA = New Point(0, 0) Then
            pointA = New Point(x:=MousePosition.X, y:=MousePosition.Y)
            Me.TextBox3.Text = pointA.ToString
        Else
            out.Add(pointA.ToString)
            out.Add(pointB.ToString)

            out.Add(unitConverter.pixelsToCM(
                gr:=My.Forms.Form1.CreateGraphics,
                pixels:=lineLength(p1:=pointA, p2:=pointB)))
            Me.TextBox3.Text = Join(out.ToArray, vbCrLf)

            pointA = New Point(0, 0)

        End If



    End Sub



    Private WithEvents kbHook As New keyboardHook

    Private Sub kbHook_KeyDown(ByVal Key As System.Windows.Forms.Keys) Handles kbHook.KeyDown

        Me.keyCounter += 1
        Me.TextBox1.Text = Me.keyCounter

        If Key.ToString() = "A" Then
            MsgBox("a")
        End If
    End Sub




    'Public Class KeyboardHook

    '    <DllImport("User32.dll", CharSet:=CharSet.Auto, CallingConvention:=CallingConvention.StdCall)>
    '    Private Overloads Shared Function SetWindowsHookEx(ByVal idHook As Integer, ByVal HookProc As KBDLLHookProc, ByVal hInstance As IntPtr, ByVal wParam As Integer) As Integer
    '    End Function
    '    <DllImport("User32.dll", CharSet:=CharSet.Auto, CallingConvention:=CallingConvention.StdCall)>
    '    Private Overloads Shared Function CallNextHookEx(ByVal idHook As Integer, ByVal nCode As Integer, ByVal wParam As IntPtr, ByVal lParam As IntPtr) As Integer
    '    End Function
    '    <DllImport("User32.dll", CharSet:=CharSet.Auto, CallingConvention:=CallingConvention.StdCall)>
    '    Private Overloads Shared Function UnhookWindowsHookEx(ByVal idHook As Integer) As Boolean
    '    End Function

    '    <StructLayout(LayoutKind.Sequential)>
    '    Private Structure KBDLLHOOKSTRUCT
    '        Public vkCode As UInt32
    '        Public scanCode As UInt32
    '        Public flags As KBDLLHOOKSTRUCTFlags
    '        Public time As UInt32
    '        Public dwExtraInfo As UIntPtr
    '    End Structure

    '    <Flags()>
    '    Private Enum KBDLLHOOKSTRUCTFlags As UInt32
    '        LLKHF_EXTENDED = &H1
    '        LLKHF_INJECTED = &H10
    '        LLKHF_ALTDOWN = &H20
    '        LLKHF_UP = &H80
    '    End Enum

    '    Public Shared Event KeyDown(ByVal Key As Keys)
    '    Public Shared Event KeyUp(ByVal Key As Keys)

    '    Private Const WH_KEYBOARD_LL As Integer = 13
    '    Private Const HC_ACTION As Integer = 0
    '    Private Const WM_KEYDOWN = &H100
    '    Private Const WM_KEYUP = &H101
    '    Private Const WM_SYSKEYDOWN = &H104
    '    Private Const WM_SYSKEYUP = &H105

    '    Private Delegate Function KBDLLHookProc(ByVal nCode As Integer, ByVal wParam As IntPtr, ByVal lParam As IntPtr) As Integer

    '    Private KBDLLHookProcDelegate As KBDLLHookProc = New KBDLLHookProc(AddressOf KeyboardProc)
    '    Private HHookID As IntPtr = IntPtr.Zero

    '    Private Function KeyboardProc(ByVal nCode As Integer, ByVal wParam As IntPtr, ByVal lParam As IntPtr) As Integer
    '        If (nCode = HC_ACTION) Then
    '            Dim struct As KBDLLHOOKSTRUCT
    '            Select Case wParam
    '                Case WM_KEYDOWN, WM_SYSKEYDOWN
    '                    RaiseEvent KeyDown(CType(CType(Marshal.PtrToStructure(lParam, struct.GetType()), KBDLLHOOKSTRUCT).vkCode, Keys))
    '                Case WM_KEYUP, WM_SYSKEYUP
    '                    RaiseEvent KeyUp(CType(CType(Marshal.PtrToStructure(lParam, struct.GetType()), KBDLLHOOKSTRUCT).vkCode, Keys))
    '            End Select
    '        End If
    '        Return CallNextHookEx(IntPtr.Zero, nCode, wParam, lParam)
    '    End Function

    '    Public Sub New()
    '        HHookID =
    '            SetWindowsHookEx(WH_KEYBOARD_LL, KBDLLHookProcDelegate,
    '                System.Runtime.InteropServices.Marshal.GetHINSTANCE(System.Reflection.Assembly.GetExecutingAssembly.GetModules()(0)).ToInt64, 0)
    '        If HHookID = IntPtr.Zero Then
    '            Throw New Exception("Could not set keyboard hook")
    '        End If
    '    End Sub

    '    Protected Overrides Sub Finalize()
    '        If Not HHookID = IntPtr.Zero Then
    '            UnhookWindowsHookEx(HHookID)
    '        End If
    '        MyBase.Finalize()
    '    End Sub

    'End Class







    'Public Class measurement

    '    ''' <summary>
    '    ''' lineLength
    '    ''' </summary>
    '    ''' <param name="p1">point1</param>
    '    ''' <param name="p2">point2</param>
    '    ''' <returns>length in pixels between p1 and p2</returns>
    '    ''' <remarks></remarks>
    '    Public Shared Function lineLength(ByVal p1 As Point, ByVal p2 As Point) As Single
    '        Dim r As Rectangle = normalizeRect(p1, p2)
    '        Return CSng(Math.Sqrt(r.Width ^ 2 + r.Height ^ 2))
    '    End Function

    '    ''' <summary>
    '    ''' </summary>
    '    ''' <param name="p1">point1</param>
    '    ''' <param name="p2">point2</param>
    '    ''' <returns>a rectangle encapsulating p1, p2</returns>
    '    ''' <remarks></remarks>
    '    Private Shared Function normalizeRect(ByVal p1 As Point, ByVal p2 As Point) As Rectangle
    '        Dim r As New Rectangle
    '        If p1.X < p2.X Then
    '            r.X = p1.X
    '            r.Width = p2.X - p1.X
    '        Else
    '            r.X = p2.X
    '            r.Width = p1.X - p2.X
    '        End If
    '        If p1.Y < p2.Y Then
    '            r.Y = p1.Y
    '            r.Height = p2.Y - p1.Y
    '        Else
    '            r.Y = p2.Y
    '            r.Height = p1.Y - p2.Y
    '        End If
    '        Return r
    '    End Function

    'End Class


    'Public Class unitConverter

    '    ''' <summary>
    '    ''' pixelsToCM Function
    '    ''' </summary>
    '    ''' <param name="gr">the graphics object</param>
    '    ''' <param name="pixels">a length in pixels</param>
    '    ''' <returns>length in cm</returns>
    '    ''' <remarks></remarks>
    '    Public Shared Function pixelsToCM(ByVal gr As Graphics, ByVal pixels As Integer) As Decimal
    '        Return CDec((pixels / gr.DpiX) * 2.54)
    '    End Function

    '    ''' <summary>
    '    ''' CMToPixels Function
    '    ''' </summary>
    '    ''' <param name="gr">the graphics object</param>
    '    ''' <param name="CM">a length in cm</param>
    '    ''' <returns>length in pixels</returns>
    '    ''' <remarks></remarks>
    '    Public Shared Function CMToPixels(ByVal gr As Graphics, ByVal CM As Decimal) As Integer
    '        Return CInt((gr.DpiX / 2.54) * CM)
    '    End Function

    '    ''' <summary>
    '    ''' pixelsSquaredToCMSquared Function
    '    ''' </summary>
    '    ''' <param name="gr">the graphics object</param>
    '    ''' <param name="pixels">an area in pixels²</param>
    '    ''' <returns>area in cm²</returns>
    '    ''' <remarks></remarks>
    '    Public Shared Function pixelsSquaredToCMSquared(ByVal gr As Graphics, ByVal pixels As Decimal) As Decimal
    '        Return CDec(pixels * ((2.54 / gr.DpiX) ^ 2))
    '    End Function

    'End Class

End Class
