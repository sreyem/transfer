﻿
Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Design
Imports System.IO
Imports System.Text
Imports System.Web.Script.Serialization
Imports System.Windows.Forms
Imports System.Windows.Forms.Design
Imports System.Xml.Serialization

Imports Tools


<TypeConverter(GetType(propGridConverter))>
<Serializable>
Public Class chemStructureProperty

    Public Sub New()

    End Sub


    Public Function ShallowCopy() As chemStructureProperty
        Return DirectCast(Me.MemberwiseClone(), chemStructureProperty)
    End Function


    Private _chemStructure As Bitmap

    Public Shared CompoundName As String = ""

    ''' <summary>
    ''' Chemical Structure as a bitmap
    ''' </summary>
    ''' <returns></returns>
    <TypeConverter(GetType(propGridConverter))>
    <Editor(GetType(PictureEditor), GetType(UITypeEditor))>
    <XmlIgnore>
    <DisplayName("Chem. Structure")>
    <Description("Chemical Structure as a bitmap")>
    Public Property chemStructure() As Bitmap
        Get

            If PictureEditor.loadpic Then

                PictureEditor.loadpic = False
                _chemStructure = CType(PictureEditor.pictureBox.Image, Bitmap)
                PictureEditor.pictureBox = New PictureBox

            Else
                PictureEditor.pictureBox.Image = _chemStructure
            End If

            Return _chemStructure

        End Get
        Set(vStructure2Show As Bitmap)
            _chemStructure = vStructure2Show
        End Set
    End Property


#Region "De-Serialize"

    <Browsable(False), EditorBrowsable(EditorBrowsableState.Never)>
    <XmlElement("Chem_Structure")>
    Public Property pictureSerialized() As Byte()
        Get
            ' serialize
            If chemStructure Is Nothing Then
                Return Nothing
            End If
            Using ms As New MemoryStream()
                chemStructure.Save(ms, chemStructure.RawFormat)
                Return ms.ToArray()
            End Using
        End Get
        Set(value As Byte())
            ' de-serialize
            If value Is Nothing Then
                chemStructure = Nothing
            Else
                Using ms As New MemoryStream(value)
                    chemStructure = New Bitmap(ms)
                End Using
            End If
        End Set
    End Property

#End Region


End Class


Public Class PictureEditor

    Inherits UITypeEditor

    ' usage :  add 
    '<Editor(GetType(PictureEditor), GetType(UITypeEditor))>
    ' to property


    Public Shared WithEvents pictureBox As New PictureBox

    Public Shared TTip As New ToolTip
    Public Shared TTipTest As String = ""

    Public Shared loadpic As Boolean = False
    Public Shared savepic As Boolean = False

    Private editorService As IWindowsFormsEditorService

    Public Overrides Function GetEditStyle(
                            context As ITypeDescriptorContext) As UITypeEditorEditStyle
        Return UITypeEditorEditStyle.Modal
    End Function


    Public Overrides Function EditValue(
                            context As ITypeDescriptorContext,
                           provider As IServiceProvider,
                              value As Object) As Object

        editorService = DirectCast(
            provider.GetService(GetType(IWindowsFormsEditorService)),
            IWindowsFormsEditorService)

        With TTip

            .IsBalloon = True
            .InitialDelay = 1000
            .ReshowDelay = 500
            .AutoPopDelay = 5000
            .ShowAlways = True
            .UseAnimation = True


            .UseFading = True

            If IsNothing(pictureBox.Image) Then

                .SetToolTip(
                       control:=pictureBox,
                       caption:="dblClick to load new or save structure")
            Else
                .SetToolTip(
                       control:=pictureBox,
                       caption:=TTipTest)

            End If

        End With

        With pictureBox

            If Not IsNothing(.Image) Then

                .Size = New Size(
                     width:= .Image.Size.Width,
                    height:= .Image.Size.Height)

                .SizeMode = PictureBoxSizeMode.CenterImage
                .Dock = DockStyle.Fill

            End If

        End With

        editorService.DropDownControl(pictureBox)

        Return pictureBox.Image

    End Function


    Public Shared Sub load(sender As Object, e As EventArgs) Handles pictureBox.DoubleClick

        Dim ofd As New OpenFileDialog

        With ofd

            .InitialDirectory = My.Application.Info.DirectoryPath
            .Multiselect = False

        End With

        If IsNothing(pictureBox.Image) Then

            With ofd

                If .ShowDialog() = DialogResult.OK Then

                    Try
                        pictureBox.Load(.FileName)
                    Catch ex As Exception
                        MsgBox(ex.Message)
                    End Try

                    loadpic = True

                End If

            End With

        ElseIf MsgBox(
            Prompt:="Load (Yes) or save (No) Structure from/to png?",
            Buttons:=MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then

            With ofd

                If .ShowDialog() = DialogResult.OK Then

                    Try
                        pictureBox.Load(.FileName)
                    Catch ex As Exception
                        MsgBox(ex.Message)
                    End Try

                    loadpic = True

                End If

            End With

        Else

            Dim sfd As New SaveFileDialog

            With sfd

                .AddExtension = True
                .Filter = "PNG Bitmap (*.png)|*.png| All files (*.*)|*.*"

                If .ShowDialog() = DialogResult.OK Then

                    Try
                        pictureBox.Image.Save(.FileName)
                    Catch ex As Exception
                        MsgBox(ex.Message)
                    End Try

                End If

            End With

        End If

    End Sub

End Class

