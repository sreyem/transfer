﻿


Imports System.ComponentModel
Imports System.Drawing.Design
Imports System.Text
Imports System.Web.Script.Serialization
Imports System.Xml.Serialization


Imports Tools


''' <summary>
''' Phys-Chem
''' Mol mass and structure, VP and solubility
''' </summary>
<TypeConverter(GetType(propGridConverter))>
<Serializable>
Public Class physChem

#Region "    Constructor and name"


    Public Sub New()

    End Sub

    <Browsable(False)>
    <XmlIgnore> <ScriptIgnore>
    Public Property collapseStd As String() =
    {catVaporization, catDissolution, catDiffusion,
    catMisc,
    catPRLTXWOutput, catPELMOOutput, catPRZMOutput}

    <Browsable(False)>
    Public ReadOnly Property name As String
        Get

            Dim out As New StringBuilder
            Dim inputIncomplete As Boolean = False

            If Double.IsNaN(_molMass) Then
                Return Misc.not_defined
            Else
                out.Append(
                    "Mol mass   : " &
                   conv2String(
                    value:=_molMass,
                    unit:=" g/mol") &
                    " - " & vbCrLf)
            End If

            If Not Double.IsNaN(_preVapRef) Then
                out.Append(
                    getEnumDescription(EnumConstant:=EVAClassification) &
                    " - " & vbCrLf)
            Else
                out.Append("preVapRef ?" &
                           " - " & vbCrLf)
                inputIncomplete = True
            End If

            If Not Double.IsNaN(_sblWatRef) Then
                out.Append(
                    "Solubility : " &
                    conv2String(
                    value:=_sblWatRef,
                    unit:=" mg/L") &
                    " - " & vbCrLf)
            Else
                out.Append("sblWatRef ?")
                inputIncomplete = True
            End If


            Return out.ToString

        End Get
    End Property

#End Region

#Region "    Constants and std. values"

    ''' <summary>
    ''' Std. temperature for VP and solubility
    ''' </summary>
    Public Const stdTemRef As Double = 20.0
    Public Const temRefUnit As String = "(°C)"
    Public Const temRefMinMax As String = ""

    ''' <summary>
    ''' Std. molar enthalpy of vaporization = 95 kJ/mol
    ''' </summary>
    Public Const stdMolEntVap As Double = 95

    ''' <summary>
    ''' Std. molar enthalpy of dissolution = 27 kJ/mol
    ''' </summary>
    ''' <remarks></remarks>
    Public Const stdMolEntSlb As Double = 27

    ''' <summary>
    ''' Std. diffusion coefficient in water = 4.3E-5 m²/day
    ''' </summary>
    ''' <remarks></remarks>
    Public Const stdCofDifWatRef As Double = 0.000043

    ''' <summary>
    ''' Std. diffusion coefficient in air = 0.43 m²/day
    ''' </summary>
    ''' <remarks></remarks>
    Public Const stdCofDifAirRef As Double = 0.43

#End Region


    Public Event fill()

    Private Sub physChem_fill() Handles Me.fill

        createPEARLPhysChem()
        createPELMOVolatilization()

        getPRZM_RECORD26_PhyChem_Description()
        getPRZM_RECORD26_PhysChem(physChemList:={Me})

    End Sub


    Public Const CATMolarMassStructure As String = "01  Molar mass and Structure"

#Region "    01  Molar mass and Structure"

    Private _iop As String = "|IOP|"

    <DisplayName(
        "Substance Code")>
    <Description(
    "3 letter substance code" & vbCrLf &
    "")>
    <Browsable(True)>
    <RefreshProperties(RefreshProperties.All)>
    <Category(CATMolarMassStructure)>
    <XmlIgnore> <ScriptIgnore>
    Public Property iop As String
        Get
            Return _iop
        End Get
        Set(value As String)
            _iop = value
            RaiseEvent fill()
        End Set
    End Property


    ''' <summary>
    ''' Chemical structure
    ''' as bitmap in png format
    ''' </summary>
    <DisplayName(
        "Structure")>
    <Description(
    "Chemical structure" & vbCrLf &
    "as bitmap in png format")>
    <Browsable(True)>
    <RefreshProperties(RefreshProperties.All)>
    <Category(CATMolarMassStructure)>
    Public Property chemStructure As New chemStructureProperty


    Private _molMass As Double = stdDblEmpty

    ''' <summary>
    ''' Molar mass in g/mol
    ''' [10.0 - 10000 ; MolMas]
    ''' </summary>
    <Category(CATMolarMassStructure)>
    <DisplayName(
    "Molar Mass")>
    <Description(
    "in g/mol [10.0 - 10000, MolMas]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.00'|unit=' g/mol'")>
    <DefaultValue(stdDblEmpty)>
    Public Property molMass As Double
        Get
            Return _molMass
        End Get
        Set

            Try

                If Value < 10 OrElse
                   Value > 10000 Then

                    MsgBox(
                        Prompt:=Value.ToString("0.00") &
                        " g/mol : " & "Molar mass exceeds limits [10|10000]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else
                    _molMass = Value
                    RaiseEvent fill()
                End If

            Catch ex As Exception

                mylog(
                    LogTxt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property

    Private _smilesCode As String = String.Empty

    ''' <summary>
    ''' Smiles Code
    ''' Simplified Molecular Input
    ''' Line Entry Specification, click for editor 
    ''' </summary>
    <Category(CATMolarMassStructure)>
    <DisplayName(
    "Smiles Code")>
    <Description(
    "Simplified Molecular Input " & vbCrLf &
    "Line Entry Specification, click '...' for editor")>
    <Browsable(True)>
    <RefreshProperties(RefreshProperties.All)>
    <Editor(GetType(buttonEmulator), GetType(UITypeEditor))>
    <DefaultValue("")>
    Public Property smilesCode As String
        Get
            Return _smilesCode
        End Get
        Set(value As String)

            If value.Contains(buttonEmulator.Clicked) Then
                Process.Start("https://pubchem.ncbi.nlm.nih.gov/edit2/index.html")
            Else
                _smilesCode = value
                RaiseEvent fill()
            End If

        End Set
    End Property

#End Region

    Public Const catVPSolubility As String = "02  VP and Solubility"

#Region "    02  VP and Solubility"

#Region "    Vapor pressure incl. ref temp."

    Private _preVapRef As Double = stdDblEmpty

    ''' <summary>
    ''' Saturated vapor pressure
    ''' in Pa [0|2.0E+05 ; PreVapRef]
    ''' </summary>
    <DisplayName(
        "Vapor Pressure")>
    <Description(
    "Saturated Vapor pressure" & vbCrLf &
    "in Pa [0|2.0E+05 ; PreVapRef]")>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <Category(catVPSolubility)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
    "format= '0.00E-00'|unit=' Pa'")>
    <DefaultValue(stdDblEmpty)>
    Public Property preVapRef As Double
        Get
            Return _preVapRef
        End Get
        Set(value As Double)

            Try

                If value < 0 OrElse
                   value > 200000.0 Then

                    MsgBox(
                        Prompt:=value.ToString("0.00E00") &
                        " Pa : " & "Vapor Pressure exceeds limits [0|2e5]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else

                    _preVapRef = value

                    'EVA classification
                    EVAClassification = convertVaporPressure2EVAClassification(_preVapRef)

                    RaiseEvent fill()

                End If

            Catch ex As Exception

                mylog(
                    LogTxt:=value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property

#Region "    EVA VP Classification"

    ''' <summary>
    ''' converts vapor pressure in PA
    ''' into the respective EVA classification
    ''' </summary>
    ''' <param name="vaporPressure">
    ''' vapor pressure in PA
    ''' </param>
    ''' <returns>
    ''' "non_volatile","semi_low",
    ''' "semi_medium","volatile"
    ''' </returns>
    Public Shared Function convertVaporPressure2EVAClassification(
                                    vaporPressure As Double) As eEVAClassificationVP
        If Double.IsNaN(vaporPressure) OrElse vaporPressure = stdDblEmpty Then
            Return eEVAClassificationVP.not_dev
        ElseIf vaporPressure = 0 Then
            Return eEVAClassificationVP.non_volatile
        ElseIf vaporPressure < 0.00001 Then
            Return eEVAClassificationVP.non_volatile
        ElseIf vaporPressure >= 0.00001 AndAlso vaporPressure < 0.0001 Then
            Return eEVAClassificationVP.semi_low
        ElseIf vaporPressure >= 0.0001 AndAlso vaporPressure < 0.005 Then
            Return eEVAClassificationVP.semi_medium
        Else
            Return eEVAClassificationVP.volatile
        End If

    End Function


    ''' <summary>
    ''' EVA classification of volatility
    ''' </summary>
    <DisplayName(
        "EVA Classification")>
    <Description(
    "<1E-5 non      ; 1E-5 <= VP < 1e-4 low " & vbCrLf &
    ">5E-3 volatile ; 1E-4 <= VP < 5e-3 semi")>
    <[ReadOnly](True)>
    <DefaultValue(CInt(eEVAClassificationVP.non_volatile))>
    <Category(catVPSolubility)>
    <XmlIgnore>
    <Browsable(True)>
    Public Property EVAClassification As eEVAClassificationVP = eEVAClassificationVP.not_dev

    <TypeConverter(GetType(enumConverter(Of eEVAClassificationVP)))>
    Public Enum eEVAClassificationVP


        <Description(enumConverter(Of Type).not_defined)>
        not_dev = -1

        <Description("non volatile (VP < 1.0E-05 Pa)")>
        non_volatile

        <Description("low volatile (1.0E-05 Pa <= VP > 1.0E-04 Pa)")>
        semi_low

        <Description("semi volatile (1.0E-04 Pa <= VP > 5.0E-03 Pa)")>
        semi_medium

        <Description("volatile (VP >= 5.0E-03 Pa)")>
        volatile


    End Enum

#End Region


    Private _temRefVap As Double = stdTemRef

    ''' <summary>
    ''' Ref. temp. for vapor pressure
    ''' in °C [0|40 ; TemRefVap]
    ''' </summary>
    <DisplayName(
        "  at ref. temp.")>
    <Description(
    "Ref. temp. for vapor pressure" & vbCrLf &
    "in °C [0|40 ; TemRefVap, std. = 20°C]")>
    <[ReadOnly](False)>
    <Editor(GetType(nudValueEditorInteger), GetType(UITypeEditor))>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
    "format= '0.0'|unit=' °C'")>
    <Category(catVPSolubility)>
    <DefaultValue(stdTemRef)>
    Public Property temRefVap As Double
        Get
            Return _temRefVap
        End Get
        Set

            Try

                If Value < 0 OrElse
                   Value > 40 Then

                    MsgBox(
                        Prompt:=Value & "°C : " &
                        "Ref temp for vapor pressure exceeds limits [0|40]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else
                    _temRefVap = Value
                    RaiseEvent fill()
                End If

            Catch ex As Exception

                MsgBox(
                    Prompt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                    Buttons:=MsgBoxStyle.Critical,
                    Title:="Unknown Error")

            End Try

        End Set
    End Property


#End Region


#Region "    Solubility incl. ref temp"

    Private _sblWatRef As Double = stdDblEmpty

    ''' <summary>
    ''' Water solubility
    ''' in mg/L [0.001|1e6]; SlbWatRef]
    ''' </summary>
    <DisplayName(
        "Solubility")>
    <Description(
    "Water solubility" & vbCrLf &
    "in mg/L [0.001|1e6 ; SlbWatRef]")>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <Category(catVPSolubility)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
    "format= 'G4'|unit=' mg/L'")>
    <DefaultValue(stdDblEmpty)>
    Public Property slbWatRef As Double
        Get
            Return _sblWatRef
        End Get
        Set(value As Double)

            Try

                If value < 0.001 OrElse
                   value > 1000000 Then

                    MsgBox(
                        Prompt:=value.ToString("0.00") &
                        " mg/L : " & "Solubility exceeds limits [0.001|1e6]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else
                    _sblWatRef = value
                    RaiseEvent fill()
                End If

            Catch ex As Exception

                mylog(
                    LogTxt:=value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property


    Private _temRefSlb As Double = stdTemRef

    ''' <summary>
    ''' Ref. temp. for solubility
    ''' in °C [0|40 ; TemRefSol]
    ''' </summary>
    <DisplayName(
        "  at ref. temp.")>
    <Description(
    "Ref. temp. for water solubility" & vbCrLf &
    "in °C [0|40 ; TemRefSlb, std. = 20°C]")>
    <[ReadOnly](False)>
    <Editor(GetType(nudValueEditorInteger), GetType(UITypeEditor))>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
    "format= '0.0'|unit=' °C'")>
    <Category(catVPSolubility)>
    <DefaultValue(stdTemRef)>
    Public Property temRefSlb As Double
        Get
            Return _temRefSlb
        End Get
        Set

            Try

                If Value < 0 OrElse
                   Value > 40 Then

                    MsgBox(
                        Prompt:=Value & "°C : " &
                        "Ref temp for solubility exceeds limits [0|40]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else
                    _temRefSlb = Value
                    RaiseEvent fill()
                End If

            Catch ex As Exception

                MsgBox(
                    Prompt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                    Buttons:=MsgBoxStyle.Critical,
                    Title:="Unknown Error")

            End Try

        End Set
    End Property

#End Region

#End Region

    Public Const catMisc As String = "03  Misc"

#Region "    03  Misc"

    <AttributeProvider("format= 'G4'|unit=''")>
    <Category(catMisc)>
    <TypeConverter(GetType(dblConv))>
    <DefaultValue(stdDblEmpty)>
    Public Property logP As Double = stdDblEmpty

    <AttributeProvider("format= 'G4'|unit=''")>
    <Category(CATMisc)>
    <TypeConverter(GetType(dblConv))>
    <DefaultValue(stdDblEmpty)>
    Public Property pKa As Double = stdDblEmpty

#End Region


    Public Const catVaporization As String = "04a Vaporization"
    Public Const catDissolution As String = "04b Dissolution"
    Public Const catDiffusion As String = "04c Diffusion"


#Region "    04  'Constants'"

#Region "    Vaporization"

    Private _molEntVap As Double = stdMolEntVap

    ''' <summary>
    ''' MolEntVap
    ''' Molar enthalpy of vaporization in kJ/mol
    ''' [-200|200; MolEntVap; std. = 95 kJ/mol]
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName("MolEntVap")>
    <Description("Molar enthalpy of vaporization in kJ/mol" & vbCrLf &
                 "[-200|200; MolEntVap; std. = 95 kJ/mol]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(catVaporization)>
    <DefaultValue(stdMolEntVap)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
    "format= '0'|unit=' kJ/mol'")>
    Public Property molEntVap As Double
        Get

            Return _molEntVap

        End Get
        Set

            Try

                If Value < -200 OrElse
                   Value > 200 Then

                    MsgBox(
                        Prompt:=Value.ToString("0.00") & " mg/L : " & "Molar enthalpy of vaporization [-200|200]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else

                    If Value <> CDbl(stdMolEntVap) Then

                        If _
                            MsgBox(
                                Prompt:=Value & " kJ/mol : Really? std. value is " & stdMolEntVap &
                                                " kJ/mol and you shouldn't touch it!!",
                                Buttons:=MsgBoxStyle.YesNo,
                                Title:="Don't Change BASIC values!!") <> MsgBoxResult.No Then

                            _molEntVap = Value

                        End If

                    Else
                        _molEntVap = Value
                    End If

                End If

            Catch ex As Exception

                mylog(
                    LogTxt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property


    ''' <summary>
    ''' ENPY
    ''' Enthalpy of vaporization in kcal/mol
    ''' PRZM value; std. = 22.7 kcal/mol, 1kcal = 4.184J
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
    "PRZM : ENPY")>
    <Description(
    "Enthalpy of vaporization" & vbCrLf &
    "PRZM value; std. = 22.7 kcal/mol = 95 kJ/mol, 1kcal = 4.184 J")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(catVaporization)>
    <DefaultValue(22.7)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
    "format= '0.0'|unit=' kJ/mol'")>
    Public ReadOnly Property ENPY As Double
        Get

            Try
                If _molEntVap = stdDblEmpty Then
                    Return stdDblEmpty
                Else
                    Return Math.Round(_molEntVap / 4.184, digits:=1)
                End If

            Catch ex As Exception

                mylog(
                    LogTxt:="MolEntVap : " & _molEntVap & "kJ/mol" & vbCrLf &
                            "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")

                Return stdDblEmpty

            End Try

        End Get
    End Property

#End Region

#Region "    Dissolution"

    Private _molEntSlb As Double = StdMolEntSlb

    ''' <summary>
    ''' Molar enthalpy of dissolution in kJ/mol
    ''' -200|200; MolEntSlb; std. = 27 kJ/mol
    ''' MolEntSlb
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
    "MolEntSlb")>
    <Description(
    "Molar enthalpy of dissolution in kJ/mol" & vbCrLf &
    "[-200|200; MolEntSlb; std. = 27 kJ/mol]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(catDissolution)>
    <DefaultValue(StdMolEntSlb)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
    "format= '0'|unit=' kJ/mol'")>
    Public Property molEntSlb As Double
        Get
            Return _molEntSlb
        End Get
        Set

            Try

                If Value < -200 OrElse
                   Value > 200 Then

                    MsgBox(
                        Prompt:=Value.ToString("0.00") & " mg/L : " & "Molar enthalpy of dissolution [-200|200]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else

                    If Value <> CDbl(StdMolEntSlb) Then

                        If _
                         MsgBox(
                             Prompt:=Value & " kJ/mol : Really? std. value is " & StdMolEntSlb &
                                             " kJ/mol and you shouldn't touch it!!",
                             Buttons:=MsgBoxStyle.YesNo,
                             Title:="Don't Change BASIC values!!") <> MsgBoxResult.No Then

                            _molEntSlb = Value

                        End If

                    Else
                        _molEntSlb = Value
                    End If
                End If

            Catch ex As Exception

                mylog(
                    LogTxt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property


#End Region

#Region "    Diffusion"

    Private _cofDifWatRef As Double = StdCofDifWatRef

    ''' <summary>
    ''' Reference diffusion coefficient in water in m²/day
    ''' [0|0.002; CofDifWatRef; std. = 4.3E-5 m²/day]
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
    "CofDifWatRef")>
    <Description(
    "Reference diffusion coefficient in water in m²/day" & vbCrLf &
    "[0|0.002; CofDifWatRef; std. = 0.000043 (4.3E-05) m²/day]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(catDiffusion)>
    <DefaultValue(StdCofDifWatRef)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
    "format= '0.0E-00'|unit=' m²/day'")>
    Public Property cofDifWatRef As Double
        Get
            Return _cofDifWatRef
        End Get
        Set(value As Double)

            Try


                If value < 0 OrElse
                   value > 0.002 Then

                    MsgBox(
                        Prompt:=value.ToString("0.00") & "m²/day : " & "Diffusion coefficient in water [0|0.002]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")
                Else

                    If value <> CDbl(StdCofDifWatRef) Then

                        If _
                            MsgBox(
                                Prompt:=value & " m²/day : Really? std. value is " & CDbl(StdCofDifWatRef) &
                                                " m²/day and you shouldn't touch it!!",
                                Buttons:=MsgBoxStyle.YesNo,
                                Title:="Don't Change BASIC values!!") <> MsgBoxResult.No Then

                            _cofDifWatRef = value
                        End If

                    Else
                        _cofDifWatRef = value
                    End If

                End If

            Catch ex As Exception

                mylog(
                    LogTxt:=value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property


    Private _cofDifAirRef As Double = StdCofDifAirRef

    ''' <summary>
    ''' Reference diffusion coefficient in water in m²/day
    ''' [0|0.002; CofDifWatRef; std. = 4.3E-5 m²/day]
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
    "CofDifAirRef")>
    <Description(
    "Reference diffusion coefficient in air in [m²/day]" & vbCrLf &
    "PEARL 0.1|3; CofDifAirRef; std. = 0.43 m²/day]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(catDiffusion)>
    <DefaultValue(StdCofDifAirRef)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
    "format= '0.0E-00'|unit=' m²/day'")>
    Public Property cofDifAirRef As Double
        Get
            Return _cofDifAirRef
        End Get
        Set(value As Double)

            Try

                If value < 0.1 OrElse
                   value > 3 Then

                    MsgBox(
                        Prompt:=value.ToString("0.00") & "m^2/day : " & "Diffusion coefficient in air [0.1|3]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else

                    If _
                MsgBox(
                    Prompt:=value & " m^2/day : Really? std. value is 0.43 m^2/day and you shouldn't touch it!!",
                    Buttons:=MsgBoxStyle.YesNo,
                    Title:="Don't Change BASIC values!!") <> MsgBoxResult.No Then


                        _cofDifAirRef = value

                    End If

                End If

            Catch ex As Exception

                mylog(
                    LogTxt:=value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property


    Private _temRefDif As Double = stdTemRef

    ''' <summary>
    ''' Ref. temp. for Diff. coeff
    ''' in °C [0|40 ; TemRefDif]
    ''' </summary>
    <DisplayName(
        "  at ref. temp.")>
    <Description(
    "Ref. temp. for Diff. coeff" & vbCrLf &
    "in °C [0|40 ; TemRefDif, std. = 20°C]")>
    <[ReadOnly](False)>
    <Editor(GetType(nudValueEditorInteger), GetType(UITypeEditor))>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
    "format= '0.0'|unit=' °C'")>
    <Category(catDiffusion)>
    <DefaultValue(stdTemRef)>
    Public Property temRefDif As Double
        Get
            Return _temRefDif
        End Get
        Set

            Try

                If Value < 0 OrElse
                   Value > 40 Then

                    MsgBox(
                        Prompt:=Value & "°C : " &
                        "Ref temp for Diff. coeff measur. exceeds limits [0|40]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else
                    _temRefDif = Value
                End If
            Catch ex As Exception

                MsgBox(
                    Prompt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                    Buttons:=MsgBoxStyle.Critical,
                    Title:="Unknown Error")

            End Try

        End Set
    End Property


#Region "    Derived PRZM values"

    ''' <summary>
    ''' Henry's law constant in J/mol
    ''' (VP * MolMass / Solubility)/ (R * Tref)
    ''' </summary>
    ''' <returns></returns>
    <Category(catDiffusion)>
    <DisplayName(
    "PRZM Henry")>
    <Description(
    "Henry's law constant (dimensionsless)" & vbCrLf &
    "(VP * MolMass / Solubility)/ (R * Tref)")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '.00E-00'")>
    <XmlIgnore>
    Public ReadOnly Property henrykPRZM As Double
        Get

            Try

                If _
                    Not Double.IsNaN(_preVapRef) AndAlso
                    Not Double.IsNaN(_sblWatRef) AndAlso
                    Not Double.IsNaN(_molMass) Then

                    Return ((_preVapRef * _molMass / _sblWatRef) /
                                   (8.3143 * (_temRefVap + 273.15)))
                Else
                    Return Double.NaN
                End If

            Catch ex As Exception
                Return Double.NaN
            End Try

        End Get
    End Property

    ''' <summary>
    ''' DAIR
    ''' Diffusion coefficient in the air in cm^2/day
    ''' PRZM value; std. = 4300.00 cm^2/day
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName("PRZM  : DAIR Base CofDifAirRef")>
    <Description("Diffusion coefficient in the air in cm²/day" & vbCrLf &
                 "PRZM value; std. = 4300.00 [cm²/day]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATDiffusion)>
    <DefaultValue(4300.0)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= 'G5'|unit=' cm²/day'")>
    Public ReadOnly Property DAIR As Double
        Get

            Try
                Return _cofDifAirRef * 100 * 100
            Catch ex As Exception

                mylog(
                   LogTxt:="CofDifAirRef : " & _cofDifAirRef & " m²/day" & vbCrLf &
                           "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                   Log2MsgBox:=True,
                   MsgBoxBtn:=MsgBoxStyle.Critical,
                   MsgTitle:="Unknown Error")

                Return Double.NaN
            End Try

        End Get
    End Property


    ''' <summary>
    ''' Diffusion coefficient in water in m²/s
    ''' MACRO value; std. = 4.976852E-10 m²/s
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
    "MACRO : DIFF Base CofDifWatRef")>
    <Description(
    "Diffusion coefficient in water in m²/s" & vbCrLf &
    "MACRO value; std. = 4.976852E-10 [m²/s] = cofDifWatRef / (60 * 60 * 24)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(catDiffusion)>
    <DefaultValue(0.0000000004976852)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
    "format= '0.0000E00'|unit=' m²/s'")>
    Public ReadOnly Property DIFF As Double
        Get

            If Not Double.IsNaN(_cofDifWatRef) Then
                Return _cofDifWatRef / (60 * 60 * 24)
            Else
                Return Double.NaN
            End If

        End Get
    End Property

#End Region



#End Region

#Region "    PELMO"

    ''' <summary>
    ''' Henry's law constant in J/mol
    ''' (VP * MolMass / Solubility)/ (R * Tref)
    ''' </summary>
    ''' <returns></returns>
    <Category(catDiffusion)>
    <DisplayName(
    "PELMO Henry")>
    <Description(
    "Henry's law constant in J/mol" & vbCrLf &
    "HENRYK (PRZM) * R * T <=> VP * MolMass / Solubility")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
    "format= '0.00E-00'|unit=' J/mol'")>
    <XmlIgnore>
    Public ReadOnly Property henrykPELMO As Double
        Get

            Try

                If _
                    Not Double.IsNaN(henrykPRZM) Then

                    Return henrykPRZM * (8.3143 * (_temRefVap + 273.15))
                Else
                    Return stdDblEmpty
                End If

            Catch ex As Exception
                Return stdDblEmpty
            End Try

        End Get
    End Property

    ''' <summary>
    ''' Diffusion coefficient in water in cm²/s
    ''' PELMO value; std. = 0.0498 cm²/s
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
    "PELMO : 'diff air' Base CofDifWatRef")>
    <Description(
    "Diffusion coefficient in water in cm²/s" & vbCrLf &
    "PELMO value; std. = 0.0498 [cm²/s] = DIFF * 1e8")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(catDiffusion)>
    <DefaultValue(0.0498)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
    "format= '0.0000'|unit=' cm²/s'")>
    Public ReadOnly Property diffCoeffAirPELMO As Double
        Get

            If Not Double.IsNaN(DIFF) Then
                Return Math.Round(DIFF * 1000 * 1000 * 100, digits:=4)
            Else
                Return stdDblEmpty
            End If

        End Get
    End Property


    Public Const StdDepthVolat As Double = 0.1

    <Category(catDiffusion)>
    <DefaultValue(StdDepthVolat)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.00'|unit=' cm'")>
    Public Property depthVolat As Double = StdDepthVolat


    Public Const stdHV As Double = 98400

    <Category(catDiffusion)>
    <DefaultValue(stdHV)>
    Public Property HV As Double = stdHV


#End Region

#End Region

    Public Const catPRLTXWOutput As String = "05a PRL / TXW Out"
    Public Const catPRZMOutput As String = "05b PRZM Out"
    Public Const catPELMOOutput As String = "05c PELMO Out"

#Region "    05  Outputs, Experts only"

    Public Const browseOut As Boolean = True

#Region "    PRZM RECORD26"

    ''' <summary>
    ''' Description for PRZM RECORD26 parameters
    ''' Diffusion coefficient
    ''' Henry's law constant and enthalpy of vaporization
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName("RECORD26 Description")>
    <Description("Description for RECORD26 parameters")>
    <Browsable(browseOut)>
    <[ReadOnly](True)>
    <Category(catPRZMOutput)>
    <XmlIgnore>
    Public Property PRZM_RECORD26_Description As String()


    ''' <summary>
    ''' RECORD26 PRZM
    ''' Diffusion coefficient
    ''' Henry's law constant and enthalpy of vaporization
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName("RECORD26 PRZM")>
    <Description("Diffusion coefficient" & vbCrLf &
                 "Henry's law constant and enthalpy of vaporization")>
    <Browsable(browseOut)>
    <[ReadOnly](True)>
    <Category(catPRZMOutput)>
    <XmlIgnore>
    Public Property PRZM_RECORD26 As String()


#Region "    Methods"

    Public Enum eNoOfSubst
        ParOnly
        ParMet01
        ParMet01Met02
    End Enum

    Public Sub getPRZM_RECORD26_PhyChem_Description(
                       Optional NoOfSubst As eNoOfSubst = eNoOfSubst.ParOnly)

        Dim out As New List(Of String)
        Dim header As String = String.Empty

        out.AddRange(
       {"*** --- RECORD 26 PhysChem ---",
        "*** 01 DAIR    Diffusion coefficient for the pesticide(s) in the air",
        "***            std. = 4300 cm°2 day-1",
        "*** 02 HENRYK  Henry's law constant of the pesticide(s)",
        "***            in J/mol",
        "*** 03 ENPY    Enthalpy of vaporization of the pesticide(s)",
        "***            std. = 22.7 kcal/mole",
        "*** "})

        header = "*** PAR01   PAR02   PAR03"

        If NoOfSubst = eNoOfSubst.ParMet01 Then
            header &= " |  MET01   MET02   MET03"
        ElseIf NoOfSubst = eNoOfSubst.ParMet01Met02 Then
            header &= " |  M0101   M0102   M0103 |  M0201   M0202   M0203"
        End If

        out.Add(header)

        PRZM_RECORD26_Description = out.ToArray

    End Sub

    Public Sub getPRZM_RECORD26_PhysChem(physChemList As physChem())

        Dim out As New List(Of String)
        Dim row As New StringBuilder

        For counter = 0 To physChemList.Count - 1

            With physChemList(counter)

                row.Append(.DAIR.ToString("0.00").PadLeft("*** PAR01".Count))
                row.Append(.henrykPRZM.ToString(".00E-00").PadLeft("   PAR02".Count))
                row.Append(.ENPY.ToString("0.00").PadLeft("   PAR03".Count))

            End With

        Next

        out.Add(row.ToString)

        PRZM_RECORD26 = out.ToArray

    End Sub

#End Region

#End Region

#Region "    TOXSWA and PEARL"

    Public Sub createPEARLPhysChem(
                           Optional valueEndPos As Integer = valueEndPos,
                           Optional nameEndPos As Integer = nameEndPos,
                           Optional unitEndPos As Integer = unitEndPos,
                           Optional minMaxPos As Integer = minMaxPos,
                           Optional IOP As String = "",
                           Optional padPos As Integer = 20)

        Dim out As New List(Of String)

        Dim header As New List(Of String)
        Dim values As New List(Of String)
        Dim std As New List(Of String)


        Dim description As String
        Dim padDelimiter As String = " = "
        Dim row As String

        If IOP = "" Then
            IOP = Me.iop
        End If


#Region "    Overview"

        header.Add("*** PhysChem ***")
        header.Add(align2strings("* Molar Mass", _molMass & " g/mol",
                    padPos:=padPos, padDelimiter:=padDelimiter))
        header.Add(align2strings("* Vapor Pressure", _preVapRef & " Pa at " &
                                            _temRefVap & "°C",
                    padPos:=padPos, padDelimiter:=padDelimiter))
        header.Add(align2strings("* ", getEnumDescription(EVAClassification),
                    padPos:=padPos, padDelimiter:=padDelimiter))
        header.Add(align2strings("* Water Solubility", _sblWatRef & " mg/L at " &
                                                _temRefSlb & "°C",
                    padPos:=padPos, padDelimiter:=padDelimiter))

        header.Add("* ")

#End Region

#Region "    Molar Mass"

        row =
            createPrlRow(
                Value:=_molMass,
                iop:=IOP,
                parameterName:="MolMas_",
                unit:="(g/mol)",
                description:="Molar mass of parent substance",
                range:="[10.0|10000]",
                valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

        values.Add(row)

#End Region

#Region "    VP"

        If Me.temRefVap <> stdTemRef Then

            description = "Vapor pressure of substance"

            row = createPrlRow(
                    Value:=_preVapRef,
                    iop:=IOP,
                    parameterName:="PreVapRef_",
                    unit:="(Pa)",
                    description:=description,
                    range:="[0|2e5]",
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

            values.Add(row)

            description = "Std. value (20°C) for VP temp. changed !!!"
            header.Add("* " & description)

            row = createPrlRow(
                    Value:=_temRefVap,
                    iop:=IOP,
                    parameterName:="TemRefVap_",
                    unit:=temRefUnit,
                    description:=description,
                    range:=temRefMinMax,
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

            values.Add(row)

        Else

            description = "Vapor pressure of substance   at " & Me.temRefVap & "°C"

            row = createPrlRow(
                    Value:=_preVapRef,
                    iop:=IOP,
                    parameterName:="PreVapRef_",
                    unit:="(Pa)",
                    description:=description,
                    range:="[0|2e5]",
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

            values.Add(row)

            description = "Std vapor pressure measurement temperature"

            row = createPrlRow(
                    Value:=_temRefVap,
                    iop:=IOP,
                    parameterName:="TemRefVap_",
                    unit:=temRefUnit,
                    description:=description,
                    range:=temRefMinMax,
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

            std.Add(row)

        End If

#End Region

#Region "    Solubility"

        If Me.temRefSlb <> stdTemRef Then

            description = "Water solubility of substance"

            row = createPrlRow(
                Value:=slbWatRef,
                iop:=IOP,
                parameterName:="SlbWatRef_",
                unit:="(mg/L)",
                description:=description,
                range:="[0.001|1e6]",
                valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

            values.Add(row)

            description = "Std. value (20°C) for solub. temp. changed !!!"
            header.Add("* " & description)

            row =
            createPrlRow(
                Value:=_temRefSlb,
                iop:=IOP,
                parameterName:="TemRefSlb_",
                unit:=temRefUnit,
                description:=description,
                range:=temRefMinMax,
                valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

            values.Add(row)

        Else

            description = "Water solubility of substance at " & Me.temRefSlb & "°C"

            row = createPrlRow(
               Value:=slbWatRef,
               iop:=IOP,
               parameterName:="SlbWatRef_",
               unit:="(mg/L)",
               description:=description,
               range:="[0.001|1e6]",
                valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

            values.Add(row)

            description = "Std. water solubility measurement temperature"

            row =
                createPrlRow(
                    Value:=_temRefSlb,
                    iop:=IOP,
                    parameterName:="TemRefSlb_",
                    unit:=temRefUnit,
                    description:=description,
                    range:=temRefMinMax,
                valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

            std.Add(row)

        End If

#End Region

#Region "    Constants"

        row = createPrlRow(
                Value:=_molEntVap,
                iop:=IOP,
                parameterName:="MolEntVap_",
                unit:="(kJ/mol)",
                description:="Molar enthalpy of vaporization",
                range:="[-200|200]",
                valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

        If Me.molEntVap <> stdMolEntVap Then

            header.AddRange(
            {
            "*",
            "* Std. value (" & stdMolEntVap & " kJ/mol) for molar enthalpy of vaporization changed !!!",
            "*"
            })

            values.AddRange(
            {
            "*",
            "* Std. value (" & stdMolEntVap & " kJ/mol) for molar enthalpy of vaporization changed !!!",
            row,
            "*"
            })

        Else
            std.Add(row)
        End If

        row = createPrlRow(
                Value:=_molEntSlb,
                iop:=IOP,
                parameterName:="MolEntSlb_",
                unit:="(kJ/mol)",
                description:="Molar enthalpy of dissolution",
                range:="[-200|200]",
                valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

        If Me.molEntSlb <> stdMolEntSlb Then

            header.AddRange(
            {
            "*",
            "* Std. value (" & stdMolEntVap & " kJ/mol) for molar enthalpy of dissolution changed !!!",
            "*"
            })

            values.AddRange(
            {
            "*",
            "* Std. value (" & stdMolEntVap & " kJ/mol) for molar enthalpy of dissolution changed !!!",
            row,
            "*"
            })

        Else
            std.Add(row)
        End If

        row = createPrlRow(
                Value:=_cofDifWatRef,
                iop:=IOP,
                parameterName:="CofDifWatRef_",
                unit:="(m²/d)",
                description:="Reference diff. coeff. in water",
                range:="[10e-5|3e-4]",
                valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

        If Me.molEntVap <> stdMolEntVap Then

            header.AddRange(
            {
            "*",
            "* Std. value (" & stdMolEntVap & " m²/d) for reference diffusion. coefficient. in water changed !!!",
            "*"
            })

            values.AddRange(
            {
            "*",
            "* Std. value (" & stdMolEntVap & " m²/d) for reference diffusion. coefficient. in water changed !!!",
            row,
            "*"
            })

        Else
            std.Add(row)
        End If

        row = createPrlRow(
                Value:=_cofDifAirRef,
                iop:=IOP,
                parameterName:="CofDifAirRef_",
                unit:="(m²/d)",
                description:="Reference diff. coeff. in air",
                range:="0.1|3",
                valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

        If Me.molEntVap <> stdMolEntVap Then

            header.AddRange(
            {
            "*",
            "* Std. value (4.3 m²/d) for reference diffusion. coefficient. in air changed !!!",
            "*"
            })

            values.AddRange(
            {
            "*",
            "* Std. value (4.3 m²/d) for reference diffusion. coefficient. in air changed !!!",
            row,
            "*"
            })

        Else
            std.Add(row)
        End If

        If Me.temRefDif <> stdTemRef Then

            description = "Std. value (20°C) for diff. coeff meas. temp. changed !!!"

            row = createPrlRow(
                    Value:=_temRefDif,
                    iop:=IOP,
                    parameterName:="TemRefDif_",
                    unit:=temRefUnit,
                    description:=description,
                    range:=temRefMinMax,
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

            values.Add(row)
            header.Add(description)

        Else

            description = "Diff. coeff measurement temperature"

            row = createPrlRow(
                    Value:=_temRefDif,
                    iop:=IOP,
                    parameterName:="TemRefDif_",
                    unit:=temRefUnit,
                    description:=description,
                    range:=temRefMinMax,
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

            std.Add(row)

        End If

#End Region

        txwPrlPhysChemOvw = header.ToArray
        txwPrlPhysChemValues = values.ToArray
        txwPrlPhysChemStdValues = std.ToArray


    End Sub


    Public Const seeOut As Boolean = True

    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
    "TXW/PRL PhysChem Overview")>
    <Description(
    "PhysChem section for this substance" & vbCrLf &
    "for TOXSWA 5.5.3 or PEARL 5.5.5")>
    <Browsable(browseOut)>
    <[ReadOnly](True)>
    <Category(catPRLTXWOutput)>
    <XmlIgnore>
    Public Property txwPrlPhysChemOvw As String()

    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
    "TXW/PRL PhysChem Values")>
    <Description(
    "PhysChem section for this substance" & vbCrLf &
    "for TOXSWA 5.5.3 or PEARL 5.5.5")>
    <Browsable(browseOut)>
    <[ReadOnly](True)>
    <Category(catPRLTXWOutput)>
    <XmlIgnore>
    Public Property txwPrlPhysChemValues As String()

    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
    "TXW/PRL PhyChem Std. Values")>
    <Description(
    "PhysChem section for this substance" & vbCrLf &
    "for TOXSWA 5.5.3 or PEARL 5.5.5")>
    <Browsable(browseOut)>
    <[ReadOnly](True)>
    <Category(catPRLTXWOutput)>
    <XmlIgnore>
    Public Property txwPrlPhysChemStdValues As String()

#End Region

#Region "    PELMO Volatilization"

    <Browsable(browseOut)>
    <[ReadOnly](True)>
    <Category(catPELMOOutput)>
    <XmlIgnore>
    Public Property PELMOVolatilization As String()


    Public Sub createPELMOVolatilization()

        Dim row As New StringBuilder
        Dim out As New List(Of String)

        out.Add("<VOLATILIZATION>")
        out.Add("<henry       solub.     molmass   vap.press  diff air    depth volat.  Hv       Temperature>)")

        row.Append(("  " & henrykPELMO.ToString(format:="0.00E00")).PadRight(totalWidth:="<henry       ".Length))
        row.Append(_sblWatRef.ToString.PadRight(totalWidth:="solub.     ".Length))
        row.Append(_molMass.ToString.PadRight(totalWidth:="molmass   ".Length))
        row.Append(_preVapRef.ToString(format:="0.00E00").PadRight(totalWidth:="vap.press  ".Length))
        row.Append(Math.Round(diffCoeffAirPELMO, 4).ToString(format:="0.0000").PadRight(totalWidth:="diff air    ".Length))
        row.Append(depthVolat.ToString.PadRight(totalWidth:="depth volat.  ".Length))
        row.Append(HV.ToString.PadRight(totalWidth:="Hv       ".Length))

        out.Add(row.ToString & (_temRefVap - 1).ToString)
        out.Add(row.ToString & (_temRefVap + 1).ToString)

        out.Add("<END VOLATILIZATION>")

        PELMOVolatilization = out.ToArray

    End Sub



#End Region

#End Region



End Class
