﻿

Imports System.ComponentModel
Imports System.Drawing.Design
Imports System.Text
Imports System.Web.Script.Serialization
Imports System.Xml.Serialization


Imports Tools

Public Class compounds



End Class


<TypeConverter(GetType(propGridConverter))>
<Serializable>
<DefaultProperty("iop")>
Public Class compound


#Region "    Constructor and name"

    Public Sub New()
        RaiseEvent update()
    End Sub


    <Browsable(False)>
    <XmlIgnore> <ScriptIgnore>
    Public Property collapseStd As String() =
        {catPhysChem, catdegT50Soil, catSorption}

#End Region


#Region "    Constants and std. values"

    ''' <summary>
    ''' Std. temperature for VP and solubility
    ''' </summary>
    Public Const stdTemRef As Double = 20.0
    Public Const temRefUnit As String = "(°C)"
    Public Const temRefMinMax As String = ""

    ''' <summary>
    ''' Std. molar enthalpy of vaporization = 95 kJ/mol
    ''' </summary>
    Public Const stdMolEntVap As Double = 95

    ''' <summary>
    ''' Std. molar enthalpy of dissolution = 27 kJ/mol
    ''' </summary>
    ''' <remarks></remarks>
    Public Const stdMolEntSlb As Double = 27

    ''' <summary>
    ''' Std. diffusion coefficient in water = 4.3E-5 m²/day
    ''' </summary>
    ''' <remarks></remarks>
    Public Const stdCofDifWatRef As Double = 0.000043

    ''' <summary>
    ''' Std. diffusion coefficient in air = 0.43 m²/day
    ''' </summary>
    ''' <remarks></remarks>
    Public Const stdCofDifAirRef As Double = 0.43

#End Region



    Public Event update()

    Private Sub compound_update() Handles Me.update

        generatePRLout()

    End Sub

    Public Sub generatePRLout()

        Dim out As New List(Of String)
        Dim header As New List(Of String)
        Dim padPos As Integer = "* Freundlich exponent".Length + 3
        Dim padDelimiter As String = " = "
        Const comment As String = "* "
        Dim zoneStart As String = Trim(comment) & "++"
        Dim zoneEnd As String = Trim(comment) & "--"
        Dim row As String = ""
        Dim description As String = ""
        Dim startLenght As Integer = 80

#Region "    Overview"

        header.Add("")
        row = zoneStart & " Degradation and Sorption"
        header.Add(row & " ".PadRight(startLenght - row.Length, paddingChar:="*"))

#Region "    soil"

        header.Add(align2strings(comment & "degT50 Soil", _degT50Soil & " days (" &
                                     (Math.Log(2) / _degT50Soil).ToString("0.0%") & " per day) at " &
                                     temRefTra & " °C",
                        padPos:=padPos, padDelimiter:=padDelimiter))

        If corrtempMoist = eTempMoistCorrection.not_dev Then

            header.Add(align2strings(comment & "    Activation Energy", molEntTra & " kJ/mol",
                        padPos:=padPos, padDelimiter:=padDelimiter))
            header.Add(align2strings(comment & "      Walker exponent", expLiqTra & " (-)",
                       padPos:=padPos, padDelimiter:=padDelimiter))
        Else

            header.Add(align2strings(comment & "Correction", getEnumDescription(corrtempMoist),
                       padPos:=padPos, padDelimiter:=padDelimiter))
        End If

#End Region

#Region "    anaerobic"

        'header.Add(align2strings(comment & "degT50 Anaerobic", _degT50Ana & " days (" &
        '                             (Math.Log(2) / _degT50Ana).ToString("0.0%") & " per day) at " &
        '                             temRefTraAna & " °C",
        '                padPos:=padPos, padDelimiter:=padDelimiter))

        'If corrtempMoistAna = eTempMoistCorrection.not_dev Then

        '    header.Add(align2strings(comment & "    Activation Energy", molEntTraAna & " kJ/mol",
        '                padPos:=padPos, padDelimiter:=padDelimiter))
        '    header.Add(align2strings(comment & "      Walker exponent", expLiqTraAna & " (-)",
        '               padPos:=padPos, padDelimiter:=padDelimiter))
        'Else

        '    header.Add(align2strings(comment & "Correction", getEnumDescription(corrtempMoistAna),
        '               padPos:=padPos, padDelimiter:=padDelimiter))
        'End If

#End Region

#Region "    water layer"

        header.Add(align2strings(comment & "degT50 Water layer", _degT50Water & " days (" &
                                     (Math.Log(2) / _degT50Water).ToString("0.0%") & " per day)",
                        padPos:=padPos, padDelimiter:=padDelimiter))

#End Region

#Region "    sorption"

        header.Add(align2strings(comment & "Sorption", kom & " L/kg",
                        padPos:=padPos, padDelimiter:=padDelimiter))
        header.Add(align2strings(comment & "Freundlich exponent", expFre & " (-)",
                        padPos:=padPos, padDelimiter:=padDelimiter))
        header.Add(zoneEnd)

#End Region

#Region "    phys-chem"

        row = zoneStart & " PhysChem"

        header.Add(row & " ".PadRight(startLenght - row.Length, paddingChar:="*"))

        header.Add(align2strings(comment & " Molar Mass", _molMass & " g/mol",
                        padPos:=padPos, padDelimiter:=padDelimiter))
        header.Add(align2strings(comment & " Vapor Pressure", _preVapRef & " Pa at " &
                                                _temRefVap & "°C",
                        padPos:=padPos, padDelimiter:=padDelimiter))
        header.Add(align2strings(comment & " Water Solubility", _sblWatRef & " mg/L at " &
                                                    _temRefSlb & "°C",
                        padPos:=padPos, padDelimiter:=padDelimiter))

        header.Add(zoneEnd)
        header.Add("")

#End Region

#End Region


#Region "    degT50  in (Anaerobic) Soil and Water"

        row = zoneStart & " Degradation in (Anaerobic) Soil, Water and on Crop Canopy"
        out.Add(row & " ".PadRight(startLenght - row.Length, paddingChar:="*"))
        out.Add("")

        out.Add(createPrlRow(
                            Value:=iop,
                            iop:=" ",
                            parameterName:="SubstanceName",
                            unit:="",
                            description:="",
                            range:=""))

#Region "    Soil"

        row = comment & "----- Soil"
        out.Add(row & " ".PadRight(25 - row.Length, paddingChar:="-"))

        out.Add(createPrlRow(
                            Value:=degT50Soil,
                            iop:=iop,
                            parameterName:="DT50Ref_",
                            unit:="(d)",
                            description:="Soil        : degT50 in days (" &
                                        (Math.Log(2) / _degT50Soil).ToString("0.00% per day)"),
                            range:="[1|1.0E06]"))

        out.Add(createPrlRow(
                            Value:=temRefTra,
                            iop:=iop,
                            parameterName:="TemRefTra_",
                            unit:="(C)",
                            description:="Soil        : Ref. temp. for deg. in °C, std. = 20°C",
                            range:="[0|40]"))

        out.Add(createPrlRow(
                            Value:=molEntTra,
                            iop:=iop,
                            parameterName:="MolEntTra_",
                            unit:="(kJ.mol-1)",
                            description:="Soil        : Activation Energy in kJ/mol",
                            range:="[0|200]"))

        out.Add(createPrlRow(
                            Value:=expLiqTra,
                            iop:=iop,
                            parameterName:="ExpLiqTra_",
                            unit:="(-)",
                            description:="Soil        : Walker exponent",
                            range:="[0.65|1.3]"))

#End Region

#Region "    Anaerobic Soil"

        row = comment & "----- Anaerobic"
        out.Add(row & " ".PadRight(25 - row.Length, paddingChar:="-"))

        out.Add(createPrlRow(
                            Value:=degT50Ana,
                            iop:=iop,
                            parameterName:="DT50AnaRef_",
                            unit:="(d)",
                            description:="Anaerobic   : degT50 in days (" &
                                        (Math.Log(2) / _degT50Ana).ToString("0.00% per day)"),
                            range:="[1|1.0E06]"))

        out.Add(createPrlRow(
                            Value:=temRefTraAna,
                            iop:=iop,
                            parameterName:="TemRefTraAna_",
                            unit:="(C)",
                            description:="Anaerobic   : Ref. temp. for deg. in °C, std. = 20°C",
                            range:="[0|40]"))

        out.Add(createPrlRow(
                            Value:=molEntTraAna,
                            iop:=iop,
                            parameterName:="MolEntTraAna_",
                            unit:="(kJ.mol-1)",
                            description:="Anaerobic   : Activation Energy in kJ/mol",
                            range:="[0|200]"))

        out.Add(createPrlRow(
                            Value:=expLiqTraAna,
                            iop:=iop,
                            parameterName:="ExpLiqTra_",
                            unit:="(-)",
                            description:="Anaerobic   : Walker exponent",
                            range:="[0.65|1.3]"))

#End Region

#Region "    Water"

        row = comment & "----- Water layer"
        out.Add(row & " ".PadRight(25 - row.Length, paddingChar:="-"))

        out.Add(createPrlRow(
                            Value:=degT50Water,
                            iop:=iop,
                            parameterName:="DT50WatLayRef_",
                            unit:="(d)",
                            description:="Water Layer : degT50 in days (" &
                                        (Math.Log(2) / _degT50Water).ToString("0.00% per day)"),
                            range:="[1|1.0E06]"))

#End Region

        out.Add("")
        out.Add(zoneEnd)

#End Region


#Region "    sorption"

        row = zoneStart & " Equilibrium Sorption"
        out.Add(row & " ".PadRight(startLenght - row.Length, paddingChar:="*"))
        out.Add("")

        out.Add(createPrlRow(
                            Value:=kom,
                            iop:=iop,
                            parameterName:="KomEql_",
                            unit:="(L.kg-1)",
                            description:="Equilibrium Sorption on org. matter",
                            range:="[0|1.0E09]"))

        out.Add(createPrlRow(
                            Value:=expFre,
                            iop:=iop,
                            parameterName:="ExpFre_",
                            unit:="(-)",
                            description:="Freundlich sorption exponent",
                            range:="[0.1|1.3]"))

        out.Add(createPrlRow(
                            Value:=temRefSor,
                            iop:=iop,
                            parameterName:="TemRefSor_",
                            unit:="(C)",
                            description:="Sorption    : Ref. temp. for deg. in °C, std. = 20°C",
                            range:="[0|40]"))

        out.Add(createPrlRow(
                            Value:=molEntSor,
                            iop:=iop,
                            parameterName:="MolEntSor_",
                            unit:="(kJ.mol-1)",
                            description:="Sorption    : Activation Energy in kJ/mol",
                            range:="[0|200]"))

        out.Add(createPrlRow(
                            Value:=komEqlMax,
                            iop:=iop,
                            parameterName:="KomEqlMax_",
                            unit:="(L.kg-1)",
                            description:="Kom in dry soil = Kom * 100",
                            range:="[0|1.0E09]"))

        out.Add("")
        out.Add(zoneEnd)

#End Region

#Region "    degT50 SW"


#End Region

#Region "    physChem"

        row = zoneStart & " Phys-Chem Data"
        out.Add(row & " ".PadRight(startLenght - row.Length, paddingChar:="*"))
        out.Add("")

        out.Add(createPrlRow(
                    Value:=_molMass,
                    iop:=iop,
                    parameterName:="MolMas_",
                    unit:="(g.mol-1)",
                    description:="Molar mass of parent substance",
                    range:="[10.0|10000]",
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos))

#Region "    VP"

        If Me.temRefVap <> stdTemRef Then

            description = "Vapor pressure Of substance"

            row = createPrlRow(
                        Value:=_preVapRef,
                        iop:=iop,
                        parameterName:="PreVapRef_",
                        unit:="(Pa)",
                        description:=description,
                        range:="[0|2E5]",
                        valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                        unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

            out.Add(row)

            description = "Std. value (20°C) For VP temp. changed !!!"
            header.Add("* " & description)

            row = createPrlRow(
                        Value:=_temRefVap,
                        iop:=iop,
                        parameterName:="TemRefVap_",
                        unit:="(C)",
                        description:=description,
                        range:="[0|40]",
                        valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                        unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

            out.Add(row)

        Else

            description = "Vapor pressure Of substance   at " & Me.temRefVap & "°C"

            row = createPrlRow(
                        Value:=_preVapRef,
                        iop:=iop,
                        parameterName:="PreVapRef_",
                        unit:="(Pa)",
                        description:=description,
                        range:="[0|2E5]",
                        valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                        unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

            out.Add(row)

            description = "Std vapor pressure measurement temperature"

            row = createPrlRow(
                        Value:=_temRefVap,
                        iop:=iop,
                        parameterName:="TemRefVap_",
                        unit:="(C)",
                        description:=description,
                        range:="[0|40]",
                        valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                        unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

            out.Add(row)

        End If

        If molEntVap <> stdMolEntVap Then
            description = "Std. value (" & stdMolEntVap & " kJ/mo ) for molar enthalpy of vapor. changed !!!"
        Else
            description = "Std. value for molar enthalpy of vaporisation "
        End If

        row = createPrlRow(
                        Value:=_molEntVap,
                        iop:=iop,
                        parameterName:="MolEntVap_",
                        unit:="(kJ.mol-1)",
                        description:=description,
                        range:="[-200|200]",
                        valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                        unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

        out.Add(row)

#End Region

#Region "    Solubility"

        If Me.temRefSlb <> stdTemRef Then

            description = "Water solubility Of substance"

            row = createPrlRow(
                    Value:=slbWatRef,
                    iop:=iop,
                    parameterName:="SlbWatRef_",
                    unit:="(mg.L-1)",
                    description:=description,
                    range:="[0.001|1E6]",
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

            out.Add(row)

            description = "Std. value (20°C) For solub. temp. changed !!!"
            header.Add("* " & description)

            row =
                createPrlRow(
                    Value:=_temRefSlb,
                    iop:=iop,
                    parameterName:="TemRefSlb_",
                    unit:="(C)",
                    description:=description,
                    range:="[0|40]",
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

            out.Add(row)

        Else

            description = "Water solubility Of substance at " & Me.temRefSlb & "°C"

            row = createPrlRow(
                   Value:=slbWatRef,
                   iop:=iop,
                   parameterName:="SlbWatRef_",
                   unit:="(mg.L-1)",
                   description:=description,
                   range:="[0.001|1E6]",
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

            out.Add(row)

            description = "Std. water solubility measurement temperature"

            row =
                    createPrlRow(
                        Value:=_temRefSlb,
                        iop:=iop,
                        parameterName:="TemRefSlb_",
                        unit:="(C)",
                        description:=description,
                        range:="[0|40]",
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

            out.Add(row)

        End If

        If molEntSlb <> stdMolEntSlb Then
            description = "Std. value (" & stdMolEntSlb & " kJ/mo ) for molar enthalpy of solub. changed !!!"
        Else
            description = "Std. value for molar enthalpy of dissolution "
        End If

        row = createPrlRow(
                        Value:=_molEntSlb,
                        iop:=iop,
                        parameterName:="MolEntSlb_",
                        unit:="(kJ.mol-1)",
                        description:=description,
                        range:="[-200|200]",
                        valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                        unitEndPos:=unitEndPos, minMaxPos:=minMaxPos)

        out.Add(row)

#End Region

#Region "    Diffusion"

        out.Add(createPrlRow(
                    Value:=_cofDifAirRef,
                    iop:=iop,
                    parameterName:="CofDifAirRef_",
                    unit:="(m2.d-1)",
                    description:="Reference diff. coeff. in air",
                    range:="[0.1|3]",
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos))

        out.Add(createPrlRow(
                    Value:=_cofDifWatRef,
                    iop:=iop,
                    parameterName:="CofDifWatRef_",
                    unit:="(m2.d-1)",
                    description:="Reference diff. coeff. in water",
                    range:="[10e-5|3e-4]",
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos))

        out.Add(createPrlRow(
                        Value:=_temRefDif,
                        iop:=iop,
                        parameterName:="TemRefDif_",
                        unit:="(C)",
                        description:="Diff. coeff measured at temperature",
                        range:="[0|40]",
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos))



        out.Add(row)

#End Region

        out.Add("")
        out.Add(zoneEnd)

#End Region

#Region "    depth dependent deg. and sorption"

        out.Add(" ")
        row = zoneStart & "Depth Dependent degT50 and Sorption"
        out.Add(row & " ".PadRight(startLenght - row.Length, paddingChar:="*"))

        out.Add(comment & "Degradation")
        out.Add("table horizon FacZTra (-)")
        out.Add("hor " & iop)
        out.Add("1   1.0")
        out.Add("2   1.0")
        out.Add("3   0.5")
        out.Add("4   0.5")
        out.Add("5   0.5")
        out.Add("6   0.0")
        out.Add("7   0.0")
        out.Add("end_table")
        out.Add("")
        out.Add(comment & "Sorption")
        out.Add("table horizon FacZSor (-)")
        out.Add("hor " & iop)
        out.Add("1   -99")
        out.Add("2   -99")
        out.Add("3   -99")
        out.Add("4   -99")
        out.Add("5   -99")
        out.Add("6   -99")
        out.Add("7   -99")
        out.Add("end_table")
        out.Add("")

        out.Add("")
        out.Add(zoneEnd)

#End Region

#Region "    Time Dependent Sorption"

        out.Add(" ")
        row = zoneStart & " Time Dependent Sorption"
        out.Add(row & " ".PadRight(startLenght - row.Length, paddingChar:="*"))


        out.Add(createPrlRow(
                    Value:=_cofDesRat,
                    iop:=iop,
                    parameterName:="CofDesRat_",
                    unit:="(d-1)",
                    description:="Desorption rate coefficient",
                    range:="[0|0.5]",
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos))

        out.Add(createPrlRow(
                    Value:=_facSorNeqEql,
                    iop:=iop,
                    parameterName:="FacSorNeqEql_",
                    unit:="(-)",
                    description:="Ratio non equ/equ sorption",
                    range:="[0|-]",
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos))

        out.Add("")
        out.Add(zoneEnd)

#End Region

#Region "    Canopy processes"

        out.Add(" ")
        row = zoneStart & " Canopy processes"
        out.Add(row & " ".PadRight(startLenght - row.Length, paddingChar:="*"))

        out.Add(createPrlRow(
                    Value:="Lumped",
                    iop:=iop,
                    parameterName:="OptDspCrp_",
                    unit:="",
                    description:="Canopy processes Lumped (Specified or Calculated not supported)",
                    range:="",
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos))


        out.Add(createPrlRow(
                    Value:=_facUpt,
                    iop:=iop,
                    parameterName:="FacUpt_",
                    unit:="(-)",
                    description:="Coefficient for uptake by plant",
                    range:="[0|10]",
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos))


        out.Add(createPrlRow(
                    Value:=_degT50Crop,
                    iop:=iop,
                    parameterName:="DT50DspCrp_",
                    unit:="(d)",
                    description:="Half-life at crop surface",
                    range:="[0|1.0E06]",
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos))

        out.Add(createPrlRow(
                    Value:=_facWasCrp,
                    iop:=iop,
                    parameterName:="FacWasCrp_",
                    unit:="(m-1)",
                    description:="Wash-off factor, std. = 100",
                    range:="[1.0E-06|100]",
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos))

        out.Add("")
        out.Add(zoneEnd)

#End Region

#Region "    Rest"

        out.Add(" ")
        row = zoneStart & " Rest"
        out.Add(row & " ".PadRight(startLenght - row.Length, paddingChar:="*"))

        out.Add(createPrlRow(
                    Value:="pH-independent",
                    iop:=iop,
                    parameterName:="OptCofFre_",
                    unit:="",
                    description:="pH-dependent, pH-independent, CofFre",
                    range:="",
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos))

        out.Add(createPrlRow(
                    Value:=conLiqRef,
                    iop:=iop,
                    parameterName:="ConLiqRef_",
                    unit:="(mg.L-1)",
                    description:="Reference conc. in liquid phase, std. = 1 kg/kg",
                    range:="[0|-]",
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos))

        out.Add(createPrlRow(
                    Value:=cntLiqTraRef,
                    iop:=iop,
                    parameterName:="CntLiqTraRef_",
                    unit:="(kg.kg-1)",
                    description:="Liq. content at which DT50 is measured, std. = 1 kg/kg",
                    range:="[0|1]",
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos))

        out.Add(createPrlRow(
                    Value:=optCntLiqTraRef.ToString,
                    iop:=iop,
                    parameterName:="OptCntLiqTraRef_",
                    unit:="",
                    description:="OptimumConditions or NonOptimumConditions, std. = OptimumConditions",
                    range:="",
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos))

        out.Add(createPrlRow(
                    Value:=optDT50.ToString,
                    iop:=iop,
                    parameterName:="OptDT50_",
                    unit:="",
                    description:="Inp/Calc Equ. Domain or Liquid phase, std. = EqlDom_Input",
                    range:="",
                    valueEndPos:=valueEndPos, nameEndPos:=nameEndPos,
                    unitEndPos:=unitEndPos, minMaxPos:=minMaxPos))


        out.Add("table compounds")
        out.Add(iop)
        out.Add("end_table ")
        out.Add("")
        out.Add("table FraPrtDau (mol.mol-1)")
        out.Add("end_table")


        out.Add("")
        out.Add(zoneEnd)

#End Region


        prlOut = out.ToArray
        prlHeader = header.ToArray

    End Sub

    Public Const catVanilla As String = "00  Vanilla"

#Region "    Vanilla"

    ''' <summary>
    ''' Input Complete?
    ''' </summary>
    ''' <returns></returns>
    <XmlIgnore> <ScriptIgnore>
    <DisplayName("Input Complete?")>
    <Category(catVanilla)>
    Public ReadOnly Property inputComplete As String
        Get

            If iop.Length < 3 OrElse iop = Misc.not_defined Then
                Return "Substance Code ? "
            ElseIf molMass = stdDblEmpty Then
                Return "Molar Mass?"
            ElseIf preVapRef = stdDblEmpty Then
                Return "Vapor pressure?"
            ElseIf slbWatRef = stdDblEmpty Then
                Return "Solubility?"
            ElseIf degT50Soil = stdDblEmpty Then
                Return "degT50 In Soil?"
            ElseIf corrtempMoist = eTempMoistCorrection.not_dev Then
                Return "Correction degT50 Soil?"
            ElseIf degT50Water = stdDblEmpty Then
                Return "degT50 In Water?"
            ElseIf corrtempMoistWater = eTempMoistCorrection.not_dev Then
                Return "Correction degT50 Water?"
            ElseIf kom = stdDblEmpty Then
                Return "Sorption (Kom)?"
            ElseIf expFre = stdDblEmpty Then
                Return "Freundlich Exponent (1/n)?"
            ElseIf facUpt = stdDblEmpty Then
                Return "Plant uptake?"
            End If

            Return Misc.inputComplete

        End Get
    End Property


    Private _iop As String = Misc.not_defined

    ''' <summary>
    ''' Substance Code
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
            "Substance Code")>
    <Description(
        "3 letter substance code" & vbCrLf &
        "")>
    <Browsable(True)>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catVanilla)>
    Public Property iop As String
        Get
            Return _iop
        End Get
        Set(value As String)

            If value.Length >= 3 Then
                _iop = value.ToUpper.Substring(0, 3)
                RaiseEvent update()
            End If

        End Set
    End Property

    ''' <summary>
    ''' Molar mass in g/mol
    ''' [10.0 - 10000 ; MolMas]
    ''' </summary>
    <Category(catVanilla)>
    <DisplayName(
            "Molar Mass")>
    <Description(
            "In g/mol [10.0 - 10000, MolMas]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format= '0.00'|unit=' g/mol'")>
    <DefaultValue(stdDblEmpty)>
    <XmlIgnore> <ScriptIgnore>
    Public Property molMassVanilla As Double
        Get
            Return _molMass
        End Get
        Set

            Try

                If Value < 10 OrElse
                           Value > 10000 Then

                    MsgBox(
                                Prompt:=Value.ToString("0.00") &
                                " g/mol : " & "Molar mass exceeds limits [10|10000]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")

                Else
                    _molMass = Value
                    RaiseEvent update()
                End If

            Catch ex As Exception

                mylog(
                            LogTxt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                            Log2MsgBox:=True,
                            MsgBoxBtn:=MsgBoxStyle.Critical,
                            MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property

    ''' <summary>
    ''' Saturated vapor pressure
    ''' in Pa [0|2.0E+05 ; PreVapRef]
    ''' </summary>
    <DisplayName(
                "Vapor Pressure")>
    <Description(
            "Saturated Vapor pressure" & vbCrLf &
            "in Pa [0|2.0E+05 ; PreVapRef]")>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <Category(catVanilla)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format= '0.00E-00'|unit=' Pa'")>
    <DefaultValue(stdDblEmpty)>
    <XmlIgnore> <ScriptIgnore>
    Public Property preVapRefVanilla As Double
        Get
            Return _preVapRef
        End Get
        Set(value As Double)

            Try

                If value < 0 OrElse
                           value > 200000.0 Then

                    MsgBox(
                                Prompt:=value.ToString("0.00E00") &
                                " Pa : " & "Vapor Pressure exceeds limits [0|2e5]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")

                Else

                    _preVapRef = value
                    RaiseEvent update()

                End If

            Catch ex As Exception

                mylog(
                            LogTxt:=value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                            Log2MsgBox:=True,
                            MsgBoxBtn:=MsgBoxStyle.Critical,
                            MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property

    ''' <summary>
    ''' Water solubility
    ''' in mg/L [0.001|1e6]; SlbWatRef]
    ''' </summary>
    <DisplayName(
                "Solubility")>
    <Description(
            "Water solubility" & vbCrLf &
            "in mg/L [0.001|1e6 ; SlbWatRef]")>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <Category(catVanilla)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format= 'G4'|unit=' mg/L'")>
    <DefaultValue(stdDblEmpty)>
    <XmlIgnore> <ScriptIgnore>
    Public Property slbWatRefVanilla As Double
        Get
            Return _sblWatRef
        End Get
        Set(value As Double)

            Try

                If value < 0.001 OrElse
                           value > 1000000 Then

                    MsgBox(
                                Prompt:=value.ToString("0.00") &
                                " mg/L : " & "Solubility exceeds limits [0.001|1e6]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")

                Else
                    _sblWatRef = value
                    RaiseEvent update()
                End If

            Catch ex As Exception

                mylog(
                            LogTxt:=value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                            Log2MsgBox:=True,
                            MsgBoxBtn:=MsgBoxStyle.Critical,
                            MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property

    ''' <summary>
    ''' Temp / Moist Correction
    ''' </summary>
    <TypeConverter(GetType(enumConverter(Of eTempMoistCorrection)))>
    Public Enum eTempMoistCorrection

        <Description(enumConverter(Of Type).not_defined)>
        not_dev = -1

        <Description("Temp on, Moist on")>
        TempONmoistON

        <Description("Temp on, Moist off")>
        TempONmoistOFF

        <Description("Temp off, Moist on")>
        TempOFFmoistON

        <Description("Temp off, Moist off")>
        TempOFFmoistOFF

    End Enum

#Region "    Soil      degT50"

    ''' <summary>
    ''' Single first order degradation in days in soil
    ''' [1|1.0E06] , DT50Ref PEARL
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Description(
            "Single first order degradation " & vbCrLf &
            "in days in soil [1|1.0E06] , DT50Ref PEARL")>
    <DisplayName(
            "degT50 Soil")>
    <Category(catVanilla)>
    <DefaultValue(stdDblEmpty)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("unit=' days'")>
    <XmlIgnore> <ScriptIgnore>
    Public Overridable Property degT50SoilVanilla As Double
        Get
            Return _degT50Soil
        End Get
        Set
            _degT50Soil = Value
            RaiseEvent update()
        End Set
    End Property


    Private _corrtempMoistSoil As eTempMoistCorrection = eTempMoistCorrection.not_dev

    ''' <summary>
    ''' degT50 Soil  Temp/Moist  Correction
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Description(
            "degT50 Soil  Temp/Moist Correction")>
    <DisplayName(
            "   Temp / Moist Corr.")>
    <Category(catVanilla)>
    Public Property corrtempMoist As eTempMoistCorrection
        Get

            If (_molEntTra <> molEntTra_on AndAlso
                    _molEntTra <> molEntTra_off) OrElse
                   (_expLiqTra <> expLiqTra_on AndAlso
                    _expLiqTra <> expLiqTra_off) Then

                _corrtempMoistSoil = eTempMoistCorrection.not_dev

            End If

            Return _corrtempMoistSoil

        End Get
        Set(value As eTempMoistCorrection)

            _corrtempMoistSoil = value

            Select Case _corrtempMoistSoil

                Case eTempMoistCorrection.TempONmoistON

                    _molEntTra = molEntTra_on
                    _expLiqTra = expLiqTra_on

                Case eTempMoistCorrection.TempONmoistOFF

                    _molEntTra = molEntTra_on
                    _expLiqTra = expLiqTra_off

                Case eTempMoistCorrection.TempOFFmoistON

                    _molEntTra = molEntTra_off
                    _expLiqTra = expLiqTra_on

                Case eTempMoistCorrection.TempOFFmoistOFF

                    _molEntTra = molEntTra_off
                    _expLiqTra = expLiqTra_off

            End Select

            RaiseEvent update()

        End Set
    End Property

#End Region

#Region "    Water     degT50"

    ''' <summary>
    ''' Single first order degradation in days in water
    ''' [1|1.0E06] , DT50Ref TOXSWA, DT50WatLay PEARL
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Description(
            "Single first order degradation in days in water " & vbCrLf &
            "[1|1.0E06] , DT50Ref TOXSWA, DT50WatLay PEARL ")>
    <DisplayName(
            "degT50 Water")>
    <Category(catVanilla)>
    <DefaultValue(stdDblEmpty)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("unit=' days'")>
    <XmlIgnore> <ScriptIgnore>
    Public Overridable Property degT50WaterVanilla As Double
        Get
            Return _degT50Water
        End Get
        Set
            _degT50Water = Value
            RaiseEvent update()
        End Set
    End Property


    Private _corrtempMoistWater As eTempMoistCorrection = eTempMoistCorrection.not_dev

    ''' <summary>
    ''' degt50 Water Temp / Moist Correction
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Description(
            "degt50 Water Temp / Moist Correction")>
    <DisplayName(
            "   Temp / Moist Corr.")>
    <Category(catVanilla)>
    Public Property corrtempMoistWater As eTempMoistCorrection
        Get

            If (_molEntTraWater <> molEntTra_on AndAlso
                    _molEntTraWater <> molEntTra_off) OrElse
                   (_expLiqTraWater <> expLiqTra_on AndAlso
                    _expLiqTraWater <> expLiqTra_off) Then

                _corrtempMoistWater = eTempMoistCorrection.not_dev

            End If

            Return _corrtempMoistWater

        End Get
        Set(value As eTempMoistCorrection)

            _corrtempMoistWater = value

            Select Case _corrtempMoistWater

                Case eTempMoistCorrection.TempONmoistON

                    _molEntTraWater = molEntTra_on
                    _expLiqTraWater = expLiqTra_on

                Case eTempMoistCorrection.TempONmoistOFF

                    _molEntTraWater = molEntTra_on
                    _expLiqTraWater = expLiqTra_off

                Case eTempMoistCorrection.TempOFFmoistON

                    _molEntTraWater = molEntTra_off
                    _expLiqTraWater = expLiqTra_on

                Case eTempMoistCorrection.TempOFFmoistOFF

                    _molEntTraWater = molEntTra_off
                    _expLiqTraWater = expLiqTra_off

            End Select

            RaiseEvent update()

        End Set
    End Property

#End Region

#Region "    Anaerobic degT50"

    ''' <summary>
    ''' Single first order degradation in days in anaerobic soil
    ''' [1|1.0E06] , DT50SedRef TOXSWA, DT50AnaRef PEARL
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Description(
            "Single first order degradation in days in water " & vbCrLf &
            "[1|1.0E06] , DT50SedRef TOXSWA, DT50AnaRef PEARL ")>
    <DisplayName(
            "       Anaerobic")>
    <Category(catVanilla)>
    <DefaultValue(stdDblEmpty)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("unit=' days'")>
    <XmlIgnore> <ScriptIgnore>
    <Browsable(False)>
    Public Overridable Property degT50AnaVanilla As Double
        Get
            Return _degT50Ana
        End Get
        Set
            _degT50Water = Value
            RaiseEvent update()
        End Set
    End Property


    Private _corrtempMoistAna As eTempMoistCorrection = eTempMoistCorrection.not_dev

    ''' <summary>
    ''' degt50 Anaerobic Temp / Moist Correction 
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Description(
            "degt50 Anaerobic Temp / Moist Correction")>
    <DisplayName(
            "   Temp / Moist Corr.")>
    <Category(catVanilla)>
    <Browsable(False)>
    Public Property corrtempMoistAna As eTempMoistCorrection
        Get

            If (_molEntTraAna <> molEntTra_on AndAlso
                    _molEntTraAna <> molEntTra_off) OrElse
                   (_expLiqTraAna <> expLiqTra_on AndAlso
                    _expLiqTraAna <> expLiqTra_off) Then

                _corrtempMoistAna = eTempMoistCorrection.not_dev

            End If

            Return _corrtempMoistAna

        End Get
        Set(value As eTempMoistCorrection)

            _corrtempMoistAna = value

            Select Case _corrtempMoistAna

                Case eTempMoistCorrection.TempONmoistON

                    _molEntTraAna = molEntTra_on
                    _expLiqTraAna = expLiqTra_on

                Case eTempMoistCorrection.TempONmoistOFF

                    _molEntTraAna = molEntTra_on
                    _expLiqTraAna = expLiqTra_off

                Case eTempMoistCorrection.TempOFFmoistON

                    _molEntTraAna = molEntTra_off
                    _expLiqTraAna = expLiqTra_on

                Case eTempMoistCorrection.TempOFFmoistOFF

                    _molEntTraAna = molEntTra_off
                    _expLiqTraAna = expLiqTra_off

            End Select

            RaiseEvent update()

        End Set
    End Property

#End Region

#Region "    Crop"

    ''' <summary>
    ''' degT50 Crop Surface
    ''' [0|1.0E06] in days , DT50DspCrp
    ''' </summary>
    <DisplayName(
                "degT50 Crop Surface")>
    <Description(
            "degT50 Crop Surface" & vbCrLf &
            "[0|1.0E06] in days , DT50DspCrp")>
    <DefaultValue(stdDblEmpty)>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catVanilla)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format='0.0000'| unit=' days'")>
    <Browsable(True)>
    Public Property degT50CropVanilla As Double
        Get
            Return _degT50Crop
        End Get
        Set

            Try

                If Value < 0 OrElse
                           Value > 1000000.0 Then

                    MsgBox(
                        Prompt:=Value.ToString("0.00") & " : DT50DspCrp [0|1.0E06]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else

                    _degT50Crop = Value
                    RaiseEvent update()

                End If

            Catch ex As Exception

                mylog(
                            LogTxt:=Value & vbCrLf & "Error : " &
                            Join(parseExceptionMsg(ex), vbCrLf),
                            Log2MsgBox:=True,
                            MsgBoxBtn:=MsgBoxStyle.Critical,
                            MsgTitle:="Unknown Error")


            End Try

        End Set
    End Property

#End Region


    ''' <summary>
    ''' Kom
    ''' Coef. eql. sorption on org. !matter!
    ''' in L/kg, [0|1e9], KomEql\Sed\SusSol
    ''' </summary>
    <DisplayName(
                    "Kom")>
    <Description(
                "Coef. eql. sorption on org. !matter!" & vbCrLf &
                "in L/kg, [0|1e9], KomEql\Sed\SusSol")>
    <DefaultValue(stdDblEmpty)>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catVanilla)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
                "format='G8'| unit=' L/kg'")>
    <Browsable(True)>
    <XmlIgnore> <ScriptIgnore>
    Public Property komVanilla As Double
        Get
            Return _kom
        End Get
        Set

            Try

                If Value < 0 OrElse
                           Value > 1000000000 Then

                    MsgBox(
                                Prompt:=Value.ToString("0.00") & " : Kom [0|1e9]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")

                Else

                    _kom = Value
                    komEqlMax = _kom * 100
                    RaiseEvent update()

                End If

            Catch ex As Exception

                mylog(
                            LogTxt:=Value & vbCrLf & "Error : " &
                            Join(parseExceptionMsg(ex), vbCrLf),
                            Log2MsgBox:=True,
                            MsgBoxBtn:=MsgBoxStyle.Critical,
                            MsgTitle:="Unknown Error")


            End Try

        End Set
    End Property

    ''' <summary>
    ''' Summary
    ''' Freundlich Exp. 1/n
    ''' no unit 0.1 - 1.3
    ''' ExpFre
    ''' </summary>
    <DisplayName("1/n")>
    <Description("Freundlich Exp. no unit 0.1 - 1.3 ; ExpFre\Sed\SusSol ")>
    <TypeConverter(GetType(dblConv))>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catVanilla)>
    <Browsable(True)>
    <DefaultValue(stdDblEmpty)>
    <XmlIgnore> <ScriptIgnore>
    Public Property expFreVanilla As Double
        Get
            Return _expFre
        End Get
        Set(value As Double)

            Try

                If value < 0.1 OrElse
                       value > 1.3 Then

                    MsgBox(
                            Prompt:=value.ToString("0.0000") &
                            " : Freundlich Exp. 1/n [0.1|1.3]",
                            Buttons:=MsgBoxStyle.Exclamation,
                            Title:="User input outside limits")

                Else
                    _expFre = value
                    RaiseEvent update()
                End If

            Catch ex As Exception

                mylog(
                        LogTxt:=value & vbCrLf & "Error : " &
                        Join(parseExceptionMsg(ex), vbCrLf),
                        Log2MsgBox:=True,
                        MsgBoxBtn:=MsgBoxStyle.Critical,
                        MsgTitle:="Unknown Error")

            End Try


        End Set
    End Property


    ''' <summary>
    ''' Coefficient for uptake by plant
    ''' [0|10], facUpt
    ''' </summary>
    <DisplayName(
                "Plant Uptake Coeff.")>
    <Description(
            "Coefficient for uptake by plant" & vbCrLf &
            " [0|10] std = 0 , facUpt")>
    <DefaultValue(stdDblEmpty)>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catVanilla)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format='0.0000'| unit=''")>
    <Browsable(True)>
    <XmlIgnore> <ScriptIgnore>
    Public Property facUptVanilla As Double
        Get
            Return _facUpt
        End Get
        Set

            Try

                If Value < 0 OrElse
                           Value > 10 Then

                    MsgBox(
                                Prompt:=Value.ToString("0.00") & " : FacUpt [0|10]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")

                Else

                    _facUpt = Value
                    RaiseEvent update()

                End If

            Catch ex As Exception

                mylog(
                            LogTxt:=Value & vbCrLf & "Error : " &
                            Join(parseExceptionMsg(ex), vbCrLf),
                            Log2MsgBox:=True,
                            MsgBoxBtn:=MsgBoxStyle.Critical,
                            MsgTitle:="Unknown Error")


            End Try

        End Set
    End Property


#Region "    out"

    Private _prlHeader As String() = {}

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
            "Overview")>
    <Description(
        "")>
    <TypeConverter(GetType(dblConv))>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catVanilla)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <XmlIgnore> <ScriptIgnore>
    Public Property prlHeader As String()
        Get
            Return _prlHeader
        End Get
        Set(value As String())
            _prlHeader = value
        End Set
    End Property

    Private _prlOut As String() = {}

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
            "PEARL Compound Section")>
    <Description(
        "")>
    <TypeConverter(GetType(dblConv))>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catVanilla)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <XmlIgnore> <ScriptIgnore>
    Public Property prlOut As String()
        Get
            Return _prlOut
        End Get
        Set(value As String())
            _prlOut = value
        End Set
    End Property

#End Region

#End Region

    Public Const catPhysChem As String = "01  Phys-Chem"

#Region "    Phys-Chem"

    Private _molMass As Double = stdDblEmpty

    ''' <summary>
    ''' Molar mass in g/mol
    ''' [10.0 - 10000 ; MolMas]
    ''' </summary>
    <Category(catPhysChem)>
    <DisplayName(
            "Molar Mass")>
    <Description(
            "in g/mol [10.0 - 10000, MolMas]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format= '0.00'|unit=' g/mol'")>
    <DefaultValue(stdDblEmpty)>
    Public Property molMass As Double
        Get
            Return _molMass
        End Get
        Set

            Try

                If Value < 10 OrElse
                           Value > 10000 Then

                    MsgBox(
                                Prompt:=Value.ToString("0.00") &
                                " g/mol : " & "Molar mass exceeds limits [10|10000]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")

                Else
                    _molMass = Value
                    RaiseEvent update()
                End If

            Catch ex As Exception

                mylog(
                            LogTxt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                            Log2MsgBox:=True,
                            MsgBoxBtn:=MsgBoxStyle.Critical,
                            MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property

#Region "    VP and Solubility"

#Region "    Vapor pressure incl. ref temp."

    Private _preVapRef As Double = stdDblEmpty

    ''' <summary>
    ''' Saturated vapor pressure
    ''' in Pa [0|2.0E+05 ; PreVapRef]
    ''' </summary>
    <DisplayName(
                "Vapor Pressure")>
    <Description(
            "Saturated Vapor pressure" & vbCrLf &
            "in Pa [0|2.0E+05 ; PreVapRef]")>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <Category(catPhysChem)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format= '0.00E-00'|unit=' Pa'")>
    <DefaultValue(stdDblEmpty)>
    Public Property preVapRef As Double
        Get
            Return _preVapRef
        End Get
        Set(value As Double)

            Try

                If value < 0 OrElse
                           value > 200000.0 Then

                    MsgBox(
                                Prompt:=value.ToString("0.00E00") &
                                " Pa : " & "Vapor Pressure exceeds limits [0|2e5]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")

                Else

                    _preVapRef = value
                    RaiseEvent update()

                End If

            Catch ex As Exception

                mylog(
                            LogTxt:=value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                            Log2MsgBox:=True,
                            MsgBoxBtn:=MsgBoxStyle.Critical,
                            MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property


    Private _temRefVap As Double = stdTemRef

    ''' <summary>
    ''' Ref. temp. for vapor pressure
    ''' in °C [0|40 ; TemRefVap]
    ''' </summary>
    <DisplayName(
                "  at ref. temp.")>
    <Description(
            "Ref. temp. for vapor pressure" & vbCrLf &
            "in °C [0|40 ; TemRefVap, std. = 20°C]")>
    <[ReadOnly](False)>
    <Editor(GetType(nudValueEditorInteger), GetType(UITypeEditor))>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format= '0.0'|unit=' °C'")>
    <Category(catPhysChem)>
    <DefaultValue(stdTemRef)>
    Public Property temRefVap As Double
        Get
            Return _temRefVap
        End Get
        Set

            Try

                If Value < 0 OrElse
                           Value > 40 Then

                    MsgBox(
                                Prompt:=Value & "°C : " &
                                "Ref temp for vapor pressure exceeds limits [0|40]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")

                Else
                    _temRefVap = Value
                    RaiseEvent update()
                End If

            Catch ex As Exception

                MsgBox(
                            Prompt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                            Buttons:=MsgBoxStyle.Critical,
                            Title:="Unknown Error")

            End Try

        End Set
    End Property


#End Region

#Region "    Solubility incl. ref temp"

    Private _sblWatRef As Double = stdDblEmpty

    ''' <summary>
    ''' Water solubility
    ''' in mg/L [0.001|1e6]; SlbWatRef]
    ''' </summary>
    <DisplayName(
                "Solubility")>
    <Description(
            "Water solubility" & vbCrLf &
            "in mg/L [0.001|1e6 ; SlbWatRef]")>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <Category(catPhysChem)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format= 'G4'|unit=' mg/L'")>
    <DefaultValue(stdDblEmpty)>
    Public Property slbWatRef As Double
        Get
            Return _sblWatRef
        End Get
        Set(value As Double)

            Try

                If value < 0.001 OrElse
                           value > 1000000 Then

                    MsgBox(
                                Prompt:=value.ToString("0.00") &
                                " mg/L : " & "Solubility exceeds limits [0.001|1e6]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")

                Else
                    _sblWatRef = value
                    RaiseEvent update()
                End If

            Catch ex As Exception

                mylog(
                            LogTxt:=value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                            Log2MsgBox:=True,
                            MsgBoxBtn:=MsgBoxStyle.Critical,
                            MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property


    Private _temRefSlb As Double = stdTemRef

    ''' <summary>
    ''' Ref. temp. for solubility
    ''' in °C [0|40 ; TemRefSol]
    ''' </summary>
    <DisplayName(
                "  at ref. temp.")>
    <Description(
            "Ref. temp. for water solubility" & vbCrLf &
            "in °C [0|40 ; TemRefSlb, std. = 20°C]")>
    <[ReadOnly](False)>
    <Editor(GetType(nudValueEditorInteger), GetType(UITypeEditor))>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format= '0.0'|unit=' °C'")>
    <Category(catPhysChem)>
    <DefaultValue(stdTemRef)>
    Public Property temRefSlb As Double
        Get
            Return _temRefSlb
        End Get
        Set

            Try

                If Value < 0 OrElse
                           Value > 40 Then

                    MsgBox(
                                Prompt:=Value & "°C : " &
                                "Ref temp for solubility exceeds limits [0|40]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")

                Else
                    _temRefSlb = Value
                    RaiseEvent update()
                End If

            Catch ex As Exception

                MsgBox(
                            Prompt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                            Buttons:=MsgBoxStyle.Critical,
                            Title:="Unknown Error")

            End Try

        End Set
    End Property

#End Region

#End Region

#Region "    Enthalpy"

    Private _molEntVap As Double = stdMolEntVap

    ''' <summary>
    ''' MolEntVap
    ''' Molar enthalpy of vaporization in kJ/mol
    ''' [-200|200; MolEntVap; std. = 95 kJ/mol]
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName("MolEntVap")>
    <Description("Molar enthalpy of vaporization in kJ/mol" & vbCrLf &
                         "[-200|200; MolEntVap; std. = 95 kJ/mol]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(catPhysChem)>
    <DefaultValue(stdMolEntVap)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format= '0'|unit=' kJ/mol'")>
    Public Property molEntVap As Double
        Get

            Return _molEntVap

        End Get
        Set

            Try

                If Value < -200 OrElse
                           Value > 200 Then

                    MsgBox(
                                Prompt:=Value.ToString("0.00") & " mg/L : " & "Molar enthalpy of vaporization [-200|200]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")

                Else

                    If Value <> CDbl(stdMolEntVap) Then

                        If _
                                    MsgBox(
                                        Prompt:=Value & " kJ/mol : Really? std. value is " & stdMolEntVap &
                                                        " kJ/mol and you shouldn't touch it!!",
                                        Buttons:=MsgBoxStyle.YesNo,
                                        Title:="Don't Change BASIC values!!") <> MsgBoxResult.No Then

                            _molEntVap = Value

                        End If

                    Else
                        _molEntVap = Value
                    End If

                    RaiseEvent update()

                End If

            Catch ex As Exception

                mylog(
                            LogTxt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                            Log2MsgBox:=True,
                            MsgBoxBtn:=MsgBoxStyle.Critical,
                            MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property


    Private _molEntSlb As Double = stdMolEntSlb

    ''' <summary>
    ''' Molar enthalpy of dissolution in kJ/mol
    ''' -200|200; MolEntSlb; std. = 27 kJ/mol
    ''' MolEntSlb
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
            "MolEntSlb")>
    <Description(
            "Molar enthalpy of dissolution in kJ/mol" & vbCrLf &
            "[-200|200; MolEntSlb; std. = 27 kJ/mol]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(catPhysChem)>
    <DefaultValue(stdMolEntSlb)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format= '0'|unit=' kJ/mol'")>
    Public Property molEntSlb As Double
        Get
            Return _molEntSlb
        End Get
        Set

            Try

                If Value < -200 OrElse
                           Value > 200 Then

                    MsgBox(
                                Prompt:=Value.ToString("0.00") & " mg/L : " & "Molar enthalpy of dissolution [-200|200]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")

                Else

                    If Value <> CDbl(stdMolEntSlb) Then

                        If _
                                 MsgBox(
                                     Prompt:=Value & " kJ/mol : Really? std. value is " & stdMolEntSlb &
                                                     " kJ/mol and you shouldn't touch it!!",
                                     Buttons:=MsgBoxStyle.YesNo,
                                     Title:="Don't Change BASIC values!!") <> MsgBoxResult.No Then

                            _molEntSlb = Value

                        End If

                    Else
                        _molEntSlb = Value
                    End If

                    RaiseEvent update()

                End If

            Catch ex As Exception

                mylog(
                            LogTxt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                            Log2MsgBox:=True,
                            MsgBoxBtn:=MsgBoxStyle.Critical,
                            MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property

#End Region

#Region "    Diffusion"

    Private _cofDifWatRef As Double = stdCofDifWatRef

    ''' <summary>
    ''' Reference diffusion coefficient in water in m²/day
    ''' [0|0.002; CofDifWatRef; std. = 4.3E-5 m²/day]
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
            "CofDifWatRef")>
    <Description(
            "Reference diffusion coefficient in water in m²/day" & vbCrLf &
            "[0|0.002; CofDifWatRef; std. = 0.000043 (4.3E-05) m²/day]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(catPhysChem)>
    <DefaultValue(stdCofDifWatRef)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format= '0.0E-00'|unit=' m²/day'")>
    Public Property cofDifWatRef As Double
        Get
            Return _cofDifWatRef
        End Get
        Set(value As Double)

            Try


                If value < 0 OrElse
                           value > 0.002 Then

                    MsgBox(
                                Prompt:=value.ToString("0.00") & "m²/day : " & "Diffusion coefficient in water [0|0.002]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")
                Else

                    If value <> CDbl(stdCofDifWatRef) Then

                        If _
                                    MsgBox(
                                        Prompt:=value & " m²/day : Really? std. value is " & CDbl(stdCofDifWatRef) &
                                                        " m²/day and you shouldn't touch it!!",
                                        Buttons:=MsgBoxStyle.YesNo,
                                        Title:="Don't Change BASIC values!!") <> MsgBoxResult.No Then

                            _cofDifWatRef = value
                        End If

                    Else
                        _cofDifWatRef = value
                    End If

                    RaiseEvent update()

                End If

            Catch ex As Exception

                mylog(
                            LogTxt:=value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                            Log2MsgBox:=True,
                            MsgBoxBtn:=MsgBoxStyle.Critical,
                            MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property


    Private _cofDifAirRef As Double = stdCofDifAirRef

    ''' <summary>
    ''' Reference diffusion coefficient in water in m²/day
    ''' [0|0.002; CofDifWatRef; std. = 4.3E-5 m²/day]
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
            "CofDifAirRef")>
    <Description(
            "Reference diffusion coefficient in air in [m²/day]" & vbCrLf &
            "PEARL 0.1|3; CofDifAirRef; std. = 0.43 m²/day]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(catPhysChem)>
    <DefaultValue(stdCofDifAirRef)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format= '0.0E-00'|unit=' m²/day'")>
    Public Property cofDifAirRef As Double
        Get
            Return _cofDifAirRef
        End Get
        Set(value As Double)

            Try

                If value < 0.1 OrElse
                           value > 3 Then

                    MsgBox(
                                Prompt:=value.ToString("0.00") & "m²/day : " & "Diffusion coefficient in air [0.1|3]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")

                Else

                    If _
                        MsgBox(
                            Prompt:=value & " m²/day : Really? std. value is 0.43 m^2/day and you shouldn't touch it!!",
                            Buttons:=MsgBoxStyle.YesNo,
                            Title:="Don't Change BASIC values!!") <> MsgBoxResult.No Then


                        _cofDifAirRef = value

                    End If

                    RaiseEvent update()

                End If

            Catch ex As Exception

                mylog(
                            LogTxt:=value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                            Log2MsgBox:=True,
                            MsgBoxBtn:=MsgBoxStyle.Critical,
                            MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property


    Private _temRefDif As Double = stdTemRef

    ''' <summary>
    ''' Ref. temp. for Diff. coeff
    ''' in °C [0|40 ; TemRefDif]
    ''' </summary>
    <DisplayName(
                "  at ref. temp.")>
    <Description(
            "Ref. temp. for Diff. coeff" & vbCrLf &
            "in °C [0|40 ; TemRefDif, std. = 20°C]")>
    <[ReadOnly](False)>
    <Editor(GetType(nudValueEditorInteger), GetType(UITypeEditor))>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format= '0.0'|unit=' °C'")>
    <Category(catPhysChem)>
    <DefaultValue(stdTemRef)>
    Public Property temRefDif As Double
        Get
            Return _temRefDif
        End Get
        Set

            Try

                If Value < 0 OrElse
                           Value > 40 Then

                    MsgBox(
                                Prompt:=Value & "°C : " &
                                "Ref temp for Diff. coeff measur. exceeds limits [0|40]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")

                Else
                    _temRefDif = Value
                    RaiseEvent update()
                End If

            Catch ex As Exception

                MsgBox(
                            Prompt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                            Buttons:=MsgBoxStyle.Critical,
                            Title:="Unknown Error")

            End Try

        End Set
    End Property



#End Region

#End Region

    Public Const molEntTra_on As Double = 65.4
    Public Const molEntTra_off As Double = 0


    Public Const expLiqTra_on As Double = 0.7
    Public Const expLiqTra_off As Double = 0


    Public Const catdegT50Soil As String = "02  degT50 Soil"

#Region "    degT50 Soil"

    Private _degT50Soil As Double = stdDblEmpty

    ''' <summary>
    ''' Single first order degradation
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Description(
            "Single first order degradation " & vbCrLf &
            "in soil in days [1|1.0E06] , DT50Ref, PEARL")>
    <DisplayName(
            "degT50 Soil")>
    <Category(catdegT50Soil)>
    <DefaultValue(stdDblEmpty)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("unit=' days'")>
    Public Overridable Property degT50Soil As Double
        Get
            Return _degT50Soil
        End Get
        Set
            _degT50Soil = Value
            RaiseEvent update()
        End Set
    End Property

    Private _temRefTra As Double = stdTemRef

    ''' <summary>
    ''' Ref. temp. for degradation in soil
    ''' in °C [0|40 ; TemRefTra]
    ''' </summary>
    <DisplayName(
                "  at ref. temp.")>
    <Description(
            "Ref. temp. for degradation in soil" & vbCrLf &
            "in °C [0|40 ; TemRefTra, std. = 20°C]")>
    <[ReadOnly](False)>
    <Editor(GetType(nudValueEditorInteger), GetType(UITypeEditor))>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format= '0.0'|unit=' °C'")>
    <Category(catdegT50Soil)>
    <DefaultValue(stdTemRef)>
    Public Property temRefTra As Double
        Get
            Return _temRefTra
        End Get
        Set

            Try

                If Value < 0 OrElse
                           Value > 40 Then

                    MsgBox(
                                Prompt:=Value & "°C : " &
                                "Ref temp for degradation in soil exceeds limits [0|40]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")

                Else
                    _temRefTra = Value
                    RaiseEvent update()
                End If

            Catch ex As Exception

                MsgBox(
                            Prompt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                            Buttons:=MsgBoxStyle.Critical,
                            Title:="Unknown Error")

            End Try

        End Set
    End Property



    Private _molEntTra As Double = molEntTra_on

    ''' <summary>
    ''' Activation Energy
    ''' (-) [0 - 200 kJ/mol, MolEntTra PEARL
    ''' </summary>
    ''' <returns></returns>
    <Category(catdegT50Soil)>
    <DisplayName(
            "Activation Energy")>
    <Description(
            "(-) [0 - 200 kJ/mol] " & vbCrLf &
            "std. = 65.4kJ/mol (on) or 0 (off), MolEntTra PEARL")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.0'|unit=' kJ/mol'")>
    <DefaultValue(molEntTra_on)>
    Public Property molEntTra As Double
        Get
            Return _molEntTra
        End Get
        Set
            _molEntTra = Value
        End Set
    End Property



    Private _expLiqTra As Double = expLiqTra_on

    ''' <summary>
    ''' Walker exponent
    ''' (-) [0 - 5, ExpLiqTra PEARL & PELMO]
    ''' </summary>
    ''' <returns></returns>
    <Category(catdegT50Soil)>
    <DisplayName(
            "Walker exponent")>
    <Description(
            "(-) [0 - 5, ExpLiqTra on = 0.7, off = 0]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.00'|unit=' (-)'")>
    <DefaultValue(expLiqTra_on)>
    Public Property expLiqTra As Double
        Get
            Return _expLiqTra
        End Get
        Set
            _expLiqTra = Value
        End Set
    End Property



#End Region

    Public Const catdegT50Water As String = "03         Water"

#Region "    degT50 Water"

    Private _degT50Water As Double = stdDblEmpty

    ''' <summary>
    ''' Single first order degradation in Water in days
    ''' [1|1.0E06] , DT50Ref, TOXSWA / DT50WatLay PEARL
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Description(
            "Single first order degradation in Water in days" & vbCrLf &
            "[1|1.0E06] , DT50Ref, TOXSWA / DT50WatLay PEARL ")>
    <DisplayName(
            "degT50 Water PRL / TXW")>
    <Category(catdegT50Water)>
    <DefaultValue(stdDblEmpty)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("unit=' days'")>
    Public Overridable Property degT50Water As Double
        Get
            Return _degT50Water
        End Get
        Set
            _degT50Water = Value
            RaiseEvent update()
        End Set
    End Property

    Private _temRefTraWater As Double = stdTemRef

    ''' <summary>
    ''' Ref. temp. for degradation in soil
    ''' in °C [0|40 ; TemRefTra]
    ''' </summary>
    <DisplayName(
                "  at ref. temp. (TXW)")>
    <Description(
            "Ref. temp. for degradation in Water in °C [0|40]" & vbCrLf &
            "TemRefTra TOXSWA , std. = 20°C]")>
    <[ReadOnly](False)>
    <Editor(GetType(nudValueEditorInteger), GetType(UITypeEditor))>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format= '0.0'|unit=' °C'")>
    <Category(catdegT50Soil)>
    <DefaultValue(stdTemRef)>
    Public Property temRefTraWater As Double
        Get
            Return _temRefTraWater
        End Get
        Set

            Try

                If Value < 0 OrElse
                           Value > 40 Then

                    MsgBox(
                                Prompt:=Value & "°C : " &
                                "Ref temp for degradation in water exceeds limits [0|40]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")

                Else
                    _temRefTraWater = Value
                    RaiseEvent update()
                End If

            Catch ex As Exception

                MsgBox(
                            Prompt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                            Buttons:=MsgBoxStyle.Critical,
                            Title:="Unknown Error")

            End Try

        End Set
    End Property



    Private _molEntTraWater As Double = molEntTra_on

    ''' <summary>
    ''' Activation Energy
    ''' (-) [0 - 200 kJ/mol, MolEntTra PEARL
    ''' </summary>
    ''' <returns></returns>
    <Category(catdegT50Water)>
    <DisplayName(
            "Activation Energy")>
    <Description(
            "(-) [0 - 200 kJ/mol] " & vbCrLf &
            "std. = 65.4kJ/mol (on) or 0 (off), MolEntTra PEARL")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.0'|unit=' kJ/mol'")>
    <DefaultValue(molEntTra_on)>
    Public Property molEntTraWater As Double
        Get
            Return _molEntTraWater
        End Get
        Set
            _molEntTraWater = Value
        End Set
    End Property



    Private _expLiqTraWater As Double = expLiqTra_on

    ''' <summary>
    ''' Walker exponent
    ''' (-) [0 - 5, ExpLiqTra PEARL & PELMO]
    ''' </summary>
    ''' <returns></returns>
    <Category(catdegT50Water)>
    <DisplayName(
            "Walker exponent")>
    <Description(
            "(-) [0 - 5, ExpLiqTra on = 0.7, off = 0]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.00'|unit=' (-)'")>
    <DefaultValue(expLiqTra_on)>
    Public Property expLiqTraWater As Double
        Get
            Return _expLiqTraWater
        End Get
        Set
            _expLiqTraWater = Value
        End Set
    End Property



#End Region

    Public Const catdegT50Ana As String = "04         Anaerobic"

#Region "    degT50 Anaerobic"

    Private _degT50Ana As Double = 10000

    ''' <summary>
    ''' Single first order degradation in Anaerobic in days
    ''' [1|1.0E06] , DT50AnaRef PEARL, DT50SedRef TOXSWA
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Description(
            "Single first order degradation in Water in days" & vbCrLf &
            "[1|1.0E06] , DT50SedRef, TOXSWA / DT50AnaRef PEARL, std. = 10000 days ")>
    <DisplayName(
            "degT50 Anaerobic PRL / TXW")>
    <Category(catdegT50Ana)>
    <DefaultValue(10000)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("unit=' days'")>
    Public Overridable Property degT50Ana As Double
        Get
            Return _degT50Ana
        End Get
        Set
            _degT50Ana = Value
            RaiseEvent update()
        End Set
    End Property

    Private _temRefTraAna As Double = stdTemRef

    ''' <summary>
    ''' Ref. temp. for degradation anaerobic
    ''' in °C [0|40 ; TemRefTra]
    ''' </summary>
    <DisplayName(
                "  at ref. temp.")>
    <Description(
            "Ref. temp. for degradation anaerobic in °C [0|40]" & vbCrLf &
            "TemRefTraAna TOXSWA, TemRefTraSed PEARL , std. = 20°C]")>
    <[ReadOnly](False)>
    <Editor(GetType(nudValueEditorInteger), GetType(UITypeEditor))>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format= '0.0'|unit=' °C'")>
    <Category(catdegT50Ana)>
    <DefaultValue(stdTemRef)>
    Public Property temRefTraAna As Double
        Get
            Return _temRefTraAna
        End Get
        Set

            Try

                If Value < 0 OrElse
                           Value > 40 Then

                    MsgBox(
                                Prompt:=Value & "°C : " &
                                "Ref temp for degradation anaerobic exceeds limits [0|40]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")

                Else
                    _temRefTraAna = Value
                    RaiseEvent update()
                End If

            Catch ex As Exception

                MsgBox(
                            Prompt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                            Buttons:=MsgBoxStyle.Critical,
                            Title:="Unknown Error")

            End Try

        End Set
    End Property



    Private _molEntTraAna As Double = molEntTra_on

    ''' <summary>
    ''' Activation Energy
    ''' (-) [0 - 200 kJ/mol, MolEntTra PEARL
    ''' </summary>
    ''' <returns></returns>
    <Category(catdegT50Ana)>
    <DisplayName(
            "Activation Energy")>
    <Description(
            "(-) [0 - 200 kJ/mol] " & vbCrLf &
            "std. = 65.4kJ/mol (on) or 0 (off), MolEntTraAna PEARL, MolEntTraSed TOXSWA")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.0'|unit=' kJ/mol'")>
    <DefaultValue(molEntTra_on)>
    Public Property molEntTraAna As Double
        Get
            Return _molEntTraAna
        End Get
        Set
            _molEntTraAna = Value
        End Set
    End Property



    Private _expLiqTraAna As Double = expLiqTra_on

    ''' <summary>
    ''' Walker exponent
    ''' (-) [0 - 5, ExpLiqTraAna PEARL ExpLiqTraSed TOXSWA]
    ''' </summary>
    ''' <returns></returns>
    <Category(catdegT50Ana)>
    <DisplayName(
            "Walker exponent")>
    <Description(
            "(-) [0 - 5, ExpLiqTraAna/Sed on = 0.7, off = 0]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.00'|unit=' (-)'")>
    <DefaultValue(expLiqTra_on)>
    Public Property expLiqTraAna As Double
        Get
            Return _expLiqTraAna
        End Get
        Set
            _expLiqTraAna = Value
        End Set
    End Property



#End Region


    Public Const catSorption As String = "05  Sorption"

#Region "    Sorption"

    Private _kom As Double = stdDblEmpty

    ''' <summary>
    ''' Kom
    ''' Coef. eql. sorption on org. !matter!
    ''' in L/kg, [0|1e9], KomEql\Sed\SusSol
    ''' </summary>
    <DisplayName(
                "Kom")>
    <Description(
            "Coef. eql. sorption on org. !matter!" & vbCrLf &
            "in L/kg, [0|1e9], KomEql\Sed\SusSol")>
    <DefaultValue(stdDblEmpty)>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catSorption)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format='G8'| unit=' L/kg'")>
    <Browsable(True)>
    Public Property kom As Double
        Get
            Return _kom
        End Get
        Set

            Try

                If Value < 0 OrElse
                           Value > 1000000000 Then

                    MsgBox(
                                Prompt:=Value.ToString("0.00") & " : Kom [0|1e9]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")

                Else

                    _kom = Value
                    komEqlMax = _kom * 100
                    RaiseEvent update()

                End If

            Catch ex As Exception

                mylog(
                            LogTxt:=Value & vbCrLf & "Error : " &
                            Join(parseExceptionMsg(ex), vbCrLf),
                            Log2MsgBox:=True,
                            MsgBoxBtn:=MsgBoxStyle.Critical,
                            MsgTitle:="Unknown Error")


            End Try

        End Set
    End Property

    Private _temRefSor As Double = stdTemRef

    ''' <summary>
    ''' Ref. temp. for degradation anaerobic
    ''' in °C [0|40 ; TemRefTra]
    ''' </summary>
    <DisplayName(
                "  at ref. temp.")>
    <Description(
            "Ref. temp. for sorption in °C [0|40]" & vbCrLf &
            "TemRefSor PEARL , std. = 20°C]")>
    <[ReadOnly](False)>
    <Editor(GetType(nudValueEditorInteger), GetType(UITypeEditor))>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format= '0.0'|unit=' °C'")>
    <Category(catSorption)>
    <DefaultValue(stdTemRef)>
    Public Property temRefSor As Double
        Get
            Return _temRefSor
        End Get
        Set

            Try

                If Value < 0 OrElse
                           Value > 40 Then

                    MsgBox(
                                Prompt:=Value & "°C : " &
                                "Ref temp for sorption exceeds limits [0|40]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")

                Else
                    _temRefSor = Value
                    RaiseEvent update()
                End If

            Catch ex As Exception

                MsgBox(
                            Prompt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                            Buttons:=MsgBoxStyle.Critical,
                            Title:="Unknown Error")

            End Try

        End Set
    End Property

    Private _expFre As Double = stdDblEmpty

    ''' <summary>
    ''' Summary
    ''' Freundlich Exp. 1/n
    ''' no unit 0.1 - 1.3
    ''' ExpFre
    ''' </summary>
    <DisplayName("1/n")>
    <Description("Freundlich Exp. no unit 0.1 - 1.3 ; ExpFre\Sed\SusSol ")>
    <TypeConverter(GetType(dblConv))>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catSorption)>
    <Browsable(True)>
    <DefaultValue(stdDblEmpty)>
    Public Property expFre As Double
        Get
            Return _expFre
        End Get
        Set(value As Double)

            Try

                If value < 0.1 OrElse
                       value > 1.3 Then

                    MsgBox(
                            Prompt:=value.ToString("0.0000") &
                            " : Freundlich Exp. 1/n [0.1|1.3]",
                            Buttons:=MsgBoxStyle.Exclamation,
                            Title:="User input outside limits")

                Else
                    _expFre = value
                    RaiseEvent update()
                End If

            Catch ex As Exception

                mylog(
                        LogTxt:=value & vbCrLf & "Error : " &
                        Join(parseExceptionMsg(ex), vbCrLf),
                        Log2MsgBox:=True,
                        MsgBoxBtn:=MsgBoxStyle.Critical,
                        MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property




    Private _molEntSor As Double = molEntTra_on

    ''' <summary>
    ''' Activation Energy
    ''' (-) [0 - 200 kJ/mol, MolEntTra PEARL
    ''' </summary>
    ''' <returns></returns>
    <Category(catSorption)>
    <DisplayName(
            "Activation Energy")>
    <Description(
            "(-) [0 - 200 kJ/mol] " & vbCrLf &
            "std. = 65.4kJ/mol (on) or 0 (off), MolEntSor PEARL")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.0'|unit=' kJ/mol'")>
    <DefaultValue(molEntTra_on)>
    Public Property molEntSor As Double
        Get
            Return _molEntSor
        End Get
        Set
            _molEntSor = Value
        End Set
    End Property


    Private _komEqlMax As Double = stdDblEmpty

    ''' <summary>
    ''' Kom MAX
    ''' Coef. eql. sorption on org. !matter!
    ''' in L/kg, [0|1e9], KomEql\Sed\SusSol
    ''' </summary>
    <DisplayName(
                "Kom MAX")>
    <Description(
            "Coef. eql. sorption on org. !matter!" & vbCrLf &
            "in dry soil in L/kg, [0|1e9], Max = Kom * 100")>
    <DefaultValue(stdDblEmpty)>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catSorption)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format='G8'| unit=' L/kg'")>
    <Browsable(True)>
    Public Property komEqlMax As Double
        Get
            Return _komEqlMax
        End Get
        Set(value As Double)
            _komEqlMax = value
            RaiseEvent update()
        End Set
    End Property

#End Region

    Public Const catTDS As String = "06  Time Dependent Sorption"

#Region "    Time Dependent Sorption"

    Private _cofDesRat As Double = 0

    ''' <summary>
    ''' Desorption rate coefficient (TDS Parameter)
    ''' in 1/day 0 = off, [0|0.5], CofDesRat
    ''' </summary>
    <DisplayName(
                "Desorption rate coefficient")>
    <Description(
            "Desorption rate coefficient (TDS Parameter)" & vbCrLf &
            "in 1/day 0 = off, [0|0.5], CofDesRat")>
    <DefaultValue(0)>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catTDS)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format='0.0000'| unit=' 1/day'")>
    <Browsable(True)>
    Public Property cofDesRat As Double
        Get
            Return _cofDesRat
        End Get
        Set

            Try

                If Value < 0 OrElse
                           Value > 0.5 Then

                    MsgBox(
                                Prompt:=Value.ToString("0.00") & " : CofDesRat [0|0.5]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")

                Else

                    _cofDesRat = Value
                    RaiseEvent update()

                End If

            Catch ex As Exception

                mylog(
                            LogTxt:=Value & vbCrLf & "Error : " &
                            Join(parseExceptionMsg(ex), vbCrLf),
                            Log2MsgBox:=True,
                            MsgBoxBtn:=MsgBoxStyle.Critical,
                            MsgTitle:="Unknown Error")


            End Try

        End Set
    End Property

    Private _facSorNeqEql As Double = 0

    ''' <summary>
    ''' Ration non equilibrium sorption to
    ''' equilibrium sorption (TDS Parameter)
    ''' in 1/day 0 = off, [0|-], CofDesRat
    ''' </summary>
    <DisplayName(
                "Non Equil./ Equil.")>
    <Description(
            "Ration non equilibrium sorption to " & vbCrLf &
            "           equilibrium sorption, FacSorNeqEql, [0,-]")>
    <DefaultValue(0)>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catTDS)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format='0.0000'| unit=' (-)'")>
    <Browsable(True)>
    Public Property facSorNeqEql As Double
        Get
            Return _facSorNeqEql
        End Get
        Set

            Try

                If Value < 0 Then

                    MsgBox(
                                Prompt:=Value.ToString("0.00") & " : FacSorNeqEql [0|-]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")

                Else

                    _facSorNeqEql = Value
                    RaiseEvent update()

                End If

            Catch ex As Exception

                mylog(
                            LogTxt:=Value & vbCrLf & "Error : " &
                            Join(parseExceptionMsg(ex), vbCrLf),
                            Log2MsgBox:=True,
                            MsgBoxBtn:=MsgBoxStyle.Critical,
                            MsgTitle:="Unknown Error")


            End Try

        End Set
    End Property

#End Region

    Public Const catCanopy As String = "07  Canopy processes"


#Region "    Canopy processes"

    Private _facUpt As Double = stdDblEmpty

    ''' <summary>
    ''' Coefficient for uptake by plant
    ''' [0|10], facUpt
    ''' </summary>
    <DisplayName(
                "Plant Uptake Coeff.")>
    <Description(
            "Coefficient for uptake by plant" & vbCrLf &
            " [0|10] std = 0 , facUpt")>
    <DefaultValue(stdDblEmpty)>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catCanopy)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format='0.0000'| unit=''")>
    <Browsable(True)>
    Public Property facUpt As Double
        Get
            Return _facUpt
        End Get
        Set

            Try

                If Value < 0 OrElse
                           Value > 10 Then

                    MsgBox(
                                Prompt:=Value.ToString("0.00") & " : FacUpt [0|10]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")

                Else

                    _facUpt = Value
                    RaiseEvent update()

                End If

            Catch ex As Exception

                mylog(
                            LogTxt:=Value & vbCrLf & "Error : " &
                            Join(parseExceptionMsg(ex), vbCrLf),
                            Log2MsgBox:=True,
                            MsgBoxBtn:=MsgBoxStyle.Critical,
                            MsgTitle:="Unknown Error")


            End Try

        End Set
    End Property


    Private _degT50Crop As Double = stdDblEmpty

    ''' <summary>
    ''' degT50 Crop Surface
    ''' [0|1.0E06] in days , DT50DspCrp
    ''' </summary>
    <DisplayName(
                "degT50 Crop Surface")>
    <Description(
            "degT50 Crop Surface" & vbCrLf &
            " [0|1.0E06] in days , DT50DspCrp")>
    <DefaultValue(stdDblEmpty)>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catCanopy)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format='0.0000'| unit=''")>
    <Browsable(True)>
    Public Property degT50Crop As Double
        Get
            Return _degT50Crop
        End Get
        Set

            Try

                If Value < 0 OrElse
                           Value > 1000000.0 Then

                    MsgBox(
                        Prompt:=Value.ToString("0.00") & " : DT50DspCrp [0|1.0E06]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else

                    _degT50Crop = Value
                    RaiseEvent update()

                End If

            Catch ex As Exception

                mylog(
                            LogTxt:=Value & vbCrLf & "Error : " &
                            Join(parseExceptionMsg(ex), vbCrLf),
                            Log2MsgBox:=True,
                            MsgBoxBtn:=MsgBoxStyle.Critical,
                            MsgTitle:="Unknown Error")


            End Try

        End Set
    End Property

    Private _facWasCrp As Double = 100

    ''' <summary>
    ''' Wash-off factor
    ''' [1.0E-06|100], FacWasCrp
    ''' </summary>
    <DisplayName(
                "Wash-off factor")>
    <Description(
            "Wash-off factor in 1/m" & vbCrLf &
            "[1.0E-06|100] std = 100 , FacWasCrp")>
    <DefaultValue(100)>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catCanopy)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
            "format='0.0000'| unit=' per m'")>
    <Browsable(True)>
    Public Property facWasCrp As Double
        Get
            Return _facWasCrp
        End Get
        Set

            Try

                If Value < 0.000001 OrElse
                           Value > 100 Then

                    MsgBox(
                                Prompt:=Value.ToString("0.00") & " : FacWasCrp [1.0E-06|100]",
                                Buttons:=MsgBoxStyle.Exclamation,
                                Title:="User input outside limits")

                Else

                    _facWasCrp = Value
                    RaiseEvent update()

                End If

            Catch ex As Exception

                mylog(
                            LogTxt:=Value & vbCrLf & "Error : " &
                            Join(parseExceptionMsg(ex), vbCrLf),
                            Log2MsgBox:=True,
                            MsgBoxBtn:=MsgBoxStyle.Critical,
                            MsgTitle:="Unknown Error")


            End Try

        End Set
    End Property


#End Region

    Public Const catPEARLSpecial As String = "06  PEARL Special"

#Region "    PEARL Special"


#Region "    Constants"

    Public Const stdcntLiqRef As Double = 1

    <Category(catPEARLSpecial)>
    <DisplayName(
        "DT50 Liquid Content")>
    <Description(
        "Liq. content at which DT50 is measured" & vbCrLf &
        "in kg/kg [0|1], std. 1kg/kg")>
    Public Property cntLiqTraRef As Double = stdcntLiqRef

    <Category(catPEARLSpecial)>
    <DisplayName(
        "Liquid Conc. for Sorption")>
    <Description(
        "Reference conc. in liquid phase" & vbCrLf &
        "in mg/L [0.1|-], std. 1 mg/L")>
    Public Property conLiqRef As Double = stdcntLiqRef


    <TypeConverter(GetType(enumConverter(Of eOptCntLiqTraRef)))>
    Public Enum eOptCntLiqTraRef

        <Description(enumConverter(Of Type).not_defined)>
        not_dev = -1

        <Description("Optimum Conditions")>
        OptimumConditions

        <Description("Non-Optimum Conditions")>
        NonOptimumConditions

    End Enum

    <Category(catPEARLSpecial)>
    <DisplayName("(Non) Optimum Conditions")>
    <Description("std. = OptimumConditions")>
    Public Property optCntLiqTraRef As eOptCntLiqTraRef = eOptCntLiqTraRef.OptimumConditions

    ''' <summary>
    ''' Option for DT50: Input or Calculate in
    ''' equilibrium domain(EqlDom) Or In liquid phase
    ''' only (LiqPhs)
    ''' </summary>
    <TypeConverter(GetType(enumConverter(Of eOptDT50)))>
    Public Enum eOptDT50

        <Description(enumConverter(Of Type).not_defined)>
        not_dev = -1

        <Description("Equ. Domain, input")>
        EqlDom_Input
        <Description("Liquid phase, input")>
        LiqPhs_Input

        <Description("Equ. Domain, calc.")>
        EqlDom_Calculate
        <Description("Liquid phase, calc.")>
        LiqPhs_Calculate

    End Enum

    <Category(catPEARLSpecial)>
    <DisplayName("Inp/Calc Equ. Domain or Liquid phase")>
    <Description("std. = Equ. Domain, input")>
    Public Property optDT50 As eOptDT50 = eOptDT50.EqlDom_Input

#End Region


#End Region


End Class
