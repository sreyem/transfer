﻿
Imports Tools

Module main

    Sub Main()
        start()
    End Sub

    Public Sub start()

        deSerialize(targetClass:=test, fileName:="C:\developer\DevID0002\2022Q4\Reiswolf\tfs.xml")


restart:


        showform = New FrmPropGrid(
            class2Show:=test,
             classType:=test.GetType,
               restart:=True)

        Try


            If Not IsNothing(showform) Then

                With showform

                    .Text = My.Application.Info.Title & " " & My.Application.Info.Version.ToString

#If DEBUG Then

                    .Text &= "     ----- D * E * B * U * G ---- "



#Else
                    .Text &= " Release version"

#End If

                    .Width = 1200
                    .Height = 1000

                    If .ShowDialog() = Windows.Forms.DialogResult.Retry Then

                        showform.Close()
                        GoTo restart

                    End If


                End With


            End If


        Catch ex As Exception
            mylog(LogTxtArray:=parseExceptionMsg(Exception:=ex))
        End Try

    End Sub


    'Dim test As New physChem
    Dim test As New compound

    Public showform As New FrmPropGrid


End Module

Module _aux


    Public Const valueEndPos As Integer = 25
    Public Const nameEndPos As Integer = 45
    Public Const unitEndPos As Integer = 60
    Public Const minMaxPos As Integer = 115

    Public Const dummyIOP As String = "|IOP|"

    ''' <summary>
    ''' 200.0 MolMas_pest (g.mol-1) Molar mass [10|10000]
    ''' </summary>
    ''' <param name="Value">
    ''' 200.0
    ''' </param>
    ''' <param name="parameterName">
    ''' MolMas_
    ''' </param>
    ''' <param name="iop">
    ''' pest
    ''' </param>
    ''' <param name="unit">
    ''' (g.mol-1)
    ''' </param>
    ''' <param name="description">
    ''' ! Molar mass of parent substance
    ''' </param>
    ''' <param name="range">
    ''' [10.0 - 10000]
    ''' </param>
    ''' <returns></returns>
    <DebuggerStepThrough>
    Public Function createPrlRow(
                            Value As String,
                            iop As String,
                            parameterName As String,
                            unit As String,
                            description As String,
                            range As String,
                    Optional valueEndPos As Integer = valueEndPos,
                    Optional nameEndPos As Integer = nameEndPos,
                    Optional unitEndPos As Integer = unitEndPos,
                    Optional minMaxPos As Integer = minMaxPos) As String

        Dim row As String

        If iop = "" Then iop = dummyIOP
        If iop = "-" Then iop = ""

        row = Value.PadRight(valueEndPos)
        row = (row & parameterName & iop).PadRight(nameEndPos)
        row = (row & unit).PadRight(unitEndPos)
        row = (row & description).PadRight(minMaxPos)
        row &= range

        Return row

    End Function


End Module