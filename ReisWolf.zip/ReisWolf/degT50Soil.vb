﻿


Imports System.ComponentModel
Imports System.Drawing.Design
Imports System.Text
Imports System.Web.Script.Serialization
Imports System.Xml.Serialization


Imports Tools


Public Module enums


    <TypeConverter(GetType(enumConverter(Of eOnOffUserdef)))>
    Public Enum eOnOffUserdef

        <Description(enumConverter(Of Type).not_defined)>
        not_def = -1


        <Description("On")>
        [On]

        <Description("Off")>
        [Off]

        <Description("user def.")>
        userdef

    End Enum


    Public Enum eDepthDependentFOCUSuserdef
        FOCUS
        userdef
    End Enum

    <TypeConverter(GetType(enumConverter(Of ePelmoPosition)))>
    Public Enum ePelmoPosition

        <Description(enumConverter(Of Type).not_defined)>
        not_def = -1

        A0

        A1
        B1
        C1
        D1

        A2
        B2
        C2
        D2

        <Description("<BR/CO2>")>
        BR_CO2

    End Enum

    <TypeConverter(GetType(enumConverter(Of eScenariosGW)))>
    Public Enum eScenariosGW

        <Description(enumConverter(Of Type).not_defined)>
        not_def = -1

        Nanchang
        Lianping

        Chateaudun
        Hamburg
        Jokioinen
        Kremsmuenster
        Okehampton
        Piacenza
        Porto
        Sevilla
        Thiva

    End Enum

    ''' <summary>
    ''' Supported PEARL versions
    ''' 4.4.4
    ''' 5.5.5
    ''' </summary>
    <TypeConverter(GetType(enumConverter(Of ePEARLVersion)))>
    Public Enum ePEARLVersion
        <Description("4.4.4")>
        PEARL444
        <Description("5.5.5")>
        PEARL555
        <Description(enumConverter(Of Type).not_defined)>
        not_dev = -1
    End Enum

    '<DebuggerStepperBoundary>
    Public Function getFacZTra(scenario As eScenariosGW, version As ePEARLVersion) As Double()

        If scenario = eScenariosGW.not_def OrElse version = ePEARLVersion.not_dev Then
            Return {}
        End If


        Select Case version

            Case ePEARLVersion.PEARL444

                Select Case scenario

                    Case eScenariosGW.Chateaudun
                        Return {1, 0.5, 0.5, 0.3, 0, 0, 0}
                    Case eScenariosGW.Hamburg
                        Return {1, 0.5, 0.3, 0.3, 0.3, 0}
                    Case eScenariosGW.Jokioinen
                        Return {1, 0.5, 0.3, 0.3, 0, 0}
                    Case eScenariosGW.Kremsmuenster
                        Return {1, 0.5, 0.5, 0.3, 0}
                    Case eScenariosGW.Okehampton
                        Return {1, 0.5, 0.3, 0.3, 0}
                    Case eScenariosGW.Piacenza
                        Return {1, 0.5, 0.5, 0.3, 0.3, 0}
                    Case eScenariosGW.Porto
                        Return {1, 0.5, 0.3, 0}
                    Case eScenariosGW.Sevilla
                        Return {1, 1, 0.5, 0.3, 0, 0}
                    Case eScenariosGW.Thiva
                        Return {1, 0.5, 0.5, 0.3, 0.3, 0}

                End Select


            Case ePEARLVersion.PEARL555

                Select Case scenario

                    Case eScenariosGW.Chateaudun
                        Return {1, 1, 0.5, 0.5, 0.5, 0.3, 0, 0, 0, 0}
                    Case eScenariosGW.Hamburg
                        Return {1, 1, 0.5, 0.3, 0.3, 0.3, 0, 0}
                    Case eScenariosGW.Jokioinen
                        Return {1, 1, 0.5, 0.3, 0.3, 0, 0, 0}
                    Case eScenariosGW.Kremsmuenster
                        Return {1, 1, 0.5, 0.5, 0.3, 0, 0}
                    Case eScenariosGW.Okehampton
                        Return {1, 1, 0.5, 0.5, 0.3, 0.3, 0, 0}
                    Case eScenariosGW.Piacenza
                        Return {1, 1, 0.5, 0.5, 0.3, 0.3, 0, 0}
                    Case eScenariosGW.Porto
                        Return {1, 1, 1, 0.5, 0.3, 0, 0}
                    Case eScenariosGW.Sevilla
                        Return {1, 1, 1, 0.5, 0.3, 0, 0, 0}
                    Case eScenariosGW.Thiva
                        Return {1, 1, 0.5, 0.5, 0.3, 0.3, 0, 0}

                End Select

        End Select

    End Function

    <DebuggerStepperBoundary>
    Public Function getFacZSor(scenario As eScenariosGW, version As ePEARLVersion) As Double()

        If scenario = eScenariosGW.not_def OrElse version = ePEARLVersion.not_dev Then
            Return {}
        End If


        Select Case version

            Case ePEARLVersion.PEARL444

                Select Case scenario

                    Case eScenariosGW.Chateaudun
                        Return {-99, -99, -99, -99, -99, -99, -99}
                    Case eScenariosGW.Hamburg
                        Return {-99, -99, -99, -99, -99, -99}
                    Case eScenariosGW.Jokioinen
                        Return {-99, -99, -99, -99, -99, -99}
                    Case eScenariosGW.Kremsmuenster
                        Return {-99, -99, -99, -99, -99}
                    Case eScenariosGW.Okehampton
                        Return {-99, -99, -99, -99, -99}
                    Case eScenariosGW.Piacenza
                        Return {-99, -99, -99, -99, -99, -99}
                    Case eScenariosGW.Porto
                        Return {-99, -99, -99, -99}
                    Case eScenariosGW.Sevilla
                        Return {-99, -99, -99, -99, -99, -99}
                    Case eScenariosGW.Thiva
                        Return {-99, -99, -99, -99, -99, -99}
                End Select


            Case ePEARLVersion.PEARL555

                Select Case scenario

                    Case eScenariosGW.Chateaudun
                        Return {-99, -99, -99, -99, -99, -99, -99, -99, -99, -99}
                    Case eScenariosGW.Hamburg
                        Return {-99, -99, -99, -99, -99, -99, -99, -99}
                    Case eScenariosGW.Jokioinen
                        Return {-99, -99, -99, -99, -99, -99, -99, -99}
                    Case eScenariosGW.Kremsmuenster
                        Return {-99, -99, -99, -99, -99, -99, -99}
                    Case eScenariosGW.Okehampton
                        Return {-99, -99, -99, -99, -99, -99, -99, -99}
                    Case eScenariosGW.Piacenza
                        Return {-99, -99, -99, -99, -99, -99, -99, -99}
                    Case eScenariosGW.Porto
                        Return {-99, -99, -99, -99, -99, -99, -99}
                    Case eScenariosGW.Sevilla
                        Return {-99, -99, -99, -99, -99, -99, -99, -99}
                    Case eScenariosGW.Thiva
                        Return {-99, -99, -99, -99, -99, -99, -99, -99}
                End Select

        End Select

    End Function


End Module


''' <summary>
''' DT50 incl. temp. and moist. corr.
''' </summary>
<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class degT50TempMoistCorr

    Inherits degT50DepthDependent

    Public Sub New()

    End Sub

    <Browsable(False)>
    <XmlIgnore> <ScriptIgnore>
    Public Property collapseStd As String() =
    {catTempMoistCorr, catDetailsMoistCorr, catDetailsTempCorr, catConstantsDegT50, catDepthDependentDegratation}


#Region "    Output"

    Public Enum eItem
        degrate = 0
        degtemp
        q10
        mabs
        mrel
        mexp
        rel
        neq
        ff
    End Enum

    Public Function createPELMOdegRow(
                                     ff As Double,
                                     Optional PELMOpos As ePelmoPosition = ePelmoPosition.not_def,
                                     Optional scenario As eScenariosGW = eScenariosGW.not_def,
                                     Optional empty As Boolean = False) As String()

        Dim row As New StringBuilder
        Dim target As degT50TempMoistCorr
        Dim temp As String = ""
        Dim out As New List(Of String)



        Dim header As String() =
            {
        "<degrate    ",
        "temp  ",
        "q10   ",
        "m-abs  ",
        "m-rel  ",
        "m-exp  ",
        "rel  ",
        "neq  ",
        "formation factor"
        }


        For Each member As String In header
            row.Append(member)
        Next

        If empty Then

            out.Add(row.ToString)
            row.Clear()

            row.Append("  0.00E+00".PadRight(header(eItem.degrate).Length))

            row.Append("20".PadRight(header(eItem.degtemp).Length))
            row.Append("2.58".PadRight(header(eItem.q10).Length))
            row.Append("0".PadRight(header(eItem.mabs).Length))
            row.Append("100".PadRight(header(eItem.mrel).Length))
            row.Append("0.70".PadRight(header(eItem.mexp).Length))
            row.Append("0".PadRight(header(eItem.rel).Length))
            row.Append("1".PadRight(header(eItem.neq).Length))

            If PELMOpos <> ePelmoPosition.not_def Then
                row.Append("<Met " & PELMOpos.ToString & ">")
            End If

            out.Add(row.ToString)
            Return out.ToArray

        End If

        out.Add(row.ToString)
        row.Clear()

        If Me.scenarioSpecificDT50 = eOnOffUserdef.On AndAlso scenario <> eScenariosGW.not_def Then

            For Each member In Me.scenarioSpecificData

                If member.scenario = scenario Then

                    With member

                        row.Append(
                            (" " & (Math.Log(2) / .degT50 * ff).ToString(0.0000000)).PadRight(header(eItem.degrate).Length))

                    End With

                End If

            Next

        Else

            temp = " " & (Math.Round(Math.Log(2) / degT50 * ff, decimals:=7)).ToString("0.0000000")

            row.Append(temp.PadRight(header(eItem.degrate).Length))

        End If

        row.Append(_temRefTra.ToString("0.0").PadRight(header(eItem.degtemp).Length))
        row.Append(_q10.ToString("0.00").PadRight(header(eItem.q10).Length))
        row.Append("0".PadRight(header(eItem.mabs).Length))
        row.Append(_relMoist.ToString(0.0).PadRight(header(eItem.mrel).Length))
        row.Append(_EXPB.ToString("0.00").PadRight(header(eItem.mexp).Length))
        row.Append("0".PadRight(header(eItem.rel).Length))
        row.Append("1".PadRight(header(eItem.neq).Length))

        If PELMOpos <> ePelmoPosition.not_def Then
            row.Append("<Met " & PELMOpos.ToString & ">")
        End If

        out.Add(row.ToString)

        Return out.ToArray

    End Function


    Public Shadows Function createPEARLDegT50(
                Optional iop As String = "",
                Optional scenario As eScenariosGW = eScenariosGW.not_def) As List(Of String())

        Dim out As New List(Of String())
        Dim top As New List(Of String)
        Dim std As New List(Of String)
        Dim both As New List(Of String)
        Dim row As String = ""

        Dim description As New StringBuilder

        out.Add({}) : out.Add({}) : out.Add({})

        If Double.IsNaN(Me.degT50) Then Return out

        'temp & moist corr.
        If _tempCorr = eOnOffUserdef.On AndAlso
           _moistCorr = eOnOffUserdef.On Then

            description.Append("T|M = on")

        ElseIf _tempCorr = eOnOffUserdef.Off AndAlso
               _moistCorr = eOnOffUserdef.Off Then

            description.Append("T|M = off")

        Else

            description.Append(
                "T=" & getEnumDescription(_tempCorr) &
               "|M=" & getEnumDescription(_moistCorr))

        End If

        description.Append(" at " & _temRefTra & "°C")

        If Me.depthDependentFOCUSuserdef = eDepthDependentFOCUSuserdef.userDef Then

            description.Append(" FacZTra = user def!")

        ElseIf Me.scenarioSpecificDT50 = eOnOffUserdef.On AndAlso scenario <> eScenariosGW.not_def Then

            For Each member In Me.scenarioSpecificData

                If member.scenario = scenario Then

                    description.Append(", " & scenario.ToString & " " &
                          member.kPerc.ToString &
                           ", DT90 = " &
                          member.degT90.ToString("G4") & " days")

                End If

            Next

        Else

            description.Append(" ," &
                    kPerc.ToString &
                    ", DT90 = " &
                    degT90.ToString("G4") & " days")

        End If

        row = ""
        If Me.scenarioSpecificDT50 = eOnOffUserdef.On AndAlso scenario <> eScenariosGW.not_def Then

            For Each member In Me.scenarioSpecificData

                If member.scenario = scenario Then

                    row = createPrlRow(
                        Value:=member.degT50,
                        iop:=iop,
                        parameterName:="DT50Ref_",
                        unit:="(d)",
                        description:=description.ToString,
                        range:=" ")

                End If

            Next

        Else

            row = createPrlRow(
                Value:=Me.degT50,
                iop:=iop,
                parameterName:="DT50Ref_",
                unit:="(d)",
                description:=description.ToString,
                range:=" ")

        End If

        If row = "" Then
            row = createPrlRow(
                Value:=Me.degT50,
                iop:=iop,
                parameterName:="DT50Ref_",
                unit:="(d)",
                description:=description.ToString,
                range:=" ")
        End If

        top.Add(row)
        both.Add(row)

        If _tempCorr = eOnOffUserdef.On OrElse
           _tempCorr = eOnOffUserdef.Off Then

            If _temRefTra = stdTemRef Then

                row =
            createPrlRow(
                Value:=_temRefTra,
                iop:=iop,
                parameterName:="TemRefTra_",
                unit:="(C)",
                description:="DT50 measurement temp., std. = " & stdTemRef & "°C",
                range:="[5|30]")

                std.Add(row)

            Else

                row =
            createPrlRow(
                Value:=_temRefTra,
                iop:=iop,
                parameterName:="TemRefTra_",
                unit:="(C)",
                description:="Non std. measurement temp!, std. = " & stdTemRef & "°C",
                range:="[5|30]")

                top.Add(row)

            End If

            both.Add(row)

            description.Clear()

            If _tempCorr = eOnOffUserdef.On Then
                description.Append("Molar activ. energy, std. for on")
            Else
                description.Append("Molar activ. energy, std. for off")
            End If

            row = createPrlRow(
                    Value:=Me.molEntTra,
                    iop:=iop,
                    parameterName:="MolEntTra_",
                    unit:="(kJ.mol-1)",
                    description:=description.ToString,
                    range:="[0|200]")

            std.Add(row)
            both.Add(row)

        Else

            If _temRefTra = stdTemRef Then

                row =
            createPrlRow(
                Value:=_temRefTra,
                iop:=iop,
                parameterName:="TemRefTra_",
                unit:="(C)",
                description:="DT50 measurement temp., std. = " & stdTemRef & "°C",
                range:="[5|30]")

                std.Add(row)

            Else

                row =
            createPrlRow(
                Value:=_temRefTra,
                iop:=iop,
                parameterName:="TemRefTra_",
                unit:="(C)",
                description:="Non std. measurement temp!, std. = " & stdTemRef & "°C",
                range:="[5|30]")

                top.Add(row)

            End If

            both.Add(row)

            row = createPrlRow(
                    Value:=Me.molEntTra,
                    iop:=iop,
                    parameterName:="MolEntTra_",
                    unit:="(kJ.mol-1)",
                    description:="Molar activ. energy, user def. value",
                    range:="[0|200]")

            top.Add(row)
            both.Add(row)

        End If

        '**********************************

        If _moistCorr = eOnOffUserdef.On OrElse
           _moistCorr = eOnOffUserdef.Off Then

            description.Clear()

            If _moistCorr = eOnOffUserdef.On Then
                description.Append("Walker exp., std. value for on")
            Else
                description.Append("Walker exp., std. value for off")
            End If

            row = createPrlRow(
                    Value:=Me.expLiqTra,
                    iop:=iop,
                    parameterName:="ExpLiqTra_",
                    unit:="(-)",
                    description:=description.ToString,
                    range:="[0|5]")

            std.Add(row)

        Else

            description.Append("Walker exp., user def. value")
            row = createPrlRow(
                    Value:=Me.expLiqTra,
                    iop:=iop,
                    parameterName:="ExpLiqTra_",
                    unit:="(-)",
                    description:=description.ToString,
                    range:="[0|5]")

            top.Add(row)

        End If

        If Me.cntLiqTraRef = stdcntLiqTraRef Then

            row =
            createPrlRow(
                    Value:=Me.cntLiqTraRef,
                    iop:=iop,
                    parameterName:="CntLiqTraRef_",
                    unit:="(kg.kg-1)",
                    description:="std. setting",
                    range:="[0|1]")

            std.Add(row)

        Else

            row =
            createPrlRow(
                    Value:=Me.optDT50.ToString,
                    iop:=iop,
                    parameterName:="CntLiqTraRef_",
                    unit:="(kg.kg-1)",
                    description:="non std. setting !!!",
                    range:="[0|1]")

            top.Add(row)

        End If

        both.Add(row)

        If Me.optCntLiqTraRef = eOptCntLiqTraRef.OptimumConditions Then

            row =
                createPrlRow(
                        Value:=Me.optCntLiqTraRef.ToString,
                        iop:=iop,
                        parameterName:="OptCntLiqTraRef_",
                        unit:=" ",
                        description:="std. setting",
                        range:=" ")

            std.Add(row)

        Else

            row =
                createPrlRow(
                        Value:=Me.optCntLiqTraRef.ToString,
                        iop:=iop,
                        parameterName:="OptCntLiqTraRef_",
                        unit:=" ",
                        description:="non std. setting !!!",
                        range:=" ")

            top.Add(row)

        End If

        both.Add(row)

        If Me.optDT50 = eOptDT50.EqlDom_Input Then

            row =
            createPrlRow(
                    Value:=Me.optDT50.ToString,
                    iop:=iop,
                    parameterName:="OptDT50_",
                    unit:=" ",
                    description:="std. setting",
                    range:=" ")

            std.Add(row)

        Else

            row =
            createPrlRow(
                    Value:=Me.optDT50.ToString,
                    iop:=iop,
                    parameterName:="OptDT50_",
                    unit:=" ",
                    description:="non std. setting !!!",
                    range:=" ")

            top.Add(row)

        End If

        both.Add(row)

        out.Clear()
        out.Add(top.ToArray)
        out.Add(std.ToArray)
        out.Add(both.ToArray)

        Return out

    End Function

#End Region

    Public Const catTempMoistCorr As String = "03  Temp. And Moist."

#Region "    Temp/Moist corr"

    Private _tempCorr As eOnOffUserdef = eOnOffUserdef.On

    ''' <summary>
    ''' Temperature correction on or off
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
    "Corr. Temp.")>
    <Description(
    "Temperature correction" & vbCrLf &
    "On, off Or user defined")>
    <Category(catTempMoistCorr)>
    <DefaultValue(CInt(eOnOffUserdef.On))>
    Public Property tempCorr As eOnOffUserdef
        Get
            Return _tempCorr
        End Get
        Set(value As eOnOffUserdef)
            _tempCorr = value

            If _tempCorr = eOnOffUserdef.On Then

                _molEntTra = molEntTra_on   'PEARL
                _q10 = q10_on               'PELMO
                _TRESP = TRESP_on           'MACRO

            ElseIf _tempCorr = eOnOffUserdef.Off Then

                _molEntTra = molEntTra_off
                _q10 = q10_off
                _TRESP = TRESP_off

            End If

        End Set
    End Property


    Public Const stdTemRef As Double = 20

    Private _temRefTra As Double = stdTemRef

    ''' <summary>
    ''' Temperature at which half-life is measured
    ''' in °C [5|30 ; TemRef, std. = 20°C]
    ''' </summary>
    <DisplayName(
    "      at")>
    <Description(
    "Temperature at which half-life Is measured" & vbCrLf &
    "In °C [5|30 ; TemRef, std. = 20°C]")>
    <[ReadOnly](False)>
    <Editor(GetType(nudValueEditorInteger), GetType(UITypeEditor))>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.0'|unit=' °C'")>
    <Category(catTempMoistCorr)>
    <DefaultValue(stdTemRef)>
    Public Property temRefTra As Double
        Get
            Return _temRefTra
        End Get
        Set

            Try

                If Value < 5 OrElse
                   Value > 30 Then

                    MsgBox(
                        Prompt:=Value & "°C : " &
                        "Meas. temp for half-life in soil [5|30]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else
                    _temRefTra = Value
                End If
            Catch ex As Exception

                MsgBox(
                    Prompt:=Value & vbCrLf & "Error : " &
                    Join(parseExceptionMsg(ex), vbCrLf),
                    Buttons:=MsgBoxStyle.Critical,
                    Title:="Unknown Error")

            End Try

        End Set
    End Property


    Private _moistCorr As eOnOffUserdef = eOnOffUserdef.On


    ''' <summary>
    ''' Moisture correction on or off
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
    "      Moist.")>
    <Description(
    "Moisture correction" & vbCrLf &
    "On, off or user defined")>
    <Category(catTempMoistCorr)>
    <DefaultValue(CInt(eOnOffUserdef.On))>
    Public Property moistCorr As eOnOffUserdef
        Get
            Return _moistCorr
        End Get
        Set(value As eOnOffUserdef)
            _moistCorr = value

            If _moistCorr = eOnOffUserdef.On Then

                _expLiqTra = expLiqTra_on       'PEARL & PELMO
                _relMoist = relMoist_on         'PELMO
                _EXPB = EXPB_on                 'MACRO

            ElseIf _moistCorr = eOnOffUserdef.Off Then

                _expLiqTra = expLiqTra_off
                _relMoist = relMoist_off
                _EXPB = EXPB_off

            End If

        End Set
    End Property


#End Region

    Public Const catDetailsMoistCorr As String = "04a Moist."

#Region "    Details Moist. Correction"

    Public Const expLiqTra_on As Double = 0.7
    Public Const expLiqTra_off As Double = 0


    Private _expLiqTra As Double = expLiqTra_on

    ''' <summary>
    ''' Walker exponent
    ''' (-) [0 - 5, ExpLiqTra PEARL & PELMO]
    ''' </summary>
    ''' <returns></returns>
    <Category(catDetailsMoistCorr)>
    <DisplayName(
    "Walker exponent")>
    <Description(
    "(-) [0 - 5, ExpLiqTra PEARL & FEUEXP PELMO]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.00'|unit=' (-)'")>
    <DefaultValue(expLiqTra_on)>
    Public Property expLiqTra As Double
        Get
            Return _expLiqTra
        End Get
        Set
            _expLiqTra = Value
        End Set
    End Property



    Public Const relMoist_on As Double = 100
    Public Const relMoist_off As Double = 0

    Private _relMoist As Double = relMoist_on

    ''' <summary>
    ''' Walker exponent
    ''' (-) [0 - 5, relMoist PEARL & PELMO]
    ''' </summary>
    ''' <returns></returns>
    <Category(catDetailsMoistCorr)>
    <DisplayName(
    "Rel. Moisture")>
    <Description(
    "Relative moisture during study in %Field Capacity" & vbCrLf &
    "[0-100, 0 = off, 100 = on; 'moist-rel' PELMO")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0'|unit=' %FC'")>
    <DefaultValue(relMoist_on)>
    Public Property relMoist As Double
        Get
            Return _relMoist
        End Get
        Set
            _relMoist = Value
        End Set
    End Property



    Public Const EXPB_on As Double = 0.49
    Public Const EXPB_off As Double = 0

    Private _EXPB As Double = EXPB_on

    ''' <summary>
    ''' MACRO Temp EXPB
    ''' </summary>
    ''' <returns></returns>
    <Category(catDetailsMoistCorr)>
    <DisplayName(
    "MACRO Temp EXPB")>
    <Description(
    "(-) [EXPB, on = 0.49, off = 0]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.00'|unit=' (-)'")>
    <DefaultValue(Double.NaN)>
    Public Property EXPB As Double
        Get
            Return _EXPB
        End Get
        Set
            _EXPB = Value
        End Set
    End Property

#End Region

    Public Const catDetailsTempCorr As String = "04b Temp."

#Region "    Details Temp. Correction"

    Public Const molEntTra_on As Double = 65.4
    Public Const molEntTra_off As Double = 1


    Private _molEntTra As Double = molEntTra_on

    ''' <summary>
    ''' Activation Energy
    ''' (-) [0 - 200 kJ/mol, MolEntTra PEARL
    ''' </summary>
    ''' <returns></returns>
    <Category(catDetailsTempCorr)>
    <DisplayName(
    "Activation Energy")>
    <Description(
    "(-) [0 - 200 kJ/mol] " & vbCrLf &
    "std. = 65.4kJ/mol (on) or 0 (off), MolEntTra PEARL")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.0'|unit=' kJ/mol'")>
    <DefaultValue(molEntTra_on)>
    Public Property molEntTra As Double
        Get
            Return _molEntTra
        End Get
        Set
            _molEntTra = Value
        End Set
    End Property


    Public Const q10_on As Double = 2.58
    Public Const q10_off As Double = 1

    Private _q10 As Double = q10_on

    ''' <summary>
    ''' Activation Energy
    ''' (-) [0 - 200 kJ/mol, q10 PEARL
    ''' </summary>
    ''' <returns></returns>
    <Category(catDetailsTempCorr)>
    <DisplayName(
    "Q10")>
    <Description(
    "factor for degradation rate increase when temperature" & vbCrLf &
    "increases by 10°C, std. 2.58 (on) or 0 (off), q10 PELMO")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.00'|unit=' (-)'")>
    <DefaultValue(q10_on)>
    Public Property q10 As Double
        Get
            Return _q10
        End Get
        Set
            _q10 = Value
        End Set
    End Property

    Public Const TRESP_on As Double = 0.0948
    Public Const TRESP_off As Double = 0

    Private _TRESP As Double = TRESP_on

    ''' <summary>
    ''' MACRO Moist TRESP
    ''' </summary>
    ''' <returns></returns>
    <Category(catDetailsTempCorr)>
    <DisplayName(
    "MACRO Moist TRESP")>
    <Description(
    "(-) [TRESP, on = 0.0948]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.0000'|unit=' (-)'")>
    <DefaultValue(TRESP_on)>
    Public Property TRESP As Double
        Get
            Return _TRESP
        End Get
        Set
            _TRESP = Value
        End Set
    End Property


#End Region

    Public Const catConstantsDegT50 As String = "05  Constants"

#Region "    Constants"

    Public Const stdcntLiqTraRef As Double = 1

    <Category(catConstantsDegT50)>
    <DisplayName(
    "DT50 Liquid Content")>
    <Description(
    "Liq. content at which DT50 is measured" & vbCrLf &
    "in kg/kg [0|1], std. 1kg/kg")>
    Public Property cntLiqTraRef As Double = stdcntLiqTraRef


    Public Enum eOptCntLiqTraRef
        OptimumConditions
        NonOptimumConditions
    End Enum

    <Category(catConstantsDegT50)>
    <DisplayName("(Non) Optimum Conditions")>
    <Description("std. = OptimumConditions")>
    Public Property optCntLiqTraRef As eOptCntLiqTraRef = eOptCntLiqTraRef.OptimumConditions

    ''' <summary>
    ''' Option for DT50: Input or Calculate in
    ''' equilibrium domain(EqlDom) Or In liquid phase
    ''' only (LiqPhs)
    ''' </summary>
    Public Enum eOptDT50

        EqlDom_Input
        LiqPhs_Input

        EqlDom_Calculate
        LiqPhs_Calculate

    End Enum

    <Category(catConstantsDegT50)>
    <DisplayName("Inp/Calc Equ. Domain or Liquid phase")>
    <Description("std. = OptimumConditions")>
    Public Property optDT50 As eOptDT50 = eOptDT50.EqlDom_Input

#End Region

End Class

''' <summary>
''' DT50 incl. depth dependent degradation
''' </summary>
<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class degT50DepthDependent

    Inherits degT50

    Public Sub New()

    End Sub

    <Browsable(False)>
    Public Overrides ReadOnly Property name As String
        Get

            If Not Double.IsNaN(degT50) Then

                Return MyBase.name &
                    IIf(
                    Expression:=depthDependentFOCUSuserdef = eDepthDependentFOCUSuserdef.FOCUS,
                    TruePart:="",
                    FalsePart:=" ".PadLeft(40) & vbCrLf & "user def. depth dep. degT50!!")

            Else
                Return Misc.not_defined
            End If

        End Get
    End Property

    Public Const catDepthDependentDegratation As String = "02  Depth dep. degradation"

#Region "    Depth dependent degradation"


    Private _depthDependentFOCUSuserdef As eDepthDependentFOCUSuserdef = eDepthDependentFOCUSuserdef.FOCUS

    ''' <summary>
    ''' Depth dependent degt50?
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catDepthDependentDegratation)>
    <DisplayName("Depth dep. degt50")>
    <DefaultValue(CInt(eDepthDependentFOCUSuserdef.FOCUS))>
    Public Property depthDependentFOCUSuserdef As eDepthDependentFOCUSuserdef
        Get
            Return _depthDependentFOCUSuserdef
        End Get
        Set

            _depthDependentFOCUSuserdef = Value

            If _depthDependentFOCUSuserdef = eDepthDependentFOCUSuserdef.FOCUS Then
                depthDependentDegradation = Nothing
            Else
                depthDependentDegradation = New depthDependentDegradation
            End If

        End Set
    End Property

    <DisplayName("Scenario Settings")>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catDepthDependentDegratation)>
    <DefaultValue(CType(Nothing, Object))>
    Public Property depthDependentDegradation As depthDependentDegradation = Nothing

#End Region

End Class

''' <summary>
''' DT50 incl. DT90 and rate per days in %
''' </summary>
<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class degT50

#Region "    Constructor"

    Public Sub New()

    End Sub

    Public Sub New(degT50 As Double)
        Me.degT50 = degT50
    End Sub

#End Region

#Region "    Meta"

    <Browsable(False)>
    Public Overridable ReadOnly Property name As String
        Get

            If Not Double.IsNaN(degT50) Then
                Return _
                    ("DT50 : " & degT50.ToString & " days").PadRight(40) & vbCrLf &
                    ("rate : " & kPerc & " % / day").PadRight(40) & vbCrLf &
                     "DT90 : " & conv2String(value:=degT90, unit:=" days")
            Else
                Return Misc.not_defined
            End If

        End Get
    End Property

    Public Overridable Function createPEARLdegT50(Optional iop As String = "") As String

        Return createPrlRow(
            Value:=Me.degT50,
            iop:=iop,
            parameterName:="DT50Ref_",
            unit:="(d)",
            description:=kPerc & " % / day, degT90 = " & conv2String(value:=degT90, unit:=" days"),
            range:="[1|1e6]")

    End Function

    <Browsable(False)>
    Public ReadOnly Property inputComplete As String
        Get

            If Double.IsNaN(Me.degT50) Then Return " degt50 ?"

            Return Misc.inputComplete

        End Get
    End Property

#End Region

    Public Const catDT50 As String = "01  degT50"

#Region "    degT50"

    Private _degT50 As Double = stdDblEmpty

    ''' <summary>
    ''' Single first order degradation
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Description(
    "Single first order degradation" & vbCrLf &
    "click '...' to fill k")>
    <DisplayName(
    "degT50")>
    <Category(catDT50)>
    <DefaultValue(Double.NaN)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("unit=' days'")>
    <Editor(GetType(buttonEmulatorGeneric), GetType(UITypeEditor))>
    Public Overridable Property degT50 As Double
        Get
            If buttonEmulatorGeneric.Clicked Then

                If Not Double.IsNaN(_degT50) Then
                    Try
                        _k = Math.Log(2) / _degT50
                    Catch ex As Exception
                        _k = stdDblEmpty
                    End Try

                End If

                buttonEmulatorGeneric.Clicked = False

            End If

            Return _degT50

        End Get
        Set
            _degT50 = Value
        End Set
    End Property

    ''' <summary>
    ''' degT90
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catDT50)>
    <DisplayName(
    "   degT90")>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("unit=' days'")>
    Public ReadOnly Property degT90 As Double
        Get

            If Not Double.IsNaN(_degT50) AndAlso _degT50 > 0 Then

                Return Math.Log(10) /
             (Math.Log(2) / _degT50)

            Else
                Return stdDblEmpty
            End If

        End Get
    End Property

    ''' <summary>
    ''' Rate per day in percent
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catDT50)>
    <DisplayName(
    "   rate per day")>
    Public ReadOnly Property kPerc As String
        Get

            If Not Double.IsNaN(_degT50) AndAlso _degT50 > 0 Then

                Return _
             (Math.Log(2) / _degT50 * 100).ToString("0.00") & " % per day"

            Else
                Return Misc.not_defined
            End If

        End Get
    End Property

    Private _k As Double = Double.NaN

    ''' <summary>
    ''' DFOP k
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catDT50)>
    <DisplayName(
    "   k (for DFOP)")>
    <Description(" click '...' to fill degT50")>
    <TypeConverter(GetType(dblConv))>
    <Editor(GetType(buttonEmulatorGeneric), GetType(UITypeEditor))>
    <AttributeProvider("format='G8' | unit=' per day'")>
    Public Property k As Double
        Get
            If buttonEmulatorGeneric.Clicked Then
                If Not Double.IsNaN(_k) AndAlso _k <> stdDblEmpty Then

                    Try
                        _degT50 = Math.Log(2) / _k
                    Catch ex As Exception
                        _degT50 = stdDblEmpty
                    End Try

                End If
            End If

            Return _k
        End Get
        Set
            _k = Value
        End Set
    End Property

#End Region

    Public Const catScenarioSpecific As String = "01a Scenario specific"

#Region "    Scenario specific"

    Private _scenarioSpecificDT50 As eOnOffUserdef = eOnOffUserdef.Off
    Private _scenarioSpecificData As degT50ScenarioSpecific() = Nothing

    ''' <summary>
    ''' Scenario Specific degT50 ?
    ''' </summary>
    ''' <returns></returns>
    <Category(catScenarioSpecific)>
    <DisplayName("Scenario Specific degT50 ?")>
    Public Overridable Property scenarioSpecificDT50 As eOnOffUserdef
        Get
            Return _scenarioSpecificDT50
        End Get
        Set
            _scenarioSpecificDT50 = Value
        End Set
    End Property

    ''' <summary>
    ''' degT50 Data
    ''' </summary>
    ''' <returns></returns>
    <Category(catScenarioSpecific)>
    <DefaultValue(CType(Nothing, Object))>
    <DisplayName("degT50 Data")>
    Public Overridable Property scenarioSpecificData As degT50ScenarioSpecific()
        Get
            Return _scenarioSpecificData
        End Get
        Set

            If _scenarioSpecificDT50 = eOnOffUserdef.Off Then
                _scenarioSpecificData = Nothing
            Else
                _scenarioSpecificData = Value
            End If

        End Set
    End Property

#End Region

End Class


''' <summary>
''' Scenario specific degT50
''' </summary>
<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class degT50ScenarioSpecific

    Public Sub New()

    End Sub

    <Category(catDT50)>
    Public Property scenario As eScenariosGW = eScenariosGW.not_def

    <Browsable(False)>
    Public ReadOnly Property name As String
        Get
            Return getEnumDescription(Me.scenario)
        End Get
    End Property

    Public Const catDT50 As String = "01  degT50"

#Region "    degT50"

    Private _degT50 As Double = stdDblEmpty

    ''' <summary>
    ''' Single first order degradation
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Description(
    "Single first order degradation" & vbCrLf &
    "click '...' to fill k")>
    <DisplayName(
    "degT50")>
    <Category(catDT50)>
    <DefaultValue(Double.NaN)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("unit=' days'")>
    <Editor(GetType(buttonEmulatorGeneric), GetType(UITypeEditor))>
    Public Overridable Property degT50 As Double
        Get
            If buttonEmulatorGeneric.Clicked Then

                If Not Double.IsNaN(_degT50) Then
                    Try
                        _k = Math.Log(2) / _degT50
                    Catch ex As Exception
                        _k = stdDblEmpty
                    End Try

                End If

                buttonEmulatorGeneric.Clicked = False

            End If

            Return _degT50

        End Get
        Set
            _degT50 = Value
        End Set
    End Property

    ''' <summary>
    ''' degT90
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catDT50)>
    <DisplayName(
    "   degT90")>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("unit=' days'")>
    Public ReadOnly Property degT90 As Double
        Get

            If Not Double.IsNaN(_degT50) AndAlso _degT50 > 0 Then

                Return Math.Log(10) /
             (Math.Log(2) / _degT50)

            Else
                Return stdDblEmpty
            End If

        End Get
    End Property

    ''' <summary>
    ''' Rate per day in percent
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catDT50)>
    <DisplayName(
    "   rate per day")>
    Public ReadOnly Property kPerc As String
        Get

            If Not Double.IsNaN(_degT50) AndAlso _degT50 > 0 Then

                Return _
             (Math.Log(2) / _degT50 * 100).ToString("0.00") & " % per day"

            Else
                Return Misc.not_defined
            End If

        End Get
    End Property

    Private _k As Double = Double.NaN

    ''' <summary>
    ''' DFOP k
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catDT50)>
    <DisplayName(
    "   k (for DFOP)")>
    <Description(" click '...' to fill degT50")>
    <TypeConverter(GetType(dblConv))>
    <Editor(GetType(buttonEmulatorGeneric), GetType(UITypeEditor))>
    <AttributeProvider("format='G8' | unit=' per day'")>
    Public Property k As Double
        Get
            If buttonEmulatorGeneric.Clicked Then
                If Not Double.IsNaN(_k) AndAlso _k <> stdDblEmpty Then

                    Try
                        _degT50 = Math.Log(2) / _k
                    Catch ex As Exception
                        _degT50 = stdDblEmpty
                    End Try

                End If
            End If

            Return _k
        End Get
        Set
            _k = Value
        End Set
    End Property

#End Region

    <Browsable(False)>
    <DefaultValue(CType(Nothing, Object))>
    Public Property scenarioSpecificDT50 As eOnOffUserdef = Nothing

    <Browsable(False)>
    <DefaultValue(CType(Nothing, Object))>
    Public Property scenarioSpecificData As degT50ScenarioSpecific() = Nothing

End Class


''' <summary>
''' depth dependent degradation
''' </summary>
<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class depthDependentDegradation

    Public Sub New()
        resetFacZTra()
    End Sub

    Public Const catDepthDependentDegradation As String = "02  Depth dep. Degradation "

    <Editor(GetType(buttonEmulator), GetType(UITypeEditor))>
    Public Property reset As String
        Get
            Return ""
        End Get
        Set(value As String)

            If value.Contains(buttonEmulator.Clicked) Then
                resetFacZTra()
            End If

        End Set
    End Property

    Public Sub resetFacZTra()

        Dim facZTraList As New List(Of facZ)

        For scenario As eScenariosGW = eScenariosGW.Chateaudun To eScenariosGW.Thiva

            facZTraList.Add(New facZ)

            With facZTraList(facZTraList.Count - 1)

                .scenario = scenario

                .PEARL444 = getFacZTra(
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL444)

                .PEARL555 = getFacZTra(
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL555)

            End With

        Next

        facZTra = facZTraList.ToArray

    End Sub

    Public Function getFacZTra(scenario As eScenariosGW) As facZ

        For Each member As facZ In facZTra
            If member.scenario = scenario Then
                Return member
            End If
        Next

        Return Nothing

    End Function

    Public Function getFacZTra(scenario As eScenariosGW, version As ePEARLVersion) As Double()

        Dim facZ As New facZ

        facZ = getFacZTra(scenario:=scenario)

        If Not IsNothing(facZ) Then

            If version = ePEARLVersion.PEARL444 Then
                Return facZ.PEARL444
            Else
                Return facZ.PEARL555
            End If

        End If

        Return Nothing

    End Function

    Public Property facZTra As facZ() = {}

End Class


''' <summary>
''' Depth dependent degT50/Sorption base class
''' </summary>
<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class facZ

    Private _PEARL444 As Double() = {}
    Private _PEARL555 As Double() = {}

    Public Sub New()

    End Sub

    <Browsable(False)>
    Public ReadOnly Property name As String
        Get
            Return scenario.ToString
        End Get
    End Property

    Public Property scenario As eScenariosGW = eScenariosGW.not_def

    <Editor(GetType(multiLineDoubleArrayEditor), GetType(UITypeEditor))>
    <DisplayName("PEARL 4.4.4")>
    Public Property PEARL444 As Double()
        Get
            Return _PEARL444
        End Get
        Set

            If Value.Count <> getFacZSor(
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL444).Count Then
                MsgBox(Prompt:="# of horizons do not match, must be " & getFacZSor(
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL444).Count)
            Else
                _PEARL444 = Value
            End If

        End Set
    End Property

    <Editor(GetType(multiLineDoubleArrayEditor), GetType(UITypeEditor))>
    <DisplayName("PEARL 5.5.5")>
    Public Property PEARL555 As Double()
        Get
            Return _PEARL555
        End Get
        Set

            If Value.Count <> getFacZSor(
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL555).Count Then
                MsgBox(Prompt:="# of horizons do not match, must be " & getFacZSor(
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL555).Count)
            Else
                _PEARL555 = Value
            End If

        End Set
    End Property

End Class
