# To Extract the results PEC values from the TopRice runs, PEARL and TOXSWA separatly. 

  ### PEARL
  # define path to your PEARL files
  d <- dir(".", pattern = '_prl.sum$', full.names=TRUE,recursive = TRUE)
  d.sub <- dir(".", pattern = '_prl.sum$',recursive = TRUE)
resultPEARL <- data.frame(NULL)
resultTOXSWA <- data.frame(NULL)  

  i <- 2
  
  
  for(i in 1:length(d)){
    su <- scan(d[i], what = 'character')
    if(length(su) == 0) next
    
    compound <- sub("Result_", "", su[grep("Result_", su)[-1]])
    PECs <- su[grep("Result_", su)[-1] + 1]
    
    xf <- data.frame(run = sub(".sum", "", d.sub[i]), Compound = compound, PEC = PECs)
    for(j in 3){
      xf[,j] <- as.character(xf[,j])
      xf[,j] <- as.numeric((xf[,j]))
      xf[,j] <- round(xf[,j], 3)
    }
    resultPEARL <- rbind(xf, resultPEARL)
  }
  
  ### TOXSWA
  # define path to your TXW files
  d <- dir(".", pattern = '_txw.sum$', full.names=TRUE,recursive = TRUE)
  d.sub <- dir(".", pattern = '_txw.sum$',recursive = TRUE)
  
  i <- 1
  
  
  
  for(i in 1:length(d)){
    su <- scan(d[i], what = 'character')
    if(length(su) == 0) next
    
    compound <- sub("Result_", "", su[grep("Result_", su)])
    PECs <- su[grep("Result_", su) + 1]
    TWA1 <- su[grep("TWA.d", su) + 3]
    TWA2 <- su[grep("TWA..d", su)+ 3]
    
    xf <- data.frame(run = sub(".sum", "", d.sub[i]), Compound = compound, PEC = PECs, 
                     TWA1 = TWA1[6],TWA2 = TWA1[7],TWA3 = TWA1[8],TWA4 = TWA1[9],TWA7 = TWA1[10],
                     TWA14 = TWA2[6],TWA21 = TWA2[7],TWA28 = TWA2[8],TWA35 = TWA2[9],TWA90 = TWA2[10])
    for(j in 3){
      xf[,j] <- as.character(xf[,j])
      xf[,j] <- as.numeric((xf[,j]))
      xf[,j] <- round(xf[,j], 3)
    }
    resultTOXSWA <- rbind(xf, resultTOXSWA)
  }
  
  
  write.csv2(resultPEARL, paste0(".", "/PECvalues_PEARL.csv"), row.names = FALSE)
  write.csv2(resultTOXSWA, paste0(".", "/PECvalues_TOXSWA.csv"), row.names = FALSE)
