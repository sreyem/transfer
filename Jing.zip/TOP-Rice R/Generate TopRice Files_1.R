##################################################
###
### modify pearl and toxswa input file for TopRice model
### create batch for input files
###
### Mar 23, 2018
###
##################################################

## if not available:
#install.packages("lubridate")


library(lubridate)

### definition of application window
BBCH_Begin <- 10
BBCH_End <- 20

## intervall between applications [days]
Appl_nr <- 2
interv <- 7  # for single application this does not play a role.

## To ask which for which scenarios the prl and txw files should be generated.
Run_Lianping <-"TRUE" # "TRUE" or "False"
Run_Nanchang <-"TRUE" # "TRUE" or "False"

## you need to enter the name of the template files for both scenarios and models]
## read template files
if(Run_Lianping){
lianping_prl <- readLines('./22.prl')
lianping_txw <- readLines('./22.txw')
}

if(Run_Nanchang){
Nanchang_prl <- readLines('./23.prl')
Nanchang_txw <- readLines('./23.txw')
}
# generate empty data frame
resultPEARL <- data.frame(NULL)
resultTOXSWA <- data.frame(NULL)



### to Call the App_Date function to calculate the applications dates and the corrosponding Interception
App_Inter <- App_Dates(BBCH_Begin,BBCH_End,Appl_nr,interv)


### To generate the prl and txw files for the Lianping Scenarios

if (Run_Lianping){
  appDatesSpring <- c(App_Inter$Lianping_appDates_early,App_Inter$Lianping_appDates_late)
  interception <- c(App_Inter$Lianping_Interception_early,App_Inter$Lianping_Interception_late)
  appDatesSpring_2 <- c(App_Inter$Lianping_appDates_early_2,App_Inter$Lianping_appDates_late_2)
  interception_2 <- c(App_Inter$Lianping_Interception_early_2,App_Inter$Lianping_Interception_late_2)
  
  p.sub <- lianping_prl
  t.sub <- lianping_txw

 Laenge <- length(appDatesSpring)
  
  for(i in 1:Laenge){

if (Appl_nr == 1) {
  ## modify PEARL input
  appl <- p.sub[grep("table Applications", p.sub) + 1:4]
  
  appl[1] <- sub(unlist(strsplit(appl[1], "\\s+"))[1], paste0(sprintf("%02d",day(appDatesSpring[i])), "-", month(appDatesSpring[i], label = TRUE)), appl[1])
  appl[1] <- sub(unlist(strsplit(appl[1], "\\s+"))[4], interception, appl[1], fixed=TRUE)
  #appl[2] <- sub(unlist(strsplit(appl[2], "\\s+"))[1], paste0(sprintf("%02d",day(appDatesSummer[i])), "-", month(appDatesSummer[i], label = TRUE)), appl[2])
  #appl[2] <- sub(unlist(strsplit(appl[2], "\\s+"))[4], App_Inter$Lianping_Interception_late[i], appl[2])
  
  
  p.sub[grep("table Applications", p.sub) + 1:4] <- appl
  
  ## modify TOXSWA input
  appl <- t.sub[grep("table Loadings", t.sub) + 1:4]
  
  t.sub <- sub(substring(unlist(strsplit(appl[1], "\\s+"))[1], 1, 6), paste0(sprintf("%02d",day(appDatesSpring[i])), "-", month(appDatesSpring[i], label = TRUE)), t.sub)
 # t.sub <- sub(substring(unlist(strsplit(appl[2], "\\s+"))[1], 1, 6), paste0(sprintf("%02d",day(appDatesSummer[i])), "-", month(appDatesSummer[i], label = TRUE)), t.sub)
  
  
} 
    
    else {
    ## modify PEARL input
    appl <- p.sub[grep("table Applications", p.sub) + 1:4]

    appl[1] <- sub(unlist(strsplit(appl[1], "\\s+"))[1], paste0(sprintf("%02d",day(appDatesSpring[i])), "-", month(appDatesSpring[i], label = TRUE)), appl[1])
    appl[2] <- sub(unlist(strsplit(appl[2], "\\s+"))[1], paste0(sprintf("%02d",day(appDatesSpring_2[i])), "-", month(appDatesSpring_2[i], label = TRUE)), appl[2])
    appl[1] <- sub(unlist(strsplit(appl[1], "\\s+"))[4], interception[i], appl[1],fixed=TRUE)
    appl[2] <- sub(unlist(strsplit(appl[2], "\\s+"))[4], interception_2[i], appl[2],fixed=TRUE)
    
    # appl[3] <- sub(unlist(strsplit(appl[3], "\\s+"))[1], paste0(sprintf("%02d",day(appDatesSummer[i])), "-", month(appDatesSummer[i], label = TRUE)), appl[3])
    # appl[4] <- sub(unlist(strsplit(appl[4], "\\s+"))[1], paste0(sprintf("%02d",day(appDatesSummer[i]+days(interv))), "-", month(appDatesSummer[i]+days(interv), label = TRUE)), appl[4])
    # appl[3] <- sub(unlist(strsplit(appl[3], "\\s+"))[4], App_Inter$Lianping_Interception_late[i], appl[3])
    # appl[4] <- sub(unlist(strsplit(appl[4], "\\s+"))[4], App_Inter$Lianping_Interception_late[i+interv], appl[4])
    
    p.sub[grep("table Applications", p.sub) + 1:4] <- appl
    ## modify TOXSWA input
    appl <- t.sub[grep("table Loadings", t.sub) + 1:4]

    t.sub <- sub(substring(unlist(strsplit(appl[1], "\\s+"))[1], 1, 6), paste0(sprintf("%02d",day(appDatesSpring[i])), "-", month(appDatesSpring[i], label = TRUE)), t.sub)
    t.sub <- sub(substring(unlist(strsplit(appl[2], "\\s+"))[1], 1, 6), paste0(sprintf("%02d",day(appDatesSpring_2[i])), "-", month(appDatesSpring_2[i], label = TRUE)), t.sub)
    # t.sub <- sub(substring(unlist(strsplit(appl[3], "\\s+"))[1], 1, 6), paste0(sprintf("%02d",day(appDatesSummer[i])), "-", month(appDatesSummer[i], label = TRUE)), t.sub)
    # t.sub <- sub(substring(unlist(strsplit(appl[4], "\\s+"))[1], 1, 6), paste0(sprintf("%02d",day(appDatesSummer[i]+days(interv))), "-", month(appDatesSummer[i]+days(interv), label = TRUE)), t.sub)
}
    ### define filenames
    prlnam <- paste0("L_spr_",day(appDatesSpring[i]), month(appDatesSpring[i], label = TRUE), "_sum", ".prl")
    txwnam <- paste0("L_spr_",day(appDatesSpring[i]), month(appDatesSpring[i], label = TRUE), "_sum", ".txw")

    ### define the sum files names
    prlnam_sum <- paste0("L_spr_",day(appDatesSpring[i]), month(appDatesSpring[i], label = TRUE), "_sum", ".sum")
    txwnam_sum <- paste0("L_spr_",day(appDatesSpring[i]), month(appDatesSpring[i], label = TRUE), "_sum", ".sum")
    
    
    writeLines(p.sub, prlnam)
    writeLines(t.sub, txwnam)
    
    

### create batch file - PEARL and TOXSWA
### also to change the name of the pearl result file so it is not overwritten from toxswa result file
#    cat(paste0("ren ","lianping.bfo", " ", paste0(unlist(strsplit(prlnam, "[.]"))[[1]],".bfo")),file="run.bat", sep="\n", append = TRUE)
    cat(paste0('"', "pearlmodel.exe", '" ', prlnam),file="run.bat", sep="\n", append = TRUE)
#    cat(paste0("ren ", paste0(unlist(strsplit(prlnam, "[.]"))[[1]],".bfo"), " ", "lianping.bfo"),file="run.bat", sep="\n", append = TRUE)
    cat(paste0("ren ",prlnam_sum, " ", paste0(unlist(strsplit(prlnam, "[.]"))[[1]],"_prl.sum")),file="run.bat", sep="\n", append = TRUE)
    cat(paste0("ren ","lianping.hyd", " ", paste0(unlist(strsplit(prlnam, "[.]"))[[1]],".hyd")),file="run.bat", sep="\n", append = TRUE)
    cat(paste0('"', "Toxswamodel.exe", '" ', txwnam),file="run.bat", sep="\n", append = TRUE)
    cat(paste0("ren ",txwnam_sum, " ", paste0(unlist(strsplit(txwnam, "[.]"))[[1]],"_txw.sum")),file="run.bat", sep="\n", append = TRUE)
    cat(paste0("ren ", paste0(unlist(strsplit(prlnam, "[.]"))[[1]],".hyd"), " ", "lianping.hyd"),file="run.bat", sep="\n", append = TRUE)
}
}

if (Run_Nanchang){
  appDatesSpring <- c(App_Inter$Nanchang_appDates_early,App_Inter$Nanchang_appDates_late)
  interception <- c(App_Inter$Nanchang_Interception_early,App_Inter$Nanchang_Interception_late)

  appDatesSpring_2 <- c(App_Inter$Nanchang_appDates_early_2,App_Inter$Nanchang_appDates_late_2)
  interception_2 <- c(App_Inter$Nanchang_Interception_early_2,App_Inter$Nanchang_Interception_late_2)
  
    p.sub <- Nanchang_prl
  t.sub <- Nanchang_txw
  
  Laenge <- length(appDatesSpring)
  
  for(i in 1:Laenge){
    
    if (Appl_nr == 1) {
      ## modify PEARL input
      appl <- p.sub[grep("table Applications", p.sub) + 1:4]
      
      appl[1] <- sub(unlist(strsplit(appl[1], "\\s+"))[1], paste0(sprintf("%02d",day(appDatesSpring[i])), "-", month(appDatesSpring[i], label = TRUE)), appl[1])
      appl[1] <- sub(unlist(strsplit(appl[1], "\\s+"))[4], interception[i], appl[1],fixed=TRUE)
      # appl[2] <- sub(unlist(strsplit(appl[2], "\\s+"))[1], paste0(sprintf("%02d",day(appDatesSummer[i])), "-", month(appDatesSummer[i], label = TRUE)), appl[2])
      # appl[2] <- sub(unlist(strsplit(appl[2], "\\s+"))[4], App_Inter$Nanchang_Interception_late[i], appl[2])
      
      
      p.sub[grep("table Applications", p.sub) + 1:4] <- appl
      
      ## modify TOXSWA input
      appl <- t.sub[grep("table Loadings", t.sub) + 1:4]
      
      t.sub <- sub(substring(unlist(strsplit(appl[1], "\\s+"))[1], 1, 6), paste0(sprintf("%02d",day(appDatesSpring[i])), "-", month(appDatesSpring[i], label = TRUE)), t.sub)
      # t.sub <- sub(substring(unlist(strsplit(appl[2], "\\s+"))[1], 1, 6), paste0(sprintf("%02d",day(appDatesSummer[i])), "-", month(appDatesSummer[i], label = TRUE)), t.sub)
      
      
    } 
    
    else {
      ## modify PEARL input
      appl <- p.sub[grep("table Applications", p.sub) + 1:4]
      
      appl[1] <- sub(unlist(strsplit(appl[1], "\\s+"))[1], paste0(sprintf("%02d",day(appDatesSpring[i])), "-", month(appDatesSpring[i], label = TRUE)), appl[1])
      appl[2] <- sub(unlist(strsplit(appl[2], "\\s+"))[1], paste0(sprintf("%02d",day(appDatesSpring_2[i])), "-", month(appDatesSpring_2[i], label = TRUE)), appl[2])
      appl[1] <- sub(unlist(strsplit(appl[1], "\\s+"))[4], interception[i], appl[1],fixed=TRUE)
      appl[2] <- sub(unlist(strsplit(appl[2], "\\s+"))[4], interception_2[i], appl[2],fixed=TRUE)
      
      # appl[3] <- sub(unlist(strsplit(appl[3], "\\s+"))[1], paste0(sprintf("%02d",day(appDatesSummer[i])), "-", month(appDatesSummer[i], label = TRUE)), appl[3])
      # appl[4] <- sub(unlist(strsplit(appl[4], "\\s+"))[1], paste0(sprintf("%02d",day(appDatesSummer[i]+days(interv))), "-", month(appDatesSummer[i]+days(interv), label = TRUE)), appl[4])
      # appl[3] <- sub(unlist(strsplit(appl[3], "\\s+"))[4], App_Inter$Nanchang_Interception_late[i], appl[3])
      # appl[4] <- sub(unlist(strsplit(appl[4], "\\s+"))[4], App_Inter$Nanchang_Interception_late[i+interv], appl[4])
      # 
      p.sub[grep("table Applications", p.sub) + 1:4] <- appl
      ## modify TOXSWA input
      appl <- t.sub[grep("table Loadings", t.sub) + 1:4]
      
      t.sub <- sub(substring(unlist(strsplit(appl[1], "\\s+"))[1], 1, 6), paste0(sprintf("%02d",day(appDatesSpring[i])), "-", month(appDatesSpring[i], label = TRUE)), t.sub)
      t.sub <- sub(substring(unlist(strsplit(appl[2], "\\s+"))[1], 1, 6), paste0(sprintf("%02d",day(appDatesSpring_2[i])), "-", month(appDatesSpring_2[i], label = TRUE)), t.sub)
      # t.sub <- sub(substring(unlist(strsplit(appl[3], "\\s+"))[1], 1, 6), paste0(sprintf("%02d",day(appDatesSummer[i])), "-", month(appDatesSummer[i], label = TRUE)), t.sub)
      # t.sub <- sub(substring(unlist(strsplit(appl[4], "\\s+"))[1], 1, 6), paste0(sprintf("%02d",day(appDatesSummer[i]+days(interv))), "-", month(appDatesSummer[i]+days(interv), label = TRUE)), t.sub)
    }
    ### define filenames
    prlnam <- paste0("N_spr_",day(appDatesSpring[i]), month(appDatesSpring[i], label = TRUE), "_sum", ".prl")
    txwnam <- paste0("N_spr_",day(appDatesSpring[i]), month(appDatesSpring[i], label = TRUE), "_sum", ".txw")
    
    ### define the sum files names
    prlnam_sum <- paste0("N_spr_",day(appDatesSpring[i]), month(appDatesSpring[i], label = TRUE), "_sum", ".sum")
    txwnam_sum <- paste0("N_spr_",day(appDatesSpring[i]), month(appDatesSpring[i], label = TRUE), "_sum", ".sum")
    
    
    writeLines(p.sub, prlnam)
    writeLines(t.sub, txwnam)
    
    
    
    ### create batch file - PEARL and TOXSWA
    ### also to change the name of the pearl result file so it is not overwritten from toxswa result file
#    cat(paste0("ren ","nanchang.bfo", " ", paste0(unlist(strsplit(prlnam, "[.]"))[[1]],".bfo")),file="run.bat", sep="\n", append = TRUE)
    cat(paste0('"', "pearlmodel.exe", '" ', prlnam),file="run.bat", sep="\n", append = TRUE)
#    cat(paste0("ren ", paste0(unlist(strsplit(prlnam, "[.]"))[[1]],".bfo"), " ", "nanchang.bfo"),file="run.bat", sep="\n", append = TRUE)
    cat(paste0("ren ",prlnam_sum, " ", paste0(unlist(strsplit(prlnam, "[.]"))[[1]],"_prl.sum")),file="run.bat", sep="\n", append = TRUE)
    cat(paste0("ren ","nanchang.hyd", " ", paste0(unlist(strsplit(prlnam, "[.]"))[[1]],".hyd")),file="run.bat", sep="\n", append = TRUE)
    cat(paste0('"', "Toxswamodel.exe", '" ', txwnam),file="run.bat", sep="\n", append = TRUE)
    cat(paste0("ren ",txwnam_sum, " ", paste0(unlist(strsplit(txwnam, "[.]"))[[1]],"_txw.sum")),file="run.bat", sep="\n", append = TRUE)
    cat(paste0("ren ", paste0(unlist(strsplit(prlnam, "[.]"))[[1]],".hyd"), " ", "nanchang.hyd"),file="run.bat", sep="\n", append = TRUE)
  }
}