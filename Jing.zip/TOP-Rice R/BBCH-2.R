# BBCH and Interception Function to calculate the application dates, return the application dates list, and the corrosponding Interception values

App_Dates <- function(Start_BBCH, End_BBCH,No_Appli,interv_length){

# Enter the BBCH window according to the GAP

  library(lubridate)
  
BBCH_Begin <- Start_BBCH
BBCH_End <- End_BBCH


# These are the BBCH start and end values for the different growing stages of rice and the corrosponding interception values
# These are values are taken directly from TopRice.
BBCH_Begin_early <- c(0,10,20,30,40,90)
BBCH_Begin_late <- c(10,20,30,40,90)
BBCH_End_early <- c(9,19,29,39,89,99)
BBCH_End_late <- c(19,29,39,89,99)
Interception <- c(0.25,0.5,0.7,0.9,0.9)


# Beging and end dates in the first rice growing season for the different BBCHC above for the Lianping location.
# 
Lianping_Begin_Date_early <- as.Date(c("01-Jan","13-Apr","20-Apr","11-May","26-May","03-Jun"),"%d-%b")
Lianping_End_Date_early <- as.Date(c("12-Apr","19-Apr","10-May","25-May","02-Jun","15-Jul"),"%d-%b")

# Beging and end dates in the second rice growing season for the different BBCHC above for the Lianping location.
# 
Lianping_Begin_Date_late <- as.Date(c("16-Jul","22-Jul","14-Aug","29-Aug","07-Sep"),"%d-%b")
Lianping_End_Date_late <- as.Date(c("21-Jul","13-Aug","28-Aug","06-Sep","23-Oct"),"%d-%b")

# Beging and end dates in the first rice growing season for the different BBCHC above for the Nanchang location.
# 
Nanchang_Begin_Date_early <- as.Date(c("01-Jan","22-Apr","28-Apr","18-May","02-Jun","09-Jun"),"%d-%b")
Nanchang_Begin_Date_late <- as.Date(c("11-Jul","17-Jul","09-Aug","25-Aug","04-Sep"),"%d-%b")

# Beging and end dates in the second rice growing season for the different BBCHC above for the Nanchang location.
# 
Nanchang_End_Date_early <- as.Date(c("21-Apr","27-Apr","17-May","01-Jun","08-Jun","10-Jul"),"%d-%b")
Nanchang_End_Date_late <- as.Date(c("16-Jul","08-Aug","24-Aug","03-Sep","20-Oct"),"%d-%b")

# the starting and end dates for the calculation, Lianping first rice growing season
Lianping_start1 <- as.Date(approx(x=BBCH_Begin_early,y=Lianping_Begin_Date_early, xout=BBCH_Begin)$y,origin = "1970-01-01")
Lianping_end1 <- as.Date(approx(x=BBCH_End_early,y=Lianping_End_Date_early, xout=BBCH_End)$y,origin = "1970-01-01")

# the starting and end dates for the calculation, Lianping second rice growing season
Lianping_start2 <- as.Date(approx(x=BBCH_Begin_late,y=Lianping_Begin_Date_late, xout=BBCH_Begin)$y,origin = "1970-01-01")
Lianping_end2 <- as.Date(approx(x=BBCH_End_late,y=Lianping_End_Date_late, xout=BBCH_End)$y,origin = "1970-01-01")

# the starting and end dates for the calculation, Nanchang first rice growing season
Nanchang_start1 <- as.Date(approx(x=BBCH_Begin_early,y=Nanchang_Begin_Date_early, xout=BBCH_Begin)$y,origin = "1970-01-01")
Nanchang_end1 <- as.Date(approx(x=BBCH_End_early,y=Nanchang_End_Date_early, xout=BBCH_End)$y,origin = "1970-01-01")

# the starting and end dates for the calculation, Nanchang second rice growing season
Nanchang_start2 <- as.Date(approx(x=BBCH_Begin_late,y=Nanchang_Begin_Date_late, xout=BBCH_Begin)$y,origin = "1970-01-01")
Nanchang_end2 <- as.Date(approx(x=BBCH_End_late,y=Nanchang_End_Date_late, xout=BBCH_End)$y,origin = "1970-01-01")

# Listing the days from the start to the end of the application windown for Lianping first and second growing season
Lianping_appDates_early <- seq(ymd(Lianping_start1), ymd(Lianping_end1), by = "days")
Lianping_appDates_late <- seq(ymd(Lianping_start2), ymd(Lianping_end2), by = "days")

# Listing the days from the start to the end of the application windown for Nanchang first and second growing season
Nanchang_appDates_early <- seq(ymd(Nanchang_start1), ymd(Nanchang_end1), by = "days")
Nanchang_appDates_late <- seq(ymd(Nanchang_start2), ymd(Nanchang_end2), by = "days")

#################################################

if(Appl_nr !=  1){
  Lianping_appDates_early_2 <- Lianping_appDates_early + interv_length
  Lianping_appDates_late_2 <- Lianping_appDates_late + interv_length
  
  Nanchang_appDates_early_2 <- Nanchang_appDates_early + interv_length
  Nanchang_appDates_late_2 <- Nanchang_appDates_late + interv_length 
}
else
{
  Lianping_appDates_early_2 <-NULL
  Lianping_appDates_late_2 <- NULL
  
  Nanchang_appDates_early_2 <- NULL
  Nanchang_appDates_late_2 <- NULL
}

  

#################################################

# Calculating the corrosponding Interception values for the applications dates
Lianping_Interception_early <- Interception[findInterval(Lianping_appDates_early,Lianping_Begin_Date_early)-1]
Lianping_Interception_late <- Interception[findInterval(Lianping_appDates_late,Lianping_Begin_Date_late)]

Nanchang_Interception_early <- Interception[findInterval(Nanchang_appDates_early,Nanchang_Begin_Date_early)-1]
Nanchang_Interception_late <- Interception[findInterval(Nanchang_appDates_late,Nanchang_Begin_Date_late)]

if(Appl_nr !=  1){
  Lianping_Interception_early_2 <- Interception[findInterval(Lianping_appDates_early_2,Lianping_Begin_Date_early)-1]
  Lianping_Interception_late_2 <- Interception[findInterval(Lianping_appDates_late_2,Lianping_Begin_Date_late)]
  
  Nanchang_Interception_early_2 <- Interception[findInterval(Nanchang_appDates_early_2,Nanchang_Begin_Date_early)-1]
  Nanchang_Interception_late_2 <- Interception[findInterval(Nanchang_appDates_late_2,Nanchang_Begin_Date_late)]
}
else
{
  Lianping_Interception_early_2 <- NULL
  Lianping_Interception_late_2 <- NULL
  
  Nanchang_Interception_early_2 <- NULL
  Nanchang_Interception_late_2 <- NULL
  
}


Results <- list(Lianping_appDates_early=Lianping_appDates_early, Lianping_Interception_early=Lianping_Interception_early,
                Lianping_appDates_late=Lianping_appDates_late, Lianping_Interception_late=Lianping_Interception_late,
                Lianping_appDates_early_2=Lianping_appDates_early_2, Lianping_Interception_early_2=Lianping_Interception_early_2,
                Lianping_appDates_late_2=Lianping_appDates_late_2, Lianping_Interception_late_2=Lianping_Interception_late_2,
                Nanchang_appDates_early=Nanchang_appDates_early, Nanchang_Interception_early=Nanchang_Interception_early,
                Nanchang_appDates_late=Nanchang_appDates_late, Nanchang_Interception_late=Nanchang_Interception_late,
                Nanchang_appDates_early_2=Nanchang_appDates_early_2, Nanchang_Interception_early_2=Nanchang_Interception_early_2,
                Nanchang_appDates_late_2=Nanchang_appDates_late_2, Nanchang_Interception_late_2=Nanchang_Interception_late_2)

return(Results)
}
