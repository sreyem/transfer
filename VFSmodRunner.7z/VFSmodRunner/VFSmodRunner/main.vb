﻿
Imports System.Deployment
Imports System.IO
Imports System.Windows.Forms
Imports VFSmodRunner

Public Module main

    Public args As String() = {}
    Public bhpc As Boolean = False
    Public runName As String = ""

    Sub Main()

        If Not init() Then

            Environment.ExitCode = 0
            Exit Sub

        End If

        Dim runMode As eRunMode

        runMode = getRunMode(args:=args)

        Select Case runMode

            Case eRunMode.unset
                Exit Sub

            Case eRunMode.directory
                runZIPs(args:=args)

            Case eRunMode.prjSingle
                runSingle(vfsmPath:=args.First, prjPath:=args.Last)

            Case eRunMode.prjMulti

                runMulti(args:=args)

            Case Else
                Exit Sub

        End Select

    End Sub

#Region "    base : run single or zip"

    ''' <summary>
    ''' Run single *.prj file
    ''' </summary>
    ''' <param name="vfsmPath">
    ''' full path to vfsm*.exe
    ''' normal taken from 1st argument
    ''' </param>
    ''' <param name="prjPath">
    ''' full path to *.prj file
    ''' normal taken from 2nd argument
    ''' </param>
    ''' <param name="maxWaitTime">
    ''' max. time in sec for a vfsm calculation to run
    ''' std. = 30sec
    ''' </param>
    ''' <returns></returns>
    '<DebuggerStepThrough>
    Public Function runSingle(vfsmPath As String, prjPath As String,
                     Optional maxWaitTime As Integer = 30) As Boolean

        Dim myProcess As New Process
        Dim timeCounter As Integer = 0
        Dim logOut As New List(Of String)

        With myProcess

            Try

                If Not createStartInfo(
                    startInfo:= .StartInfo, vfsmPath:=vfsmPath,
                    prjPath:=prjPath, logOut:=logOut) Then
                    Return False
                End If

                If Not setArguments(
                    prjPath:=prjPath, startInfo:= .StartInfo, logOut:=logOut) Then
                    Return False
                End If

                If Not runProcess(
                    myProcess:=myProcess, maxWaitTime:=maxWaitTime) Then
                    Return False
                End If

                If Not checkProcess(myProcess:=myProcess) Then
                    Return False
                End If

                If Not writeRunTime2Log(myProcess:=myProcess) Then
                    Return False
                End If

            Catch ex As Exception

                mylog(LogTxtArray:=parseExceptionMsg(Exception:=ex))
                Return False

            End Try

        End With

        Return True

    End Function

    ''' <summary>
    ''' Run a directory with *.zip files 
    ''' for each event
    ''' </summary>
    ''' <param name="args">
    ''' cmd line arguments
    ''' 1st = full path to vfsm*.exe
    ''' 2nd = zip file directory
    ''' </param>
    ''' <returns></returns>
    '<DebuggerStepThrough>
    Public Function runZIPs(args As String()) As Boolean

#Region "    definitions"

        Dim VFSmodZIPfilePaths As String() = {}
        Dim VFSmodZIPfile As String = ""
        Dim targetPath As String = ""
        Dim prjFiles As String() = {}
        Dim prevEventName As String = ""
        Dim owqFile As String() = {}

        Dim dgmresCounter As Integer = 0
        Dim startTime As Date = Now

        Dim outFiles As New List(Of String)

#End Region

        If Not getVFSmodZIPfilePaths(
            VFSmodZIPfilePaths:=VFSmodZIPfilePaths, targetPath:=args.Last) Then Return False

        For VFSmodZIPfilecounter As Integer = 0 To VFSmodZIPfilePaths.Count - 1

            If Not startLog(
                VFSmodZIPfilePaths:=VFSmodZIPfilePaths,
                VFSmodZIPfilecounter:=VFSmodZIPfilecounter) Then Return False

            If Not setTargetPath(
                targetPath:=targetPath,
                VFSmodZIPfilePath:=VFSmodZIPfilePaths(VFSmodZIPfilecounter)) Then Return False

            If Not unzipVFSmodPackage(
                vfsModZipFilePath:=VFSmodZIPfilePaths(VFSmodZIPfilecounter), targetPath:=targetPath) Then Return False

            prjFiles =
                Directory.GetFiles(
                    path:=targetPath,
                    searchPattern:="*.prj",
                    searchOption:=SearchOption.TopDirectoryOnly)

            runTimes.Clear()

            For prjFileCounter As Integer = 0 To prjFiles.Count - 1

                If prjFileCounter = 0 AndAlso prjFiles.Count > 1 Then

                    mylog(LogTxt:=align2strings(
                              "prj files to do",
                              prjFiles.Count))

                End If

                setIntentLevel(IntentLevel:=eLogLevel.up)

                If prjFiles.Count > 1 Then
                    mylog(LogTxt:="")
                    mylog(LogTxt:=align2strings(" *** Actual prj file",
                                      (prjFileCounter + 1).ToString("00") & " of " &
                                      (prjFiles.Count).ToString("00") & "     " &
                                      Path.GetFileName(prjFiles(prjFileCounter))))

                End If


                If VFSmodZIPfilecounter > 0 Then

                    writeDGMRES(
                        dgmres:=dgmres(prjFileCounter),
                        iwqFilePath:=Path.ChangeExtension(path:=prjFiles(prjFileCounter), ".iwq"))

                Else
                    mylog(LogTxt:=align2strings(" ", "first/single run, no update of dgmres in *.iwq file"))
                End If

                If Not runSingle(vfsmPath:=args.First,
                                 prjPath:=prjFiles(prjFileCounter)) Then

                    With mitigation

                        .fem = -99
                        .frv = -99

                        If VFSmodZIPfilecounter > 0 Then

                            For Each member In mitigations(0).fluxMitigation
                                mitigation.fluxMitigation.Add(
                                    New fluxMitigation(fef:=-99, frf:=-99))
                            Next

                        End If


                    End With
                Else
                    parseOWQ(
                        owqPath:=Path.ChangeExtension(path:=prjFiles(prjFileCounter), ".owq"),
                        mitigation:=mitigation)
                End If

                setIntentLevel(IntentLevel:=eLogLevel.down)

            Next


            If dgmres.Count > prjFiles.Count Then

                For counter As Integer = 0 To prjFiles.Count - 1
                    dgmres.RemoveAt(0)
                Next

            End If

            writeMitigation2CSV_XML(
                    dateString:=Path.GetFileNameWithoutExtension(prjFiles.Last).Substring(0, 6), mitigation:=mitigation)

            mitigation = New mitigationFactors

#Region "        zip"


            outFiles.Clear()

            outFiles.AddRange(Directory.GetFiles(
                            path:=targetPath,
                            searchPattern:="*.o*",
                            searchOption:=SearchOption.TopDirectoryOnly))
            outFiles.AddRange(Directory.GetFiles(
                            path:=targetPath,
                            searchPattern:="*.log",
                            searchOption:=SearchOption.TopDirectoryOnly))

            If VFSmodZIPfilecounter > 0 Then

                outFiles.AddRange(Directory.GetFiles(
                            path:=targetPath,
                            searchPattern:="*.iwq",
                            searchOption:=SearchOption.TopDirectoryOnly))

            End If

            mylog(LogTxt:=align2strings("Adding file to zip", outFiles.Count))

            addToArchive(
                archiveFullName:=VFSmodZIPfilePaths(VFSmodZIPfilecounter),
                files:=outFiles.ToArray,
                action:=eArchiveAction.Merge)

            Try

                My.Computer.FileSystem.DeleteDirectory(
                    directory:=targetPath,
                    onDirectoryNotEmpty:=FileIO.DeleteDirectoryOption.DeleteAllContents)

                mylog(LogTxt:="     ... OK", Add2PreviousRow:=True)

            Catch ex As Exception
                mylog(LogTxtArray:=parseExceptionMsg(Exception:=ex,
                            LeadingString:=errorLeadingString))
            End Try

#End Region

        Next

        mylog("")
        mylog(LogTxt:=align2strings(
              "Runtime [HH:MM:SS]",
              Math.Round((Now - startTime).TotalHours, digits:=0).ToString("00") & ":" &
              Math.Round((Now - startTime).TotalMinutes, digits:=0).ToString("00") & ":" &
              Math.Round((Now - startTime).TotalSeconds, digits:=0).ToString("00")))

        Return True

    End Function

    ''' <summary>
    ''' ToDo
    ''' </summary>
    ''' <param name="args"></param>
    ''' <returns></returns>
    <DebuggerStepThrough>
    Public Function runMulti(args As String()) As Boolean

        For runCounter As Integer = 1 To args.Count - 1
            runSingle(vfsmPath:=args.First, prjPath:=args(runCounter))
        Next

        Return True

    End Function

#End Region

#Region "    get mitigations from *.owq file"

    ''' <summary>
    ''' Main parser
    ''' </summary>
    ''' <param name="owqPath"></param>
    ''' <param name="mitigation"></param>
    ''' <returns></returns>
    <DebuggerStepThrough>
    Public Function parseOWQ(owqPath As String, ByRef mitigation As mitigationFactors) As Boolean

        Dim owqFile As String() = {}
        Dim dummy As String() = {}

        Dim out As New List(Of Double())
        Dim parameter As New List(Of Double)


        If Not readOWQ(owqPath:=owqPath, owqFile:=owqFile) Then
            Return False
        End If

        dgmres.Add(getDGMRES(owqFile:=owqFile))
        mylog(LogTxt:=align2strings("dgmres (CMP" & dgmres.Count.ToString("00") & ") ", dgmres.Last.ToString(dgmresFormat) & " mg/m²"))

        get_frv(owqFile:=owqFile, mitigation:=mitigation, frv:=frv)
        get_fem(owqFile:=owqFile, mitigation:=mitigation, fem:=fem)
        get_frf_fef(owqFile:=owqFile, mitigation:=mitigation, frf:=frf, fef:=fef)

        Return True

    End Function

#Region "    reduction factors"

    ''' <summary>
    ''' Runoff flux reduction factor (0 - 1, frf)
    ''' 0 = no red. LM: 0.6 for low, 0.8 for high dist.
    ''' </summary>
    <DebuggerStepThrough>
    Public Function get_frf_fef(
                owqFile As String(), ByRef mitigation As mitigationFactors,
                ByRef frf As List(Of Double), ByRef fef As List(Of Double)) As Double


        If frf.Count > mitigation.fluxMitigation.Count Then
            frf.Clear()
            fef.Clear()
        End If

        frf.Add(parseOWQ(searchString:=frfSearch, owqFile:=owqFile))

        If Double.IsNaN(frf.Last) Then
            mylog(LogTxt:=align2strings(errorLeadingString & " fr:ef", "error finding " & frfSearch))
            Return Double.NaN
        End If

        fef.Add(frf.Last)

        mitigation.fluxMitigation.Add(New fluxMitigation)
        mitigation.fluxMitigation.Last.frf = frf.Last
        mitigation.fluxMitigation.Last.fef = fef.Last

        mylog(LogTxt:=align2strings("fr:ef (CMP" & frf.Count.ToString("00") & ") ", frf.Last.ToString(fractionFormat)))

        Return frf.Last

    End Function

    ''' <summary>
    ''' Runoff volume reduction factor (0 - 1, frv)
    ''' 0 = no red. LM: 0.6 for low, 0.8 for high dist.
    ''' </summary>
    <DebuggerStepThrough>
    Public Function get_frv(
                owqFile As String(), ByRef mitigation As mitigationFactors, ByRef frv As Double) As Double

        frv = parseOWQ(searchString:=frvSearch, owqFile:=owqFile)

        If Double.IsNaN(frv) Then
            mylog(LogTxt:=align2strings(errorLeadingString & " frv", "error finding " & frvSearch))
            Return Double.NaN
        End If

        If Not mitigation.frv = stdDblEmpty Then
            If mitigation.frv.ToString(fractionFormat) <> frv.ToString(fractionFormat) Then
                mylog(LogTxt:=align2strings(errorLeadingString & " frv",
                                      mitigation.frv.ToString(fractionFormat)) &
                                                 frv.ToString(fractionFormat))
                Return Double.NaN
            End If
        Else
            mitigation.frv = frv
            mylog(LogTxt:=align2strings(
                 "frv RunOff Volume", frv.ToString(fractionFormat)))
        End If

        Return frv

    End Function

    ''' <summary>
    ''' Erosion mass reduction factor (0 - 1, fem)
    ''' 0 = no red. LM: 0.85 for low, 0.95 for high dist. 
    ''' </summary>
    ''' <param name="owqFile"></param>
    ''' <returns></returns>
    <DebuggerStepThrough>
    Public Function get_fem(
                owqFile As String(), ByRef mitigation As mitigationFactors, ByRef fem As Double) As Double

        fem = parseOWQ(searchString:=femSearch, owqFile:=owqFile)

        If Double.IsNaN(fem) Then
            mylog(LogTxt:=align2strings(errorLeadingString & " fem", "error finding " & femSearch))
            Return Double.NaN
        End If

        If Not mitigation.fem = stdDblEmpty Then
            If mitigation.fem.ToString(fractionFormat) <> fem.ToString(fractionFormat) Then
                mylog(LogTxt:=align2strings(errorLeadingString & " fem",
                                      mitigation.fem.ToString(fractionFormat)) &
                                                 fem.ToString(fractionFormat))
                Return Double.NaN
            End If
        Else
            mitigation.fem = fem
            mylog(LogTxt:=align2strings(
                 "fem Erosion Mass ", fem.ToString(fractionFormat)))
        End If

        Return fem

    End Function

    ''' <summary>
    ''' Not in use!!!
    ''' Infiltration reduction factor (0 - 1, fif)
    ''' 0 = no red. 
    ''' </summary>
    <DebuggerStepThrough>
    Public Function get_fif(
                owqFile As String(), ByRef mitigation As mitigationFactors, ByRef fif As Double) As Double

        fif = parseOWQ(searchString:=fifSearch, owqFile:=owqFile)

        If Double.IsNaN(fif) Then
            mylog(LogTxt:=align2strings(errorLeadingString & " frv", "error finding " & frvSearch))
            Return Double.NaN
        End If

        If Not mitigation.fif = stdDblEmpty Then
            If mitigation.fif <> fif Then
                mylog(LogTxt:=align2strings(errorLeadingString & " fif",
                                      mitigation.fif.ToString("0.0000") & "% <> " &
                                                 fif.ToString("0.0000") & "%"))
                Return Double.NaN
            End If
        Else
            mitigation.fif = fif
            mylog(LogTxt:=padRight("fif ", fif.ToString("0.0000") & "%"))
        End If

        Return frv

    End Function

#End Region

    ''' <summary>
    ''' Next event residue remobilization (mresn, IMOB=1)
    ''' read from last line of *.owq file
    ''' search for 'mg/m2= Next event residue remobilization'
    ''' in mg/m²
    ''' </summary>
    ''' <param name="owqFile">
    ''' string array of the *.owq file to parse
    ''' </param>
    ''' <returns></returns>
    <DebuggerStepThrough>
    Public Function getDGMRES(owqFile As String()) As Double
        Return parseOWQ(searchString:=dgmresSearch, owqFile:=owqFile)
    End Function

#Region "    helper"

    ''' <summary>
    ''' Basic file reader
    ''' check and read owq file
    ''' </summary>
    ''' <param name="owqPath">
    ''' full path to owq file
    ''' </param>
    ''' <param name="owqFile"></param>
    ''' <returns></returns>
    <DebuggerStepThrough>
    Public Function readOWQ(owqPath As String, ByRef owqFile As String()) As Boolean

        Try

            If Not File.Exists(owqPath) Then
                mylog(LogTxt:="owq file doesn't exist")
                Return False
            End If

            owqFile =
                File.ReadAllLines(
                path:=owqPath)

            Return True

        Catch ex As Exception

            mylog(
                LogTxtArray:=
                    parseExceptionMsg(
                        Exception:=ex,
                        UserErrorDescription:=
                            "Can't open" & vbCrLf &
                            owqPath & vbCrLf &
                            "to read results",
                        LeadingString:=errorLeadingString))

            Return False

        End Try

    End Function

    ''' <summary>
    ''' Basic search engine
    ''' </summary>
    ''' <param name="searchString"></param>
    ''' <param name="owqFile"></param>
    ''' <returns></returns>
    '<DebuggerStepThrough>
    Private Function parseOWQ(
                        searchString As String,
                        owqFile As String()) As Double

        Dim index As Integer = -1
        Dim temp As String() = {}
        Dim out As Double = Double.NaN

        'find searchString
        index = Array.FindIndex(
                    array:=owqFile,
                    match:=Function(x)
                               Return x.Contains(searchString)
                           End Function)

        If index = -1 Then

            mylog(
                LogTxt:=
                    "Can't find " & vbCrLf &
                    searchString)

            Return Double.NaN

        Else

            'transform string -> double
            Try

                temp =
                    owqFile(index).Split(
                        separator:={" "c},
                        options:=StringSplitOptions.RemoveEmptyEntries)

                out = CDbl(Trim(temp.First))

            Catch ex As Exception

                mylog(LogTxtArray:=
                        parseExceptionMsg(
                            Exception:=ex,
                            LeadingString:=errorLeadingString))

                If temp.First.Contains("-") AndAlso
                        Not temp.First.ToUpper.Contains("E") AndAlso
                        temp.First.Split("-").Last.Length = 3 Then

                    mylog(LogTxtArray:=
                          {temp.First & " seems to be " & Replace(temp.First, "-", "E-"),
                          "Return '0'"})

                    Return 0
                Else
                    Return Double.NaN
                End If

            End Try

        End If

        Return out

    End Function

#End Region

#End Region

#Region "    helper run zip files"

    ''' <summary>
    ''' write dgmres form last event
    ''' to *.iwq file for this event
    ''' </summary>
    ''' <param name="dgmres"></param>
    ''' <param name="iwqFilePath"></param>
    ''' <returns></returns>
    '<DebuggerStepThrough>
    Private Function writeDGMRES(
                        dgmres As Double,
                        iwqFilePath As String) As Boolean

        Dim iwqFile As String()
        Dim index As Integer = -1
        Dim dummy As String() = {}

        Dim out As New List(Of Double)


        If dgmres > 0 Then

            mylog(LogTxt:=
                    align2strings(
                        first:=dgmres & " mg/m²",
                        last:="dgmres to " & log.shrinkPath(iwqFilePath, front:=2)))

            'read iwq
            Try

                iwqFile =
                        File.ReadAllLines(
                            path:=iwqFilePath)

            Catch ex As Exception

                mylog(LogTxtArray:=
                        parseExceptionMsg(
                            Exception:=ex,
                            UserErrorDescription:=
                                    "Can't read iwq file " & vbCrLf &
                                    iwqFilePath,
                                    LeadingString:=errorLeadingString))

                Return False

            End Try

            'change value in dgmresRow (last entry)
            iwqFile(dgmresRow) =
                    iwqFile(dgmresRow).Substring(
                    startIndex:=0,
                    length:=iwqFile(dgmresRow).Length - dgmresFormat.Length) &
                           " " & dgmres.ToString(dgmresFormat)

            'change explain row
            iwqFile(dgmresRowExplain) = iwqFile(dgmresRow)

            'write iwq
            Try

                File.WriteAllLines(
                        path:=iwqFilePath,
                        contents:=iwqFile)

            Catch ex As Exception

                mylog(
                        LogTxtArray:=
                            parseExceptionMsg(
                            Exception:=ex,
                            UserErrorDescription:=
                                "Can't write dgPin " & dgmres & " mg/m² to " & vbCrLf &
                                iwqFilePath,
                            LeadingString:=errorLeadingString))

                Return False

            End Try

        Else
            mylog(LogTxt:=align2strings(
                      "dgmres = 0, skip changing",
                       log.shrinkPath(iwqFilePath, front:=1, back:=2)))
        End If

        mylog(" ... OK", Add2PreviousRow:=True)

        Return True

    End Function

    <DebuggerStepThrough>
    Private Function getVFSmodZIPfilePaths(ByRef VFSmodZIPfilePaths As String(), targetPath As String) As Boolean

        Try

            mylog(LogTxt:=align2strings(
                  "Searching for zips", log.shrinkPath(targetPath)))

            VFSmodZIPfilePaths = Directory.GetFiles(
                                    path:=targetPath,
                                    searchPattern:="*.zip",
                                    searchOption:=SearchOption.TopDirectoryOnly)

            If IsNothing(VFSmodZIPfilePaths) OrElse VFSmodZIPfilePaths.Count = 0 Then
                mylog(LogTxt:="No zip files found, exit")
                Return True
            Else
                mylog(LogTxt:=align2strings("Zip files to do", VFSmodZIPfilePaths.Count))
            End If

            Array.Sort(VFSmodZIPfilePaths)

        Catch ex As Exception
            mylog(LogTxtArray:=parseExceptionMsg(
                 Exception:=ex, UserErrorDescription:="Error getting zip files",
                    LeadingString:=errorLeadingString))
            Return False
        End Try

        Return True

    End Function

    <DebuggerStepThrough>
    Private Function startLog(VFSmodZIPfilePaths As String(), VFSmodZIPfilecounter As Integer) As Boolean

        Try

            setIntentLevel(IntentLevel:=eLogLevel.init)

            Dim cur As Integer
            If Not bhpc Then
                cur = Console.CursorTop
            End If

            setIntentLevel(IntentLevel:=eLogLevel.up)

            mylog(LogTxt:="")
            mylog(LogTxt:=align2strings(" *** Actual zip file",
                                  (VFSmodZIPfilecounter + 1).ToString("000") & " of " &
                                  (VFSmodZIPfilePaths.Count).ToString("000") &
                                  " '" & Path.GetFileNameWithoutExtension(VFSmodZIPfilePaths(VFSmodZIPfilecounter) & "'")))

        Catch ex As Exception
            mylog(LogTxtArray:=parseExceptionMsg(
                 Exception:=ex, UserErrorDescription:="Error logging",
                    LeadingString:=errorLeadingString))
            Return False
        End Try

        Return True

    End Function

    <DebuggerStepThrough>
    Private Function setTargetPath(ByRef targetPath As String, VFSmodZIPfilePath As String) As Boolean

        Try
            targetPath = VFSmodZIPfilePath.Substring(
                                    startIndex:=0,
                                    length:=VFSmodZIPfilePath.Length - 4)

            mylog(LogTxt:=align2strings("Target Path", log.shrinkPath(targetPath)))

            If Directory.Exists(targetPath) Then

                mylog(LogTxt:=align2strings("exists, deleting ", "      ... "))

                Try

                    My.Computer.FileSystem.DeleteDirectory(
                                        directory:=targetPath,
                                        onDirectoryNotEmpty:=FileIO.DeleteDirectoryOption.DeleteAllContents)

                    mylog(LogTxt:="OK", Add2PreviousRow:=True)

                Catch ex As Exception

                    mylog(
                            LogTxtArray:=
                            parseExceptionMsg(
                                Exception:=ex,
                                UserErrorDescription:=align2strings("IO Error deleting", targetPath),
                                LeadingString:=errorLeadingString))

                    Return False

                End Try

            End If
        Catch ex As Exception
            mylog(LogTxtArray:=parseExceptionMsg(
                 Exception:=ex, UserErrorDescription:="Error setting target path"))
            Return False
        End Try

        Return True

    End Function

    <DebuggerStepThrough>
    Private Function unzipVFSmodPackage(vfsModZipFilePath As String, targetPath As String) As Boolean


        'unzip
        Try

            mylog(LogTxt:=align2strings(
              Path.GetFileName(vfsModZipFilePath),
              "unzip ... "))

            unzip2Path(
                zipFileName:=vfsModZipFilePath,
                TargetPath:=targetPath)

            mylog(LogTxt:="OK", Add2PreviousRow:=True)

        Catch ex As Exception

            mylog(
                LogTxtArray:=
                parseExceptionMsg(
                    Exception:=ex,
                    UserErrorDescription:=
                        "IO Error unzipping" & vbCrLf &
                        targetPath & vbCrLf &
                        " to " & vbCrLf &
                        targetPath,
                    LeadingString:=errorLeadingString))

            Return False

        End Try

        Return True

    End Function


    Public Function writeMitigation2CSV_XML(
                            dateString As String, mitigation As mitigationFactors) As Boolean

        Dim temp As New List(Of String)

        mitigation.convertDateString2Date(dateString:=dateString)

        If header.Count = 0 Then

            header.Add("Date")

            For counter As Integer = 0 To mitigation.fluxMitigation.Count - 1
                header.Add("Pesticide red. CMP" & counter.ToString("00"))
            Next

            header.Add("RunOff Volume red.")
            header.Add("Sediment mass red.")

            For counter As Integer = 0 To dgmres.Count - 1
                header.Add("dgmres CMP" & (counter).ToString("00"))
            Next

            For counter As Integer = 0 To runTimes.Count - 1
                header.Add("runtime CMP" & (counter).ToString("00"))
            Next

        End If

        If units.Count = 0 Then

            units.Add("YYMMDD")

            For counter As Integer = 0 To mitigation.fluxMitigation.Count - 1
                units.Add("%")
            Next

            units.Add("%")
            units.Add("%")

            For counter As Integer = 0 To dgmres.Count - 1
                units.Add("mg/m²")
            Next

            For counter As Integer = 0 To runTimes.Count - 1
                units.Add("mm:ss:ms")
            Next

        End If

        row.Clear()
        row.Add(dateString)

        For counter As Integer = 0 To mitigation.fluxMitigation.Count - 1
            row.Add(mitigation.fluxMitigation(counter).frf.ToString(fractionFormat))
        Next

        row.Add(mitigation.frv.ToString(fractionFormat))
        row.Add(mitigation.fem.ToString(fractionFormat))

        For counter As Integer = 0 To dgmres.Count - 1
            row.Add(dgmres(counter).ToString(dgmresFormat))
        Next

        For counter As Integer = 0 To runTimes.Count - 1
            row.Add(runTimes(counter))
        Next

        rows.Add(Join(SourceArray:=row.ToArray, Delimiter:=","))
        row.Clear()

        temp.Add(Join(SourceArray:=header.ToArray, Delimiter:=","))
        temp.Add(Join(SourceArray:=units.ToArray, Delimiter:=","))
        temp.AddRange(rows)

        mitigations.Add(mitigation)

        Try

            File.WriteAllLines(
                path:=csvFilePath,
                contents:=temp.ToArray)

            serialize(
            targetClass:=mitigations,
            fileName:=Path.ChangeExtension(
                path:=xmlFilePath,
                extension:=".xml"))

        Catch ex As Exception
            Return False
        End Try

        Return True

    End Function


#End Region

#Region "    helper run Single"

    '<DebuggerStepThrough>
    Private Function setArguments(prjPath As String, ByRef startInfo As ProcessStartInfo,
                                  ByRef logOut As List(Of String)) As Boolean

        With startInfo

            If Not File.Exists(Path.Combine(path1:= .WorkingDirectory,
                                            path2:=Path.GetFileName(prjPath))) Then

                mylog(LogTxt:="file not found " & Path.Combine(path1:= .WorkingDirectory,
                                                               path2:=Path.GetFileName(prjPath)))

                Return False

            Else

                .Arguments = Path.GetFileName(prjPath) & " 1"
                logOut.AddRange(
                                {
                                    align2strings("Arguments", log.shrinkPath(.Arguments)),
                                    align2strings("Start", "")
                                })

            End If

        End With

        Return True

    End Function

    <DebuggerStepThrough>
    Private Function runProcess(myProcess As Process, Optional maxWaitTime As Integer = 30) As Boolean

        Dim timeCounter As Integer = 0
        Dim timeStep As Integer = 500

        Try

            With myProcess


                .Start()
                Console.Write(" ".PadLeft(StdTimeStampPattern.Length + 1) & Intent & ".")

                'wait and check responding, incl 'progress bar'
                Do While Not .HasExited

                    'responding ?
                    If Not .Responding Then

                        mylog(LogTxt:=align2strings("", "process not responding"))

                        'wait a bit
                        Threading.Thread.Sleep(millisecondsTimeout:=100)

                        'still not responding
                        If Not .Responding Then

                            If .HasExited Then
                                mylog(LogTxt:=align2strings("", "        has exited"))
                            Else
                                mylog(LogTxt:=align2strings("", "  still not responding"))
                            End If

                            Exit Do

                        End If

                    End If

                    'process bar
                    Console.Write(".")
                    Threading.Thread.Sleep(millisecondsTimeout:=timeStep)

                    timeCounter += 1

                    'timeout
                    If timeCounter = maxWaitTime * 2 * timeStep Then
                        Exit Do
                    End If

                Loop

            End With

        Catch ex As Exception
            mylog(LogTxtArray:=parseExceptionMsg(
                  Exception:=ex, UserErrorDescription:="Error running vfs.exe",
                    LeadingString:=errorLeadingString))
            Return False
        End Try

        Return True

    End Function

    '<DebuggerStepThrough>
    Private Function checkProcess(myProcess As Process) As Boolean

        Try

            With myProcess

                'run ok?
                If Not .HasExited Then

                    If Not bhpc Then resetProgressBar()
                    mylog(LogTxt:="Process didn't finish correctly or in time, try to kill it")

                    Try
                        .Kill()
                    Catch ex As Exception
                        mylog(LogTxtArray:=parseExceptionMsg(
                              Exception:=ex, UserErrorDescription:="Can't kill vfsm.exe"))
                        Return False
                    End Try

                    Return False

                ElseIf .ExitCode <> 0 Then

                    If Not bhpc Then resetProgressBar()
                    mylog(LogTxt:=align2strings(errorLeadingString,
                                   "ExitCode " & .ExitCode & " " &
                                  vfsmexeFileName & " didn't finish correctly"))

                    Dim reader As StreamReader = .StandardError
                    Dim output As String = reader.ReadToEnd()

                    mylog(LogTxt:="StdErrOut")
                    mylog(LogTxtArray:=output.Split(vbCrLf))

                    reader = .StandardOutput
                    output = reader.ReadToEnd

                    runTimes.Add(
                        .TotalProcessorTime.Minutes.ToString("00") & ":" &
                        .TotalProcessorTime.Seconds.ToString("00") & ":" &
                        .TotalProcessorTime.Milliseconds.ToString("00"))



                    Return False

                End If

            End With
        Catch ex As Exception

            mylog(LogTxtArray:=parseExceptionMsg(
                  Exception:=ex, UserErrorDescription:="Error checking vfsm run",
                    LeadingString:=errorLeadingString))
            Return False

        End Try

        Return True

    End Function

    '<DebuggerStepThrough>
    Private Function writeRunTime2Log(myProcess As Process) As Boolean

        Try

            With myProcess

                If Not bhpc Then resetProgressBar()

                mylog(LogTxt:=align2strings("", "Runtime [mm:ss:ms] " &
                        .TotalProcessorTime.Minutes.ToString("00") & ":" &
                        .TotalProcessorTime.Seconds.ToString("00") & ":" &
                        .TotalProcessorTime.Milliseconds.ToString("00")))

                runTimes.Add(
                        .TotalProcessorTime.Minutes.ToString("00") & ":" &
                        .TotalProcessorTime.Seconds.ToString("00") & ":" &
                        .TotalProcessorTime.Milliseconds.ToString("00"))

            End With

        Catch ex As Exception

            mylog(LogTxtArray:=parseExceptionMsg(
                  Exception:=ex, UserErrorDescription:="Error logging runtime",
                    LeadingString:=errorLeadingString))
            Return False

        End Try

        Return True

    End Function

#End Region


#Region "    init and settings"

#Region "    constants"

    Public vfsmexeFileName As String = "vfsm*.exe"

    Public Const errorLeadingString As String = " ***** "

    Public Const dgmresSearch As String = "mg/m2= Next event residue remobilization"
    Public Const dgmresRow As Integer = 4
    Public Const dgmresRowExplain As Integer = 11

    Public Const fifSearch As String = "%  = Infiltration (dQ)"
    Public Const frvSearch As String = "%  = Runoff inflow reduction"
    Public Const femSearch As String = "%  = Sediment reduction (dE)"
    Public Const frfSearch As String = "%  = Pesticide reduction (dP)"

    Public Const processWindowStyle As ProcessWindowStyle =
                                 ProcessWindowStyle.Hidden

    Public Const stdDblEmpty As Double = -1

#End Region

#Region "    csv/xml out element definitions"

    Public csvOut As New List(Of String)

    Public header As New List(Of String)
    Public units As New List(Of String)
    Public row As New List(Of String)
    Public rows As New List(Of String)

    Public runTimes As New List(Of String)

    Public Const dgmresFormat As String = "0.00000E+00"
    Public dgmres As New List(Of Double)

    Public Const fractionFormat As String = "G5"

    ''' <summary>
    ''' Runoff Volume reduction factor (0 - 1, frv)
    ''' </summary>
    Public frv As Double = Double.NaN

    ''' <summary>
    ''' Erosion mass reduction factor (0 - 1, fem)
    ''' </summary>
    Public fem As Double = Double.NaN

    ''' <summary>
    ''' RunOff + Erosion flux reduction factors (0 - 1,frf + fef)
    ''' </summary>
    Public frf As New List(Of Double)

    ''' <summary>
    ''' fef = frf
    ''' </summary>
    Public fef As New List(Of Double)

    Public mitigation As New mitigationFactors
    Public mitigations As New List(Of mitigationFactors)

    Public csvFilePath As String = ""
    Public xmlFilePath As String = ""

#End Region

#Region "    run mode"

    Public Enum eRunMode

        prjSingle
        prjMulti
        directory
        unset

    End Enum

    '<DebuggerStepThrough>
    Public Function getRunMode(ByRef args As String()) As eRunMode

        Dim out As eRunMode

        'check args
        If IsNothing(args) OrElse args.Count = 0 Then
            Return eRunMode.unset
        End If

        'no args, start zip file mode with act. directory
        'bhpc mode or started by dblclick
        If args.Count = 1 Then

            If args.First.EndsWith("VFSmodRunner.exe") Then
                args = {args.First, Environment.CurrentDirectory}
            Else
                Return eRunMode.unset
            End If

        End If

        Try

            If args.Last.EndsWith(".prj") Then

                log.FileName =
                    Path.ChangeExtension(args.Last, ".log")

                If args.Count = 2 Then
                    mylog(LogTxt:="argument ends with '.prj' => single, direct run")
                    out = eRunMode.prjSingle
                Else
                    mylog(LogTxt:="Last argument ends with '.prj' => multi, direct run")
                    out = eRunMode.prjMulti
                End If

            ElseIf args.Count = 2 AndAlso Directory.Exists(args.Last) Then

                If bhpc AndAlso runName <> "" Then
                    log.FileName = Path.Combine(path1:=Environment.CurrentDirectory,
                                                path2:=runName & ".log")
                Else
                    log.FileName =
                        Path.Combine(
                            path1:=args.Last,
                            path2:=args.Last.Split("\").Last) & ".log"
                End If


                mylog(LogTxt:=
                      "2nd argument is a directory => run all *.zip files in that directory")

                out = eRunMode.directory

            Else
                Return eRunMode.unset
            End If

        Catch ex As Exception
            Return eRunMode.unset
        End Try

        csvFilePath = Path.ChangeExtension(path:=log.FileName, ".csv")
        xmlFilePath = Path.ChangeExtension(path:=log.FileName, ".xml")

        Return out

    End Function

#End Region

#End Region

#Region "    common"

    Public errorLogfilename As String = Path.Combine(path1:=Environment.CurrentDirectory,
                                                     path2:="ERROR.LOG")

    ''' <summary>
    ''' get cmd line args
    ''' start logging
    ''' reset lists
    ''' </summary>
    '<DebuggerStepThrough>
    Public Function init() As Boolean

        'get start info
        Try
            mylog(LogTxtArray:=getStartInfo(), Log2File:=False)
            log.padPos = 25
        Catch ex As Exception
            log.FileName = errorLogfilename
            mylog(LogTxtArray:=parseExceptionMsg(Exception:=ex))
            Return False
        End Try

        'bhpc run?
        If Environment.UserName.ToUpper = "SYSTEM" Then
            bhpc = True
            mylog(LogTxt:="BHPC run", Log2File:=False)
        Else
            bhpc = False
            mylog(LogTxt:="Local run", Log2File:=False)
        End If

        'get cmd line arguments
        Try

            args = Environment.GetCommandLineArgs

            If IsNothing(args) OrElse args.Count = 0 Then
                mylog(LogTxt:="No CMD line arguments", Log2File:=False)
                args =
                    {
                    Path.Combine(path1:=Environment.CurrentDirectory,
                                 path2:=My.Application.Info.Title & ".exe")
                    }
            ElseIf args.Count = 2 AndAlso bhpc Then
                runName = args.Last
            Else
                mylog(LogTxt:="CMD line arguments", Log2File:=False)
                mylog(LogTxtArray:=args, Log2File:=False)
            End If

        Catch ex As Exception
            log.FileName = errorLogfilename
            mylog(LogTxtArray:=parseExceptionMsg(Exception:=ex))
            Return False
        End Try

        'adjust dimensions of dosbox
        If Not bhpc Then

            Try
                Console.SetWindowSize(width:=120, height:=50)
            Catch ex As Exception
                log.FileName = errorLogfilename
                mylog(LogTxtArray:=parseExceptionMsg(Exception:=ex))
                Return False
            End Try

        End If

        'get vfsmVersion
        Try

            Dim vfsm As String() = {}

            vfsm = Directory.GetFiles(path:=My.Application.Info.DirectoryPath.ToString,
                                      searchPattern:=vfsmexeFileName,
                                      searchOption:=SearchOption.TopDirectoryOnly)

            If IsNothing(vfsm) OrElse vfsm.Count = 0 Then
                log.FileName = errorLogfilename
                mylog(LogTxt:="Can't find model 'vfsm*.exe'")
                Return False
            End If

            vfsm = Filter(Source:=vfsm,
                          Match:=My.Application.Info.Title & ".exe",
                          Include:=False,
                          Compare:=CompareMethod.Text)

            If vfsm.Count <> 1 Then
                log.FileName = errorLogfilename
                mylog(LogTxt:="Can't find exact model 'vfsm*.exe'")
                mylog(LogTxtArray:=vfsm)
                Return False
            End If


            vfsmexeFileName = vfsm.First

            Dim myProcess As New Process

            With myProcess

                With .StartInfo

                    .FileName = vfsmexeFileName
                    .UseShellExecute = False
                    .RedirectStandardOutput = True
                    .RedirectStandardError = True

                End With

                .Start()

                .WaitForExit(milliseconds:=5 * 1000)

                Dim reader As StreamReader
                Dim output As String

                If .HasExited Then

                    reader = myProcess.StandardOutput
                    output = reader.ReadToEnd()

                    mylog(LogTxt:=Path.GetFileName(.StartInfo.FileName) & " version info",
                          Log2File:=False)

                    mylog(LogTxtArray:=
                          Filter(Source:=output.Split(vbCrLf),
                                 Match:="projectname",
                                 Include:=False,
                                 Compare:=CompareMethod.Text),
                          Log2File:=False)
                Else

                    .Kill()
                    .WaitForExit(milliseconds:=5 * 1000)

                    reader = myProcess.StandardError
                    output = reader.ReadToEnd()

                    log.FileName = errorLogfilename
                    mylog(LogTxtArray:=output.Split(vbCrLf))
                    Environment.ExitCode = 0
                    End

                End If

            End With

        Catch ex As Exception
            log.FileName = errorLogfilename
            mylog(LogTxtArray:=
                  parseExceptionMsg(Exception:=ex,
                                    UserErrorDescription:="Can't find model 'vfsm*.exe'"))
            Return False
        End Try

        'init lists
        runTimes.Clear()
        dgmres.Clear()
        header.Clear()
        units.Clear()
        row.Clear()
        rows.Clear()

        Return True

    End Function


    ''' <summary>
    ''' check/set exe, working dir, windows style
    ''' </summary>
    '<DebuggerStepThrough>
    Public Function createStartInfo(ByRef startInfo As ProcessStartInfo,
                        vfsmPath As String, prjPath As String,
                  ByRef logOut As List(Of String)) As Boolean

        With startInfo

            .FileName =
                Path.Combine(
                path1:=Path.GetDirectoryName(
                        path:=vfsmPath),
                path2:=vfsmexeFileName)

            If Not File.Exists(path:= .FileName) Then

                mylog(LogTxt:=align2strings(
                          "no vfsm*.exe",
                          .FileName))

                Return False

            End If

            .WorkingDirectory = Path.GetDirectoryName(prjPath)
            .UseShellExecute = False
            .RedirectStandardError = True
            .RedirectStandardOutput = True

            If Not Directory.Exists(path:= .WorkingDirectory) Then
                mylog(LogTxt:=align2strings(
                          "no directory",
                          .WorkingDirectory))

                Return False

            End If


            .WindowStyle = ProcessWindowStyle.Hidden

        End With

        Return True

    End Function


    <DebuggerStepThrough>
    Private Sub resetProgressBar()

        Dim temp As Integer

        temp = Console.CursorTop
        clearCurrentConsoleLine()
        temp = Console.CursorTop

    End Sub

    <DebuggerStepThrough>
    Public Sub clearCurrentConsoleLine()
        Dim currentLineCursor As Integer = Console.CursorTop
        Console.SetCursorPosition(0, Console.CursorTop)
        Console.Write(New String(" "c, Console.WindowWidth))
        Console.SetCursorPosition(0, currentLineCursor)
    End Sub

#End Region

End Module


'Public args As String() = {}

'#Region "    run mode"

'Public Enum eRunMode

'    prjSingle
'    prjMulti
'    directory
'    unset

'End Enum


'<DebuggerStepThrough>
'Public Function getRunMode(args As String()) As eRunMode

'    Dim out As eRunMode

'    'check args
'    If IsNothing(args) OrElse args.Count = 0 Then
'        Return eRunMode.unset
'    End If

'    'no args, start zip file mode with act. directory
'    'bhpc mode or started by dblclick
'    If args.Count = 1 Then

'        If args.First.EndsWith("VFSmodRunner.exe") Then
'            args = {args.First, Environment.CurrentDirectory}
'        Else
'            Return eRunMode.unset
'        End If

'    End If

'    Try

'        If args.Last.EndsWith(".prj") Then

'            log.FileName =
'                    Path.ChangeExtension(args.Last, ".log")

'            If args.Count = 2 Then
'                mylog(LogTxt:="argument ends with '.prj' => single, direct run")
'                out = eRunMode.prjSingle
'            Else
'                mylog(LogTxt:="Last argument ends with '.prj' => multi, direct run")
'                out = eRunMode.prjMulti
'            End If

'        ElseIf args.Count = 2 AndAlso Directory.Exists(args.Last) Then

'            log.FileName =
'                    Path.Combine(
'                        path1:=args.Last,
'                        path2:=args.Last.Split("\").Last) & ".log"

'            mylog(LogTxt:=
'                      "2nd argument is a directory => run all *.zip files in that directory")

'            out = eRunMode.directory

'        Else
'            Return eRunMode.unset
'        End If

'    Catch ex As Exception
'        Return eRunMode.unset
'    End Try

'    csvFilePath = Path.ChangeExtension(path:=log.FileName, ".csv")
'    xmlFilePath = Path.ChangeExtension(path:=log.FileName, ".xml")

'    Return out

'End Function

'#End Region
