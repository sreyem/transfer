﻿


Imports System.IO
Imports System.IO.Compression
Imports System.Windows.Forms
Imports System.Xml.Serialization

<DebuggerStepThrough>
Public Module zipTools

    Public Enum eArchiveAction
        Merge
        Replace
        [Error]
        Ignore
    End Enum

    Public Enum eOverwrite
        Always
        IfNewer
        Never
    End Enum

    Public zipLog As New List(Of String)

    Public Function addToArchive(
                ByVal archiveFullName As String,
                ByVal files As String(),
                ByVal Optional action As eArchiveAction = eArchiveAction.Replace,
                ByVal Optional fileOverwrite As eOverwrite = eOverwrite.IfNewer,
                ByVal Optional compression As CompressionLevel = CompressionLevel.Optimal,
                      Optional deleteOrig As Boolean = False) As Boolean

        Dim mode As ZipArchiveMode = ZipArchiveMode.Create
        Dim archiveExists As Boolean = File.Exists(archiveFullName)
        Dim err As Boolean = False

        Select Case action
            Case eArchiveAction.Merge

                If archiveExists Then
                    mode = ZipArchiveMode.Update
                End If

            Case eArchiveAction.Replace

                If archiveExists Then
                    File.Delete(archiveFullName)
                End If

            Case eArchiveAction.[Error]

                If archiveExists Then
                    Throw New IOException(String.Format("The zip file {0} already exists.", archiveFullName))
                End If

            Case eArchiveAction.Ignore

                If archiveExists Then
                    Return True
                End If

            Case Else

        End Select

        Try

            Using archive As ZipArchive = ZipFile.Open(archiveFullName, mode)

                If mode = ZipArchiveMode.Create Then

                    For Each file As String In files

                        If System.IO.File.Exists(file) Then

                            archive.CreateEntryFromFile(
                                file, Path.GetFileName(file), compression)

                            If deleteOrig Then

                                Try

                                    zipLog.Add("Try to delete " &
                                          Path.GetFileName(file).PadRight(10))

                                    IO.File.Delete(file)

                                    If IO.File.Exists(file) Then
                                        zipLog.Add(" ... ERROR, " & IO.File.Exists(file) & " exist")
                                        err = True
                                    Else
                                        zipLog.Add(" ... OK")
                                    End If

                                Catch ex As Exception

                                    zipLog.Add("Can't delete " & Path.GetFileName(file))
                                    zipLog.Add(ex.Message)
                                    Return False

                                End Try

                            End If

                        Else
                            zipLog.Add(file & " does NOT exist ???")
                        End If

                    Next

                Else

                    For Each file As String In files

                        Dim fileInZip = (From f In archive.Entries
                                         Where f.Name = Path.GetFileName(file)
                                         Select f).FirstOrDefault()

                        Select Case fileOverwrite

                            Case eOverwrite.Always

                                If fileInZip IsNot Nothing Then
                                    fileInZip.Delete()
                                End If

                                archive.CreateEntryFromFile(
                                                    sourceFileName:=file,
                                                    entryName:=Path.GetFileName(file),
                                                    compressionLevel:=compression)

                            Case eOverwrite.IfNewer

                                If fileInZip IsNot Nothing Then

                                    If fileInZip.LastWriteTime < System.IO.File.GetLastWriteTime(file) Then
                                        fileInZip.Delete()
                                        archive.CreateEntryFromFile(
                                                    sourceFileName:=file,
                                                    entryName:=Path.GetFileName(file),
                                                    compressionLevel:=compression)
                                    End If

                                Else
                                    archive.CreateEntryFromFile(
                                                    sourceFileName:=file,
                                                    entryName:=Path.GetFileName(file),
                                                    compressionLevel:=compression)
                                End If

                            Case eOverwrite.Never

                            Case Else

                        End Select

                        If deleteOrig Then
                            Try

                                zipLog.Add("Delete " & Path.GetFileName(file).PadLeft(15))
                                System.IO.File.Delete(file)
                                zipLog.Add(" ... OK")

                            Catch ex As Exception

                                zipLog.Add("Can't delete " & Path.GetFileName(file))
                                zipLog.Add(ex.Message)

                            End Try
                        End If

                    Next

                End If

                Return True

            End Using

        Catch ex As Exception

            zipLog.Add("Error during zip process")
            zipLog.Add(ex.Message)

            Return False

        End Try

    End Function


    Public Sub unzip2Path(zipFileName As String, TargetPath As String)

        ZipFile.ExtractToDirectory(
            sourceArchiveFileName:=zipFileName,
            destinationDirectoryName:=TargetPath)

    End Sub

    Public Sub zipPath(
                      Path2Zip As String,
                      zipFilePath As String,
                      Optional compressionLevel As CompressionLevel = CompressionLevel.Optimal,
                      Optional includeBaseDirectory As Boolean = True)

        ZipFile.CreateFromDirectory(
            sourceDirectoryName:=Path2Zip,
            destinationArchiveFileName:=zipFilePath,
            compressionLevel:=compressionLevel,
            includeBaseDirectory:=includeBaseDirectory)

    End Sub

    ''' <summary>
    ''' load zip file entry to string array
    ''' </summary>
    ''' <param name="zipFileName"></param>
    ''' <param name="entryName"></param>
    ''' <returns></returns>
    Public Function loadZip2Array(zipFileName As String, entryName As String) As String()

        Dim temp As String()

        Try

            Using archive As ZipArchive =
                           ZipFile.Open(
                           archiveFileName:=zipFileName,
                           mode:=ZipArchiveMode.Read)

                Dim entry As ZipArchiveEntry =
                archive.GetEntry(entryName:=entryName)

                If IsNothing(entry) Then

                    Throw New ArgumentException(
                        message:="No entry found" & vbCrLf &
                        "Entry    : " & entryName & vbCrLf &
                        "zip file : " & zipFileName)

                End If


                Dim s As String = ""
                Using sr As StreamReader = New StreamReader(entry.Open())

                    s = sr.ReadToEnd()
                    temp = s.Split(vbCrLf)

                End Using

            End Using

        Catch ex As Exception
            Throw New IOException(message:="Error getting file array out of zip file" & vbCrLf &
                                  "zip file name : " & zipFileName & vbCrLf &
                                  "entry    name : " & entryName & vbCrLf &
                                  ex.Message)
        End Try



        Return temp

    End Function



    Public Function serialize(
                             targetClass As Object,
                    Optional fileName As String = Nothing) As String

        Dim mySaveFileDialog As New SaveFileDialog

        With mySaveFileDialog

#Region "            SaveFileDialog settings"

            .Filter =
                    "XML files (*.xml)|*.xml|" &
                    "Binary files (*.soap)|*.soap|" &
                    "JSON files (*.json)|*.json|" &
                    "All files (*.*)|*.*"

            .FilterIndex = 0

            .AddExtension = True
            .AutoUpgradeEnabled = True

            .CheckFileExists = False
            .CheckPathExists = True

            .CreatePrompt = False
            .OverwritePrompt = True

#End Region

            If Not IsNothing(fileName) Then
                .FileName = fileName
            Else
                'get filename
                If .ShowDialog <> DialogResult.OK Then
                    Return " Save canceled by user"
                End If
            End If

            Select Case Path.GetExtension(.FileName).ToLower

                Case ".xml"

                    Dim myWriter As IO.StreamWriter = Nothing

                    Try

                        Dim mySerializer As XmlSerializer =
                                New XmlSerializer(targetClass.GetType)

                        myWriter = New IO.StreamWriter(.FileName)

                        mySerializer.Serialize(
                                textWriter:=myWriter,
                                o:=targetClass)

                    Catch ex As Exception

                        Return "Error serializing (saving) class " &
                                ex.Message

                    Finally
                        myWriter.Close()
                        myWriter = Nothing
                    End Try

                Case ".soap"

                    'Dim formatter As IFormatter = Nothing
                    'Dim fileStream As FileStream = Nothing

                    'Try

                    '    fileStream =
                    '            New FileStream(
                    '        path:= .FileName,
                    '        mode:=FileMode.Create,
                    '      access:=FileAccess.Write)

                    '    formatter =
                    '            New Formatters.Binary.BinaryFormatter

                    '    formatter.Serialize(
                    '                serializationStream:=fileStream,
                    '                              graph:=targetClass)

                    'Catch ex As Exception
                    '    Return "Error serializing to SOAP " & ex.Message
                    'Finally

                    '    If fileStream IsNot Nothing Then
                    '        fileStream.Close()
                    '    End If

                    'End Try

                Case ".json"

                    'Try

                    '    Dim serializer As New JavaScriptSerializer

                    '    Dim serializedResult =
                    '            serializer.Serialize(targetClass)

                    '    serializedResult =
                    '            New JSONFormatter(json:=serializedResult).Format

                    '    File.WriteAllText(
                    '            path:= .FileName,
                    '            contents:=serializedResult)

                    '    Return True

                    'Catch ex As Exception
                    '    Return "Error serializing to JSON " & ex.Message
                    'End Try

            End Select

            Return "OK : Serializing class to file " & .FileName

        End With

        Return False

    End Function


End Module

