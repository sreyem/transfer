﻿


Imports System.ComponentModel
Imports System.Globalization
Imports System.Reflection
Imports System.Web.Script.Serialization
Imports System.Xml.Serialization

<Serializable>
Public Class mitigationFactors

    Public Sub New()

    End Sub

    Public Sub New(dateString As String)
        convertDateString2Date(dateString:=dateString)
    End Sub

    Public Sub convertDateString2Date(dateString As String)

        Try

            Me.eventDate =
                New Date(
                    year:=1900 + CInt(dateString.Substring(0, 2)),
                    month:=CInt(dateString.Substring(2, 2)),
                    day:=CInt(dateString.Substring(4, 2)))

        Catch ex As Exception

        End Try

    End Sub

#Region "    methods"

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _eventDate As New Date

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _frv As Double = stdDblEmpty

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _fem As Double = stdDblEmpty

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _fif As Double = stdDblEmpty

#End Region

    ''' <summary>
    ''' Date of event
    ''' </summary>
    <Category()>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
    "Date")>
    <Description(
    "Date of event" & vbCrLf &
    "")>
    <Browsable(True)>
    <[ReadOnly](True)>
    Public Property eventDate As Date
        Get
            Return _eventDate
        End Get
        Set
            _eventDate = Value
        End Set
    End Property


    ''' <summary>
    ''' Runoff Volume reduction factor (0 - 1, frv)
    ''' 0 = no red. LM: 0.6 for low, 0.8 for high dist.
    ''' </summary>
    <Category()>
    <DisplayName("frv RunOff  Volume")>
    <Description("Runoff volume reduction factor (0 - 1, frv)" & vbCrLf &
                 "0 = no red. LM: 0.6 for low, 0.8 for high dist.")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(stdDblEmpty)>
    Public Property frv As Double
        Get
            Return _frv
        End Get
        Set
            _frv = Value
        End Set
    End Property


    ''' <summary>
    ''' Erosion mass reduction factor (0 - 1, fem)
    ''' 0 = no red. LM: 0.85 for low, 0.95 for high dist.
    ''' </summary>
    <Category()>
    <DisplayName("fem Erosion Mass")>
    <Description("Erosion mass reduction factor (0 - 1, fem)" & vbCrLf &
                 "0 = no red. LM: 0.85 for low, 0.95 for high dist.")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(stdDblEmpty)>
    Public Property fem As Double
        Get
            Return _fem
        End Get
        Set
            _fem = Value
        End Set
    End Property

    Public fluxMitigation As New List(Of fluxMitigation)

    ''' <summary>
    ''' RunOff/Erosion Flux
    ''' RunOff / Erosion flux reduction factors (0 - 1,frf / fef)
    ''' </summary>
    ''' <returns></returns>
    <DisplayName("RunOff/Erosion Flux")>
    <Description("RunOff & Erosion flux reduction factors (0 - 1,frf & fef)" & vbCrLf &
                 "0 = no red. LM: 0.6 for low, 0.8 for high dist.")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <XmlIgnore> <ScriptIgnore>
    Public Property fluxMitigationGUI As fluxMitigation()
        Get
            Return fluxMitigation.ToArray
        End Get
        Set(value As fluxMitigation())

            fluxMitigation.Clear()
            fluxMitigation.AddRange(value)

        End Set
    End Property

#Region "    not used"

    ''' <summary>
    ''' fif Infiltration
    ''' Infiltration reduction factor (0 - 1, fif)
    ''' </summary>
    <Category()>
    <DisplayName("Infiltration")>
    <Description("Infiltration reduction factor (0 - 1, fif)" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(False)>
    <[ReadOnly](False)>
    <DefaultValue(stdDblEmpty)>
    Public Property fif As Double
        Get
            Return _fif
        End Get
        Set
            _fif = Value
        End Set
    End Property

#End Region

End Class

''' <summary>
''' flux mitigation Erosion and RunOff
''' </summary>
<Serializable>
Public Class fluxMitigation

    Public Sub New()

    End Sub

    ''' <summary>
    '''  Constructor with parameters
    ''' </summary>
    ''' <param name="fef">
    ''' Erosion flux reduction factor (0 - 1, fef)
    ''' </param>
    ''' <param name="frf">
    ''' Runoff flux reduction factor (0 - 1, frf)
    ''' </param>
    Public Sub New(
                  fef As Double,
                  frf As Double)

        Me.fef = fef
        Me.frf = frf

    End Sub

    <Browsable(False)>
    Public ReadOnly Property name As String
        Get
            Return "Runoff  frf := " & Me.frf.ToString("G4") & "".PadLeft(20) & vbCrLf &
                   "Erosion fef := " & Me.fef.ToString("G4")
        End Get
    End Property

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _fef As Double = stdDblEmpty

    ''' <summary>
    ''' fef Erosion Flux
    ''' Erosion flux reduction factor (0 - 1, fef)
    ''' 0 = no red. LM: 0.85 for low, 0.95 for high dist.
    ''' </summary>
    <DisplayName("fef Erosion")>
    <Description("Erosion flux reduction factor (0 - 1, fef)" & vbCrLf &
                 "0 = no red. LM: 0.6 for low, 0.8 for high dist.")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(stdDblEmpty)>
    Public Property fef As Double
        Get
            Return _fef
        End Get
        Set
            _fef = Value
        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _frf As Double = stdDblEmpty

    ''' <summary>
    ''' frf RunOff Flux METXX
    ''' Runoff flux reduction factor (0 - 1, frf)
    ''' 0 = no red. LM: 0.6 for low, 0.8 for high dist.
    ''' </summary>
    <Category()>
    <DisplayName("frf Runoff")>
    <Description("Runoff flux reduction factor (0 - 1, frf)" & vbCrLf &
                 "0 = no red. LM: 0.6 for low, 0.8 for high dist.")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(stdDblEmpty)>
    Public Property frf As Double
        Get
            Return _frf
        End Get
        Set
            _frf = Value
        End Set
    End Property

End Class

