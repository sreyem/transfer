﻿Public Module alignstring


#Region "    pad left/right"

    Public padPos As Integer = 15
    Public padDelimiter As String = " : "
    Public leadingString As String = ""
    Public toConsole As Boolean = False
    Public filler As String = " "

    ''' <summary>
    ''' enum for water body depth
    ''' </summary>
    Public Enum eAlignLeftRight

        ''' <summary>
        ''' no align
        ''' </summary>
        not_defined = -1

        ''' <summary>
        ''' align left, fill right with 'filler' till 'padPos'
        ''' </summary>
        left

        ''' <summary>
        ''' align right, fill left with 'filler' till 'padPos'
        ''' </summary>
        right

    End Enum


    Public Function align2strings(
                           first As String,
                           last As String(),
                           Optional alignLeftRight As eAlignLeftRight = eAlignLeftRight.left,
                           Optional padPos As Integer = -1,
                           Optional padDelimiter As String = Nothing,
                           Optional toConsole As Boolean = False,
                           Optional leadingString As String = Nothing,
                           Optional filler As String = Nothing,
                           Optional maxLength As Integer = -1) As String()


        Dim out As New List(Of String)
        out.Add(align2strings(first:=first, last:=last.First,
                              alignLeftRight:=alignLeftRight,
                              padPos:=padPos, padDelimiter:=padDelimiter,
                              toConsole:=toConsole, leadingString:=leadingString, filler:=filler,
                              maxLength:=maxLength))

        For counter As Integer = 1 To last.Count - 1

            out.Add(align2strings(first:="", last:=last(counter),
                              alignLeftRight:=alignLeftRight,
                              padPos:=padPos, padDelimiter:=filler.PadLeft(totalWidth:=padDelimiter.Length),
                              toConsole:=toConsole, leadingString:=leadingString, filler:=filler,
                              maxLength:=maxLength))

        Next

        Return out.ToArray

    End Function


    ''' <summary>
    ''' fill left or right ('leadingString' + 'first') with 'filler' to padPos 
    ''' add padDelimiter
    ''' leadingString + first.Pad(padPos - leadingString.Length) + padDelimiter + last 
    ''' </summary>
    ''' <param name="first">
    ''' string on the left of padDelimiter
    ''' </param>
    ''' <param name="last">
    ''' string on the right of padDelimiter
    ''' </param>
    ''' <param name="alignLeftRight">
    ''' alignment left or right of the first string
    ''' std. = left
    ''' </param>
    ''' <param name="padPos">
    ''' position of the padDelimiter, std. = 15
    ''' </param>
    ''' <param name="padDelimiter">
    ''' delimiter between left and right string
    ''' std.  = ' : '
    ''' </param>
    ''' <param name="toConsole">
    ''' keep log intend level in mind
    ''' </param>
    ''' <param name="leadingString">
    ''' string to add in front of first string
    ''' std. =''
    ''' </param>
    ''' <param name="filler">
    ''' string to align the first string with
    ''' std. = ' '
    ''' </param>
    ''' <param name="maxLength">
    ''' cut resulting string to maxLength
    ''' std. = -1 = no cut
    ''' </param>
    ''' <returns>
    ''' nicely aligned string ;-)
    ''' </returns>
    <DebuggerStepThrough>
    Public Function align2strings(
                           first As String,
                           last As String,
                           Optional alignLeftRight As eAlignLeftRight = eAlignLeftRight.left,
                           Optional padPos As Integer = -1,
                           Optional padDelimiter As String = Nothing,
                           Optional toConsole As Boolean = False,
                           Optional leadingString As String = Nothing,
                           Optional filler As String = Nothing,
                           Optional maxLength As Integer = -1) As String

        first = leadingString & first

        If padPos = -1 Then padPos = log.padPos
        If IsNothing(padDelimiter) Then padDelimiter = alignstring.padDelimiter
        If IsNothing(leadingString) Then leadingString = alignstring.leadingString
        If IsNothing(filler) Then filler = alignstring.filler
        If toConsole Then padPos -= Intent.Length

        Dim out As String

        Try

            Select Case alignLeftRight

                Case eAlignLeftRight.left

                    out = leadingString &
                           first.PadRight(totalWidth:=padPos - leadingString.Length,
                                          paddingChar:=filler) &
                           padDelimiter &
                           last

                Case eAlignLeftRight.right

                    out = leadingString &
                           first.PadLeft(totalWidth:=padPos - leadingString.Length,
                                          paddingChar:=filler) &
                           padDelimiter &
                           last

                Case Else

                    out = leadingString &
                           first &
                           padDelimiter &
                           last

            End Select

        Catch ex As Exception
            Return ex.Message
        End Try

        If maxLength <> -1 AndAlso out.Length > maxLength Then
            out = out.Substring(0, maxLength)
        End If

        Return out

    End Function

    ''' <summary>
    ''' cuts a combined/aligned string at padDelimiter
    ''' </summary>
    ''' <param name="string2cut">
    ''' the orig. string
    ''' </param>
    ''' <param name="padDelimiter">
    ''' delimiter between left and right string
    ''' std.  = ' : '
    ''' </param>
    ''' <param name="leadingString">
    ''' string to add in front of first string
    ''' std. =''
    ''' </param>
    ''' <param name="filler">
    ''' string to align the first string with
    ''' std. = ' '
    ''' </param>
    ''' <returns>two strings as array</returns>
    Public Function cut2strings(string2cut As String,
                                Optional padDelimiter As String = Nothing,
                                Optional leadingString As String = Nothing,
                                Optional filler As String = Nothing) As String()

        If IsNothing(padDelimiter) Then padDelimiter = alignstring.padDelimiter
        If IsNothing(leadingString) Then leadingString = alignstring.leadingString
        If IsNothing(filler) Then filler = alignstring.filler

        Dim first As String = ""
        Dim last As String = ""

        Dim temp As String() = {}
        Try

            temp = Split(Expression:=string2cut,
                         Delimiter:=padDelimiter,
                         Compare:=CompareMethod.Text)

            If temp.Count <> 2 Then

                Throw New ArgumentException(
                    message:=
                    "More than on delimiter in string" & vbCrLf &
                    "padDelimiter = " & padDelimiter & vbCrLf &
                    "target string = " & string2cut)

            End If

        Catch ex As Exception
            Throw New ArgumentException(
                message:="Unknown ERROR during 'cut2strings' split",
                innerException:=ex)
        End Try

        last = Trim(str:=temp.Last)

        first = temp.First

        Try
            If leadingString <> "" Then
                first = first.Substring(startIndex:=leadingString.Length,
                                        length:=first.Length - leadingString.Length)
            End If
        Catch ex As Exception
            Throw New ArgumentException(
                message:="Unknown ERROR during 'cut2strings' ignore leading string",
                innerException:=ex)
        End Try

        Try
            If filler <> " " Then
                first = Replace(Expression:=first,
                                Find:=filler,
                                Replacement:="",
                                Compare:=CompareMethod.Text)
            End If
        Catch ex As Exception
            Throw New ArgumentException(
                message:="Unknown ERROR during 'cut2strings' replace 'filler'",
                innerException:=ex)
        End Try


        Return {first, last}

    End Function

    <DebuggerStepThrough>
    Public Function shrinkPath(
                              origPath As String,
                     Optional front As Integer = 2,
                     Optional back As Integer = 2, Optional filler As String = "...") As String

        Dim orig As String() = {}
        Dim out As New List(Of String)

        orig = origPath.Split(System.IO.Path.DirectorySeparatorChar)

        If IsNothing(orig) OrElse
            orig.Count = 0 OrElse orig.Count <= front + back Then Return origPath

        If front < 1 Then front = 1

        For counter As Integer = 0 To front - 1
            out.Add(orig(counter))
        Next

        out.Add(filler)
        If orig.Count > 2 * front + 2 * back Then
            out.Add(filler)
        End If

        For counter As Integer = orig.Count - 1 - back + 1 To orig.Count - 1
            out.Add(orig(counter))
        Next

        Return Join(SourceArray:=out.ToArray, Delimiter:=System.IO.Path.DirectorySeparatorChar)

    End Function

#End Region



End Module
