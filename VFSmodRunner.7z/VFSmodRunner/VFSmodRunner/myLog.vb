﻿
Imports System.Globalization
Imports System.IO
Imports System.Management
Imports System.Windows.Forms
Imports Microsoft.Win32

<DebuggerStepThrough()>
Public Module log

#Region "Settings"

    ''' <summary>
    ''' Contend of the log
    ''' </summary>
    ''' <remarks></remarks>
    Public LogList As New List(Of String)

    ''' <summary>
    ''' Log Filename
    ''' </summary>
    ''' <remarks></remarks>
    Public FileName As String = ""

    Public Enum eLogLevel

        std = -1

        init = 0

        one
        two
        three

        up
        down

    End Enum

    ''' <summary>
    ''' Intent level
    ''' </summary>
    ''' <remarks></remarks>
    Public stdIntentLevel As eLogLevel = eLogLevel.init

    ''' <summary>
    ''' No of spaces per intent level
    ''' </summary>
    ''' <remarks></remarks>
    Public IntentSpacePerLevel As Integer = 3


    Public FirstIntentChar As Char = "|"c

    ''' <summary>
    ''' std. time stamp at the start of the log line
    ''' </summary>
    ''' <remarks></remarks>
    Public Const StdTimeStampPattern As String = "hh:mm"

    Public Enum eLog2Console
        Yes
        No
        Only
    End Enum

    'Public FilenameOK As Boolean = False

    Public listBox As ListBox = Nothing

#End Region

#Region "Log and friends"

    Public padPos As Integer = 15
    Public padDelimiter As String = ": "

    ''' <summary>
    ''' align log text to the left
    ''' </summary>
    ''' <param name="first">
    ''' first part
    ''' </param>
    ''' <param name="last">
    ''' last part
    ''' </param>
    <DebuggerStepThrough>
    Public Function padLeft(
                           first As String,
                           last As String,
                           Optional padPos As Integer = 15,
                           Optional padDelimiter As String = " : ") As String

        Dim out As String

        If padPos <> log.padPos Then padPos = log.padPos
        padPos -= Intent.Length
        If padDelimiter <> log.padDelimiter Then padDelimiter = log.padDelimiter

        Try
            out = first.PadRight(padPos) & padDelimiter & last
            Return first.PadRight(padPos) & padDelimiter & last
        Catch ex As Exception
            Return first & padDelimiter & last
        End Try


    End Function

    ''' <summary>
    ''' align log text to the left
    ''' </summary>
    ''' <param name="first">
    ''' first part
    ''' </param>
    ''' <param name="last">
    ''' last part
    ''' </param>
    <DebuggerStepThrough>
    Public Function padRight(
                           first As String,
                           last As String,
                           Optional padPos As Integer = 15,
                           Optional padLeftDelimiter As String = " : ") As String

        If padPos <> log.padPos Then padPos = log.padPos
        padPos -= Intent.Length
        If padLeftDelimiter <> log.padDelimiter Then padLeftDelimiter = log.padDelimiter

        Return first.PadLeft(padPos) & padLeftDelimiter & last

    End Function


    '<DebuggerStepThrough>
    Public Function shrinkPath(
                              origPath As String,
                     Optional front As Integer = 2,
                     Optional back As Integer = 2, Optional filler As String = "...") As String

        Dim orig As String() = {}
        Dim out As New List(Of String)

        orig = origPath.Split(Path.DirectorySeparatorChar)

        If IsNothing(orig) OrElse
            orig.Count = 0 OrElse orig.Count <= front + back Then Return origPath

        For counter As Integer = 0 To front
            out.Add(orig(counter))
        Next

        out.Add(filler)
        If orig.Count > 2 * front + 2 * back Then
            out.Add(filler)
        End If

        For counter As Integer = orig.Count - 1 - back + 1 To orig.Count - 1
            out.Add(orig(counter))
        Next

        Return Join(SourceArray:=out.ToArray, Delimiter:=Path.DirectorySeparatorChar)

    End Function

    Public Intent As String = " "

    ''' <summary>
    ''' log simple one line msg
    ''' </summary>
    ''' <param name="LogTxt">
    ''' Log msg as one line
    ''' </param>
    ''' <param name="IntentLevel">
    ''' Intent level as enum
    ''' std, init, on, two, three, up, down
    ''' </param>
    ''' <param name="Log2Console">
    ''' Log also to console, std. = on
    ''' </param>
    ''' <param name="Log2File">
    ''' Write log instantaneously to file, std. = on
    ''' </param>
    ''' <param name="Log2Msgbox">
    ''' Log also to MsgBox, std. = false
    ''' </param>
    ''' <param name="MsgBoxBtn">
    ''' If Log2MsgBox = true => Button
    ''' </param>
    ''' <param name="MsgTitle">
    ''' If Log2MsgBox = true => MsgTitle
    ''' ></param>
    ''' <param name="Add2PreviousRow">
    ''' If true log will be append to prev. row, std. = false
    ''' </param>
    ''' <param name="TimeStampPattern">
    ''' Std. = "hh:mm"
    ''' </param>
    ''' <param name="Exception2Throw">
    ''' Throw this exception
    ''' </param>
    ''' <param name="ShowInNotepad">
    ''' Show complete Log in Notepad, std. = false
    ''' </param>
    ''' <returns>
    ''' MsgBoxResult, like Yes, No or Cancel
    ''' </returns>
    Function mylog(
                LogTxt As String,
                Optional IntentLevel As eLogLevel = eLogLevel.std,
                Optional Log2Console As eLog2Console = eLog2Console.Yes,
                Optional Log2File As Boolean = True,
                Optional Log2MsgBox As Boolean = False,
                Optional MsgBoxBtn As MsgBoxStyle = MsgBoxStyle.Exclamation,
                Optional MsgTitle As String = "",
                Optional Add2PreviousRow As Boolean = False,
                Optional TimeStampPattern As String = "std",
                Optional Exception2Throw As Exception = Nothing,
                Optional ShowInNotepad As Boolean = False) As MsgBoxResult

        Dim TempList As New List(Of String)
        Dim TimeStamp As String



        If Not IsNothing(Exception2Throw) Then

            If LogTxt <> String.Empty Then LogTxt &= vbCrLf

            LogTxt &= Join(parseExceptionMsg(
                                    Exception:=Exception2Throw,
                         UserErrorDescription:=LogTxt),
                                    Delimiter:=vbCrLf)

        End If

        Select Case IntentLevel

            Case eLogLevel.std
                IntentLevel = stdIntentLevel

            Case eLogLevel.init
                stdIntentLevel = IntentLevel

            Case eLogLevel.up

                If stdIntentLevel = eLogLevel.std Then IntentLevel = eLogLevel.one
                If stdIntentLevel = eLogLevel.init Then IntentLevel = eLogLevel.one
                If stdIntentLevel = eLogLevel.one Then IntentLevel = eLogLevel.two
                If stdIntentLevel = eLogLevel.two Then IntentLevel = eLogLevel.three
                stdIntentLevel = IntentLevel

            Case eLogLevel.down

                If stdIntentLevel = eLogLevel.init Then IntentLevel = eLogLevel.std
                If stdIntentLevel = eLogLevel.one Then IntentLevel = eLogLevel.std
                If stdIntentLevel = eLogLevel.two Then IntentLevel = eLogLevel.one
                If stdIntentLevel = eLogLevel.three Then IntentLevel = eLogLevel.two
                stdIntentLevel = IntentLevel

        End Select

        Select Case IntentLevel

            Case eLogLevel.init
                Intent = " "

            Case eLogLevel.one
                Intent = " " & FirstIntentChar.ToString.PadRight(IntentSpacePerLevel)

            Case eLogLevel.two
                Intent = " " & FirstIntentChar.ToString.PadRight(IntentSpacePerLevel) &
                               FirstIntentChar.ToString.PadRight(IntentSpacePerLevel)

            Case eLogLevel.three
                Intent = " " & FirstIntentChar.ToString.PadRight(IntentSpacePerLevel) &
                               FirstIntentChar.ToString.PadRight(IntentSpacePerLevel) &
                               FirstIntentChar.ToString.PadRight(IntentSpacePerLevel)

        End Select


        Dim Lastlines As New List(Of String)

        Dim Txt2Log As String = ""

        'format time stamp + log level
        If TimeStampPattern = "std" Then
            TimeStampPattern = StdTimeStampPattern
        End If

        If TimeStampPattern = "" Then
            TimeStamp = " "
        Else
            TimeStamp = Now.ToString(StdTimeStampPattern) & " "
        End If

        'multi row log text without repeating time stamp
        If LogTxt.Contains(vbCrLf) OrElse
           LogTxt.Contains(vbLf) Then

            TempList.Clear()
            TempList.AddRange(LogTxt.Split(CChar(vbCrLf)))

            '1st row with time stamp
            'add to prev. row ?
            If Add2PreviousRow Then

                Txt2Log = Replace(
                            Expression:="".PadLeft(TimeStamp.Length) & Intent & TempList.First,
                                  Find:=vbCrLf,
                           Replacement:="")

            Else

                Txt2Log = Replace(
                            Expression:=TimeStamp & Intent & TempList.First,
                                  Find:=vbCrLf,
                           Replacement:="")

                Txt2Log = Replace(
                            Expression:=Txt2Log,
                                  Find:=vbLf,
                           Replacement:="")

            End If



            If Log2Console = eLog2Console.Only Then
                Console.WriteLine(Txt2Log)
            Else
                Console.WriteLine(Txt2Log)
                LogList.Add(Txt2Log)
            End If

            'all others without
            For counter As Integer = 1 To TempList.Count - 1

                Txt2Log = Replace(
                    Expression:=TempList(counter),
                          Find:=vbLf,
                   Replacement:="")


                If TimeStampPattern <> "" Then

                    Txt2Log = "".PadLeft(TimeStamp.Length) & Intent &
                    Txt2Log

                End If

                'log 2 console
                Select Case Log2Console

                    Case eLog2Console.Yes

                        Console.WriteLine(Txt2Log)
                        LogList.Add(Txt2Log)

                    Case eLog2Console.Only

                        Console.WriteLine(Txt2Log)

                    Case eLog2Console.No
                        LogList.Add(Txt2Log)

                End Select

            Next

        Else

            'single row log text
            If Add2PreviousRow Then
                LogList(LogList.Count - 1) = LogList.Last & LogTxt
            Else
                If TimeStampPattern = "" Then
                    LogList.Add(Intent & LogTxt)
                Else
                    LogList.Add(TimeStamp & Intent & LogTxt)
                End If
            End If

            'log 2 console
            Select Case Log2Console

                Case eLog2Console.Yes, eLog2Console.Only
                    Try
                        If Add2PreviousRow Then Console.CursorTop = Console.CursorTop - 1
                    Catch ex As Exception

                    End Try

                    Console.WriteLine(LogList(LogList.Count - 1))
                    'LogList.Add(LogTxt)

                Case eLog2Console.No

            End Select

        End If

        Try

            If Log2File Then

                File.WriteAllLines(path:=FileName,
                           contents:=LogList.ToArray)

            End If

            Try
                If ShowInNotepad Then ShowLogInNotepad()
            Catch ex As Exception

                Throw New ArgumentException(message:="Can't show log file in editor" & vbCrLf & FileName,
                                innerException:=ex)

            End Try

        Catch ex As Exception

            Throw New ArgumentException(message:="Can't write to log file" & vbCrLf & FileName,
                                innerException:=ex)

        End Try

        If Not IsNothing(listBox) Then
            listBox.DataSource = Nothing
            listBox.DataSource = LogList
            listBox.SelectedIndex = listBox.Items.Count - 1
            listBox.Refresh()
        End If

        If Not IsNothing(Exception2Throw) Then
            Throw New ArgumentException(
                       message:=LogTxt,
                innerException:=Exception2Throw)
        End If

        If Log2MsgBox Then

            Return MsgBox(Prompt:=LogTxt,
                         Buttons:=MsgBoxBtn,
                           Title:=MsgTitle)

        End If

        Return MsgBoxResult.Ok

    End Function

    Public Sub setIntentLevel(IntentLevel As eLogLevel)

        Select Case IntentLevel

            Case eLogLevel.std
                IntentLevel = stdIntentLevel

            Case eLogLevel.init
                stdIntentLevel = IntentLevel

            Case eLogLevel.up

                If stdIntentLevel = eLogLevel.std Then IntentLevel = eLogLevel.one
                If stdIntentLevel = eLogLevel.init Then IntentLevel = eLogLevel.one
                If stdIntentLevel = eLogLevel.one Then IntentLevel = eLogLevel.two
                If stdIntentLevel = eLogLevel.two Then IntentLevel = eLogLevel.three
                stdIntentLevel = IntentLevel

            Case eLogLevel.down

                If stdIntentLevel = eLogLevel.init Then IntentLevel = eLogLevel.std
                If stdIntentLevel = eLogLevel.one Then IntentLevel = eLogLevel.std
                If stdIntentLevel = eLogLevel.two Then IntentLevel = eLogLevel.one
                If stdIntentLevel = eLogLevel.three Then IntentLevel = eLogLevel.two
                stdIntentLevel = IntentLevel

        End Select

        Select Case IntentLevel

            Case eLogLevel.init
                Intent = " "

            Case eLogLevel.one
                Intent = " " & FirstIntentChar.ToString.PadRight(IntentSpacePerLevel)

            Case eLogLevel.two
                Intent = " " & FirstIntentChar.ToString.PadRight(IntentSpacePerLevel) &
                               FirstIntentChar.ToString.PadRight(IntentSpacePerLevel)

            Case eLogLevel.three
                Intent = " " & FirstIntentChar.ToString.PadRight(IntentSpacePerLevel) &
                               FirstIntentChar.ToString.PadRight(IntentSpacePerLevel) &
                               FirstIntentChar.ToString.PadRight(IntentSpacePerLevel)

        End Select

    End Sub

    ''' <summary>
    ''' Log array of strings
    ''' </summary>
    ''' <param name="LogTxtArray">
    ''' Array of strings to log
    ''' </param>
    ''' <param name="IntentLevel">
    ''' Intent level as enum
    ''' std,init,on,two,three,up,down
    ''' </param>
    ''' <param name="Log2Console">
    ''' Log also to console, std. = on
    ''' </param>
    ''' <param name="Log2File">
    ''' Write log instantaneously to file, std. = on
    ''' </param>
    ''' <param name="Log2Msgbox">
    ''' Log also to MsgBox, std. = false
    ''' </param>
    ''' <param name="MsgBoxBtn">
    ''' If Log2MsgBox = true => Button
    ''' </param>
    ''' <param name="MsgTitle">
    ''' If Log2MsgBox = true => MsgTitle
    ''' ></param>
    ''' <param name="Add2PreviousRow">
    ''' If true log will be append to prev. row, std. = false
    ''' </param>
    ''' <param name="TimeStampPattern">
    ''' Std. = "hh:mm"
    ''' </param>
    ''' <param name="Exception2Throw">
    ''' Throw this exception
    ''' </param>
    ''' <param name="ShowInNotepad">
    ''' Show complete Log in Notepad, std. = false
    ''' </param>
    ''' <returns></returns>
    Public Function mylog(
                        LogTxtArray As String(),
                        Optional IntentLevel As eLogLevel = eLogLevel.std,
                        Optional Log2Console As eLog2Console = eLog2Console.Yes,
                        Optional Log2File As Boolean = True,
                        Optional Log2MsgBox As Boolean = False,
                        Optional MsgBoxBtn As MsgBoxStyle = MsgBoxStyle.Exclamation,
                        Optional MsgTitle As String = "",
                        Optional Add2PreviousRow As Boolean = False,
                        Optional TimeStampPattern As String = "std",
                        Optional Exception2Throw As Exception = Nothing,
                        Optional ShowInNotepad As Boolean = False) As MsgBoxResult

        Return mylog(
                    LogTxt:=Join(LogTxtArray, vbCrLf),
                    IntentLevel:=IntentLevel,
                    Log2Console:=Log2Console,
                    Log2File:=Log2File,
                    Log2MsgBox:=Log2MsgBox,
                    MsgBoxBtn:=MsgBoxBtn,
                    MsgTitle:=MsgTitle,
                    TimeStampPattern:=TimeStampPattern,
                    Exception2Throw:=Exception2Throw,
                    ShowInNotepad:=ShowInNotepad)

    End Function

    ''' <summary>
    ''' Log multiple lines
    ''' </summary>
    ''' <param name="LogTxtList">
    ''' List of string of lines to log
    ''' </param>
    ''' <param name="IntentLevel">
    ''' Intent level as enum
    ''' std,init,on,two,three,up,down
    ''' </param>
    ''' <param name="Log2Console">
    ''' Log also to console, std. = on
    ''' </param>
    ''' <param name="Log2File">
    ''' Write log instantaneously to file, std. = on
    ''' </param>
    ''' <param name="Log2Msgbox">
    ''' Log also to MsgBox, std. = false
    ''' </param>
    ''' <param name="MsgBoxBtn">
    ''' If Log2MsgBox = true => Button
    ''' </param>
    ''' <param name="MsgTitle">
    ''' If Log2MsgBox = true => MsgTitle
    ''' ></param>
    ''' <param name="TimeStampPattern">
    ''' Std. = "hh:mm"
    ''' </param>
    ''' <param name="Exception2Throw">
    ''' Throw this exception
    ''' </param>
    ''' <param name="ShowInNotepad">
    ''' Show complete Log in Notepad, std. = false
    ''' </param>
    ''' <returns></returns>
    Public Function mylog(
                        LogTxtList As List(Of String),
                        Optional IntentLevel As eLogLevel = eLogLevel.std,
                        Optional Log2Console As eLog2Console = eLog2Console.Yes,
                        Optional Log2File As Boolean = True,
                        Optional Log2MsgBox As Boolean = False,
                        Optional MsgBoxBtn As MsgBoxStyle = MsgBoxStyle.Exclamation,
                        Optional MsgTitle As String = "",
                        Optional TimeStampPattern As String = "std",
                        Optional Exception2Throw As Exception = Nothing,
                        Optional ShowInNotepad As Boolean = False) As MsgBoxResult

        Return mylog(
                LogTxt:=Join(LogTxtList.ToArray, vbCrLf),
                IntentLevel:=IntentLevel,
                Log2Console:=Log2Console,
                Log2File:=Log2File,
                Log2MsgBox:=Log2MsgBox,
                MsgBoxBtn:=MsgBoxBtn,
                MsgTitle:=MsgTitle,
                TimeStampPattern:=TimeStampPattern,
                Exception2Throw:=Exception2Throw,
                ShowInNotepad:=ShowInNotepad)

    End Function

#End Region

#Region "Helper: getStartInfo, showLogInNotepad, resetLog"

    ''' <summary>
    ''' Basic app. infos
    ''' </summary>
    Public Function getStartInfo(Optional LeadingString As String = "") As String()

        Dim InfoList As New List(Of String)

        With InfoList

            Try
                With My.Application.Info
                    InfoList.Add(LeadingString & .ProductName & " v" & .Version.ToString)
                    InfoList.Add(LeadingString & .Title)
                    InfoList.Add(LeadingString & .Copyright)
                End With
            Catch ex As Exception
                InfoList.Add("No info about title and version !!")
            End Try


            .Add(LeadingString & "Started on " & Now.ToString(format:="dddd, dd.MMM.yyyy", CultureInfo.CreateSpecificCulture("en-US")))
            .Add(LeadingString & "        at " & Now.ToString(format:="hh:mm:ss", CultureInfo.CreateSpecificCulture("en-US")))
            .Add(LeadingString & "        by " & Environment.UserName)
            .Add(LeadingString & "on machine " & Environment.MachineName &
                                          " (" & Environment.ProcessorCount & " CPUs with " & GetCpuSpeed() & " GHz and " &
                                                 Math.Round(My.Computer.Info.TotalPhysicalMemory / 1024 / 1024 / 1024, 0) & " GB RAM)")

            .Add(LeadingString & "        OS " & My.Computer.Info.OSFullName & " / " &
                                                 My.Computer.Info.OSPlatform & " / " &
                                                 My.Computer.Info.OSVersion)


            .Add(LeadingString & ".net       " & Get45PlusFromRegistry())
            '.Add(LeadingString & "core       " & getAssemblyVersion())
            .Add(LeadingString & "           ")
            .Add(LeadingString & "Culture    " & My.Application.Culture.ToString)
            .Add(LeadingString & "           " & "Numbers = " & Math.Round(Math.PI, 9).ToString)
            .Add(LeadingString & "           " & "Dates   = " & Now.ToLongDateString)
            .Add(LeadingString & "           " & "CSV     = " & My.Application.Culture.NumberFormat.NumberGroupSeparator.ToString)

            Try

                .Add(LeadingString & "Exec.  Dir " & My.Application.Info.DirectoryPath.ToString)

                If My.Application.Info.DirectoryPath.ToString <> Environment.CurrentDirectory Then
                    .Add(LeadingString & "Work   Dir " & Environment.CurrentDirectory)
                End If

                .Add(LeadingString & "Net avail. " & My.Computer.Network.IsAvailable.ToString &
                                                    " (" & Environment.UserDomainName & ")")



                If FileName <> "" Then

                    If Path.GetDirectoryName(My.Application.Info.DirectoryPath.ToString) <>
                       Path.GetDirectoryName(FileName) Then

                        .Add(LeadingString & "Log path   " & FileName)

                    Else
                        .Add(LeadingString & "Log path   .\" & Path.GetFileName(FileName))
                    End If

                Else
                    .Add(LeadingString & "Log path   Not Set")
                End If

            Catch ex As Exception
                .Add("No info about execution directory And/Or network !!")
            End Try

            .Add("----------------------------------------------------------------------")
            .Add("")

        End With

        Return InfoList.ToArray

    End Function


    Private Function GetOSInfo() As String

        Dim os As OperatingSystem = Environment.OSVersion
        Dim vs As Version = os.Version
        Dim operatingSystem As String = ""

        If os.Platform = PlatformID.Win32Windows Then

            Select Case vs.Minor
                Case 0
                    operatingSystem = "95"
                Case 10

                    If vs.Revision.ToString() = "2222A" Then
                        operatingSystem = "98SE"
                    Else
                        operatingSystem = "98"
                    End If

                Case 90
                    operatingSystem = "Me"
                Case Else

            End Select

        ElseIf os.Platform = PlatformID.Win32NT Then

            Select Case vs.Major
                Case 3
                    operatingSystem = "NT 3.51"
                Case 4
                    operatingSystem = "NT 4.0"
                Case 5

                    If vs.Minor = 0 Then
                        operatingSystem = "2000"
                    Else
                        operatingSystem = "XP"
                    End If

                Case 6

                    If vs.Minor = 0 Then
                        operatingSystem = "Vista"
                    ElseIf vs.Minor = 1 Then
                        operatingSystem = "7"
                    ElseIf vs.Minor = 2 Then
                        operatingSystem = "8"
                    Else
                        operatingSystem = "8.1"
                    End If

                Case 10
                    operatingSystem = "10"
                Case Else

            End Select

        End If

        If operatingSystem <> "" Then
            operatingSystem = "Windows " & operatingSystem

            If os.ServicePack <> "" Then
                operatingSystem += " " & os.ServicePack
            End If
        End If

        Return operatingSystem
    End Function


    ''' <summary>
    ''' Show log in editor
    ''' </summary>
    Public Sub ShowLogInNotepad()

        If FileName = "" Then Exit Sub

        Try
            Process.Start(FileName)
        Catch ex As Exception
            MsgBox(Prompt:="Can't show log file '" & FileName & "'" & vbCrLf & ex.Message,
                  Buttons:=MsgBoxStyle.Critical,
                    Title:="IO Error")
        End Try

    End Sub


    Public Function GetCpuSpeed() As Double
        Dim managementObject = New ManagementObject("Win32_Processor.DeviceID='CPU0'")
        Dim speed As UInteger = CUInt(managementObject("CurrentClockSpeed"))
        managementObject.Dispose()
        Return Math.Round(speed / 1000, digits:=2)
    End Function

    Private Function Get45PlusFromRegistry() As String

        Const subkey As String = "SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full\"

        Using ndpKey As RegistryKey =
            RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry32).OpenSubKey(subkey)

            If ndpKey IsNot Nothing AndAlso ndpKey.GetValue("Release") IsNot Nothing Then
                Return $".NET Framework Version: {CheckFor45PlusVersion(ndpKey.GetValue("Release"))}"
            Else
                Return ".NET Framework Version 4.5 or later is not detected."
            End If

        End Using
    End Function

    ' Checking the version using >= enables forward compatibility.
    Private Function CheckFor45PlusVersion(releaseKey As Integer) As String
        If releaseKey >= 528040 Then
            Return "4.8 or later"
        ElseIf releaseKey >= 461808 Then
            Return "4.7.2"
        ElseIf releaseKey >= 461308 Then
            Return "4.7.1"
        ElseIf releaseKey >= 460798 Then
            Return "4.7"
        ElseIf releaseKey >= 394802 Then
            Return "4.6.2"
        ElseIf releaseKey >= 394254 Then
            Return "4.6.1"
        ElseIf releaseKey >= 393295 Then
            Return "4.6"
        ElseIf releaseKey >= 379893 Then
            Return "4.5.2"
        ElseIf releaseKey >= 378675 Then
            Return "4.5.1"
        ElseIf releaseKey >= 378389 Then
            Return "4.5"
        End If
        ' This code should never execute. A non-null release key should mean
        ' that 4.5 or later is installed.
        Return "No 4.5 or later version detected"
    End Function


    Public Sub ResetLog(Optional LogFileName As String = "",
                        Optional Logo As String() = Nothing,
                        Optional Clear As Boolean = True,
                        Optional ShowLogInNotepad As Boolean = False)

        Dim LogMsg As New List(Of String)

        If LogFileName = "" Then
            LogFileName = Path.Combine(My.Application.Info.DirectoryPath,
                                       My.Application.Info.ProductName & ".log")
        Else
            If Not Directory.Exists(Path.GetDirectoryName(LogFileName)) Then

                Throw New IOException(
                    message:="Directory does NOT exist : Can't write to" & vbCrLf &
                             "LogFileName = " & LogFileName)

                Exit Sub

            End If
        End If

        FileName = LogFileName

        If Clear Then LogList.Clear()

        If Not IsNothing(Logo) Then
            LogMsg.AddRange(Logo)
        End If

        LogMsg.AddRange(getStartInfo())

        mylog(LogTxtArray:=LogMsg.ToArray)

    End Sub

#End Region


    Public Function parseExceptionMsg(Exception As Exception,
                             Optional UserErrorDescription As String = "",
                             Optional LeadingString As String = "",
                             Optional toConsole As Boolean = False,
                             Optional toFile As String = "",
                             Optional ExitCode As Integer = -1) As String()

#Region "    Definitions"

        Const TargetAllignSpace As Integer = 8

        Dim Delimiter As String
        Dim ModuleDelimiter As String
        Dim RowDelimiter As String

        Dim StackTraceArray As String()
        Dim ErrorLineArray As String()
        Dim Output As New List(Of String)

        Dim ModuleRow As String = ""

#End Region

#Region "    Check inputs"

        If IsNothing(UserErrorDescription) Then
            UserErrorDescription = ""
        ElseIf UserErrorDescription <> "" Then
            Output.Add(UserErrorDescription)
        End If

        If IsNothing(LeadingString) Then
            LeadingString = ""
        End If

        If IsNothing(Exception) Then
            Return {"Exception = Nothing"}
        End If

#End Region

#Region "    Check language : German or English"

        Output.Add(padLeft("Error Message", Exception.Message))

        'check if German or English error MSG
        If Not IsNothing(Exception.StackTrace) Then

            If Exception.StackTrace.Contains("at ") Then

                'English
                Delimiter = "at "
                ModuleDelimiter = " in "
                RowDelimiter = ":line"

            ElseIf Exception.StackTrace.Contains("bei ") Then

                'German
                Delimiter = "bei "
                ModuleDelimiter = " in "
                RowDelimiter = ":Zeile"

            Else

                With Output

                    .Add("Unknown language. can't parse error msg!")
                    .Add("ErrorMsg".PadRight(TargetAllignSpace) & ": " &
                          Exception.Message.ToString)
                    .Add("StackTrace")
                    .Add(Exception.StackTrace.ToString)

                End With

                Return Output.ToArray

            End If

        Else

            Return Output.ToArray

        End If

#End Region

#Region "    Main"

        Try

            StackTraceArray = Split(Exception.StackTrace,
                                    Delimiter)
            StackTraceArray = Filter(StackTraceArray,
                                     ModuleDelimiter)

            'parse each msg
            For Each ErrorLine As String In StackTraceArray

                With Output

                    'Module name
                    ErrorLineArray = Split(ErrorLine,
                                           ModuleDelimiter)

                    ModuleRow = padLeft("Module", Trim(ErrorLineArray.First))

                    If Output.Contains(ModuleRow) Then
                        Continue For
                    Else
                        .Add(ModuleRow)
                        ModuleRow = ""
                    End If


                    ErrorLineArray = Split(ErrorLineArray.Last,
                                           RowDelimiter)

                    'Where is the problem
                    .Add(padLeft("in file", Trim(ErrorLineArray.First)))
                    .Add(padLeft("at row", Trim(Replace(ErrorLineArray.Last, ".", ""))))

                End With

            Next

        Catch FatalException As Exception

            With Output

                .Add("Can't parse error msg!")
                .Add("ErrorMsg".PadRight(TargetAllignSpace) & ": " &
                                Exception.Message.ToString)
                .Add("StackTrace")
                .Add(Exception.StackTrace.ToString)
                .Add(FatalException.StackTrace.ToString)

            End With

        End Try

#End Region

#Region "    Output"

        'add leading string
        If LeadingString <> "" Then
            For Counter As Integer = 0 To Output.Count - 1
                Output(Counter) = LeadingString & Output(Counter)
            Next
        End If


        'inner exception
        If Not IsNothing(Exception.InnerException) Then

            If Exception.InnerException.Message <> Exception.Message Then

                Output.Add(" ")
                Output.Add(" ")
                Output.Add("inner exception: ")
                Output.Add(" ")
                Output.AddRange(
                parseExceptionMsg(
                    Exception:=Exception.InnerException))

            End If

        End If

        If toConsole Then
            Console.WriteLine(
                Join(
                    SourceArray:=Output.ToArray,
                    Delimiter:=vbCrLf))
        End If

        Try

            If toFile <> "" Then

                IO.File.WriteAllLines(
                    path:=toFile,
                    contents:=Output.ToArray)

            End If

        Catch ex As Exception

            parseExceptionMsg(
                Exception:=ex,
                UserErrorDescription:="Can't write error to file",
                LeadingString:=LeadingString,
                toFile:="", toConsole:=True)

        End Try

#End Region

        If ExitCode > 0 Then

            Try

                Environment.ExitCode = ExitCode
                End

            Catch ex As Exception

                parseExceptionMsg(
                    Exception:=ex,
                    UserErrorDescription:="Can't exit program",
                    LeadingString:=LeadingString)

            End Try

        End If

        Return Output.ToArray

    End Function


    'Public Function getAssemblyVersion() As String
    '    Return GetType(Misc).Assembly.GetName().Version.ToString
    'End Function

    Public Function getExecVersionInfo(ByVal filename As String) As Version
        Return Version.Parse(FileVersionInfo.GetVersionInfo(filename).FileVersion)
    End Function

End Module
