﻿
Imports System.IO

Module indump

    Public Sub indump()

        Dim tmp As String()
        Dim target As String

        tmp = Directory.GetFiles(path:=Environment.CurrentDirectory,
                                 searchPattern:="*.tmp",
                                 searchOption:=SearchOption.TopDirectoryOnly)

        target = Path.Combine(path1:=Environment.CurrentDirectory,
                              path2:="indump.tmp")

        File.Move(sourceFileName:=tmp.First, destFileName:=target)

    End Sub

End Module
