﻿
Imports System.IO

Module runModel

    Public Const modelName As String = "Macro52Model.exe"

    Public Sub runModel()

        Dim myProcess As New Process
        Dim binFile As FileInfo
        Dim loopCounter As Integer = 1
        Const counterLimit As Integer = 100
        Const resultBin As String = "MACRO001.BIN"

        With myProcess

            With .StartInfo

                .FileName = modelName
                .WindowStyle = ProcessWindowStyle.Hidden

            End With

            .Start()

            Do While Not .HasExited

                Threading.Thread.Sleep(30 * 1000)

                binFile = New FileInfo(resultBin)

                Console.WriteLine((loopCounter * 30 / 60).ToString("0.0").PadLeft(4) & "min  " &
                                  (binFile.Length / 1000).ToString("0").PadLeft(5) & "  " &
                                  (binFile.Length / maxBinFileSize).ToString("0.0%"))


                loopCounter += 1
                If loopCounter > counterLimit Then

                    .Kill()
                    Throw New Exception(message:="Run model error")
                    End

                End If

            Loop

        End With



    End Sub

End Module
