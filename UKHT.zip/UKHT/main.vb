﻿
Imports System.IO

Module main


    Sub main()

        obin.obin()
        indump.indump()
        runModel.runModel()
        renBin.renBin()
        bin2csv.bin2csv()

    End Sub

End Module
