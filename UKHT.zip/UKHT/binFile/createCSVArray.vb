﻿

Module createCSVArray

    Public Sub createCSVArray()

        Const numberFormat As String = "0.00000E+00"
        Const dateFormat As String = "yyyyMMddHHmm"

        csvRows.Add(
                dateFormat.ToUpper & "," &
                cols(0).Label.Split.First.PadLeft(numberFormat.Length) & "," &
                cols(1).Label.Split.First.PadLeft(numberFormat.Length) & "," &
                cols(2).Label.Split.First.PadLeft(numberFormat.Length))

        For Each row As row In rows

            csvRows.Add(
                row.myDate.ToString(dateFormat) & "," &
                row(0).ToString(numberFormat) & "," &
                row(1).ToString(numberFormat) & "," &
                row(2).ToString(numberFormat))

        Next

    End Sub

End Module
