﻿

Imports System.IO

Module bin2csv



    Public cols As List(Of column) = New List(Of column)()
    Public rows As List(Of row) = New List(Of row)()

    Public varNo As Integer
    Public recordNo As Integer
    Public recordLength As Integer
    Public julDate As Integer

    Public binFilePath As String
    Public binaryReader As BinaryReader
    Public inputStream As Stream

    Public csvRows As New List(Of String)

    Public Const minBinFileSize As Integer = 150 * 1000
    Public Const maxBinFileSize As Integer = 250 * 1000

    Public Sub bin2csv()


        getBinFilePath.getBinFilePath()

        openStream.openStream()
        createReader.createReader()
        initReader.initReader()
        getColumnHeaders.getColumnHeaders()
        getRows.getRows()

        createCSVArray.createCSVArray()
        writeCSV.writeCSV()

    End Sub

End Module
