﻿
Imports System.IO

Module writeCSV

    Public Sub writeCSV()

        Try

            File.WriteAllLines(
                path:=Path.ChangeExtension(path:=binFilePath,
                                           extension:=".csv"),
                contents:=csvRows.ToArray)

        Catch ex As Exception

            Throw New IOException(message:=("Can't write csv file"),
                                  innerException:=ex)

        End Try

    End Sub

End Module
