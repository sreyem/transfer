﻿
Imports System.IO

Module getRows

    Public Sub getRows()

        Dim row As row

        inputStream.Seek(recordLength, SeekOrigin.Begin)

        For i As Integer = 1 To recordNo

            row = New row()
            julDate = binaryReader.ReadInt32()

            row.myDate = New DateTime(
                1, 1, 1, 0, 0, 0).AddMinutes(julDate - 2 * 24 * 60)
            row.Values = New Single(cols.Count - 1 - 1) {}

            For j As Integer = 1 To varNo - 1
                row.Values(j - 1) = binaryReader.ReadSingle()
            Next

            rows.Add(row)

        Next

    End Sub

End Module
