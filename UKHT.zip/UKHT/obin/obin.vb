﻿

Module obin

    Public obinPath As String

    Public Sub obin()

        createOBIN.createOBIN()
        moveWeatherFiles.moveWeatherFiles()

    End Sub

End Module
