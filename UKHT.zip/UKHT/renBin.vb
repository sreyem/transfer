﻿

Imports System.IO

Module renBin

    Public Sub renBin()

        Dim parFilePath As String()
        Dim macroBinFile As String()
        Dim target As String

        parFilePath =
            Directory.GetFiles(path:=Environment.CurrentDirectory,
                               searchPattern:="*.par",
                               searchOption:=SearchOption.TopDirectoryOnly)

        If parFilePath.Count <> 1 Then
            Throw New IOException(message:="Can't find one par file")
        End If

        macroBinFile =
           Directory.GetFiles(path:=Environment.CurrentDirectory,
                              searchPattern:="MACRO*.BIN",
                              searchOption:=SearchOption.TopDirectoryOnly)

        If macroBinFile.Count <> 1 Then
            Throw New IOException(message:="Can't find one result bin file")
        End If

        target = Path.Combine(path1:=Environment.CurrentDirectory,
                              path2:=Path.GetFileNameWithoutExtension(parFilePath.First) & ".bin")

        File.Move(sourceFileName:=macroBinFile.First,
                  destFileName:=target)

    End Sub

End Module
