﻿
Imports System.IO
Imports System.Text
Imports System.Web.Script.Serialization
Imports System.Xml.Serialization


Public Class Form1

    Public Sub New()
        InitializeComponent()

        class2Show = test2

        propGridMain.SelectedObject = class2Show

    End Sub



    'Public WithEvents test As New FOCUSDrift
    Public Property test2 As New PECman.PECman


    Public Property class2Show As New Object


    Private Sub mainGridItemChanged(
            sender As Object,
            e As SelectedGridItemChangedEventArgs) Handles propGridMain.SelectedGridItemChanged

        If IsNothing(e.OldSelection) OrElse
           IsNothing(e.NewSelection.Value) Then Exit Sub

        If e.NewSelection.Value.GetType.ToString = (New Date).GetType.ToString Then
            Exit Sub
        End If


        'Try
        '    Dim test As String = e.NewSelection.Value.count.ToString
        '    Exit Sub
        'Catch ex As Exception
        '    Console.Write(ex.Message)
        'End Try

        Try

            With propGridDetails

                .Font = New Font(
                                familyName:="Courier New",
                                emSize:=10)

                .PropertySort = PropertySort.Categorized
                .SelectedObject = e.NewSelection.Value
                .Refresh()

            End With

        Catch ex As Exception
            Console.Write(ex.Message)
        End Try


    End Sub

    ''' <summary>
    ''' update status bar and 'DataChanged'
    ''' </summary>
    ''' <param name="s"></param>
    ''' <param name="e"></param>
    Private Sub propGrid_PropertyValueChanged(s As Object, e As PropertyValueChangedEventArgs) Handles _
        propGridMain.PropertyValueChanged, propGridDetails.PropertyValueChanged

        Dim oldValue As String

        '1st change
        If IsNothing(e.OldValue) Then
            oldValue = ""
        Else
            oldValue = e.OldValue.ToString
        End If

        Dim NewValue As String
        Dim ChangedItemLabel As String = e.ChangedItem.Label.ToString
        Dim Status As String

        Try

            If IsNothing(e.ChangedItem.Value) Then Exit Sub

            NewValue = e.ChangedItem.Value.ToString

            oldValue = Replace(
                    Expression:=oldValue,
                          Find:=Environment.NewLine,
                   Replacement:=" ")

            If oldValue = NewValue Then Exit Sub

            Status = "Value for '" &
                                 ChangedItemLabel & "' changed: " &
                                 IIf(
                                     oldValue = "",
                                     "",
                                     " from " & oldValue).ToString &
                                     " to " & NewValue

            Status = Replace(
                    Expression:=Status,
                          Find:=vbCrLf,
                   Replacement:="")

            Me.tsslStatus.Text = Status

        Catch ex As Exception

        End Try

        Me.propGridMain.Refresh()
        Me.propGridDetails.Refresh()

    End Sub

    Private Sub save_click(sender As Object, e As EventArgs) Handles tsmiSave.Click

        Try
            Me.tsslStatus.Text = serialize()
        Catch ex As Exception

        End Try

    End Sub


    Public Function serialize() As String


        Dim mySaveFileDialog As New SaveFileDialog

        With mySaveFileDialog

#Region "            SaveFileDialog settings"

            .Filter =
                "XML files (*.xml)|*.xml|" &
                "Binary files (*.soap)|*.soap|" &
                "JSON files (*.json)|*.json|" &
                "All files (*.*)|*.*"

            .FilterIndex = 0

            .AddExtension = True
            .AutoUpgradeEnabled = True

            .CheckFileExists = False
            .CheckPathExists = True

            .CreatePrompt = False
            .OverwritePrompt = True

#End Region

            'get filename
            If .ShowDialog <> DialogResult.OK Then
                Return " Save canceled by user"
            End If


            Select Case Path.GetExtension(.FileName).ToLower

                Case ".xml"

                    Try

                        Dim mySerializer As XmlSerializer =
                            New XmlSerializer(class2Show.GetType)

                        Dim myWriter As IO.StreamWriter =
                            New IO.StreamWriter(.FileName)

                        mySerializer.Serialize(myWriter, class2Show)

                        myWriter.Close()
                        myWriter = Nothing

                    Catch ex As Exception

                        Throw New IOException(
                            message:=
                                "Error serializing (saving) class " &
                                class2Show.GetType.Name.ToString &
                                "to file " & .FileName,
                            innerException:=ex)

                    End Try

                    'Case eFileType.soap

                    '    Try



                    '    Catch ex As Exception

                    '        Throw New IOException(
                    '            message:=
                    '                "Error serializing (saving) class " &
                    '                classType.Name.ToString &
                    '                "to file " & .FileName,
                    '            innerException:=ex)

                    '    End Try

                Case ".json"



                    Try

                        Dim serializer As New JavaScriptSerializer

                        Dim serializedResult =
                            serializer.Serialize(class2Show)

                        serializedResult =
                            New JsonFormatter(json:=serializedResult).Format

                        File.WriteAllText(
                            path:= .FileName,
                            contents:=serializedResult)

                        Return True

                    Catch ex As Exception

                    End Try


            End Select

            Return "OK : Save class to file " & .FileName

        End With

        Return False

    End Function

    Private Sub load_click(sender As Object, e As EventArgs) Handles tsmiLoad.Click

        Try
            Me.tsslStatus.Text = deSerialize()
        Catch ex As Exception

        End Try

    End Sub

    Public Function deSerialize() As String



        Dim myOpenFileDialog As New OpenFileDialog
        Dim xmlFile As String() = {}

        With myOpenFileDialog

#Region "            OpenFileDialog settings"

            .Filter =
                "XML files (*.xml)|*.xml|" &
                "Binary files (*.soap)|*.soap|" &
                "JSON files (*.json)|*.json|" &
                "All files (*.*)|*.*"

            .FilterIndex = 0

            .AddExtension = True
            .AutoUpgradeEnabled = True

            .CheckFileExists = False
            .CheckPathExists = True

#End Region

            'get filename
            If .ShowDialog <> DialogResult.OK Then
                Return " Load canceled by user"
            End If


            Select Case Path.GetExtension(.FileName).ToLower

                Case ".xml"

                    Try

                        xmlFile = File.ReadAllLines(.FileName)

                        Dim mySerializer As XmlSerializer =
                               New XmlSerializer(class2Show.GetType)

                        ' To read the file, create a FileStream.
                        Dim myFileStream As IO.FileStream =
                               New IO.FileStream(.FileName, IO.FileMode.Open)


                        Dim type As Type = class2Show.GetType()
                        Dim typeName As String = type.FullName.Split(".").Last


                        class2Show = mySerializer.Deserialize(myFileStream)
                        myFileStream.Close()


                        If Not xmlFile(1).StartsWith("<" & typeName) Then

                            Return "File and class don't match"

                        Else

                            With Me.propGridMain

                                .SelectedObject = Nothing
                                .SelectedObject = class2Show
                                .Refresh()

                            End With

                            Return "OK : Load file " & .FileName

                        End If

                    Catch ex As Exception

                        Return ex.Message

                    End Try

                Case Else

                    Return "Unknown file type "

            End Select

        End With

    End Function

    Private Sub tsmiExit_Click(sender As Object, e As EventArgs) Handles tsmiExit.Click

        Me.Close()

    End Sub


#Region "json"


    Public Class JsonFormatter

        Private ReadOnly _walker As StringWalker
        Private ReadOnly _writer As IndentWriter = New IndentWriter()
        Private ReadOnly _currentLine As StringBuilder = New StringBuilder()
        Private _quoted As Boolean

        Public Sub New(ByVal json As String)
            _walker = New StringWalker(json)
            ResetLine()
        End Sub

        Public Sub ResetLine()
            _currentLine.Length = 0
        End Sub

        Public Function Format() As String
            While MoveNextChar()

                If Me._quoted = False AndAlso Me.IsOpenBracket() Then
                    Me.WriteCurrentLine()
                    Me.AddCharToLine()
                    Me.WriteCurrentLine()
                    _writer.Indent()
                ElseIf Me._quoted = False AndAlso Me.IsCloseBracket() Then
                    Me.WriteCurrentLine()
                    _writer.UnIndent()
                    Me.AddCharToLine()
                ElseIf Me._quoted = False AndAlso Me.IsColon() Then
                    Me.AddCharToLine()
                    Me.WriteCurrentLine()
                Else
                    AddCharToLine()
                End If
            End While

            Me.WriteCurrentLine()
            Return _writer.ToString()
        End Function

        Private Function MoveNextChar() As Boolean
            Dim success As Boolean = _walker.MoveNext()

            If Me.IsApostrophe() Then
                Me._quoted = Not _quoted
            End If

            Return success
        End Function

        Public Function IsApostrophe() As Boolean
            Return Me._walker.CurrentChar = """"c AndAlso Me._walker.IsEscaped = False
        End Function

        Public Function IsOpenBracket() As Boolean
            Return Me._walker.CurrentChar = "{"c OrElse Me._walker.CurrentChar = "["c
        End Function

        Public Function IsCloseBracket() As Boolean
            Return Me._walker.CurrentChar = "}"c OrElse Me._walker.CurrentChar = "]"c
        End Function

        Public Function IsColon() As Boolean
            Return Me._walker.CurrentChar = ","c
        End Function

        Private Sub AddCharToLine()
            Me._currentLine.Append(_walker.CurrentChar)
        End Sub

        Private Sub WriteCurrentLine()
            Dim line As String = Me._currentLine.ToString().Trim()

            If line.Length > 0 Then
                _writer.WriteLine(line)
            End If

            Me.ResetLine()
        End Sub
    End Class

    Public Class StringWalker
        Private ReadOnly _s As String
        Public Property Index As Integer
        Public Property IsEscaped As Boolean
        Public Property CurrentChar As Char

        Public Sub New(ByVal s As String)
            _s = s
            Me.Index = -1
        End Sub

        Public Function MoveNext() As Boolean
            If Me.Index = _s.Length - 1 Then Return False

            If IsEscaped = False Then
                IsEscaped = CurrentChar = "\"c
            Else
                IsEscaped = False
            End If

            Me.Index += 1
            CurrentChar = _s(Index)
            Return True
        End Function
    End Class

    Public Class IndentWriter
        Private ReadOnly _result As StringBuilder = New StringBuilder()
        Private _indentLevel As Integer

        Public Sub Indent()
            _indentLevel += 1
        End Sub

        Public Sub UnIndent()
            If _indentLevel > 0 Then _indentLevel -= 1
        End Sub

        Public Sub WriteLine(ByVal line As String)
            _result.AppendLine(CreateIndent() & line)
        End Sub

        Private Function CreateIndent() As String
            Dim indent As StringBuilder = New StringBuilder()

            For i As Integer = 0 To _indentLevel - 1
                indent.Append("    ")
            Next

            Return indent.ToString()
        End Function

        Public Overrides Function ToString() As String
            Return _result.ToString()
        End Function
    End Class


#End Region

End Class
Public Class test

    Public Sub New()

    End Sub


    'Public Property scenario As eFOCUSswScenario

    'Public Property FOCUScrop As eFOCUSDriftCrop


    'Public ReadOnly Property Ganzelmeier As eGanzelmeier
    '    Get
    '        Return FOCUSCrop2Ganzelmeier(FOCUScrop)
    '    End Get
    'End Property


End Class

