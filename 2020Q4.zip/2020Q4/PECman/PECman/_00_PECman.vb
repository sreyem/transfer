﻿

Public Class PECman


    Public Sub New()

    End Sub


    Public Shared endpointType As String = "80th perc."
    Public Shared resultUnit As String = " µg/L "



End Class
