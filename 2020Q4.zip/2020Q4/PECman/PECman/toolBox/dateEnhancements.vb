﻿

Imports System.ComponentModel
Imports System.Globalization
Imports System.Runtime.CompilerServices

Imports PECman.propGridEnhancements



Public Class dateEnhancements

#Region "    shared"

    Public Enum eCountry
        de_DE
        en_US
        fr_FR
    End Enum

    Public Enum eJulian
        add
        only
        none
    End Enum

    Public Shared country As eCountry = stdCountry
    Public Shared dateFormat As String = stdDblformat
    Public Shared emptyString As String = stdEmptyString
    Public Shared julian As eJulian = eJulian.add

#End Region



    Public Class dateConvPara

        Inherits DateTimeConverter

#Region "    get/set parameters"

        Public Shared Function getDateParameter(context As ITypeDescriptorContext) As String()

            Dim Attributes As AttributeCollection
            Dim Provider As AttributeProviderAttribute

            Dim formatArray As String() = {}

            Try

                With context

                    Attributes = .PropertyDescriptor.Attributes

                    For Each attribute In Attributes

                        If attribute.ToString =
                        "System.ComponentModel.AttributeProviderAttribute" Then

                            Provider = attribute
                            formatArray = Provider.TypeName.Split("|")

                        End If

                    Next

                End With
            Catch ex As Exception

            End Try

            For counter As Integer = 0 To formatArray.Count - 1
                formatArray(counter) = Trim(formatArray(counter))
            Next

            Return formatArray

        End Function

        Public Shared Sub setDateParameters(formatArray As String())

            Dim parameterValue As String()

            setStd()

            For Each member As String In formatArray

                parameterValue = member.Split("=")
                parameterValue(0) = Trim(parameterValue(0))

                Select Case parameterValue.First

                    Case "format"
                        dateFormat = parameterValue.Last

                    Case "country"
                        country = parameterValue.Last

                    Case "emptyString"
                        emptyString = parameterValue.Last

                    Case "julian"
                        julian = [Enum].Parse(GetType(eJulian), Trim(parameterValue.Last))


                End Select

            Next

        End Sub

        Public Shared Sub setStd()

            country = stdCountry
            dateFormat = stdDateFormat
            emptyString = stdEmptyString
            julian = stdJulian

        End Sub

#End Region

#Region "    Engine"

        '<DebuggerStepThrough>
        Public Overrides Function ConvertTo(
                            context As ITypeDescriptorContext,
                            culture As CultureInfo,
                            value As Object,
                            destType As Type) As Object


            setDateParameters(formatArray:=getDateParameter(context:=context))

            Try

                Return _
              CDate(value).convDate2String(
                    format:=dateFormat,
                    country:=country,
                    emptyString:=emptyString,
                    julian:=julian)

            Catch ex As Exception
                Return value
            End Try

        End Function

        '<DebuggerStepThrough>
        Public Overrides Function ConvertFrom(
                            context As ITypeDescriptorContext,
                            culture As CultureInfo,
                            value As Object) As Object

            Dim valueString As String

            Try

                valueString = CType(value, String)

                If valueString.Contains(emptyString) Then
                    Return New Date
                ElseIf IsNothing(value) Then
                    Return Double.NaN
                Else
                    Return Double.Parse(valueString)
                End If

            Catch ex As Exception
                Return Nothing
            End Try

        End Function

#End Region

    End Class


End Class