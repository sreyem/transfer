﻿

Imports System.ComponentModel
Imports System.Globalization
Imports System.Runtime.CompilerServices

Imports PECman.propGridEnhancements

Module extension

    Public Enum eCountry
        de_DE
        en_US
        fr_FR
    End Enum

    Public Enum eJulian
        add
        only
        none
    End Enum

    Public Const stdCountry As eCountry = eCountry.en_US
    Public Const stdEmptyString As String = " - "
    Public Const stdJulian As eJulian = eJulian.add

    Public Const stdDblformat As String = "G4"
    Public Const stdMinSign As String = "<"
    Public Const stdMinValue As Double = Nothing
    Public Const stdDigits As Integer = -1
    Public Const stdUnit As String = ""
    Public Const stdnegDef As Boolean = False

    Public Const stdDateFormat As String = "dd. MMM"

    <DebuggerStepThrough>
    <Extension()>
    Public Function convDate2String(
                                   value As Date,
                          Optional format As String = stdDateFormat,
                          Optional julian As eJulian = stdJulian,
                          Optional emptyString As String = stdEmptyString,
                          Optional country As eCountry = stdCountry) As String

        Dim countryString As String
        Dim out As String = ""

        countryString =
                Replace(
                Expression:=country.ToString,
                Find:="_", Replacement:="-",
                Compare:=CompareMethod.Text)
        Try

            If value = New Date OrElse IsNothing(value) Then
                Return emptyString
            End If

            out = value.ToString(
                            format:=format,
                            provider:=CultureInfo.CreateSpecificCulture(countryString))

            Select Case julian

                Case eJulian.none

                Case eJulian.add
                    out &= " " & value.DayOfYear.ToString

                Case eJulian.only
                    out = value.DayOfYear.ToString()

            End Select

            Return out

        Catch ex As Exception
            Return emptyString
        End Try


    End Function

    <DebuggerStepThrough>
    <Extension()>
    Public Function conv2String(
                             value As Double,
                    Optional format As String = stdDblformat,
                    Optional country As eCountry = stdCountry,
                    Optional minValue As Double = stdMinValue,
                    Optional minSign As String = stdMinSign,
                    Optional digits As Integer = stdDigits,
                    Optional unit As String = stdUnit,
                    Optional negativeDefined As Boolean = stdnegDef) As String

        Dim countryString As String

        countryString =
                Replace(
                Expression:=country.ToString,
                Find:="_", Replacement:="-",
                Compare:=CompareMethod.Text)

        If value < 0 And Not negativeDefined Then
            Return stdEmptyString
        End If

        If Not Double.IsNaN(minValue) AndAlso value < minValue Then
            Return minSign & minValue.ToString & unit
        End If

        If Double.IsNaN(Double.Parse(value)) Then
            Return stdEmptyString
        End If

        Try

            If digits > -1 Then

                value =
                Math.Round(
                    value,
                    digits:=digits)

            End If

            Return value.ToString(
                          format:=format,
                        provider:=CultureInfo.CreateSpecificCulture(countryString)) & unit

        Catch ex As Exception

            Console.WriteLine("error converting double to string")
            Return ex.Message

        End Try

    End Function

End Module

