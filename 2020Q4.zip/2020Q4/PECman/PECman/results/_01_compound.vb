﻿

Imports System.ComponentModel
Imports System.Text
Imports System.Xml.Serialization
Imports System.Web.Script.Serialization
Imports System.IO
Imports PECman
Imports PECman.propGridEnhancements
Imports PECman.dateEnhancements

Imports PECman._FOCUSGWdb

Public Class test

    Implements gap


End Class

<TypeConverter(GetType(propGridConverter))>
<DefaultProperty("scenario")>
<Serializable>
Public Class gap
    Private _resultPath As String


    Public Sub New()

    End Sub

    Public Property crop As eCropsGW

    Public Property results As AI_GAP() = Nothing

    Public Property resultPath As String
        Get
            Return _resultPath
        End Get
        Set
            _resultPath = Value
        End Set
    End Property


    Public Sub parseResultPath(resultPath As String)

        Dim AIs As String() = {}
        Dim aiResult As AI_GAP

        AIs =
            Directory.GetDirectories(
            path:=resultPath,
            searchPattern:="*",
            searchOption:=SearchOption.TopDirectoryOnly)

        For Each ai As String In AIs

            aiResult = New AI_GAP

        Next


    End Sub

End Class

''' <summary>
''' All Scenario results for one AI
''' </summary>
<TypeConverter(GetType(propGridConverter))>
<DefaultProperty("scenario")>
<Serializable>
Public Class AI_GAP

    Private _runs As run() = Nothing

    Public Sub New()

    End Sub


    <Browsable(False)>
    <XmlIgnore> <ScriptIgnore>
    Public Shadows Property name As String
        Get
            If Me.scenario = eScenariosGW.notdef Then
                Return emptyString
            Else

                Return Me.scenario.ToString
            End If
        End Get
        Set

        End Set
    End Property

    Public Property scenario As eScenariosGW = eScenariosGW.notdef

    ''' <summary>
    ''' Short (5 chars) code of the compound/AI
    ''' no numbers at the beginning, no special characters
    ''' </summary>
    ''' <returns></returns>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category("")>
    <DisplayName(
    "AIs")>
    <Description(
    "Active Ingredients" & vbCrLf &
    "of the formulation, just one if it's a strait")>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    <DefaultValue(CType(Nothing, Object))>
    Public Property runs As run()
        Get
            Return _runs
        End Get
        Set
            _runs = Value
        End Set
    End Property

End Class

''' <summary>
''' Complete results for one AI
''' </summary>
<TypeConverter(GetType(propGridConverter))>
<DefaultProperty("code")>
<Serializable>
Public Class run

    Public Sub New()

    End Sub

    <Browsable(False)>
    <XmlIgnore> <ScriptIgnore>
    Public Shadows Property name As String
        Get
            Dim out As String

            If Not IsNothing(compounds) AndAlso
                compounds.Count > 0 Then

                For counter As Integer = 0 To compounds.Count - 1
                    out &= compounds(counter).code & " "
                    If counter < compounds.Count - 1 Then out &= vbCrLf
                Next

            Else
                out = emptyString
            End If

            Return out

        End Get
        Set

        End Set
    End Property

    Private _code As String = String.Empty
    Private _compounds As compound() = Nothing

    ''' <summary>
    ''' Short (5 chars) code of the compound/AI
    ''' no numbers at the beginning, no special characters
    ''' </summary>
    ''' <returns></returns>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category("")>
    <DisplayName(
    "Code")>
    <Description(
    "Short (5 chars) code of the compound/AI" & vbCrLf &
    "no numbers at the beginning, no special characters")>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    <DefaultValue(CType(Nothing, Object))>
    Public Property code As String
        Get
            Return _code
        End Get
        Set
            _code =
                _FOCUSGWdb.parseSubstanceCode(
                        code:=Value,
                        maxLength:=5)



        End Set
    End Property

    ''' <summary>
    ''' Compounds
    ''' Parent and metabolites of this Active Ingredient
    ''' code = Parent code (compounds[0])
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category("")>
    <DisplayName(
    "Compounds")>
    <Description(
    "Parent and metabolites of this Active Ingredient" & vbCrLf &
    "code = Parent code (compounds[0])")>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    <DefaultValue(CType(Nothing, Object))>
    Public Property compounds As compound()
        Get
            Return _compounds
        End Get
        Set
            _compounds = Value

            If Not IsNothing(_compounds) AndAlso
                            _compounds.Count > 0 Then
                compounds(0).code = _code
            End If

        End Set
    End Property

End Class

''' <summary>
''' One Parent or metabolite of an AI
''' </summary>
<TypeConverter(GetType(propGridConverter))>
<DefaultProperty("code")>
<Serializable>
Public Class compound

    Public Sub New()

    End Sub


    <Browsable(False)>
    Public Shadows Property name As String
        Get
            Return code.PadRight(6) & vbCrLf & endPoints.name
        End Get
        Set

        End Set
    End Property


    Private _code As String = String.Empty
    Private _endPoints As New endPoint
    Private _details As statisticPEC() = {}

    ''' <summary>
    ''' Short (5 chars) code of the compound/AI
    ''' no numbers at the beginning, no special characters
    ''' </summary>
    ''' <returns></returns>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category("")>
    <DisplayName(
    "Code")>
    <Description(
    "Short (5 chars) code of the compound/AI" & vbCrLf &
    "no numbers at the beginning, no special characters")>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    <DefaultValue(CType(Nothing, Object))>
    Public Property code As String
        Get
            Return _code
        End Get
        Set

            _code =
            _FOCUSGWdb.parseSubstanceCode(
                    code:=Value,
                    maxLength:=5)

        End Set
    End Property

    ''' <summary>
    ''' Endpoints for all three FOCUSgw models
    ''' mostly 80th percentile in µg/L
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category("")>
    <DisplayName(
    "PECgw Endpoints")>
    <Description(
    "Endpoints for all three FOCUSgw models" & vbCrLf &
    "80th percentile in µg/L")>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    Public Property endPoints As endPoint
        Get
            Return _endPoints
        End Get
        Set
            _endPoints = Value
        End Set
    End Property

    ''' <summary>
    ''' Endpoints for all three FOCUSgw models
    ''' mostly 80th percentile in µg/L
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category("")>
    <DisplayName(
    "Details")>
    <Description(
    "FOCUS GW result data for 20 years" & vbCrLf &
    "incl. statistic")>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    Public Property details As statisticPEC()
        Get
            Return _details
        End Get
        Set
            _details = Value
        End Set
    End Property

End Class



''' <summary>
''' Endpoints for all three FOCUSgw models
''' mostly 80th percentile in µg/L
''' </summary>
<TypeConverter(GetType(propGridConverter))>
<DefaultProperty("percentiles")>
<Serializable>
Public Class endPoint

    Public Sub New()

    End Sub

    <Browsable(False)>
    <XmlIgnore> <ScriptIgnore>
    Public Shadows Property name As String
        Get

            Dim temp As New StringBuilder

            temp.Clear()
            temp.AppendLine("PEARL : " & PEARL.conv2String(unit:=PECman.resultUnit))
            temp.AppendLine("PELMO : " & PELMO.conv2String(unit:=PECman.resultUnit))
            temp.AppendLine("MACRO : " & MACRO.conv2String(unit:=PECman.resultUnit))

            Return temp.ToString

        End Get
        Set(value As String)

        End Set
    End Property

    Public Const CAT As String = "Endpoints in µg/L"

    Private _PEARL As Double = Double.NaN
    Private _PELMO As Double = Double.NaN
    Private _MACRO As Double = Double.NaN

    ''' <summary>
    ''' Max result out of PEARL, PELMO and MACRO
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CAT)>
    <DisplayName(
    "Max Result")>
    <Description(
    "Max result out of PEARL, PELMO and MACRO")>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    <TypeConverter(GetType(dblConvPara))>
    <AttributeProvider("minValue = 0.0001")>
    <DefaultValue(Double.NaN)>
    Public ReadOnly Property max As Double
        Get

            Dim temp As Double() = {PEARL, PELMO, MACRO}

            Return temp.Max

        End Get
    End Property

    ''' <summary>
    ''' PEARL
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CAT)>
    <DisplayName(
    "PEARL")>
    <Description("")>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    <TypeConverter(GetType(dblConvPara))>
    <AttributeProvider("minValue = 0.0001")>
    <DefaultValue(Double.NaN)>
    Public Property PEARL As Double
        Get
            Return _PEARL
        End Get
        Set
            _PEARL = Value
        End Set
    End Property

    ''' <summary>
    ''' PELMO
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CAT)>
    <DisplayName(
    "PELMO")>
    <Description("")>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    <TypeConverter(GetType(dblConvPara))>
    <AttributeProvider("minValue = 0.0001")>
    <DefaultValue(Double.NaN)>
    Public Property PELMO As Double
        Get
            Return _PELMO
        End Get
        Set
            _PELMO = Value
        End Set
    End Property

    ''' <summary>
    ''' MACRO
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CAT)>
    <DisplayName(
    "MACRO")>
    <Description("")>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    <TypeConverter(GetType(dblConvPara))>
    <AttributeProvider("minValue = 0.0001")>
    <DefaultValue(Double.NaN)>
    Public Property MACRO As Double
        Get
            Return _MACRO
        End Get
        Set
            _MACRO = Value
        End Set
    End Property

End Class


''' <summary>
''' FOCUS GW result data for 20 years
''' incl. statistic
''' </summary>
<DefaultProperty("gwModel")>
<Serializable>
Public Class statisticPEC

    Inherits statistic

    Public Sub New()

    End Sub

    <Category(statistic.CATBasic)>
    Public Property gwModel As eGWModels

    <Browsable(False)>
    Public Shadows Property name As String
        Get
            Return gwModel.ToString()
        End Get
        Set(value As String)

        End Set
    End Property


End Class
