﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.txt2ndCWID = New System.Windows.Forms.TextBox()
        Me.lbl2ndCWID = New System.Windows.Forms.Label()
        Me.lblPasswd = New System.Windows.Forms.Label()
        Me.txtPasswd = New System.Windows.Forms.TextBox()
        Me.cbxPasswdVisible = New System.Windows.Forms.CheckBox()
        Me.txtexecPath = New System.Windows.Forms.TextBox()
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.tsslExpiry = New System.Windows.Forms.ToolStripStatusLabel()
        Me.tsProgessbar = New System.Windows.Forms.ToolStripProgressBar()
        Me.Timer = New System.Windows.Forms.Timer(Me.components)
        Me.txtStartPath = New System.Windows.Forms.TextBox()
        Me.lblSubSearch = New System.Windows.Forms.Label()
        Me.btnScannSub = New System.Windows.Forms.Button()
        Me.txtRegEx = New System.Windows.Forms.TextBox()
        Me.lblRegEx = New System.Windows.Forms.Label()
        Me.btnStartPath = New System.Windows.Forms.Button()
        Me.txtRunTile = New System.Windows.Forms.TextBox()
        Me.cbxSubSearch = New System.Windows.Forms.ComboBox()
        Me.cbxInclSubfolder = New System.Windows.Forms.CheckBox()
        Me.txtBHPCinit = New System.Windows.Forms.TextBox()
        Me.lblSessionID = New System.Windows.Forms.Label()
        Me.txtSessionID = New System.Windows.Forms.TextBox()
        Me.gbxLogIn = New System.Windows.Forms.GroupBox()
        Me.gbxProjectInfo = New System.Windows.Forms.GroupBox()
        Me.gbxCalculation = New System.Windows.Forms.GroupBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtCPUh = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.nudInstances = New System.Windows.Forms.NumericUpDown()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cbxCPUtype = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.nudHours = New System.Windows.Forms.NumericUpDown()
        Me.txtBHPCrun = New System.Windows.Forms.TextBox()
        Me.TabControl = New System.Windows.Forms.TabControl()
        Me.tpgStart = New System.Windows.Forms.TabPage()
        Me.tpbRun = New System.Windows.Forms.TabPage()
        Me.tbpSettings = New System.Windows.Forms.TabPage()
        Me.ckbPowerUserMode = New System.Windows.Forms.CheckBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.cbxPowershell = New System.Windows.Forms.CheckBox()
        Me.StatusStrip1.SuspendLayout()
        Me.gbxLogIn.SuspendLayout()
        Me.gbxProjectInfo.SuspendLayout()
        Me.gbxCalculation.SuspendLayout()
        CType(Me.nudInstances, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudHours, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl.SuspendLayout()
        Me.tpgStart.SuspendLayout()
        Me.tbpSettings.SuspendLayout()
        Me.SuspendLayout()
        '
        'txt2ndCWID
        '
        Me.txt2ndCWID.Location = New System.Drawing.Point(97, 32)
        Me.txt2ndCWID.Name = "txt2ndCWID"
        Me.txt2ndCWID.Size = New System.Drawing.Size(119, 20)
        Me.txt2ndCWID.TabIndex = 0
        Me.ToolTip.SetToolTip(Me.txt2ndCWID, "Please enter your 2nd CWID, min. 5 chars")
        '
        'lbl2ndCWID
        '
        Me.lbl2ndCWID.AutoSize = True
        Me.lbl2ndCWID.Location = New System.Drawing.Point(20, 35)
        Me.lbl2ndCWID.Name = "lbl2ndCWID"
        Me.lbl2ndCWID.Size = New System.Drawing.Size(57, 13)
        Me.lbl2ndCWID.TabIndex = 1
        Me.lbl2ndCWID.Text = "2nd CWID"
        '
        'lblPasswd
        '
        Me.lblPasswd.AutoSize = True
        Me.lblPasswd.Location = New System.Drawing.Point(24, 62)
        Me.lblPasswd.Name = "lblPasswd"
        Me.lblPasswd.Size = New System.Drawing.Size(53, 13)
        Me.lblPasswd.TabIndex = 2
        Me.lblPasswd.Text = "Password"
        '
        'txtPasswd
        '
        Me.txtPasswd.Location = New System.Drawing.Point(97, 59)
        Me.txtPasswd.Name = "txtPasswd"
        Me.txtPasswd.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPasswd.Size = New System.Drawing.Size(161, 20)
        Me.txtPasswd.TabIndex = 3
        '
        'cbxPasswdVisible
        '
        Me.cbxPasswdVisible.AutoSize = True
        Me.cbxPasswdVisible.Location = New System.Drawing.Point(276, 61)
        Me.cbxPasswdVisible.Name = "cbxPasswdVisible"
        Me.cbxPasswdVisible.Size = New System.Drawing.Size(51, 17)
        Me.cbxPasswdVisible.TabIndex = 4
        Me.cbxPasswdVisible.Text = "show"
        Me.cbxPasswdVisible.UseVisualStyleBackColor = True
        '
        'txtexecPath
        '
        Me.txtexecPath.Location = New System.Drawing.Point(200, 54)
        Me.txtexecPath.Name = "txtexecPath"
        Me.txtexecPath.Size = New System.Drawing.Size(400, 20)
        Me.txtexecPath.TabIndex = 6
        Me.txtexecPath.Text = "C:\AWS4EnSa\20209010\bhpc_1_1_1"
        '
        'btnLogin
        '
        Me.btnLogin.Location = New System.Drawing.Point(97, 85)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(84, 28)
        Me.btnLogin.TabIndex = 7
        Me.btnLogin.Text = "Login"
        Me.btnLogin.UseVisualStyleBackColor = True
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsslExpiry, Me.tsProgessbar})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 762)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(986, 22)
        Me.StatusStrip1.TabIndex = 8
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'tsslExpiry
        '
        Me.tsslExpiry.Name = "tsslExpiry"
        Me.tsslExpiry.Size = New System.Drawing.Size(127, 17)
        Me.tsslExpiry.Tag = "Credentials expire(d)  : "
        Me.tsslExpiry.Text = "Credentials expire(d)  : "
        '
        'tsProgessbar
        '
        Me.tsProgessbar.Maximum = 20
        Me.tsProgessbar.Name = "tsProgessbar"
        Me.tsProgessbar.Size = New System.Drawing.Size(100, 16)
        '
        'Timer
        '
        '
        'txtStartPath
        '
        Me.txtStartPath.Location = New System.Drawing.Point(122, 21)
        Me.txtStartPath.Name = "txtStartPath"
        Me.txtStartPath.Size = New System.Drawing.Size(303, 20)
        Me.txtStartPath.TabIndex = 10
        '
        'lblSubSearch
        '
        Me.lblSubSearch.AutoSize = True
        Me.lblSubSearch.Location = New System.Drawing.Point(36, 55)
        Me.lblSubSearch.Name = "lblSubSearch"
        Me.lblSubSearch.Size = New System.Drawing.Size(66, 13)
        Me.lblSubSearch.TabIndex = 11
        Me.lblSubSearch.Text = "*.sub search"
        '
        'btnScannSub
        '
        Me.btnScannSub.Location = New System.Drawing.Point(27, 41)
        Me.btnScannSub.Name = "btnScannSub"
        Me.btnScannSub.Size = New System.Drawing.Size(84, 23)
        Me.btnScannSub.TabIndex = 13
        Me.btnScannSub.Text = "Scann"
        Me.btnScannSub.UseVisualStyleBackColor = True
        '
        'txtRegEx
        '
        Me.txtRegEx.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.txtRegEx.Location = New System.Drawing.Point(351, 55)
        Me.txtRegEx.Name = "txtRegEx"
        Me.txtRegEx.ReadOnly = True
        Me.txtRegEx.Size = New System.Drawing.Size(171, 20)
        Me.txtRegEx.TabIndex = 12
        '
        'lblRegEx
        '
        Me.lblRegEx.AutoSize = True
        Me.lblRegEx.Location = New System.Drawing.Point(306, 58)
        Me.lblRegEx.Name = "lblRegEx"
        Me.lblRegEx.Size = New System.Drawing.Size(39, 13)
        Me.lblRegEx.TabIndex = 16
        Me.lblRegEx.Text = "RegEx"
        '
        'btnStartPath
        '
        Me.btnStartPath.Location = New System.Drawing.Point(27, 19)
        Me.btnStartPath.Name = "btnStartPath"
        Me.btnStartPath.Size = New System.Drawing.Size(75, 23)
        Me.btnStartPath.TabIndex = 17
        Me.btnStartPath.Text = "Start path"
        Me.btnStartPath.UseVisualStyleBackColor = True
        '
        'txtRunTile
        '
        Me.txtRunTile.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRunTile.Location = New System.Drawing.Point(191, 66)
        Me.txtRunTile.Multiline = True
        Me.txtRunTile.Name = "txtRunTile"
        Me.txtRunTile.ReadOnly = True
        Me.txtRunTile.Size = New System.Drawing.Size(321, 103)
        Me.txtRunTile.TabIndex = 18
        '
        'cbxSubSearch
        '
        Me.cbxSubSearch.FormattingEnabled = True
        Me.cbxSubSearch.Items.AddRange(New Object() {"Step03Condor.sub", "Cloud4GWPEARL.sub", "Step04LMCondor*.sub"})
        Me.cbxSubSearch.Location = New System.Drawing.Point(122, 52)
        Me.cbxSubSearch.Name = "cbxSubSearch"
        Me.cbxSubSearch.Size = New System.Drawing.Size(180, 21)
        Me.cbxSubSearch.TabIndex = 19
        '
        'cbxInclSubfolder
        '
        Me.cbxInclSubfolder.AutoSize = True
        Me.cbxInclSubfolder.Checked = True
        Me.cbxInclSubfolder.CheckState = System.Windows.Forms.CheckState.Checked
        Me.cbxInclSubfolder.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.cbxInclSubfolder.Location = New System.Drawing.Point(431, 23)
        Me.cbxInclSubfolder.Name = "cbxInclSubfolder"
        Me.cbxInclSubfolder.Size = New System.Drawing.Size(91, 17)
        Me.cbxInclSubfolder.TabIndex = 20
        Me.cbxInclSubfolder.Text = "incl. subfolder"
        Me.cbxInclSubfolder.UseVisualStyleBackColor = True
        Me.cbxInclSubfolder.Visible = False
        '
        'txtBHPCinit
        '
        Me.txtBHPCinit.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBHPCinit.Location = New System.Drawing.Point(6, 117)
        Me.txtBHPCinit.Name = "txtBHPCinit"
        Me.txtBHPCinit.ReadOnly = True
        Me.txtBHPCinit.Size = New System.Drawing.Size(587, 21)
        Me.txtBHPCinit.TabIndex = 21
        '
        'lblSessionID
        '
        Me.lblSessionID.AutoSize = True
        Me.lblSessionID.Location = New System.Drawing.Point(44, 86)
        Me.lblSessionID.Name = "lblSessionID"
        Me.lblSessionID.Size = New System.Drawing.Size(58, 13)
        Me.lblSessionID.TabIndex = 22
        Me.lblSessionID.Text = "Session ID"
        '
        'txtSessionID
        '
        Me.txtSessionID.Location = New System.Drawing.Point(122, 83)
        Me.txtSessionID.Name = "txtSessionID"
        Me.txtSessionID.Size = New System.Drawing.Size(100, 20)
        Me.txtSessionID.TabIndex = 23
        '
        'gbxLogIn
        '
        Me.gbxLogIn.Controls.Add(Me.txt2ndCWID)
        Me.gbxLogIn.Controls.Add(Me.lbl2ndCWID)
        Me.gbxLogIn.Controls.Add(Me.lblPasswd)
        Me.gbxLogIn.Controls.Add(Me.txtPasswd)
        Me.gbxLogIn.Controls.Add(Me.cbxPasswdVisible)
        Me.gbxLogIn.Controls.Add(Me.btnLogin)
        Me.gbxLogIn.Location = New System.Drawing.Point(26, 20)
        Me.gbxLogIn.Name = "gbxLogIn"
        Me.gbxLogIn.Size = New System.Drawing.Size(365, 143)
        Me.gbxLogIn.TabIndex = 35
        Me.gbxLogIn.TabStop = False
        Me.gbxLogIn.Text = "AWS Login"
        '
        'gbxProjectInfo
        '
        Me.gbxProjectInfo.Controls.Add(Me.cbxPowershell)
        Me.gbxProjectInfo.Controls.Add(Me.btnStartPath)
        Me.gbxProjectInfo.Controls.Add(Me.txtStartPath)
        Me.gbxProjectInfo.Controls.Add(Me.lblSubSearch)
        Me.gbxProjectInfo.Controls.Add(Me.txtRegEx)
        Me.gbxProjectInfo.Controls.Add(Me.lblRegEx)
        Me.gbxProjectInfo.Controls.Add(Me.cbxSubSearch)
        Me.gbxProjectInfo.Controls.Add(Me.cbxInclSubfolder)
        Me.gbxProjectInfo.Controls.Add(Me.txtBHPCinit)
        Me.gbxProjectInfo.Controls.Add(Me.lblSessionID)
        Me.gbxProjectInfo.Controls.Add(Me.txtSessionID)
        Me.gbxProjectInfo.Location = New System.Drawing.Point(26, 180)
        Me.gbxProjectInfo.Name = "gbxProjectInfo"
        Me.gbxProjectInfo.Size = New System.Drawing.Size(599, 156)
        Me.gbxProjectInfo.TabIndex = 36
        Me.gbxProjectInfo.TabStop = False
        Me.gbxProjectInfo.Text = "Project Info"
        '
        'gbxCalculation
        '
        Me.gbxCalculation.Controls.Add(Me.Label9)
        Me.gbxCalculation.Controls.Add(Me.txtCPUh)
        Me.gbxCalculation.Controls.Add(Me.Label8)
        Me.gbxCalculation.Controls.Add(Me.nudInstances)
        Me.gbxCalculation.Controls.Add(Me.Label7)
        Me.gbxCalculation.Controls.Add(Me.cbxCPUtype)
        Me.gbxCalculation.Controls.Add(Me.Label6)
        Me.gbxCalculation.Controls.Add(Me.nudHours)
        Me.gbxCalculation.Controls.Add(Me.btnScannSub)
        Me.gbxCalculation.Controls.Add(Me.txtRunTile)
        Me.gbxCalculation.Controls.Add(Me.txtBHPCrun)
        Me.gbxCalculation.Location = New System.Drawing.Point(26, 342)
        Me.gbxCalculation.Name = "gbxCalculation"
        Me.gbxCalculation.Size = New System.Drawing.Size(599, 222)
        Me.gbxCalculation.TabIndex = 37
        Me.gbxCalculation.TabStop = False
        Me.gbxCalculation.Text = "Calculation"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(30, 152)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(35, 13)
        Me.Label9.TabIndex = 43
        Me.Label9.Text = "CPUh"
        '
        'txtCPUh
        '
        Me.txtCPUh.Location = New System.Drawing.Point(82, 149)
        Me.txtCPUh.Name = "txtCPUh"
        Me.txtCPUh.ReadOnly = True
        Me.txtCPUh.Size = New System.Drawing.Size(76, 20)
        Me.txtCPUh.TabIndex = 42
        Me.txtCPUh.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(30, 125)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(53, 13)
        Me.Label8.TabIndex = 41
        Me.Label8.Text = "Instances"
        '
        'nudInstances
        '
        Me.nudInstances.Location = New System.Drawing.Point(96, 123)
        Me.nudInstances.Name = "nudInstances"
        Me.nudInstances.Size = New System.Drawing.Size(62, 20)
        Me.nudInstances.TabIndex = 40
        Me.nudInstances.Tag = "instances"
        Me.nudInstances.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.nudInstances.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(30, 99)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(52, 13)
        Me.Label7.TabIndex = 39
        Me.Label7.Text = "CPU type"
        '
        'cbxCPUtype
        '
        Me.cbxCPUtype.FormattingEnabled = True
        Me.cbxCPUtype.Items.AddRange(New Object() {"dual", "quad", "octa", "hexa"})
        Me.cbxCPUtype.Location = New System.Drawing.Point(96, 96)
        Me.cbxCPUtype.MaxDropDownItems = 5
        Me.cbxCPUtype.Name = "cbxCPUtype"
        Me.cbxCPUtype.Size = New System.Drawing.Size(62, 21)
        Me.cbxCPUtype.TabIndex = 38
        Me.cbxCPUtype.Tag = "CPUtype"
        Me.cbxCPUtype.Text = "quad"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(30, 72)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(61, 13)
        Me.Label6.TabIndex = 37
        Me.Label6.Text = "Runtime (h)"
        '
        'nudHours
        '
        Me.nudHours.Location = New System.Drawing.Point(96, 70)
        Me.nudHours.Maximum = New Decimal(New Integer() {250, 0, 0, 0})
        Me.nudHours.Name = "nudHours"
        Me.nudHours.Size = New System.Drawing.Size(62, 20)
        Me.nudHours.TabIndex = 36
        Me.nudHours.Tag = "Runtime"
        Me.nudHours.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.nudHours.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'txtBHPCrun
        '
        Me.txtBHPCrun.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBHPCrun.Location = New System.Drawing.Point(6, 195)
        Me.txtBHPCrun.Name = "txtBHPCrun"
        Me.txtBHPCrun.Size = New System.Drawing.Size(587, 21)
        Me.txtBHPCrun.TabIndex = 21
        '
        'TabControl
        '
        Me.TabControl.Controls.Add(Me.tpgStart)
        Me.TabControl.Controls.Add(Me.tpbRun)
        Me.TabControl.Controls.Add(Me.tbpSettings)
        Me.TabControl.Location = New System.Drawing.Point(12, 12)
        Me.TabControl.Name = "TabControl"
        Me.TabControl.SelectedIndex = 0
        Me.TabControl.Size = New System.Drawing.Size(947, 681)
        Me.TabControl.TabIndex = 38
        '
        'tpgStart
        '
        Me.tpgStart.Controls.Add(Me.gbxLogIn)
        Me.tpgStart.Controls.Add(Me.gbxCalculation)
        Me.tpgStart.Controls.Add(Me.gbxProjectInfo)
        Me.tpgStart.Location = New System.Drawing.Point(4, 22)
        Me.tpgStart.Name = "tpgStart"
        Me.tpgStart.Padding = New System.Windows.Forms.Padding(3)
        Me.tpgStart.Size = New System.Drawing.Size(939, 655)
        Me.tpgStart.TabIndex = 0
        Me.tpgStart.Text = "Start"
        Me.tpgStart.UseVisualStyleBackColor = True
        '
        'tpbRun
        '
        Me.tpbRun.Location = New System.Drawing.Point(4, 22)
        Me.tpbRun.Name = "tpbRun"
        Me.tpbRun.Padding = New System.Windows.Forms.Padding(3)
        Me.tpbRun.Size = New System.Drawing.Size(939, 655)
        Me.tpbRun.TabIndex = 1
        Me.tpbRun.Text = "Run"
        Me.tpbRun.UseVisualStyleBackColor = True
        '
        'tbpSettings
        '
        Me.tbpSettings.Controls.Add(Me.ckbPowerUserMode)
        Me.tbpSettings.Controls.Add(Me.Label2)
        Me.tbpSettings.Controls.Add(Me.txtexecPath)
        Me.tbpSettings.Location = New System.Drawing.Point(4, 22)
        Me.tbpSettings.Name = "tbpSettings"
        Me.tbpSettings.Size = New System.Drawing.Size(939, 655)
        Me.tbpSettings.TabIndex = 2
        Me.tbpSettings.Text = "Settings"
        Me.tbpSettings.UseVisualStyleBackColor = True
        '
        'ckbPowerUserMode
        '
        Me.ckbPowerUserMode.AutoSize = True
        Me.ckbPowerUserMode.Checked = True
        Me.ckbPowerUserMode.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ckbPowerUserMode.Location = New System.Drawing.Point(57, 101)
        Me.ckbPowerUserMode.Name = "ckbPowerUserMode"
        Me.ckbPowerUserMode.Size = New System.Drawing.Size(81, 17)
        Me.ckbPowerUserMode.TabIndex = 8
        Me.ckbPowerUserMode.TabStop = False
        Me.ckbPowerUserMode.Text = "Power User"
        Me.ckbPowerUserMode.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(54, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(131, 26)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Path to bayer-aws-sso.exe" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and bhpc.exe"
        '
        'ToolTip
        '
        Me.ToolTip.AutomaticDelay = 1000
        Me.ToolTip.IsBalloon = True
        Me.ToolTip.ShowAlways = True
        Me.ToolTip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info
        '
        'cbxPowershell
        '
        Me.cbxPowershell.AutoSize = True
        Me.cbxPowershell.Checked = True
        Me.cbxPowershell.CheckState = System.Windows.Forms.CheckState.Checked
        Me.cbxPowershell.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.cbxPowershell.Location = New System.Drawing.Point(264, 86)
        Me.cbxPowershell.Name = "cbxPowershell"
        Me.cbxPowershell.Size = New System.Drawing.Size(79, 17)
        Me.cbxPowershell.TabIndex = 24
        Me.cbxPowershell.Text = "PowerShell"
        Me.cbxPowershell.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(986, 784)
        Me.Controls.Add(Me.TabControl)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.gbxLogIn.ResumeLayout(False)
        Me.gbxLogIn.PerformLayout()
        Me.gbxProjectInfo.ResumeLayout(False)
        Me.gbxProjectInfo.PerformLayout()
        Me.gbxCalculation.ResumeLayout(False)
        Me.gbxCalculation.PerformLayout()
        CType(Me.nudInstances, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudHours, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl.ResumeLayout(False)
        Me.tpgStart.ResumeLayout(False)
        Me.tbpSettings.ResumeLayout(False)
        Me.tbpSettings.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txt2ndCWID As TextBox
    Friend WithEvents lbl2ndCWID As Label
    Friend WithEvents lblPasswd As Label
    Friend WithEvents txtPasswd As TextBox
    Friend WithEvents cbxPasswdVisible As CheckBox
    Friend WithEvents txtexecPath As TextBox
    Friend WithEvents btnLogin As Button
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents tsslExpiry As ToolStripStatusLabel
    Friend WithEvents Timer As Timer
    Friend WithEvents txtStartPath As TextBox
    Friend WithEvents lblSubSearch As Label
    Friend WithEvents btnScannSub As Button
    Friend WithEvents txtRegEx As TextBox
    Friend WithEvents lblRegEx As Label
    Friend WithEvents btnStartPath As Button
    Friend WithEvents txtRunTile As TextBox
    Friend WithEvents cbxSubSearch As ComboBox
    Friend WithEvents cbxInclSubfolder As CheckBox
    Friend WithEvents tsProgessbar As ToolStripProgressBar
    Friend WithEvents txtBHPCinit As TextBox
    Friend WithEvents lblSessionID As Label
    Friend WithEvents txtSessionID As TextBox
    Friend WithEvents gbxLogIn As GroupBox
    Friend WithEvents gbxProjectInfo As GroupBox
    Friend WithEvents gbxCalculation As GroupBox
    Friend WithEvents txtBHPCrun As TextBox
    Friend WithEvents TabControl As TabControl
    Friend WithEvents tpgStart As TabPage
    Friend WithEvents tpbRun As TabPage
    Friend WithEvents tbpSettings As TabPage
    Friend WithEvents Label2 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents txtCPUh As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents nudInstances As NumericUpDown
    Friend WithEvents Label7 As Label
    Friend WithEvents cbxCPUtype As ComboBox
    Friend WithEvents Label6 As Label
    Friend WithEvents nudHours As NumericUpDown
    Friend WithEvents ckbPowerUserMode As CheckBox
    Friend WithEvents ToolTip As ToolTip
    Friend WithEvents cbxPowershell As CheckBox
End Class
