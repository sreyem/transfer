﻿
Imports System.IO

Public Class frmMain

    Public Sub New()

        underConstruction = True
        InitializeComponent()
        underConstruction = False

        Try
            tsslExpiry.Text = tsslExpiry.Text & My.Settings.lastLogin
        Catch ex As Exception

        End Try

        init()

        test()

    End Sub

    Dim emptyEntry As Color = Color.PapayaWhip
    Dim editEntry As Color = Color.LightYellow

    Private Sub init()

        txt2ndCWID.BackColor = emptyEntry
        txtPasswd.BackColor = emptyEntry
        txtStartPath.BackColor = emptyEntry
        txtSessionID.BackColor = emptyEntry
        cbxSubSearch.BackColor = emptyEntry

        nudHours.BackColor = editEntry
        nudInstances.BackColor = editEntry
        cbxCPUtype.BackColor = editEntry

    End Sub

    Private Sub test()

        'txtStartPath.Text = "X:\RRP2000468"
        txt2ndCWID.Text = "pfyme"
        txtPasswd.Text = "Loriot11Loriot11"

    End Sub

    Public bbs_sso As String = "bayer-aws-sso.exe"
    Public bhpc As String = "bhpc.exe"
    Public waitTime As Integer = 3 * 1000


    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click

        Dim myProcess As New Process

        Dim out As String
        Dim outArray As String()

        Dim smsnumber As String

        Dim SR As System.IO.StreamReader
        Dim SW As System.IO.StreamWriter

        Dim smsDate As Date

        With myProcess

            With .StartInfo

                .FileName =
                    Path.Combine(
                    path1:=txtexecPath.Text,
                    path2:=bbs_sso)

                .WorkingDirectory = txtexecPath.Text

                .Arguments =
                    " --username " & txt2ndCWID.Text &
                    " --password " & txtPasswd.Text

                .RedirectStandardInput = True
                .RedirectStandardOutput = True
                .UseShellExecute = False

                .CreateNoWindow = True
                .WindowStyle = ProcessWindowStyle.Hidden

                .EnvironmentVariables("HTTPS_PROXY") =
                    "http://MVHNG:jA54QWMy@10.185.190.10:8080"

                .EnvironmentVariables("NO_PROXY") =
                    ".bayer.biz,.windowsazure.com"

            End With

            Try

                .Start()

                SR = .StandardOutput
                SW = .StandardInput

                With tsProgessbar

                    .Visible = True
                    .Maximum = 27
                    .Value = 0

                End With


                'wait 3 sec until
                For waitCounter As Integer = 1 To 3

                    Threading.Thread.Sleep(1000)
                    tsProgessbar.Value += 1

                Next

                '... until 'dev environment = 0'
                ' Please Choose the Account you would Like to access
                '     [0] Account AWS proutt4aws - dev(579321376818)
                '     [1] Account: AWS proutt4aws - prd(126183243897)
                SW.WriteLine("0")

                smsDate = Now

                'wait 3 sec until
                For waitCounter As Integer = 1 To 3

                    Threading.Thread.Sleep(1000)
                    tsProgessbar.Value += 1

                Next

                '... ask for 2nd factor sms
                smsnumber =
                    InputBox(
                    Prompt:="SMS number for 2 factor authentication" & vbCrLf &
                            "Please choose a code send later than  " & smsDate.AddMinutes(-1).ToShortTimeString,
                    Title:="Number send by SMS, 6 digits")

                Do While smsnumber.Length <> 6

                    If MsgBox(
                    Prompt:="SMS number has to be 6 digits, but you typed " & vbCrLf &
                            smsnumber & vbCrLf &
                            "Please re-enter the number send to you via sms number ") <> MsgBoxResult.Yes Then

                        SW.Close()
                        SR.Close()
                        tsProgessbar.Visible = False

                        Exit Sub

                    Else

                        smsnumber =
                    InputBox(
                    Prompt:="SMS number for 2 factor authentication" & vbCrLf &
                            "Please choose a code send later than  " & smsDate.AddMinutes(-1).ToShortTimeString,
                    Title:="Number send by SMS, 6!!!! digits")

                    End If

                Loop

                'Selection: Two-Factor authentication is enabled using OneWaySMS.
                '           Please Enter the code from your device now. 
                SW.WriteLine(smsnumber)

                'wait 20 sec for exit of sso
                For waitCounter As Integer = 1 To 20

                    If Not .HasExited Then
                        Threading.Thread.Sleep(1000)
                        tsProgessbar.Value += 1
                    Else
                        tsProgessbar.Value = 0
                        tsProgessbar.Visible = False
                        Exit For
                    End If

                    'both tenant or 'normal' user?
                    'Please Choose the role you would Like to assume: 
                    '[0] (579321376818) Account/Role proutt4aws-dev / dev - user
                    '[1] (579321376818) Account/Role: proutt4aws-dev / smbc - tenant - admin
                    If waitCounter = 4 Then
                        If ckbPowerUserMode.Checked Then
                            'tenant
                            SW.WriteLine("1")
                        Else
                            'normal user
                            SW.WriteLine("0")
                        End If
                    End If

                Next

                If Not .HasExited Then

                    If MsgBox(
                        Prompt:="bayer-sso.exe stil running wait another 20 sec.?",
                        Buttons:=MsgBoxStyle.YesNo) = MsgBoxResult.No Then

                        SW.Close()
                        SR.Close()
                        tsProgessbar.Visible = False

                        Exit Sub

                    Else

                        tsProgessbar.Maximum += 21

                        'wait 20 sec for exit of sso
                        For waitCounter As Integer = 1 To 20

                            If Not .HasExited Then
                                Threading.Thread.Sleep(1000)
                                tsProgessbar.Value += 1
                            Else
                                tsProgessbar.Value = 0
                                tsProgessbar.Visible = False
                                Exit For
                            End If

                        Next

                    End If

                End If


                'get output and write to file, show if exit code <> 0
                out = SR.ReadToEnd

                Try
                    out &= vbCrLf & "ExitCode = " & .ExitCode.ToString
                Catch ex As Exception

                End Try

                File.WriteAllText(
                    path:=
                        Path.Combine(
                            path1:=Environment.CurrentDirectory,
                            path2:="sso.txt"),
                    contents:=out)

                If Not .HasExited Then .Kill()

                If .ExitCode <> 0 Then

                    Process.Start(
                        Path.Combine(
                            path1:=Environment.CurrentDirectory,
                            path2:="sso.txt"))

                    SW.Close()
                    SR.Close()
                    tsProgessbar.Visible = False

                    Exit Sub

                End If

                'get expiry date ...
                outArray = out.Split(vbCrLf)

                out =
                    Filter(
                    Source:=outArray,
                    Match:="NOTE",
                    Include:=True,
                    Compare:=CompareMethod.Text).First

                outArray = out.Split

                '... and write into status
                Try

                    My.Settings.lastLogin = outArray(outArray.Count - 2) & " at " &
                                            outArray(outArray.Count - 1).Split("+").First

                    tsslExpiry.Text = tsslExpiry.Tag.ToString & My.Settings.lastLogin

                Catch ex As Exception

                End Try

                'MsgBox(
                '    Prompt:="Login to AWS successful, auto - logout in 6h" & vbCrLf &
                '     "   on " & Now.AddHours(6).ToLongDateString & vbCrLf &
                '     "   at " & Now.AddHours(6).ToLongTimeString,
                '    Buttons:=MsgBoxStyle.Information)

            Catch ex As Exception

                MsgBox(Prompt:="Login to AWS failed!" & vbCrLf &
                               ex.Message,
                       Buttons:=MsgBoxStyle.Critical)

            Finally

                SW.Close()
                SR.Close()
                tsProgessbar.Visible = False

            End Try

        End With

    End Sub

    Private Sub Timer_Tick(sender As Object, e As EventArgs) Handles Timer.Tick

        Dim ticks As New Date

    End Sub

    Private Sub cbxPasswdVisible_CheckedChanged(sender As Object, e As EventArgs) Handles cbxPasswdVisible.CheckedChanged

        If cbxPasswdVisible.Checked Then
            txtPasswd.PasswordChar = vbNullChar
        Else
            txtPasswd.PasswordChar = "*"
        End If

    End Sub

    Private Sub cbxSubSearch_Changed(sender As Object, e As EventArgs) Handles _
        cbxSubSearch.SelectedIndexChanged,
        cbxSubSearch.TextChanged

        Dim temp As String = cbxSubSearch.Text

        temp =
            Replace(
                Expression:=temp,
                Find:=".",
                Replacement:="\.",
                Compare:=CompareMethod.Text)

        temp =
            Replace(
                Expression:=temp,
                Find:="*",
                Replacement:=".*",
                Compare:=CompareMethod.Text)

        txtRegEx.Text = temp

        If cbxSubSearch.Text = "" Then
            cbxSubSearch.BackColor = emptyEntry
        Else
            cbxSubSearch.BackColor = editEntry
        End If


        updateBHPCinit()

    End Sub

    Private Sub btnStartPath_Click(sender As Object, e As EventArgs) Handles btnStartPath.Click

        Dim fbd As New FolderBrowserDialog

        With fbd

            .ShowNewFolderButton = False
            .Description = "Please select the start path of your project"

            If txtStartPath.Text <> "" Then
                If Directory.Exists(txtStartPath.Text) Then .SelectedPath = txtStartPath.Text
            ElseIf New DriveInfo(driveName:="X:").IsReady Then
                .SelectedPath = "X:\"
            End If

            If .ShowDialog <> DialogResult.OK Then Exit Sub

            If Directory.Exists(.SelectedPath) Then
                txtStartPath.Text = .SelectedPath
            End If

        End With


    End Sub


    Public macroMetabRuns As Integer = 0
    Public runOffRuns As Integer = 0
    Public macroRuns As Integer = 0
    Public txwRuns As Integer = 0
    Public step04Run As Integer = 0
    Public pearlRun As Integer = 0
    Public runCounter As Integer = 0
    Public totalRunTime As Integer = 0

    Public runtimeMacro As Integer = 15
    Public runtimeMacroMetabolite As Integer = 30
    Public runtimeToxswa As Integer = 10
    Public runtimePEARL As Integer = 20
    Public costPerCPU As Double = 0.15

    Private Sub btnScannSub_Click(sender As Object, e As EventArgs) Handles btnScannSub.Click

        Dim subFilePaths As String() = {}

        Dim subFile As String() = {}
        Dim temp As Integer = 0
        Dim out As New List(Of String)
        Dim summary As String = ""
        Dim macroMetabRuns As Integer = 0
        Dim macroRuns As Integer = 0
        Dim txwRuns As Integer = 0
        Dim step04Run As Integer = 0
        Dim pearlRun As Integer = 0

        Dim runMACRO As Double = 0
        Dim runtoxswa As Double = 0
        Dim timeFormat As String = "dd:hh:mm"
        Dim GAPcounter As Integer

        Me.macroMetabRuns = 0
        Me.runOffRuns = 0
        Me.macroRuns = 0
        Me.txwRuns = 0
        Me.step04Run = 0
        Me.pearlRun = 0
        Me.totalRunTime = 0
        Me.runCounter = 0

        Dim submitFiles =
            IO.Directory.EnumerateFiles(
            path:=txtStartPath.Text,
            searchPattern:=cbxSubSearch.Text,
            searchOption:=IO.SearchOption.AllDirectories)



        Application.DoEvents()


        For Each submitFilePath As String In submitFiles

        Next


        If txtStartPath.Text = "" Then

            MsgBox(
               Prompt:="Please enter project start path",
               Buttons:=MsgBoxStyle.Exclamation,
               Title:="Project start path is missing")

            txtStartPath.Select()

            Exit Sub

        End If

        If cbxSubSearch.Text = "" Then

            MsgBox(
                Prompt:="Please enter or select submit file search pattern",
                Buttons:=MsgBoxStyle.Exclamation,
                Title:="Search pattern is missing")

            cbxSubSearch.Select()

            Exit Sub

        End If

        'Dim submitFiles =
        '    IO.Directory.EnumerateFiles(
        '    path:=txtStartPath.Text,
        '    searchPattern:=cbxSubSearch.Text,
        '    searchOption:=IO.SearchOption.AllDirectories)



        Application.DoEvents()


        For Each submitFilePath As String In submitFiles

        Next



        subFilePaths =
            Directory.GetFiles(
            path:=txtStartPath.Text,
            searchPattern:=cbxSubSearch.Text,
            searchOption:=
                IIf(
                    Expression:=cbxInclSubfolder.Checked,
                    TruePart:=SearchOption.AllDirectories,
                    FalsePart:=SearchOption.TopDirectoryOnly))

        If subFilePaths.Count = 0 Then

            MsgBox(
                Prompt:="No submit files found matching the search pattern",
                Buttons:=MsgBoxStyle.Critical,
                Title:="Wrong input? (start path, search pattern, only start path to search?)")

            Exit Sub

        End If

        For Each subFilePath As String In subFilePaths

            Try

                subFile = File.ReadAllLines(subFilePath)

                runCounter +=
                    Filter(
                        Source:=subFile,
                        Match:="Queue",
                        Include:=True,
                        Compare:=CompareMethod.Text).Count

                'MACRO runs
                'metabolite runs?
                macroMetabRuns =
                    Filter(
                    Source:=subFile,
                    Match:="metab",
                    Include:=True,
                    Compare:=CompareMethod.Text).Count

                Me.macroMetabRuns += macroMetabRuns

                If macroMetabRuns = 0 Then

                    'or parent MACRO runs
                    macroRuns =
                            Filter(
                            Source:=subFile,
                            Match:=".par",
                            Include:=True,
                            Compare:=CompareMethod.Text).Count

                    Me.macroRuns += macroRuns

                End If


                If macroRuns = 0 AndAlso macroMetabRuns = 0 Then

                    step04Run =
                       Filter(
                       Source:=
                            Filter(
                            Source:=subFile,
                            Match:="#",
                            Include:=False,
                            Compare:=CompareMethod.Text),
                       Match:=".txw",
                       Include:=True,
                       Compare:=CompareMethod.Text).Count

                    Me.step04Run += step04Run

                Else

                    'step03 toxswa runs
                    txwRuns =
                       Filter(
                       Source:=
                            Filter(
                            Source:=subFile,
                            Match:="#",
                            Include:=False,
                            Compare:=CompareMethod.Text),
                       Match:=".txw",
                       Include:=True,
                       Compare:=CompareMethod.Text).Count

                    Me.txwRuns += txwRuns

                End If

                pearlRun =
                    Filter(
                    Source:=
                        Filter(
                            Source:=subFile,
                            Match:="Arguments",
                            Include:=True,
                            Compare:=CompareMethod.Text),
                    Match:=".prl",
                    Include:=True,
                    Compare:=CompareMethod.Text).Count

                Me.pearlRun += pearlRun


            Catch ex As Exception

            End Try

        Next

        Dim duration As New TimeSpan

        If Me.macroMetabRuns <> 0 Then

            duration = New TimeSpan(0, runtimeMacroMetabolite * Me.macroMetabRuns, 0)

            out.Add("MACRO metab.  runs : " &
                   Me.macroMetabRuns.ToString(IIf(
                                            Expression:=Me.macroMetabRuns < 100,
                                            TruePart:="  00",
                                            FalsePart:=" 000")) &
                                            " = " & duration.ToString.PadLeft("00.00:00:00".Length))

            totalRunTime += runtimeMacroMetabolite * Me.macroMetabRuns

        ElseIf Me.macroRuns <> 0 Then

            duration = New TimeSpan(0, runtimeMacro * Me.macroRuns, 0)

            out.Add("MACRO parent  runs : " &
                   Me.macroRuns.ToString(IIf(
                                            Expression:=Me.macroRuns < 100,
                                            TruePart:="  00",
                                            FalsePart:=" 000")) &
                                            " = " & duration.ToString.PadLeft("00.00:00:00".Length))

            totalRunTime += runtimeMacro * Me.macroRuns

        End If

        If Me.txwRuns <> 0 Then

            duration = New TimeSpan(0, runtimeToxswa * Me.txwRuns, 0)

            out.Add("Step03 TOXSWA runs : " &
                  Me.txwRuns.ToString(IIf(
                                           Expression:=Me.txwRuns < 100,
                                           TruePart:="  00",
                                           FalsePart:=" 000")) &
                                           " = " & duration.ToString.PadLeft("00.00:00:00".Length))

            totalRunTime += runtimeToxswa * Me.txwRuns

        End If

        If Me.step04Run <> 0 Then

            duration = New TimeSpan(0, runtimeToxswa * Me.step04Run, 0)

            out.Add("Step04 TOXSWA runs : " &
                  Me.step04Run.ToString(IIf(
                                           Expression:=Me.step04Run < 1000,
                                           TruePart:=" 000",
                                           FalsePart:="0000")) &
                                           " = " & duration.ToString.PadLeft("00.00:00:00".Length))

            totalRunTime += runtimeToxswa * Me.step04Run

        End If

        If Me.pearlRun <> 0 Then

            duration = New TimeSpan(0, runtimePEARL * Me.pearlRun, 0)

            out.Add("FOCUS PEARL  runs : " &
                  Me.pearlRun.ToString(IIf(
                                           Expression:=Me.pearlRun < 100,
                                           TruePart:="  00",
                                           FalsePart:="0000")) &
                                           " = " & duration.ToString.PadLeft("00.00:00:00".Length))

            totalRunTime += runtimePEARL * Me.pearlRun

        End If

        out.Add("-".PadLeft(out.Last.Length, paddingChar:=("-")))



        out.Add(subFilePaths.Count.ToString(" 000") & " submit files")

        GAPcounter = 0
        For Each member As String In subFilePaths

            If Path.GetDirectoryName(member).EndsWith("01") Then
                GAPcounter += 1
            End If

        Next


        summary = runCounter.ToString("0000") & " runs in " & GAPcounter & " GAPs"

        duration = New TimeSpan(0, totalRunTime, 0)


        out.Add(summary.PadRight(("FOCUS PEARL  runs : " &
                   pearlRun.ToString(IIf(
                                           Expression:=pearlRun < 100,
                                           TruePart:="  00",
                                           FalsePart:=" 000")) &
                                           " =  ").Length) & duration.ToString.PadLeft("00.00:00:00".Length))
        summary = "cost estimate for " & Math.Round(totalRunTime / 60, 0) + 1 & " CPUh"

        out.Add(summary.PadRight(("FOCUS PEARL  runs : " &
                   pearlRun.ToString(IIf(
                                           Expression:=pearlRun < 100,
                                           TruePart:="  00",
                                           FalsePart:=" 000")) &
                                           " =  ").Length) & (duration.TotalHours * costPerCPU).ToString("C"))

        out.Add("-".PadLeft(out.Last.Length, paddingChar:=("-")))

        Dim CPUhours As Integer

        If Me.macroMetabRuns <> 0 Then

            'Me.txwRuns = Me.txwRuns - Me.macroMetabRuns

            runtimeMacroMetabolite = Me.macroMetabRuns * runtimeMacroMetabolite

            CPUhours += Me.macroMetabRuns / (60 / runtimeMacroMetabolite)

        End If

        If Me.macroRuns <> 0 Then

            'Me.txwRuns = Me.txwRuns - Me.macroRuns

            CPUhours += Me.macroRuns / (60 / runtimeMacro)

        End If

        If Me.txwRuns <> 0 Then
            CPUhours += Me.txwRuns / (60 / runtimeToxswa)
        End If

        If Me.step04Run <> 0 Then
            CPUhours += Me.step04Run / (60 / runtimeToxswa)
        End If

        If Me.pearlRun <> 0 Then
            CPUhours += Me.pearlRun / (60 / runtimePEARL)
        End If




        'out.Add("Runtime = " & hours & "h")
        'out.Add((Math.Round(CPUhours / 2, 0) + 1).ToString.PadRight(4) & " *  c5.large   (Dual Core)")
        'out.Add((Math.Round(CPUhours / 4, 0) + 1).ToString.PadRight(4) & " *  c5.xlarge  (Quad Core)")
        'out.Add((Math.Round(CPUhours / 8, 0) + 1).ToString.PadRight(4) & " *  c5.2xlarge (Octa Core)")


        'out.Add("Normal runtime, 2h")
        'out.Add((Math.Round(CPUhours / 4, 0) + 1).ToString.PadRight(4) & " *  c5.large   (Dual Core)")
        'out.Add((Math.Round(CPUhours / 8, 0) + 1).ToString.PadRight(4) & " *  c5.xlarge  (Quad Core)")
        'out.Add((Math.Round(CPUhours / 16, 0) + 1).ToString.PadRight(4) & " *  c5.2xlarge (Octa Core)")

        'out.Add("Fast, 1h runtime")
        'out.Add((Math.Round(CPUhours / 2, 0) + 1).ToString.PadRight(4) & " *  c5.large   (Dual Core)")
        'out.Add((Math.Round(CPUhours / 4, 0) + 1).ToString.PadRight(4) & " *  c5.xlarge  (Quad Core)")
        'out.Add((Math.Round(CPUhours / 8, 0) + 1).ToString.PadRight(4) & " *  c5.2xlarge (Octa Core)")
        'out.Add("EMERGENYC, one CPU per run")
        'out.Add((Math.Round(runCounter / 2, 0) + 1).ToString.PadRight(4) & " *  c5.large   (Dual Core)")
        'out.Add((Math.Round(runCounter / 4, 0) + 1).ToString.PadRight(4) & " *  c5.xlarge  (Quad Core)")
        'out.Add((Math.Round(runCounter / 8, 0) + 1).ToString.PadRight(4) & " *  c5.2xlarge (Octa Core)")

        txtRunTile.Text = Join(out.ToArray, vbCrLf)

        updateCPUCount()
        updateHourCount()

        updateBHPCrun()
        updateBHPCinit()

    End Sub

    Public Enum eCPUtype
        dual = 2
        quad = 4
        octa = 8
        hexa = 16
    End Enum

    Public CPUtype As String() =
        {"", "c5.large", "c5.xlarge", "c5.2xlarge", "c5.4xlarge"}

    Private Sub txtStartPath_TextChanged(sender As Object, e As EventArgs) Handles txtStartPath.DoubleClick

        Process.Start("Explorer.exe", txtStartPath.Text)

    End Sub

    Private Sub txtSessionID_TextChanged(sender As Object, e As EventArgs) Handles txtSessionID.TextChanged

        If txtSessionID.Text.Length > 7 Then

            txtSessionID.Text = txtSessionID.Text.Substring(0, 7)

            MsgBox(
                Prompt:="Max lenght = 7",
                Buttons:=MsgBoxStyle.OkOnly,
                Title:="Input restriction")

        End If

        updateBHPCinit()
        updateBHPCrun()

    End Sub

    Private Sub txtStartPath_TextChanged_1(sender As Object, e As EventArgs) Handles txtStartPath.TextChanged
        updateBHPCinit()
    End Sub

    Private Sub updateBHPCinit()


        Dim temp As String = "bhpc.exe init "

        If cbxPowershell.Checked Then
            temp = ".\ " & temp
        End If

        temp &= "-path " & txtStartPath.Text & " -search "

        If cbxSubSearch.Text.Contains("*") Then
            temp &= txtRegEx.Text
        Else
            temp &= cbxSubSearch.Text
        End If

        If txtSessionID.Text <> "" Then
            temp &= " " & Environment.UserName.ToUpper & "-" & txtSessionID.Text
        Else
            temp &= " SessionID"
        End If

        txtBHPCinit.Text = temp

    End Sub

    Private Sub txtBHPCinit_TextChanged(sender As Object, e As EventArgs) Handles txtBHPCinit.TextChanged

        If txtBHPCinit.Text.Length = 0 Then
            Return
        End If

        Exit Sub

        Dim height As Single = txtBHPCinit.Height * 0.99F
        Dim width As Single = txtBHPCinit.Width * 0.99F
        txtBHPCinit.SuspendLayout()
        Dim tryFont As Font = txtBHPCinit.Font
        Dim tempSize As Size = TextRenderer.MeasureText(txtBHPCinit.Text, tryFont)
        Dim heightRatio As Single = height / tempSize.Height
        Dim widthRatio As Single = width / tempSize.Width
        tryFont = New Font(tryFont.FontFamily, tryFont.Size * Math.Min(widthRatio, heightRatio), tryFont.Style)
        txtBHPCinit.Font = tryFont
        txtBHPCinit.ResumeLayout()

    End Sub

    Private Sub updateCPUCount()

        Dim temp As Double = 1
        Dim CPUtype As eCPUtype

        'If cbxCPUtypeA.Text = "" Then Exit Sub
        ''totalRunTime = 22900

        'Try
        '    CPUtype = [Enum].Parse(GetType(eCPUtype), cbxCPUtypeA.Text)
        '    temp = (totalRunTime / 60) / (CPUtype * nudHoursA.Value)
        '    txtCPUCountA.Text = Math.Floor(temp) + 1

        '    If Not IsNothing(lblCPUhA.Tag) Then
        '        lblCPUhA.Text =
        '            lblCPUhA.Tag.ToString &
        '            (CPUtype * nudHoursA.Value * (Math.Floor(temp) + 1)).ToString

        '    End If

        'Catch ex As Exception

        'End Try

        updateBHPCrun()

    End Sub


    Private Sub nudHours_ValueChanged(sender As Object, e As EventArgs)
        updateCPUCount()
    End Sub

    Private Sub cbxCPUtype_SelectedIndexChanged(sender As Object, e As EventArgs)
        updateCPUCount()
    End Sub


    Private Sub updateHourCount()

        Dim temp As Double
        Dim CPUtype As eCPUtype

        'If cbxCPUtypeB.Text = "" Then Exit Sub
        ''totalRunTime = 22900

        'Try
        '    CPUtype = [Enum].Parse(GetType(eCPUtype), cbxCPUtypeB.Text)
        '    temp = (totalRunTime / 60) / (CPUtype * nudCPUsB.Value)
        '    txtHourCountB.Text = Math.Floor(temp) + 1

        '    If Not IsNothing(lblCPUhB.Tag) Then
        '        lblCPUhB.Text =
        '            lblCPUhB.Tag.ToString &
        '            (CPUtype * nudCPUsB.Value * (Math.Floor(temp) + 1)).ToString

        '    End If

        'Catch ex As Exception

        'End Try

        updateBHPCrun()


    End Sub

    Private Sub nudCPUs_ValueChanged(sender As Object, e As EventArgs)
        updateHourCount()
    End Sub

    Private Sub cbxCPUtypeHourCount_SelectedIndexChanged(sender As Object, e As EventArgs)
        updateHourCount()
    End Sub

    Private Sub rbtnHours_CheckedChanged(sender As Object, e As EventArgs)
        updateBHPCrun()
    End Sub


    Private underConstruction As Boolean = False

    Private Sub runCalc_Changed(sender As Object, e As EventArgs) Handles _
        nudHours.ValueChanged, cbxCPUtype.SelectedIndexChanged, nudInstances.ValueChanged

        If underConstruction Then Exit Sub
        updateRunCalc(sender:=sender)

    End Sub

    Private Sub updateRunCalc(sender As Object)

        Dim CPUtype As eCPUtype
        Dim CPUhPercent As Integer = 100

        'totalRunTime = 22900

        underConstruction = True

        CPUtype = [Enum].Parse(GetType(eCPUtype), cbxCPUtype.Text)

        Select Case sender.tag.ToString

            Case "Runtime"
                Me.nudInstances.Value = Math.Round((totalRunTime / 60) / (CPUtype * nudHours.Value), 0) + 1

            Case "CPUtype"
                Me.nudInstances.Value = Math.Round((totalRunTime / 60) / (CPUtype * nudHours.Value), 0) + 1

            Case "instances"
                Me.nudHours.Value = Math.Round((totalRunTime / 60) / (nudInstances.Value * CPUtype), 0) + 1

        End Select

        Me.txtCPUh.Text = CPUtype * Me.nudInstances.Value * nudHours.Value &
                    " ( + " & Math.Round((CPUtype * Me.nudInstances.Value * nudHours.Value) / (totalRunTime / 60) * 100, 0) - 100 & "%)"

        underConstruction = False

        updateBHPCrun()

    End Sub

    Private Sub updateBHPCrun()

        Dim temp As String = "bhpc.exe run "
        Dim CPUType As String

        If cbxPowershell.Checked Then
            temp = ".\ " & temp
        End If

        Select Case cbxCPUtype.Text

            Case "dual"
                CPUType = "c5.large"
            Case "quad"
                CPUType = "c5.xlarge"
            Case "octa"
                CPUType = "c5.2xlarge"
            Case "hexa"
                CPUType = "c5.4xlarge"
            Case Else
                CPUType = "c5.large"

        End Select

        temp &= "-type " & CPUType
        temp &= " -count " & nudInstances.Value


        If txtSessionID.Text <> "" Then
            temp &= " " & Environment.UserName.ToUpper & "-" & txtSessionID.Text
        Else
            temp &= " SessionID"
        End If

        txtBHPCrun.Text = temp

    End Sub

    Private Sub txt2ndCWID_TextChanged(sender As Object, e As EventArgs) Handles txt2ndCWID.TextChanged

        'txt2ndCWID.Text = txt2ndCWID.Text.ToUpper

        If txt2ndCWID.Text.Length >= 5 Then
            checkEntry(txt2ndCWID, False)
        Else
            checkEntry(txt2ndCWID, True)
        End If
    End Sub

    Private Sub txtPasswd_TextChanged(sender As Object, e As EventArgs) Handles txtPasswd.TextChanged

        If txtPasswd.Text.Length > 12 Then
            txtPasswd.BackColor = editEntry
        Else
            txtPasswd.BackColor = emptyEntry
        End If

    End Sub

    Private Sub txtStartPath_Leave(sender As Object, e As EventArgs) Handles txtStartPath.Leave

        With txtStartPath
            If Directory.Exists(.Text) Then
                checkEntry(txtStartPath, False)
            Else
                checkEntry(txtStartPath, True)
            End If
        End With


    End Sub


    Public Sub checkEntry(ByRef txtbox As TextBox, wrong As Boolean)

        With txtbox

            If wrong Then
                .ForeColor = Color.Red
                .BackColor = emptyEntry
            Else
                .BackColor = editEntry
                .ForeColor = Color.Black
            End If

        End With

    End Sub

    Private Sub cbxPowershell_CheckedChanged(sender As Object, e As EventArgs) Handles cbxPowershell.CheckedChanged

        updateBHPCrun()
        updateBHPCinit()


    End Sub
End Class


