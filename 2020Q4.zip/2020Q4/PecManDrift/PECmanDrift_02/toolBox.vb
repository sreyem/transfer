﻿
Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Design
Imports System.Globalization
Imports System.Reflection
Imports System.Threading
Imports System.Windows.Forms
Imports System.Windows.Forms.Design
Imports System.IO
Imports Microsoft.Win32
Imports System.Management


#Region "toolBox"

#Region "propGrid"

''' <summary>
''' TypeConverter(GetType(propGridConverter))
''' Make a class brows-able in the property grid
''' Name property should be defined!
''' </summary>
Public Class propGridConverter

    'usage : <TypeConverter(GetType(propGridConverter))>

    Inherits ExpandableObjectConverter

    'test

#Region "    Engine"

    <DebuggerStepThrough>
    Public Overloads Overrides Function CanConvertTo(
                                                ByVal context As ITypeDescriptorContext,
                                                ByVal destinationType As Type) As Boolean
        Try

            If (destinationType Is GetType(propGridConverter)) Then
                Return True
            End If

        Catch ex As Exception

        End Try

        Return MyBase.CanConvertTo(
                                context,
                                destinationType)

    End Function

    <DebuggerStepThrough>
    Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

        If (destinationType Is GetType(System.String)) Then

            Try

                Return CallByName(
                                value,
                                "Name",
                                CallType.Get)

            Catch ex As Exception
                Return " ... "
            End Try

        End If

        Return MyBase.ConvertTo(
                            context,
                            culture,
                            value,
                            destinationType)

    End Function

#End Region

End Class

''' <summary>
''' Show enum descriptions
''' TypeConverter(GetType(EnumConverter(of enumType))
''' </summary>
''' <typeparam name="T">
''' enum type
''' </typeparam>
Public Class enumConverter(Of T)

    'usage :  <TypeConverter(GetType(EnumConverter(of <Type>))>

    Inherits EnumConverter

    Public Const not_defined As String = " - "


    '' <summary>
    '' Initializing instance
    '' </summary>       
    '' <remarks></remarks>
    Public Sub New()
        MyBase.New(GetType(T))
    End Sub

    ''' <summary>
    ''' don't show enum members with this description
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property dontShow As String() = {}

    ''' <summary>
    ''' only show enum members with this description
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property onlyShow As String() = {}


    Public Shared no2Show As Integer = -1

#Region "    Engine"

    Public Overrides Function CanConvertTo(context As ITypeDescriptorContext, destType As Type) As Boolean
        Return destType = GetType(String)
    End Function

    Public Overrides Function ConvertTo(
                                    context As ITypeDescriptorContext,
                                    culture As CultureInfo,
                                    value As Object,
                                    destType As Type) As Object

        Dim fi As FieldInfo = GetType(T).GetField([Enum].GetName(GetType(T), value))
        Dim dna As DescriptionAttribute = DirectCast(
            Attribute.GetCustomAttribute(fi, GetType(DescriptionAttribute)), DescriptionAttribute)

        If dna IsNot Nothing Then

            If no2Show > -1 And dna.Description.Split(vbLf).Count > no2Show Then
                Return dna.Description.Split(vbLf)(no2Show).Split(vbCr).First
            Else
                Return dna.Description
            End If

        Else
            Return value.ToString()
        End If

    End Function

    Public Overrides Function CanConvertFrom(
                                            context As ITypeDescriptorContext,
                                            srcType As Type) As Boolean
        Return srcType = GetType(String)
    End Function

    Public Overrides Function ConvertFrom(
                                    context As ITypeDescriptorContext,
                                    culture As CultureInfo,
                                    value As Object) As Object

        Dim found As Boolean = False

        For Each member As String In dontShow

            If CStr(value).Contains(member) Then
                value = not_defined
            End If

        Next


        If onlyShow.Count <> 0 Then

            For Each member As String In onlyShow
                If CStr(value).Contains(member) Then
                    found = True
                    Exit For
                End If
            Next

            If Not found Then
                value = not_defined
            End If

        End If


        For Each fi As FieldInfo In GetType(T).GetFields()

            Dim dna As DescriptionAttribute =
                DirectCast(
                        Attribute.GetCustomAttribute(
                                element:=fi,
                                attributeType:=GetType(DescriptionAttribute)),
                        DescriptionAttribute)

            If (dna IsNot Nothing) AndAlso
                    (dna.Description).Contains(DirectCast(value, String)) Then
                '(DirectCast(value, String).Contains(dna.Description)) Then
                Return [Enum].Parse(GetType(T), fi.Name)
            End If

        Next

        Return [Enum].Parse(GetType(T), DirectCast(value, String))

    End Function

#End Region

    ''' <summary>
    ''' returns the enum description
    ''' </summary>
    ''' <param name="EnumConstant"></param>
    ''' <returns></returns>
    <DebuggerStepThrough>
    Public Shared Function getEnumDescription(ByVal EnumConstant As [Enum]) As String

        Dim fi As FieldInfo =
            EnumConstant.GetType().GetField(EnumConstant.ToString())

        Dim attr() As DescriptionAttribute =
                      DirectCast(fi.GetCustomAttributes(GetType(DescriptionAttribute),
                      False), DescriptionAttribute())

        If attr.Length > 0 Then
            Return attr(0).Description
        Else
            Return EnumConstant.ToString()
        End If

    End Function

End Class


''' <summary>
''' double to string converter
''' AttributeProvider(
''' format , minValue , unit , country , minSign , digits , negDef  
''' </summary>
Public Class dblConv

    Inherits DoubleConverter

    'usage : 
    '<TypeConverter(GetType(dblConvPara))>
    '<AttributeProvider("format= 'G5'|unit=' kg/ha'")>

#Region "    get/set parameters"

    Public Shared Function getDblParameter(context As ITypeDescriptorContext) As String()

        Dim Attributes As AttributeCollection
        Dim Provider As AttributeProviderAttribute

        Dim formatArray As String() = {}

        Try

            With context

                Attributes = .PropertyDescriptor.Attributes

                For Each attribute In Attributes

                    If attribute.ToString =
                        "System.ComponentModel.AttributeProviderAttribute" Then

                        Provider = attribute
                        formatArray = Provider.TypeName.Split("|")

                    End If

                Next

            End With
        Catch ex As Exception

        End Try

        For counter As Integer = 0 To formatArray.Count - 1
            formatArray(counter) = Trim(formatArray(counter))
        Next

        Return formatArray

    End Function

    Public Shared Sub setDblParameters(formatArray As String())

        Dim parameterValue As String()

        setStd()

        For Each member As String In formatArray

            parameterValue = member.Split("=")
            parameterValue(0) = Trim(parameterValue(0))
            parameterValue(1) = parameterValue(1).Split("'")(1)

            Select Case parameterValue.First

                Case "format"
                    dblformat = parameterValue.Last

                Case "country"

                    Try
                        country =
                            [Enum].Parse(
                            enumType:=GetType(eCountry),
                            value:=parameterValue.Last)
                    Catch ex As Exception
                        country = stdCountry
                    End Try

                Case "minSign"
                    minSign = parameterValue.Last

                Case "minValue"
                    minValue = parameterValue.Last

                Case "digits"
                    digits = parameterValue.Last

                Case "negDef"
                    negDef = parameterValue.Last

                Case "unit"
                    unit = parameterValue.Last

            End Select

        Next

    End Sub

    Public Shared Sub setStd()

        country = stdCountry
        dblformat = stdDblformat
        emptyString = stdEmptyString
        minSign = stdMinSign
        minValue = stdMinValue
        digits = stdDigits
        unit = ""
        negDef = stdnegDef

    End Sub

#End Region

#Region "    engine"

    <DebuggerStepThrough>
    Public Overrides Function ConvertTo(
                            context As ITypeDescriptorContext,
                            culture As CultureInfo,
                            value As Object,
                            destType As Type) As Object


        setDblParameters(formatArray:=getDblParameter(context:=context))

        Try

            Return _
              conv2String(
                    value:=value,
                    format:=dblformat,
                    country:=country,
                    minSign:=minSign,
                    minValue:=minValue,
                    unit:=unit,
                    digits:=digits,
                    negativeDefined:=negDef)

        Catch ex As Exception
            Return value
        End Try

    End Function

    <DebuggerStepThrough>
    Public Overrides Function ConvertFrom(
                            context As ITypeDescriptorContext,
                            culture As CultureInfo,
                            value As Object) As Object

        Dim valueString As String

        Try

            valueString = CType(value, String)

            If valueString.Contains(minSign) Then
                Return minValue
            ElseIf Double.IsNaN(Double.Parse(valueString)) Then
                Return Double.NaN
            Else
                Return Double.Parse(valueString)
            End If

        Catch ex As Exception
            Return Double.NaN
        End Try

    End Function

#End Region

#Region "    functions"

    Public Shared Function conv2String(
                                 value As Double,
                        Optional format As String = stdDblformat,
                        Optional country As eCountry = stdCountry,
                        Optional minValue As Double = stdMinValue,
                        Optional minSign As String = stdMinSign,
                        Optional digits As Integer = stdDigits,
                        Optional unit As String = stdUnit,
                        Optional negativeDefined As Boolean = stdnegDef) As String

        Dim countryString As String

        countryString =
                    Replace(
                    Expression:=country.ToString,
                    Find:="_", Replacement:="-",
                    Compare:=CompareMethod.Text)

        If value < 0 And Not negativeDefined Then
            Return stdEmptyString
        End If

        If Not Double.IsNaN(minValue) AndAlso value < minValue Then
            Return minSign & minValue.ToString & unit
        End If

        If Double.IsNaN(Double.Parse(value)) Then
            Return stdEmptyString
        End If

        Try

            If digits > -1 Then

                value =
                    Math.Round(
                        value,
                        digits:=digits)

            End If

            Return value.ToString(
                              format:=format,
                            provider:=CultureInfo.CreateSpecificCulture(countryString)) & unit

        Catch ex As Exception

            Console.WriteLine("error converting double to string")
            Return ex.Message

        End Try

    End Function

#End Region

#Region "    definitions"

    Public Enum eCountry
        de_DE
        en_US
        fr_FR
    End Enum

#Region "    shared"

    Public Shared country As eCountry = stdCountry
    Public Shared dblformat As String = stdDblformat
    Public Shared emptyString As String = stdEmptyString
    Public Shared minSign As String = stdMinSign
    Public Shared minValue As Double = stdMinValue
    Public Shared digits As Integer = stdDigits
    Public Shared unit As String = ""
    Public Shared negDef As Boolean = stdnegDef

#End Region

#Region "    constants"

    Public Const stdCountry As eCountry = eCountry.en_US
    Public Const stdEmptyString As String = " - "

    Public Const stdDblformat As String = "G4"
    Public Const stdMinSign As String = "<"
    Public Const stdMinValue As Double = Nothing
    Public Const stdDigits As Integer = -1
    Public Const stdUnit As String = ""
    Public Const stdnegDef As Boolean = False

#End Region

#End Region

End Class

''' <summary>
''' date to string converter
''' AttributeProvider(
''' format, julian = add/only/none, country
''' </summary>
Public Class dateConv

    Inherits DateTimeConverter

    '<TypeConverter(GetType(dateConv)>

#Region "    get/set parameters"

    Public Shared Sub setStd()

        country = stdCountry
        dateFormat = stdDateFormat
        emptyString = stdEmptyString

    End Sub

    Public Shared Function getDateParameter(context As ITypeDescriptorContext) As String()

        Dim Attributes As AttributeCollection
        Dim Provider As AttributeProviderAttribute

        Dim formatArray As String() = {}

        Try

            With context

                Attributes = .PropertyDescriptor.Attributes

                For Each attribute In Attributes

                    If attribute.ToString =
                        "System.ComponentModel.AttributeProviderAttribute" Then

                        Provider = attribute
                        formatArray = Provider.TypeName.Split("|")

                    End If

                Next

            End With

        Catch ex As Exception

        End Try

        Return formatArray

    End Function

    Public Shared Sub setDateParameters(formatArray As String())

        Dim parameterValue As String()

        setStd()

        For Each member As String In formatArray

            parameterValue = member.Split("=")
            parameterValue(0) = Trim(parameterValue(0))
            parameterValue(1) = parameterValue(1).Split("'")(1)

            Select Case parameterValue.First

                Case "format"
                    dateFormat = parameterValue.Last

                Case "country"

                    Try
                        country =
                            [Enum].Parse(
                            enumType:=GetType(eCountry),
                            value:=parameterValue.Last)
                    Catch ex As Exception
                        country = stdCountry
                    End Try

                Case "julian"

                    Try

                        julian =
                            [Enum].Parse(
                            enumType:=GetType(eJulian),
                            value:=parameterValue.Last)

                    Catch ex As Exception
                        julian = stdJulian
                    End Try

            End Select

        Next

    End Sub

#End Region

#Region "    engine"


    <DebuggerStepThrough>
    Public Overrides Function ConvertTo(
                            context As ITypeDescriptorContext,
                            culture As CultureInfo,
                            value As Object,
                            destType As Type) As Object

        setDateParameters(
            formatArray:=getDateParameter(
                            context:=context))

        Try
            If CType(value, Date) = Date.MinValue OrElse
               CType(value, Date) = New Date Then

                Return emptyString

            Else

                Return _
                convDate2String(
                        value:=value,
                        format:=dateFormat,
                        julian:=julian,
                        emptyString:=emptyString,
                        country:=country)

            End If
        Catch ex As Exception
            Return emptyString
        End Try



    End Function

    <DebuggerStepThrough>
    Public Overrides Function ConvertFrom(
                            context As ITypeDescriptorContext,
                            culture As CultureInfo,
                            value As Object) As Object

        Try

            If CType(value, Date) = New Date Then
                Return New Date
            Else
                Return Date.Parse(CType(value, String))
            End If

        Catch ex As Exception
            Return New Date
        End Try

    End Function

#End Region

#Region "    functions"

    ''' <summary>
    ''' converts a date to a string
    ''' </summary>
    ''' <param name="value"></param>
    ''' <param name="format"></param>
    ''' <param name="julian"></param>
    ''' <param name="emptyString"></param>
    ''' <param name="country"></param>
    ''' <returns></returns>
    Public Shared Function convDate2String(
                                       value As Date,
                              Optional format As String = stdDateFormat,
                              Optional julian As eJulian = stdJulian,
                              Optional emptyString As String = stdEmptyString,
                              Optional country As eCountry = stdCountry) As String

        Dim countryString As String
        Dim out As String = ""

        countryString =
                    Replace(
                    Expression:=country.ToString,
                    Find:="_", Replacement:="-",
                    Compare:=CompareMethod.Text)
        Try

            If value = New Date OrElse IsNothing(value) Then
                Return emptyString
            End If

            out = value.ToString(
                                format:=format,
                                provider:=CultureInfo.CreateSpecificCulture(countryString))

            Select Case julian

                Case eJulian.none

                Case eJulian.add
                    out &= " (" & value.DayOfYear.ToString & ")"

                Case eJulian.only
                    out = value.DayOfYear.ToString()

            End Select

            Return out

        Catch ex As Exception
            Return emptyString
        End Try


    End Function

#End Region

#Region "    definitions"

    Public Enum eCountry
        de_DE
        en_US
        fr_FR
    End Enum

    Public Enum eJulian
        add
        only
        none
    End Enum

#Region "    shared"

    Public Shared country As eCountry = stdCountry
    Public Shared emptyString As String = stdEmptyString

    Public Shared julian As eCountry = stdJulian
    Public Shared dateFormat As String = stdDateFormat

#End Region

#Region "    constants"

    Public Const stdCountry As eCountry = eCountry.en_US
    Public Const stdEmptyString As String = " - "

    Public Const stdDateFormat As String = "dd. MMM"
    Public Const stdJulian As eJulian = eJulian.add

#End Region

#End Region


End Class


''' <summary>
''' Multi line editor for string properties
''' change FontName and FontSize
''' used by adding
''' [Editor(GetType(MultiLineTextArrayEditor), GetType(UITypeEditor))]
''' </summary>
''' <remarks></remarks>
Public Class multiLineDoubleArrayEditor

    Inherits UITypeEditor

    ' usage :  add 
    '<Editor(GetType(MultiLineTextArrayEditor), GetType(UITypeEditor))>
    ' to property

    Public Shared FontName As String = "Courier New"
    Public Shared FontSize As Integer = 10
    Public Shared Width As Integer = 250
    Public Shared Height As Integer = 150
    Public Shared AcceptsReturn As Boolean = True


    Private editorService As IWindowsFormsEditorService

    Public Overrides Function GetEditStyle(
                            context As ITypeDescriptorContext) As UITypeEditorEditStyle
        Return UITypeEditorEditStyle.Modal
    End Function

    Public Overrides Function EditValue(
                            context As ITypeDescriptorContext,
                           provider As IServiceProvider,
                              value As Object) As Object

        editorService = DirectCast(
            provider.GetService(GetType(IWindowsFormsEditorService)),
            IWindowsFormsEditorService)

        Dim txtBox As New TextBox()
        Dim temp As New List(Of String)
        Dim out As New List(Of Double)

        With txtBox

            .Multiline = True

            .Font = New Font(
                familyName:=FontName,
                    emSize:=FontSize)

            .ScrollBars = ScrollBars.Both
            .BorderStyle = BorderStyle.None

            .Width = Width
            .Height = Height

            .AcceptsReturn = AcceptsReturn

            For Each member As Double In value

                Try
                    temp.Add(member.ToString)
                Catch ex As Exception
                    temp.Add("parsing error")
                End Try
            Next

            txtBox.Text = Join(SourceArray:=temp.ToArray, Delimiter:=vbCrLf)

        End With

        editorService.DropDownControl(txtBox)

        temp.Clear()
        temp.AddRange(txtBox.Text.Split(CChar(vbCrLf)))

        For Each member As String In temp

            Try
                out.Add(Double.Parse(Trim(member)))
            Catch ex As Exception
                out.Add(Double.NaN)
            End Try

        Next

        Return out.ToArray

    End Function

End Class




#End Region

#Region "myLog"

<DebuggerStepThrough()>
Public Module log

#Region "Settings"

    ''' <summary>
    ''' Contend of the log
    ''' </summary>
    ''' <remarks></remarks>
    Public LogList As New List(Of String)

    ''' <summary>
    ''' Log Filename
    ''' </summary>
    ''' <remarks></remarks>
    Public FileName As String = ""

    Public Enum eLogLevel
        std = -1
        init = 0
        one
        two
        three
        up
        down
    End Enum

    ''' <summary>
    ''' Intent level
    ''' </summary>
    ''' <remarks></remarks>
    Public stdIntentLevel As eLogLevel = eLogLevel.init

    ''' <summary>
    ''' No of spaces per intent level
    ''' </summary>
    ''' <remarks></remarks>
    Public IntentSpacePerLevel As Integer = 3


    Public FirstIntentChar As Char = "|"c

    ''' <summary>
    ''' std. time stamp at the start of the log line
    ''' </summary>
    ''' <remarks></remarks>
    Public Const StdTimeStampPattern As String = "hh:mm"

    Public Enum eLog2Console
        Yes
        No
        Only
    End Enum

    Public FilenameOK As Boolean = False

#End Region

#Region "Log and friends"

    ''' <summary>
    ''' log simple one line msg
    ''' </summary>
    ''' <param name="LogTxt">
    ''' Log msg as one line
    ''' </param>
    ''' <param name="IntentLevel">
    ''' Intent level as enum
    ''' std, init, on, two, three, up, down
    ''' </param>
    ''' <param name="Log2Console">
    ''' Log also to console, std. = on
    ''' </param>
    ''' <param name="Log2File">
    ''' Write log instantaneously to file, std. = on
    ''' </param>
    ''' <param name="Log2Msgbox">
    ''' Log also to MsgBox, std. = false
    ''' </param>
    ''' <param name="MsgBoxBtn">
    ''' If Log2MsgBox = true => Button
    ''' </param>
    ''' <param name="MsgTitle">
    ''' If Log2MsgBox = true => MsgTitle
    ''' ></param>
    ''' <param name="Add2PreviousRow">
    ''' If true log will be append to prev. row, std. = false
    ''' </param>
    ''' <param name="TimeStampPattern">
    ''' Std. = "hh:mm"
    ''' </param>
    ''' <param name="Exception2Throw">
    ''' Throw this exception
    ''' </param>
    ''' <param name="ShowInNotepad">
    ''' Show complete Log in Notepad, std. = false
    ''' </param>
    ''' <returns>
    ''' MsgBoxResult, like Yes, No or Cancel
    ''' </returns>
    Function mylog(
                LogTxt As String,
                Optional IntentLevel As eLogLevel = eLogLevel.std,
                Optional Log2Console As eLog2Console = eLog2Console.Yes,
                Optional Log2File As Boolean = True,
                Optional Log2MsgBox As Boolean = False,
                Optional MsgBoxBtn As MsgBoxStyle = MsgBoxStyle.Exclamation,
                Optional MsgTitle As String = "",
                Optional Add2PreviousRow As Boolean = False,
                Optional TimeStampPattern As String = "std",
                Optional Exception2Throw As Exception = Nothing,
                Optional ShowInNotepad As Boolean = False) As MsgBoxResult

        Dim TempList As New List(Of String)
        Dim TimeStamp As String
        Dim Intent As String = " "


        If Not IsNothing(Exception2Throw) Then

            If LogTxt <> String.Empty Then LogTxt &= vbCrLf

            LogTxt &= Join(parseExceptionMsg(
                                    Exception:=Exception2Throw,
                         UserErrorDescription:=LogTxt),
                                    Delimiter:=vbCrLf)

        End If

        Select Case IntentLevel

            Case eLogLevel.std
                IntentLevel = stdIntentLevel

            Case eLogLevel.init
                stdIntentLevel = IntentLevel

            Case eLogLevel.up

                If stdIntentLevel = eLogLevel.init Then IntentLevel = eLogLevel.one
                If stdIntentLevel = eLogLevel.one Then IntentLevel = eLogLevel.two
                If stdIntentLevel = eLogLevel.two Then IntentLevel = eLogLevel.three
                stdIntentLevel = IntentLevel

            Case eLogLevel.down

                If stdIntentLevel = eLogLevel.init Then IntentLevel = eLogLevel.std
                If stdIntentLevel = eLogLevel.one Then IntentLevel = eLogLevel.std
                If stdIntentLevel = eLogLevel.two Then IntentLevel = eLogLevel.one
                If stdIntentLevel = eLogLevel.three Then IntentLevel = eLogLevel.two
                stdIntentLevel = IntentLevel

        End Select

        Select Case IntentLevel

            Case eLogLevel.init
                Intent = " "

            Case eLogLevel.one
                Intent = " " & FirstIntentChar.ToString.PadRight(IntentSpacePerLevel)

            Case eLogLevel.two
                Intent = " " & FirstIntentChar.ToString.PadRight(IntentSpacePerLevel) &
                               FirstIntentChar.ToString.PadRight(IntentSpacePerLevel)

            Case eLogLevel.three
                Intent = " " & FirstIntentChar.ToString.PadRight(IntentSpacePerLevel) &
                               FirstIntentChar.ToString.PadRight(IntentSpacePerLevel) &
                               FirstIntentChar.ToString.PadRight(IntentSpacePerLevel)

        End Select


        Dim Lastlines As New List(Of String)

        Dim Txt2Log As String = ""

        'format time stamp + log level
        If TimeStampPattern = "std" Then
            TimeStampPattern = StdTimeStampPattern
        End If

        If TimeStampPattern = "" Then
            TimeStamp = " "
        Else
            TimeStamp = Now.ToString(StdTimeStampPattern) & " "
        End If

        'multi row log text without repeating time stamp
        If LogTxt.Contains(vbCrLf) OrElse
           LogTxt.Contains(vbLf) Then

            TempList.Clear()
            TempList.AddRange(LogTxt.Split(CChar(vbCrLf)))

            '1st row with time stamp
            'add to prev. row ?
            If Add2PreviousRow Then

                Txt2Log = Replace(
                            Expression:="".PadLeft(TimeStamp.Length) & Intent & TempList.First,
                                  Find:=vbCrLf,
                           Replacement:="")

            Else

                Txt2Log = Replace(
                            Expression:=TimeStamp & Intent & TempList.First,
                                  Find:=vbCrLf,
                           Replacement:="")

                Txt2Log = Replace(
                            Expression:=Txt2Log,
                                  Find:=vbLf,
                           Replacement:="")

            End If



            If Log2Console = eLog2Console.Only Then
                Console.WriteLine(Txt2Log)
            Else
                Console.WriteLine(Txt2Log)
                LogList.Add(Txt2Log)
            End If

            'all others without
            For counter As Integer = 1 To TempList.Count - 1

                Txt2Log = Replace(
                    Expression:=TempList(counter),
                          Find:=vbLf,
                   Replacement:="")


                If TimeStampPattern <> "" Then

                    Txt2Log = "".PadLeft(TimeStamp.Length) & Intent &
                    Txt2Log

                End If

                'log 2 console
                Select Case Log2Console

                    Case eLog2Console.Yes

                        Console.WriteLine(Txt2Log)
                        LogList.Add(Txt2Log)

                    Case eLog2Console.Only

                        Console.WriteLine(Txt2Log)

                    Case eLog2Console.No
                        LogList.Add(Txt2Log)

                End Select

            Next

        Else

            'single row log text
            If Add2PreviousRow Then
                LogList(LogList.Count - 1) = LogList.Last & LogTxt
            Else
                If TimeStampPattern = "" Then
                    LogList.Add(Intent & LogTxt)
                Else
                    LogList.Add(TimeStamp & Intent & LogTxt)
                End If
            End If

            'log 2 console
            Select Case Log2Console

                Case eLog2Console.Yes, eLog2Console.Only
                    Try
                        If Add2PreviousRow Then Console.CursorTop = Console.CursorTop - 1
                    Catch ex As Exception

                    End Try

                    Console.WriteLine(LogList(LogList.Count - 1))
                    'LogList.Add(LogTxt)

                Case eLog2Console.No

            End Select

        End If

        Try

            If Log2File Then

                If Not FilenameOK Then

                    resetLog()
                    FilenameOK = True

                End If

                File.WriteAllLines(path:=FileName,
                           contents:=LogList.ToArray)

            End If

            Try
                If ShowInNotepad Then showLogInNotepad()
            Catch ex As Exception

                Throw New Exception(message:="Can't show log file in editor" & vbCrLf & FileName,
                                innerException:=ex)

            End Try

        Catch ex As Exception

            Throw New Exception(message:="Can't write to log file" & vbCrLf & FileName,
                                innerException:=ex)

        End Try

        If Not IsNothing(Exception2Throw) Then
            Throw New Exception(
                       message:=LogTxt,
                innerException:=Exception2Throw)
        End If

        If Log2MsgBox Then

            Return MsgBox(Prompt:=LogTxt,
                         Buttons:=MsgBoxBtn,
                           Title:=MsgTitle)

        End If

        Return MsgBoxResult.Ok

    End Function

    ''' <summary>
    ''' Log array of strings
    ''' </summary>
    ''' <param name="LogTxtArray">
    ''' Array of strings to log
    ''' </param>
    ''' <param name="IntentLevel">
    ''' Intent level as enum
    ''' std,init,on,two,three,up,down
    ''' </param>
    ''' <param name="Log2Console">
    ''' Log also to console, std. = on
    ''' </param>
    ''' <param name="Log2File">
    ''' Write log instantaneously to file, std. = on
    ''' </param>
    ''' <param name="Log2Msgbox">
    ''' Log also to MsgBox, std. = false
    ''' </param>
    ''' <param name="MsgBoxBtn">
    ''' If Log2MsgBox = true => Button
    ''' </param>
    ''' <param name="MsgTitle">
    ''' If Log2MsgBox = true => MsgTitle
    ''' ></param>
    ''' <param name="Add2PreviousRow">
    ''' If true log will be append to prev. row, std. = false
    ''' </param>
    ''' <param name="TimeStampPattern">
    ''' Std. = "hh:mm"
    ''' </param>
    ''' <param name="Exception2Throw">
    ''' Throw this exception
    ''' </param>
    ''' <param name="ShowInNotepad">
    ''' Show complete Log in Notepad, std. = false
    ''' </param>
    ''' <returns></returns>
    Public Function mylog(
                        LogTxtArray As String(),
                        Optional IntentLevel As eLogLevel = eLogLevel.std,
                        Optional Log2Console As eLog2Console = eLog2Console.Yes,
                        Optional Log2File As Boolean = True,
                        Optional Log2MsgBox As Boolean = False,
                        Optional MsgBoxBtn As MsgBoxStyle = MsgBoxStyle.Exclamation,
                        Optional MsgTitle As String = "",
                        Optional Add2PreviousRow As Boolean = False,
                        Optional TimeStampPattern As String = "std",
                        Optional Exception2Throw As Exception = Nothing,
                        Optional ShowInNotepad As Boolean = False) As MsgBoxResult

        Return mylog(
                    LogTxt:=Join(LogTxtArray, vbCrLf),
                    IntentLevel:=IntentLevel,
                    Log2Console:=Log2Console,
                    Log2File:=Log2File,
                    Log2MsgBox:=Log2MsgBox,
                    MsgBoxBtn:=MsgBoxBtn,
                    MsgTitle:=MsgTitle,
                    TimeStampPattern:=TimeStampPattern,
                    Exception2Throw:=Exception2Throw,
                    ShowInNotepad:=ShowInNotepad)

    End Function

    ''' <summary>
    ''' Log multiple lines
    ''' </summary>
    ''' <param name="LogTxtList">
    ''' List of string of lines to log
    ''' </param>
    ''' <param name="IntentLevel">
    ''' Intent level as enum
    ''' std,init,on,two,three,up,down
    ''' </param>
    ''' <param name="Log2Console">
    ''' Log also to console, std. = on
    ''' </param>
    ''' <param name="Log2File">
    ''' Write log instantaneously to file, std. = on
    ''' </param>
    ''' <param name="Log2Msgbox">
    ''' Log also to MsgBox, std. = false
    ''' </param>
    ''' <param name="MsgBoxBtn">
    ''' If Log2MsgBox = true => Button
    ''' </param>
    ''' <param name="MsgTitle">
    ''' If Log2MsgBox = true => MsgTitle
    ''' ></param>
    ''' <param name="TimeStampPattern">
    ''' Std. = "hh:mm"
    ''' </param>
    ''' <param name="Exception2Throw">
    ''' Throw this exception
    ''' </param>
    ''' <param name="ShowInNotepad">
    ''' Show complete Log in Notepad, std. = false
    ''' </param>
    ''' <returns></returns>
    Public Function mylog(
                        LogTxtList As List(Of String),
                        Optional IntentLevel As eLogLevel = eLogLevel.std,
                        Optional Log2Console As eLog2Console = eLog2Console.Yes,
                        Optional Log2File As Boolean = True,
                        Optional Log2MsgBox As Boolean = False,
                        Optional MsgBoxBtn As MsgBoxStyle = MsgBoxStyle.Exclamation,
                        Optional MsgTitle As String = "",
                        Optional TimeStampPattern As String = "std",
                        Optional Exception2Throw As Exception = Nothing,
                        Optional ShowInNotepad As Boolean = False) As MsgBoxResult

        Return mylog(
                LogTxt:=Join(LogTxtList.ToArray, vbCrLf),
                IntentLevel:=IntentLevel,
                Log2Console:=Log2Console,
                Log2File:=Log2File,
                Log2MsgBox:=Log2MsgBox,
                MsgBoxBtn:=MsgBoxBtn,
                MsgTitle:=MsgTitle,
                TimeStampPattern:=TimeStampPattern,
                Exception2Throw:=Exception2Throw,
                ShowInNotepad:=ShowInNotepad)

    End Function

#End Region

#Region "Helper: getStartInfo, showLogInNotepad, resteLog"

    ''' <summary>
    ''' Basic app. infos
    ''' </summary>
    Public Function getStartInfo(Optional LeadingString As String = "") As String()

        Dim InfoList As New List(Of String)

        With InfoList

            Try
                With My.Application.Info
                    InfoList.Add(LeadingString & .ProductName & " v" & .Version.ToString)
                    InfoList.Add(LeadingString & .Title)
                    InfoList.Add(LeadingString & .Copyright)
                End With
            Catch ex As Exception
                InfoList.Add("No info about title and version !!")
            End Try


            .Add(LeadingString & "Started on " & Now.ToString("dddd, dd.MMM.yy"))
            .Add(LeadingString & "        at " & Now.ToString("hh:mm:ss"))
            .Add(LeadingString & "        by " & Environment.UserName)
            .Add(LeadingString & "on machine " & Environment.MachineName &
                                          " (" & Environment.ProcessorCount & " CPUs with " & GetCpuSpeed() & " GHz)")
            .Add(LeadingString & "        OS " & My.Computer.Info.OSFullName & " / " &
                                                 My.Computer.Info.OSPlatform & " / " &
                                                 My.Computer.Info.OSVersion)
            .Add(LeadingString & ".net       " & Get45PlusFromRegistry())
            .Add(LeadingString & "core       " & misc.getAssemblyVersion)
            .Add(LeadingString & "           ")
            .Add(LeadingString & "Culture    " & My.Application.Culture.ToString)
            .Add(LeadingString & "           " & "Numbers = " & Math.Round(Math.PI, 2).ToString)
            .Add(LeadingString & "           " & "Dates   = " & New Date(year:=1984, month:=10, day:=15).ToLongDateString)
            .Add(LeadingString & "           " & "CSV     = " & My.Application.Culture.NumberFormat.NumberGroupSeparator.ToString)

            Try
                .Add(LeadingString & "Exec.  Dir " & My.Application.Info.DirectoryPath.ToString)
                .Add(LeadingString & "Work   Dir " & Environment.CurrentDirectory)
                .Add(LeadingString & "Net avail. " & My.Computer.Network.IsAvailable.ToString &
                                                    " (" & Environment.UserDomainName & ")")
                .Add(LeadingString & "Log path   " & log.FileName)
            Catch ex As Exception
                .Add("No info about execution directory And/Or network !!")
            End Try

            .Add("----------------------------------------------------------------------")
            .Add("")

        End With

        Return InfoList.ToArray

    End Function


    ''' <summary>
    ''' Show log in editor
    ''' </summary>
    Public Sub showLogInNotepad()

        If FileName = "" Then Exit Sub

        Try
            Process.Start(FileName)
        Catch ex As Exception
            MsgBox(Prompt:="Can't show log file '" & FileName & "'" & vbCrLf & ex.Message,
                  Buttons:=MsgBoxStyle.Critical,
                    Title:="IO Error")
        End Try

    End Sub


    Public Function GetCpuSpeed() As Double
        Dim managementObject = New ManagementObject("Win32_Processor.DeviceID='CPU0'")
        Dim speed As UInteger = CUInt(managementObject("CurrentClockSpeed"))
        managementObject.Dispose()
        Return Math.Round(speed / 1000, digits:=2)
    End Function

    Private Function Get45PlusFromRegistry() As String

        Const subkey As String = "SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full\"

        Using ndpKey As RegistryKey =
            RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry32).OpenSubKey(subkey)

            If ndpKey IsNot Nothing AndAlso ndpKey.GetValue("Release") IsNot Nothing Then
                Return $".NET Framework Version: {CheckFor45PlusVersion(ndpKey.GetValue("Release"))}"
            Else
                Return ".NET Framework Version 4.5 or later is not detected."
            End If

        End Using
    End Function

    ' Checking the version using >= enables forward compatibility.
    Private Function CheckFor45PlusVersion(releaseKey As Integer) As String
        If releaseKey >= 528040 Then
            Return "4.8 or later"
        ElseIf releaseKey >= 461808 Then
            Return "4.7.2"
        ElseIf releaseKey >= 461308 Then
            Return "4.7.1"
        ElseIf releaseKey >= 460798 Then
            Return "4.7"
        ElseIf releaseKey >= 394802 Then
            Return "4.6.2"
        ElseIf releaseKey >= 394254 Then
            Return "4.6.1"
        ElseIf releaseKey >= 393295 Then
            Return "4.6"
        ElseIf releaseKey >= 379893 Then
            Return "4.5.2"
        ElseIf releaseKey >= 378675 Then
            Return "4.5.1"
        ElseIf releaseKey >= 378389 Then
            Return "4.5"
        End If
        ' This code should never execute. A non-null release key should mean
        ' that 4.5 or later is installed.
        Return "No 4.5 or later version detected"
    End Function


    Public Sub resetLog(Optional LogFileName As String = "",
                        Optional Logo As String() = Nothing,
                        Optional Clear As Boolean = True,
                        Optional ShowLogInNotepad As Boolean = False)

        Dim LogMsg As New List(Of String)

        If LogFileName = "" Then
            LogFileName = Path.Combine(My.Application.Info.DirectoryPath,
                                       My.Application.Info.ProductName & ".log")
        Else
            If Not Directory.Exists(Path.GetDirectoryName(LogFileName)) Then

                Throw New IOException(
                    message:="Directory does NOT exist : Can't write to" & vbCrLf &
                             "LogFileName = " & LogFileName)

                Exit Sub

            End If
        End If

        FileName = LogFileName
        FilenameOK = True

        If Clear Then LogList.Clear()

        If Not IsNothing(Logo) Then
            LogMsg.AddRange(Logo)
        End If

        LogMsg.AddRange(getStartInfo())

        mylog(LogTxtArray:=LogMsg.ToArray)

        If ShowLogInNotepad Then log.showLogInNotepad()

    End Sub

#End Region

    Public Function parseExceptionMsg(Exception As Exception,
                             Optional UserErrorDescription As String = "",
                             Optional LeadingString As String = "") As String()

        Const TargetAllignSpace As Integer = 8

        Dim Delimiter As String
        Dim ModuleDelimiter As String
        Dim RowDelimiter As String

        Dim StackTraceArray As String()
        Dim ErrorLineArray As String()
        Dim Output As New List(Of String)

        Dim ModuleRow As String = ""


        If UserErrorDescription <> "" Then Output.Add(UserErrorDescription)

        Output.Add(Exception.Message)

        'check if German or English error MSG
        If Exception.StackTrace.Contains("at ") Then

            'English
            Delimiter = "at "
            ModuleDelimiter = " in "
            RowDelimiter = ":line"

        ElseIf Exception.StackTrace.Contains("bei ") Then

            'German
            Delimiter = "bei "
            ModuleDelimiter = " in "
            RowDelimiter = ":Zeile"

        Else

            With Output

                .Add("Unknown language. can't parse error msg!")
                .Add("ErrorMsg".PadRight(TargetAllignSpace) & ": " & Exception.Message.ToString)
                .Add("StackTrace")
                .Add(Exception.StackTrace.ToString)

            End With

            Return Output.ToArray

        End If

        Try

            StackTraceArray = Split(Exception.StackTrace,
                                    Delimiter)
            StackTraceArray = Filter(StackTraceArray,
                                     ModuleDelimiter)

            'parse each msg
            For Each ErrorLine As String In StackTraceArray

                With Output

                    'Module name
                    ErrorLineArray = Split(ErrorLine,
                                           ModuleDelimiter)

                    ModuleRow = "Module".PadRight(TargetAllignSpace) & ": " &
                         Trim(ErrorLineArray.First)

                    If Output.Contains(ModuleRow) Then
                        Continue For
                    Else
                        .Add(ModuleRow)
                        ModuleRow = ""
                    End If


                    ErrorLineArray = Split(ErrorLineArray.Last,
                                           RowDelimiter)

                    'Where is the problem
                    .Add("in file".PadRight(TargetAllignSpace) & ": " &
                         Trim(ErrorLineArray.First))

                    .Add("at row".PadRight(TargetAllignSpace) & ": " &
                         Trim(Replace(ErrorLineArray.Last,
                                      ".", "")))

                End With

            Next

        Catch FatalException As Exception

            With Output

                .Add("Can't parse error msg!")
                .Add("ErrorMsg".PadRight(TargetAllignSpace) & ": " &
                                Exception.Message.ToString)
                .Add("StackTrace")
                .Add(Exception.StackTrace.ToString)
                .Add(FatalException.StackTrace.ToString)

            End With

        End Try

        For Counter As Integer = 0 To Output.Count - 1
            Output(Counter) = LeadingString & Output(Counter)
        Next


        If IsNothing(Exception.InnerException) Then
            Return Output.ToArray
        Else
            Output.Add(" ")
            Output.Add(" ")
            Output.Add("inner exception: ")
            Output.Add(" ")
            Output.AddRange(parseExceptionMsg(Exception:=Exception.InnerException))
        End If

        Return Output.ToArray

    End Function


End Module

#End Region


#Region "misc"

Public Module misc

    Public Const Multipy As Char = "×"c

    Public Sub setCulture(Optional CultureString As String = "en-US")
        Thread.CurrentThread.CurrentCulture =
            CultureInfo.CreateSpecificCulture(CultureString)
    End Sub

    Public Function getAssemblyVersion() As String
        Return GetType(misc).Assembly.GetName().Version.ToString
    End Function

    <DebuggerStepThrough>
    Public Function Integer2Roman(Number As Integer) As String

        Dim result As New System.Text.StringBuilder()

        Dim digitsValues As Integer() =
                {1, 4, 5, 9, 10, 40, 50, 90, 100, 400, 500, 900, 1000}
        Dim romanDigits As String() =
                {"I", "IV", "V", "IX", "X", "XL", "L", "XC", "C", "CD", "D", "CM", "M"}

        If Number = 0 Then Number = 1

        While Number > 0
            For i As Integer = digitsValues.Count() - 1 To 0 Step -1
                If Number \ digitsValues(i) >= 1 Then
                    Number -= digitsValues(i)
                    result.Append(romanDigits(i))
                    Exit For
                End If
            Next
        End While

        Return result.ToString()

    End Function

#Region "std. enums"

    Public Const NotDef As String = " - "

    <TypeConverter(GetType(enumConverter(Of eOnOff)))>
    Public Enum eOnOff

        <Description("On")>
        [On]

        <Description("Off")>
        [Off]

    End Enum

    <TypeConverter(GetType(enumConverter(Of eInteger)))>
    Public Enum eInteger
        <Description("0")>
        _0 = 0
        <Description("1")>
        _1
        <Description("2")>
        _2
        <Description("3")>
        _3
        <Description("4")>
        _4
        <Description("5")>
        _5
        <Description("6")>
        _6
        <Description("7")>
        _7
        <Description("8")>
        _8
        <Description("9")>
        _9
        <Description("10")>
        _10
        <Description("11")>
        _11
        <Description("12")>
        _12
        <Description("13")>
        _13
        <Description("14")>
        _14
        <Description("15")>
        _15
        <Description("16")>
        _16
        <Description("17")>
        _17
        <Description("18")>
        _18
        <Description("19")>
        _19
        <Description("20")>
        _20
        <Description("21")>
        _21
        <Description("22")>
        _22
        <Description("23")>
        _23
        <Description("24")>
        _24
        <Description("25")>
        _25
        <Description("26")>
        _26
        <Description("27")>
        _27
        <Description("28")>
        _28
        <Description("29")>
        _29
        <Description("30")>
        _30
        <Description("31")>
        _31
        <Description("32")>
        _32
        <Description("33")>
        _33
        <Description("34")>
        _34
        <Description("35")>
        _35
        <Description("36")>
        _36
        <Description("37")>
        _37
        <Description("38")>
        _38
        <Description("39")>
        _39
        <Description("40")>
        _40
        <Description("41")>
        _41
        <Description("42")>
        _42
        <Description("43")>
        _43
        <Description("44")>
        _44
        <Description("45")>
        _45
        <Description("46")>
        _46
        <Description("47")>
        _47
        <Description("48")>
        _48
        <Description("49")>
        _49
        <Description("50")>
        _50
        <Description("51")>
        _51
        <Description("52")>
        _52
        <Description("53")>
        _53
        <Description("54")>
        _54
        <Description("55")>
        _55
        <Description("56")>
        _56
        <Description("57")>
        _57
        <Description("58")>
        _58
        <Description("59")>
        _59
        <Description("60")>
        _60
        <Description("61")>
        _61
        <Description("62")>
        _62
        <Description("63")>
        _63
        <Description("64")>
        _64
        <Description("65")>
        _65
        <Description("66")>
        _66
        <Description("67")>
        _67
        <Description("68")>
        _68
        <Description("69")>
        _69
        <Description("70")>
        _70
        <Description("71")>
        _71
        <Description("72")>
        _72
        <Description("73")>
        _73
        <Description("74")>
        _74
        <Description("75")>
        _75
        <Description("76")>
        _76
        <Description("77")>
        _77
        <Description("78")>
        _78
        <Description("79")>
        _79
        <Description("80")>
        _80
        <Description("81")>
        _81
        <Description("82")>
        _82
        <Description("83")>
        _83
        <Description("84")>
        _84
        <Description("85")>
        _85
        <Description("86")>
        _86
        <Description("87")>
        _87
        <Description("88")>
        _88
        <Description("89")>
        _89
        <Description("90")>
        _90
        <Description("91")>
        _91
        <Description("92")>
        _92
        <Description("93")>
        _93
        <Description("94")>
        _94
        <Description("95")>
        _95
        <Description("96")>
        _96
        <Description("97")>
        _97
        <Description("98")>
        _98
        <Description("99")>
        _99
        <Description("100")>
        _100
        <Description("101")>
        _101
        <Description("102")>
        _102
        <Description("103")>
        _103
        <Description("104")>
        _104
        <Description("105")>
        _105
        <Description("106")>
        _106
        <Description("107")>
        _107
        <Description("108")>
        _108
        <Description("109")>
        _109
        <Description("110")>
        _110
        <Description("111")>
        _111
        <Description("112")>
        _112
        <Description("113")>
        _113
        <Description("114")>
        _114
        <Description("115")>
        _115
        <Description("116")>
        _116
        <Description("117")>
        _117
        <Description("118")>
        _118
        <Description("119")>
        _119
        <Description("120")>
        _120
        <Description("121")>
        _121
        <Description("122")>
        _122
        <Description("123")>
        _123
        <Description("124")>
        _124
        <Description("125")>
        _125
        <Description("126")>
        _126
        <Description("127")>
        _127
        <Description("128")>
        _128
        <Description("129")>
        _129
        <Description("130")>
        _130
        <Description("131")>
        _131
        <Description("132")>
        _132
        <Description("133")>
        _133
        <Description("134")>
        _134
        <Description("135")>
        _135
        <Description("136")>
        _136
        <Description("137")>
        _137
        <Description("138")>
        _138
        <Description("139")>
        _139
        <Description("140")>
        _140
        <Description("141")>
        _141
        <Description("142")>
        _142
        <Description("143")>
        _143
        <Description("144")>
        _144
        <Description("145")>
        _145
        <Description("146")>
        _146
        <Description("147")>
        _147
        <Description("148")>
        _148
        <Description("149")>
        _149
        <Description("150")>
        _150
        <Description("151")>
        _151
        <Description("152")>
        _152
        <Description("153")>
        _153
        <Description("154")>
        _154
        <Description("155")>
        _155
        <Description("156")>
        _156
        <Description("157")>
        _157
        <Description("158")>
        _158
        <Description("159")>
        _159
        <Description("160")>
        _160
        <Description("161")>
        _161
        <Description("162")>
        _162
        <Description("163")>
        _163
        <Description("164")>
        _164
        <Description("165")>
        _165
        <Description("166")>
        _166
        <Description("167")>
        _167
        <Description("168")>
        _168
        <Description("169")>
        _169
        <Description("170")>
        _170
        <Description("171")>
        _171
        <Description("172")>
        _172
        <Description("173")>
        _173
        <Description("174")>
        _174
        <Description("175")>
        _175
        <Description("176")>
        _176
        <Description("177")>
        _177
        <Description("178")>
        _178
        <Description("179")>
        _179
        <Description("180")>
        _180
        <Description("181")>
        _181
        <Description("182")>
        _182
        <Description("183")>
        _183
        <Description("184")>
        _184
        <Description("185")>
        _185
        <Description("186")>
        _186
        <Description("187")>
        _187
        <Description("188")>
        _188
        <Description("189")>
        _189
        <Description("190")>
        _190
        <Description("191")>
        _191
        <Description("192")>
        _192
        <Description("193")>
        _193
        <Description("194")>
        _194
        <Description("195")>
        _195
        <Description("196")>
        _196
        <Description("197")>
        _197
        <Description("198")>
        _198
        <Description("199")>
        _199
        <Description("200")>
        _200
        <Description("201")>
        _201
        <Description("202")>
        _202
        <Description("203")>
        _203
        <Description("204")>
        _204
        <Description("205")>
        _205
        <Description("206")>
        _206
        <Description("207")>
        _207
        <Description("208")>
        _208
        <Description("209")>
        _209
        <Description("210")>
        _210
        <Description("211")>
        _211
        <Description("212")>
        _212
        <Description("213")>
        _213
        <Description("214")>
        _214
        <Description("215")>
        _215
        <Description("216")>
        _216
        <Description("217")>
        _217
        <Description("218")>
        _218
        <Description("219")>
        _219
        <Description("220")>
        _220
        <Description("221")>
        _221
        <Description("222")>
        _222
        <Description("223")>
        _223
        <Description("224")>
        _224
        <Description("225")>
        _225
        <Description("226")>
        _226
        <Description("227")>
        _227
        <Description("228")>
        _228
        <Description("229")>
        _229
        <Description("230")>
        _230
        <Description("231")>
        _231
        <Description("232")>
        _232
        <Description("233")>
        _233
        <Description("234")>
        _234
        <Description("235")>
        _235
        <Description("236")>
        _236
        <Description("237")>
        _237
        <Description("238")>
        _238
        <Description("239")>
        _239
        <Description("240")>
        _240
        <Description("241")>
        _241
        <Description("242")>
        _242
        <Description("243")>
        _243
        <Description("244")>
        _244
        <Description("245")>
        _245
        <Description("246")>
        _246
        <Description("247")>
        _247
        <Description("248")>
        _248
        <Description("249")>
        _249
        <Description("250")>
        _250
        <Description("251")>
        _251
        <Description("252")>
        _252
        <Description("253")>
        _253
        <Description("254")>
        _254
        <Description("255")>
        _255
        <Description("256")>
        _256
        <Description("257")>
        _257
        <Description("258")>
        _258
        <Description("259")>
        _259
        <Description("260")>
        _260
        <Description("261")>
        _261
        <Description("262")>
        _262
        <Description("263")>
        _263
        <Description("264")>
        _264
        <Description("265")>
        _265
        <Description("266")>
        _266
        <Description("267")>
        _267
        <Description("268")>
        _268
        <Description("269")>
        _269
        <Description("270")>
        _270
        <Description("271")>
        _271
        <Description("272")>
        _272
        <Description("273")>
        _273
        <Description("274")>
        _274
        <Description("275")>
        _275
        <Description("276")>
        _276
        <Description("277")>
        _277
        <Description("278")>
        _278
        <Description("279")>
        _279
        <Description("280")>
        _280
        <Description("281")>
        _281
        <Description("282")>
        _282
        <Description("283")>
        _283
        <Description("284")>
        _284
        <Description("285")>
        _285
        <Description("286")>
        _286
        <Description("287")>
        _287
        <Description("288")>
        _288
        <Description("289")>
        _289
        <Description("290")>
        _290
        <Description("291")>
        _291
        <Description("292")>
        _292
        <Description("293")>
        _293
        <Description("294")>
        _294
        <Description("295")>
        _295
        <Description("296")>
        _296
        <Description("297")>
        _297
        <Description("298")>
        _298
        <Description("299")>
        _299
        <Description("300")>
        _300
        <Description("301")>
        _301
        <Description("302")>
        _302
        <Description("303")>
        _303
        <Description("304")>
        _304
        <Description("305")>
        _305
        <Description("306")>
        _306
        <Description("307")>
        _307
        <Description("308")>
        _308
        <Description("309")>
        _309
        <Description("310")>
        _310
        <Description("311")>
        _311
        <Description("312")>
        _312
        <Description("313")>
        _313
        <Description("314")>
        _314
        <Description("315")>
        _315
        <Description("316")>
        _316
        <Description("317")>
        _317
        <Description("318")>
        _318
        <Description("319")>
        _319
        <Description("320")>
        _320
        <Description("321")>
        _321
        <Description("322")>
        _322
        <Description("323")>
        _323
        <Description("324")>
        _324
        <Description("325")>
        _325
        <Description("326")>
        _326
        <Description("327")>
        _327
        <Description("328")>
        _328
        <Description("329")>
        _329
        <Description("330")>
        _330
        <Description("331")>
        _331
        <Description("332")>
        _332
        <Description("333")>
        _333
        <Description("334")>
        _334
        <Description("335")>
        _335
        <Description("336")>
        _336
        <Description("337")>
        _337
        <Description("338")>
        _338
        <Description("339")>
        _339
        <Description("340")>
        _340
        <Description("341")>
        _341
        <Description("342")>
        _342
        <Description("343")>
        _343
        <Description("344")>
        _344
        <Description("345")>
        _345
        <Description("346")>
        _346
        <Description("347")>
        _347
        <Description("348")>
        _348
        <Description("349")>
        _349
        <Description("350")>
        _350
        <Description("351")>
        _351
        <Description("352")>
        _352
        <Description("353")>
        _353
        <Description("354")>
        _354
        <Description("355")>
        _355
        <Description("356")>
        _356
        <Description("357")>
        _357
        <Description("358")>
        _358
        <Description("359")>
        _359
        <Description("360")>
        _360
        <Description("361")>
        _361
        <Description("362")>
        _362
        <Description("363")>
        _363
        <Description("364")>
        _364
        <Description("365")>
        _365
        <Description("366")>
        _366
        <Description("367")>
        _367
        <Description("368")>
        _368
        <Description("369")>
        _369
        <Description("370")>
        _370
        <Description("371")>
        _371
        <Description("372")>
        _372
        <Description("373")>
        _373
        <Description("374")>
        _374
        <Description("375")>
        _375
        <Description("376")>
        _376
        <Description("377")>
        _377
        <Description("378")>
        _378
        <Description("379")>
        _379
        <Description("380")>
        _380
        <Description("381")>
        _381
        <Description("382")>
        _382
        <Description("383")>
        _383
        <Description("384")>
        _384
        <Description("385")>
        _385
        <Description("386")>
        _386
        <Description("387")>
        _387
        <Description("388")>
        _388
        <Description("389")>
        _389
        <Description("390")>
        _390
        <Description("391")>
        _391
        <Description("392")>
        _392
        <Description("393")>
        _393
        <Description("394")>
        _394
        <Description("395")>
        _395
        <Description("396")>
        _396
        <Description("397")>
        _397
        <Description("398")>
        _398
        <Description("399")>
        _399
        <Description("400")>
        _400
        <Description("401")>
        _401
        <Description("402")>
        _402
        <Description("403")>
        _403
        <Description("404")>
        _404
        <Description("405")>
        _405
        <Description("406")>
        _406
        <Description("407")>
        _407
        <Description("408")>
        _408
        <Description("409")>
        _409
        <Description("410")>
        _410
        <Description("411")>
        _411
        <Description("412")>
        _412
        <Description("413")>
        _413
        <Description("414")>
        _414
        <Description("415")>
        _415
        <Description("416")>
        _416
        <Description("417")>
        _417
        <Description("418")>
        _418
        <Description("419")>
        _419
        <Description("420")>
        _420
        <Description("421")>
        _421
        <Description("422")>
        _422
        <Description("423")>
        _423
        <Description("424")>
        _424
        <Description("425")>
        _425
        <Description("426")>
        _426
        <Description("427")>
        _427
        <Description("428")>
        _428
        <Description("429")>
        _429
        <Description("430")>
        _430
        <Description("431")>
        _431
        <Description("432")>
        _432
        <Description("433")>
        _433
        <Description("434")>
        _434
        <Description("435")>
        _435
        <Description("436")>
        _436
        <Description("437")>
        _437
        <Description("438")>
        _438
        <Description("439")>
        _439
        <Description("440")>
        _440
        <Description("441")>
        _441
        <Description("442")>
        _442
        <Description("443")>
        _443
        <Description("444")>
        _444
        <Description("445")>
        _445
        <Description("446")>
        _446
        <Description("447")>
        _447
        <Description("448")>
        _448
        <Description("449")>
        _449
        <Description("450")>
        _450
        <Description("451")>
        _451
        <Description("452")>
        _452
        <Description("453")>
        _453
        <Description("454")>
        _454
        <Description("455")>
        _455
        <Description("456")>
        _456
        <Description("457")>
        _457
        <Description("458")>
        _458
        <Description("459")>
        _459
        <Description("460")>
        _460
        <Description("461")>
        _461
        <Description("462")>
        _462
        <Description("463")>
        _463
        <Description("464")>
        _464
        <Description("465")>
        _465
        <Description("466")>
        _466
        <Description("467")>
        _467
        <Description("468")>
        _468
        <Description("469")>
        _469
        <Description("470")>
        _470
        <Description("471")>
        _471
        <Description("472")>
        _472
        <Description("473")>
        _473
        <Description("474")>
        _474
        <Description("475")>
        _475
        <Description("476")>
        _476
        <Description("477")>
        _477
        <Description("478")>
        _478
        <Description("479")>
        _479
        <Description("480")>
        _480
        <Description("481")>
        _481
        <Description("482")>
        _482
        <Description("483")>
        _483
        <Description("484")>
        _484
        <Description("485")>
        _485
        <Description("486")>
        _486
        <Description("487")>
        _487
        <Description("488")>
        _488
        <Description("489")>
        _489
        <Description("490")>
        _490
        <Description("491")>
        _491
        <Description("492")>
        _492
        <Description("493")>
        _493
        <Description("494")>
        _494
        <Description("495")>
        _495
        <Description("496")>
        _496
        <Description("497")>
        _497
        <Description("498")>
        _498
        <Description("499")>
        _499
        <Description("500")>
        _500


    End Enum

    <TypeConverter(GetType(enumConverter(Of eYesNo)))>
    Public Enum eYesNo

        <Description("Yes")>
        Yes

        <Description("No")>
        No

    End Enum

End Module

#End Region



#End Region

#End Region


