﻿

#Region "System"

Imports System.ComponentModel
Imports System.Drawing.Design
Imports System.IO
Imports System.Globalization
Imports System.Reflection
Imports System.Xml.Serialization

#End Region

Imports PecManDrift.FOCUSswBase
Imports PecManDrift.definitions


Public Class FOCUSDrift

#Region "   Constructors"

    Public Sub New()

        depthDrainCSV =
            File.ReadAllLines(
            path:=Path.Combine(
                path1:=Environment.CurrentDirectory,
                path2:="DrainageHYD.csv"))

    End Sub

#End Region

#Region "   Categories"

    Public Const CatMetaData As String = "00 Meta Data"
    Public Const CATApplication As String = "01 Application"
    Public Const CATCrop As String = "02 Crop"
    Public Const CATWB As String = "03 Water body"
    Public Const CATDistances As String = "04 Distances from crop"

    Public Const CATStep12Drift As String = "05 Step 12"
    Public Const CATStep03Drift As String = "06 Step 03"
    Public Const CATStep04Drift As String = "07 Step 04"
    Public Const CATRiskAssessment As String = "08 Risk Assessment"
    Public Const CATFile As String = "09 Apply Drift 2 File(s)"

    Public Const align As String = "   "

#End Region

#Region "00 Settings"

    <Category(CatMetaData)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property formatDrift As String = "G5"

    <Category(CatMetaData)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property formatPEC As String = "G5"

    <Category(CatMetaData)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property test As New dblConvSetDrift.formatSet

#End Region

#Region "01 Application"

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_NoOfApplns As eNoOfApplns = eNoOfApplns.one

    ''' <summary>
    ''' Number of applications
    ''' 1 - 8
    ''' </summary>
    <Category(CATApplication)>
    <DisplayName(
    "# of Applns")>
    <Description(
    "Number of applications" & vbCrLf &
    "1 - 8 (or more)")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(CInt(eNoOfApplns.one))>
    Public Property NoOfApplns As eNoOfApplns
        Get
            Return m_NoOfApplns
        End Get
        Set(vNoOfApplns As eNoOfApplns)
            m_NoOfApplns = vNoOfApplns
        End Set
    End Property


    ''' <summary>
    ''' Drift percentile regarding to the 
    ''' # of applns in %
    ''' </summary>
    <Category(CATApplication)>
    <DisplayName(
    align & "Drift Percentile")>
    <Description(
    "Drift percentile regarding to the # of applns in %")>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <[ReadOnly](True)>
    Public ReadOnly Property DriftPercentile As Double
        Get

            Select Case NoOfApplns

                Case eNoOfApplns.one
                    Return 90
                Case eNoOfApplns.two
                    Return 81.76
                Case eNoOfApplns.three
                    Return 77.03
                Case eNoOfApplns.four
                    Return 73.92
                Case eNoOfApplns.fife
                    Return 71.67
                Case eNoOfApplns.six
                    Return 69.96
                Case eNoOfApplns.seven
                    Return 68.59
                Case eNoOfApplns.eight
                    Return 67.48
                Case Else
                    Return -99

            End Select

        End Get
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_ApplnRate As Double = Double.NaN

    ''' <summary>
    ''' Application rate
    ''' in kg/ha
    ''' </summary>
    <Category(CATApplication)>
    <DisplayName(
    "Appln Rate")>
    <Description(
    "Application rate" & vbCrLf &
    "in kg/ha")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(Double.NaN)>
    <TypeConverter(GetType(dblConvPara))>
    <AttributeProvider(stdDblformat)>
    Public Property ApplnRate As Double
        Get
            Return m_ApplnRate
        End Get
        Set(vApplnRate As Double)
            m_ApplnRate = vApplnRate
        End Set
    End Property

#End Region

#Region "02 Crop"

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_FOCUSDriftCrop As eFOCUSDriftCrop = eFOCUSDriftCrop.Grass_alfalfa

    ''' <summary>
    ''' Target crop out of the
    ''' available FOCUS crops
    ''' </summary>
    <Category(CATCrop)>
    <DisplayName(
    "FOCUS DRIFT Crop")>
    <Description(
    "Target crop for DRIFT out of the" & vbCrLf &
    "available FOCUS crops")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public Property FOCUSDriftCrop As eFOCUSDriftCrop
        Get
            Return m_FOCUSDriftCrop
        End Get
        Set(vFOCUSDriftCrop As eFOCUSDriftCrop)

            m_FOCUSDriftCrop = vFOCUSDriftCrop

            Try

                'Me.Step04Buffer =
                '        getFOCUSStdDistance(
                '                FOCUSDriftCrop:=FOCUSDriftCrop,
                '                FOCUSWaterBody:=m_FOCUSWaterBody,
                '                FOCUSStdDistancesMember:=eFOCUSStdDistancesMember.edgeField2topBank) +
                '        WaterBodyDB(Me.FOCUSWaterBody, eWBMember.DistanceBankWater)

                Me.FOCUSSswScenario = CType([Enum].Parse(enumType:=GetType(eFOCUSswScenario),
                                                      value:=scenariosAvailable.Split({"|"c}).First),
                                                eFOCUSswScenario)
            Catch ex As Exception

            End Try

        End Set
    End Property

    <Category(CATCrop)>
    <DisplayName(
    align & "def. Scenarios")>
    <Description(
    "FOCUS Sw Scenarios" & vbCrLf &
    "where this crop is defined")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public ReadOnly Property scenariosAvailable As String
        Get
            Try

                Dim out As String
                out = Join(
                        SourceArray:=getScenariosPerCrop(Me.FOCUSDriftCrop),
                        Delimiter:="|")

                m_FOCUSSswScenario =
                    [Enum].Parse(
                    enumType:=GetType(eFOCUSswScenario),
                    value:=out.Substring(0, 2))

                Return out

            Catch ex As Exception
                Return ""
            End Try
        End Get
    End Property

    ''' <summary>
    ''' Ganzelmeier crop group
    ''' Arable crops, Fruit crops, etc
    ''' </summary>
    <Category(CATCrop)>
    <DisplayName(
    align & "Ganzelmeier")>
    <Description(
    "Ganzelmeier crop group" & vbCrLf &
    "Arable crops, Fruit crops, etc")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(CInt(eGanzelmeier.ArableCrops))>
    Public ReadOnly Property Ganzelmeier As eGanzelmeier
        Get
            Return FOCUSCrop2Ganzelmeier(FOCUSDriftCrop)
        End Get
    End Property

#End Region

#Region "03 Water body"

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_FOCUSWaterBody As eFOCUSWaterBody = eFOCUSWaterBody.ditch

    ''' <summary>
    ''' FOCUS water body
    ''' Ditch, pond or stream
    ''' </summary>
    <Category(CATWB)>
    <DisplayName("Water Body")>
    <Description("Ditch, pond or stream" & vbCrLf &
                     "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(CInt(eFOCUSWaterBody.ditch))>
    Public Property FOCUSWaterBody As eFOCUSWaterBody
        Get
            Return m_FOCUSWaterBody
        End Get
        Set(vFOCUSWaterBody As eFOCUSWaterBody)

            If vFOCUSWaterBody = eFOCUSWaterBody.not_defined Then
                m_FOCUSWaterBody = eFOCUSWaterBody.ditch
            Else
                m_FOCUSWaterBody = vFOCUSWaterBody
            End If

        End Set
    End Property

#Region "Water body geometry"

    ''' <summary>
    ''' Width
    ''' </summary>
    <Category(CATWB)>
    <DisplayName(
    align & "width")>
    <Description(
    "Width of the water body" & vbCrLf &
    "in m ")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    Public ReadOnly Property width As Double
        Get
            Return WaterBodyDB(FOCUSWaterBody, eWBMember.Witdth)
        End Get
    End Property

    ''' <summary>
    ''' Depth
    ''' </summary>
    <Category(CATWB)>
    <DisplayName(
    align & "std. depth")>
    <Description(
    "Depth of the water body" & vbCrLf &
    "in m, scenario specific!")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    Public ReadOnly Property stdDepth As Double
        Get
            Return WaterBodyDB(FOCUSWaterBody, eWBMember.Depth)
        End Get
    End Property

    ''' <summary>
    ''' Length
    ''' </summary>
    <Category(CATWB)>
    <DisplayName(
    align & "length")>
    <Description(
    "Length of the water body" & vbCrLf &
    "in m")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    Public ReadOnly Property length As Double
        Get
            Return WaterBodyDB(eFOCUSWaterBody.ditch, eWBMember.Length)
        End Get
    End Property

    ''' <summary>
    ''' volue in m^3
    ''' </summary>
    <Category(CATWB)>
    <DisplayName(
    align & "volume")>
    <Description(
    "Volume of the water body" & vbCrLf &
    "in m^3")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    Public ReadOnly Property volume As Double
        Get
            Return Me.width * Me.stdDepth * Me.length
        End Get
    End Property

#End Region

    Public Property depthDrainCSV As String() = {}

#End Region

#Region "04 Distances from crop"

    ''' <summary>
    ''' Distance  Crop to Bank in m 
    ''' </summary>
    <Category(CATDistances)>
    <DisplayName(
    "Crop <-> Bank")>
    <Description(
    "Distance Crop <-> Bank" & vbCrLf &
    "in m")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public ReadOnly Property distanceCrop2Bank As Double
        Get

            Try

                Return getFOCUSStdDistance(
                    FOCUSDriftCrop:=Me.FOCUSDriftCrop,
                    FOCUSWaterBody:=Me.FOCUSWaterBody,
                    FOCUSStdDistancesMember:=eFOCUSStdDistancesMember.edgeField2topBank)

            Catch ex As Exception
                Return Double.NaN
            End Try

        End Get
    End Property

    ''' <summary>
    ''' Distance  Bank to Water in m
    ''' </summary>
    <Category(CATDistances)>
    <DisplayName("Bank <-> Water")>
    <Description("Distance Bank <-> Water" & vbCrLf &
                     "in m")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public ReadOnly Property distanceBank2Water As Double
        Get

            Try

                Return getFOCUSStdDistance(
                    FOCUSDriftCrop:=Me.FOCUSDriftCrop,
                    FOCUSWaterBody:=Me.FOCUSWaterBody,
                    FOCUSStdDistancesMember:=eFOCUSStdDistancesMember.topBank2edgeWaterbody)

            Catch ex As Exception
                Return Double.NaN
            End Try

        End Get
    End Property

    ''' <summary>
    ''' Hinge Point
    ''' Distance limit for each regression in m
    ''' to switch from A + B to C + D
    ''' </summary>
    <Category(CATDistances)>
    <DisplayName("Hinge Point")>
    <Description("Distance limit for each regression in m" & vbCrLf &
                     "to switch from A/B to C/D")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <AttributeProvider(stdDblformat)>
    Public ReadOnly Property hingePoint As Double
        Get
            Return hingePointDB(FOCUSCrop2Ganzelmeier(Me.FOCUSDriftCrop), m_NoOfApplns)
        End Get
    End Property



    ''' <summary>
    ''' Closest to the edge of the field in m
    ''' </summary>
    <Category(CATDistances)>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
    ". edge  nearest field")>
    <Description(
    "Closest to the edge of the field in m" & vbCrLf &
    "FOCUS std. Buffer length: Crop2Bank + Bank2Water")>
    <Browsable(True)>
    <AttributeProvider(stdDblformat)>
    Public ReadOnly Property closest2EdgeOfField As Double
        Get
            Return distanceCrop2Bank + distanceBank2Water
        End Get
    End Property

    ''' <summary>
    ''' Drift at edge nearest field in %
    ''' </summary>
    ''' <returns></returns>
    <Category(CATDistances)>
    <DisplayName(
    align & "drift %")>
    <Description(
    "Drift at edge nearest field" & vbCrLf &
    "in %")>
    <Browsable(True)>
    <TypeConverter(GetType(dblConvSetDrift))>
    Public ReadOnly Property nearestDriftPercent As Double
        Get

            Dim out As Double

            out =
                calcDriftPercent(
                        noOfApplns:=Me.NoOfApplns,
                    FOCUSDriftCrop:=Me.FOCUSDriftCrop,
                         FOCUSWaterBody:=Me.FOCUSWaterBody,
                         DriftDistance:=eDriftDistance.closest)

            Return out

        End Get
    End Property

    ''' <summary>
    ''' Farthest to the edge of the field in m
    ''' BufferWidth + WaterBodyWidth
    ''' </summary>
    <Category(CATDistances)>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
    ". farthest from field")>
    <Description(
    "Farthest to the edge of the field in m" & vbCrLf &
    "Closest2Edge + water body width")>
    <Browsable(True)>
    Public ReadOnly Property Farthest2EdgeOfWB As Double
        Get

            Return distanceCrop2Bank +
                       distanceBank2Water +
                       WaterBodyDB(FOCUSWaterBody, eWBMember.Witdth)
        End Get
    End Property

    ''' <summary>
    ''' Drift farthest to the 
    ''' edge of the field in %
    ''' </summary>
    ''' <returns></returns>
    <Category(CATDistances)>
    <DisplayName(
    align & "drift %")>
    <Description(
    "Drift farthest to the edge of the field" & vbCrLf &
    "in %")>
    <Browsable(True)>
    <TypeConverter(GetType(dblConvSetDrift))>
    Public ReadOnly Property FarthestDriftPercent As Double
        Get

            Dim out As Double

            out =
                calcDriftPercent(
                        noOfApplns:=Me.NoOfApplns,
                    FOCUSDriftCrop:=Me.FOCUSDriftCrop,
                        FOCUSWaterBody:=Me.FOCUSWaterBody,
                        DriftDistance:=eDriftDistance.farthest)

            Return out

        End Get
    End Property


    ''' <summary>
    ''' Areic mean drift in %
    ''' </summary>
    ''' <returns></returns>
    <Category(CATDistances)>
    <DisplayName(
    "Mean Drift %")>
    <Description(
    "Areic mean drift" & vbCrLf &
    "in %")>
    <Browsable(True)>
    <TypeConverter(GetType(dblConvSetDrift))>
    Public ReadOnly Property areicMeanDriftPercent As Double
        Get

            Dim out As Double

            out =
                calcDriftPercent(
                        noOfApplns:=Me.NoOfApplns,
                    FOCUSDriftCrop:=Me.FOCUSDriftCrop,
                        FOCUSWaterBody:=Me.FOCUSWaterBody,
                        DriftDistance:=eDriftDistance.average)

            Return out

        End Get
    End Property


#End Region

#Region "05 Step12"

    ''' <summary>
    ''' Step12 Drift %
    ''' </summary>
    ''' <returns></returns>
    <Category(CATStep12Drift)>
    <DisplayName("Drift %")>
    <Description("" & vbCrLf &
                     "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public ReadOnly Property Step12DriftPercent As Double
        Get

            Dim out As Double

            out = Step12DriftValuesDB(Me.FOCUSDriftCrop, Me.NoOfApplns)

            Return out

        End Get
    End Property

    ''' <summary>
    ''' Step12 Mass loading
    ''' </summary>
    ''' <returns></returns>
    <Category(CATStep12Drift)>
    <DisplayName("Mass loading")>
    <Description("in mg/m^2" & vbCrLf &
                     "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <TypeConverter(GetType(dblConvSetDrift))>
    Public ReadOnly Property Step12MassLoading As Double
        Get

            Dim out As New Double
            out = calcMassLoading(
                    applnRate:=Me.ApplnRate,
                    drift:=Me.Step12DriftPercent)

            Return out

        End Get
    End Property

    <Category(CATStep12Drift)>
    <DisplayName("Drift PECsw")>
    <Description(" µg/L" & vbCrLf &
                     "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <TypeConverter(GetType(dblConvSetDrift))>
    Public ReadOnly Property Step12PECsw As Double
        Get

            Dim out As New Double

            out = calcPECsw(
                        applnRate:=Me.ApplnRate,
                        drift:=Me.Step12DriftPercent,
                        waterBodyDepth:=0.3)

            Return out

        End Get
    End Property

#End Region

#Region "06 Step03"

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_FOCUSSswScenario As eFOCUSswScenario = eFOCUSswScenario.not_defined

    ''' <summary>
    ''' FOCUSSswScenario
    ''' </summary>
    <Category(CATStep03Drift)>
    <DisplayName("FOCUSSsw Scenario")>
    <Description("" & vbCrLf &
                     "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(CInt(eFOCUSswScenario.not_defined))>
    Public Property FOCUSSswScenario As eFOCUSswScenario
        Get
            Return m_FOCUSSswScenario
        End Get
        Set(vFOCUSSswScenario As eFOCUSswScenario)

            Dim test As String()
            Dim index As Integer = -1

            If vFOCUSSswScenario.ToString.StartsWith("D") Then

                test = depthDrainCSV.First.Split(",")

                index =
                Array.FindIndex(
                array:=test,
                match:=Function(x) _
                            x = vFOCUSSswScenario.ToString & "_" &
                                FOCUSWaterBody.ToString.Substring(0, 2).ToUpper & "_" & Trim(
                                enumConverter(Of eFOCUSDriftCrop).getEnumDescription(FOCUSDriftCrop).Split(":").First))

                If index <> -1 Then
                    m_FOCUSSswScenario = vFOCUSSswScenario
                    drainageStartYear = depthDrainCSV(1).Split(",")(index)
                    csvIndex = index
                    ApplnDate = New Date(year:=drainageStartYear, month:=1, day:=1)
                Else
                    m_FOCUSSswScenario = eFOCUSswScenario.not_defined
                End If

            End If

        End Set
    End Property

    Public Property drainageStartYear As Integer = 1982
    Public Property csvIndex As Integer = -1

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_ApplnDate As Date = Date.MinValue



    ''' <summary>
    ''' Appln Date
    ''' </summary>
    <Category(CATStep03Drift)>
    <DisplayName("Appln  Date")>
    <Description("Application date" & vbCrLf &
                     "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public Property ApplnDate As Date
        Get
            Return m_ApplnDate
        End Get
        Set(vApplnDate As Date)

            Dim dateIndex As Integer

            dateIndex = (vApplnDate - New Date(year:=drainageStartYear, month:=1, day:=1)).TotalDays

            If dateIndex = 0 Then
                dateIndex = 2
            End If

            'm_FOCUSDepth = CDbl(depthDrainCSV(dateIndex).Split(",")(csvIndex))

            m_ApplnDate = vApplnDate

        End Set
    End Property

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_FOCUSDepth As Double = 0.3

    ''' <summary>
    ''' Depth
    ''' </summary>
    <Category(CATStep03Drift)>
    <DisplayName("Water Body depth")>
    <Description("Depth of the water body" & vbCrLf &
                     "in m, scenario specific!")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public Property FOCUSDepth As Double
        Get
            Return m_FOCUSDepth
        End Get
        Set(value As Double)

            m_FOCUSDepth = value

        End Set
    End Property


    <Category(CATStep03Drift)>
    <DisplayName("Drift %")>
    <Description("" & vbCrLf &
                     "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <TypeConverter(GetType(dblConvSetDrift))>
    Public ReadOnly Property Step03DriftPercent As Double
        Get

            Dim out As New Double

            out = calcDriftPercent(
                                noOfApplns:=Me.NoOfApplns,
                            FOCUSDriftCrop:=Me.FOCUSDriftCrop,
                            FOCUSWaterBody:=Me.FOCUSWaterBody)


            Return out

        End Get
    End Property

    <Category(CATStep03Drift)>
    <DisplayName("Mass loading")>
    <Description("mg/m^2" & vbCrLf &
                     "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <TypeConverter(GetType(dblConvSetDrift))>
    Public ReadOnly Property Step03MassLoading As Double
        Get

            Dim out As New Double

            out = calcMassLoading(
                    applnRate:=Me.ApplnRate,
                        drift:=Me.Step03DriftPercent)

            Return out

        End Get
    End Property

    <Category(CATStep03Drift)>
    <DisplayName("TXW Rows")>
    <Description("TXW drift loading rows" & vbCrLf &
                     "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    Public ReadOnly Property TXWDriftLoadingRowsStep03 As String
        Get

            Dim out As New List(Of String)
            Const Start As String = "30-Dec-1899    drift     "

            For counter = 0 To Me.NoOfApplns
                out.Add(Start &
                            Me.Step03MassLoading.ToString("E04") &
                            "  0.        " &
                            IIf(Me.FOCUSWaterBody = eFOCUSWaterBody.pond, "30", "100").ToString)
            Next

            Return Join(SourceArray:=out.ToArray, Delimiter:=vbCrLf)

        End Get
    End Property

    <Category(CATStep03Drift)>
    <DisplayName("DRIFT PECsw")>
    <Description(" µg/L" & vbCrLf &
                     "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <TypeConverter(GetType(dblConvSetDrift))>
    Public ReadOnly Property Step03PECsw As Double
        Get

            Dim out As New Double

            out = calcPECsw(
                        applnRate:=Me.ApplnRate,
                        drift:=Me.Step03DriftPercent,
                        waterBodyDepth:=Me.FOCUSDepth)

            Return out

        End Get
    End Property




#End Region

#Region "07 Step04"

    ''' <summary>
    ''' Overview PECsw
    ''' </summary>
    <Category(CATStep04Drift)>
    <DisplayName("Overview PECsw")>
    <Description("for 5m, 10m, 15m and 20m" & vbCrLf &
                     "in µg/L")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    Public ReadOnly Property OVW As String
        Get

            Dim out As New List(Of String)
            Dim bufferString As New List(Of String)


            Dim Buffers As New List(Of Double)


            For Buffer As Integer = 5 To 20 Step 5

                Buffers.Add(calcPECsw(
                       applnRate:=Me.ApplnRate,
                       noOfApplns:=Me.NoOfApplns,
                       FOCUSDriftCrop:=Me.FOCUSDriftCrop,
                       FOCUSWaterBody:=Me.FOCUSWaterBody,
                       bufferWidth:=Buffer, nozzleRedPerc:=Me.Nozzle))

                out.Add(
                conv2String(value:=Buffers.Last, format:="0.0000"))

                bufferString.Add((Buffer.ToString("00") & "m").PadLeft(("0.0000").Length))

            Next


            Return Join(out.ToArray, Delimiter:=" | ") & vbCrLf &
                    Join(bufferString.ToArray, Delimiter:=" | ")


        End Get
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_Step04Buffer As Double = Double.NaN

    ''' <summary>
    ''' Buffer length in m
    ''' 
    ''' </summary>
    <Category(CATStep04Drift)>
    <DisplayName("Buffer")>
    <Description("Step04 Buffer length in m" & vbCrLf &
                     "click '...' to set to FOCUS std.")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Editor(GetType(ButtonEmulatorDouble), GetType(UITypeEditor))>
    Public Property Step04Buffer As Double
        Get
            Return m_Step04Buffer
        End Get
        Set(vStep04Buffer As Double)

            If vStep04Buffer = ButtonEmulatorDouble.Clicked Then
                m_Step04Buffer = closest2EdgeOfField
            ElseIf vStep04Buffer < (distanceCrop2Bank + distanceBank2Water) Then
                m_Step04Buffer = distanceCrop2Bank + distanceBank2Water
            Else
                m_Step04Buffer = vStep04Buffer
            End If

        End Set
    End Property



    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_Nozzle As Integer = 0

    ''' <summary>
    ''' Nozzle
    ''' </summary>
    <Category(CATStep04Drift)>
    <DisplayName("Nozzle")>
    <Description("Drift reducing nozzle" & vbCrLf &
                     "from 0 (std.) to 100%")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0)>
    Public Property Nozzle As Integer
        Get
            Return m_Nozzle
        End Get
        Set(vNozzle As Integer)
            m_Nozzle = vNozzle
        End Set
    End Property



    ''' <summary>
    ''' Step04Drift
    ''' </summary>
    <Category(CATStep04Drift)>
    <DisplayName("FOCUS Step 04  Drift")>
    <Description("regarding buffer and nozzle red." & vbCrLf &
                     "in percent")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public ReadOnly Property Step04DriftPercent As Double
        Get

            Dim out As Double

            out =
                calcDriftPercent(
                    noOfApplns:=Me.NoOfApplns,
                    FOCUSDriftCrop:=Me.FOCUSDriftCrop,
                    FOCUSWaterBody:=Me.FOCUSWaterBody,
                    bufferWidth:=Me.Step04Buffer) * (100 - Me.Nozzle) / 100

            Return out

        End Get
    End Property


    <Category(CATStep04Drift)>
    <DisplayName("Mass loading")>
    <Description("mg/m^2" & vbCrLf &
                     "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public ReadOnly Property Step04MassLoading As Double
        Get

            Dim out As New Double

            out = calcMassLoading(
                    applnRate:=Me.ApplnRate,
                        drift:=Me.Step04DriftPercent)

            Return out

        End Get
    End Property


    <Category(CATStep04Drift)>
    <DisplayName("TXW Rows")>
    <Description("TXW drift loading rows" & vbCrLf &
                     "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    Public ReadOnly Property TXWDriftLoadingRowsStep04 As String
        Get

            Dim out As New List(Of String)
            Const Start As String = "30-Dec-1899    drift     "

            For counter = 0 To Me.NoOfApplns
                out.Add(Start &
                            Me.Step04MassLoading.ToString("E04") &
                            "  0.        " &
                            IIf(Me.FOCUSWaterBody = eFOCUSWaterBody.pond, "30", "100").ToString)
            Next

            Return Join(SourceArray:=out.ToArray, Delimiter:=vbCrLf)

        End Get
    End Property


    <Category(CATStep04Drift)>
    <Browsable(True)>
    <DisplayName("Rautmann Ditch Drift")>
    <Description("regarding buffer and nozzle red.")>
    Public ReadOnly Property RautmannDriftPercent As Double
        Get

            Return calcBasicRautmannDriftPerc(
                                NoOfApplns:=Me.NoOfApplns,
                                    Buffer:=Me.Step04Buffer) * (100 - Me.Nozzle) / 100

        End Get
    End Property

    ''' <summary>
    ''' Step04Drift
    ''' </summary>
    <Category(CATStep04Drift)>
    <DisplayName("Drift reduction")>
    <Description("Step03 -> Step04, in %" & vbCrLf &
                     "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    Public ReadOnly Property Step34DriftReduction As Integer
        Get

            Try
                Return 100 - CInt(Math.Round(Step04DriftPercent * 100 / Step03DriftPercent, digits:=0))
            Catch ex As Exception
                Return 0
            End Try

        End Get
    End Property


    ''' <summary>
    ''' Step04PECsw
    ''' </summary>
    <Category(CATStep04Drift)>
    <DisplayName("Step04 PECsw")>
    <Description("in µg/L" & vbCrLf &
                     "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public ReadOnly Property Step04PECsw As Double
        Get

            Dim out As Double = Double.NaN

            out = calcPECsw(
                       applnRate:=Me.ApplnRate,
                       noOfApplns:=Me.NoOfApplns,
                       FOCUSDriftCrop:=Me.FOCUSDriftCrop,
                       FOCUSWaterBody:=Me.FOCUSWaterBody,
                       bufferWidth:=Me.Step04Buffer,
                       nozzleRedPerc:=Me.Nozzle)

            Return out
        End Get
    End Property



#End Region

#Region "08 Risk Assessment"


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_EndPoint As Double = Double.NaN

    ''' <summary>
    ''' EndPoint
    ''' </summary>
    <Category(CATRiskAssessment)>
    <DisplayName("EndPoint")>
    <Description("Endpoints in µg/L" & vbCrLf &
                     "for the risk assessment for aquatic organisms")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(Double.NaN)>
    <XmlIgnore>
    Public Property EndPoint As Double = Double.NaN




    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_AssessmentFactor As Double = Double.NaN

    ''' <summary>
    ''' Assessment Factor
    ''' </summary>
    <Category(CATRiskAssessment)>
    <DisplayName("Assessment Factor")>
    <Description("" & vbCrLf &
                     "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(Double.NaN)>
    <XmlIgnore>
    Public Property AssessmentFactor As Double = Double.NaN



    ''' <summary>
    ''' Regulatory acceptable concentration in µg/L
    ''' </summary>
    <Category(CATRiskAssessment)>
    <DisplayName("RAC")>
    <Description("Regulatory acceptable concentration" & vbCrLf &
                     "in µg/L")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <XmlIgnore>
    Public ReadOnly Property RAC As Double
        Get
            If Double.IsNaN(EndPoint) OrElse
                    Double.IsNaN(AssessmentFactor) OrElse
                    AssessmentFactor = 0 Then

                Return Double.NaN

            Else

                getMinBuffer(Nozzles:=Me.Nozzles, RAC:=EndPoint / AssessmentFactor)
                'Return (EndPoint / AssessmentFactor).double2string2double(format:="G3")

            End If
        End Get
    End Property

    <Category(CATRiskAssessment)>
    Public Property Assessment As String() = {}



    Public Function getMinBuffer(Nozzles As Integer(), RAC As Double) As Integer()

        Dim out As New List(Of Integer)
        Dim PEC As Double = 1
        Dim Buffer As Integer = 0

        Dim Assessment As New List(Of String)
        Assessment.Add("Buffer Nozzle PEC/RAC")
        Assessment.Add("   [m]    [%]     [-]")
        ' Assessment.Add(" - Step 03 -  " & (Me.Step03PECsw / RAC).double2string.PadLeft("PEC/RAC".Length))

        For Each Nozzle As Integer In Nozzles

            PEC = 0
            Buffer = 0

            Do

                Buffer += 1

                PEC = calcPECsw(
                       applnRate:=Me.ApplnRate,
                       noOfApplns:=Me.NoOfApplns,
                       FOCUSDriftCrop:=Me.FOCUSDriftCrop,
                       FOCUSWaterBody:=Me.FOCUSWaterBody,
                       bufferWidth:=Buffer,
                       nozzleRedPerc:=Nozzle)


            Loop Until PEC / RAC < 1

            Assessment.Add(
                    IIf(Buffer > 1000, " >1000",
                        Buffer.ToString.PadLeft("Buffer".Length)).ToString & " " &
                    Nozzle.ToString.PadLeft("Nozzle".Length) & " ") '&
            '((PEC / RAC).double2string.PadLeft("PEC/RAC".Length)))

            out.Add(Buffer)

        Next

        Me.Assessment = Assessment.ToArray

        Return out.ToArray

    End Function



    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_Nozzles As Integer() = {0, 25, 50, 75, 90}

    ''' <summary>
    ''' Drift reducing nozzles
    ''' 0, 25, 50, 75, 90%
    ''' </summary>
    <Category(CATRiskAssessment)>
    <DisplayName("Drift red. Nozzles")>
    <Description("Drift reducing nozzles" & vbCrLf &
                     "from 0 (std.) to 100%")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <XmlIgnore>
    Public Property Nozzles As Integer()
        Get
            Return m_Nozzles
        End Get
        Set(vNozzles As Integer())
            m_Nozzles = vNozzles
        End Set
    End Property


#End Region


End Class

''' <summary>
''' TypeConverter(GetType(dblConvSetManager)) with formatSet
''' </summary>
Public Class dblConvSetDrift

    'usage : <TypeConverter(GetType(dblConvSetDrift))>

    Inherits DoubleConverter

#Region "    shared"

    Public Shared country As eCountry = stdCountry
    Public Shared dblFormat As String = stdDblformat
    Public Shared emptyString As String = stdEmptyString
    Public Shared minSign As String = stdMinSign
    Public Shared minValue As Double = stdMinValue
    Public Shared digits As Integer = stdDigits
    Public Shared unit As String = ""
    Public Shared negDef As Boolean = stdnegDef

#End Region

#Region "    Engine"

    <DebuggerStepThrough>
    Public Overrides Function ConvertTo(
                            context As ITypeDescriptorContext,
                            culture As CultureInfo,
                            value As Object,
                            destType As Type) As Object

        Try

            Return _
                conv2String(
                    value:=value,
                    format:=dblFormat,
                    country:=country,
                    minSign:=minSign,
                    minValue:=minValue,
                    unit:=unit,
                    digits:=digits,
                    negativeDefined:=negDef)

        Catch ex As Exception
            Return value
        End Try

    End Function

    <DebuggerStepThrough>
    Public Overrides Function ConvertFrom(
                            context As ITypeDescriptorContext,
                            culture As CultureInfo,
                            value As Object) As Object

        Dim valueString As String

        Try

            valueString = CType(value, String)

            If valueString.Contains(minSign) Then
                Return minValue
            ElseIf Double.IsNaN(Double.Parse(valueString)) Then
                Return Double.NaN
            Else
                Return Double.Parse(valueString)
            End If

        Catch ex As Exception
            Return Double.NaN
        End Try

    End Function

#End Region

#Region "    Format Set"

    ''' <summary>
    ''' Grid able settings manager
    ''' </summary>
    <TypeConverter(GetType(propGridConverter))>
    <Serializable>
    Public Class formatSet

        Public Sub New()

        End Sub

        Public Const CATMeta As String = ""
#Region "        Meta Info"

        ''' <summary>
        ''' Overview of the format setting
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <Browsable(False)>
        <[ReadOnly](True)>
        <DisplayName("Overview")>
        <Category(CATMeta)>
        Public ReadOnly Property name As String
            Get
                Return _
                Me.dblFormat & "; " &
                Me.country.ToString & "; " &
                Me.minSign & Me.minValue
            End Get
        End Property

        ''' <summary>
        ''' Reset to Std.
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <DefaultValue(True)>
        <DisplayName("Reset to Std.")>
        <Description("")>
        <Category(CATMeta)>
        Public Property set2Std As Boolean
            Get
                Return True
            End Get
            Set(value As Boolean)

                If value Then Exit Property

                dblFormat = stdDblformat
                country = stdCountry
                minSign = stdMinSign
                minValue = stdMinValue
                digits = stdDigits
                unit = stdUnit
                negDef = stdnegDef

            End Set
        End Property

#End Region

        Public Const CATMain As String = "Main"
#Region "        Main"

        'https://docs.microsoft.com/de-de/dotnet/api/system.double.tostring?view=net-5.0
        ''' <summary>
        ''' Format String
        ''' like '0.00', '0.00E00', E4 | std.  ='G4', 
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <DefaultValue(stdDblformat)>
        <DisplayName("Format String")>
        <Description("like '0.00', '0.00E00', E4 | std.  ='G4', ")>
        <Category(CATMain)>
        Public Property dblFormat As String
            Get
                Return dblConvSetDrift.dblFormat
            End Get
            Set
                dblConvSetDrift.dblFormat = Value
            End Set
        End Property

        ''' <summary>
        ''' Unit
        ''' Unit to display like 'µg/L', std. = ''
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <DefaultValue(stdDigits)>
        <DisplayName("Unit")>
        <Description("Unit to display like 'µg/L', std. = ''")>
        <Category(CATMain)>
        Public Property unit As String
            Get
                Return dblConvSetDrift.unit
            End Get
            Set
                dblConvSetDrift.unit = Value
            End Set
        End Property


        ''' <summary>
        ''' Min value
        ''' Display  min sign minValue when value  minValue > value
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <DefaultValue(stdMinValue)>
        <DisplayName("Min value")>
        <Description("Display <minValue when value < minValue")>
        <Category(CATMain)>
        Public Property minValue As Double
            Get
                Return dblConvSetDrift.minValue
            End Get
            Set
                dblConvSetDrift.minValue = Value
            End Set
        End Property

#End Region

        Public Const CATDetail As String = "Details"
#Region "        Details"

        'https://www.csharp-examples.net/culture-names/
        ''' <summary>
        ''' Country String
        ''' avail. for English, German and French
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <DefaultValue(CInt(stdCountry))>
        <DisplayName("Country String")>
        <Description("Avail. for English, German and French")>
        <Category(CATDetail)>
        Public Property country As eCountry
            Get
                Return dblConvSetDrift.country
            End Get
            Set
                dblConvSetDrift.country = Value
            End Set
        End Property

        ''' <summary>
        ''' NaN String
        ''' Display this string when value is NaN
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <DefaultValue(stdEmptyString)>
        <DisplayName("NaN String")>
        <Description("Display this string when value is NaN")>
        <Category(CATDetail)>
        Public Property emptyString As String
            Get
                Return dblConvSetDrift.emptyString
            End Get
            Set
                dblConvSetDrift.emptyString = Value
            End Set
        End Property

        ''' <summary>
        ''' Min sign, >
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <DefaultValue(stdMinSign)>
        <DisplayName("<")>
        <Description("")>
        <Category(CATDetail)>
        Public Property minSign As String
            Get
                Return dblConvSetDrift.minSign
            End Get
            Set
                dblConvSetDrift.minSign = Value
            End Set
        End Property

        ''' <summary>
        ''' Digits
        ''' Rounding digits, -1 = no rounding
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <DefaultValue(stdDigits)>
        <DisplayName("Digits")>
        <Description("Rounding digits, -1 = no rounding")>
        <Category(CATDetail)>
        Public Property digits As Integer
            Get
                Return dblConvSetDrift.digits
            End Get
            Set
                dblConvSetDrift.digits = Value
            End Set
        End Property


        ''' <summary>
        ''' Neg. Values Poss.
        ''' If true, there's no minValue
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <DefaultValue(stdDigits)>
        <DisplayName("Neg. Values Poss.")>
        <Description("If true, there's no minValue")>
        <Category(CATDetail)>
        Public Property negDef As Boolean
            Get
                Return dblConvSetDrift.negDef
            End Get
            Set
                dblConvSetDrift.negDef = Value
            End Set
        End Property

#End Region

    End Class

#End Region

End Class


