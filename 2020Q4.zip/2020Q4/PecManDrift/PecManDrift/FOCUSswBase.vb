﻿



Imports System.ComponentModel
Imports System.IO

Public Class FOCUSswBase

    ''' <summary>
    ''' Number of applns.
    ''' 1 - 8 (or more)
    ''' </summary>
    <TypeConverter(GetType(enumConverter(Of eNoOfApplns)))>
    Public Enum eNoOfApplns

        <Description("1")>
        one = 0
        <Description("2")>
        two
        <Description("3")>
        three
        <Description("4")>
        four
        <Description("5")>
        fife
        <Description("6")>
        six
        <Description("7")>
        seven
        <Description("8 or more")>
        eight

        <Description(" - ")>
        not_defined

    End Enum

    ''' <summary>
    ''' all FOCUSsw scenarios D1-6 and R1-4
    ''' </summary>
    <TypeConverter(GetType(enumConverter(Of eFOCUSswScenario)))>
    Public Enum eFOCUSswScenario

        <Description("D1, Lanna d,s")>
        D1 = 0
        <Description("D2, Brimstone d,s")>
        D2
        <Description("D3, Vredepeel d")>
        D3
        <Description("D4, Skousbo p,s")>
        D4
        <Description("D5, La Jailliere p,s")>
        D5
        <Description("D6, Thiva d")>
        D6

        <Description("R1, Weiherbach p/s")>
        R1
        <Description("R2, Porto s")>
        R2
        <Description("R3, Bologna s")>
        R3
        <Description("R4, Roujan s")>
        R4

        <Description(" - ")>
        not_defined

    End Enum


#Region "Crops"


    ''' <summary>
    ''' FOCUSsw DRIFT crops as enumeration
    ''' </summary>
    <TypeConverter(GetType(enumConverter(Of eFOCUSDriftCrop)))>
    Public Enum eFOCUSDriftCrop

        <Description("CS: Cereals, spring")>
        Cereals_spring = 0

        <Description("CW: Cereals, winter")>
        Cereals_winter

        '-------------------------------------------------------------

        <Description("CI: Citrus")>
        Citrus

        <Description("CO: Cotton")>
        Cotton

        '-------------------------------------------------------------

        <Description("FB: Field beans, 1st/2nd")>
        Field_beans

        <Description("GA: Grass/alfalfa")>
        Grass_alfalfa

        '-------------------------------------------------------------

        <Description("HP: Hops")>
        Hops

        '-------------------------------------------------------------

        <Description("LG: Legumes")>
        Legumes

        <Description("MZ: Maize")>
        Maize

        '-------------------------------------------------------------

        <Description("OS: Oil seed rape, spring")>
        Oil_seed_rape_spring

        <Description("OW: Oil seed rape, winter")>
        Oil_seed_rape_winter

        '-------------------------------------------------------------

        <Description("OL: Olives")>
        Olives


        <Description("PF: Pome/stone fruits, early")>
        Pome_stone_fruit_early_applns

        <Description("PF: Pome/stone fruits, late")>
        Pome_stone_fruit_late_applns

        '-------------------------------------------------------------

        <Description("PS: Potatoes, 1st/2nd")>
        Potatoes

        <Description("SY: Soybeans")>
        Soybeans

        <Description("SB: Sugar beets")>
        Sugar_beets

        <Description("SU: Sunflowers")>
        Sunflowers

        '-------------------------------------------------------------

        <Description("TB: Tobacco")>
        Tobacco

        '-------------------------------------------------------------

        <Description("VB: Vegetables, bulb, 1st/2nd")>
        Vegetables_bulb

        <Description("VF: Vegetables, fruiting")>
        Vegetables_fruiting

        <Description("VL: Vegetables, leafy, 1st/2nd")>
        Vegetables_leafy

        <Description("VR: Vegetables, root, 1st/2nd")>
        Vegetables_root

        '-------------------------------------------------------------

        <Description("VI: Vines, early")>
        Vines_early_applns

        <Description("VI: Vines, late")>
        Vines_late_applns

        '-------------------------------------------------------------

        <Description("Aerial appln.")>
        Aerial


        <Description("Appln, hand" & vbCrLf &
                     " (crop < 50 cm)")>
        HandAppLow

        <Description("Appln, hand" & vbCrLf &
                     " (crop > 50 cm)")>
        HandAppHigh


        <Description("No drift" & vbCrLf &
                     " (incorp or seed trtmt)")>
        NoDrift


        <Description(" - ")>
        not_defined

    End Enum


    ''' <summary>
    ''' Ganzelmeier crop groups
    ''' </summary>
    <TypeConverter(GetType(enumConverter(Of eGanzelmeier)))>
    Public Enum eGanzelmeier

        <Description("Arable crops")>
        ArableCrops = 0

        <Description("Fruit crops, early")>
        FruitCrops_Early
        <Description("Fruit crops, late")>
        FruitCrops_Late

        <Description("Hops")>
        Hops

        <Description("Vines, early")>
        Vines_Early
        <Description("Vines, late")>
        Vines_Late

        <Description("Aerial appln")>
        AerialAppln

        <Description("no drift")>
        noDrift

        <Description(" - ")>
        not_defined

    End Enum


    ''' <summary>
    ''' convert FOCUSsw DRIFT crop to Ganzelmeier crop group
    ''' </summary>
    Public Shared FOCUSCrop2Ganzelmeier As eGanzelmeier() =
   {
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.FruitCrops_Late,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.Hops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.FruitCrops_Late,
       eGanzelmeier.FruitCrops_Early,
       eGanzelmeier.FruitCrops_Late,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.Vines_Early,
       eGanzelmeier.Vines_Late,
       eGanzelmeier.AerialAppln,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.Vines_Late,
       eGanzelmeier.noDrift,
       eGanzelmeier.not_defined
   }

#End Region

#Region "Water body"

    ''' <summary>
    ''' FOCUS water body
    ''' ditch, stream or pond
    ''' </summary>
    <TypeConverter(GetType(enumConverter(Of eFOCUSWaterBody)))>
    Public Enum eFOCUSWaterBody

        ditch = 0
        stream
        pond

        not_defined

    End Enum

    Public Enum eWBMember

        Witdth
        Length
        Depth
        DistanceBankWater
        Factor

    End Enum

    Public Shared WaterBodyDB As Double(,) =
    {
        {1, 100, 0.3, 0.5, 1},
        {1, 100, 0.3, 1, 1.2},
        {30, 30, 1, 3, 1}
    }

    Public Shared RunOffStreamDepths As Double() = {0.41, 0.3, 0.29, 0.41}

#End Region

#Region "Std. FOCUS Step03 buffer distance in m"

    Public Shared Function getFOCUSStdDistance(FOCUSDriftCrop As eFOCUSDriftCrop,
                                               FOCUSWaterBody As eFOCUSWaterBody,
                                               FOCUSStdDistancesMember As eFOCUSStdDistancesMember) As Double

        Dim FOCUSStdDistancesEntry As String = ""
        Dim CropString As String = String.Empty


        CropString = enumConverter(Of eFOCUSDriftCrop).getEnumDescription(FOCUSDriftCrop)

        CropString =
            Replace(
            Expression:=CropString,
            Find:=", early applns",
            Replacement:="",
            Compare:=CompareMethod.Text)

        CropString =
            Replace(
            Expression:=CropString,
            Find:=", late applns",
            Replacement:="",
            Compare:=CompareMethod.Text)

        Try


            FOCUSStdDistancesEntry =
                Array.Find(
                array:=
                    Filter(
                        Source:=FOCUSStdDistances,
                        Match:=FOCUSWaterBody.ToString,
                        Include:=True,
                        Compare:=CompareMethod.Text),
                match:=Function(x) x.StartsWith(CropString.Substring(0, 2)))


            FOCUSStdDistancesEntry =
                FOCUSStdDistancesEntry.Split({"|"c})(FOCUSStdDistancesMember)

            Return CDbl(FOCUSStdDistancesEntry)

        Catch ex As Exception
            Return Double.NaN
        End Try

    End Function


    Public Enum eFOCUSStdDistancesMember

        cropShort
        cropString
        waterbody
        edgeField2topBank
        topBank2edgeWaterbody

    End Enum


    Public Shared FOCUSStdDistances As String() =
            {
"CS|cereals, spring|ditch|0.5|0.5",
"CS|cereals, spring|stream|0.5|1",
"CS|cereals, spring|pond|0.5|3",
"CW|cereals, winter|ditch|0.5|0.5",
"CW|cereals, winter|stream|0.5|1",
"CW|cereals, winter|pond|0.5|3",
"GA|grass/alfalfa|ditch|0.5|0.5",
"GA|grass/alfalfa|stream|0.5|1",
"GA|grass/alfalfa|pond|0.5|3",
"OS|oil seed rape, spring|ditch|0.5|0.5",
"OS|oil seed rape, spring|stream|0.5|1",
"OS|oil seed rape, spring|pond|0.5|3",
"OW|oil seed rape, winter|ditch|0.5|0.5",
"OW|oil seed rape, winter|stream|0.5|1",
"OW|oil seed rape, winter|pond|0.5|3",
"VB|vegetables, bulb|ditch|0.5|0.5",
"VB|vegetables, bulb|stream|0.5|1",
"VB|vegetables, bulb|pond|0.5|3",
"VF|vegetables, fruiting|ditch|0.5|0.5",
"VF|vegetables, fruiting|stream|0.5|1",
"VF|vegetables, fruiting|pond|0.5|3",
"VL|vegetables, leafy|ditch|0.5|0.5",
"VL|vegetables, leafy|stream|0.5|1",
"VL|vegetables, leafy|pond|0.5|3",
"VR|vegetables, root|ditch|0.5|0.5",
"VR|vegetables, root|stream|0.5|1",
"VR|vegetables, root|pond|0.5|3",
"K5|appln, hand (crop < 50 cm)|ditch|0.5|0.5",
"K5|appln, hand (crop < 50 cm)|stream|0.5|1",
"K5|appln, hand (crop < 50 cm)|pond|0.5|3",
"PS|potatoes|ditch|0.8|0.5",
"PS|potatoes|stream|0.8|1",
"PS|potatoes|pond|0.8|3",
"SY|soybeans|ditch|0.8|0.5",
"SY|soybeans|stream|0.8|1",
"SY|soybeans|pond|0.8|3",
"SB|sugar beets|ditch|0.8|0.5",
"SB|sugar beets|stream|0.8|1",
"SB|sugar beets|pond|0.8|3",
"SF|sunflowers|ditch|0.8|0.5",
"SF|sunflowers|stream|0.8|1",
"SF|sunflowers|pond|0.8|3",
"CO|cotton|ditch|0.8|0.5",
"CO|cotton|stream|0.8|1",
"CO|cotton|pond|0.8|3",
"FB|field beans|ditch|0.8|0.5",
"FB|field beans|stream|0.8|1",
"FB|field beans|pond|0.8|3",
"LG|legumes|ditch|0.8|0.5",
"LG|legumes|stream|0.8|1",
"LG|legumes|pond|0.8|3",
"MZ|maize|ditch|0.8|0.5",
"MZ|maize|stream|0.8|1",
"MZ|maize|pond|0.8|3",
"TB|tobacco|ditch|1|0.5",
"TB|tobacco|stream|1|1",
"TB|tobacco|pond|1|3",
"CI|citrus|ditch|3|0.5",
"CI|citrus|stream|3|1",
"CI|citrus|pond|3|3",
"HP|hops|ditch|3|0.5",
"HP|hops|stream|3|1",
"HP|hops|pond|3|3",
"OL|olives|ditch|3|0.5",
"OL|olives|stream|3|1",
"OL|olives|pond|3|3",
"PF|pome/stone fruits|ditch|3|0.5",
"PF|pome/stone fruits|stream|3|1",
"PF|pome/stone fruits|pond|3|3",
"VI|vines|ditch|3|0.5",
"VI|vines|stream|3|1",
"VI|vines|pond|3|3",
"G5|appln, hand (crop > 50 cm)|ditch|3|0.5",
"G5|appln, hand (crop > 50 cm)|stream|3|1",
"G5|appln, hand (crop > 50 cm)|pond|3|3",
"AA|appln, aerial|ditch|5|0.5",
"AA|appln, aerial|stream|5|1",
"AA|appln, aerial|pond|5|3"
            }

#End Region

#Region "Rautmann"

    Public Shared powerParameter_a As Double() =
        {2.7705, 2.3816, 2.0093, 1.8542, 1.7488, 1.6429, 1.6111, 1.5222}

    Public Shared powerParameter_b As Double() =
        {-0.9787, -1.005, -0.9922, -0.9907, -0.9885, -0.9843, -0.9847, -0.9817}

    Public Shared Function calcBasicRautmannDriftPerc(
                                     NoOfApplns As eNoOfApplns,
                                     Buffer As Double) As Double

        Try
            Return powerParameter_a(NoOfApplns) * Buffer ^ powerParameter_b(NoOfApplns)
        Catch ex As Exception
            Return Double.NaN
        End Try

    End Function

#End Region

#Region "Step12"

    Public Shared Step12DriftValuesDB As Double(,) =
    {
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {15.725, 12.129, 11.011, 10.124, 9.743, 9.204, 9.102, 8.656},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {19.326, 17.723, 15.928, 15.378, 15.114, 14.902, 14.628, 13.52},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {15.725, 12.129, 11.011, 10.124, 9.743, 9.204, 9.102, 8.656},
    {29.197, 25.531, 23.96, 23.603, 23.116, 22.76, 22.69, 22.241},
    {15.725, 12.129, 11.011, 10.124, 9.743, 9.204, 9.102, 8.656},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.699, 2.496, 2.546, 2.499, 2.398, 2.336, 2.283, 2.265},
    {8.028, 7.119, 6.898, 6.631, 6.636, 6.431, 6.227, 6.173},
    {33.2, 33.2, 33.2, 33.2, 33.2, 33.2, 33.2, 33.2},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {8.028, 7.119, 6.898, 6.631, 6.636, 6.431, 6.227, 6.173},
    {0, 0, 0, 0, 0, 0, 0, 0},
    {-1, -1, -1, -1, -1, -1, -1, -1}
    }


    ''' <summary>
    ''' get the Step12 drift percent from db
    ''' </summary>
    ''' <param name="NoOfApplns">
    ''' No of applications from 1 to 8 (one - eight)
    ''' </param>
    ''' <param name="FOCUSDriftCrop">
    ''' FOCUS DRIFT crop as enum like 
    ''' eFOCUSCrop.SugarBeets
    ''' </param>
    ''' <returns>
    ''' Step12 drift percent as double
    ''' or double.NaN
    ''' </returns>
    ''' <remarks></remarks>
    Public Shared Function getStep12DriftPercent(NoOfApplns As eNoOfApplns,
                                                 FOCUSDriftCrop As eFOCUSDriftCrop) As Double

        If NoOfApplns = eNoOfApplns.not_defined OrElse
            FOCUSDriftCrop = eFOCUSDriftCrop.not_defined Then Return Double.NaN

        Try

            Return Step12DriftValuesDB(FOCUSDriftCrop, NoOfApplns)

        Catch ex As Exception
            Return Double.NaN
        End Try

    End Function

#End Region

#Region "Step 34"

#Region "Regression"

    Public Shared Property regressionA As Double(,) =
    {
        {2.7593, 2.4376, 2.0244, 1.8619, 1.7942, 1.6314, 1.5784, 1.5119},
        {66.702, 62.272, 58.796, 58.947, 58.111, 58.829, 59.912, 59.395},
        {60.396, 42.002, 40.12, 36.273, 34.591, 31.64, 31.561, 29.136},
        {58.247, 66.243, 60.397, 58.559, 59.548, 60.136, 59.774, 53.2},
        {15.793, 15.461, 16.887, 16.484, 15.648, 15.119, 14.675, 14.948},
        {44.769, 40.262, 39.314, 37.401, 37.767, 36.908, 35.498, 35.094},
        {50.47, 50.47, 50.47, 50.47, 50.47, 50.47, 50.47, 50.47}
    }

    Public Shared Property regressionB As Double(,) =
    {
        {-0.9778, -1.01, -0.9956, -0.9861, -0.9943, -0.9861, -0.9811, -0.9832},
        {-0.752, -0.8116, -0.8171, -0.8331, -0.8391, -0.8644, -0.8838, -0.8941},
        {-1.2249, -1.1306, -1.1769, -1.1616, -1.1533, -1.1239, -1.1318, -1.1048},
        {-1.0042, -1.2001, -1.2132, -1.2171, -1.2481, -1.2699, -1.2813, -1.2469},
        {-1.608, -1.6599, -1.7223, -1.7172, -1.7072, -1.6999, -1.6936, -1.7177},
        {-1.5643, -1.5771, -1.5842, -1.5746, -1.5829, -1.5905, -1.5844, -1.5819},
        {-0.3819, -0.3819, -0.3819, -0.3819, -0.3819, -0.3819, -0.3819, -0.3819}
    }

    'only used for fruit/early, fruit/late and hops
    Public Shared Property regressionC As Double(,) =
    {
        {2.7593, 2.4376, 2.0244, 1.8619, 1.7942, 1.6314, 1.5784, 1.5119},
        {3867.9, 7961.7, 9598.8, 8609.8, 7684.6, 7065.6, 7292.9, 7750.9},
        {210.7, 298.76, 247.78, 201.98, 197.08, 228.69, 281.84, 256.33},
        {8654.9, 5555.3, 4060.9, 3670.4, 2860.6, 2954, 3191.6, 3010.1},
        {15.793, 15.461, 16.887, 16.484, 15.648, 15.119, 14.675, 14.948},
        {44.769, 40.262, 39.314, 37.401, 37.767, 36.908, 35.498, 35.094},
        {281.06, 281.06, 281.06, 281.06, 281.06, 281.06, 281.06, 281.06}
    }

    'only used for fruit/early, fruit/late and hops
    Public Shared Property regressionD As Double(,) =
    {
        {-0.9778, -1.01, -0.9956, -0.9861, -0.9943, -0.9861, -0.9811, -0.9832},
        {-2.4183, -2.6854, -2.7706, -2.7592, -2.7366, -2.7323, -2.7463, -2.7752},
        {-1.7599, -1.9464, -1.9299, -1.8769, -1.8799, -1.9519, -2.0087, -1.9902},
        {-2.8354, -2.8231, -2.7625, -2.7619, -2.7036, -2.7269, -2.7665, -2.7549},
        {-1.608, -1.6599, -1.7223, -1.7172, -1.7072, -1.6999, -1.6936, -1.7177},
        {-1.5643, -1.5771, -1.5842, -1.5746, -1.5829, -1.5905, -1.5844, -1.5819},
        {-0.9989, -0.9989, -0.9989, -0.9989, -0.9989, -0.9989, -0.9989, -0.9989}
    }

    'distance limit for each regression (m), also called hinge point.
    Public Shared Property hingePointDB As Double(,) =
    {
        {1, 1, 1, 1, 1, 1, 1, 1},
        {11.4, 13.3, 13.6, 13.3, 13.1, 13, 13.2, 13.3},
        {10.3, 11.1, 11.2, 11, 11, 10.9, 12.1, 11.7},
        {15.3, 15.3, 15.1, 14.6, 14.3, 14.5, 14.6, 14.6},
        {1, 1, 1, 1, 1, 1, 1, 1},
        {1, 1, 1, 1, 1, 1, 1, 1},
        {16.2, 16.2, 16.2, 16.2, 16.2, 16.2, 16.2, 16.2}
    }

#End Region


#Region "Methods"

    ''' <summary>
    ''' Distances
    ''' nearest, farthest, average
    ''' </summary>
    <TypeConverter(GetType(enumConverter(Of eDriftDistance)))>
    Public Enum eDriftDistance
        <Description("Drift at edge nearest field")>
        closest
        <Description("Drift farthest to the edge of the field")>
        farthest
        <Description("Areic mean drift")>
        average
    End Enum


    ''' <summary>
    ''' calculation of FOCUS drift values
    ''' </summary>
    ''' <param name="noOfApplns">
    ''' # of applications, 1 - 8
    ''' </param>
    ''' <param name="FOCUSDriftCrop">
    ''' FOCUS crop
    ''' </param>
    ''' <param name="FOCUSWaterBody">
    ''' Ditch, pond or stream
    ''' </param>
    ''' <param name="bufferWidth">
    ''' Buffer width in m, -1 = FOCUS std. width
    ''' </param>
    ''' <returns>
    ''' FOCUS drift in percent as double
    ''' </returns>
    ''' <remarks></remarks>
    Public Shared Function calcDriftPercent(
                                    noOfApplns As eNoOfApplns,
                                    FOCUSDriftCrop As eFOCUSDriftCrop,
                                    FOCUSWaterBody As eFOCUSWaterBody,
                           Optional bufferWidth As Double = Double.NaN,
                           Optional DriftDistance As eDriftDistance = eDriftDistance.average) As Double

        'drift for output
        Dim Drift As Double = Double.NaN

        'Application
        Dim Ganzelmeier As eGanzelmeier = eGanzelmeier.not_defined
        Dim FOCUSStdDistance As Double = Double.NaN

        'regression parameters
        Dim A As Double = Double.NaN
        Dim B As Double = Double.NaN

        Dim C As Double = Double.NaN
        Dim D As Double = Double.NaN

        'set buffer width to FOCUS std.
        Dim hingePoint As Double = Double.NaN
        Dim edgeField2topBank As Double = Double.NaN
        Dim topBank2edgeWaterbody As Double = Double.NaN
        Dim closest2EdgeOfField As Double = Double.NaN
        Dim farthest2EdgeOfField As Double = Double.NaN

        Dim targetLine As String = ""

        If Double.IsNaN(bufferWidth) Then

            edgeField2topBank = getFOCUSStdDistance(
                            FOCUSDriftCrop:=FOCUSDriftCrop,
                            FOCUSWaterBody:=FOCUSWaterBody,
                            FOCUSStdDistancesMember:=eFOCUSStdDistancesMember.edgeField2topBank)

        End If

        'get Ganzelmeier crop group
        Ganzelmeier = FOCUSCrop2Ganzelmeier(FOCUSDriftCrop)

        'FOCUS Step03 std. 'buffer' distance, topBank2edgeWaterbody
        topBank2edgeWaterbody = getFOCUSStdDistance(
                            FOCUSDriftCrop:=FOCUSDriftCrop,
                            FOCUSWaterBody:=FOCUSWaterBody,
                            FOCUSStdDistancesMember:=eFOCUSStdDistancesMember.topBank2edgeWaterbody)


        'distances
        'distance limit for each regression in m, hinge point

        hingePoint = hingePointDB(Ganzelmeier, noOfApplns)


        'distance from crop at edge nearest to field
        If Double.IsNaN(bufferWidth) Then
            closest2EdgeOfField = edgeField2topBank + topBank2edgeWaterbody
        Else
            closest2EdgeOfField = bufferWidth
        End If

        'distance from crop at edge farthest from field
        If Double.IsNaN(bufferWidth) Then
            farthest2EdgeOfField = edgeField2topBank + topBank2edgeWaterbody + WaterBodyDB(FOCUSWaterBody, eWBMember.Witdth)
        Else
            farthest2EdgeOfField = bufferWidth + WaterBodyDB(FOCUSWaterBody, eWBMember.Witdth)
        End If

        'get regression parameter
        A = regressionA(Ganzelmeier,
                        noOfApplns)

        B = regressionB(Ganzelmeier,
                        noOfApplns)

        C = regressionC(Ganzelmeier,
                        noOfApplns)

        D = regressionD(Ganzelmeier,
                        noOfApplns)

        Select Case DriftDistance

            Case eDriftDistance.farthest

                Try

                    If farthest2EdgeOfField < hingePoint Then
                        Drift = A * (farthest2EdgeOfField ^ B)
                    Else
                        Drift = C * (farthest2EdgeOfField ^ D)
                    End If

                Catch ex As Exception
                    Throw New _
                        ArithmeticException(
                        message:="Error during drift calc.",
                        innerException:=ex)
                End Try

            Case eDriftDistance.closest

                Try

                    If closest2EdgeOfField < hingePoint Then
                        Drift = A * (closest2EdgeOfField ^ B)
                    Else
                        Drift = C * (closest2EdgeOfField ^ D)
                    End If

                Catch ex As Exception
                    Throw New _
                        ArithmeticException(
                        message:="Error during drift calc.",
                        innerException:=ex)
                End Try

            Case eDriftDistance.average

                Try

                    If farthest2EdgeOfField < hingePoint Then
                        Drift = (A / (B + 1) * (farthest2EdgeOfField ^ (B + 1) - closest2EdgeOfField ^ (B + 1))) /
                                          (farthest2EdgeOfField - closest2EdgeOfField)
                    ElseIf closest2EdgeOfField > hingePoint Then
                        Drift = C / (D + 1) * (farthest2EdgeOfField ^ (D + 1) - closest2EdgeOfField ^ (D + 1)) /
                                          (farthest2EdgeOfField - closest2EdgeOfField)
                    Else
                        Drift = (A / (B + 1) * (hingePoint ^ (B + 1) - closest2EdgeOfField ^ (B + 1)) + C / (D + 1) * (farthest2EdgeOfField ^ (D + 1) - hingePoint ^ (D + 1))) * 1 /
                                          (farthest2EdgeOfField - closest2EdgeOfField)
                    End If

                Catch ex As Exception
                    Throw New _
                        ArithmeticException(
                        message:="Error during drift calc.",
                        innerException:=ex)
                End Try

        End Select

        ' if stream then apply upstream catchment factor 1.2
        Drift = Drift * WaterBodyDB(FOCUSWaterBody, eWBMember.Factor)

        Return Drift

    End Function


    ''' <summary>
    ''' Calculation of mass loading for TOXSWA in mg/m^2 of water surface; ApplnRate * Drift
    ''' </summary>
    ''' <param name="applnRate">
    ''' Application rate in kg/ha
    ''' </param>
    ''' <param name="drift">
    ''' FOCUS drift in percent, 0 - 100%
    ''' </param>
    ''' <returns>
    ''' Mass loading in mg/m^2 of water surface as double
    ''' </returns>
    ''' <remarks></remarks>
    Public Shared Function calcMassLoading(applnRate As Double,
                                           drift As Double) As Double

        Try
            Return applnRate * drift
        Catch ex As Exception
            Throw New _
                        ArithmeticException(
                        message:="Error during MassLoading calc.",
                        innerException:=ex)
        End Try

    End Function


    ''' <summary>
    ''' Calculation of dirft PECsw in µg/L
    '''  
    '''             applnRate
    ''' PECsw =  --------------------- 
    '''          waterBodyDepth * drift
    ''' 
    ''' </summary>
    ''' <param name="applnrate">
    ''' Application rate in kg/ha
    ''' </param>
    ''' <param name="drift">
    ''' FOCUS drift in percent, 0 - 100%
    ''' </param>
    ''' <param name="waterBodyDepth">
    ''' Depth of water body in m, std. 0.3m for ditch and stream, 1m for pond
    ''' </param>
    ''' <returns>
    ''' PECsw in µg/L as double
    ''' </returns>
    ''' <remarks></remarks>
    Public Shared Function calcPECsw(applnRate As Double,
                                     drift As Double,
                            Optional waterBodyDepth As Double = 0.3) As Double

        Try
            Return applnRate / waterBodyDepth * drift
        Catch ex As Exception
            Throw New _
                        ArithmeticException(
                        message:="Error during PECsw calc.",
                        innerException:=ex)
        End Try

    End Function


    ''' <summary>
    ''' Calculation of drift PECsw in µg/L
    ''' </summary>
    ''' <param name="NoOfApplns">
    ''' # of applications, 1 - 8
    ''' </param>
    ''' <param name="ApplnRate">
    ''' Application rate in kg/ha
    ''' </param>
    ''' <param name="FOCUSDriftCrop">
    ''' FOCUS Step34 crop
    ''' </param>
    ''' <param name="FOCUSWaterBody">
    ''' Ditch, pond or stream
    ''' </param>
    ''' <param name="BufferWidth">
    ''' Buffer width in m, -1 = FOCUS std. width
    ''' </param>
    ''' <param name="depth">
    ''' Depth of water body in m, std. 0.3m for ditch and stream, 1m for pond
    ''' </param>
    ''' <param name="nozzleRedPerc">
    ''' Drift reducing Nozzle in percent (0 - 100) reduction 
    ''' std = 0 = no reduction
    ''' </param>
    ''' <returns>
    ''' Drift PECsw in µg/L as double
    ''' </returns>
    ''' <remarks></remarks>
    Public Shared Function calcPECsw(noOfApplns As eNoOfApplns,
                                     applnRate As Double,
                                     FOCUSDriftCrop As eFOCUSDriftCrop,
                                     FOCUSWaterBody As eFOCUSWaterBody,
                            Optional depth As Double = Double.NaN,
                            Optional bufferWidth As Double = Double.NaN,
                            Optional nozzleRedPerc As Double = 0) As Double

        Dim drift As Double = Double.NaN


        'calc drift
        Try
            drift = calcDriftPercent(
                            noOfApplns:=noOfApplns,
                             FOCUSDriftCrop:=FOCUSDriftCrop,
                           bufferWidth:=bufferWidth,
                             FOCUSWaterBody:=FOCUSWaterBody)


        Catch ex As Exception
            Return Double.NaN
        End Try

        If Double.IsNaN(depth) Then
            depth = WaterBodyDB(FOCUSWaterBody, eWBMember.Depth)
        End If

        'nozzle reduction
        drift = drift * ((100 - nozzleRedPerc) / 100)

        Try
            Return calcPECsw(
                        applnRate:=applnRate,
                            drift:=drift,
                   waterBodyDepth:=depth)
        Catch ex As Exception
            Throw New _
                        ArithmeticException(
                        message:="Error during PECsw calc.",
                        innerException:=ex)
        End Try

    End Function

    ''' <summary>
    ''' Calculation of simple R1-R4 drift PECsw ;-)
    ''' </summary>
    ''' <param name="NoOfApplns">
    ''' # of applications, 1 - 8
    ''' </param>
    ''' <param name="applnRate">
    ''' Application rate in kg/ha
    ''' </param>
    ''' <param name="applnDate">
    ''' Date of Application
    ''' </param>
    ''' <param name="FOCUSDriftCrop">
    ''' FOCUS Step34 crop
    ''' </param>
    ''' <param name="WaterBody">
    ''' Ditch, pond or stream
    ''' </param>
    ''' <param name="BufferWidth">
    ''' Buffer width in m, -1 = FOCUS std. width
    ''' </param>
    ''' <param name="FOCUSswScenario">
    ''' Scenario D1 - D6, R1 - R4
    ''' </param>
    ''' <param name="nozzleRedPerc">
    ''' Drift reducing Nozzle in percent (0 - 100) reduction 
    ''' std = 0 = no reduction
    ''' </param>
    ''' <returns>
    ''' Drift PECsw in µg/L as double
    ''' </returns>
    ''' <remarks></remarks>
    Public Shared Function calcPECsw(
                                     noOfApplns As eNoOfApplns,
                                     applnRate As Double,
                                     applnDate As Date,
                                     FOCUSDriftCrop As eFOCUSDriftCrop,
                                     waterBody As eFOCUSWaterBody,
                                     FOCUSswScenario As eFOCUSswScenario,
                                     HydInfo As Object,
                            Optional bufferWidth As Double = Double.NaN,
                            Optional nozzleRedPerc As Double = 0) As Double


        Dim depth As Double = 0.3

        Try
            depth = HydInfo.getWaterBodyDepth(
                            ApplnDate:=applnDate,
                            FOCUSScenario:=FOCUSswScenario,
                            FOCUSDriftCrop:=FOCUSDriftCrop,
                            waterbody:=waterBody)
        Catch ex As Exception

        End Try



        Return calcPECsw(
            noOfApplns:=noOfApplns,
            applnRate:=applnRate,
            FOCUSDriftCrop:=FOCUSDriftCrop,
            FOCUSWaterBody:=waterBody,
            depth:=depth,
            bufferWidth:=bufferWidth,
            nozzleRedPerc:=nozzleRedPerc)

    End Function

    ''' <summary>
    ''' Calculation of simple R1-R4 drift PECsw ;-)
    ''' </summary>
    ''' <param name="NoOfApplns">
    ''' # of applications, 1 - 8
    ''' </param>
    ''' <param name="ApplnRate">
    ''' Application rate in kg/ha
    ''' </param>
    ''' <param name="FOCUSDriftCrop">
    ''' FOCUS Step34 crop
    ''' </param>
    ''' <param name="WaterBody">
    ''' Ditch, pond or stream
    ''' </param>
    ''' <param name="BufferWidth">
    ''' Buffer width in m, -1 = FOCUS std. width
    ''' </param>
    ''' <param name="RunOffScenario">
    ''' RunOff scenario R1 - R4
    ''' </param>
    ''' <param name="nozzleRedPerc">
    ''' Drift reducing Nozzle in percent (0 - 100) reduction 
    ''' std = 0 = no reduction
    ''' </param>
    ''' <returns>
    ''' Drift PECsw in µg/L as double
    ''' </returns>
    ''' <remarks></remarks>
    Public Shared Function calcPECsw(
                                     noOfApplns As eNoOfApplns,
                                     applnRate As Double,
                                     FOCUSDriftCrop As eFOCUSDriftCrop,
                                     RunOffScenario As eFOCUSswScenario,
                            Optional waterBody As eFOCUSWaterBody = eFOCUSWaterBody.stream,
                            Optional bufferWidth As Double = Double.NaN,
                            Optional nozzleRedPerc As Double = 0) As Double


        If RunOffScenario.ToString.StartsWith("D") Then Return Double.NaN

        Return calcPECsw(
           noOfApplns:=noOfApplns,
           applnRate:=applnRate,
           FOCUSDriftCrop:=FOCUSDriftCrop,
           FOCUSWaterBody:=waterBody,
           depth:=RunOffStreamDepths(RunOffScenario - 6),
           bufferWidth:=bufferWidth,
           nozzleRedPerc:=nozzleRedPerc)

    End Function

#End Region


#End Region

#Region "Scenarios per Crop"

    Public Shared SwScenariosPerCrop As String() =
          {
          "CS:Cereals, Spring+D1|D3|D4|D5|R4",
          "CW:Cereals, Winter+D1|D2|D3|D4|D5|D6|R1|R3|R4",
          "CI:Citrus+D6|R4",
          "CO:Cotton+D6",
          "FB:Field beans 1st+D2|D3|D4|D6|R1|R2|R3|R4",
          "FB:Field beans 2nd+D6",
          "GA:Grass/alfalfa+D1|D2|D3|D4|D5|R2|R3",
          "HP:Hops+R1",
          "LG:Legumes+D3|D4|D5|D6|R1|R2|R3|R4",
          "MZ:Maize+D3|D4|D5|D6|R1|R2|R3|R4",
          "OS:Oil seed rape, spring+D1|D3|D4|D5|R1",
          "OW:Oil seed rape, winter+D2|D3|D4|D5|R1|R3",
          "OL:Olives+D6|R4",
          "PF:Pome/stone fruits+D3|D4|D5|R1|R2|R3|R4",
          "PS:Potatoes 1st+D3|D4|D6|R1|R2|R3",
          "PD:Potatoes 2nd+D6",
          "SY:Soybeans+R3|R4",
          "SB:Sugar beets+D3|D4|R1|R3",
          "SU:Sunflowers+D5|R1|R3|R4",
          "TB:Tobacco+R3",
          "VB:Vegetables, bulb 1st+D3|D4|D6|R1|R2|R3|R4",
          "VB:Vegetables, bulb 2nd+D6",
          "VF:Vegetables, fruiting+D6|R2|R3|R4",
          "VL:Vegetables, leafy 1st+D3|D4|D6|R1|R2|R3|R4",
          "VL:Vegetables, leafy 2nd+D3|R1|R2|R3|R4",
          "VR:Vegetables, root 1st+D3|D6|R1|R2|R3|R4",
          "VR:Vegetables, root 2nd+R2",
          "VI:Vines+D6|R1|R2|R3|R4"
          }

    Public Enum eEntry
        drainage
        runoff
        both
    End Enum

    <DebuggerStepThrough>
    Public Shared Function getScenariosPerCrop(FOCUSswDriftCrop As eFOCUSDriftCrop,
                                        Optional entry As eEntry = eEntry.both) As String()


        If FOCUSswDriftCrop = eFOCUSDriftCrop.not_defined Then
            Return {}
        End If

        Dim cropData As String = ""
        Dim cropName =
            enumConverter(Of eFOCUSDriftCrop).getEnumDescription(EnumConstant:=FOCUSswDriftCrop)


        cropData = Array.Find(
            array:=SwScenariosPerCrop,
            match:=Function(x) x.StartsWith(cropName.Substring(0, 2)))

        cropData = cropData.Split("+"c).Last

        If entry = eEntry.drainage Then
            Return _
                Filter(
                Source:=cropData.Split("|"c),
                Match:="D",
                Include:=True,
                Compare:=CompareMethod.Text)
        ElseIf entry = eEntry.runoff Then
            Return _
                Filter(
                Source:=cropData.Split("|"c),
                Match:="R",
                Include:=True,
                Compare:=CompareMethod.Text)
        Else
            Return cropData.Split("|"c)
        End If

    End Function

#End Region


End Class



