﻿

Imports System.ComponentModel
Imports System.Globalization

''' <summary>
''' Display double values
''' >TypeConverter(GetType(statistic.dblConv))>
''' </summary>
Public Class dblConv

    'usage : <TypeConverter(GetType(statistic.dblConv))>

    Inherits DoubleConverter

#Region "    shared"

    Public Shared country As eCountry = stdCountry
    Public Shared dblFormat As String = stdDblformat
    Public Shared emptyString As String = stdEmptyString
    Public Shared minSign As String = stdMinSign
    Public Shared minValue As Double = stdMinValue
    Public Shared digits As Integer = stdDigits
    Public Shared unit As String = ""
    Public Shared negDef As Boolean = stdnegDef

#End Region

#Region "    std. as const"

    Public Enum eCountry
        de_DE
        en_US
        fr_FR
    End Enum

    Public Const stdCountry As eCountry = eCountry.en_US
    Public Const stdDblformat As String = "G4"
    Public Const stdEmptyString As String = " - "
    Public Const stdMinSign As String = "<"
    Public Const stdMinValue As Double = 0.0001
    Public Const stdDigits As Integer = -1
    Public Const stdUnit As String = ""
    Public Const stdnegDef As Boolean = False

#End Region

#Region "    Engine"

    <DebuggerStepThrough>
    Public Overrides Function ConvertTo(
                            context As ITypeDescriptorContext,
                            culture As CultureInfo,
                            value As Object,
                            destType As Type) As Object

        Try

            Return _
                double2String(
                    value:=value,
                    format:=dblFormat,
                    country:=country,
                    minSign:=minSign,
                    minValue:=minValue,
                    digits:=digits,
                    negativeDefined:=negDef) & unit

        Catch ex As Exception
            Return value
        End Try

    End Function

    <DebuggerStepThrough>
    Public Overrides Function ConvertFrom(
                            context As ITypeDescriptorContext,
                            culture As CultureInfo,
                            value As Object) As Object

        Dim valueString As String

        Try

            valueString = CType(value, String)

            If valueString.Contains(minSign) Then
                Return minValue
            ElseIf Double.IsNaN(Double.Parse(valueString)) Then
                Return Double.NaN
            Else
                Return Double.Parse(valueString)
            End If

        Catch ex As Exception
            Return Double.NaN
        End Try

    End Function

#End Region

    ''' <summary>
    ''' Grid able settings manager
    ''' </summary>
    <TypeConverter(GetType(propGridConverter))>
    <Serializable>
    Public Class formatSetter

        Public Sub New()

        End Sub

        ''' <summary>
        ''' Overview of the format setting
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <Browsable(False)>
        <[ReadOnly](True)>
        Public ReadOnly Property name As String
            Get
                Return _
                Me.dblFormat & "; " &
                Me.country.ToString & "; " &
                Me.minSign & Me.minValue
            End Get
        End Property

        ''' <summary>
        ''' Reset to Std.
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <DefaultValue(True)>
        <DisplayName("Reset to Std.")>
        <Description("")>
        Public Property set2Std As Boolean
            Get
                Return True
            End Get
            Set(value As Boolean)

                If value Then Exit Property

                dblFormat = stdDblformat
                country = stdCountry
                minSign = stdMinSign
                minValue = stdMinValue
                digits = stdDigits
                unit = stdUnit
                negDef = stdnegDef

            End Set
        End Property

        'https://docs.microsoft.com/de-de/dotnet/api/system.double.tostring?view=net-5.0
        ''' <summary>
        ''' Format String
        ''' like '0.00', '0.00E00', E4 | std.  ='G4', 
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <DefaultValue(stdDblformat)>
        <DisplayName("Format String")>
        <Description("like '0.00', '0.00E00', E4 | std.  ='G4', ")>
        Public Property dblFormat As String
            Get
                Return dblConv.dblFormat
            End Get
            Set
                dblConv.dblFormat = Value
            End Set
        End Property

        'https://www.csharp-examples.net/culture-names/
        ''' <summary>
        ''' Country String
        ''' avail. for English, German and French
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <DefaultValue(CInt(stdCountry))>
        <DisplayName("Country String")>
        <Description("Avail. for English, German and French")>
        Public Property country As eCountry
            Get
                Return dblConv.country
            End Get
            Set
                dblConv.country = Value
            End Set
        End Property

        ''' <summary>
        ''' NaN String
        ''' Display this string when value is NaN
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <DefaultValue(stdEmptyString)>
        <DisplayName("NaN String")>
        <Description("Display this string when value is NaN")>
        Public Property emptyString As String
            Get
                Return dblConv.emptyString
            End Get
            Set
                dblConv.emptyString = Value
            End Set
        End Property

        ''' <summary>
        ''' Min sign, >
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <DefaultValue(stdMinSign)>
        <DisplayName("<")>
        <Description("")>
        Public Property minSign As String
            Get
                Return dblConv.minSign
            End Get
            Set
                dblConv.minSign = Value
            End Set
        End Property

        ''' <summary>
        ''' Min value
        ''' Display  min sign minValue when value  minValue > value
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <DefaultValue(stdMinValue)>
        <DisplayName("Min value")>
        <Description("Display <minValue when value < minValue")>
        Public Property minValue As Double
            Get
                Return dblConv.minValue
            End Get
            Set
                dblConv.minValue = Value
            End Set
        End Property

        ''' <summary>
        ''' Digits
        ''' Rounding digits, -1 = no rounding
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <DefaultValue(stdDigits)>
        <DisplayName("Digits")>
        <Description("Rounding digits, -1 = no rounding")>
        Public Property digits As Integer
            Get
                Return dblConv.digits
            End Get
            Set
                dblConv.digits = Value
            End Set
        End Property

        ''' <summary>
        ''' Unit
        ''' Unit to display like 'µg/L', std. = ''
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <DefaultValue(stdDigits)>
        <DisplayName("Unit")>
        <Description("Unit to display like 'µg/L', std. = ''")>
        Public Property unit As String
            Get
                Return dblConv.unit
            End Get
            Set
                dblConv.unit = Value
            End Set
        End Property

        ''' <summary>
        ''' Neg. Values Poss.
        ''' If true, there's no minValue
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <DefaultValue(stdDigits)>
        <DisplayName("Neg. Values Poss.")>
        <Description("If true, there's no minValue")>
        Public Property negDef As Boolean
            Get
                Return dblConv.negDef
            End Get
            Set
                dblConv.negDef = Value
            End Set
        End Property

    End Class

    Public Shared Function double2String(
                             value As Double,
                    Optional format As String = stdDblformat,
                    Optional country As eCountry = stdCountry,
                    Optional minValue As Double = stdMinValue,
                    Optional minSign As String = stdMinSign,
                    Optional digits As Integer = stdDigits,
                    Optional unit As String = stdUnit,
                    Optional negativeDefined As Boolean = stdnegDef) As String

        Dim countryString As String

        countryString =
        Replace(
        Expression:=country.ToString,
        Find:="_", Replacement:="-",
        Compare:=CompareMethod.Text)

        If value < 0 And Not negativeDefined Then
            Return stdEmptyString
        End If

        If Not Double.IsNaN(minValue) AndAlso value < minValue Then
            Return minSign & minValue.ToString & unit
        End If

        If Double.IsNaN(Double.Parse(value)) Then
            Return stdEmptyString
        End If

        Try

            If digits > -1 Then

                value =
                Math.Round(
                    value,
                    digits:=digits)

            End If

            Return value.ToString(
                          format:=format,
                        provider:=CultureInfo.CreateSpecificCulture(countryString)) & unit

        Catch ex As Exception

            Console.WriteLine("error converting double to string")
            Return ex.Message

        End Try

    End Function

End Class

