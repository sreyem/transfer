﻿
Imports System.ComponentModel

''' <summary>
''' Make a class brows-able in the property grid
''' >TypeConverter(GetType(propGridConverter))>
''' </summary>
Public Class propGridConverter

    'usage : <TypeConverter(GetType(propGridConverter))>

    Inherits ExpandableObjectConverter

#Region "    Engine"

    <DebuggerStepThrough>
    Public Overloads Overrides Function CanConvertTo(
                                                ByVal context As ITypeDescriptorContext,
                                                ByVal destinationType As Type) As Boolean
        Try

            If (destinationType Is GetType(propGridConverter)) Then
                Return True
            End If

        Catch ex As Exception

        End Try

        Return MyBase.CanConvertTo(
                                context,
                                destinationType)

    End Function

    <DebuggerStepThrough>
    Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

        If (destinationType Is GetType(System.String)) Then

            Try

                Return CallByName(
                                value,
                                "Name",
                                CallType.Get)

            Catch ex As Exception
                Return " ... "
            End Try

        End If

        Return MyBase.ConvertTo(
                            context,
                            culture,
                            value,
                            destinationType)

    End Function

#End Region

End Class

