﻿Imports System.ComponentModel

Public Class frmPgrid

    Public Sub New()

        ' Dieser Aufruf ist für den Designer erforderlich.
        InitializeComponent()

        ' Fügen Sie Initialisierungen nach dem InitializeComponent()-Aufruf hinzu.

        Me.propGridMain.SelectedObject = tC

    End Sub


    Public Property tC As New testClass

    Public Property stats As New statisticTest.statistic


    Public Class testClass

        Public Sub New()

        End Sub

        Public Property stats As New statisticTest.statistic

        Public Property second As String = "dfgdfg"

        Public Property statsArray As statisticTest.statistic() = Nothing


    End Class



    Private Sub mainGridItemChanged(
            sender As Object,
            e As SelectedGridItemChangedEventArgs) Handles propGridMain.SelectedGridItemChanged

        If IsNothing(e.OldSelection) OrElse
           IsNothing(e.NewSelection.Value) Then Exit Sub

        Try

            If (e.NewSelection.Value).GetType.ToString = "System.String" Then

                'With propGridDetails

                '    .Font = New Font(familyName:="Courier New", emSize:=10)
                '    .PropertySort = PropertySort.Categorized
                '    .SelectedObject = Nothing

                'End With

                'Exit Sub

            End If

            With propGridDetails

                .Font = New Font(familyName:="Courier New", emSize:=10)
                .PropertySort = PropertySort.Categorized
                .SelectedObject = e.NewSelection.Value

            End With

        Catch ex As Exception

        End Try


    End Sub


End Class
