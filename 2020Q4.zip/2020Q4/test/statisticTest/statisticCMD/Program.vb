Imports System
Imports statisticTest

Module Program
    Sub Main(args As String())

        Dim test As New statistic

        test.addValue(values:={0.3, 0.5, 0.2, 0.6})

    End Sub
End Module
