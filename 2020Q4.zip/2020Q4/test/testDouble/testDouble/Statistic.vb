﻿
Imports System.ComponentModel
Imports System.Xml.Serialization
Imports System.Web.Script.Serialization
Imports System.Globalization

''' <summary>
''' Descriptive statistic
''' </summary>
<DefaultProperty("dataImporter")>
<Serializable>
Public Class statistic

#Region "    Constructors"

    ''' <summary>
    ''' Default constructor
    ''' </summary>
    Public Sub New()

    End Sub

    ''' <summary>
    ''' Complete constructor
    ''' </summary>
    ''' <param name="Data">
    ''' Array of double to analyze
    ''' </param>
    ''' <param name="Percentile">
    ''' Percentile, from 1 to 100
    ''' </param>
    ''' <param name="Base">
    ''' std deviation and variance
    ''' from sample or totality
    ''' </param>
    ''' <remarks></remarks>
    Public Sub New(
                  Data As Double(),
                  Optional Percentile As Integer = 80,
                  Optional Base As eSampleTotality = eSampleTotality.Sample)


        Me.data = Data
        Me.Percent = Percentile
        Me.Base = Base
        Analyze()

    End Sub

#End Region

#Region "    Calculations"

    ''' <summary>
    ''' Run the analysis to obtain descriptive information of the data
    ''' </summary>
    Public Function Analyze() As statistic

        Dim ZeroOrNeg As Boolean = False

        If data.Count = 0 Then Return New statistic

#Region "        order data"

        'sort data
        sortedData = New Double(data.Length - 1) {}
        gauss = New Double(data.Length - 1) {}

        Me.order = New Int16(data.Length - 1) {}

        For counter As Integer = 0 To order.Count - 1
            Me.order(counter) = counter + 1
            Me.sortedData(counter) = Me.data(counter)
        Next

        Dim temp As Double
        Dim tempOrder As Int16

        For outerCounter As Integer = 0 To order.Count - 1

            For innerCounter As Integer = 0 To order.Count - 1

                If sortedData(innerCounter) > sortedData(outerCounter) Then
                    temp = sortedData(innerCounter)
                    sortedData(innerCounter) = sortedData(outerCounter)
                    sortedData(outerCounter) = temp
                    tempOrder = order(innerCounter)
                    order(innerCounter) = order(outerCounter)
                    order(outerCounter) = tempOrder

                End If

            Next

        Next

        'Data.CopyTo(sortedData, 0)
        'Array.Sort(sortedData)

#End Region

        Me.n = data.Count
        Me.Min = sortedData.First
        Me.Max = sortedData.Last
        Me.Range = data.Max - data.Min

        For i As Integer = 0 To data.Length - 1

            If i = 0 Then

                'init
                Me.Sum = data(i)
                Me.SumOfProducts = data(i)
                Me.SumOfReciprocalProducts = 1.0 / data(i)
                Me.Arithmetic = data(i)

            Else

                Me.Sum += data(i)
                Me.SumOfProducts *= data(i)
                Me.SumOfReciprocalProducts += 1.0 / data(i)

            End If

            If data(i) <= 0 Then ZeroOrNeg = True

        Next

        Me.Arithmetic = Me.Sum / n

        If ZeroOrNeg Then

            Me.Geometric = Double.NaN
            Me.Harmonic = Double.NaN

        Else

            'https://support.office.com/en-us/article/geomean-function-045ff75c-0bb8-4748-831d-16c395804586?redirectSourcePath=%252fde-de%252farticle%252fGEOMITTEL-Funktion-d97b6117-3280-475d-ac88-7c7858adf58e
            Me.Geometric = Math.Pow(Me.SumOfProducts, 1.0 / n)

            'https://support.office.com/en-us/article/harmean-function-5efd9184-fab5-42f9-b1d3-57883a1d3bc6?redirectSourcePath=%252fde-de%252farticle%252fHARMITTEL-Funktion-b2d540ce-445f-4d31-a09d-021ca38fb416
            Me.Harmonic = 1.0 / (Me.SumOfReciprocalProducts / n)

        End If

        Dim KurtHelper As Double = 0

        For i As Integer = 0 To data.Length - 1

            If i = 0 Then

                Me.SumOfError = Math.Abs(data(i) - Me.Arithmetic)
                Me.SumOfErrorSquare = (Math.Abs(data(i) - Me.Arithmetic)) ^ 2

                KurtHelper = (Math.Abs(data(i) - Me.Arithmetic)) ^ 4

            Else

                Me.SumOfError += Math.Abs(data(i) - Me.Arithmetic)
                Me.SumOfErrorSquare += (Math.Abs(data(i) - Me.Arithmetic)) ^ 2

                KurtHelper += (Math.Abs(data(i) - Me.Arithmetic)) ^ 4

            End If

        Next

        'https://support.office.com/de-de/article/VAR-S-Funktion-913633DE-136B-449D-813E-65A00B2B990B
        Me.Variance = Me.SumOfErrorSquare / (n - IIf(Me.Base = eSampleTotality.Sample, 1, 0))

        'https://support.office.com/en-us/article/STDEV-S-function-7D69CF97-0C1F-4ACF-BE27-F3E83904CC23
        Me.StdDeviation = Math.Sqrt(Me.Variance)

        For i As Integer = 0 To gauss.Length - 1

            Try
                gauss(i) =
              Double.Parse(getGauss(
                value:=data(i),
                stdDeviation:=Me.StdDeviation,
                arithmeticMean:=Me.Arithmetic).double2string)

            Catch ex As Exception

            End Try

        Next

        If norm Then

            Dim maxgauss As Double = gauss.Max

            For i As Integer = 0 To gauss.Length - 1
                gauss(i) = Double.Parse((gauss(i) * 100 / maxgauss).double2string)
            Next

        End If

        'https://welt-der-bwl.de/Variationskoeffizient
        Me.relativeVariance = Me.StdDeviation / Me.Arithmetic * 100

        ' using Excel approach
        Dim SkewHelper As Double = 0.0
        ' the cum part of SKEW formula
        For i As Integer = 0 To data.Length - 1
            SkewHelper += Math.Pow((data(i) - Me.Arithmetic) / (Math.Sqrt(Me.SumOfErrorSquare / (n - 1))), 3)
        Next

        'https://support.office.com/en-us/article/skew-function-bdf49d86-b1ef-4804-a046-28eaea69c9fa
        Me.Skewness = n /
            (n - 1) / (n - 2) * SkewHelper

        'https://support.office.com/de-de/article/kurt-funktion-bc3a265c-5da4-4dcb-b7fd-c237789095ab
        Me.Kurtosis = ((n + 1) * n * (n - 1)) / ((n - 2) * (n - 3)) * (KurtHelper / Me.SumOfErrorSquare ^ 2) - 3 * Math.Pow(n - 1, 2) / ((n - 2) * (n - 3))


        Me.FirstQuartile = calcPercentile(sortedData, 25)
        Me.ThirdQuartile = calcPercentile(sortedData, 75)
        Me.IQR = Me.ThirdQuartile - Me.FirstQuartile
        Me.Median = calcPercentile(sortedData, 50)
        Me.Percentile = calcPercentile(sortedData, Me.Percent)

        Return Me

    End Function

#Region "     Percentile"

    ''' <summary>
    ''' Percentile
    ''' </summary>
    ''' <param name="percent">Percentile, between 0 to 100</param>
    ''' <returns>Percentile</returns>
    Public Function calcPercentile(percent As Double) As Double
        Return Me.calcPercentile(sortedData, percent)
    End Function


    ''' <summary>
    ''' Calculate percentile of a sorted data set
    ''' </summary>
    ''' <param name="sortedData"></param>
    ''' <param name="p"></param>
    ''' <returns></returns>
    Public Function calcPercentile(sortedData As Double(), p As Double) As Double

        If IsNothing(sortedData) Then Return 0

        Try

            ' algorithm derived from Aczel pg 15 bottom
            If p >= 100.0 Then
                Return sortedData(sortedData.Length - 1)
            End If

            Dim position As Double = CDbl(sortedData.Length + 1) * p / 100.0
            Dim leftNumber As Double = 0.0, rightNumber As Double = 0.0

            Dim n As Double = p / 100.0 * (sortedData.Length - 1) + 1.0

            If position >= 1 Then
                leftNumber = sortedData(CInt(System.Math.Floor(n)) - 1)
                rightNumber = sortedData(CInt(System.Math.Floor(n)))
            Else
                leftNumber = sortedData(0)
                ' first data
                ' first data
                rightNumber = sortedData(1)
            End If

            If leftNumber = rightNumber Then
                Return leftNumber
            Else
                Dim part As Double = n - System.Math.Floor(n)
                Return leftNumber + part * (rightNumber - leftNumber)
            End If

        Catch ex As Exception
            Return Double.NaN
        End Try

    End Function

    Private Shared Function InlineAssignHelper(Of T)(ByRef target As T, value As T) As T
        target = value
        Return value
    End Function

#End Region


    'http://jumbo.uni-muenster.de/index.php?id=185
    Public Function getGauss(value As Double, stdDeviation As Double, arithmeticMean As Double) As Double

        Dim temp01 As Double
        Dim temp02 As Double

        Try

            temp01 = 1 /
                        (stdDeviation * Math.Sqrt(2 * Math.PI))

            temp02 = Math.Exp(-0.5 * Math.Pow(
                                          x:=(value - arithmeticMean) / stdDeviation,
                                          y:=2))

        Catch ex As Exception
            Return Double.NaN
        End Try


        Return temp01 * temp02

    End Function


#End Region

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Public Const CATBasic As String = "01 Basic"
#Region "    Basic"

    <RefreshProperties(RefreshProperties.All)>
    <Category(CATBasic)>
    <DisplayName("Display Format")>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public Property doubleFormat As New statisticsDblConv.formatSetter

    ''' <summary>
    ''' name to display and for .tostring
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
    "Name")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATBasic)>
    <RefreshProperties(RefreshProperties.All)>
    Public Overridable Property name As String


    ''' <summary>
    ''' add a single value to the dataset
    ''' </summary>
    ''' <param name="value">data point as double</param>
    Public Sub addValue(value As Double)

        Dim temp As New List(Of Double)

        temp.AddRange(Me.data)
        temp.Add(value)

        Me.data = temp.ToArray

    End Sub

    ''' <summary>
    ''' add multiple values to the dataset
    ''' </summary>
    ''' <param name="values">data points as array of double</param>
    Public Sub addValue(values As Double())

        Dim temp As New List(Of Double)

        temp.AddRange(Me.data)
        temp.AddRange(values)

        Me.data = temp.ToArray

    End Sub

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _dataImporter As String() = {}

    ''' <summary>
    ''' orig.data is used to calculate percentiles
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
    "Data, importer")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATBasic)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property dataImporter As String()
        Get
            Return _dataImporter
        End Get
        Set

            Dim temp As New List(Of Double)

            For Each member As String In Value

                Try
                    temp.Add(Double.Parse(Trim(member)))
                Catch ex As Exception

                End Try

            Next

            _data = temp.ToArray
            Analyze()

            _dataImporter = Value

        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _data As Double()

    ''' <summary>
    ''' orig.data is used to calculate percentiles
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
    "Data, as double")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATBasic)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property data As Double()
        Get
            Return _data
        End Get
        Set(value As Double())

            Dim temp As New List(Of String)

            For Each member As Double In value
                temp.Add(member.ToString)
            Next

            _dataImporter = temp.ToArray
            _data = value

            Analyze()

        End Set
    End Property



    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _sortedData As Double()

    ''' <summary>
    ''' sortedData is used to calculate percentiles
    ''' </summary>
    ''' <returns></returns>
    <XmlIgnore> <ScriptIgnore>
    <DisplayName(
    " '' , sorted")>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATBasic)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property sortedData As Double()
        Get
            Return _sortedData
        End Get
        Set
            _sortedData = Value
        End Set
    End Property

    ''' <summary>
    ''' sortedData is used to calculate percentiles
    ''' </summary>
    ''' <returns></returns>
    <XmlIgnore> <ScriptIgnore>
    <DisplayName(
    " '' , order")>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATBasic)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property order As Int16()

    ''' <summary>
    ''' Count
    ''' </summary>
    <Description(
    "Number of elements")>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATBasic)>
    <XmlIgnore> <ScriptIgnore>
    Public Property n As Integer

    ''' <summary>
    ''' Sum
    ''' </summary>
    <Description(
    "Sum of elements")>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATBasic)>
    <TypeConverter(GetType(statisticsDblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property Sum As Double = Double.NaN


    ''' <summary>
    ''' The range of the values
    ''' </summary>
    <Description(
    "Range of the values")>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATBasic)>
    <TypeConverter(GetType(statisticsDblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property Range As Double = Double.NaN

#End Region

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Public Const CATMeans As String = "02 Mean"
#Region "    Mean"

    ''' <summary>
    ''' Arithmetic mean
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATMeans)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(statisticsDblConv))>
    <XmlIgnore> <ScriptIgnore>
    <Description(
    "(a1 + a2  +...+ an)/n")>
    Public Property Arithmetic As Double = Double.NaN

    ''' <summary>
    ''' Geometric mean
    ''' </summary>
    ''' 
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATMeans)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(statisticsDblConv))>
    <XmlIgnore> <ScriptIgnore>
    <Description(
    "(a1 * a2 *...* an)^1/n" & vbCrLf &
    "not def. if any value is 0 or neg.")>
    Public Property Geometric As Double = Double.NaN

    ''' <summary>
    ''' Harmonic mean
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATMeans)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(statisticsDblConv))>
    <XmlIgnore> <ScriptIgnore>
    <Description(
    "n(1/a1 + 1/a2 +...+ 1/an)" & vbCrLf &
    "not def. if any value is 0 or neg.")>
    Public Property Harmonic As Double = Double.NaN

    ''' <summary>
    ''' Median, or second quartile, or at 50 percentile
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATMeans)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(statisticsDblConv))>
    <XmlIgnore> <ScriptIgnore>
    <Description("= second quartile or 50th percentile")>
    Public Property Median As Double = Double.NaN

#End Region

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Public Const CATWhisker As String = "03 Whisker"
#Region "    Whisker"

    ''' <summary>
    ''' Minimum value
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATWhisker)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(statisticsDblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property Min As Double = Double.NaN

    ''' <summary>
    ''' First quartile, at 25 percentile
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATWhisker)>
    <DisplayName(
    "1st Quartile")>
    <Description(
    "First quartile = 25th percentile")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(statisticsDblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property FirstQuartile As Double = Double.NaN

    ''' <summary>
    ''' Interquartile range
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATWhisker)>
    <DisplayName(
    "IQR")>
    <Description(
    "Inter Quartile Range")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(statisticsDblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property IQR As Double = Double.NaN

    ''' <summary>
    ''' Third quartile, at 75 percentile
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATWhisker)>
    <DisplayName(
    "3rd Quartile")>
    <Description(
    "Third Quartile")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(statisticsDblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property ThirdQuartile As Double = Double.NaN

    ''' <summary>
    ''' Maximum value
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATWhisker)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(statisticsDblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property Max As Double = Double.NaN

    <DebuggerBrowsable(False)>
    Private m_Percent As Double = 80

    ''' <summary>
    ''' Percentile
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATWhisker)>
    <DisplayName(
    "Percentile")>
    <Description(
    "Percentile in percent 0 - 100%")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(statisticsDblConv))>
    <XmlIgnore> <ScriptIgnore>
    <DefaultValue(80)>
    Public Property Percent As Double
        Get
            Return m_Percent
        End Get
        Set(value As Double)

            m_Percent = value
            Percentile = calcPercentile(percent:=Me.Percent)

        End Set
    End Property

    ''' <summary>
    ''' Percentile
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATWhisker)>
    <DisplayName(
    "Value")>
    <Description(
    "Percentile value")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(statisticsDblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property Percentile As Double = Double.NaN

    ''' <summary>
    ''' Percentile of PEC values
    ''' Arithmetic mean of 16th and 17th value
    ''' </summary>
    ''' <returns></returns>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATWhisker)>
    <DisplayName(
    "PECgw Perc.")>
    <Description(
    "Percentile  of PEC values" & vbCrLf &
    "Arithmetic mean of 16th and 17th value")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(statisticsDblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public ReadOnly Property stdPECgwPercentile
        Get

            If n = 20 Then

                Return (sortedData(15) + sortedData(16)) / 2

            Else
                Return Double.NaN
            End If
        End Get
    End Property

#End Region

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Public Const CATStatistic As String = "04 Statistic"
#Region "    Statistic"

    Public Enum eSampleTotality
        Sample
        Totality
    End Enum

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_Base As eSampleTotality = eSampleTotality.Sample

    ''' <summary>
    ''' Sample or Totality
    ''' for std. deviation and variance
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATStatistic)>
    <DisplayName("Sample or Totality")>
    <RefreshProperties(RefreshProperties.All)>
    <DefaultValue(CInt(eSampleTotality.Sample))>
    <XmlIgnore> <ScriptIgnore>
    Public Property Base As eSampleTotality
        Get
            Return m_Base
        End Get
        Set(value As eSampleTotality)
            m_Base = value
            Analyze()
        End Set
    End Property

    ''' <summary>
    ''' Sample variance
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatistic)>
    <DisplayName(
    "Variance")>
    <Description(
    "Sum of error^2 / (n - 1{Sample}, 0{Total})" & vbCrLf &
    "EXCEL : VARIANZA sample; VARIANZENA totality" & vbCrLf &
    "1/n * (a1^2 + a2^2 + ... + an^2) - mean^2")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(statisticsDblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property Variance As Double = Double.NaN

    ''' <summary>
    ''' Sample variance
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatistic)>
    <DisplayName(
    "Relative Variance in %")>
    <Description(
    "std deviation / mean" & vbCrLf &
    "EXCEL : VARIANZA sample; VARIANZENA totality")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(statisticsDblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property relativeVariance As Double = Double.NaN

    ''' <summary>
    ''' Sample standard deviation
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatistic)>
    <DisplayName(
    "Std. Deviation")>
    <Description(
    "sqrt(Variance)" & vbCrLf &
    "EXCEL : STABWA sample; STABWNA totality")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(statisticsDblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property StdDeviation As Double = Double.NaN

    ''' <summary>
    ''' orig.data is used to calculate percentiles
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
    "Gaussian distribution")>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatistic)>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    Public Property gauss As Double()

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _norm As Boolean = False

    ''' <summary>
    ''' orig.data is used to calculate percentiles
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
    " '     ' norm. to 100?")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATStatistic)>
    <RefreshProperties(RefreshProperties.All)>
    <DefaultValue(False)>
    <XmlIgnore> <ScriptIgnore>
    Public Property norm As Boolean
        Get
            Return _norm
        End Get
        Set(value As Boolean)
            _norm = value
            Analyze()
        End Set
    End Property

    ''' <summary>
    ''' Skewness of the data distribution
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatistic)>
    <DisplayName(
    "Skewness")>
    <Description(
    "Measure of the asymmetry" & vbCrLf &
    "negative/positive: left/right tail; EXCEL schief")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(statisticsDblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property Skewness As Double = Double.NaN

    ''' <summary>
    ''' Kurtosis of the data distribution
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatistic)>
    <DisplayName(
    "Kurtosis")>
    <Description(
    "measure of the 'tailedness' of the probability distribution" & vbCrLf &
    "positive/negative: sharp/wide distirbution")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(statisticsDblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property Kurtosis As Double = Double.NaN

#End Region

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Public Const CATStatHelper As String = "05 Helper"
#Region "    05 Helper"

    ''' <summary>
    ''' Sum of Error
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatHelper)>
    <DisplayName(
    "Sum of error")>
    <Description(
    "(|a1| - aver.) + (|a2| - aver.) + ... + (|a3| - aver.)")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(statisticsDblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property SumOfError As Double = Double.NaN

    ''' <summary>
    ''' The sum of the squares of errors
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatHelper)>
    <DisplayName(
    "Sum of error^2")>
    <Description(
    "(|a1| - aver.)^2 + (|a2| - aver.)^2 + ... + (|a3| - aver.)^2")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(statisticsDblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property SumOfErrorSquare As Double = Double.NaN


    ''' <summary>
    ''' Sum of Products
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatHelper)>
    <DisplayName(
    "Sum of products")>
    <Description(
    "a1 * a2 * ... * an")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(statisticsDblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property SumOfProducts As Double = Double.NaN

    ''' <summary>
    ''' Sum of reciprocal Products
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatHelper)>
    <DisplayName(
    "Sum of reciprocal products")>
    <Description(
    "1/a1 + 1/a2 + ... + 1/an")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(statisticsDblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property SumOfReciprocalProducts As Double = Double.NaN

#End Region

End Class

Public Class statisticsDblConv

    '<TypeConverter(GetType(doubleConv))>

    Inherits DoubleConverter

    Public Shared country As String = stdCountry
    Public Shared dblFormat As String = stdDblformat
    Public Shared emptyString As String = stdEmptyString
    Public Shared minSign As String = stdMinSign
    Public Shared minValue As Double = stdMinValue
    Public Shared digits As Integer = stdDigits
    Public Shared unit As String = ""
    Public Shared negDef As Boolean = stdnegDef

    Public Overrides Function ConvertTo(
                                context As ITypeDescriptorContext,
                                culture As CultureInfo,
                                value As Object,
                                destType As Type) As Object

        Try

            Return _
                    CDbl(value).double2string(
                                    format:=dblFormat,
                                    country:=country,
                                    minValue:=minValue,
                                    digits:=digits,
                                    negativeDefined:=negDef) & unit

        Catch ex As Exception
            Return value
        End Try

    End Function

    Public Overrides Function ConvertFrom(
                                context As ITypeDescriptorContext,
                                culture As CultureInfo,
                                value As Object) As Object

        Dim valueString As String

        Try

            valueString = CType(value, String)

            If valueString.Contains(minSign) Then
                Return minValue
            ElseIf Double.IsNaN(Double.Parse(valueString)) Then
                Return Double.NaN
            Else
                Return Double.Parse(valueString)
            End If

        Catch ex As Exception
            Return Double.NaN
        End Try

    End Function


    <TypeConverter(GetType(statisticspropGridConverter))>
    Public Class formatSetter

        Public Sub New()

        End Sub

        <RefreshProperties(RefreshProperties.All)>
        <Browsable(False)>
        Public Property name As String
            Get
                Return Me.dblFormat & "; " & country & "; " & minSign & minValue
            End Get
            Set(value As String)

            End Set
        End Property

        <RefreshProperties(RefreshProperties.All)>
        Public Property set2Std As Boolean
            Get
                Return True
            End Get
            Set(value As Boolean)

                If value Then Exit Property

                dblFormat = stdDblformat
                country = stdCountry
                minSign = stdMinSign
                minValue = stdMinValue
                digits = stdDigits
                unit = stdUnit
                negDef = stdnegDef

            End Set
        End Property

        <RefreshProperties(RefreshProperties.All)>
        Public Property dblFormat As String
            Get
                Return statisticsDblConv.dblFormat
            End Get
            Set
                statisticsDblConv.dblFormat = Value
            End Set
        End Property

        <RefreshProperties(RefreshProperties.All)>
        Public Property country As String
            Get
                Return statisticsDblConv.country
            End Get
            Set
                statisticsDblConv.country = Value
            End Set
        End Property

        <RefreshProperties(RefreshProperties.All)>
        Public Property emptyString As String
            Get
                Return statisticsDblConv.emptyString
            End Get
            Set
                statisticsDblConv.emptyString = Value
            End Set
        End Property

        <RefreshProperties(RefreshProperties.All)>
        Public Property minSign As String
            Get
                Return statisticsDblConv.minSign
            End Get
            Set
                statisticsDblConv.minSign = Value
            End Set
        End Property

        <RefreshProperties(RefreshProperties.All)>
        Public Property minValue As Double
            Get
                Return statisticsDblConv.minValue
            End Get
            Set
                statisticsDblConv.minValue = Value
            End Set
        End Property

        <RefreshProperties(RefreshProperties.All)>
        Public Property digits As Integer
            Get
                Return statisticsDblConv.digits
            End Get
            Set
                statisticsDblConv.digits = Value
            End Set
        End Property

        <RefreshProperties(RefreshProperties.All)>
        Public Property unit As String
            Get
                Return statisticsDblConv.unit
            End Get
            Set
                statisticsDblConv.unit = Value
            End Set
        End Property

        <RefreshProperties(RefreshProperties.All)>
        Public Property negDef As Boolean
            Get
                Return statisticsDblConv.negDef
            End Get
            Set
                statisticsDblConv.negDef = Value
            End Set
        End Property

    End Class

End Class

''' <summary>
''' make a class brows able in the property grid
''' </summary>
Public Class statisticspropGridConverter

    Inherits ExpandableObjectConverter

    ' usage  <TypeConverter(GetType(propGridConverter))>
    ' define Property gridName As String
#Region "Overloads Overrides"

    Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                         ByVal destinationType As Type) As Boolean

        Try

            If (destinationType Is GetType(statisticspropGridConverter)) Then
                Return True
            End If

        Catch ex As Exception

        End Try

        Return MyBase.CanConvertTo(context,
                                       destinationType)

    End Function

    <DebuggerStepThrough>
    Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

        If (destinationType Is GetType(System.String)) Then

            Try

                Return CallByName(
                                value,
                                "Name",
                                CallType.Get)

            Catch ex As Exception
                Return "..."
            End Try

        End If

        Return MyBase.ConvertTo(context,
                                    culture,
                                    value,
                                    destinationType)

    End Function

#End Region

End Class



