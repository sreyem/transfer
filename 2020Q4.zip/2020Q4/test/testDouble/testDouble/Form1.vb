﻿


Public Class Form1

    Public Sub New()

        ' Dieser Aufruf ist für den Designer erforderlich.
        InitializeComponent()

        ' Fügen Sie Initialisierungen nach dem InitializeComponent()-Aufruf hinzu.

        With propGrid
            .Font = New Font(familyName:="Courier New", emSize:=12)
            .PropertySort = PropertySort.Categorized
            .ToolbarVisible = False
            .SelectedObject = stat
        End With

    End Sub

    Public Property stat As New statistic


End Class

Public Class testStat

    Public Sub New()

    End Sub

    Public Property testString As String = "dfsggf"
    Public Property stat As New statistic

End Class



