﻿



Imports System.ComponentModel
Imports System.Globalization
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms.Design

Public Module extensions

    Public Const stdCountry As String = "en-US"
    Public Const stdDblformat As String = "G4"
    Public Const stdEmptyString As String = " - "
    Public Const stdMinSign As String = "<"
    Public Const stdMinValue As Double = 0.0001
    Public Const stdDigits As Integer = -1
    Public Const stdUnit As String = ""
    Public Const stdnegDef As Boolean = False



    ''' <summary>
    ''' converts a double into a formated string
    ''' </summary>
    ''' <param name="value">
    ''' the value to convert as double
    ''' </param>
    ''' <param name="format">
    ''' format string, like "G4" (std if "") or "0.000E+00"
    ''' </param>
    ''' <param name="country">
    ''' country string like "en-US" (std if "") or "de-DE"
    ''' </param>
    ''' <param name="minValue">
    ''' min value, std. = 0.0001, values below = <0.0001
    ''' </param>
    ''' <param name="negativeDefined">
    ''' if value < 0 and not negativeDefined then stdEmptyString 
    ''' </param>
    ''' <param name="digits">
    ''' round double if digits > -1
    ''' </param>
    ''' <param name="unit">
    ''' unit as string like 'µg/L'
    ''' </param>
    ''' <returns>
    ''' a string , String.Empty on error
    ''' </returns>
    ''' <remarks></remarks>
    ''' 
    <Extension()>
    <DebuggerStepThrough>
    Public Function double2string(
                                 value As Double,
                        Optional format As String = stdDblformat,
                        Optional country As String = stdCountry,
                        Optional minValue As Double = stdMinValue,
                        Optional minSign As String = stdMinSign,
                        Optional digits As Integer = stdDigits,
                        Optional unit As String = stdUnit,
                        Optional negativeDefined As Boolean = stdnegDef) As String

        If value < 0 And Not negativeDefined Then
            Return stdEmptyString
        End If

        If Not Double.IsNaN(minValue) AndAlso value < minValue Then
            Return minSign & minValue.ToString & unit
        End If

        If Double.IsNaN(Double.Parse(value)) Then
            Return stdEmptyString
        End If

        Try

            If digits > -1 Then

                value =
                    Math.Round(
                        value,
                        digits:=digits)

            End If

            Return value.ToString(
                              format:=format,
                            provider:=CultureInfo.CreateSpecificCulture(country)) & unit

        Catch ex As Exception

            Console.WriteLine("error converting double to string")
            Return ex.Message

        End Try

    End Function

End Module


