﻿
Imports System.IO

Module Module1

    Sub Main()


        scann20YearRunOff(targetPath:="C:\_PROUTT\SP\TOXSWAtxw")
        'scann1YearDrain(targetPath:="C:\_PROUTT\SP\TOXSWAtxw")

        'matrix = File.ReadAllLines(path:=Path.Combine(Environment.CurrentDirectory, "hyd.csv"))

        'Dim result As Double()

        'result =
        '    getDepth(
        '        Crop:="VL",
        '        applnDate:=
        '            New Date(
        '            year:=1987,
        '            month:=4,
        '            day:=21),
        '        matrix:=matrix)

    End Sub


    Const searchCrop As String = "C:\VS2019\20191029\POSH\Examples\CompleteXXXMet\CompleteXXXMet\PRZM"
    Const searchScenario As String = "Location          !"

    Const targetPath As String = "C:\SwashProjects\project_PRZM_all\TXWold"
    'Const targetPath As String = "C:\SwashProjects\project_PRZM_all\TXWold"

    Const delimiter As String = ","

    Public startDate As New Date(year:=1975, month:=1, day:=1)


    Public Sub scann1YearDrain(targetPath As String)


        Dim out As New List(Of List(Of String))
        Dim csv As String() = {}

        Dim txwFiles As String() = {}
        Dim txwFile As String() = {}
        Dim hydFile As String() = {}
        Dim przmPath As String = ""
        Dim Scenario As String = ""
        Dim Crop As String = ""



        txwFiles =
            Directory.GetFiles(
            path:=targetPath,
            searchPattern:="*.txw",
            searchOption:=SearchOption.TopDirectoryOnly)

        For Each member As String In txwFiles

            Try

                txwFile = File.ReadAllLines(member)

                przmPath = Array.Find(array:=txwFile, match:=Function(x) x.Contains(searchCrop))
                przmPath = Path.GetDirectoryName(przmPath)
                przmPath =
                    Path.GetFileName(Directory.GetFiles(
                    path:=przmPath,
                    searchPattern:="*.inp",
                    searchOption:=SearchOption.TopDirectoryOnly).First)

                Crop = przmPath.Substring(3, 2)

                Scenario = Array.Find(array:=txwFile, match:=Function(x) x.Contains(searchScenario))

                If Scenario.Contains("_Pond") Then Continue For
                Scenario = Scenario.Substring(0, 2)

            Catch ex As Exception

            End Try

            out.Add(New List(Of String))

            With out(out.Count - 1)

                .Add(Scenario & "-" & Crop)

                Console.WriteLine(.Last)

                Try

                    hydFile =
                    File.ReadAllLines(
                    Path.ChangeExtension(
                    path:=member,
                    extension:=".hyd"))

                    hydFile =
                        Filter(
                        Source:=hydFile,
                        Match:="09h00",
                        Include:=True,
                        Compare:=CompareMethod.Text)

                    For Each row As String In hydFile

                        .Add(
                            Trim(row.Split(
                                    separator:={" "c},
                                    options:=StringSplitOptions.RemoveEmptyEntries).Last))
                    Next

                Catch ex As Exception

                End Try
            End With

        Next

        ReDim csv(out.First.Count)

        For rxcrCounter As Integer = 0 To out.Count - 1

            If rxcrCounter = 0 Then
                csv(0) = "Date"
            End If


            For rowCounter As Integer = 0 To out.First.Count - 1

                If rxcrCounter = 0 And Not rowCounter = 0 Then
                    csv(rowCounter) = startDate.AddDays(rowCounter - 1)
                End If

                csv(rowCounter) &= delimiter & out(rxcrCounter)(rowCounter)

            Next

        Next


        Try
            File.WriteAllLines(Path.Combine(Environment.CurrentDirectory, "hyd_old.csv"), csv)
        Catch ex As Exception

        End Try



    End Sub


    Public Sub scann20YearRunOff(targetPath As String)


        Dim out As New List(Of List(Of String))
        Dim csv As String() = {}

        Dim txwFiles As String() = {}
        Dim txwFile As String() = {}
        Dim hydFile As String() = {}
        Dim przmPath As String = ""
        Dim Scenario As String = ""
        Dim Crop As String = ""



        txwFiles =
            Directory.GetFiles(
            path:=targetPath,
            searchPattern:="R*.txw",
            searchOption:=SearchOption.TopDirectoryOnly)

        For Each member As String In txwFiles

            'Try

            '    txwFile = File.ReadAllLines(member)

            '    przmPath = Array.Find(array:=txwFile, match:=Function(x) x.Contains(searchCrop))
            '    przmPath = Path.GetDirectoryName(przmPath)
            '    przmPath =
            '        Path.GetFileName(Directory.GetFiles(
            '        path:=przmPath,
            '        searchPattern:="*.inp",
            '        searchOption:=SearchOption.TopDirectoryOnly).First)

            '    Crop = przmPath.Substring(3, 2)

            '    Scenario = Array.Find(array:=txwFile, match:=Function(x) x.Contains(searchScenario))

            '    If Scenario.Contains("_Pond") Then Continue For
            '    Scenario = Scenario.Substring(0, 2)

            'Catch ex As Exception

            'End Try

            Scenario = Path.GetFileNameWithoutExtension(member).Substring(0, 2)
            Crop = Path.GetFileNameWithoutExtension(member).Substring(6, 2)

            out.Add(New List(Of String))

            With out(out.Count - 1)

                .Add(Scenario & "-" & Crop)

                Console.WriteLine(.Last)

                Try

                    hydFile =
                    File.ReadAllLines(
                    Path.ChangeExtension(
                    path:=member,
                    extension:=".hyd"))

                    hydFile =
                        Filter(
                        Source:=hydFile,
                        Match:="09h00",
                        Include:=True,
                        Compare:=CompareMethod.Text)

                    For Each row As String In hydFile

                        .Add(
                            Trim(row.Split(
                                    separator:={" "c},
                                    options:=StringSplitOptions.RemoveEmptyEntries).Last))
                    Next

                Catch ex As Exception

                End Try
            End With

            Console.WriteLine(out.Last.Count)

            Try
                File.WriteAllLines(Path.ChangeExtension(member, ".csv"), out.Last)
            Catch ex As Exception

            End Try

            If out.Count > 1 Then
                If out.First.Count <> out.Last.Count Then
                    Console.WriteLine()
                End If
            End If


        Next

        ReDim csv(out.First.Count)

        For rxcrCounter As Integer = 0 To out.Count - 1

            If rxcrCounter = 0 Then
                csv(0) = "Date"
            End If


            For rowCounter As Integer = 0 To out.First.Count - 1

                If rxcrCounter = 0 And Not rowCounter = 0 Then
                    csv(rowCounter) = startDate.AddDays(rowCounter - 1)
                End If

                csv(rowCounter) &= delimiter & out(rxcrCounter)(rowCounter)

            Next

        Next


        Try
            File.WriteAllLines(Path.Combine(Path.GetDirectoryName(txwFiles.First), "RunOffHyd553.csv"), csv)
        Catch ex As Exception

        End Try



    End Sub

    Public matrix As String() = {}

    Public Function getDepth(Crop As String, applnDate As Date, matrix As String()) As Double()

        Dim targetRow As String() = {}
        Dim wd As String() = {}
        Dim scenarioXcrop As New List(Of String)
        Dim out As New List(Of Double)
        Dim index As Integer = -1

        scenarioXcrop.AddRange(matrix.First.Split(delimiter))

        targetRow = matrix((applnDate - startDate).TotalDays + 1).Split(delimiter)

        For scenario As Integer = 1 To 4

            index =
                Array.FindIndex(
                array:=scenarioXcrop.ToArray,
                match:=Function(x) x = "R" & scenario.ToString & "-" & Crop)

            If index = -1 Then
                out.Add(Double.NaN)
            Else
                out.Add(targetRow(index))
            End If

        Next

        Return out.ToArray

    End Function

End Module
