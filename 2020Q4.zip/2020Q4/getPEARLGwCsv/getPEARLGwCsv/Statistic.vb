﻿

Imports System.ComponentModel
Imports System.Drawing.Design
Imports System.Web.Script.Serialization
Imports System.Xml.Serialization

''' <summary>
''' The result class the holds the analysis results
''' </summary>
Public Class DescriptiveResult

    ''' <summary>
    ''' DescriptiveResult default constructor
    ''' </summary>
    Public Sub New()

    End Sub

    Public Const CATBasic As String = "01 Basic"
#Region "    Basic"

    ' sortedData is used to calculate percentiles
    <DisplayName("Data, sorted")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATBasic)>
    <XmlIgnore> <ScriptIgnore>
    Public Property sortedData As Double()

    ''' <summary>
    ''' Count
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATBasic)>
    Public Property Count As Integer
    ''' <summary>
    ''' Sum
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATBasic)>
    <TypeConverter(GetType(doubleString))>
    Public Property Sum As Double


    ''' <summary>
    ''' The range of the values
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATBasic)>
    <TypeConverter(GetType(doubleString))>
    Public Property Range As Double

#End Region

    Public Const CATMeans As String = "02 Mean"
#Region "    Mean"

    ''' <summary>
    ''' Arithmetic mean
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATMeans)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(doubleString))>
    Public Property Arithmetic As Double
    ''' <summary>
    ''' Geometric mean
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATMeans)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(doubleString))>
    Public Property Geometric As Double
    ''' <summary>
    ''' Harmonic mean
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATMeans)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(doubleString))>
    Public Property Harmonic As Double
    ''' <summary>
    ''' Median, or second quartile, or at 50 percentile
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATMeans)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(doubleString))>
    Public Property Median As Double

#End Region

    Public Const CATWhisker As String = "03 Whisker"
#Region "    Whisker"

    ''' <summary>
    ''' Minimum value
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATWhisker)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(doubleString))>
    Public Property Min As Double

    ''' <summary>
    ''' First quartile, at 25 percentile
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATWhisker)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(doubleString))>
    Public Property FirstQuartile As Double
    ''' <summary>
    ''' Interquartile range
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATWhisker)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(doubleString))>
    Public Property IQR As Double
    ''' <summary>
    ''' Third quartile, at 75 percentile
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATWhisker)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(doubleString))>
    Public Property ThirdQuartile As Double

    Private m_Percent As Double = 0

    ''' <summary>
    ''' Percecntile
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATWhisker)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(doubleString))>
    Public Property Percent As Double
        Get
            Return m_Percent
        End Get
        Set(value As Double)
            m_Percent = value
            Percentile = calcPercentile(percent:=Me.Percent)
        End Set
    End Property

    ''' <summary>
    ''' Percecntile
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATWhisker)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(doubleString))>
    Public Property Percentile As Double

    ''' <summary>
    ''' Maximum value
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATWhisker)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(doubleString))>
    Public Property Max As Double
#End Region



    Public Const CATStatistic As String = "04 Statistic"
#Region "Statistic"

    ''' <summary>
    ''' Sample variance
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatistic)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(doubleString))>
    Public Property Variance As Double
    ''' <summary>
    ''' Sample standard deviation
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatistic)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(doubleString))>
    Public Property StdDev As Double
    ''' <summary>
    ''' Skewness of the data distribution
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatistic)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(doubleString))>
    Public Property Skewness As Double
    ''' <summary>
    ''' Kurtosis of the data distribution
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatistic)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(doubleString))>
    Public Property Kurtosis As Double
    ''' <summary>
    ''' Sum of Error
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatistic)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(doubleString))>
    Friend SumOfError As Double

    ''' <summary>
    ''' The sum of the squares of errors
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatistic)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(doubleString))>
    Friend SumOfErrorSquare As Double

#End Region

    ''' <summary>
    ''' Percentile
    ''' </summary>
    ''' <param name="percent">Pecentile, between 0 to 100</param>
    ''' <returns>Percentile</returns>
    Public Function calcPercentile(percent As Double) As Double
        Return Statistic.percentile(sortedData, percent)
    End Function

End Class


''' <summary>
''' Descriptive class
''' </summary>
Public Class Statistic

    Public Property data As Double()

    Private sortedData As Double()

    ''' <summary>
    ''' Descriptive results
    ''' </summary>
    Public Result As New DescriptiveResult()

#Region "Constructors"
    ''' <summary>
    ''' Descriptive analysis default constructor
    ''' </summary>
    Public Sub New()
    End Sub
    ' default empty constructor
    ''' <summary>
    ''' Descriptive analysis constructor
    ''' </summary>
    ''' <param name="dataVariable">Data array</param>
    Public Sub New(dataVariable As Double())
        data = dataVariable
    End Sub
#End Region

    ''' <summary>
    ''' Run the analysis to obtain descriptive information of the data
    ''' </summary>
    Public Sub Analyze()

        ' initializations
        Result.Count = 0
        Result.Min =
            InlineAssignHelper(Result.Max,
                               InlineAssignHelper(Result.Range,
                                                  InlineAssignHelper(
                                                  Result.Arithmetic,
                                                  InlineAssignHelper(
                                                  Result.Sum,
                                                  InlineAssignHelper(
                                                  Result.StdDev,
                                                  InlineAssignHelper(Result.Variance, 0.0))))))

        Dim sumOfSquare As Double = 0.0
        Dim sumOfESquare As Double = 0.0
        ' must initialize
        Dim squares As Double() = New Double(data.Length - 1) {}
        Dim cumProduct As Double = 1.0
        ' to calculate geometric mean
        Dim cumReciprocal As Double = 0.0
        ' to calculate harmonic mean
        ' First iteration
        For i As Integer = 0 To data.Length - 1
            If i = 0 Then
                ' first data point
                Result.Min = data(i)
                Result.Max = data(i)
                Result.Arithmetic = data(i)
                Result.Range = 0.0
            Else
                ' not the first data point
                If data(i) < Result.Min Then
                    Result.Min = data(i)
                End If
                If data(i) > Result.Max Then
                    Result.Max = data(i)
                End If
            End If
            Result.Sum += data(i)
            squares(i) = Math.Pow(data(i), 2)
            'TODO: may not be necessary
            sumOfSquare += squares(i)

            cumProduct *= data(i)
            cumReciprocal += 1.0 / data(i)
        Next

        Result.Count = data.Length
        Dim n As Double = CDbl(Result.Count)
        ' use a shorter variable in double type
        Result.Arithmetic = Result.Sum / n
        Result.Geometric = Math.Pow(cumProduct, 1.0 / n)
        Result.Harmonic = 1.0 / (cumReciprocal / n)
        ' see http://mathworld.wolfram.com/HarmonicMean.html
        Result.Range = Result.Max - Result.Min

        ' second loop, calculate Stdev, sum of errors
        'double[] eSquares = new double[data.Length];
        Dim m1 As Double = 0.0
        Dim m2 As Double = 0.0
        Dim m3 As Double = 0.0
        ' for skewness calculation
        Dim m4 As Double = 0.0
        ' for kurtosis calculation
        ' for skewness
        For i As Integer = 0 To data.Length - 1
            Dim m As Double = data(i) - Result.Arithmetic
            Dim mPow2 As Double = m * m
            Dim mPow3 As Double = mPow2 * m
            Dim mPow4 As Double = mPow3 * m

            m1 += Math.Abs(m)

            m2 += mPow2

            ' calculate skewness
            m3 += mPow3

            ' calculate skewness

            m4 += mPow4
        Next

        Result.SumOfError = m1
        Result.SumOfErrorSquare = m2
        ' Added for Excel function DEVSQ
        sumOfESquare = m2

        ' var and standard deviation
        Result.Variance = sumOfESquare / (CDbl(Result.Count) - 1)
        Result.StdDev = Math.Sqrt(Result.Variance)

        ' using Excel approach
        Dim skewCum As Double = 0.0
        ' the cum part of SKEW formula
        For i As Integer = 0 To data.Length - 1
            skewCum += Math.Pow((data(i) - Result.Arithmetic) / Result.StdDev, 3)
        Next
        Result.Skewness = n / (n - 1) / (n - 2) * skewCum

        ' kurtosis: see http://en.wikipedia.org/wiki/Kurtosis (heading: Sample Kurtosis)
        Dim m2_2 As Double = Math.Pow(sumOfESquare, 2)
        Result.Kurtosis = ((n + 1) * n * (n - 1)) / ((n - 2) * (n - 3)) * (m4 / m2_2) - 3 * Math.Pow(n - 1, 2) / ((n - 2) * (n - 3))
        ' second last formula for G2
        ' calculate quartiles
        sortedData = New Double(data.Length - 1) {}
        data.CopyTo(sortedData, 0)
        Array.Sort(sortedData)

        ' copy the sorted data to result object so that
        ' user can calculate percentile easily
        Result.sortedData = New Double(data.Length - 1) {}
        sortedData.CopyTo(Result.sortedData, 0)

        Result.FirstQuartile = percentile(sortedData, 25)
        Result.ThirdQuartile = percentile(sortedData, 75)
        Result.Median = percentile(sortedData, 50)
        Result.IQR = percentile(sortedData, 75) - percentile(sortedData, 25)

    End Sub

    ''' <summary>
    ''' Calculate percentile of a sorted data set
    ''' </summary>
    ''' <param name="sortedData"></param>
    ''' <param name="p"></param>
    ''' <returns></returns>
    Public Shared Function percentile(sortedData As Double(), p As Double) As Double

        If IsNothing(sortedData) Then Return 0

        Try
            ' algo derived from Aczel pg 15 bottom
            If p >= 100.0 Then
                Return sortedData(sortedData.Length - 1)
            End If

            Dim position As Double = CDbl(sortedData.Length + 1) * p / 100.0
            Dim leftNumber As Double = 0.0, rightNumber As Double = 0.0

            Dim n As Double = p / 100.0 * (sortedData.Length - 1) + 1.0

            If position >= 1 Then
                leftNumber = sortedData(CInt(System.Math.Floor(n)) - 1)
                rightNumber = sortedData(CInt(System.Math.Floor(n)))
            Else
                leftNumber = sortedData(0)
                ' first data
                ' first data
                rightNumber = sortedData(1)
            End If

            If leftNumber = rightNumber Then
                Return leftNumber
            Else
                Dim part As Double = n - System.Math.Floor(n)
                Return leftNumber + part * (rightNumber - leftNumber)
            End If
        Catch ex As Exception
            Return 0
        End Try

    End Function

    Private Shared Function InlineAssignHelper(Of T)(ByRef target As T, value As T) As T
        target = value
        Return value
    End Function

End Class




