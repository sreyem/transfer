﻿



Imports System.ComponentModel
Imports System.Drawing.Design
Imports System.Globalization
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports System.Windows.Forms.Design

Module PropertyEnhancements

    Public Const stdCountry As String = "en-US"
    Public Const stdDblformat As String = "G4"
    Public Const stdEmptystring As String = " - "
    Public Const stdPECSWGWunit As String = " µg/L"
    Public Const stdPECSedUnit As String = " µg/kg"
    Public Const stdPECmin As Double = 0.0001
    Public Const EmptyValue As Double = -1

    ''' <summary>
    ''' converts a double into a formated string
    ''' </summary>
    ''' <param name="value">
    ''' the value to convert as double
    ''' </param>
    ''' <param name="format">
    ''' format string, like "G4" (std if "") or "0.000E+00"
    ''' </param>
    ''' <param name="country">
    ''' country string like "en-US" (std if "") or "de-DE"
    ''' </param>
    ''' <returns>
    ''' a string , String.Empty on error
    ''' </returns>
    ''' <remarks></remarks>
    ''' 
    <Extension()>
    <DebuggerStepThrough>
    Public Function double2string(
                                 value As Double,
                        Optional format As String = "",
                        Optional country As String = "",
                        Optional min As Double = Double.NaN) As String


        If format = "" Then format = stdDblformat
        If country = "" Then country = stdCountry


        If Double.Parse(value) = EmptyValue Then Return stdEmptystring

        If Not Double.IsNaN(min) AndAlso value < min Then
            Return "<" & min.ToString
        End If

        Try
            Return value.ToString(
                              format:=format,
                            provider:=CultureInfo.CreateSpecificCulture(country))
        Catch ex As Exception

            Console.WriteLine("error converting double to string")
            Console.WriteLine("value   : " & value)
            Console.WriteLine("format  : " & format)
            Console.WriteLine("country : " & country)
            Console.WriteLine(ex.Message)

            Return String.Empty

        End Try

    End Function


    Public Class doubleString

        Inherits DoubleConverter

        '<TypeConverter(GetType(doubleString))>
        '<AttributeProvider(stdDblformat)>


        Public Shared country As String = stdCountry
        Public Shared format As String = stdDblformat
        Public Shared unit As String = String.Empty
        Public Shared min As Double = 0.0
        Public Shared minstring As String = " < " & stdPECmin.ToString
        Public Shared emptystring As String = " - "


        Public Overrides Function ConvertTo(
                                           context As ITypeDescriptorContext,
                                           culture As CultureInfo,
                                           value As Object,
                                           destType As Type) As Object

            Try

                If Double.IsNaN(value) Then

                    Return emptystring

                ElseIf CType(value, Double) = 0 Then

                    Return "0.0"

                ElseIf CType(value, Double) <= min Then

                    Return CType(value, Double).double2string(
                            format:=".0000E-00",
                            country:=country) & IIf(Double.IsNaN(CType(value, Double)), "", unit).ToString

                Else

                    Return CType(value, Double).double2string(
                            format:=doubleString.format,
                            country:=country) & IIf(Double.IsNaN(CType(value, Double)), "", unit).ToString

                End If


            Catch ex As Exception
                Return value
            End Try


        End Function

        Public Overrides Function ConvertFrom(
                                             context As ITypeDescriptorContext,
                                             culture As CultureInfo,
                                             value As Object) As Object

            Dim valueString As String = String.Empty

            Try

                valueString = CType(value, String)

                valueString = Replace(
                    Expression:=valueString,
                    Find:=unit,
                    Replacement:=String.Empty,
                    Compare:=CompareMethod.Text)

                If Double.IsNaN(Double.Parse(valueString)) Then
                    Return stdEmptystring
                Else
                    Return Double.Parse(valueString)
                End If

            Catch ex As Exception
                Return Double.NaN
            End Try

        End Function

    End Class

    Public Class Date2String2Date

        Inherits UITypeEditor

        ' usage :  add 
        '<Editor(GetType(Date2String2Date), GetType(UITypeEditor))>
        ' to property

        Public Shared startDate As Date = New Date(year:=1901, month:=1, day:=1)

        Public Shared DateTimePicker As New DateTimePicker

        Public Shared DateFormat As String = "dd. MMM. yyyy"

        Private editorService As IWindowsFormsEditorService

        Public Overrides Function GetEditStyle(
                            context As ITypeDescriptorContext) As UITypeEditorEditStyle
            Return UITypeEditorEditStyle.Modal
        End Function

        Public Overrides Function EditValue(
                            context As ITypeDescriptorContext,
                           provider As IServiceProvider,
                              value As Object) As Object

            editorService = DirectCast(
            provider.GetService(GetType(IWindowsFormsEditorService)),
            IWindowsFormsEditorService)

            Try

                With DateTimePicker

                    Try

                        If value.ToString = "" OrElse DateTime.Parse(s:=value.ToString) = Date.MinValue Then
                            .Value = Date2String2Date.startDate
                        Else
                            .Value = DateTime.Parse(s:=value.ToString)
                        End If

                    Catch ex As Exception
                        .Value = Date2String2Date.startDate
                    End Try


                End With

                editorService.DropDownControl(DateTimePicker)

                Return DateTimePicker.Value.ToString(DateFormat)
            Catch ex As Exception
                Return ""
            End Try


        End Function

    End Class


    ''' <summary>
    ''' on click enabler
    ''' [Editor(GetType(ButtonEmulator), GetType(UITypeEditor))]
    ''' </summary>
    Public Class ButtonEmulator

        Inherits UITypeEditor

        'use : <Editor(GetType(ButtonEmulator), GetType(UITypeEditor))>
        Public Shared Clicked As String = "Clicked"

#Region "Overloads Overrides"

        Public Overrides Function GetEditStyle(context As ITypeDescriptorContext) As UITypeEditorEditStyle
            Return UITypeEditorEditStyle.Modal
        End Function

        Public Overrides Function EditValue(context As ITypeDescriptorContext,
                                        provider As IServiceProvider,
                                        value As Object) As Object

            value = Clicked

            Return MyBase.EditValue(context,
                                    provider,
                                    value)

        End Function

#End Region

    End Class

    Public Class intNaN

        Inherits Int16Converter

        Public Shared emptystring As String = " - "
        Public Shared min As Integer = 1
        Public Shared minstring As String = " < "

        Public Overrides Function ConvertTo(
                                       context As ITypeDescriptorContext,
                                       culture As CultureInfo,
                                       value As Object,
                                       destType As Type) As Object

            Try

                If CType(value, Integer) = Integer.MaxValue Then

                    Return emptystring

                ElseIf CType(value, Integer) < min Then

                    Return minstring & min.ToString
                Else

                    Return CType(value, Integer).ToString

                End If

            Catch ex As Exception
                Return value
            End Try


        End Function

        Public Overrides Function ConvertFrom(
                                         context As ITypeDescriptorContext,
                                         culture As CultureInfo,
                                         value As Object) As Object

            Dim valueString As String = String.Empty

            Try

                valueString = CType(value, String)

                If valueString.Contains(minstring) Then
                    Return min
                ElseIf Integer.MaxValue = CInt(value) Then
                    Return Integer.MaxValue
                Else
                    Return Integer.Parse(valueString)
                End If

            Catch ex As Exception
                Return Integer.MaxValue
            End Try

        End Function


    End Class


    Public Class doubleNaN

        Inherits DoubleConverter

        '<TypeConverter(GetType(doubleString))>
        '<AttributeProvider(stdDblformat)>

        Public Shared min As Double = 0.001
        Public Shared minstring As String = " < "
        Public Shared emptystring As String = " - "


        Public Overrides Function ConvertTo(
                                           context As ITypeDescriptorContext,
                                           culture As CultureInfo,
                                           value As Object,
                                           destType As Type) As Object

            Try

                If Double.IsNaN(value) Then

                    Return emptystring

                ElseIf CType(value, Double) = 0 Then

                    Return "0.0"

                ElseIf CType(value, Double) <= min Then

                    Return minstring & min.ToString
                Else

                    Return CType(value, Double).ToString

                End If


            Catch ex As Exception
                Return value
            End Try


        End Function

        Public Overrides Function ConvertFrom(
                                             context As ITypeDescriptorContext,
                                             culture As CultureInfo,
                                             value As Object) As Object

            Dim valueString As String = String.Empty

            Try

                valueString = CType(value, String)

                If valueString.Contains(minstring) Then
                    Return min
                ElseIf Double.IsNaN(Double.Parse(valueString)) Then
                    Return 6
                Else
                    Return Double.Parse(valueString)
                End If

            Catch ex As Exception
                Return Double.NaN
            End Try

        End Function

    End Class

    Public Class Converter

        Inherits ExpandableObjectConverter

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                             ByVal destinationType As Type) As Boolean

            Try
                If (destinationType Is GetType(Converter)) Then
                    Return True
                End If
            Catch ex As Exception

            End Try

            Return MyBase.CanConvertTo(context,
                                           destinationType)

        End Function

        Public Overloads Overrides Function ConvertTo(
                                 ByVal context As ITypeDescriptorContext,
                                 ByVal culture As Globalization.CultureInfo,
                                 ByVal value As Object,
                                 ByVal destinationType As System.Type) As Object

            If (destinationType Is GetType(System.String)) Then
                Return ""
            End If

            Return MyBase.ConvertTo(context,
                                        culture,
                                        value,
                                        destinationType)

        End Function

        Public ReadOnly Property Name As String
            Get
                Return "#"
            End Get
        End Property

    End Class

End Module
