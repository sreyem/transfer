﻿Imports System.IO
Imports System.Runtime.Serialization
Imports System.Runtime.Serialization.Json
Imports System.Text
Imports System.Web.Script.Serialization
Imports System.Xml.Serialization

Public Module DeSerialize

#Region "XML"

    ''' <summary>
    ''' Save to file
    ''' Serializes a class to an xml file
    ''' </summary>
    ''' <param name="Class2Save">
    ''' The class to serialize
    ''' </param>
    ''' <param name="ClassType">
    ''' = gettype(Class2Save)
    ''' </param>
    ''' <param name="XMLFileName">
    ''' Target filename for the xml
    ''' </param>
    ''' <param name="ShowInNotepad">
    ''' if true notepad will display the file
    ''' </param> 
    ''' <returns> true or false
    ''' </returns>
    ''' <remarks></remarks>
    Public Function Class2XML(ByVal Class2Save As Object,
                              ByVal ClassType As Type,
                              ByVal XMLFileName As String,
                              Optional ShowInNotepad As Boolean = False) As Boolean

        If Not Directory.Exists(Path.GetDirectoryName(XMLFileName)) Then

            Try
                My.Computer.FileSystem.CreateDirectory(
                    Path.GetDirectoryName(XMLFileName))
            Catch ex As Exception
                mylog(LogTxtArray:={"IO ERROR",
                                    "Not a valid xml Path",
                                    XMLFileName,
                                    Join(parseExceptionMsg(ex), vbCrLf)})
                Return False
            End Try

        End If

        Try

            Dim mySerializer As XmlSerializer =
                            New XmlSerializer(ClassType)

            Dim myWriter As IO.StreamWriter =
                        New IO.StreamWriter(XMLFileName)

            mySerializer.Serialize(myWriter, Class2Save)

            myWriter.Close()
            myWriter = Nothing

            mylog(
                 LogTxtArray:={"OK : XML Serializing ",
                 Class2Save.ToString,
                 "to : " & XMLFileName})

        Catch ex As Exception

            mylog(Log2MsgBox:=True, MsgBoxBtn:=MsgBoxStyle.Critical, MsgTitle:="ERROR : XML Serializing",
                 LogTxtArray:={"ERROR : XML Serializing ",
                              Class2Save.ToString,
                              "to : " & XMLFileName,
                              Join(
                                  SourceArray:=parseExceptionMsg(ex),
                                  Delimiter:=vbCrLf)},
                ShowInNotepad:=ShowInNotepad)
            Return False

        End Try

        Return True

    End Function

    ''' <summary>
    ''' Load xml to class
    ''' De-serializes an xml file to a class 
    ''' </summary>
    ''' <param name="ClassType">
    ''' = gettype(Class2Fill)
    ''' </param>
    ''' <param name="XMLFileName">
    ''' Target filename for the xml
    ''' </param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function XML2Class(ByVal ClassType As Type,
                              ByVal XMLFileName As String) As Object

        Dim TargetClass As New Object


        Dim xmlFile As String() = {}


        If Not File.Exists(XMLFileName) Then

            mylog(
                LogTxtArray:={"IO ERROR",
                              "Not a valid XML Path",
                               XMLFileName})
            Return Nothing

        End If

        Try

            xmlFile = File.ReadAllLines(XMLFileName)

        Catch ex As Exception

            mylog(
                LogTxtArray:={"IO ERROR",
                              "Can't read xml file",
                               XMLFileName})
            Return Nothing
        End Try


        ' Call the Deserialize method and cast to the object type.
        Try

            Dim mySerializer As XmlSerializer =
                                   New XmlSerializer(ClassType)

            ' To read the file, create a FileStream.
            Dim myFileStream As IO.FileStream =
                            New IO.FileStream(XMLFileName, IO.FileMode.Open)


            Dim type As Type = TargetClass.GetType()
            Dim typeName As String = type.FullName


            TargetClass = mySerializer.Deserialize(myFileStream)
            myFileStream.Close()

            Try
                'check for xmltype
                typeName = TargetClass.xmlname
            Catch ex As Exception

                'else compare 2nd row start with class name
                typeName = ClassType.Name.ToString

            End Try

            If Not xmlFile(1).StartsWith("<" & typeName) Then

                mylog(
                LogTxtArray:={"File does NOT fit to class!",
                              "XML   type : " & xmlFile(1),
                              "Class type : " & typeName & " | " & ClassType.ToString})

                Return Nothing

            End If

        Catch ex As Exception

            mylog(
                LogTxtArray:={"Error de-serializing class",
                              "from file " & XMLFileName,
                              "XML   type : " & xmlFile(1),
                              "Class type : " & ClassType.ToString,
                              parseExceptionMsg(ex).First})

            Return Nothing

        End Try

        mylog(
                LogTxtArray:={"OK : XML De-serialize",
                XMLFileName,
                "to : " & ClassType.ToString})



        'Try
        '    CallByName(
        '        TargetClass,
        '        "_MD5Hash",
        '        CallType.Set,
        '        MD5HashGenerator.GenerateKey(sourceObject:=TargetClass))

        'Catch ex As Exception

        'End Try

        Return TargetClass

    End Function

#End Region

#Region "SOAP"

    ''' <summary>
    ''' Serializes a class to a binary file
    ''' </summary>
    ''' <param name="Class2Save">
    ''' The class to serialize
    ''' </param>
    ''' <param name="BINFileName">
    ''' Target filename for the binary file
    ''' </param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function Class2SOAP(Class2Save As Object,
                               BINFileName As String) As Boolean

        Dim formatter As IFormatter
        Dim fileStream As FileStream = Nothing
        Dim strObject As String = ""

        If Not Directory.Exists(Path.GetDirectoryName(BINFileName)) Then

            Try
                My.Computer.FileSystem.CreateDirectory(Path.GetDirectoryName(BINFileName))
            Catch ex As Exception
                mylog(LogTxtArray:={"IO ERROR",
                                    "Not a valid bin Path",
                                    BINFileName,
                                    Join(parseExceptionMsg(ex), vbCrLf)})
            End Try

        End If


        Try


            fileStream = New FileStream(
                        path:=BINFileName,
                        mode:=FileMode.Create,
                      access:=FileAccess.Write)

            formatter = New Formatters.Binary.BinaryFormatter
            formatter.Serialize(
                    serializationStream:=fileStream,
                                  graph:=Class2Save)

            mylog(
                 LogTxtArray:={"OK : SOAP Serializing ",
                 Class2Save.ToString,
                 "to : " & BINFileName})

        Catch ex As Exception

            mylog(LogTxtArray:={"ERROR SOAP Serializing",
                                "SOAP File " & BINFileName,
                                "Class " & Class2Save.ToString,
                                 Join(parseExceptionMsg(ex), vbCrLf)})

            Return False

        Finally

            If fileStream IsNot Nothing Then
                fileStream.Close()
            End If

        End Try

        Return True

    End Function


    ''' <summary>
    ''' De-serializes an binary file to a class
    ''' </summary>
    ''' <param name="BINFileName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function SOAP2Class(BINFileName As String) As Object

        Dim formatter As IFormatter
        Dim fileStream As FileStream = Nothing
        Dim objectFromSoap As Object = Nothing


        If Not File.Exists(BINFileName) Then

            mylog(
                LogTxtArray:={"IO ERROR",
                              "Not a valid bin Path",
                               BINFileName})
            Return Nothing

        End If

        Try

            fileStream = New FileStream(
                     path:=BINFileName,
                     mode:=FileMode.Open,
                   access:=FileAccess.Read)

            formatter = New Formatters.Binary.BinaryFormatter
            objectFromSoap = formatter.Deserialize(serializationStream:=fileStream)

            mylog(
                LogTxtArray:={"OK : SOAP De-Serializing ",
                              "from : " & BINFileName})

        Catch ex As Exception

            mylog(LogTxtArray:={"ERROR SOAP De-Serializing",
                                "SOAP File " & BINFileName,
                                 Join(parseExceptionMsg(ex), vbCrLf)})

            Return Nothing

        Finally

            If fileStream IsNot Nothing Then
                fileStream.Close()
            End If

        End Try

        Return objectFromSoap

    End Function


#End Region

#Region "JSON"

    Public Function formatJSON(ByVal inputText As String) As String

        Dim escaped As Boolean = False
        Dim inquotes As Boolean = False
        Dim column As Integer = 0
        Dim indentation As Integer = 0
        Dim indentations As Stack(Of Integer) = New Stack(Of Integer)()
        Dim TABBING As Integer = 2
        Dim sb As StringBuilder = New StringBuilder()

        For Each x As Char In inputText

            sb.Append(x)
            column += 1

            If escaped Then
                escaped = False
            Else

                If x = "\"c Then
                    escaped = True
                ElseIf x = """"c Then
                    inquotes = Not inquotes
                ElseIf Not inquotes Then

                    If x = ","c Then
                        sb.Append(vbCrLf)
                        column = 0

                        For i As Integer = 0 To indentation - 1
                            sb.Append(" ")
                            column += 1
                        Next
                    ElseIf x = "["c OrElse x = "{"c Then
                        indentations.Push(indentation)
                        indentation = column
                    ElseIf x = "]"c OrElse x = "}"c Then
                        indentation = indentations.Pop()
                    ElseIf x = ":"c Then

                        While (column Mod TABBING) <> 0
                            sb.Append(" "c)
                            column += 1
                        End While
                    End If
                End If
            End If
        Next

        Return sb.ToString()

    End Function

    Public Function saveClass2JSON(
                                  Class2Save As Object,
                                  filePath As String,
                                  Optional formatted As Boolean = True,
                              Optional ShowInNotepad As Boolean = False) As Boolean

        Dim serializer As New JavaScriptSerializer

        Dim serializedResult = serializer.Serialize(Class2Save)

        If formatted Then

            serializedResult =
                New JsonFormatter(
                    json:=serializedResult).Format
        End If

        Try

            File.WriteAllText(
                path:=filePath,
                contents:=serializedResult)

            mylog(
                 LogTxtArray:={"OK : JSON Serializing ",
                 Class2Save.ToString,
                 "to : " & filePath})

            If ShowInNotepad Then
                Process.Start(filePath)
            End If

            Return True

        Catch ex As Exception


            mylog(Log2MsgBox:=True, MsgBoxBtn:=MsgBoxStyle.Critical, MsgTitle:="ERROR : JSON Serializing",
                 LogTxtArray:={"ERROR : JSON Serializing ",
                              Class2Save.ToString,
                              "to : " & filePath,
                              Join(
                                  SourceArray:=parseExceptionMsg(ex),
                                  Delimiter:=vbCrLf)},
                ShowInNotepad:=ShowInNotepad)

            Return False

        End Try

        Return False

    End Function

    Public Function loadFromJSON(jsonFileName As String, classType As Type) As Object

        Dim jss = New JavaScriptSerializer()
        Dim jsonString As String = String.Empty

        'get json string
        Try
            jsonString =
                File.ReadAllText(
                    path:=jsonFileName)
        Catch ex As Exception

            mylog(LogTxtArray:={"IO ERROR reading JSON file",
                                 jsonFileName,
                                 Join(parseExceptionMsg(ex), vbCrLf)})

            Return Nothing

        End Try

        'de-serialization JSON string
        Try

            Return jss.Deserialize(
                           input:=jsonString,
                           targetType:=classType)



        Catch ex As Exception

            mylog(LogTxtArray:={"ERROR de-serialization JSON",
                                jsonFileName,
                                Join(parseExceptionMsg(ex), vbCrLf)})

            Return Nothing

        End Try

    End Function

#Region "file stream"

    Public Function Class2JSON(ByVal Class2Save As Object,
                               ByVal ClassType As Type,
                               ByVal JSONFileName As String,
                            Optional format As Boolean = True) As Boolean



        If Not Directory.Exists(Path.GetDirectoryName(JSONFileName)) Then


            Try
                My.Computer.FileSystem.CreateDirectory(
                    Path.GetDirectoryName(JSONFileName))
            Catch ex As Exception
                mylog(LogTxtArray:={"IO ERROR",
                                    "Not a valid JSON Path",
                                    JSONFileName,
                                    Join(parseExceptionMsg(ex), vbCrLf)})
                Return False
            End Try

        End If

        Try

            Dim fs As FileStream =
                New FileStream(
                path:=JSONFileName,
                mode:=FileMode.Create,
                access:=FileAccess.Write)

            Dim jf As New DataContractJsonSerializer(type:=ClassType)

            jf.WriteObject(fs, Class2Save)
            fs.Close()

        Catch ex As Exception

            mylog(Log2MsgBox:=True, MsgBoxBtn:=MsgBoxStyle.Critical, MsgTitle:="ERROR : JSON Serializing",
                LogTxtArray:={"ERROR : JSON Serializing ",
                             Class2Save.ToString,
                             "to : " & JSONFileName,
                             Join(
                                 SourceArray:=parseExceptionMsg(ex),
                                 Delimiter:=vbCrLf)},
               ShowInNotepad:=True)

            Return False

        End Try

        Return True

    End Function

    Public Function JSON2Class(ByVal ClassType As Type,
                               ByVal JSONFileName As String) As Object



        'Dim jss As New JavaScriptSerializer()
        'Dim jsonText As String = File.ReadAllText(path:=JSONFileName)

        Dim TargetClass As New Object

        If Not File.Exists(JSONFileName) Then

            mylog(
                LogTxtArray:={"IO ERROR",
                              "Not a valid JSON Path",
                               JSONFileName})
            Return Nothing

        End If

        Try

            Dim fs As FileStream =
               New FileStream(
               path:=JSONFileName,
               mode:=FileMode.Open)

            Dim jf As New DataContractJsonSerializer(type:=ClassType)

            TargetClass = jf.ReadObject(fs)
            fs.Close()

            Return TargetClass

        Catch ex As Exception

            mylog(Log2MsgBox:=True, MsgBoxBtn:=MsgBoxStyle.Critical, MsgTitle:="ERROR : JSON De-Serializing",
               LogTxtArray:={"ERROR : JSON De-Serializing ",
                             "Class type : " & ClassType.ToString,
                             "from file  :  " & JSONFileName,
                            Join(
                                SourceArray:=parseExceptionMsg(ex),
                                Delimiter:=vbCrLf)},
              ShowInNotepad:=True)

            Return False

        End Try

    End Function

#End Region

#Region "formating"

    Public Class JsonFormatter

        Private ReadOnly _walker As StringWalker
        Private ReadOnly _writer As IndentWriter = New IndentWriter()
        Private ReadOnly _currentLine As StringBuilder = New StringBuilder()
        Private _quoted As Boolean

        Public Sub New(ByVal json As String)
            _walker = New StringWalker(json)
            ResetLine()
        End Sub

        Public Sub ResetLine()
            _currentLine.Length = 0
        End Sub

        Public Function Format() As String
            While MoveNextChar()

                If Me._quoted = False AndAlso Me.IsOpenBracket() Then
                    Me.WriteCurrentLine()
                    Me.AddCharToLine()
                    Me.WriteCurrentLine()
                    _writer.Indent()
                ElseIf Me._quoted = False AndAlso Me.IsCloseBracket() Then
                    Me.WriteCurrentLine()
                    _writer.UnIndent()
                    Me.AddCharToLine()
                ElseIf Me._quoted = False AndAlso Me.IsColon() Then
                    Me.AddCharToLine()
                    Me.WriteCurrentLine()
                Else
                    AddCharToLine()
                End If
            End While

            Me.WriteCurrentLine()
            Return _writer.ToString()
        End Function

        Private Function MoveNextChar() As Boolean
            Dim success As Boolean = _walker.MoveNext()

            If Me.IsApostrophe() Then
                Me._quoted = Not _quoted
            End If

            Return success
        End Function

        Public Function IsApostrophe() As Boolean
            Return Me._walker.CurrentChar = """"c AndAlso Me._walker.IsEscaped = False
        End Function

        Public Function IsOpenBracket() As Boolean
            Return Me._walker.CurrentChar = "{"c OrElse Me._walker.CurrentChar = "["c
        End Function

        Public Function IsCloseBracket() As Boolean
            Return Me._walker.CurrentChar = "}"c OrElse Me._walker.CurrentChar = "]"c
        End Function

        Public Function IsColon() As Boolean
            Return Me._walker.CurrentChar = ","c
        End Function

        Private Sub AddCharToLine()
            Me._currentLine.Append(_walker.CurrentChar)
        End Sub

        Private Sub WriteCurrentLine()
            Dim line As String = Me._currentLine.ToString().Trim()

            If line.Length > 0 Then
                _writer.WriteLine(line)
            End If

            Me.ResetLine()
        End Sub
    End Class

    Public Class StringWalker
        Private ReadOnly _s As String
        Public Property Index As Integer
        Public Property IsEscaped As Boolean
        Public Property CurrentChar As Char

        Public Sub New(ByVal s As String)
            _s = s
            Me.Index = -1
        End Sub

        Public Function MoveNext() As Boolean
            If Me.Index = _s.Length - 1 Then Return False

            If IsEscaped = False Then
                IsEscaped = CurrentChar = "\"c
            Else
                IsEscaped = False
            End If

            Me.Index += 1
            CurrentChar = _s(Index)
            Return True
        End Function
    End Class

    Public Class IndentWriter
        Private ReadOnly _result As StringBuilder = New StringBuilder()
        Private _indentLevel As Integer

        Public Sub Indent()
            _indentLevel += 1
        End Sub

        Public Sub UnIndent()
            If _indentLevel > 0 Then _indentLevel -= 1
        End Sub

        Public Sub WriteLine(ByVal line As String)
            _result.AppendLine(CreateIndent() & line)
        End Sub

        Private Function CreateIndent() As String
            Dim indent As StringBuilder = New StringBuilder()

            For i As Integer = 0 To _indentLevel - 1
                indent.Append("    ")
            Next

            Return indent.ToString()
        End Function

        Public Overrides Function ToString() As String
            Return _result.ToString()
        End Function
    End Class

#End Region

#End Region

End Module
