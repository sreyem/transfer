﻿
Imports System.IO

Module main

    Public Sub main()

        Dim args As String() = Environment.GetCommandLineArgs

        Dim csv As String() = {}
        Dim startFilePath As String = ""

        Const logFileName As String = "getGwCsv.log"

#Region "    get startPath"

        If args.Count = 2 Then
            startFilePath = args.Last
        Else

            startFilePath = InputBox(Prompt:="Enter Start Path")

            If startFilePath = "" Then
                startFilePath = Environment.CurrentDirectory
            End If

        End If

        If Directory.Exists(startFilePath) Then

            log.FileName =
                        Path.Combine(
                            path1:=
                                Path.GetDirectoryName(
                                        path:=startFilePath),
                            path2:=logFileName)

            mylog(LogTxtArray:=getStartInfo)

        Else

            log.FileName =
                        Path.Combine(
                            path1:=
                                Environment.CurrentDirectory,
                            path2:=logFileName)

            mylog(
                LogTxt:=
                    "Invalid Start Path" & vbCrLf &
                    startFilePath)

            Process.Start(log.FileName)

            End

        End If

#End Region

        Dim PECgwResultsPELMO As New PECgwResultPELMO
        Dim PECgwResultsPEARL As New PECgwResultPEARL


        'PECgwResultsPELMO =
        'DeSerialize.XML2Class(
        'ClassType:=GetType(PECgwResultPELMO),
        'XMLFileName:=Path.Combine(startFilePath, "getGwCsv_PELMO.xml"))

        'PECgwResultsPEARL =
        'DeSerialize.XML2Class(
        'ClassType:=GetType(PECgwResultPEARL),
        'XMLFileName:=Path.Combine(startFilePath, "getGwCsv_PEARL.xml"))


#Region "    PELMO"

        PECgwResultsPELMO =
            PECgwResultPELMO.getPECgwResults4PELMO(
                startPath:=startFilePath)

        If Not IsNothing(PECgwResultsPELMO) Then

            PECgwResultsPELMO.serialize(filePath:=startFilePath, Model:="PELMO")

            csv =
            PECgwResultsPELMO.createCSV(
                PECgwResults:=PECgwResultsPELMO,
                Delimiter:=",")

            File.WriteAllLines(
            path:=Path.Combine(
                path1:=startFilePath,
                path2:="ResultsPELMO.csv"),
             contents:=csv)

            csv = {}

        End If


#End Region


#Region "    PEARL"

        PECgwResultsPEARL =
            PECgwResultPEARL.getPECgwResults4PEARL(
                startPath:=startFilePath)

        If Not IsNothing(PECgwResultsPEARL) Then
            PECgwResultsPEARL.serialize(filePath:=startFilePath, Model:="PEARL")

            csv =
                PECgwResultsPEARL.createCSV(
                    PECgwResults:=PECgwResultsPEARL,
                    Delimiter:=",")

            File.WriteAllLines(
                path:=Path.Combine(
                    path1:=startFilePath,
                    path2:="ResultsPEARL.csv"),
            contents:=csv)

            csv = {}
        End If



#End Region

        If Not IsNothing(PECgwResultsPELMO) AndAlso Not IsNothing(PECgwResultsPEARL) Then

            PECgwResults.createMD(
                       PELMO:=PECgwResultsPELMO,
                       PEARL:=PECgwResultsPEARL,
                       MACRO:=New PECgwResultMACRO,
                       mdFilePath:=
                           Path.Combine(
                               path1:=startFilePath,
                               path2:="getGwCsv.md"))

        End If




#Region "    MACRO"

        'Dim PECgwResultsMACRO As New PECgwResultMACRO

        'PECgwResultsMACRO =
        '    PECgwResultMACRO.getPECgwResults4MACRO(
        '        startPath:=startFilePath)

        'csv =
        '    PECgwResultsMACRO.createCSV(
        '        PECgwResults:=PECgwResultsMACRO,
        '        Delimiter:=",")

        'File.WriteAllLines(
        '    path:=Path.Combine(
        '        path1:=startFilePath,
        '        path2:="ResultsPELMO.csv"),
        'contents:=csv)

        'csv = {}

#End Region


    End Sub

#Region "    test"

    Public Sub createSUBs4GW(
                TargetPath As String,
                Optional masterPathPEARL As String = "Z:\_PROUTT\_software\FOCUSPEARL444")

        Dim CropDirs As String() = {}
        Dim prlFiles As String() = {}
        Dim prlFile As String() = {}
        Dim metFile As String = ""
        Dim botFile As String = ""
        Dim execFiles As String() = {}
        Dim space As Integer = 25




        Dim out As New List(Of String)
        Dim Complete As New List(Of String)

        Dim jobName As String
        Dim taskName As String = ""

        Const searchMet As String = "MeteoStation"
        Const searchBot As String = "LowerBoundaryFile"
        Const lineCont As String = ",\"
        Const queueDelimiter As String = "#-------------------------------------------------------------------------------"

        Const modelName As String = "pearlmodel.exe"

        Dim Header As String() =
            {
                "Universe".PadRight(space) & "= Vanilla",
                "Executable".PadRight(space) & "= ",
                "Log".PadRight(space) & "= log.txt"
            }


        CropDirs = Directory.GetDirectories(
            path:=TargetPath,
            searchPattern:="*.*",
            searchOption:=SearchOption.AllDirectories)

        CropDirs =
            Filter(
                Source:=CropDirs,
                Match:="PEARL",
                Include:=True,
                Compare:=CompareMethod.Text)

        CropDirs =
            Filter(
                Source:=CropDirs,
                Match:="\Crop",
                Include:=True,
                Compare:=CompareMethod.Text)

        File.Copy(
                sourceFileName:=
                    Path.Combine(
                        path1:=My.Application.Info.DirectoryPath,
                        path2:="CondorGWMaster.bat"),
                destFileName:=Path.Combine(
                        path1:=TargetPath,
                        path2:="CondorGWMaster.bat"), overwrite:=True)

        execFiles =
                Directory.GetFiles(
                path:=masterPathPEARL,
                searchPattern:="*.exe",
                searchOption:=SearchOption.TopDirectoryOnly)

        Header(1) =
            Header(1) &
            Filter(
                Source:=execFiles,
                Match:=modelName,
                Include:=True,
                Compare:=CompareMethod.Text).First

        execFiles = Filter(
                Source:=execFiles,
                Match:=modelName,
                Include:=False,
                Compare:=CompareMethod.Text)

        For Each CropDir As String In CropDirs

            out.Clear()

            prlFiles =
                Directory.GetFiles(
                path:=CropDir,
                searchPattern:="*.prl",
                searchOption:=SearchOption.TopDirectoryOnly)

            If prlFiles.Count = 0 Then
                Continue For
            End If

            Console.WriteLine(queueDelimiter)

            Console.WriteLine(".." &
                Replace(
                Expression:=CropDir,
                Find:=TargetPath,
                Replacement:=""))

            jobName = Replace(
                Expression:=CropDir,
                Find:=TargetPath,
                Replacement:="").Split("\")(1)

            For Each prlFilePath As String In prlFiles

                Console.Write(".")

                prlFile = File.ReadAllLines(path:=prlFilePath)
                metFile = Filter(Source:=prlFile, Match:=searchMet).First.Split.First & ".met"

                Try
                    botFile = Filter(Source:=prlFile, Match:=searchBot).First.Split.First & ".bot"
                Catch ex As Exception
                    botFile = ""
                End Try


                out.Add(queueDelimiter)

                taskName = Path.GetDirectoryName(path:=CropDir).Split("\").Last & " " &
                        Path.GetFileNameWithoutExtension(prlFilePath)

                out.Add("# JobName  : " & taskName.Split.First)
                out.Add("# TaskName : " & taskName.Split.Last)

                out.Add(queueDelimiter)

                out.Add(
                    "Arguments".PadRight(space) & "= " &
                    Path.GetFileName(prlFilePath))
                out.Add(
                    "transfer_input_files".PadRight(space) & "= " &
                    Path.GetFileName(prlFilePath) & lineCont)

                For Each exec As String In execFiles
                    out.Add(" ".PadRight(space) & "  " & exec & lineCont)
                Next

                out.Add(" ".PadRight(space) & "  " &
                        Path.Combine(path1:=masterPathPEARL, path2:=metFile))

                If botFile <> "" Then

                    out(out.Count - 1) &= lineCont

                    out.Add(" ".PadRight(space) & "  " &
                        Path.Combine(
                            path1:=masterPathPEARL,
                            path2:=botFile))

                End If

                out.Add(
                    "transfer_output_files".PadRight(space) & "= " &
                    Path.GetFileName(
                        Path.ChangeExtension(
                            path:=prlFilePath,
                            extension:="sum")) & lineCont)

                'out.Add(" ".PadRight(("transfer_output_files".PadRight(space) & "= ").Length) &
                '    Path.GetFileName(
                '        Path.ChangeExtension(
                '            path:=prlFilePath,
                '            extension:="err")))

                out.Add("Queue")

            Next

            Complete.Add("Initialdir".PadRight(space) & "= " & CropDir)
            Complete.AddRange(out)

            out.InsertRange(0, Header)

            Try
                File.WriteAllLines(
                    path:=Path.Combine(
                        path1:=CropDir,
                        path2:="Cloud4GWPEARL.sub"), contents:=out.ToArray)

                File.Copy(
                sourceFileName:=
                    Path.Combine(
                        path1:=My.Application.Info.DirectoryPath,
                        path2:="SingleCrop.bat"),
                destFileName:=Path.Combine(
                        path1:=CropDir,
                        path2:="SingleCrop.bat"), overwrite:=True)


                Console.WriteLine()

            Catch ex As Exception

            End Try

        Next

        Complete.InsertRange(0, Header)

        Try
            File.WriteAllLines(
                   path:=Path.Combine(
                       path1:=TargetPath,
                       path2:="CondorSubmit.sub"), contents:=Complete.ToArray)
        Catch ex As Exception

        End Try

    End Sub

    Public Function transformPeriodPlm2CSV(startPELMORunFilePath As String) As String()

        'C:\VS2020\GWExample\GWCabbageTFS\pathway3 TFS

    End Function

    Public Function transformPEARLSum2CSV(startSumFilePath As String) As String()

#Region "Definitions"


        Dim out As New List(Of String)
        Dim log As New List(Of String)
        Dim Delimiter As String = ","
        Dim Header As String = ""
        Dim Results As New List(Of String)
        Dim Scenario As String = ""
        Dim CropNumber As String = ""
        Dim Compounds As New List(Of String)
        Dim temp As String() = {}
        Dim tempList As New List(Of String)
        Dim yearList As New List(Of String)
        Dim Row As String = ""
        Dim StaticPart As String = ""
        Dim resFile As New List(Of String)
        Dim lastCrop As String = ""
        Dim actCrop As String = ""
        Dim CropName As String = ""
        Dim nextCrop As Boolean = False
        Dim resPath As String = ""
        Dim Target As String = ""

        Dim sumFiles As String() = {}
        Dim sumFile As String() = {}


#End Region

#Region "Search strings"

        Const resultSearch As String = "Result_"
        Const scenarioSearch As String = "* Location"
        Const cropNumberSearch As String = "* Application_scheme"
        Const cropSearch As String = "* Crop calendar"
        Const percentileSearch As String = "th percentile"
        Const targetSearch As String = "Target_"

#End Region


#Region "Crop001_Chat.sum in start dir"

        'get all sum files in start path and recursive
        sumFiles =
            Directory.GetFiles(
            path:=startSumFilePath,
            searchPattern:="*.sum",
            searchOption:=SearchOption.AllDirectories)

        For counter As Integer = 0 To sumFiles.Count - 1

            'check whether we have Crop001_Chat.sum in start dir ..., 
            If Path.GetDirectoryName(sumFiles(counter)) = startSumFilePath Then

                tempList.Clear()
                tempList.AddRange(Path.GetFileName(sumFiles(counter)).Split("_"))

                'then rename 
                Target =
                    Path.Combine(
                    path1:=startSumFilePath,
                    path2:=Join(
                        SourceArray:={tempList(0),
                                      tempList(1)},
                        Delimiter:="_"),
                    path3:="PEARL444",
                    path4:=tempList(2))

                'And copy to crop folder
                Console.WriteLine("Source : " & sumFiles(counter))
                Console.WriteLine("Target : " & Target)
                File.Move(
                    sourceFileName:=sumFiles(counter),
                    destFileName:=Target)

            End If

        Next

#End Region

        'get all sum files in crop dirs and recursive
        sumFiles =
            Directory.GetFiles(
            path:=startSumFilePath,
            searchPattern:="*.sum",
            searchOption:=SearchOption.AllDirectories)

        sumFile = File.ReadAllLines(path:=sumFiles.First)

#Region "get Compound(s)"

        tempList.Clear()
        tempList.AddRange(
            Filter(
            Source:=sumFile,
            Match:=resultSearch,
            Include:=True,
            Compare:=CompareMethod.Text))

        tempList.RemoveAt(0)
        Compounds.Clear()

        Console.WriteLine("Compounds : ")

        For Each member As String In tempList

            temp =
                member.Split(
                separator:={" "c},
                options:=StringSplitOptions.RemoveEmptyEntries)

            temp = temp(1).Split("_")
            Compounds.Add(temp.Last)
            Console.Write(vbTab & Compounds.Last)

        Next

#End Region

#Region "Header and GAP row"

        Row =
            Join(
            SourceArray:=Compounds.ToArray,
            Delimiter:=Delimiter)

        Row = "Model,PMTno,Crop,Scenario,Type," & Row

        out.Add(Row) : Row = ""

#End Region

        For counter As Integer = 0 To sumFiles.Count - 1

            Console.WriteLine()
            Console.WriteLine(counter.ToString("000") & " of " & sumFiles.Count.ToString("000"))

            sumFile = File.ReadAllLines(path:=sumFiles(counter))

#Region "Info from *.sum files"

            'get 'crop001'
            Try

                actCrop = Trim(Filter(
                           Source:=sumFile,
                           Match:=cropNumberSearch,
                           Include:=True,
                           Compare:=CompareMethod.Text).First.Split.Last.Split("_").First)

                Console.Write(vbTab & actCrop)

                StaticPart = "PEARL," & actCrop & ","

            Catch ex As Exception
                Continue For
            End Try

            'get crop name like SPOTATOES
            CropName = Trim(Filter(
                Source:=sumFile,
                Match:=cropSearch,
                Include:=True,
                Compare:=CompareMethod.Text).Last.Split("-").Last)

            Console.Write(CropName.PadLeft(15))

            StaticPart &= CropName & ","

            'check whether 'crop001' is changing and write *.res file for each of those
            If lastCrop = "" Then

                lastCrop = actCrop

            ElseIf actCrop <> lastCrop Then

                Try

                    Target =
                    Path.Combine(
                    path1:=Path.GetDirectoryName(sumFiles(counter - 1)),
                    path2:=lastCrop & "_" & CropName & ".res")

                    File.WriteAllLines(
                        path:=Target,
                        contents:=resFile.ToArray)

                Catch ex As Exception

                End Try

                resFile.Clear()
                lastCrop = actCrop

            End If

            'get scenario like 'Hamburg'
            Scenario = Filter(
                Source:=sumFile,
                Match:=scenarioSearch,
                Include:=True,
                Compare:=CompareMethod.Text).First.Split.Last

            If Scenario.Length > 4 Then

                Scenario = Scenario.ToUpper.Substring(0, 4)

                Scenario =
                    Replace(
                        Expression:=Scenario,
                        Find:="Â",
                        Replacement:="A",
                        Compare:=CompareMethod.Text)

            End If

            Console.Write(Scenario.PadLeft(15))
            StaticPart &= Scenario & ","
            Row = StaticPart
            resFile.Add(Scenario & ";")


            'get percentile
            Row &= Filter(
            Source:=sumFile,
            Match:=percentileSearch,
            Include:=True,
            Compare:=CompareMethod.Text).First.Split(" ")(9) & ","

#End Region

#Region "get results"

            tempList.Clear()
            tempList.AddRange(
            Filter(
            Source:=sumFile,
            Match:=resultSearch,
            Include:=True,
            Compare:=CompareMethod.Text))

            tempList.RemoveAt(0)
            Results.Clear()

            For Each Compound As String In Compounds
                Try
                    Results.Add(Filter(Source:=tempList.ToArray, Match:="_" & Compound).First.Split.Last)
                Catch ex As Exception

                    Console.WriteLine()
                    Console.WriteLine("********")
                    Console.WriteLine(ex.Message)
                    Console.WriteLine("********")

                    If InputBox(
                        Prompt:=ex.Message & vbCrLf &
                        " Continue?",
                        Title:="Error reading results", "No").ToUpper <> "YES" Then
                        Return {}
                    End If

                End Try
            Next

#End Region



            Row &= Join(SourceArray:=Results.ToArray, Delimiter:=Delimiter)
            out.Add(Row)
            resFile(resFile.Count - 1) &= Join(SourceArray:=Results.ToArray, Delimiter:=";")

#Region "get all years results"

            yearList.Clear()
            For Each Compound As String In Compounds

                tempList.Clear()
                tempList.AddRange(Filter(Source:=sumFile, Match:=targetSearch & Compound))

                For rowCounter As Integer = 0 To tempList.Count - 1

                    temp = tempList(rowCounter).Split

                    If Compound = Compounds.First Then
                        yearList.Add(StaticPart & temp.First & "," & temp.Last)
                    Else
                        yearList(rowCounter) &= "," & temp.Last
                    End If

                Next

            Next

            out.AddRange(yearList)

#End Region

        Next



        Try

            resPath = Path.Combine(
                            path1:=Path.GetDirectoryName(path:=sumFiles.Last),
                            path2:=lastCrop & "_" & CropName & ".res")

            File.WriteAllLines(
                        path:=resPath,
                        contents:=resFile.ToArray)

        Catch ex As Exception

        End Try

        Return out.ToArray

    End Function

    Public Function transformPELMOPlm2CSV(plmFilePath As String) As String()

#Region "Definitions"

        Dim out As New List(Of String)
        Dim log As New List(Of String)
        Dim Delimiter As String = ","
        Dim Header As String = ""
        Dim Results As New List(Of String)
        Dim Scenario As String = ""
        Dim CropNumber As String = ""
        Dim CropName As String = ""
        Dim temp As String() = {}
        Dim tempList As New List(Of String)
        Dim yearList As New List(Of String)
        Dim Row As String = ""
        Dim StaticPart As String = ""
        Dim Compounds As New List(Of String)
        Dim plmFiles As String() = {}
        Dim plmFile As String() = {}
        Dim modelVersion As String = ""

        Dim lastCrop As String = ""
        Dim actCrop As String = ""
        Dim target As String
        Dim percentile As String

        Dim startIndex As Integer
        Dim endIndex As Integer




#End Region


#Region "Search strings"

        Const compSearch As String = "in the percolate at 1 m"
        Const percSearch As String = "Perc.("

#End Region

#Region "get all period.plm files"

        'get all period.plm files in start path and recursive
        plmFiles =
            Directory.GetFiles(
            path:=plmFilePath,
            searchPattern:="period.plm",
            searchOption:=SearchOption.AllDirectories)

        Try
            plmFile = File.ReadAllLines(plmFiles.First)
        Catch ex As Exception
            mylog(LogTxtArray:=parseExceptionMsg(Exception:=ex))
            Return {}
        End Try

#End Region

#Region "get Compound(s)"

        tempList.Clear()
        tempList.AddRange(
            Filter(
            Source:=plmFile,
            Match:=compSearch,
            Include:=True,
            Compare:=CompareMethod.Text))

        Compounds.Clear()

        Console.WriteLine("Compounds : ")

        For Each member As String In tempList

            temp =
                member.Split(
                separator:={"("c},
                options:=StringSplitOptions.RemoveEmptyEntries)

            temp = temp(1).Split(")")
            Compounds.Add(temp.First)
            Console.Write(vbTab & Compounds.First)

        Next



#End Region

#Region "Header and GAP row"

        Row =
            Join(
            SourceArray:=Compounds.ToArray,
            Delimiter:=Delimiter)

        Row = "Model,CropNumber,Crop,Scenario,Type," & Row

        out.Add(Row) : Row = ""

#End Region

        For counter As Integer = 0 To plmFiles.Count - 1

            Console.WriteLine()
            Console.WriteLine(counter.ToString("000") & " of " & plmFiles.Count.ToString("000"))

            plmFile = File.ReadAllLines(path:=plmFiles(counter))

#Region "get 'crop001, crop name and model version from path"

            temp = plmFiles(counter).Split("\")

            For Each member As String In temp

                If member.StartsWith("Crop") Then

                    temp = member.Split("_")
                    CropNumber = temp.First
                    CropName = temp.Last

                ElseIf member.StartsWith("PELMO") Then
                    modelVersion = member

                    Exit For
                End If

            Next

#End Region

#Region "check whether 'crop001' is changing and write *.res file for each of those"


            'check whether 'crop001' is changing and write *.res file for each of those
            If lastCrop = "" Then

                lastCrop = actCrop

            ElseIf actCrop <> lastCrop Then

                Try

                    target =
                    Path.Combine(
                    path1:=Path.GetDirectoryName(plmFiles(counter - 1)),
                    path2:=lastCrop & "_" & CropName & ".res")

                    'File.WriteAllLines(
                    '    path:=Target,
                    '    contents:=resFile.ToArray)

                Catch ex As Exception

                End Try

                ' resFile.Clear()
                lastCrop = actCrop

            End If

#End Region

            Scenario = Path.GetDirectoryName(plmFiles(counter))
            Scenario = Path.GetFileNameWithoutExtension(Scenario).Split("_").First

            If Scenario.Length > 4 Then

                Scenario = Scenario.ToUpper.Substring(0, 4)

                Scenario =
                    Replace(
                        Expression:=Scenario,
                        Find:="Â",
                        Replacement:="A",
                        Compare:=CompareMethod.Text)

            End If

            Row =
                        Join(
                        SourceArray:={modelVersion, CropNumber, CropName, Scenario},
                        Delimiter:=", ")

            'get percentile
            temp = Filter(
            Source:=plmFile,
            Match:=percSearch,
            Include:=True,
            Compare:=CompareMethod.Text)

            ReDim Preserve temp(temp.Count / 2 - 1)

            For Each member As String In temp
                Results.Add(member.Split(vbTab).Last)
            Next

            percentile =
            temp.First.Split(
                        separator:={" "c},
                        options:=StringSplitOptions.RemoveEmptyEntries).First
            percentile =
                Replace(
                    Expression:=percentile,
                    Find:=vbTab,
                    Replacement:="",
                    Compare:=CompareMethod.Text)
            Row &= ", " & percentile & "th"
            Row &= ", " & Join(SourceArray:=Results.ToArray, Delimiter:=",")
            out.Add(Row)

            tempList.Clear()

            For compoundCounter As Integer = 0 To Compounds.Count - 1

                startIndex =
                    Array.FindIndex(
                    array:=plmFile,
                    match:=Function(x) x.StartsWith(vbTab & "---"))

                endIndex =
                    Array.FindIndex(
                    startIndex:=startIndex + 1,
                    array:=plmFile,
                    match:=Function(x) x.StartsWith(vbTab & "---"))

                For yearCounter As Integer = startIndex + 1 To endIndex - 1

                    Row = plmFile(yearCounter)

                    If compoundCounter = 0 Then
                        tempList.Add(Row.Split(vbTab).Last)
                    Else
                        tempList(yearCounter - startIndex - 1) = tempList(yearCounter - startIndex - 1) & "," & (Row.Split(vbTab).Last)
                    End If

                Next


            Next


            For yearcouter As Integer = 0 To tempList.Count - 1

                Row =
                       Join(
                       SourceArray:={modelVersion, CropNumber, CropName, Scenario},
                       Delimiter:=", ")

                Row &= " ," &
                    1907 + yearcouter & " ," &
                    tempList(yearcouter)

                out.Add(Row)

            Next

        Next

        Return out.ToArray

    End Function

#End Region

End Module
