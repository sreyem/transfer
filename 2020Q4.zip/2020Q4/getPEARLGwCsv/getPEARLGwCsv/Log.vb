﻿
Imports System.IO
Imports System.Management

<DebuggerStepThrough()>
Public Module log

#Region "Settings"

    ''' <summary>
    ''' Contend of the log
    ''' </summary>
    ''' <remarks></remarks>
    Public LogList As New List(Of String)

    ''' <summary>
    ''' Log Filename
    ''' </summary>
    ''' <remarks></remarks>
    Public FileName As String = ""

    Public Enum eLogLevel
        std = -1
        init = 0
        one
        two
        three
        up
        down
    End Enum

    ''' <summary>
    ''' Intent level
    ''' </summary>
    ''' <remarks></remarks>
    Public stdIntentLevel As eLogLevel = eLogLevel.init

    ''' <summary>
    ''' No of spaces per intent level
    ''' </summary>
    ''' <remarks></remarks>
    Public IntentSpacePerLevel As Integer = 3


    Public FirstIntentChar As Char = "|"c

    ''' <summary>
    ''' std. time stamp at the start of the log line
    ''' </summary>
    ''' <remarks></remarks>
    Public Const StdTimeStampPattern As String = "hh:mm"

    Public Enum eLog2Console
        Yes
        No
        Only
    End Enum

#End Region

#Region "Log and friends"

    ''' <summary>
    ''' log simple one line msg
    ''' </summary>
    ''' <param name="LogTxt">
    ''' Log msg as one line
    ''' </param>
    ''' <param name="IntentLevel">
    ''' Intent level as enum
    ''' std, init, on, two, three, up, down
    ''' </param>
    ''' <param name="Log2Console">
    ''' Log also to console, std. = on
    ''' </param>
    ''' <param name="Log2File">
    ''' Write log instantaneously to file, std. = on
    ''' </param>
    ''' <param name="Log2Msgbox">
    ''' Log also to MsgBox, std. = false
    ''' </param>
    ''' <param name="MsgBoxBtn">
    ''' If Log2MsgBox = true => Button
    ''' </param>
    ''' <param name="MsgTitle">
    ''' If Log2MsgBox = true => MsgTitle
    ''' ></param>
    ''' <param name="Add2PreviousRow">
    ''' If true log will be append to prev. row, std. = false
    ''' </param>
    ''' <param name="TimeStampPattern">
    ''' Std. = "hh:mm"
    ''' </param>
    ''' <param name="Exception2Throw">
    ''' Throw this exception
    ''' </param>
    ''' <param name="ShowInNotepad">
    ''' Show complete Log in Notepad, std. = false
    ''' </param>
    ''' <returns>
    ''' MsgBoxResult, like Yes, No or Cancel
    ''' </returns>
    Function mylog(
                LogTxt As String,
                Optional IntentLevel As eLogLevel = eLogLevel.std,
                Optional Log2Console As eLog2Console = eLog2Console.Yes,
                Optional Log2File As Boolean = True,
                Optional Log2MsgBox As Boolean = False,
                Optional MsgBoxBtn As MsgBoxStyle = MsgBoxStyle.Exclamation,
                Optional MsgTitle As String = "",
                Optional Add2PreviousRow As Boolean = False,
                Optional TimeStampPattern As String = "std",
                Optional Exception2Throw As Exception = Nothing,
                Optional ShowInNotepad As Boolean = False) As MsgBoxResult




        Dim TempList As New List(Of String)
        Dim TimeStamp As String
        Dim Intent As String = " "


        If Not IsNothing(Exception2Throw) Then

            If LogTxt <> String.Empty Then LogTxt &= vbCrLf

            LogTxt &= Join(parseExceptionMsg(
                                    Exception:=Exception2Throw,
                         UserErrorDescription:=LogTxt),
                                    Delimiter:=vbCrLf)

        End If

        Select Case IntentLevel

            Case eLogLevel.std
                IntentLevel = stdIntentLevel

            Case eLogLevel.init
                stdIntentLevel = IntentLevel

            Case eLogLevel.up

                If stdIntentLevel = eLogLevel.init Then IntentLevel = eLogLevel.one
                If stdIntentLevel = eLogLevel.one Then IntentLevel = eLogLevel.two
                If stdIntentLevel = eLogLevel.two Then IntentLevel = eLogLevel.three
                stdIntentLevel = IntentLevel

            Case eLogLevel.down

                If stdIntentLevel = eLogLevel.init Then IntentLevel = eLogLevel.std
                If stdIntentLevel = eLogLevel.one Then IntentLevel = eLogLevel.std
                If stdIntentLevel = eLogLevel.two Then IntentLevel = eLogLevel.one
                If stdIntentLevel = eLogLevel.three Then IntentLevel = eLogLevel.two
                stdIntentLevel = IntentLevel

        End Select

        Select Case IntentLevel

            Case eLogLevel.init
                Intent = " "

            Case eLogLevel.one
                Intent = " " & FirstIntentChar.ToString.PadRight(IntentSpacePerLevel)

            Case eLogLevel.two
                Intent = " " & FirstIntentChar.ToString.PadRight(IntentSpacePerLevel) &
                               FirstIntentChar.ToString.PadRight(IntentSpacePerLevel)

            Case eLogLevel.three
                Intent = " " & FirstIntentChar.ToString.PadRight(IntentSpacePerLevel) &
                               FirstIntentChar.ToString.PadRight(IntentSpacePerLevel) &
                               FirstIntentChar.ToString.PadRight(IntentSpacePerLevel)

        End Select


        Dim Lastlines As New List(Of String)

        Dim Txt2Log As String = ""

        'format time stamp + log level
        If TimeStampPattern = "std" Then
            TimeStampPattern = StdTimeStampPattern
        End If

        If TimeStampPattern = "" Then
            TimeStamp = " "
        Else
            TimeStamp = Now.ToString(StdTimeStampPattern) & " "
        End If

        'multi row log text without repeating time stamp
        If LogTxt.Contains(vbCrLf) OrElse
           LogTxt.Contains(vbLf) Then

            TempList.Clear()
            TempList.AddRange(LogTxt.Split(CChar(vbCrLf)))

            '1st row with time stamp
            'add to prev. row ?
            If Add2PreviousRow Then

                Txt2Log = Replace(
                            Expression:="".PadLeft(TimeStamp.Length) & Intent & TempList.First,
                                  Find:=vbCrLf,
                           Replacement:="")

            Else

                Txt2Log = Replace(
                            Expression:=TimeStamp & Intent & TempList.First,
                                  Find:=vbCrLf,
                           Replacement:="")

                Txt2Log = Replace(
                            Expression:=Txt2Log,
                                  Find:=vbLf,
                           Replacement:="")

            End If



            If Log2Console = eLog2Console.Only Then
                Console.WriteLine(Txt2Log)
            Else
                Console.WriteLine(Txt2Log)
                LogList.Add(Txt2Log)
            End If

            'all others without
            For counter As Integer = 1 To TempList.Count - 1

                Txt2Log = Replace(
                    Expression:=TempList(counter),
                          Find:=vbLf,
                   Replacement:="")


                If TimeStampPattern <> "" Then

                    Txt2Log = "".PadLeft(TimeStamp.Length) & Intent &
                    Txt2Log

                End If

                'log 2 console
                Select Case Log2Console

                    Case eLog2Console.Yes

                        Console.WriteLine(Txt2Log)
                        LogList.Add(Txt2Log)

                    Case eLog2Console.Only

                        Console.WriteLine(Txt2Log)

                    Case eLog2Console.No
                        LogList.Add(Txt2Log)

                End Select

            Next

        Else

            'single row log text
            If Add2PreviousRow Then
                LogList(LogList.Count - 1) = LogList.Last & LogTxt
            Else
                If TimeStampPattern = "" Then
                    LogList.Add(Intent & LogTxt)
                Else
                    LogList.Add(TimeStamp & Intent & LogTxt)
                End If
            End If

            'log 2 console
            Select Case Log2Console

                Case eLog2Console.Yes, eLog2Console.Only
                    Try
                        If Add2PreviousRow Then Console.CursorTop = Console.CursorTop - 1
                    Catch ex As Exception

                    End Try

                    Console.WriteLine(LogList(LogList.Count - 1))
                    'LogList.Add(LogTxt)

                Case eLog2Console.No

            End Select

        End If

        Try

            If Log2File Then

                File.WriteAllLines(
                                path:=FileName,
                                contents:=LogList.ToArray)

            End If

            Try
                If ShowInNotepad Then showLogInNotepad()
            Catch ex As Exception

                Throw New Exception(message:="Can't show log file in editor" & vbCrLf & FileName,
                                innerException:=ex)

            End Try

        Catch ex As Exception

            Throw New Exception(message:="Can't write to log file" & vbCrLf & FileName,
                                innerException:=ex)

        End Try

        If Not IsNothing(Exception2Throw) Then
            Throw New Exception(
                       message:=LogTxt,
                innerException:=Exception2Throw)
        End If

        If Log2MsgBox Then

            Return MsgBox(Prompt:=LogTxt,
                         Buttons:=MsgBoxBtn,
                           Title:=MsgTitle)

        End If

        Return MsgBoxResult.Ok

    End Function

    ''' <summary>
    ''' Log array of strings
    ''' </summary>
    ''' <param name="LogTxtArray">
    ''' Array of strings to log
    ''' </param>
    ''' <param name="IntentLevel">
    ''' Intent level as enum
    ''' std,init,on,two,three,up,down
    ''' </param>
    ''' <param name="Log2Console">
    ''' Log also to console, std. = on
    ''' </param>
    ''' <param name="Log2File">
    ''' Write log instantaneously to file, std. = on
    ''' </param>
    ''' <param name="Log2Msgbox">
    ''' Log also to MsgBox, std. = false
    ''' </param>
    ''' <param name="MsgBoxBtn">
    ''' If Log2MsgBox = true => Button
    ''' </param>
    ''' <param name="MsgTitle">
    ''' If Log2MsgBox = true => MsgTitle
    ''' ></param>
    ''' <param name="Add2PreviousRow">
    ''' If true log will be append to prev. row, std. = false
    ''' </param>
    ''' <param name="TimeStampPattern">
    ''' Std. = "hh:mm"
    ''' </param>
    ''' <param name="Exception2Throw">
    ''' Throw this exception
    ''' </param>
    ''' <param name="ShowInNotepad">
    ''' Show complete Log in Notepad, std. = false
    ''' </param>
    ''' <returns></returns>
    Public Function mylog(
                        LogTxtArray As String(),
                        Optional IntentLevel As eLogLevel = eLogLevel.std,
                        Optional Log2Console As eLog2Console = eLog2Console.Yes,
                        Optional Log2File As Boolean = True,
                        Optional Log2MsgBox As Boolean = False,
                        Optional MsgBoxBtn As MsgBoxStyle = MsgBoxStyle.Exclamation,
                        Optional MsgTitle As String = "",
                        Optional Add2PreviousRow As Boolean = False,
                        Optional TimeStampPattern As String = "std",
                        Optional Exception2Throw As Exception = Nothing,
                        Optional ShowInNotepad As Boolean = False) As MsgBoxResult

        Return mylog(
                    LogTxt:=Join(LogTxtArray, vbCrLf),
                    IntentLevel:=IntentLevel,
                    Log2Console:=Log2Console,
                    Log2File:=Log2File,
                    Log2MsgBox:=Log2MsgBox,
                    MsgBoxBtn:=MsgBoxBtn,
                    MsgTitle:=MsgTitle,
                    TimeStampPattern:=TimeStampPattern,
                    Exception2Throw:=Exception2Throw,
                    ShowInNotepad:=ShowInNotepad)

    End Function

    ''' <summary>
    ''' Log multiple lines
    ''' </summary>
    ''' <param name="LogTxtList">
    ''' List of string of lines to log
    ''' </param>
    ''' <param name="IntentLevel">
    ''' Intent level as enum
    ''' std,init,on,two,three,up,down
    ''' </param>
    ''' <param name="Log2Console">
    ''' Log also to console, std. = on
    ''' </param>
    ''' <param name="Log2File">
    ''' Write log instantaneously to file, std. = on
    ''' </param>
    ''' <param name="Log2Msgbox">
    ''' Log also to MsgBox, std. = false
    ''' </param>
    ''' <param name="MsgBoxBtn">
    ''' If Log2MsgBox = true => Button
    ''' </param>
    ''' <param name="MsgTitle">
    ''' If Log2MsgBox = true => MsgTitle
    ''' ></param>
    ''' <param name="TimeStampPattern">
    ''' Std. = "hh:mm"
    ''' </param>
    ''' <param name="Exception2Throw">
    ''' Throw this exception
    ''' </param>
    ''' <param name="ShowInNotepad">
    ''' Show complete Log in Notepad, std. = false
    ''' </param>
    ''' <returns></returns>
    Public Function mylog(
                        LogTxtList As List(Of String),
                        Optional IntentLevel As eLogLevel = eLogLevel.std,
                        Optional Log2Console As eLog2Console = eLog2Console.Yes,
                        Optional Log2File As Boolean = True,
                        Optional Log2MsgBox As Boolean = False,
                        Optional MsgBoxBtn As MsgBoxStyle = MsgBoxStyle.Exclamation,
                        Optional MsgTitle As String = "",
                        Optional TimeStampPattern As String = "std",
                        Optional Exception2Throw As Exception = Nothing,
                        Optional ShowInNotepad As Boolean = False) As MsgBoxResult

        Return mylog(
                LogTxt:=Join(LogTxtList.ToArray, vbCrLf),
                IntentLevel:=IntentLevel,
                Log2Console:=Log2Console,
                Log2File:=Log2File,
                Log2MsgBox:=Log2MsgBox,
                MsgBoxBtn:=MsgBoxBtn,
                MsgTitle:=MsgTitle,
                TimeStampPattern:=TimeStampPattern,
                Exception2Throw:=Exception2Throw,
                ShowInNotepad:=ShowInNotepad)

    End Function

#End Region

#Region "Helper: getStartInfo, showLogInNotepad, reset Log"

    ''' <summary>
    ''' Basic app. infos
    ''' </summary>
    Public Function getStartInfo(Optional LeadingString As String = "") As String()

        Dim InfoList As New List(Of String)

        With InfoList

            Try
                With My.Application.Info
                    InfoList.Add(LeadingString & .ProductName & " v" & .Version.ToString)
                    InfoList.Add(LeadingString & .Title)
                    InfoList.Add(LeadingString & .Copyright)
                End With
            Catch ex As Exception
                InfoList.Add("No info about title and version !!")
            End Try

            .Add(LeadingString & "Started on " & Now.ToString("dddd, dd.MMM.yy"))
            .Add(LeadingString & "        at " & Now.ToString("hh:mm:ss"))
            .Add(LeadingString & "        by " & Environment.UserName)
            .Add(LeadingString & "on machine " & Environment.MachineName &
                                          " (" & Environment.ProcessorCount & " CPUs with " & GetCpuSpeed() & " GHz)")
            .Add(LeadingString & "        OS " & My.Computer.Info.OSFullName & " / " &
                                                 My.Computer.Info.OSPlatform & " / " &
                                                 My.Computer.Info.OSVersion)
            .Add(LeadingString & "           ")
            .Add(LeadingString & "Culture    " & My.Application.Culture.ToString)
            .Add(LeadingString & "           " & "Numbers = " & Math.Round(Math.PI, 2).ToString)
            .Add(LeadingString & "           " & "Dates   = " & New Date(year:=1984, month:=10, day:=15).ToLongDateString)
            .Add(LeadingString & "           " & "CSV     = " & My.Application.Culture.NumberFormat.NumberGroupSeparator.ToString)

            Try
                .Add(LeadingString & "Exec.  Dir " & My.Application.Info.DirectoryPath.ToString)
                .Add(LeadingString & "Work   Dir " & Environment.CurrentDirectory)
                .Add(LeadingString & "Net avail. " & My.Computer.Network.IsAvailable.ToString &
                                                    " (" & Environment.UserDomainName & ")")
            Catch ex As Exception
                .Add("No info about execution directory And/Or network !!")
            End Try

        End With

        Return InfoList.ToArray

    End Function

    Public Function GetCpuSpeed() As Double
        Dim managementObject = New ManagementObject("Win32_Processor.DeviceID='CPU0'")
        Dim speed As UInteger = CUInt(managementObject("CurrentClockSpeed"))
        managementObject.Dispose()
        Return Math.Round(speed / 1000, digits:=2)
    End Function

    ''' <summary>
    ''' Show log in editor
    ''' </summary>
    Public Sub showLogInNotepad()

        If FileName = "" Then Exit Sub

        Try
            Process.Start(FileName)
        Catch ex As Exception
            MsgBox(Prompt:="Can't show log file '" & FileName & "'" & vbCrLf & ex.Message,
                  Buttons:=MsgBoxStyle.Critical,
                    Title:="IO Error")
        End Try

    End Sub

    Public Sub resetLog(Optional LogFileName As String = "",
                        Optional Logo As String() = Nothing,
                        Optional Clear As Boolean = True,
                        Optional ShowLogInNotepad As Boolean = False)

        Dim LogMsg As New List(Of String)
        Dim tempList As New List(Of String)


        Try

            If LogFileName = "" OrElse Not Directory.Exists(Path.GetDirectoryName(LogFileName)) Then

                If Not File.Exists(FileName) Then

                    With Now
                        LogFileName = Path.Combine(
                                path1:=Environment.CurrentDirectory,
                                path2:=My.Application.Info.ProductName & "_" &
                                        .Year.ToString &
                                        .Month.ToString("00") &
                                        .Day.ToString("00") &
                                        .Hour.ToString("00") &
                                        .Minute.ToString("00") & ".log")
                    End With


                Else
                    LogFileName = FileName
                End If

            End If

        Catch ex As Exception

            LogFileName = Path.Combine(
                                path1:=Environment.CurrentDirectory,
                                path2:="MajorError.log")

            LogMsg.AddRange(
                parseExceptionMsg(
                    Exception:=ex,
                    UserErrorDescription:="Major error getting log-filename"))

        End Try

        FileName = LogFileName


        If Clear Then
            LogList.Clear()
            Console.Clear()
        End If


        If Not IsNothing(Logo) Then
            LogMsg.AddRange(Logo)
        End If

        LogMsg.AddRange(getStartInfo())

        mylog(LogTxtArray:=LogMsg.ToArray)

        If ShowLogInNotepad Then log.showLogInNotepad()

    End Sub

#End Region

End Module
