﻿
Imports System.ComponentModel
Imports System.IO

Imports System.Text.RegularExpressions
Imports System.Text
Imports System.Xml.Serialization
Imports System.Web.Script.Serialization

Public Class PECgwResultMACRO

    Inherits PECgwResults

    Public Sub New()

    End Sub


    Public Shared Function getPECgwResults4MACRO(
                           startPath As String,
                           Optional searchOption As SearchOption = SearchOption.AllDirectories,
                           Optional searchPattern As String = "*.par") As PECgwResultMACRO

#Region "Definitions"

        Dim out As New PECgwResultMACRO
        Dim parFilePaths As String() = {}
        Dim parFile As String() = {}
        Dim index As Integer = -1
        Dim tempRow As String = String.Empty
        Dim tempRowArray As String() = {}
        Dim tempList As New List(Of String)
        Dim GrpCounter As Integer = 0
        Dim JobCounter As Integer = 0
        Dim parFileGrp As String() = {}
        Dim parFileJob As String() = {}

#End Region


        Const Space As Integer = 13

        mylog(LogTxt:="")
        mylog(LogTxt:="Start path".PadRight(Space) & startPath)
        mylog(LogTxt:="search str".PadRight(Space) & searchPattern)
        mylog(LogTxt:=" '' option".PadRight(Space) & searchOption.ToString)
        mylog(LogTxt:="")

        'get all par files, without input.par
        Try

            parFilePaths =
                Directory.GetFiles(
                    path:=startPath,
                    searchPattern:=searchPattern,
                    searchOption:=searchOption)

            parFilePaths =
                Filter(
                Source:=parFilePaths,
                Match:="input",
                Include:=False,
                Compare:=CompareMethod.Text)

            Array.Sort(parFilePaths)

            mylog(
           LogTxt:=
                   (parFilePaths.Count.ToString() & " " &
                   searchPattern).PadRight(Space) & "macro/metab par files found")

        Catch ex As Exception

            mylog(
            LogTxtArray:=parseExceptionMsg(
                Exception:=ex,
                UserErrorDescription:=
                    " *** ERROR : No " & searchPattern & " files found in" &
                    startPath & " in " & searchOption.ToString))

            Return Nothing

        End Try

        With out

            'get compound names
            tempRow = parFilePaths.First
            tempRow = Path.GetDirectoryName(tempRow)
            tempRowArray = Directory.GetFiles(path:=tempRow, searchPattern:="*.par", searchOption:=SearchOption.TopDirectoryOnly)

            tempRowArray =
                    Filter(
                    Source:=tempRowArray,
                    Match:="input",
                    Include:=False,
                    Compare:=CompareMethod.Text)



            Const searchCompound As String = "Compound :"
            Const searchModelVersion As String = "FOCUS Version"
            Dim binFilePath As String = ""

            Do While parFilePaths.Count > 0

                GrpCounter += 1

                parFileGrp =
                Filter(
                Source:=parFilePaths,
                Match:=out.filterGrp & GrpCounter.ToString(out.grpNumberFormat),
                Include:=True,
                Compare:=CompareMethod.Text)

                If parFileGrp.Count = 0 Then

                    mylog(
                    LogTxt:=
                    "No " & out.filterGrp & GrpCounter.ToString(out.grpNumberFormat) & " files found")

                    'all files are group 1
                    parFileGrp = parFilePaths

                Else

                    'delete grp files from total list
                    parFilePaths =
                    Filter(
                    Source:=parFilePaths,
                    Match:=out.filterGrp & GrpCounter.ToString(out.grpNumberFormat),
                    Include:=False,
                    Compare:=CompareMethod.Text)

                    mylog(
                    LogTxt:=
                        out.filterGrp & GrpCounter.ToString(out.grpNumberFormat) & " : " &
                        parFileGrp.Count.ToString() & " " &
                        searchPattern & " files found")

                End If

                .Compounds.Clear()


                With out

                    .Groups.Add(New group)

                    With .Groups(.Groups.Count - 1)

                        .GroupNo = GrpCounter

                        Do While parFileGrp.Count > 0

#Region "    get par files for job"

                            JobCounter += 1

                            'filter jobs from group
                            parFileJob =
                            Filter(
                            Source:=parFileGrp,
                            Match:=out.filterGap & JobCounter.ToString(out.GAPNumberFormat),
                            Include:=True,
                            Compare:=CompareMethod.Text)

                            If parFileJob.Count = 0 Then

                                mylog(
                            LogTxt:="No " & out.filterGap & JobCounter.ToString(out.GAPNumberFormat) & " files found")

                                If GrpCounter = 1 Then mylog(LogTxt:="Try to use one group with different 'Cropxxx' as search string")

                                parFileJob =
                            Filter(
                            Source:=parFileGrp,
                            Match:=out.filterCrop & JobCounter.ToString(out.cropNumberFormat),
                            Include:=True,
                            Compare:=CompareMethod.Text)


                                'delete crop files from group list
                                parFileGrp =
                            Filter(
                            Source:=parFileGrp,
                            Match:=out.filterCrop & JobCounter.ToString(out.cropNumberFormat),
                            Include:=False,
                            Compare:=CompareMethod.Text)

                                parFilePaths = parFileGrp

                            Else

                                'delete job files from group list
                                parFileGrp =
                            Filter(
                            Source:=parFileGrp,
                            Match:=out.filterGap & JobCounter.ToString(out.GAPNumberFormat),
                            Include:=False,
                            Compare:=CompareMethod.Text)

                            End If

#End Region


                        Loop

                    End With
                End With

                For Each member As String In tempRowArray

                    parFile = File.ReadAllLines(member)

                    tempRow = Array.Find(array:=parFile, match:=Function(x) x.StartsWith(searchCompound))
                    tempRow = Trim(tempRow.Split(":").Last)

                    If Not .Compounds.Contains(tempRow) Then

                        .Compounds.Add(tempRow)

                        binFilePath =
                                        Path.Combine(
                                            path1:=Path.GetDirectoryName(member),
                                            path2:="MACRO" &
                                                getMACROrunID(binFilePath:=member).ToString("000"))
                        getPECsFromMACRObin(binFilePath:=binFilePath, writeDAT:=True)



                    End If

                Next





                parFilePaths =
                       Filter(
                           Source:=parFilePaths,
                           Match:=Path.GetDirectoryName(parFilePaths.First),
                           Include:=False,
                           Compare:=CompareMethod.Text)

            Loop
        End With

    End Function


#Region "    MACRO"

#Region "    ID from par or bin file"

    Public Shared Function getMACROrunID(parFile As String(), Optional searchString As String = "RUNID") As Integer

        Dim index As Integer = -1

        index =
            Array.FindIndex(
            array:=parFile,
            match:=Function(x) x.StartsWith(searchString))

        If index = -1 Then
            Return -1
        Else
            Return CInt(Trim(parFile(index).Split(vbTab).Last))
        End If

    End Function

    Public Shared Function getMACROrunID(binFilePath As String, Optional digits As Integer = 3) As Integer

        Dim temp As String

        temp = Path.GetFileNameWithoutExtension(binFilePath)

        Try
            Return _
                temp.Substring(
                        startIndex:=temp.Length - digits,
                        length:=digits)

        Catch ex As Exception
            Return -1
        End Try

    End Function

#End Region

#Region "    runtime in years"

    Public Shared Function getRunTimeYears(parFile As String(),
                            Optional searchRunTime As String = "DRIVINGPERIOD") As Integer


        Dim index As Integer = -1
        Dim row As String()

        Try

            index =
                Array.FindIndex(
                    array:=parFile,
                    match:=Function(x) x.Contains(searchRunTime))

            If index <> -1 Then

                row = parFile(index).Split("-")

                If row.Count = 2 Then
                    row(0) = row(0).Split("/").Last
                    row(1) = row(1).Split("/").Last
                    Return CInt(row(1)) - CInt(row(0))

                ElseIf row.Count = 6 Then
                    Return CInt(row.Last) - CInt(row(2))
                End If

            Else

                Throw New ArgumentException(
                    message:="Can't find " & searchRunTime)

            End If

        Catch ex As Exception

            Throw New ArgumentException(
                message:="Can't get " & searchRunTime,
                innerException:=ex)

        End Try

    End Function

    Public Shared Function getRunTimeYears(rows As List(Of row)) As Integer
        Try

            If rows.Count < 2 Then
                Throw New ArgumentException(
                    message:="Only " &
                    rows.Count & " rows?")
            End If

            Return _
                rows.Last.myDate.Year -
                rows.First.myDate.Year

        Catch ex As Exception
            Throw New ArgumentException(
                message:="Error getting runtime in years from rows",
                innerException:=ex)
        End Try

    End Function

#End Region

    Public Enum eMACROFiles
        et
        p
        driving
    End Enum

    Public Shared Function get_set_MACROFiles(ByRef parFile As String(), fileType As eMACROFiles,
                                    Optional newValue As String = Nothing,
                                    Optional searchET As String = "METFILE",
                                    Optional searchP As String = "RAINFALLFILE",
                                    Optional searchDrive As String = "DRIVINGFILE") As String

        Dim index As Integer = -1
        Dim search As String = ""
        Dim MACROFile As String

        Select Case fileType

            Case eMACROFiles.et
                search = searchET
            Case eMACROFiles.p
                search = searchP
            Case eMACROFiles.driving
                search = searchDrive

        End Select

        Try

            index = Array.FindIndex(
                array:=parFile,
                match:=Function(x) x.StartsWith(search))

            If index = -1 Then
                Throw New ArgumentException(message:="Can't find " & search)
            End If

            MACROFile = Trim(parFile(index).Split(vbTab).Last)

            If Not IsNothing(newValue) Then
                parFile(index) = search & vbTab & newValue
            End If

            Return MACROFile

        Catch ex As Exception
            Throw New ArgumentException(
                message:="Can't get " & search,
                innerException:=ex)
        End Try

    End Function

    Public Shared dat As New List(Of String)
    Public Shared csv As New List(Of String)

    Public Shared Function getPECsFromMACRObin(
                binFilePath As String,
                Optional periodLength As Integer = -1,
                Optional writeDAT As Boolean = False,
                Optional writeCSV As Boolean = False) As Double()



        Dim yearPECs As New List(Of Double)

        Dim SFLOW As Integer = -9999
        Dim SFLOWOUT As Integer = -9999
        Dim WOUT As Integer = -9999
        Dim WFLOWOUT As Integer = -9999

        Dim runID As String


        runID = getMACROrunID(binFilePath)

        readMACROBin(binFilePath:=binFilePath)

        If cols.Count < 3 OrElse rows.Count < 300 Then

            Throw New ArgumentException(
                message:=
                "No data in" & vbCrLf &
                binFilePath & vbCrLf &
                "  Columns :" & cols.Count & vbCrLf &
                "  Rows : " & rows.Count)

        End If

        'get column numbers
        For counter As Integer = 0 To cols.Count - 1

            Select Case cols(counter).Name

                Case "SFLOW"
                    SFLOW = counter - 1

                Case "SFLOWOUT"
                    SFLOWOUT = counter - 1

                Case "WOUT"
                    WOUT = counter - 1

                Case "WFLOWOUT"
                    WFLOWOUT = counter - 1

            End Select

        Next

        If SFLOW + SFLOWOUT + WFLOWOUT + WOUT < 1 Then
            Throw New IOException(message:="Data missing in bin file")
        End If

        Dim mydate As Integer = rows.First.myDate.Year

        Dim sumSolute As Single = 0
        Dim sumWater As Single = 0

        For i As Integer = 0 To rows.Count - 2

            Try

                If rows(i + 1).myDate.Year - mydate = periodLength Then

                    mydate = rows(i + 1).myDate.Year

                    sumSolute += (rows(i)(SFLOW) + rows(i)(SFLOWOUT)) * 24
                    sumWater += (rows(i)(WOUT) + rows(i)(WFLOWOUT)) * 24

                    ' no water => pec = 0 
                    If sumWater <= 0 Then
                        yearPECs.Add(0)
                    Else
                        yearPECs.Add(sumSolute / sumWater * 1000)
                    End If

                    sumSolute = 0
                    sumWater = 0

                Else

                    sumSolute += (rows(i)(SFLOW) + rows(i)(SFLOWOUT)) * 24
                    sumWater += (rows(i)(WOUT) + rows(i)(WFLOWOUT)) * 24

                End If

                csv.Add(
                    rows(i)(SFLOW) & "," & rows(i)(SFLOWOUT) & "," &
                    rows(i)(WOUT) & "," & rows(i)(WFLOWOUT))

            Catch ex As Exception
                Console.WriteLine(ex.Message)
            End Try

        Next

        'last year
        csv.Add(
            rows(rows.Count - 1)(SFLOW) & "," & rows(rows.Count - 1)(SFLOWOUT) & "," &
            rows(rows.Count - 1)(WOUT) & "," & rows(rows.Count - 1)(WFLOWOUT))

        sumSolute += (rows(rows.Count - 1)(SFLOW) + rows(rows.Count - 1)(SFLOWOUT)) * 24
        sumWater += (rows(rows.Count - 1)(WOUT) + rows(rows.Count - 1)(WFLOWOUT)) * 24

        ' no water => pec = 0 
        If sumWater <= 0 Then
            yearPECs.Add(0)
        Else
            yearPECs.Add(sumSolute / sumWater * 1000)
        End If


        If writeCSV Then

            Try
                File.WriteAllLines(
                    path:=
                        Path.Combine(
                            path1:=Path.GetDirectoryName(binFilePath),
                            path2:="conc" & runID & ".csv"),
                    contents:=csv.ToArray)
            Catch ex As Exception
                Throw New IOException(
                    message:=
                        "Can't write csv file from MACRO results" & vbCrLf &
                        "Bin file : " & binFilePath,
                    innerException:=ex)
            End Try

        End If

        If writeDAT Then

            Try

                csv.Clear()
                csv.Add("Period        Av_FluxConc_at_reporting_depth")

                For counter As Integer = 1 To yearPECs.Count

                    csv.Add(" " &
                        counter.ToString("0").PadRight("Period        ".Length).PadRight(2) &
                        yearPECs(counter - 1))

                Next

                File.WriteAllLines(
                    path:=Path.Combine(Path.GetDirectoryName(binFilePath), "conc" & runID & ".dat"),
                    contents:=csv.ToArray)

            Catch ex As Exception
                Throw New IOException(
                    message:=
                        "Can't write std. MACRO *.dat file from results" & vbCrLf &
                        "Bin file : " & binFilePath,
                    innerException:=ex)
            End Try

        End If

        Return yearPECs.ToArray

    End Function


#Region "    read macro*.bin to cols and rows"

#Region "    definition of rows and columns"

    ''' <summary>
    ''' Index, name and label
    ''' </summary>
    <DebuggerStepThrough>
    Public Class column

        Public ReadOnly Index As Integer
        Public ReadOnly Name As String
        Public ReadOnly Label As String

        Public Sub New(
                    ByVal index As Integer,
                    ByVal name As String,
                    ByVal label As String)

            Me.Index = index
            Me.Name = name
            Me.Label = label

        End Sub

    End Class

    ''' <summary>
    ''' Date and value
    ''' </summary>
    <DebuggerStepThrough>
    Public Class row

        Public myDate As DateTime
        Public Values As Single()

        Default Public ReadOnly Property Item(ByVal i As Integer) As Single
            Get
                Return Values(i)
            End Get
        End Property

    End Class

#End Region

    ''' <summary>
    ''' Index, name and label
    ''' </summary>
    Public Shared cols As New List(Of column)

    ''' <summary>
    ''' Date and value
    ''' </summary>
    Public Shared rows As New List(Of row)


    ''' <summary>
    ''' Read macro*.bin to cols and rows
    ''' </summary>
    ''' <param name="binFilePath">
    ''' Path to the MACRO bin file
    ''' </param>
    Public Shared Sub readMACROBin(binFilePath As String)

#Region "    Definitions reading stream"

        Dim inputStream As Stream = Nothing
        Dim binReader As BinaryReader = Nothing
        Dim recordNo As Integer
        Dim recordLength As Integer
        Dim varNo As Integer
        Dim hdrPos As Integer

        Dim entry As String
        Dim label As String
        Dim name As String
        Dim m As Match

        Dim row As row
        Dim julDate As Integer

        cols.Clear()
        rows.Clear()

#End Region

#Region "    Reading bin file"

        'open stream
        Try

            If Not binFilePath.Contains("\") Then

                binFilePath =
                    Path.Combine(
                    path1:=Environment.CurrentDirectory,
                    path2:=binFilePath)

            End If

            mylog(LogTxt:="Open stream to " & binFilePath)

            inputStream =
                       File.Open(
                           path:=binFilePath,
                           mode:=FileMode.Open,
                           access:=FileAccess.Read,
                           share:=FileShare.Read)

            mylog(LogTxt:=" ... OK", Add2PreviousRow:=True)

        Catch ex As Exception
            mylog(
                LogTxtArray:=parseExceptionMsg(
                    Exception:=ex,
                    UserErrorDescription:=
                    "Error opening stream to " & vbCrLf & binFilePath))

        End Try

        'create reader
        Try

            mylog(LogTxt:="starting binary reader")

            binReader =
                    New BinaryReader(
                        input:=inputStream,
                        encoding:=Encoding.ASCII,
                        leaveOpen:=False)

            mylog(LogTxt:=" ... OK", Add2PreviousRow:=True)

        Catch ex As Exception
            mylog(
               LogTxtArray:=parseExceptionMsg(
                   Exception:=ex,
                   UserErrorDescription:=
                   "Error opening reader to " & vbCrLf & binFilePath))

        End Try

        'init
        Try

            mylog(LogTxt:="init")

            recordNo = binReader.ReadInt32()
            recordLength = binReader.ReadInt32()

            varNo = recordLength / 4
            hdrPos = (recordNo + 1) * recordLength

            inputStream.Seek(hdrPos, SeekOrigin.Begin)
            cols.Add(New column(0, "Date", "Date"))

            mylog(LogTxt:=" ... OK", Add2PreviousRow:=True)

        Catch ex As Exception
            mylog(
              LogTxtArray:=parseExceptionMsg(
                  Exception:=ex,
                  UserErrorDescription:="Error init stream"))

        End Try

        'get columns and their header
        Try

            For i As Integer = 1 To varNo - 1

                entry =
                    New String(binReader.ReadChars(60))

                label =
                    entry.Substring(0, 52).Trim()

                name = label.Split(
                    separator:={" "},
                    options:=StringSplitOptions.RemoveEmptyEntries).First

                m = Regex.Match(label, "^(\S+(\s\S+)*\S*)")

                If m.Success Then
                    name = m.Groups(1).Value.Trim
                End If

                cols.Add(New column(i - 1, name, label))

            Next

        Catch ex As Exception

            mylog(
             LogTxtArray:=parseExceptionMsg(
                 Exception:=ex,
                 UserErrorDescription:="Error getting column info"))

        End Try

        'get rows
        Try

            inputStream.Seek(recordLength, SeekOrigin.Begin)

            For i As Integer = 1 To recordNo

                row = New row()
                julDate = binReader.ReadInt32()

                row.myDate =
                    New DateTime(1, 1, 1, 0, 0, 0).AddMinutes(julDate - 2 * 24 * 60)
                row.Values =
                    New Single(cols.Count - 1 - 1) {}

                For j As Integer = 1 To varNo - 1
                    row.Values(j - 1) = binReader.ReadSingle()
                Next

                rows.Add(row)

            Next

            With rows
                mylog(
                LogTxt:= .Count & " rows from " &
                        .First.myDate.ToShortDateString & " to " &
                        .Last.myDate.ToShortDateString)
            End With

        Catch ex As Exception

            mylog(
            LogTxtArray:=parseExceptionMsg(
                Exception:=ex,
                UserErrorDescription:="Error getting row info"))

        End Try

        'closing 
        Try

            With binReader
                .Close()
                .Dispose()
            End With

        Catch ex As Exception
            mylog(
                LogTxtArray:=parseExceptionMsg(
                    Exception:=ex,
                    UserErrorDescription:="Error closing the reader "))
        End Try

#End Region

    End Sub

#End Region


#End Region


End Class


Public Class PECgwResultPEARL

    Inherits PECgwResults

    Public Sub New()

    End Sub

    Public Shared Function getPECgwResults4PEARL(
                            startPath As String,
                            Optional searchOption As SearchOption = SearchOption.AllDirectories,
                            Optional searchPattern As String = "*.sum") As PECgwResultPEARL

#Region "Definitions"

        Dim out As New PECgwResultPEARL
        Dim sumFilePaths As String() = {}
        Dim sumFile As String() = {}
        Dim index As Integer = -1
        Dim tempRow As String = String.Empty
        Dim tempRowArray As String() = {}
        Dim tempList As New List(Of String)
        Dim GrpCounter As Integer = 0
        Dim JobCounter As Integer = 0
        Dim sumFileGrp As String() = {}
        Dim sumFileJob As String() = {}

#End Region


        Const Space As Integer = 13

        mylog(LogTxt:="")
        mylog(LogTxt:="Start path".PadRight(Space) & startPath)
        mylog(LogTxt:="search str".PadRight(Space) & searchPattern)
        mylog(LogTxt:=" '' option".PadRight(Space) & searchOption.ToString)
        mylog(LogTxt:="")

        'get all sum files, but not macro.sum
        Try

            sumFilePaths =
                Directory.GetFiles(
                    path:=startPath,
                    searchPattern:=searchPattern,
                    searchOption:=searchOption)

            sumFilePaths =
                Filter(
                Source:=sumFilePaths,
                Match:="MACRO",
                Include:=False,
                Compare:=CompareMethod.Text)

            mylog(
           LogTxt:=
                   (sumFilePaths.Count.ToString() & " " &
                   searchPattern).PadRight(Space) & "PEARL files found")

        Catch ex As Exception

            mylog(
            LogTxtArray:=parseExceptionMsg(
                Exception:=ex,
                UserErrorDescription:=
                    " *** ERROR : No " & searchPattern & " files found in" &
                    startPath & " in " & searchOption.ToString))

            Return Nothing

        End Try

        If sumFilePaths.Count = 0 Then
            Return Nothing
        End If

        'read 1st sum file 2 array
        Try

            sumFile =
                File.ReadAllLines(
                path:=sumFilePaths.First)

        Catch ex As Exception

            mylog(
                    LogTxtArray:=parseExceptionMsg(
                        Exception:=ex,
                        UserErrorDescription:=
                            "Can't read from " & sumFilePaths.First))
            Return Nothing

        End Try

        'model + version

        With out

            'model + version
            index = Array.FindIndex(array:=sumFile, Function(s) s.Contains(searchModelVersion))

            If index = -1 Then
                mylog(LogTxt:="Can't get version and model info out of " & sumFilePaths.First & vbCrLf &
                                                    "Continue anyway")
            Else

                Try

                    '* PEARL was called from      : FOCUSPEARL,version x.x.x
                    .version = sumFile(index).Split.Last
                    .model = Trim(sumFile(index).Split(":").Last.Split(",").First)

                Catch ex As Exception

                    mylog(
                        LogTxtArray:=parseExceptionMsg(
                        Exception:=ex,
                        UserErrorDescription:=
                        "Can't get version and model info out of " & sumFilePaths.First))

                    Return Nothing

                End Try

                mylog(LogTxt:="Model".PadRight(Space) & .model & " version " & .version)

            End If

            'percentile type, std. = 80th
            index = Array.FindIndex(array:=sumFile, Function(s) s.Contains(searchPercentileType))

            If index = -1 Then
                mylog(LogTxt:="Can't get percentile type info out of " & sumFilePaths.First & vbCrLf &
                                                   "Continue anyway")
            Else

                Try

                    '* Result_text         Concentration closest to the 80th percentile (ug/L)
                    tempRowArray = sumFile(index).Split(separator:={" "c}, options:=StringSplitOptions.RemoveEmptyEntries)
                    tempRowArray = Filter(Source:=tempRowArray, Match:="th", Include:=True, Compare:=CompareMethod.Text)

                    .PercentileType = Replace(Expression:=tempRowArray.Last, Find:="th", Replacement:="", Compare:=CompareMethod.Text)

                Catch ex As Exception

                    mylog(
                    LogTxtArray:=parseExceptionMsg(
                        Exception:=ex,
                        UserErrorDescription:=
                            "Can't get percentile type info out of " & sumFilePaths.First))
                    Return Nothing

                End Try

            End If

            mylog(LogTxt:="Percentile".PadRight(Space) & .PercentileType)

            tempRowArray =
                Filter(
                Source:=sumFile,
                Match:=searchCompoundsPercentiles,
                Include:=True,
                Compare:=CompareMethod.Text)

            tempRowArray =
                Filter(
                Source:=tempRowArray,
                Match:="concentration",
                Include:=False,
                Compare:=CompareMethod.Text)

            For compoundCounter As Integer = 0 To tempRowArray.Count - 1

                tempList.Clear()
                tempList.AddRange(tempRowArray(compoundCounter).Split(separator:={" "c}, options:=StringSplitOptions.RemoveEmptyEntries))
                tempRow = tempList(1)
                tempList.Clear()
                tempList.AddRange(tempRow.Split("_"))
                tempList.RemoveAt(0)


                tempRow = Join(tempList.ToArray, "_")

                If tempRow.Length > out.compoundNameLenght Then
                    tempRow = tempRow.Substring(0, out.compoundNameLenght)
                Else
                    tempRow = tempRow.PadRight(out.compoundNameLenght + 3)
                End If

                out.Compounds.Add(
                    tempRow)

            Next

            mylog(
                LogTxt:="Compounds".PadRight(Space) &
                Join(
                    SourceArray:=out.Compounds.ToArray,
                    Delimiter:=", "))

        End With

        mylog(LogTxt:="")

        Do While sumFilePaths.Count > 0

            GrpCounter += 1

            sumFileGrp =
                Filter(
                Source:=sumFilePaths,
                Match:=out.filterGrp & GrpCounter.ToString(out.grpNumberFormat),
                Include:=True,
                Compare:=CompareMethod.Text)

            If sumFileGrp.Count = 0 Then

                mylog(
                    LogTxt:=
                    "No " & out.filterGrp & GrpCounter.ToString(out.grpNumberFormat) & " files found")

                out.cropFilter = True

                'all files are group 1
                sumFileGrp = sumFilePaths

            Else

                out.cropFilter = False

                'delete grp files from total list
                sumFilePaths =
                    Filter(
                    Source:=sumFilePaths,
                    Match:=out.filterGrp & GrpCounter.ToString(out.grpNumberFormat),
                    Include:=False,
                    Compare:=CompareMethod.Text)

                mylog(
                    LogTxt:=
                        out.filterGrp & GrpCounter.ToString(out.grpNumberFormat) & " : " &
                        sumFileGrp.Count.ToString() & " " &
                        searchPattern & " files found")

            End If

            With out

                .Groups.Add(New group)

                With .Groups(.Groups.Count - 1)

                    .GroupNo = GrpCounter

                    Do While sumFileGrp.Count > 0

#Region "    get sum files for job"

                        JobCounter += 1

                        'filter jobs from group
                        sumFileJob =
                            Filter(
                            Source:=sumFileGrp,
                            Match:=out.filterGap & JobCounter.ToString(out.GAPNumberFormat),
                            Include:=True,
                            Compare:=CompareMethod.Text)

                        If sumFileJob.Count = 0 Then

                            mylog(
                            LogTxt:="No " & out.filterGap & JobCounter.ToString(out.GAPNumberFormat) & " files found")

                            If GrpCounter = 1 Then mylog(LogTxt:="Try to use one group with different 'Cropxxx' as search string")

                            sumFileJob =
                            Filter(
                            Source:=sumFileGrp,
                            Match:=out.filterCrop & JobCounter.ToString(out.cropNumberFormat),
                            Include:=True,
                            Compare:=CompareMethod.Text)


                            'delete crop files from group list
                            sumFileGrp =
                            Filter(
                            Source:=sumFileGrp,
                            Match:=out.filterCrop & JobCounter.ToString(out.cropNumberFormat),
                            Include:=False,
                            Compare:=CompareMethod.Text)

                            sumFilePaths = sumFileGrp

                        Else

                            'delete job files from group list
                            sumFileGrp =
                            Filter(
                            Source:=sumFileGrp,
                            Match:=out.filterGap & JobCounter.ToString(out.GAPNumberFormat),
                            Include:=False,
                            Compare:=CompareMethod.Text)

                        End If

#End Region

                        .Gaps.Add(New gap)

                        With .Gaps(.Gaps.Count - 1)

                            .GapNo = JobCounter

                            For Each sumFilePath As String In sumFileJob

                                'read sum file 2 array
                                Try

                                    sumFile = File.ReadAllLines(path:=sumFilePath)

                                Catch ex As Exception

                                    mylog(
                                    LogTxtArray:=parseExceptionMsg(
                                        Exception:=ex,
                                        UserErrorDescription:=
                                            "Can't read from " & sumFilePath))
                                    Return Nothing

                                End Try

                                'crop
                                If sumFilePath = sumFileJob.First Then

                                    'crop
                                    index = Array.FindIndex(array:=sumFile, Function(s) s.Contains(searchCrop))

                                    If index = True Then
                                        mylog(LogTxt:="Can't get crop info out of " & sumFilePath & vbCrLf &
                                              "Continue anyway")
                                    Else

                                        Try

                                            '* Crop calendar      : CHAT-SCEREALS
                                            .Crop = Trim(sumFile(index).Split(":").Last.Split("-").Last)

                                        Catch ex As Exception

                                            mylog(
                                                LogTxtArray:=parseExceptionMsg(
                                                    Exception:=ex,
                                                    UserErrorDescription:=
                                                        "Can't get crop info out of " & sumFilePath))
                                            Return Nothing

                                        End Try

                                        mylog(
                                        LogTxt:=out.filterGap & JobCounter.ToString(out.GAPNumberFormat) & " " & .Crop & " : " &
                                          sumFileJob.Count.ToString() & " " &
                                          searchPattern & " files found")

                                    End If

                                End If


                                .Runs.Add(New run)

                                With .Runs(.Runs.Count - 1)

                                    'scenario
                                    index = Array.FindIndex(array:=sumFile, Function(s) s.Contains(searchScenario))

                                    If index = -1 Then
                                        mylog(LogTxt:="Can't get scenario out of " & sumFilePath & vbCrLf &
                                              "Continue anyway")
                                    Else

                                        Try

                                            '* Crop calendar      : CHAT-SCEREALS
                                            .Scenario = Trim(sumFile(index).Split(":").Last).ToUpper.Substring(0, 4)

                                        Catch ex As Exception

                                            mylog(
                                                LogTxtArray:=parseExceptionMsg(
                                                    Exception:=ex,
                                                    UserErrorDescription:=
                                                        "Can't get scenario out of " & sumFilePath))
                                            Return Nothing

                                        End Try

                                        mylog(LogTxt:= .Scenario.PadRight(Space) &
                                              Replace(Expression:=sumFilePath, Find:=startPath, Replacement:=""))

                                    End If

                                    tempRowArray =
                                        Filter(
                                        Source:=sumFile,
                                        Match:=searchCompoundsPercentiles,
                                        Include:=True,
                                        Compare:=CompareMethod.Text)

                                    tempRowArray =
                                        Filter(
                                        Source:=tempRowArray,
                                        Match:="concentration",
                                        Include:=False,
                                        Compare:=CompareMethod.Text)

                                    If tempRowArray.Count = 0 Then

                                        mylog(LogTxt:="No " & searchCompoundsPercentiles & " found in " & sumFilePath)
                                        Return Nothing

                                    End If

                                    For compoundCounter As Integer = 0 To out.Compounds.Count - 1

                                        .Results.Add(New result)

                                        Dim statsPEC As New List(Of Double)

                                        With .Results(.Results.Count - 1)

                                            .Compound = out.Compounds(compoundCounter)
                                            .Percentile = Double.Parse(Trim(tempRowArray(compoundCounter).Split.Last))

                                            Dim PECarray As String() = {}

                                            PECarray =
                                                Filter(
                                                Source:=sumFile,
                                                Match:="Target_" & Trim(.Compound),
                                                Include:=True,
                                                Compare:=CompareMethod.Text)

                                            mylog(LogTxt:= .Compound.PadRight(Space))


                                            If PECarray.Count <> 20 Then
                                                Console.WriteLine("Sum file broken?")
                                                Console.WriteLine(sumFilePath)
                                            End If

                                            statsPEC.Clear()

                                            For Each result As String In PECarray

                                                .PECs.Add(New PEC)

                                                mylog(LogTxt:=".", Add2PreviousRow:=True)

                                                With .PECs(.PECs.Count - 1)

                                                    .year = Integer.Parse(result.Split.First)
                                                    .PEC = Double.Parse(result.Split.Last)

                                                    statsPEC.Add(.PEC)

                                                End With

                                            Next

                                            With .Statistic
                                                .data = statsPEC.ToArray
                                                .Analyze()
                                            End With

                                            mylog(
                                                LogTxt:=" " & out.PercentileType & " perc. : " &
                                                        .Percentile.ToString.PadRight(9) & "µg/L",
                                                Add2PreviousRow:=True)

                                        End With

                                    Next

                                End With

                            Next

                        End With

                    Loop

                End With

            End With

        Loop

        Return out

    End Function

    Public Const searchModelVersion As String = "PEARL was called from"

    Public Const searchCompoundsPercentiles As String = "* Result_"

    Public Const searchPercentileType As String = "* Result_text"


    Public Const searchCrop As String = "* Crop calendar"
    Public Const searchScenario As String = "* Location"

End Class

Public Class PECgwResultPELMO

    Inherits PECgwResults

    Public Sub New()

    End Sub

    Public Shared Function getPECgwResults4PELMO(
                            startPath As String,
                            Optional searchOption As SearchOption = SearchOption.AllDirectories,
                            Optional searchPattern As String = "period.plm") As PECgwResultPELMO

#Region "Definitions"

        Dim out As New PECgwResultPELMO
        Dim plmFilePaths As String() = {}
        Dim plmFile As String() = {}
        Dim index As Integer = -1
        Dim tempRow As String = String.Empty
        Dim tempRowArray As String() = {}
        Dim GrpCounter As Integer = 0
        Dim JobCounter As Integer = 0
        Dim plmFileGrp As String() = {}
        Dim plmFileJob As String() = {}
        Dim posPELMO As String = ""
#End Region


        Const Space As Integer = 15

        mylog(LogTxt:="")
        mylog(LogTxt:="Start path".PadRight(Space) & startPath)
        mylog(LogTxt:="search str".PadRight(Space) & searchPattern)
        mylog(LogTxt:=" '' option".PadRight(Space) & searchOption.ToString)
        mylog(LogTxt:="")

        'get all period.plm files
        Try

            plmFilePaths =
                Directory.GetFiles(
                    path:=startPath,
                    searchPattern:=searchPattern,
                    searchOption:=searchOption)

            mylog(
           LogTxt:=
                   (plmFilePaths.Count.ToString() & " " &
                   searchPattern).PadRight(Space) & "PELMO files found")

        Catch ex As Exception

            mylog(
            LogTxtArray:=parseExceptionMsg(
                Exception:=ex,
                UserErrorDescription:=
                    " *** ERROR : No " & searchPattern & " files found in" &
                    startPath & " in " & searchOption.ToString))

            Return Nothing

        End Try

        If plmFilePaths.Count = 0 Then Return Nothing

        'read 1st plm file 2 array
        Try

            plmFile =
                File.ReadAllLines(
                path:=plmFilePaths.First, encoding:=Text.Encoding.ASCII)

        Catch ex As Exception

            mylog(
                    LogTxtArray:=parseExceptionMsg(
                        Exception:=ex,
                        UserErrorDescription:=
                            "Can't read from " & plmFilePaths.First))
            Return Nothing

        End Try

        'model + version

        With out

            'model + version
            index = 0

            Try

                '*** FOCUSPELMO  5. 5. 3 *** (PELMO 4.01  )
                '*** FOCUS PELMO  6. 6. 4 *** (PELMO 5.0)
                tempRow = plmFile(index)
                index = tempRow.IndexOf(value:="PELMO")

                tempRow =
                    tempRow.Substring(
                    startIndex:=index,
                    length:=tempRow.IndexOf(value:="*", startIndex:=index) - index)

                tempRow = Trim(tempRow)
                .model = "FOCUS" & tempRow.Split.First

                index = tempRow.IndexOf(value:="PELMO") + 5
                tempRow =
                    Trim(tempRow.Substring(startIndex:=index, length:=tempRow.Length - index))

                tempRow = Replace(
                        Expression:=tempRow,
                        Find:=(" "),
                        Replacement:="",
                        Compare:=CompareMethod.Text)
                .version = tempRow

            Catch ex As Exception

                mylog(
                    LogTxtArray:=parseExceptionMsg(
                    Exception:=ex,
                    UserErrorDescription:=
                    "Can't get version and model info out of " & plmFilePaths.First))

                Return Nothing

            End Try

            mylog(LogTxt:="Model".PadRight(Space) & .model & " version " & .version)


            'percentile type, std. = 80th
            index = Array.FindIndex(array:=plmFile, Function(s) s.Contains(searchPercentileType))

            If index = -1 Then
                mylog(LogTxt:="Can't get percentile type info out of " & plmFilePaths.First & vbCrLf &
                                                   "Continue anyway")
            Else

                Try

                    '	80 Perc.(4/5)	    0.00E+00	     654.500	0.000
                    .PercentileType =
                        plmFile(index).Split(
                            separator:={" "c},
                            options:=StringSplitOptions.RemoveEmptyEntries).First.Trim(vbTab)


                Catch ex As Exception

                    mylog(
                        LogTxtArray:=parseExceptionMsg(
                            Exception:=ex,
                            UserErrorDescription:=
                                "Can't get percentile type info out of " & plmFilePaths.First))
                    Return Nothing

                End Try

            End If

            mylog(LogTxt:="Percentile".PadRight(Space) & .PercentileType & "th")

            tempRowArray =
                Filter(
                Source:=plmFile,
                Match:=searchCompoundNames,
                Include:=True,
                Compare:=CompareMethod.Text)

            'compound names
            For compoundCounter As Integer = 0 To tempRowArray.Count - 1

                tempRow = tempRowArray(compoundCounter)

                If tempRow.Contains("ACTIVE SUBSTANCE") Then
                    posPELMO = " AS"
                Else
                    posPELMO = tempRow.Split("(").First
                    posPELMO = " " & Trim(posPELMO).Split.Last
                End If

                tempRow = Trim(tempRowArray(compoundCounter).Split("(").Last.Split(")").First)

                If tempRow.Length > out.compoundNameLenght Then
                    tempRow = tempRow.Substring(0, out.compoundNameLenght)
                Else
                    tempRow = tempRow.PadRight(out.compoundNameLenght)
                End If

                out.Compounds.Add(
                    tempRow &
                    posPELMO)

            Next

            mylog(
                LogTxt:="Compounds".PadRight(Space) &
                Join(
                    SourceArray:=out.Compounds.ToArray,
                    Delimiter:=", "))

        End With

        mylog(LogTxt:="")

        Do While plmFilePaths.Count > 0

            GrpCounter += 1

            plmFileGrp =
                Filter(
                Source:=plmFilePaths,
                Match:=out.filterGrp & GrpCounter.ToString(out.grpNumberFormat),
                Include:=True,
                Compare:=CompareMethod.Text)

            If plmFileGrp.Count = 0 Then

                mylog(
                    LogTxt:=
                    "No " & out.filterGrp & GrpCounter.ToString(out.grpNumberFormat) & " files found")

                out.cropFilter = True

                'all files are group 1
                plmFileGrp = plmFilePaths

            Else

                out.cropFilter = False

                'delete grp files from total list
                plmFilePaths =
                    Filter(
                    Source:=plmFilePaths,
                    Match:=out.filterGrp & GrpCounter.ToString(out.grpNumberFormat),
                    Include:=False,
                    Compare:=CompareMethod.Text)

                mylog(
                    LogTxt:=
                        out.filterGrp & GrpCounter.ToString(out.grpNumberFormat) & " : " &
                        plmFileGrp.Count.ToString() & " " &
                        searchPattern & " files found")

            End If

            With out

                .Groups.Add(New group)

                With .Groups(.Groups.Count - 1)

                    .GroupNo = GrpCounter

                    Do While plmFileGrp.Count > 0

#Region "    get period.plm files for job"

                        JobCounter += 1

                        'filter jobs from group
                        plmFileJob =
                            Filter(
                            Source:=plmFileGrp,
                            Match:=out.filterGap & JobCounter.ToString(out.GAPNumberFormat),
                            Include:=True,
                            Compare:=CompareMethod.Text)

                        If plmFileJob.Count = 0 Then

                            mylog(
                            LogTxt:="No " & out.filterGap & JobCounter.ToString(out.GAPNumberFormat) & " files found")

                            If GrpCounter = 1 Then mylog(LogTxt:="Try to use one group with different 'Cropxxx' as search string")

                            plmFileJob =
                            Filter(
                            Source:=plmFileGrp,
                            Match:=out.filterCrop & JobCounter.ToString(out.cropNumberFormat),
                            Include:=True,
                            Compare:=CompareMethod.Text)


                            'delete crop files from group list
                            plmFileGrp =
                            Filter(
                            Source:=plmFileGrp,
                            Match:=out.filterCrop & JobCounter.ToString(out.cropNumberFormat),
                            Include:=False,
                            Compare:=CompareMethod.Text)

                            plmFilePaths = plmFileGrp

                        Else

                            'delete job files from group list
                            plmFileGrp =
                            Filter(
                            Source:=plmFileGrp,
                            Match:=out.filterGap & JobCounter.ToString(out.GAPNumberFormat),
                            Include:=False,
                            Compare:=CompareMethod.Text)

                        End If

#End Region

                        .Gaps.Add(New gap)

                        With .Gaps(.Gaps.Count - 1)

                            .GapNo = JobCounter

                            For Each plmFilePath As String In plmFileJob

                                'read plm file 2 array
                                Try

                                    plmFile = File.ReadAllLines(path:=plmFilePath, encoding:=Text.Encoding.ASCII)

                                Catch ex As Exception

                                    mylog(
                                    LogTxtArray:=parseExceptionMsg(
                                        Exception:=ex,
                                        UserErrorDescription:=
                                            "Can't read from " & plmFilePath))
                                    Return Nothing

                                End Try

                                Select Case out.version
                                    Case "5.5.3"
                                        index = 1

                                    Case "6.6.4"
                                        index = 2

                                    Case Else
                                        index = -1
                                End Select

                                'crop
                                If plmFilePath = plmFileJob.First Then

                                    If index = -1 Then
                                        mylog(LogTxt:="Unknown PELMO version, can't get crop info")
                                    Else
                                        Try
                                            tempRow = plmFile(index)
                                            .Crop = Trim(
                                                        Replace(
                                                        Expression:=tempRow,
                                                        Find:=tempRow.Split(",").First & ",",
                                                        Replacement:="",
                                                        Compare:=CompareMethod.Text)).ToUpper
                                        Catch ex As Exception
                                            mylog(LogTxt:="Can't get crop info out of " & vbCrLf &
                                                  plmFile(index) & vbCrLf &
                                                  ex.Message & vbCrLf &
                                                  "Continue anyway")
                                        End Try
                                    End If


                                    mylog(
                                        LogTxt:=out.filterGap & JobCounter.ToString(out.GAPNumberFormat) & " " & .Crop & " : " &
                                          plmFileJob.Count.ToString() & " scenarios")


                                End If


                                .Runs.Add(New run)

                                With .Runs(.Runs.Count - 1)

                                    'scenario
                                    If index = -1 Then
                                        mylog(LogTxt:="Can't get scenario out of " & plmFilePath & vbCrLf &
                                              "Continue anyway")
                                    Else

                                        Try
                                            tempRow = plmFile(index)
                                            tempRow =
                                                Replace(
                                                Expression:=tempRow,
                                                Find:="?",
                                                Replacement:="a",
                                                Compare:=CompareMethod.Text
                                                             )
                                            .Scenario = Trim(tempRow.Split(",").First).Split.Last.ToUpper.Substring(0, 4)

                                        Catch ex As Exception
                                            mylog(LogTxt:="Can't get crop info out of " & vbCrLf &
                                                  plmFile(index) & vbCrLf &
                                                  ex.Message & vbCrLf &
                                                  "Continue anyway")
                                        End Try

                                        mylog(LogTxt:= .Scenario.PadRight(Space) &
                                              Replace(Expression:=plmFilePath, Find:=startPath, Replacement:=""))

                                    End If

                                    tempRowArray =
                                        Filter(
                                        Source:=plmFile,
                                        Match:=searchCompoundsPercentiles,
                                        Include:=True,
                                        Compare:=CompareMethod.Text)

                                    If tempRowArray.Count = 0 Then

                                        mylog(LogTxt:="No " & searchCompoundsPercentiles & " found in " & plmFilePath)
                                        Return Nothing

                                    End If

                                    For compoundCounter As Integer = 0 To out.Compounds.Count - 1

                                        .Results.Add(New result)

                                        Dim statsPEC As New List(Of Double)

                                        With .Results(.Results.Count - 1)

                                            .Compound = out.Compounds(compoundCounter)
                                            .Percentile = Double.Parse(Trim(tempRowArray(compoundCounter).Split(vbTab).Last))

                                            Dim PECarray As String() = {}
                                            ReDim PECarray(19)

                                            index =
                                                Array.FindIndex(
                                                array:=plmFile,
                                                match:=Function(x) x = tempRowArray(compoundCounter))

                                            Try

                                                index -= 22

                                                Array.ConstrainedCopy(
                                                    sourceArray:=plmFile,
                                                    sourceIndex:=index,
                                                    destinationArray:=PECarray,
                                                    destinationIndex:=0,
                                                    length:=20)

                                            Catch ex As Exception
                                                mylog(LogTxt:="Can't get PEC values" & vbCrLf & ex.Message)
                                                Return Nothing
                                            End Try

                                            mylog(LogTxt:= .Compound.PadRight(Space))

                                            statsPEC.Clear()

                                            For Each result As String In PECarray

                                                .PECs.Add(New PEC)

                                                mylog(LogTxt:=".", Add2PreviousRow:=True)

                                                With .PECs(.PECs.Count - 1)

                                                    .year = 1906 + Integer.Parse(Trim(result.Split(vbTab)(1)))
                                                    .PEC = Double.Parse(Trim(result.Split(vbTab).Last))

                                                    statsPEC.Add(.PEC)

                                                End With

                                            Next

                                            With .Statistic
                                                .data = statsPEC.ToArray
                                                .Analyze()
                                            End With

                                            mylog(
                                                LogTxt:=" " & out.PercentileType & " perc. : " &
                                                        .Percentile.ToString.PadRight(9) & "µg/L",
                                                Add2PreviousRow:=True)

                                        End With

                                    Next

                                End With

                            Next

                        End With

                    Loop

                End With

            End With

        Loop

        Return out

    End Function

    Public Const searchModelVersion As String = "PEARL was called from"

    Public Const searchCompoundsPercentiles As String = " Perc."

    Public Const searchPercentileType As String = " Perc."
    Public Const searchCompoundNames As String = ") in the percolate at 1 m"


    Public Const searchCrop As String = "* Crop calendar"
    Public Const searchScenario As String = "* Location"



End Class


Public Class PECgwResults

    Public Sub New()

    End Sub

    <XmlIgnore> <ScriptIgnore>
    Public Property filterGrp As String = My.Settings.filterGrp
    <XmlIgnore> <ScriptIgnore>
    Public Property grpNumberFormat As String = My.Settings.grpNumberFormat

    <XmlIgnore> <ScriptIgnore>
    Public Property filterGap As String = My.Settings.filterGap
    <XmlIgnore> <ScriptIgnore>
    Public Property GAPNumberFormat As String = My.Settings.GAPNumberFormat

    <XmlIgnore> <ScriptIgnore>
    Public Property filterCrop As String = My.Settings.filterCrop
    <XmlIgnore> <ScriptIgnore>
    Public Property cropNumberFormat As String = My.Settings.cropNumberFormat


    Public Property model As String = String.Empty
    Public Property version As String = String.Empty

    Public Property masterPath As String = String.Empty

    Public Property PercentileType As String = String.Empty
    Public Property Compounds As New List(Of String)

    Public Property compoundNameLenght As Integer = 5

    Public Property cropFilter As Boolean = False

    Public Property Groups As New List(Of group)

    Public Function createCSV(PECgwResults As PECgwResults, Optional Delimiter As String = ",") As String()

        Dim out As New List(Of String)
        Dim row As New List(Of String)

        Dim headerRow As New List(Of String)

        headerRow.AddRange(
            {
            "Model",
            "Version",
            filterGrp,
            IIf(
                Expression:=cropFilter,
                    TruePart:=filterCrop,
                    FalsePart:=filterGap) & "#",
            "Crop",
            "Scenario",
            "Period/perc."})


        headerRow.AddRange(Compounds)

        out.Add(Join(SourceArray:=headerRow.ToArray, Delimiter:=Delimiter))

        For Each group As group In PECgwResults.Groups

            For Each gap As gap In group.Gaps

                For Each run As run In gap.Runs

                    For pecCounter As Integer = -1 To run.Results.First.Statistic.data.Count - 1

                        With row

                            .Clear()
                            .AddRange(
                                    {
                                    model,
                                    version,
                                    filterGrp & group.GroupNo.ToString(grpNumberFormat),
                                   IIf(
                                       Expression:=cropFilter,
                                       TruePart:=filterCrop & gap.GapNo.ToString(cropNumberFormat),
                                       FalsePart:=filterGap & gap.GapNo.ToString(GAPNumberFormat)
                                       ),
                                    gap.Crop.ToString,
                                    run.Scenario.ToString
                                    })

                            For resultCounter As Integer = 0 To run.Results.Count - 1

                                With run.Results(resultCounter)

                                    If pecCounter = -1 Then

                                        If resultCounter = 0 Then
                                            row.Add(PercentileType.ToString & "th")
                                        End If

                                        row.Add(.Percentile)

                                    Else

                                        If pecCounter < .Statistic.data.Count Then

                                            With .Statistic.data(pecCounter)

                                                If resultCounter = 0 Then
                                                    row.Add(pecCounter + 1)
                                                End If

                                                row.Add(.double2string)

                                            End With

                                        Else

                                            Console.WriteLine("error")

                                        End If



                                    End If

                                End With

                            Next

                        End With

                        out.Add(
                            Join(
                                SourceArray:=row.ToArray,
                                Delimiter:=Delimiter))

                    Next

                Next

            Next

        Next

        Return out.ToArray

    End Function

    Public Shared Function createMD(
                        PELMO As PECgwResultPELMO,
                        PEARL As PECgwResultPEARL,
                        MACRO As PECgwResultMACRO,
                        mdFilePath As String) As String()

        Dim delimit_Row As New StringBuilder
        Dim compLen As Integer = 8
        Dim comp As String = ""
        Dim row As New StringBuilder
        Dim scenarioRow As New StringBuilder
        Dim header As String() = {}
        Dim out As New List(Of String)

        Dim maxPECPEARL As New List(Of List(Of Double))
        Dim maxPECPELMO As New List(Of List(Of Double))

        Dim temp As Double() = {}
        Dim maxString As String


        Dim format As String = "0.0000"
        Dim minPEC As Double = 0.0001

        out.Clear()
        row.Clear()
        delimit_Row.Clear()
        scenarioRow.Clear()

        row.Append("| Compound |")
        delimit_Row.Append("| -------- |")
        scenarioRow.Append("| Scenario |")

        For compCounter As Integer = 0 To PEARL.Compounds.Count - 1

            row.Append(" " & PEARL.Compounds(compCounter) & " |")

            delimit_Row.Append(
                    " ".PadRight(
                    totalWidth:=row.Length - delimit_Row.Length - 2,
                    paddingChar:="-") & " |")

            scenarioRow.Append(
                    " PEARL".PadRight(
                    totalWidth:=row.Length - scenarioRow.Length - 2) & " |")

            row.Append(" " & PELMO.Compounds(compCounter) & " |")

            delimit_Row.Append(
                    " ".PadRight(
                    totalWidth:=row.Length - delimit_Row.Length - 2,
                    paddingChar:="-") & " |")

            scenarioRow.Append(
                    " PELMO".PadRight(
                    totalWidth:=row.Length - scenarioRow.Length - 2) & " |")

        Next


        out.Add(row.ToString)
        out.Add(delimit_Row.ToString)
        out.Add(scenarioRow.ToString)

        header = out.ToArray

        out.Clear()
        row.Clear()

        For grpCounter As Integer = 0 To PELMO.Groups.Count - 1

            row.Append("# Grp" & grpCounter.ToString("000"))
            out.Add(row.ToString)

            For gapCounter As Integer = 0 To PELMO.Groups(grpCounter).Gaps.Count - 1

                out.Add("")
                row.Clear()
                row.Append("## GAP" & gapCounter.ToString("000") & " : ")
                row.Append(PELMO.Groups(grpCounter).Gaps(gapCounter).Crop)
                out.Add(row.ToString)
                out.Add("")

                out.AddRange(header)

                maxPECPEARL.Clear()
                maxPECPELMO.Clear()

                For compCounter As Integer = 0 To PEARL.Compounds.Count - 1

                    maxPECPEARL.Add(New List(Of Double))
                    maxPECPELMO.Add(New List(Of Double))

                    For runCounter As Integer = 0 To PELMO.Groups(grpCounter).Gaps(gapCounter).Runs.Count - 1

                        maxPECPEARL(maxPECPEARL.Count - 1).Add(PEARL.Groups(grpCounter).Gaps(gapCounter).Runs(runCounter).Results(compCounter).Percentile)
                        maxPECPELMO(maxPECPELMO.Count - 1).Add(PELMO.Groups(grpCounter).Gaps(gapCounter).Runs(runCounter).Results(compCounter).Percentile)

                    Next

                Next

                For runCounter As Integer = 0 To PELMO.Groups(grpCounter).Gaps(gapCounter).Runs.Count - 1

                    row.Clear()
                    row.Append("| " &
                      PEARL.Groups(grpCounter).Gaps(gapCounter).Runs(runCounter).Scenario.PadRight(8) &
                      " |")

                    For compCounter As Integer = 0 To PEARL.Compounds.Count - 1

                        temp = maxPECPEARL(compCounter).ToArray

                        With PEARL.Groups(grpCounter).Gaps(gapCounter).Runs(runCounter).Results(compCounter)

                            If .Percentile > 0 AndAlso temp.Max = .Percentile Then
                                maxString = "**"
                            Else
                                maxString = ""
                            End If

                            maxString &= .Percentile.double2string(
                                       format:=format,
                                       min:=minPEC) & maxString

                            row.Append(" " & maxString.PadRight(8) & " |")

                        End With

                        temp = maxPECPELMO(compCounter).ToArray

                        With PELMO.Groups(grpCounter).Gaps(gapCounter).Runs(runCounter).Results(compCounter)

                            If .Percentile > 0 AndAlso temp.Max = .Percentile Then
                                maxString = "**"
                            Else
                                maxString = ""
                            End If

                            maxString &= .Percentile.double2string(
                                       format:=format,
                                       min:=minPEC) & maxString

                            row.Append(" " & maxString.PadRight(8) & " |")

                        End With

                    Next

                    out.Add(row.ToString)

                    File.WriteAllLines(path:=mdFilePath, contents:=out.ToArray)

                Next

            Next

        Next

        File.WriteAllLines(path:=mdFilePath, contents:=out.ToArray)

        Return out.ToArray

    End Function

    Public Sub serialize(filePath As String, Model As String)

        filePath = Path.Combine(path1:=filePath, path2:="getGwCsv_" & Model)

        DeSerialize.Class2XML(Class2Save:=Me, ClassType:=Me.GetType, XMLFileName:=filePath & ".xml")
        DeSerialize.saveClass2JSON(Class2Save:=Me, filePath:=filePath & ".json")

    End Sub

End Class

''' <summary>
''' Results for all GAPs belonging to one group
''' </summary>
<DebuggerStepThrough>
Public Class group

    Public Sub New()

    End Sub

    Public Property GroupNo As Integer = -1

    Public Property Gaps As New List(Of gap)

End Class

''' <summary>
''' Results for all compounds and all scenarios for a GAP
''' </summary>
<DebuggerStepThrough>
Public Class gap

    Public Sub New()

    End Sub

    Public Property GapNo As Integer = -1

    Public Property Crop As String = String.Empty

    Public Property Runs As New List(Of run)


End Class

''' <summary>
''' Results for all compounds for a scenario
''' </summary>
<DebuggerStepThrough>
Public Class run

    Public Sub New()

    End Sub

    <Category("01  Input")>
    Public Property Scenario As String = String.Empty

    Public Property Results As New List(Of result)

End Class

''' <summary>
''' Percentile and PECs in µg/L for all years for a respective Compound
''' </summary>
<DebuggerStepThrough>
Public Class result

    Public Sub New()

    End Sub

    Public ReadOnly Property Name As String
        Get

            If Compound = String.Empty OrElse Double.IsNaN(Percentile) Then
                Return " - "
            Else
                Return _
                        Compound.PadRight(7) & " : " &
                        IIf(
                        Expression:=Percentile > 0,
                        TruePart:=Percentile.ToString("0.000"), FalsePart:="<0.001") & " µg/L"
            End If

        End Get
    End Property

    Public Property Compound As String = String.Empty

    Public Property Percentile As Double = Double.NaN

    <XmlIgnore> <ScriptIgnore>
    Public Property PECs As New List(Of PEC)

    Public Property Statistic As New Statistic

End Class

''' <summary>
''' PECgw in µg/L and year
''' </summary>
<DebuggerStepThrough>
Public Class PEC

    Public Sub New()

    End Sub

    Public ReadOnly Property Name As String
        Get
            If year = -1 OrElse Double.IsNaN(PEC) Then
                Return " - "
            Else
                Return year.ToString & " : " & PEC.double2string & " µg/L"
            End If
        End Get
    End Property

    <DisplayName("PECgw in µg/L")>
    Public Property PEC As Double = Double.NaN

    Public Property year As Integer = -1

End Class