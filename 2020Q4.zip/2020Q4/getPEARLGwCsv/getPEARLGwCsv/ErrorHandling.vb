﻿
Imports System.IO

<DebuggerStepThrough>
Public Module ErrorHandling

    ''' <summary>
    ''' Complete ex description with error origin
    ''' </summary>
    ''' <param name="Exception">
    ''' Error object from 'try catch'
    ''' </param>
    ''' <param name="UserErrorDescription">
    ''' Optional user comment, will be out in the 1st row
    ''' </param>
    ''' <param name="LeadingString">
    ''' Optional precessing string
    ''' </param>
    ''' <returns>
    ''' Error description as string array
    ''' </returns>
    ''' <remarks>
    ''' Last Edit: 2015:Nov:24
    ''' by       : Horatio
    ''' </remarks>
    Public Function parseExceptionMsg(Exception As Exception,
                             Optional UserErrorDescription As String = "",
                             Optional LeadingString As String = "") As String()

        Const TargetAllignSpace As Integer = 8

        Dim Delimiter As String
        Dim ModuleDelimiter As String
        Dim RowDelimiter As String

        Dim StackTraceArray As String()
        Dim ErrorLineArray As String()
        Dim Output As New List(Of String)

        Dim ModuleRow As String = ""

       
        If UserErrorDescription <> "" Then Output.Add(UserErrorDescription)

        Output.Add(Exception.Message)

        'check if German or English error MSG
        If Exception.StackTrace.Contains("at ") Then

            'English
            Delimiter = "at "
            ModuleDelimiter = " in "
            RowDelimiter = ":line"

        ElseIf Exception.StackTrace.Contains("bei ") Then

            'German
            Delimiter = "bei "
            ModuleDelimiter = " in "
            RowDelimiter = ":Zeile"

        Else

            With Output

                .Add("Unknown language. can't parse error msg!")
                .Add("ErrorMsg".PadRight(TargetAllignSpace) & ": " & Exception.Message.ToString)
                .Add("StackTrace")
                .Add(Exception.StackTrace.ToString)

            End With

            Return Output.ToArray

        End If

        Try

            StackTraceArray = Split(Exception.StackTrace,
                                    Delimiter)
            StackTraceArray = Filter(StackTraceArray,
                                     ModuleDelimiter)

            'parse each msg
            For Each ErrorLine As String In StackTraceArray

                With Output

                    'Module name
                    ErrorLineArray = Split(ErrorLine,
                                           ModuleDelimiter)

                    ModuleRow = "Module".PadRight(TargetAllignSpace) & ": " &
                         Trim(ErrorLineArray.First)

                    If Output.Contains(ModuleRow) Then
                        Continue For
                    Else
                        .Add(ModuleRow)
                        ModuleRow = ""
                    End If


                    ErrorLineArray = Split(ErrorLineArray.Last,
                                           RowDelimiter)

                    'Where is the problem
                    .Add("in file".PadRight(TargetAllignSpace) & ": " &
                         Trim(ErrorLineArray.First))

                    .Add("at row".PadRight(TargetAllignSpace) & ": " &
                         Trim(Replace(ErrorLineArray.Last,
                                      ".", "")))

                End With

            Next

        Catch FatalException As Exception

            With Output

                .Add("Can't parse error msg!")
                .Add("ErrorMsg".PadRight(TargetAllignSpace) & ": " &
                                Exception.Message.ToString)
                .Add("StackTrace")
                .Add(Exception.StackTrace.ToString)
                .Add(FatalException.StackTrace.ToString)

            End With

        End Try

        For Counter As Integer = 0 To Output.Count - 1
            Output(Counter) = LeadingString & Output(Counter)
        Next


        If IsNothing(Exception.InnerException) Then
            Return Output.ToArray
        Else
            Output.Add(" ")
            Output.Add(" ")
            Output.Add("inner exception: ")
            Output.Add(" ")
            Output.AddRange(parseExceptionMsg(Exception:=Exception.InnerException))
        End If

        Return Output.ToArray

    End Function

End Module
