﻿Public Class StartForm

    Public cForm As Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        If cForm IsNot Nothing Then
            cForm.Hide()
            cForm.Dispose()
            cForm = Nothing
        End If
        cForm = New Form1
        cForm.myCaller = Me
        cForm.ShowDialog()
        'If cForm.DialogResult = Windows.Forms.DialogResult.Retry Then
        '    Reset()
        '    MessageBox.Show("resetting")
        'Else
        '    'just quit if reset (represented by 'retry') was not chosen inside of the "showdialog"
        '    Me.Close()
        'End If

    End Sub

    Private Sub StartForm_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated

        Dim resetSwitch As Boolean
        resetSwitch = True

        'Me.Hide()
        'Me.Show()
        'MsgBox("OK")
        'Me.Hide()
        Do While resetSwitch
            ' let's do it at least once!
            If cForm IsNot Nothing Then
                cForm.Hide()
                cForm.Dispose()
                cForm = Nothing
            End If
            cForm = New Form1
            cForm.mycaller = Me
            cForm.Visible = False
            cForm.ShowDialog()
            'If cForm.DialogResult = Windows.Forms.DialogResult.Retry Then
            '    ' reset
            '    'MessageBox.Show("resetting")
            'Else
            '    ' just quit if reset (represented by 'retry') was not chosen inside of the "showdialog"
            '    resetSwitch = False
            'End If
        Loop

        Me.Close()

    End Sub
End Class