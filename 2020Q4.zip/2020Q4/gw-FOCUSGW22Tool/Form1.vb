﻿Imports System.IO
Imports System.Windows

Public Class Form1

    ' for reset button
    Public myCaller As StartForm
    Public MyConfig As New mySettings

    Public IndexSearchString As String = ""
    Public EverythingAllright As Boolean = False
    ' new program version with PSM files compatible with PELMO 5
    Public Const ExtendedScenarioRunList As Boolean = True

    ' the tool should warn the user just once about possible non-consistency of coreinfo files
    Public warnCoreInconsistent As Boolean = True

    Public FOCUSScenarios As String() = {"Chateaudun", _
                                        "Hamburg", _
                                        "Jokioinen", _
                                        "Kremsmuenster", _
                                        "Okehampton", _
                                        "Piacenza", _
                                        "Porto", _
                                        "Sevilla", _
                                        "Thiva"}

    'Public PROUTTMasterpath As String = "Z:\" & Environment.UserName.ToUpper & "\PROUTT"
    Public PROUTTMasterpath As String = "Z:"

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        'StartPEARL()
        'startPELMO()

        init()

    End Sub

    Public PELMOExecPath As String = "C:\Emod\FOCUSPELMO553"
    Public PEARLExecPath As String = "Z:\_PROUTT\_software\FOCUSPEARL444"
    Public PELMOVersion As String = "PELMO553"
    Public PEARLVersion As String = "PEARL444"

    Public Sub init()

        'Dim Dinfo As DriveInfo
        Dim Dummy As String = ""

        With Me.ToolTip1

            .AutoPopDelay = 1000
            .InitialDelay = 1000
            .ReshowDelay = 200
            .ShowAlways = True

        End With

        My.Application.ChangeCulture("en-US")

        Dim VersionNumber As String
        If System.Deployment.Application.ApplicationDeployment.IsNetworkDeployed Then
            ' running deployed calculation -> version number is available
            VersionNumber = My.Application.Deployment.CurrentVersion.ToString
        Else
            ' debug run, not deployed application, command line...
            ' we use assembly (?)version name here!
            'http://msdn.microsoft.com/en-us/library/system.windows.forms.datagridview.aspx
            'http://msdn.microsoft.com/en-us/library/ms171600.aspx
            VersionNumber = My.Application.Info.Version.ToString
            VersionNumber = VersionNumber & " (debug)"
        End If

        'If ExtendedScenarioRunList Then
        'Me.lblPelmoWarning.Text = "Experimental PSM file handling!"
        'End If

        Me.Text = "FOCUSgw2.1 Tool v" & VersionNumber

        If Environment.MachineName.ToUpper.StartsWith("ADEMONS") Then
            Dummy = Path.Combine("E:\User", Environment.UserName)
            MsgBox("The tool should not be started on the server!", MsgBoxStyle.Exclamation, "Unsupported computer")
            Me.DialogResult = DialogResult.Abort
            Me.Close()

            'Elseif Environment.MachineName.ToUpper.StartsWith("ADEMONC") Then

            'Dummy = "C:\Emod"

            'Else
            '    MsgBox("Critical error - please contact the PROUTT Team", MsgBoxStyle.Exclamation, "Error during init")
            '    Me.DialogResult = Windows.Forms.DialogResult.Abort
            '    Me.Close()

        End If

        txtPELMOPath.Text = PELMOExecPath
        txtPEARLPath.Text = PEARLExecPath

        'If Not Directory.Exists(PELMOExecPath) Then

        '    MsgBox("Please make sure that FOCUS PELMO is available under " & PELMOExecPath & vbCrLf & _
        '           "Is the Z: drive connected properly? Open Windows Explorer and go to Z:", vbExclamation)

        '    Me.Close()

        'End If

        If Not Directory.Exists(PEARLExecPath) Then

            MsgBox("Please make sure that FOCUS PEARL is available under " & PEARLExecPath & vbCrLf & _
                   "Is the Z: drive connected properly? Open Windows Explorer and go to Z:", vbExclamation)

            Me.Close()

        End If

        Try

            If Not Directory.Exists(PROUTTMasterpath) Then
                MsgBox("PROUTT master path found, please make it available!" & vbNewLine &
                       PROUTTMasterpath, vbExclamation)
                End
            End If

        Catch ex As Exception

            MsgBox("PROUTT master path found, please make it available!" & vbNewLine &
                   PROUTTMasterpath, vbExclamation)
            End

        End Try

        Me.Show()

        With Me.lsbLog.Items

            .Add(Me.Text)
            .Add(" Started on " & Format(Now, "ddd, dd.MMM.yy") & " at " & Format(Now, "hh:mm:ss"))
            .Add("         by " & My.User.Name)
            .Add(" on machine " & My.Computer.Name & " (" & Environment.ProcessorCount & " CPUs)")
            .Add("         OS " & My.Computer.Info.OSFullName)
            .Add("            v" & My.Computer.Info.OSVersion & " (" & My.Computer.Info.OSPlatform & ")")

            .Add("PROUTT Masterpath : " & PROUTTMasterpath)
            .Add("*******************************************************")

            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

        End With

        Exit Sub

    End Sub

    Public Sub startPELMO()


        Dim PELMOCompletePath As String = ""
        Dim PELMOCompleteFiles As String() = {}
        Dim SubstanceTemplates As String() = {}
        Dim AppFileNames As String() = {}
        Dim PELMOFiles As New List(Of String)

        Dim TargetPSMFileList As New List(Of String)
        Dim AppList As New List(Of String)
        Dim SingleCountryList As New List(Of String)

        Dim Crop As String = ""
        Dim AppRepeat As String = ""
        Dim AppInfo As String() = {}
        Dim AppString As String = ""
        Dim Location As String = ""
        Dim CropNo As String = ""

        Dim OldPSMFileList As String() = {}

        Dim AppFileStringArray As String() = {}
        Dim PELMOAppStringArray As String() = {}

        Dim StartIndex As Integer = 0
        Dim EndIndex As Integer = 0
        Dim TargetFolder As String = ""

        Dim LocationCounter As Integer = 0
        Dim DummyArray As String() = {}
        Dim NoOfApps As Integer = 0

        Dim BareSoil As Integer = 0

        Dim NewPSMCountryFile As New List(Of String)
        Dim NewPSMCompleteFile As New List(Of String)
        Dim ActualPSMFile As String() = {}
        Dim Filename As String = ""

        Dim YeearStep As Integer = -1
        Dim Complete As Boolean = False
        Dim MsgBoxResult As New MsgBoxResult

        Dim AppDummyRow As String = ""
        Dim EllerichSpecial As String = ""

        ' new stuff for PELMO5 support
        ' we need scenario+1 application sections in the PSM file with some dummy application info
        Dim Pelmo5Special As Boolean = False
        'If PELMOCompletePath Then
        If txtPELMOPath.Text.Contains("PELMO553") Then
            Pelmo5Special = True
        End If

        If lbxApp.Items.Count = 0 Then

            MsgBox("Select .app Files first!")
            Exit Sub

        End If

        With Me.lsbLog.Items

            Try
                SubstanceTemplates = Directory.GetFiles(Me.txtPELMOTemplate.Text, "*.psm")
            Catch ex As Exception
                If Me.txtPELMOTemplate.Text = "" Then
                    MsgBox("Define PELMO template directory first!", vbCritical)
                    Exit Sub

                Else
                    MsgBox("IO Error" & vbNewLine & ex.Message)
                    Exit Sub

                End If
            End Try


            .Add("*******************************")
            .Add("********** PELMO **************")
            .Add("*******************************")

            '.Add("PELMO332 Compound Templates")
            .Add("PELMO Compound Templates")
            .AddRange(SubstanceTemplates)

            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

            SaveLog_Click(Me, Nothing)

            'delete old psm files

            'If PELMOExecPath.ToLower.StartsWith("c:\") Then

            '    If MsgBox("Start deleting *** LOCAL *** FOCUS PELMO Results !!",
            '              MsgBoxStyle.OkCancel) = Microsoft.VisualBasic.MsgBoxResult.Cancel Then
            '        Exit Sub
            '    End If

            'End If

            OldPSMFileList = Directory.GetFiles(Me.txtPELMOPath.Text, "Crop*.psm")

            If OldPSMFileList.Length <> 0 Then

                MsgBoxResult = MsgBox("Delete old PROUTT psm files (Crop??_*.psm)?", MsgBoxStyle.YesNoCancel)

                Select Case MsgBoxResult

                    Case Microsoft.VisualBasic.MsgBoxResult.Yes

                        With Me.ToolStripProgressBar

                            .Minimum = 0
                            .Value = 0
                            .Maximum = OldPSMFileList.Count
                            .Visible = True

                        End With
                        Me.ToolStripStatusLabel.Visible = True

                        Try

                            For Each psmfile As String In OldPSMFileList

                                File.Delete(psmfile)
                                Me.ToolStripStatusLabel.Text = "Delete :" & psmfile
                            Next

                            Me.ToolStripStatusLabel.Visible = False
                            Me.ToolStripProgressBar.Visible = False

                            .Add("Delete old psm file(s)")

                        Catch ex As Exception

                            MsgBox("IO Error" & vbCrLf & ex.Message, MsgBoxStyle.Critical)
                            .Add("IO Error")
                            .Add(ex.Message)
                            SaveLog_Click(Me, Nothing)
                            Exit Sub

                        End Try

                    Case Microsoft.VisualBasic.MsgBoxResult.No

                        .Add("Keep old psm files")

                    Case Microsoft.VisualBasic.MsgBoxResult.Cancel

                        .Add("Abort by user")
                        SaveLog_Click(Me, Nothing)
                        Exit Sub

                End Select

            End If

            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

            'delete old PELMO result directories
            OldPSMFileList = Directory.GetDirectories(Path.Combine(Me.txtPELMOPath.Text, "FOCUS"))

            If OldPSMFileList.Count <> 0 Then

                MsgBoxResult = MsgBox("Delete old FOCUS PELMO Result Directories ?", MsgBoxStyle.YesNoCancel)

                Select Case MsgBoxResult

                    Case Microsoft.VisualBasic.MsgBoxResult.Yes

                        With Me.ToolStripProgressBar

                            .Minimum = 0
                            .Value = 0
                            .Maximum = OldPSMFileList.Count
                            .Visible = True

                        End With
                        Me.ToolStripStatusLabel.Visible = True


                        Try

                            For Each ResultDir As String In OldPSMFileList

                                My.Computer.FileSystem.DeleteDirectory(ResultDir, _
                                                                       FileIO.DeleteDirectoryOption.DeleteAllContents)

                                Me.ToolStripStatusLabel.Text = "Delete :" & ResultDir

                            Next

                            Me.ToolStripStatusLabel.Visible = False
                            Me.ToolStripProgressBar.Visible = False

                            .Add("Delete old FOCUS PELMO result directories")

                        Catch ex As Exception

                            MsgBox("IO Error" & vbCrLf & ex.Message, MsgBoxStyle.Critical)
                            .Add("IO Error")
                            .Add(ex.Message)
                            SaveLog_Click(Me, Nothing)
                            Exit Sub

                        End Try

                    Case Microsoft.VisualBasic.MsgBoxResult.No

                        .Add("Keep old FOCUS PELMO Result Directories")

                    Case Microsoft.VisualBasic.MsgBoxResult.Cancel

                        .Add("Abort by user")
                        SaveLog_Click(Me, Nothing)
                        Exit Sub

                End Select

            End If

            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1


            For Each AppFileName As String In Me.lbxApp.Items


                'Crop01 etc.
                CropNo = Path.GetFileNameWithoutExtension(AppFileName)
                .Add("*******************************")
                .Add("Crop No      : " & CropNo)
                SaveLog_Click(Me, Nothing)
                TargetPSMFileList.Clear()

                Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                'get appfile content
                AppFileStringArray = File.ReadAllLines(AppFileName)

                'only PELMO part of it
                IndexSearchString = "#"
                EndIndex = AppFileStringArray.Length - 2
                StartIndex = Array.FindIndex(AppFileStringArray, AddressOf getIndex) + 1

                ReDim PELMOAppStringArray(EndIndex - StartIndex)

                Array.ConstrainedCopy(AppFileStringArray, StartIndex, _
                          PELMOAppStringArray, 0, EndIndex - StartIndex + 1)


                'get crop and apprepeat
                Crop = AppFileStringArray(0)
                .Add("Crop Name    : " & Crop)

                AppRepeat = AppFileStringArray(1)



                Select Case AppRepeat

                    Case "Every Year"
                        NoOfApps = 26
                        YeearStep = 1

                    Case "Every 2nd Year"
                        NoOfApps = 46
                        YeearStep = 2

                    Case "Every 3rd Year"
                        NoOfApps = 66
                        YeearStep = 3

                    Case Else

                        .Add("Invalid AppRepeat : " & AppRepeat)
                        Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                        SaveLog_Click(Me, Nothing)


                End Select

                .Add("Appl. Repeat : " & AppRepeat & ", Runtime : " & NoOfApps & " years")

                TargetFolder = Path.Combine(Path.GetDirectoryName(AppFileName), _
                                            Path.GetFileNameWithoutExtension(AppFileName) & "_" & Crop)

                TargetFolder = Path.Combine(TargetFolder, "PELMO" & txtPELMOPath.Text.Substring(txtPELMOPath.Text.Length - 3, 3))



                Try
                    Directory.CreateDirectory(TargetFolder)
                    .Add("Create Directory '" & TargetFolder & "'")
                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                Catch ex As Exception

                    .Add("Error creating directroy '" & TargetFolder & "'")
                    .Add(ex.Message.ToString)
                    SaveLog_Click(Me, Nothing)
                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                    Exit Sub

                End Try

                AppList.Clear()
                SingleCountryList.Clear()


                If ExtendedScenarioRunList = False Then
                    ' original code
                    ' number of application sections in psm file is equal to the number of scenarios in the calculation
                    ' doesn't work with PELMO 5
                    AppList.Add(" " & PELMOAppStringArray.Length - 3 & _
                                "     0     0    <number of locations absolute app/relative app crop stage>")
                    SingleCountryList.Add(" 1     0     0    <number of locations absolute app/relative app crop stage>")

                Else
                    ' new code
                    ' add one section with general information, non-related to the calculation
                    ' we use the first defined entry, copy it, and remove the scenario key code

                    ' new code with number of calculation + 1
                    ' let's copy things in
                    AppList.Add(" " & PELMOAppStringArray.Length - 3 + 1 & _
                                "     0     0    <number of locations absolute app/relative app crop stage>")
                    SingleCountryList.Add(" 2     0     0    <number of locations absolute app/relative app crop stage>")


                    .Add("Pseudo application first")

                    DummyArray = Split(PELMOAppStringArray(3), vbTab)
                    Dim tempstr As String = DummyArray(1)

                    tempstr = tempstr.Substring(0, 12) + " " + tempstr.Substring(13)

                    AppList.Add(tempstr)
                    .AddRange(DummyArray)
                    SaveLog_Click(Me, Nothing)
                    SingleCountryList.Add(AppList(AppList.Count - 1))

                    For AppNoCounter As Integer = 1 To NoOfApps Step YeearStep

                        For dummycounter = 2 To DummyArray.Length - 1
                            AppList.Add(Replace(DummyArray(dummycounter), "xx", Format(AppNoCounter, "00")))
                            SingleCountryList.Add(AppList(AppList.Count - 1))
                        Next

                    Next
                End If

                .Add("Application Header all countries")
                .Add(AppList.Item(AppList.Count - 1))

                Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                ' old code did not work well
                ' now we make a backup copy here!
                Dim SingleCountryListBak As New List(Of String)
                For Each country In SingleCountryList
                    SingleCountryListBak.Add(country)
                Next


                For LocationCounter = 3 To PELMOAppStringArray.Length - 1

                    ' reuse the backup copy
                    SingleCountryList = Nothing
                    SingleCountryList = New List(Of String)
                    For Each country In SingleCountryListBak
                        SingleCountryList.Add(country)
                    Next

                    .Add("Application Info")
                    '.AddRange(DummyArray)


                    DummyArray = Split(PELMOAppStringArray(LocationCounter), vbTab)
                    AppList.Add(DummyArray(1))  '*******************************************************************
                    .AddRange(DummyArray)
                    SaveLog_Click(Me, Nothing)
                    SingleCountryList.Add(AppList(AppList.Count - 1))

                    For AppNoCounter As Integer = 1 To NoOfApps Step YeearStep

                        For dummycounter = 2 To DummyArray.Length - 1
                            AppList.Add(Replace(DummyArray(dummycounter), "xx", Format(AppNoCounter, "00")))
                            SingleCountryList.Add(AppList(AppList.Count - 1))
                        Next

                    Next

                    SingleCountryList.Add(" 1    <pesticide appl. flag: 1=soil 2 =linear 3=exp. foliar>")

                    'check if one template for all scenarios
                    If Path.GetFileNameWithoutExtension(SubstanceTemplates(0)) = "Complete" Then

                        '.Add("Just one psm template for all scenarios")
                        'SaveLog_Click(Me, Nothing)
                        ActualPSMFile = SubstanceTemplates
                        Complete = True

                        If ActualPSMFile.Length = 1 And LocationCounter <> PELMOAppStringArray.Length - 1 Then

                            Continue For

                        End If

                        ActualPSMFile = File.ReadAllLines(ActualPSMFile(0))

                        Try
                            AppDummyRow = Filter(ActualPSMFile, "<pesticide appl. flag:", True).First
                            If Not AppDummyRow.StartsWith(" 1    <") Then
                                EllerichSpecial = Filter(ActualPSMFile, "<plant decay rate;washoff parameter", True).First
                            Else
                                EllerichSpecial = ""
                            End If

                            For SingleCountryRowCounter As Integer = 0 To SingleCountryList.Count - 1

                                If SingleCountryList(SingleCountryRowCounter) = " 1    <pesticide appl. flag: 1=soil 2 =linear 3=exp. foliar>" Then
                                    SingleCountryList(SingleCountryRowCounter) = AppDummyRow
                                    If EllerichSpecial <> "" Then
                                        SingleCountryList.Insert(SingleCountryRowCounter + 1, EllerichSpecial)
                                    End If
                                End If

                            Next

                        Catch ex As Exception

                        End Try



                    Else

                        .Add("Psm Template : '" & DummyArray(0) & "'")
                        DummyArray = Filter(SubstanceTemplates, DummyArray(0))
                        ActualPSMFile = File.ReadAllLines(DummyArray(0))

                    End If

                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                    'search for application part
                    For counter As Integer = 0 To ActualPSMFile.Length - 1

                        NewPSMCountryFile.Add(ActualPSMFile(counter))
                        If ActualPSMFile(counter) = "<APPLICATION>" Then Exit For

                    Next

                    If Complete Then

                        If AppDummyRow <> "" Then
                            AppList.Add(AppDummyRow)
                            If EllerichSpecial <> "" Then
                                AppList.Add(EllerichSpecial)
                            End If
                        Else
                            AppList.Add(" 1    <pesticide appl. flag: 1=soil 2 =linear 3=exp. foliar>")
                        End If


                        NewPSMCountryFile.AddRange(AppList)

                    Else
                        NewPSMCountryFile.AddRange(SingleCountryList)
                    End If

                    IndexSearchString = "<END APPLICATION>"
                    StartIndex = Array.FindIndex(ActualPSMFile, AddressOf getIndex)

                    'baresoil
                    If Crop = "BARESOIL" And BareSoil = 0 Then

                        If MsgBox("Set plant uptake factor to 0 for bare soil application ?", MsgBoxStyle.YesNo) = _
                                   Microsoft.VisualBasic.MsgBoxResult.Yes Then

                            BareSoil = 1
                            .Add("Baresoil: Set Plant Uptake to 0")
                            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                            SaveLog_Click(Me, Nothing)

                        End If

                    End If


                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                    If BareSoil = 1 Then

                        For counter As Integer = StartIndex To ActualPSMFile.Length - 1

                            If InStr(ActualPSMFile(counter), "plant uptake factor", CompareMethod.Text) <> 0 Then
                                ActualPSMFile(counter) = " 0.0      <plant uptake factor"
                            End If

                        Next

                    End If



                    For counter As Integer = StartIndex To ActualPSMFile.Length - 1

                        NewPSMCountryFile.Add(ActualPSMFile(counter))

                    Next

                    If Not Complete Then

                        Filename = Path.Combine(Me.txtPELMOPath.Text, _
                                                        Path.GetFileNameWithoutExtension(AppFileName) & "_" & _
                                                            Crop & "_" & _
                                                            Path.GetFileNameWithoutExtension(DummyArray(0)) & ".psm")

                        Try

                            File.WriteAllLines(Filename, NewPSMCountryFile.ToArray)
                            .Add("Write file : " & Filename)
                            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                        Catch ex As Exception

                            MsgBox("Error writing '" & Filename & _
                                                     vbCrLf & ex.Message, MsgBoxStyle.Critical)

                            .Add("Error writing '" & Filename & ".psm")
                            .Add(ex.Message.ToString)
                            SaveLog_Click(Me, Nothing)
                            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                            Exit Sub

                        End Try
                        Try
                            Filename = Path.Combine(TargetFolder, _
                                                    Path.GetFileNameWithoutExtension(AppFileName) & "_" & _
                                                    Crop & "_" & Path.GetFileNameWithoutExtension(DummyArray(0)) & ".psm")
                        Catch ex As Exception
                            .Add(ex.Message)
                            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                            SaveLog_Click(Me, Nothing)
                        End Try
                        Filename = Path.Combine(TargetFolder, Path.GetFileNameWithoutExtension(AppFileName) & "_" & _
                                                            Crop & "_" & _
                                                            Path.GetFileNameWithoutExtension(DummyArray(0)) & ".psm")

                        Try

                            File.WriteAllLines(Filename, NewPSMCountryFile.ToArray)
                            .Add("Write file : " & Filename)

                        Catch ex As Exception

                            MsgBox("Error writing '" & Filename & _
                                                     vbCrLf & ex.Message, MsgBoxStyle.Critical)

                            .Add("Error writing '" & Filename)
                            .Add(ex.Message.ToString)
                            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                            SaveLog_Click(Me, Nothing)
                            Exit Sub

                        End Try


                    Else


                        Filename = Path.Combine(Me.txtPELMOPath.Text, _
                                                        Path.GetFileNameWithoutExtension(AppFileName) & "_" & _
                                                                Crop & "_" & ".psm")

                        Try

                            File.WriteAllLines(Filename, NewPSMCountryFile.ToArray)
                            .Add("Write file : " & Filename)

                        Catch ex As Exception

                            MsgBox("Error writing '" & Filename & _
                                                     vbCrLf & ex.Message, MsgBoxStyle.Critical)

                            .Add("Error writing '" & Filename & ".psm")
                            .Add(ex.Message.ToString)
                            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                            SaveLog_Click(Me, Nothing)
                            Exit Sub

                        End Try

                        Filename = Path.Combine(TargetFolder, Path.GetFileNameWithoutExtension(AppFileName) & "_" & _
                                                                Crop & "_" & ".psm")

                        Try

                            File.WriteAllLines(Filename, NewPSMCountryFile.ToArray)
                            .Add("Write file : " & Filename)

                        Catch ex As Exception

                            MsgBox("Error writing '" & Filename & _
                                                     vbCrLf & ex.Message, MsgBoxStyle.Critical)

                            .Add("Error writing '" & Filename)
                            .Add(ex.Message.ToString)
                            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                            SaveLog_Click(Me, Nothing)
                            Exit Sub

                        End Try

                    End If


                    'SingleCountryList.Clear()
                    NewPSMCountryFile.Clear()
                    'SingleCountryList.Add(" 1     0     0    <number of locations absolute app/relative app crop stage>")

                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                Next

            Next

            Try
                My.Computer.FileSystem.CopyDirectory(Me.txtPELMOTemplate.Text,
        Path.Combine(My.Computer.FileSystem.GetParentPath(My.Computer.FileSystem.GetParentPath(TargetFolder)),
                     "CompoundTemplates\PELMO"), True)
                .Add("Compound templates copied!")
            Catch ex As Exception

            End Try

        End With

        MsgBox("PELMO inputs succesfully prepared. You can perform the simulation now.", vbInformation)

    End Sub


    Public Sub StartPEARL()

        Dim PEARLCompleteFiles As String() = {}
        Dim SubstanceTemplates As String() = {}
        Dim AppFileNames As String() = {}

        Dim BotString As String = ""

        Dim PrlFileArray As String() = {}

        Dim CompoundSection As String() = {}

        Dim AppFileStringArray As String() = {}
        Dim PEARLAppStringArray As String() = {}

        Dim Crop As String = ""
        Dim AppRepeat As String = ""
        Dim AppInfo As String() = {}
        Dim AppString As String = ""
        Dim Location As String = ""
        Dim CropNo As String = ""
        Dim BOTFile As String = ""
        Dim IrrFile As String = ""
        Dim MetFile As String = ""

        Dim PrlFileName As String = ""

        Dim TargetFolder As String = ""
        Dim LineCounter As Integer = 0

        Dim TargetPrlFileList As New List(Of String)

        Dim StartIndex As Integer = 0
        Dim EndIndex As Integer = 0

        Dim ControlSectionIndex As Integer = 0

        Dim PEARLFiles As New List(Of String)

        Dim CondorSubmit As New List(Of String)
        Dim NextLine As String = ",\"
        Dim dummy As String() = {}

        Dim DOSBATCH As New List(Of String)

        Dim JobCounter As Integer = 0

        Dim BareSoil As String() = _
        { _
        "* Section 7: Crop section", _
        "*-------------------------------------------------------------------------------", _
        "", _
        "No CropCalendar", _
        "Yes               RepeatCrops", _
        "Fixed             OptLenCrp", _
        "table  Crops", _
        "end_table" _
        }


        'add condor header
        CondorSubmit.Add("Universe               = Vanilla")
        CondorSubmit.Add("Executable             = " & Path.Combine(Me.txtPEARLPath.text, "pearlmodel.exe"))
        CondorSubmit.Add("Log                    = log.txt")
        CondorSubmit.Add("Notification           = Never")

        If lbxApp.Items.Count = 0 Then

            MsgBox("Select .app Files first!")
            Exit Sub

        End If


        With Me.lsbLog.Items
            .Add("*******************************")
            .Add("********** PEARL **************")
            .Add("*******************************")
            SaveLog_Click(Me, Nothing)

            SubstanceTemplates = Directory.GetFiles(Me.txtPEARLTemplate.Text, "*.cmp")

            .Add("PEARL compound templates")
            .AddRange(SubstanceTemplates)
            .Add("Executable             = " & Path.Combine(Me.txtPEARLPath.text, "pearlmodel.exe"))
            .Add("SWAP                   = " & (Directory.GetFiles(Me.txtPEARLPath.text, "swap*.exe")).First)

            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

            For Each AppFileName As String In Me.lbxApp.Items

                SaveLog_Click(Me, Nothing)
                PEARLFiles.AddRange(Directory.GetFiles(Me.txtPEARLPath.text, "swap*.exe"))

                'CROP01 etc.
                CropNo = Path.GetFileNameWithoutExtension(AppFileName)
                .Add("*******************************")
                .Add("Crop No      : " & CropNo)
                Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                TargetPrlFileList.Clear()

                'get appfile content
                AppFileStringArray = File.ReadAllLines(AppFileName)

                'only PEARL part of it
                IndexSearchString = "#"
                StartIndex = 0
                EndIndex = Array.FindIndex(AppFileStringArray, AddressOf getIndex) - 1

                ReDim PEARLAppStringArray(EndIndex - StartIndex)

                Array.ConstrainedCopy(AppFileStringArray, StartIndex, _
                          PEARLAppStringArray, 0, EndIndex - StartIndex + 1)


                'get crop and apprepeat
                Crop = AppFileStringArray(0)
                AppRepeat = AppFileStringArray(1)
                .Add("Crop Name    : " & Crop)
                .Add("Appl. Repeat : " & AppRepeat)

                TargetFolder = Path.Combine(Path.GetDirectoryName(AppFileName), _
                                            Path.GetFileNameWithoutExtension(AppFileName) & "_" & Crop)

                TargetFolder = Path.Combine(TargetFolder, "PEARL" & txtPEARLTemplate.Text.Substring(txtPEARLTemplate.Text.Length - 3, 3))

                .Add("Target Folder : '" & TargetFolder & "'")

                Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                Try

                    If Directory.Exists(TargetFolder) Then

                        Select Case MsgBox("Target folder '" & TargetFolder & "' exists, skip " & CropNo & " " & Crop & " ?", _
                                           MsgBoxStyle.YesNoCancel)

                            Case MsgBoxResult.Yes

                                .Add(CropNo & " " & Crop & " skipped")

                                JobCounter += 1
                                TargetPrlFileList.Clear()
                                PEARLFiles.Clear()
                                PEARLFiles.AddRange(Directory.GetFiles(Me.txtPEARLPath.text, "swap*.exe"))

                                Continue For

                            Case MsgBoxResult.No
                                Try
                                    My.Computer.FileSystem.DeleteDirectory(TargetFolder, _
                                                                           FileIO.DeleteDirectoryOption.DeleteAllContents)
                                    Directory.CreateDirectory(TargetFolder)
                                    .Add("Delete '" & TargetFolder)

                                Catch ex As Exception

                                    .Add(ex.Message)
                                    MsgBox(ex.Message)

                                End Try


                            Case MsgBoxResult.Cancel

                                .Add("Abort by user")
                                SaveLog_Click(Me, Nothing)
                                Exit Sub

                        End Select

                    Else

                        Directory.CreateDirectory(TargetFolder)
                        .Add("Create '" & TargetFolder)

                    End If
                    SaveLog_Click(Me, Nothing)

                Catch ex As Exception

                    MsgBox("Error deleting '" & TargetFolder & "'", MsgBoxStyle.Critical)

                    .Add("Error deleting '" & TargetFolder & "'")
                    .Add(ex.Message.ToString)
                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                    SaveLog_Click(Me, Nothing)

                    Exit Sub

                End Try

                Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                For CountryCounter As Integer = 3 To PEARLAppStringArray.Length - 1

                    'get appinfo
                    AppInfo = Split(PEARLAppStringArray(CountryCounter), vbTab)
                    If AppInfo.First = "" Then Exit For

                    Location = AppInfo.First
                    .AddRange(AppInfo)
                    SaveLog_Click(Me, Nothing)

                    CompoundSection = Filter(SubstanceTemplates, Location.ToUpper)

                    If CompoundSection.Length = 0 Then

                        MsgBox("Can't find template for '" & Location, MsgBoxStyle.Critical)
                        .Add("Can't find template for '" & Location)
                        SaveLog_Click(Me, Nothing)

                        Exit Sub

                    End If

                    Try
                        CompoundSection = File.ReadAllLines(CompoundSection.First)
                    Catch ex As Exception

                        MsgBox("Error reading '" & CompoundSection.First, MsgBoxStyle.Critical)
                        .Add("Error reading '" & CompoundSection.First)
                        .Add(ex.Message.ToString)
                        SaveLog_Click(Me, Nothing)
                        Exit Sub

                    End Try


                    If Crop <> "BARESOIL" Then
                        PEARLCompleteFiles = Directory.GetFiles(Me.txtPEARLPath.Text, Crop & "-" & Location & ".prl")
                    Else
                        PEARLCompleteFiles = Directory.GetFiles(Me.txtPEARLPath.text, "WCEREALS-" & Location & ".prl")
                    End If

                    .Add("Template : " & PEARLCompleteFiles.First)

                    Try
                        PrlFileArray = File.ReadAllLines(PEARLCompleteFiles.First)
                    Catch ex As Exception
                        MsgBox("Error reading '" & PEARLCompleteFiles.First)
                        .Add("Error reading '" & PEARLCompleteFiles.First)
                        .Add(ex.Message.ToString)
                        SaveLog_Click(Me, Nothing)
                        Exit Sub
                    End Try

                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                    IndexSearchString = "ApplicationScheme"
                    StartIndex = Array.FindIndex(PrlFileArray, AddressOf getIndex)

                    If StartIndex = -1 Then

                        MsgBox("Can't find 'ApplicationScheme'", MsgBoxStyle.Critical)
                        .Add("Can't find 'ApplicationScheme'")
                        SaveLog_Click(Me, Nothing)
                        Exit Sub

                    End If


                    PrlFileArray(StartIndex) = CropNo & "_" & Crop & "_" & Location & " ApplicationScheme"
                    .Add(PrlFileArray(StartIndex))

                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                    'start with control section
                    Try
                        IndexSearchString = "* Section 1: Control section"
                        ControlSectionIndex = Array.FindIndex(PrlFileArray, AddressOf getIndex) - 1

                        If StartIndex = -1 Then

                            MsgBox("Can't find '* Section 1: Control section'", MsgBoxStyle.Critical)
                            .Add("Can't find '* Section 1: Control section'")
                            SaveLog_Click(Me, Nothing)
                            Exit Sub

                        End If

                        Array.ConstrainedCopy(PrlFileArray, ControlSectionIndex, _
                                              PrlFileArray, 0, PrlFileArray.Length - ControlSectionIndex)

                        .Add("* Section 1: Control section  OK!")

                    Catch ex As Exception

                        .Add("* Section 1: Control section  ERROR!")
                        .Add(ex.Message)
                        Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                        SaveLog_Click(Me, Nothing)

                        Exit Sub

                    End Try

                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                    Try
                        IndexSearchString = "* Section 5: Compound section"
                        StartIndex = Array.FindIndex(PrlFileArray, AddressOf getIndex) - 2

                        If StartIndex = -1 Then

                            MsgBox("Can't find '* Section 5: Compound section'", MsgBoxStyle.Critical)
                            .Add("Can't find '* Section 5: Compound section'")
                            SaveLog_Click(Me, Nothing)
                            Exit Sub

                        End If

                        .Add("* Section 5: Compound section  OK!")

                    Catch ex As Exception

                        .Add("* Section 5: Compound section  ERROR!")
                        .Add(ex.Message)
                        Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                        SaveLog_Click(Me, Nothing)

                        Exit Sub

                    End Try


                    Try
                        IndexSearchString = "* Section 6: Management section"
                        EndIndex = Array.FindIndex(PrlFileArray, AddressOf getIndex)

                        If EndIndex = -1 Then

                            MsgBox("Can't find '* Section 6: Management section'", MsgBoxStyle.Critical)
                            .Add("Can't find '* Section 6: Management section'")
                            SaveLog_Click(Me, Nothing)
                            Exit Sub

                        End If

                        .Add("* Section 6: Management section  OK!")

                    Catch ex As Exception

                        .Add("* Section 6: Management section  ERROR!")
                        .Add(ex.Message)
                        Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                        SaveLog_Click(Me, Nothing)

                        Exit Sub

                    End Try

                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                    For LineCounter = 0 To StartIndex
                        TargetPrlFileList.Add(PrlFileArray(LineCounter))
                    Next

                    TargetPrlFileList.AddRange(CompoundSection)

                    Try
                        IndexSearchString = "DelTimEvt (a)"
                        StartIndex = Array.FindIndex(PrlFileArray, AddressOf getIndex) - 1

                        If StartIndex = -1 Then

                            MsgBox("Can't find 'DelTimEvt (a)", MsgBoxStyle.Critical)
                            .Add("Can't find 'DelTimEvt (a)'")
                            SaveLog_Click(Me, Nothing)
                            Exit Sub

                        End If

                        .Add("DelTimEvt (a)  OK!")

                    Catch ex As Exception


                        .Add("DelTimEvt (a)  ERROR!")
                        .Add(ex.Message)
                        Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                        SaveLog_Click(Me, Nothing)

                        Exit Sub

                    End Try


                    For LineCounter = EndIndex To StartIndex
                        TargetPrlFileList.Add(PrlFileArray(LineCounter))
                    Next

                    Try
                        IndexSearchString = "TimEnd"
                        StartIndex = Array.FindIndex(PrlFileArray, AddressOf getIndex)

                        If StartIndex = -1 Then

                            MsgBox("Can't find 'TimEnd'", MsgBoxStyle.Critical)
                            .Add("Can't find 'TimEnd'")
                            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                            SaveLog_Click(Me, Nothing)
                            Exit Sub

                        End If

                        .Add("TimEnd  OK!")

                    Catch ex As Exception

                        .Add("TimEnd  ERROR!")
                        .Add(ex.Message)
                        Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                        SaveLog_Click(Me, Nothing)

                        Exit Sub

                    End Try

                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                    Select Case AppRepeat

                        Case "Every Year"
                            TargetPrlFileList.Add("1                 DelTimEvt (a)")
                            BotString = "1"

                        Case "Every 2nd Year"
                            TargetPrlFileList.Add("2                 DelTimEvt (a)")
                            BotString = "2"
                            TargetPrlFileList.Item(StartIndex) = "31-Dec-1946       TimEnd"

                        Case "Every 3rd Year"
                            TargetPrlFileList.Add("3                 DelTimEvt (a)")
                            BotString = "3"
                            TargetPrlFileList.Item(StartIndex) = "31-Dec-1966       TimEnd"

                    End Select

                    .Add("Appl. Repeat : " & AppRepeat)
                    .Add(TargetPrlFileList.Last)
                    .Add(TargetPrlFileList.Item(StartIndex))
                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                    TargetPrlFileList.Add("table Applications")


                    For AppCounter As Integer = 1 To AppInfo.Length - 1
                        TargetPrlFileList.Add(AppInfo(AppCounter))
                    Next

                    TargetPrlFileList.Add("end_table")

                    Try
                        IndexSearchString = "table TillageDates"
                        StartIndex = Array.FindIndex(PrlFileArray, AddressOf getIndex)

                        If StartIndex = -1 Then

                            MsgBox("Can't find 'table TillageDates'", MsgBoxStyle.Critical)
                            .Add("Can't find 'table TillageDates'")
                            SaveLog_Click(Me, Nothing)
                            Exit Sub

                        End If

                        .Add("table TillageDates  OK!")

                    Catch ex As Exception

                        .Add("table TillageDates  ERROR!")
                        .Add(ex.Message)
                        Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                        SaveLog_Click(Me, Nothing)

                        Exit Sub

                    End Try


                    Do While Not PrlFileArray(StartIndex).EndsWith("-----")
                        TargetPrlFileList.Add(PrlFileArray(StartIndex))
                        StartIndex += 1
                    Loop
                    TargetPrlFileList.Add(PrlFileArray(StartIndex))


                    Try
                        IndexSearchString = "table VerticalProfiles"
                        StartIndex = Array.FindIndex(PrlFileArray, AddressOf getIndex) - 1

                        If StartIndex = -1 Then

                            MsgBox("Can't find 'table VerticalProfiles'", MsgBoxStyle.Critical)
                            .Add("Can't find 'table VerticalProfiles'")
                            SaveLog_Click(Me, Nothing)
                            Exit Sub

                        End If

                        .Add("table VerticalProfiles  OK!")

                    Catch ex As Exception

                        .Add("table VerticalProfiles  ERROR!")
                        .Add(ex.Message)
                        Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                        SaveLog_Click(Me, Nothing)

                        Exit Sub

                    End Try
                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1



                    If Crop = "BARESOIL" Then

                        IndexSearchString = "* Section 7: Crop section"
                        EndIndex = Array.FindIndex(PrlFileArray, AddressOf getIndex) - 1


                        If EndIndex = -1 Then

                            MsgBox("Can't find '* Section 7: Crop section'", MsgBoxStyle.Critical)
                            .Add("Can't find '* Section 7: Crop section'")
                            SaveLog_Click(Me, Nothing)
                            Exit Sub

                        End If

                        For LineCounter = StartIndex To EndIndex
                            TargetPrlFileList.Add(PrlFileArray(LineCounter))
                        Next

                        TargetPrlFileList.AddRange(BareSoil)

                        IndexSearchString = "* Section 8: Output control"
                        StartIndex = Array.FindIndex(PrlFileArray, AddressOf getIndex) - 1

                        If StartIndex = -1 Then

                            MsgBox("Can't find '* Section 8: Output control'", MsgBoxStyle.Critical)
                            .Add("Can't find '* Section 8: Output control'")
                            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                            SaveLog_Click(Me, Nothing)
                            Exit Sub

                        End If

                    End If

                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                    Try
                        IndexSearchString = "* Section 7: Crop section"
                        StartIndex = Array.FindIndex(PrlFileArray, AddressOf getIndex)

                        If StartIndex = -1 Then

                            MsgBox("Can't find '* Section 7: Crop section'", MsgBoxStyle.Critical)
                            .Add("Can't find '* Section 7: Crop section'")
                            SaveLog_Click(Me, Nothing)
                            Exit Sub

                        End If

                        .Add("* Section 7: Crop section  OK!")

                    Catch ex As Exception

                        .Add("* Section 7: Crop section  ERROR!")
                        .Add(ex.Message)
                        Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                        SaveLog_Click(Me, Nothing)

                        Exit Sub

                    End Try
                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1


                    For LineCounter = StartIndex To PrlFileArray.Length - 1
                        TargetPrlFileList.Add(PrlFileArray(LineCounter))
                        If PrlFileArray(LineCounter) = "* End of PEARL input file" Then
                            TargetPrlFileList.Add(PrlFileArray(LineCounter + 1))
                            Exit For
                        End If
                    Next

                    IndexSearchString = "LowerBoundaryFile"
                    StartIndex = Array.FindIndex(PrlFileArray, AddressOf getIndex)

                    If StartIndex = -1 Then

                        .Add("No 'LowerBoundaryFile'")

                    Else

                        TargetPrlFileList.Item(StartIndex) = (Location & "_" & BotString).PadRight(18) & "LowerBoundaryFile"

                        .Add(TargetPrlFileList.Item(StartIndex))


                        PEARLFiles.Add(Path.Combine(Me.txtPEARLPath.text, Location & "_" & BotString & ".bot"))

                    End If

                    IndexSearchString = "MeteoStation"
                    StartIndex = Array.FindIndex(PrlFileArray, AddressOf getIndex)

                    If StartIndex = -1 Then

                        MsgBox("Can't find 'MeteoStation'", MsgBoxStyle.Critical)
                        .Add("Can't find 'MeteoStation'")
                        Exit Sub

                    End If
                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                    MetFile = Trim(Replace(PrlFileArray(StartIndex), "MeteoStation", ""))
                    .Add("Meteo File : " & MetFile)

                    PEARLFiles.Add(Path.Combine(Me.txtPEARLPath.text, MetFile & ".met"))

                    'IndexSearchString = "IrrigationData"
                    'StartIndex = Array.FindIndex(PrlFileArray, AddressOf getIndex)

                    'If StartIndex = -1 Then

                    '    .Add("No 'IrrigationData'")

                    'Else

                    '    MetFile = Trim(Replace(PrlFileArray(StartIndex), "IrrigationData", ""))
                    '    .Add("Irrigation file: " & MetFile)

                    '    PEARLFiles.Add(Path.Combine(Me.txtPEARLPath.text, MetFile & ".irr"))
                    '    'File.Copy(Path.Combine(PEARLCompletePath, MetFile & ".irr"), _
                    '    '          Path.Combine(TargetFolder, MetFile & ".irr"))

                    'End If
                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                    PrlFileName = Path.Combine(TargetFolder, MetFile.Substring(0, 4) & ".prl")

                    File.WriteAllLines(PrlFileName, TargetPrlFileList.ToArray)
                    CondorSubmit.Add("#-------------------------------------------------------------------------------")
                    CondorSubmit.Add("# Job No " & Format(JobCounter, "0000") & " ; " & CropNo & " : " & Crop & " , " & Location)
                    CondorSubmit.Add("#-------------------------------------------------------------------------------")

                    ' new cluster requires different requirements
                    CondorSubmit.Add("Requirements           = memory < 3071 && \")
                    'CondorSubmit.Add("                         (Arch == ""INTEL"" || Arch == ""X86_64"")")
                    CondorSubmit.Add("                         Arch == ""X86_64""")
                    CondorSubmit.Add("Rank                   = memory")

                    CondorSubmit.Add("Arguments              = " & Path.GetFileName(PrlFileName))
                    CondorSubmit.Add("transfer_input_files   = " & Path.GetFileName(PrlFileName) & NextLine)

                    For Each member As String In PEARLFiles

                        If member = PEARLFiles.Item(PEARLFiles.Count - 1) Then
                            CondorSubmit.Add("                         " & member)
                        Else
                            CondorSubmit.Add("                         " & member & NextLine)
                        End If

                    Next

                    CondorSubmit.Add("transfer_output_remaps = " & """" & Path.GetFileNameWithoutExtension(PrlFileName) & ".sum = " & _
                                     CropNo & "_" & Crop & "_" & MetFile.Substring(0, 4) & ".sum" & """")

                    CondorSubmit.Add("transfer_output_files  = " & Path.GetFileNameWithoutExtension(PrlFileName) & ".sum")

                    CondorSubmit.Add("Queue")

                    JobCounter += 1

                    TargetPrlFileList.Clear()
                    PEARLFiles.Clear()
                    PEARLFiles.AddRange(Directory.GetFiles(Me.txtPEARLPath.text, "swap*.exe"))

                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                Next

                Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                SaveLog_Click(Me, Nothing)

            Next

            Try
                File.WriteAllLines(Path.Combine(My.Computer.FileSystem.GetParentPath(My.Computer.FileSystem.GetParentPath(TargetFolder)), "CondorSubmit.sub"), CondorSubmit.ToArray)
                CondorSubmit.Clear()
            Catch ex As Exception
                .Add(ex.Message)
                SaveLog_Click(Me, Nothing)
            End Try

            Try
                My.Computer.FileSystem.CopyDirectory(Me.txtPEARLTemplate.Text,
                        Path.Combine(My.Computer.FileSystem.GetParentPath(My.Computer.FileSystem.GetParentPath(TargetFolder)), "CompoundTemplates\PEARL"), True)
                .Add("Compound templates copied!")
            Catch ex As Exception
                MsgBox("Can't copy PEARL template prl files", vbExclamation)
            End Try

        End With

        'start condor batch
        ' this will be done by the user!

        With DOSBATCH
            .Add("echo off")
            .Add("REM check for credentials")
            .Add("condor_store_cred query")
            .Add("if %ERRORLEVEL%==1 condor_store_cred add")
            .Add("if %ERRORLEVEL%==1 echo. no valid credentials, exit")
            .Add("if %ERRORLEVEL%==1 pause")
            .Add("if %ERRORLEVEL%==1 exit")
            .Add("condor_submit CondorSubmit.sub")
            .Add("pause")
            .Add(": start")
            .Add("condor_q")
            .Add("ping -n 6 127.0.0.1 >null ")
            .Add("cls")
            .Add("goto start")
        End With

        File.WriteAllLines(Path.Combine(My.Computer.FileSystem.GetParentPath(My.Computer.FileSystem.GetParentPath(TargetFolder)), "StartCondor.bat"), DOSBATCH.ToArray)

        DOSBATCH.Clear()

        MsgBox("Log on to the cluster ademons1500 and execute the PEARL batch" & vbCrLf & vbCrLf & _
                "file name: StartCondor.bat" & vbCrLf & _
                "directory: " & My.Computer.FileSystem.GetParentPath(My.Computer.FileSystem.GetParentPath(TargetFolder)) & vbCrLf & vbCrLf & _
                "In the meantime, you can continue with PELMO..." _
                , vbInformation)

        'If MsgBox("Start CONDOR", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then

        '    Dim MyProcessStartInfo As New ProcessStartInfo

        '    With MyProcessStartInfo

        '        .FileName = Path.Combine(My.Computer.FileSystem.GetParentPath(My.Computer.FileSystem.GetParentPath(TargetFolder)), "StartCondor.bat")

        '        .WorkingDirectory = Path.GetDirectoryName(.FileName)

        '    End With

        '    Process.Start(MyProcessStartInfo)


        'End If

        Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

    End Sub

    <DebuggerStepThrough()> _
    Private Function getIndex(ByVal TestRow As String) As Boolean

        If InStr(TestRow, IndexSearchString) <> 0 Then Return True Else Return False

    End Function

    'Private Sub test()
    '    Dim myOFD As New OpenFileDialog

    '    Dim AppFiles As String() = {}

    '    Dim Results As New List(Of String)
    '    Dim dummy As String = ""
    '    Dim Substances As String() = {}
    '    Dim Substance As String = ""
    '    Dim StringArray As String() = {}
    '    Dim CropNo As String = ""
    '    Dim Crop As String = ""
    '    Dim Location As String = ""
    '    Dim Report As New List(Of String)
    '    Dim dummyarray As String() = {}
    '    Dim PEARLSumFile As String() = {}

    '    Dim TestList As New List(Of String)

    '    Dim LineCounter As Integer = 0

    '    Dim StartIndex As Integer = 0
    '    Dim EndIndex As Integer = 0

    '    Dim SearchIndex As Integer = 0

    '    'select Crop0x.app files
    '    With myOFD

    '        .Reset()
    '        .Title = "Select Application files"

    '        .CheckFileExists = True
    '        .Multiselect = True
    '        .Filter = "Sum files (*.app)|*.app|All files (*.*)|*.*"

    '        .ShowDialog()

    '        AppFiles = .FileNames

    '    End With


    '    For Each AppFile As String In AppFiles

    '        StringArray = File.ReadAllLines(AppFile)

    '        Substances = Split(StringArray(2), ";")
    '        Crop = StringArray(0)
    '        CropNo = Path.GetFileNameWithoutExtension(AppFile)



    '        For LocationCounter = 3 To StringArray.Length - 1

    '            Location = StringArray(LocationCounter)

    '            If Location = "" Then Exit For

    '            dummyarray = Split(Location, vbTab)
    '            Location = dummyarray(0)

    '            PEARLSumFile = File.ReadAllLines(Path.Combine(Path.GetDirectoryName(AppFile), _
    '                                                          CropNo & "_" & Crop & "_" & Location.Substring(0, 4) & ".sum"))

    '            IndexSearchString = "* PEARL REPORT: Header"
    '            StartIndex = Array.FindIndex(PEARLSumFile, AddressOf getIndex) - 1

    '            IndexSearchString = "* End of PEARL REPORT: Header"
    '            EndIndex = Array.FindIndex(PEARLSumFile, AddressOf getIndex) + 1


    '            For LineCounter = StartIndex To EndIndex

    '                Results.Add(PEARLSumFile(LineCounter))

    '            Next


    '            IndexSearchString = "* PEARL REPORT: FOCUS"
    '            StartIndex = Array.FindIndex(PEARLSumFile, AddressOf getIndex)


    '            Do While PEARLSumFile(StartIndex) <> ""
    '                Results.Add(PEARLSumFile(StartIndex))
    '                StartIndex += 1
    '            Loop

    '            IndexSearchString = "* PEARL REPORT: Project_Summary"
    '            StartIndex = Array.FindIndex(PEARLSumFile, AddressOf getIndex) - 1


    '            Do While StartIndex <= PEARLSumFile.Length - 1
    '                Results.Add(PEARLSumFile(StartIndex))
    '                StartIndex += 1
    '            Loop


    '            Results.Add("|||")


    '            For Each Substance In Substances

    '                dummyarray = Filter(PEARLSumFile, "* Result_" & Substance)

    '                TestList.Add(Location & "_" & Substance & "_" & Trim(Replace(dummyarray(0), "* Result_" & Substance, "")))


    '                IndexSearchString = "* FOCUS summary for compound " & Substance
    '                StartIndex = Array.FindIndex(PEARLSumFile, AddressOf getIndex)

    '                IndexSearchString = "* The average concentration of " & Substance
    '                EndIndex = Array.FindIndex(PEARLSumFile, AddressOf getIndex) + 1


    '                For LineCounter = StartIndex To EndIndex

    '                    Results.Add(PEARLSumFile(LineCounter))

    '                Next

    '                Results.Add("|||")

    '            Next

    '        Next

    '        TestList.Add("|||")

    '        TestList.AddRange(Results)

    '        File.WriteAllLines(Path.ChangeExtension(AppFile, ".res"), TestList.ToArray)

    '        Results.Clear()

    '    Next

    'End Sub


    Private Sub btnPEARL333_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPEARL333.Click

        If lblMNumberPEARL.Text <> lblMNumberPELMO.Text Then

            If warnCoreInconsistent = True Then
                MsgBox("Warning: 'Substance Core-Info' pdf files differ between PEARL and PELMO",
                           vbCritical)
                ' the user has been warned
                warnCoreInconsistent = False
            End If

        End If

        StartPEARL()

    End Sub


    Private Sub btnPELMO32_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPELMO32.Click

        'If Not Directory.Exists(txtPELMOPath.Text) Then
        '    MsgBox("You MUST define a valid FOCUS PELMO exec path", vbCritical)
        'Else

        If lblMNumberPEARL.Text <> lblMNumberPELMO.Text Then

                If warnCoreInconsistent = True Then
                    MsgBox("Warning: 'Substance Core-Info' pdf files differ between PEARL and PELMO",
                               vbCritical)
                    ' the user has been warned
                    warnCoreInconsistent = False
                End If

            End If

            startPELMO()
        ' End If

    End Sub

    Private Sub txtPEARLTemplate_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles txtPEARLTemplate.MouseDown, txtPELMOTemplate.MouseDown, txtMasterPath.MouseDown

        Dim txt As String = CType(sender, TextBox).Text

        If txt = "" Then Exit Sub

        If e.Button = MouseButtons.Right Then

            Process.Start("explorer.exe", "/n,/root," & """" & CType(sender, TextBox).Text & """")

        End If


    End Sub

    Private Sub lblPEARLPath_Click(sender As Object, e As EventArgs) Handles lblPEARLPath.Click

        Dim myFBD As New FolderBrowserDialog

        With myFBD

            .Reset()
            .Description = "Select PEARL master path"
            .ShowNewFolderButton = False

            .ShowDialog()

            txtPEARLPath.Text = .SelectedPath

        End With

    End Sub

    Private Sub lblPELMOPath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblPELMOPath.Click

        Dim myFBD As New FolderBrowserDialog

        With myFBD

            .Reset()
            .Description = "Select PELMO master path"
            .ShowNewFolderButton = False

            .ShowDialog()

            txtPELMOPath.Text = .SelectedPath

        End With

    End Sub

    Private Sub btnGetApp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetApp.Click

        Dim myOFD As New OpenFileDialog
        Dim DummyArray As String() = {}


        Me.lbxApp.Items.Clear()


        If Me.txtMasterPath.Text = "" Or Not Directory.Exists(Me.txtMasterPath.Text) Then

            MsgBox("Invalid MasterPath : " & Me.txtMasterPath.Text, MsgBoxStyle.Critical)
            Me.lsbLog.Items.Add("Invalid MasterPath : " & Me.txtMasterPath.Text)
            Exit Sub

        End If

        With Me.lsbLog.Items

            .Add("Paths")
            .Add("Master                : " & Me.txtMasterPath.Text)
            .Add("PEARL Environment     : " & Me.txtPEARLPath.text)
            .Add("PELMO Environment     : " & Me.txtPELMOPath.Text)
            .Add("PEARL Comp. TemplateS : " & Me.txtPEARLTemplate.Text)
            .Add("PELMO Comp. Templates : " & Me.txtPELMOTemplate.Text)

        End With

        DummyArray = Directory.GetFiles(Me.txtMasterPath.Text, "*.app")

        If DummyArray.Count = 0 Then

            MsgBox("MasterPath contains no *.app files" & vbCrLf & Me.txtMasterPath.Text, MsgBoxStyle.Critical)
            Me.lsbLog.Items.Add("MasterPath contains no *.app files  : " & Me.txtMasterPath.Text)
            Exit Sub

        Else

            Select Case MsgBox(DummyArray.Count & " .app files found, append all ?", MsgBoxStyle.YesNoCancel)

                Case MsgBoxResult.Yes
                    Me.lbxApp.Items.AddRange(DummyArray)
                    Exit Sub

                Case MsgBoxResult.No

                Case MsgBoxResult.Cancel
                    Exit Sub

            End Select

        End If

        Me.SaveLog_Click(Me, Nothing)

        With myOFD

            .Reset()
            .Title = "Select Application files"

            .InitialDirectory = txtMasterPath.Text

            .CheckFileExists = True
            .Multiselect = True
            .Filter = "Sum files (*.app)|*.app|All files (*.*)|*.*"

            .ShowDialog()

            For Each FileName As String In .FileNames
                Me.lbxApp.Items.Add(FileName)
            Next

        End With

    End Sub

    Private Sub btnValMaster_Click(sender As Object, e As EventArgs) Handles btnValMaster.Click

        If Directory.Exists(txtMasterPath.Text) Then

            lblValMaster.Text = "valid"
            lblValMaster.ForeColor = Color.Green
            btnGetApp.Enabled = True
            btnEvaluatePEARL.Enabled = True
            btnSubstInfoPEARL.Enabled = True
            btnEvaluatePELMO.Enabled = True
            btnSubstInfoPELMO.Enabled = True

        Else

            MsgBox("Project location not available. Try again!", vbCritical)
            'txtMasterPath.Text = ""
            lblValMaster.Text = "invalid"
            lblValMaster.ForeColor = Color.Red
            btnGetApp.Enabled = False
            btnEvaluatePEARL.Enabled = False
            btnSubstInfoPEARL.Enabled = False
            btnEvaluatePELMO.Enabled = False
            btnSubstInfoPELMO.Enabled = False

        End If

    End Sub


    Private Sub lblMasterPath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblMasterPath.Click

        Dim myFBD As New FolderBrowserDialog
        Dim DummyPath As String = PROUTTMasterpath
        With myFBD

            .Reset()
            .Description = "Select PROUTT Master Path"
            .ShowNewFolderButton = True

            Try
                'DummyPath = Path.Combine(DummyPath, "Projects")
                If Directory.Exists(DummyPath) Then

                    .SelectedPath = DummyPath

                Else

                    MsgBox("Default project location not available. First connect the workdrive " & PROUTTMasterpath, vbCritical)

                    lblValMaster.Text = "invalid"
                    lblValMaster.ForeColor = Color.Red

                    Exit Sub
                    'Select Case MsgBox("Default PROUTT Project Path is not available ?" _
                    '                   & vbCrLf & DummyPath, MsgBoxStyle.YesNoCancel)

                    '    Case MsgBoxResult.Cancel
                    '        Exit Sub

                    '    Case MsgBoxResult.No

                    '    Case MsgBoxResult.Yes

                    '        My.Computer.FileSystem.CreateDirectory(DummyPath)

                    'End Select

                End If


            Catch ex As Exception

            End Try

            If .ShowDialog() = vbOK Then
                txtMasterPath.Text = .SelectedPath
                lblValMaster.Text = "valid"
                lblValMaster.ForeColor = Color.Green
                btnGetApp.Enabled = True
                btnEvaluatePEARL.Enabled = True
                btnSubstInfoPEARL.Enabled = True
                btnEvaluatePELMO.Enabled = True
                btnSubstInfoPELMO.Enabled = True

            Else
                lblValMaster.Text = "invalid"
                lblValMaster.ForeColor = Color.Red
                btnGetApp.Enabled = False
                btnEvaluatePEARL.Enabled = False
                btnSubstInfoPEARL.Enabled = False
                btnEvaluatePELMO.Enabled = False
                btnSubstInfoPELMO.Enabled = False

            End If

        End With

        If File.Exists(Path.Combine(Me.txtMasterPath.Text, "FOCUSGWToolSettings.xml")) Then

            btnLoadFromConfig_Click(Me, Nothing)

        End If

    End Sub


    Private Sub btnValPearl_Click(sender As Object, e As EventArgs) Handles btnValPearl.Click

        If Directory.Exists(txtPEARLTemplate.Text) Then

            If IsPearlPathValid() = True Then

                lblValPearl.Text = "valid"
                lblValPearl.ForeColor = Color.Green
                btnPEARL333.Enabled = True

            Else

                'MsgBox("PEARL template path not available. Try again!", vbCritical)
                'txtPEARLTemplate.Text = ""
                lblValPearl.Text = "invalid"
                lblValPearl.ForeColor = Color.Red
                btnPEARL333.Enabled = False

            End If

        Else

            MsgBox("PEARL template path not available. Try again!", vbCritical)
            'txtPEARLTemplate.Text = ""
            lblValPearl.Text = "invalid"
            lblValPearl.ForeColor = Color.Red
            btnPEARL333.Enabled = False

            Exit Sub

        End If

    End Sub

    Private Sub lblPEARLTemplate_Click(ByVal sender As System.Object, _
                                       ByVal e As System.EventArgs) Handles lblPEARLTemplate.Click


        Dim myFBD As New FolderBrowserDialog
        Dim DummyPath As String = ""
        Dim Dummy As String = ""

        If Not Directory.Exists(Me.txtMasterPath.Text) Then
            MsgBox("Select 'Masterpath' first", vbExclamation)
            Exit Sub
        End If

        txtPEARLTemplate.Text = ""

        With myFBD

            .Reset()
            .Description = "Select PEARL Substance Template Path"
            .ShowNewFolderButton = False

            Try

                If Not Directory.Exists(Me.txtMasterPath.Text) Then
                    MsgBox("Select 'Masterpath' first", vbExclamation)
                    Exit Sub
                End If

                'DummyPath = Path.Combine(PROUTTMasterpath, "CompoundTemplates")
                Dim pathProc As String
                Dim pathProcSplit As String()
                pathProc = Me.txtMasterPath.Text
                pathProcSplit = Split(pathProc, "\")
                If pathProcSplit.Length > 1 Then
                    .SelectedPath = Path.Combine(pathProcSplit(0) & "\", pathProcSplit(1) & "\")
                Else
                    .SelectedPath = PROUTTMasterpath
                End If

                'If Directory.Exists(DummyPath) Then
                '    .SelectedPath = DummyPath
                'Else

                '    MsgBox("Please store your compound templates under" & vbCrLf & _
                '           DummyPath, MsgBoxStyle.Critical)
                '    Exit Sub

                'End If

            Catch ex As Exception

                MsgBox(ex.Message)
                End

            End Try

            .ShowDialog()

            txtPEARLTemplate.Text = .SelectedPath

        End With

        If IsPearlPathValid() = True Then

            lblValPearl.Text = "valid"
            lblValPearl.ForeColor = Color.Green
            btnPEARL333.Enabled = True

        Else

            'MsgBox("PEARL template path not available. Try again!", vbCritical)
            'txtPEARLTemplate.Text = ""
            lblValPearl.Text = "invalid"
            lblValPearl.ForeColor = Color.Red
            btnPEARL333.Enabled = False

        End If

    End Sub

    Private Function IsPearlPathValid() As Boolean

        Dim DummyArray As String() = {}

        If InStr(txtPEARLTemplate.Text, "PEARL") = 0 Then

            Select Case MsgBox("Selected path contains no 'PEARL'" & vbCrLf & _
                               txtPEARLTemplate.Text & vbCrLf & _
                               "Continue anyway ?", MsgBoxStyle.YesNoCancel)

                Case MsgBoxResult.Yes

                Case MsgBoxResult.No, MsgBoxResult.Cancel
                    Return False

            End Select

        End If

        DummyArray = Directory.GetFiles(txtPEARLTemplate.Text, "*.pdf")

        If DummyArray.Length > 1 Then

            If MsgBox(DummyArray.Length & " 'Substance Core-Info' pdf files found, continue anyway?",
                       vbYesNo) = MsgBoxResult.No Then
                Return False
            End If

        ElseIf DummyArray.Length = 0 Then

            If MsgBox("No 'Substance Core-Info' pdf file found continue anyway?",
                                       vbYesNo) = MsgBoxResult.No Then
                Return False
            End If

        Else
            lblMNumberPEARL.Text = Path.GetFileNameWithoutExtension(DummyArray(0))
        End If

        If Directory.GetFiles(txtPEARLTemplate.Text, "*.cmp").Length = 0 Then

            If Directory.GetFiles(txtPEARLTemplate.Text, "*.prl").Length = 9 Then

                MsgBox("Please use my 'PreparePEARLInput.exe' tool to convert prl to cmp files", MsgBoxStyle.Critical)
                Return False

            End If

            MsgBox("PEARL Compound Template directory contains no .cmp or .prl files!", MsgBoxStyle.Critical)
            Return False

        ElseIf Directory.GetFiles(txtPEARLTemplate.Text, "*.cmp").Length <> 9 Then

            MsgBox("PEARL Compound Template directory must contain 9 .cmp files!", MsgBoxStyle.Critical)
            Return False

        End If

        If InStr(txtPEARLTemplate.Text, "PELMO") <> 0 Then
            If MsgBox("Selected *** PEARL *** Path contains the string 'PELMO'" & vbCrLf & _
                    "Continue anyway ?", MsgBoxStyle.YesNo) = MsgBoxResult.No Then
                Return False
            End If
        End If

        Return True

    End Function

    Private Sub btnValPelmo_Click(sender As Object, e As EventArgs) Handles btnValPelmo.Click

        If Directory.Exists(txtPELMOTemplate.Text) Then

            If IsPelmoPathValid() = True Then

                lblValPelmo.Text = "valid"
                lblValPelmo.ForeColor = Color.Green
                btnPELMO32.Enabled = True
                btnStartPELMO.Enabled = True

            Else

                'MsgBox("pelmo template path not available. Try again!", vbCritical)
                'txtpelmoTemplate.Text = ""
                lblValPelmo.Text = "invalid"
                lblValPelmo.ForeColor = Color.Red
                btnPELMO32.Enabled = False
                btnStartPELMO.Enabled = False

            End If

        Else

            MsgBox("PELMO template path not available. Try again!", vbCritical)
            'txtpelmoTemplate.Text = ""
            lblValPelmo.Text = "invalid"
            lblValPelmo.ForeColor = Color.Red
            btnPELMO32.Enabled = False
            btnStartPELMO.Enabled = False

            Exit Sub

        End If


    End Sub

    Private Sub lblPELMOTemplate_Click(ByVal sender As System.Object, _
                                       ByVal e As System.EventArgs) Handles lblPELMOTemplate.Click

        Dim myFBD As New FolderBrowserDialog
        Dim DummyPath As String = ""
        Dim Dummy As String = ""
        Dim DummyArray As String() = {}



        If Not Directory.Exists(Me.txtMasterPath.Text) Then
            MsgBox("Select 'Masterpath' first", vbExclamation)
            Exit Sub
        End If


        'DummyPath = Path.Combine(DummyPath, My.Settings.StdCompoundTemplatePath)
        txtPELMOTemplate.Text = ""

        With myFBD

            .Reset()
            .Description = "Select PELMO Substance Template Path"
            .ShowNewFolderButton = False


            Try

                'DummyPath = Path.Combine(PROUTTMasterpath, "CompoundTemplates")
                Dim pathProc As String
                Dim pathProcSplit As String()
                pathProc = Me.txtMasterPath.Text
                pathProcSplit = Split(pathProc, "\")
                If pathProcSplit.Length > 1 Then
                    .SelectedPath = Path.Combine(pathProcSplit(0) & "\", pathProcSplit(1) & "\")
                Else
                    .SelectedPath = PROUTTMasterpath
                End If

                'If Directory.Exists(DummyPath) Then
                '    .SelectedPath = DummyPath
                'Else

                '    MsgBox("Please store your compound templates under" & vbCrLf & _
                '           DummyPath, MsgBoxStyle.Critical)
                '    Exit Sub

                'End If

            Catch ex As Exception

                MsgBox(ex.Message)
                End

            End Try

            .ShowDialog()

            txtPELMOTemplate.Text = .SelectedPath

        End With

        If IsPelmoPathValid() = True Then

            lblValPelmo.Text = "valid"
            lblValPelmo.ForeColor = Color.Green
            btnPELMO32.Enabled = True
            btnStartPELMO.Enabled = True

        Else

            'MsgBox("pelmo template path not available. Try again!", vbCritical)
            'txtpelmoTemplate.Text = ""
            lblValPelmo.Text = "invalid"
            lblValPelmo.ForeColor = Color.Red
            btnPELMO32.Enabled = False
            btnStartPELMO.Enabled = False

        End If

    End Sub

    Private Function IsPelmoPathValid() As Boolean

        Dim Dummy As String = ""
        Dim DummyArray As String() = {}

        If InStr(txtPELMOTemplate.Text, "PELMO") = 0 Then

            Select Case MsgBox("Selected path contains no 'PELMO'" & vbCrLf & _
                               txtPELMOTemplate.Text & vbCrLf & _
                               "Continue anyway ?", MsgBoxStyle.YesNoCancel)

                Case MsgBoxResult.Yes

                Case MsgBoxResult.No, MsgBoxResult.Cancel
                    Return False

            End Select

        End If

        If Directory.GetFiles(txtPELMOTemplate.Text, "*.psm").Length = 1 Then

            Dummy = Directory.GetFiles(txtPELMOTemplate.Text, "*.psm").First

            If Path.GetFileName(Dummy) <> "Complete.psm" Then

                If MsgBox("The General PELMO Compund Template has to be 'Complete.psm' and not" & vbCrLf & _
                Path.GetFileName(Dummy) & vbCrLf & "Rename ?", MsgBoxStyle.Critical) = MsgBoxResult.No Then
                    Return False
                Else

                    My.Computer.FileSystem.RenameFile(Dummy, Path.Combine(txtPELMOTemplate.Text, "Complete.psm"))

                End If


            End If

        ElseIf Directory.GetFiles(txtPELMOTemplate.Text, "*.psm").Length <> 9 Then

            MsgBox("PELMO Compound Template directory must contain 9 or 1 .psm files!", MsgBoxStyle.Critical)
            Return False

        ElseIf Directory.GetFiles(txtPELMOTemplate.Text, "*.psm").Length = 9 Then

            For Each Scenario In FOCUSScenarios

                If Not File.Exists(Path.Combine(txtPELMOTemplate.Text, Scenario & ".psm")) Then

                    MsgBox(" PELMO Template File " & Scenario & ".psm is missing !!!", MsgBoxStyle.Critical)
                    Return False

                End If

            Next

        ElseIf Directory.GetFiles(txtPELMOTemplate.Text, "*.psm").Length = 0 Then

            MsgBox("PELMO Template File directory is emty", MsgBoxStyle.Critical)
            Return False

        End If


        DummyArray = Directory.GetFiles(txtPELMOTemplate.Text, "*.pdf")

        If DummyArray.Length > 1 Then

            If MsgBox(DummyArray.Length & " 'Substance Core-Info' pdf files found, continue anyway?",
                       vbYesNo) = MsgBoxResult.No Then
                Return False
            End If
        ElseIf DummyArray.Length = 0 Then

            If MsgBox("No 'Substance Core-Info' pdf file found continue anyway?",
                                       vbYesNo) = MsgBoxResult.No Then
                Return False
            End If

        Else
            lblMNumberPELMO.Text = Path.GetFileNameWithoutExtension(DummyArray(0))
        End If

        If InStr(txtPELMOTemplate.Text, "PEARL") <> 0 Then
            If MsgBox("Selected *** PELMO *** Path contains the string 'PEARL'" & vbCrLf & _
                    "Continue anyway ?", MsgBoxStyle.YesNo) = MsgBoxResult.No Then
                Return False
            End If
        End If

        Return True

    End Function


    Private Sub btnStartPELMO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStartPELMO.Click

        Dim myStartInfo As New ProcessStartInfo
        Dim myProcess As New Process


        If lbxApp.Items.Count = 0 Then

            MsgBox("Select .app Files first!")
            Exit Sub

        End If

        With myStartInfo

            .FileName = Path.Combine(Me.txtPELMOPath.Text, "wpelmo.exe")
            .WorkingDirectory = Me.txtPELMOPath.Text


        End With

        With myProcess

            .StartInfo = myStartInfo
            .Start()

        End With



    End Sub

    Private Sub btnEvaluatePELMO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEvaluatePELMO.Click

        Dim CropNo As String = ""
        Dim DirectoryList As String() = {}
        Dim TargetRootFolder As String = ""
        Dim TargetCrop As String = ""
        Dim DummyArray As String() = {}
        Dim StartIndex As Integer = -1
        Dim EndIndex As Integer = -1
        Dim PelmoAppFileArray As String() = {}
        Dim Substances As String() = {}
        Dim Dummy As String = ""
        Dim Result As String = ""
        Dim PSMArray As String() = {}

        Dim Delimiter As String = ";"
        Dim ResultList As New List(Of String)

        Dim Country As String = ""

        Dim ResultPeriodFiles As String() = {}
        Dim ResList As New List(Of String)



        With Me.lsbLog.Items

            .Add("***************** PELMO Evaluation ***************************")

            For Each Crop As String In Me.lbxApp.Items

                DummyArray = File.ReadAllLines(Crop)

                'only PELMO part of it
                IndexSearchString = "#"
                EndIndex = DummyArray.Length - 2
                StartIndex = Array.FindIndex(DummyArray, AddressOf getIndex) + 1

                ReDim PelmoAppFileArray(EndIndex - StartIndex)

                Array.ConstrainedCopy(DummyArray, StartIndex, _
                          PelmoAppFileArray, 0, EndIndex - StartIndex + 1)


                TargetCrop = DummyArray.First
                Substances = Split(PelmoAppFileArray(2), ";")


                CropNo = Path.GetFileNameWithoutExtension(Crop)

                .Add(CropNo & " " & Crop)

                Try
                    DirectoryList = Directory.GetDirectories(Path.Combine(Me.txtPELMOPath.Text, "FOCUS"), CropNo & "*")
                Catch ex As Exception

                    MsgBox("IO Error" & vbNewLine & ex.Message, vbCritical)
                    Exit Sub

                End Try


                If DirectoryList.Length = 0 Then

                    MsgBox("Directory for " & CropNo & " not found under" & vbCrLf & "   " & Path.Combine(Me.txtPELMOPath.Text, "FOCUS") & vbCrLf & "skipping...", vbCritical)
                    Continue For

                End If


                TargetRootFolder = Path.Combine(Path.GetDirectoryName(Crop), CropNo & "_" & TargetCrop)
                TargetRootFolder = Path.Combine(TargetRootFolder, "PELMO" &
                                                Me.txtPELMOPath.Text.Substring(Me.txtPELMOPath.Text.Length - 3, 3))


                'move results
                With Me.ToolStripProgressBar

                    .Minimum = 0
                    .Value = 0
                    .Maximum = DirectoryList.Count
                    .Visible = True

                End With
                Me.ToolStripStatusLabel.Visible = True


                For Each CropDir As String In DirectoryList

                    Me.ToolStripProgressBar.Value += 1

                    Try

                        Dummy = Path.Combine(TargetRootFolder, Path.GetFileName(CropDir))
                        Me.ToolStripStatusLabel.Text = "Copy : " & Dummy

                        Me.Refresh()

                        If (Directory.GetFiles(CropDir, "period.plm", SearchOption.AllDirectories)).Length = 0 Then

                            MsgBox("No 'period-plm' files in directory '" & CropDir & "', please use 'PELMO-Evaluate'", _
                                   MsgBoxStyle.Critical)
                            .Add("No 'period-plm' files in directory '" & CropDir & "', please use 'PELMO-Evaluate'")
                            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                            Exit Sub

                        End If
                        .Add("Target File : " & Dummy)
                        lsbLog.Refresh()

                        ' originally, the whole directory would be moved
                        ' in the new version, we delete everything except the period.plm file
                        ' if user doesn't request otherwise

                        If chkKeepPelmoData.Checked = True Then

                            ' copy the whole directory (as backup for debugging)
                            My.Computer.FileSystem.CopyDirectory(CropDir, CropDir & "-PROUTTBAK", True)

                        End If

                        '   delete everything except period.plm, echo.plm and the respective psm in the original folder
                        For Each fName As String In Directory.GetFiles(CropDir, "*", SearchOption.AllDirectories)
                            If InStr(fName.ToUpper, "ECHO.PLM") > 0 Or InStr(fName.ToUpper, "PERIOD.PLM") > 0 Or InStr(fName.ToUpper, "PSM") > 0 Or InStr(fName.ToUpper, "YEAR.PLM") > 0 Then
                                ' do nothing
                            Else
                                My.Computer.FileSystem.DeleteFile(fName)
                            End If
                        Next
 
                        '   move the directory to Z:
                        My.Computer.FileSystem.MoveDirectory(CropDir, Path.Combine(TargetRootFolder, Path.GetFileName(CropDir)), True)

                        If chkKeepPelmoData.Checked = True Then

                            ' restore the original folder
                            My.Computer.FileSystem.MoveDirectory(CropDir & "-PROUTTBAK", CropDir, True)

                        End If

                    Catch ex As Exception

                        MsgBox("Unknown error" & vbCrLf & ex.Message.ToString)
                        .Add("Unknown error")
                        .Add(ex.Message)
                        SaveLog_Click(Me, Nothing)

                        Exit Sub

                    End Try

                Next
                Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                Me.ToolStripProgressBar.Visible = False
                Me.ToolStripStatusLabel.Visible = False

                ResultPeriodFiles = Directory.GetFiles(TargetRootFolder, "period.plm", SearchOption.AllDirectories)


                Dim dummylist As New List(Of String)
                Dim TargetLoc As String = ""
                Dim TempDummy As String = ""

                'sort
                For dummycounter As Integer = 3 To PelmoAppFileArray.Count - 1

                    TempDummy = PelmoAppFileArray(dummycounter)
                    TargetLoc = (Split(PelmoAppFileArray(dummycounter), vbTab)).First
                    If TargetLoc = "Chateaudun" Then
                        TargetLoc = "Châteaudun"
                    ElseIf TargetLoc = "Kremsmuenster" Then
                        TargetLoc = "Kremsmünster"
                    Else
                        TargetLoc = "\" & TargetLoc & "_"
                    End If

                    Try
                        TempDummy = (Filter(ResultPeriodFiles, TargetLoc)).First
                    Catch ex As Exception
                        MsgBox("Can't find result file 'period.plm' for " & vbNewLine &
                               TargetLoc & ", " & CropNo & ", " & TargetCrop, vbCritical)
                        Exit Sub
                    End Try

                    dummylist.Add(TempDummy)

                Next

                ResultPeriodFiles = dummylist.ToArray



                ResultList.Clear()


                With Me.ToolStripProgressBar

                    .Minimum = 0
                    .Value = 0
                    .Maximum = ResultPeriodFiles.Length
                    .Visible = True

                End With
                Me.ToolStripStatusLabel.Visible = True

                For Counter As Integer = 0 To ResultPeriodFiles.Length - 1

                    Me.ToolStripProgressBar.Value += 1
                    Me.ToolStripStatusLabel.Text = "Evaluate : " & ResultPeriodFiles(Counter)
                    Me.Refresh()

                    .Add("Results : " & ResultPeriodFiles(Counter))

                    Try
                        PSMArray = File.ReadAllLines(ResultPeriodFiles(Counter))
                    Catch ex As Exception

                        MsgBox("Can't access '" & ResultPeriodFiles(Counter) & vbCrLf & _
                               ex.Message.ToString, MsgBoxStyle.Critical)
                        .Add("Can't access '" & ResultPeriodFiles(Counter))
                        .Add(ex.Message.ToString)
                        Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                        SaveLog_Click(Me, Nothing)
                        Exit Sub

                    End Try



                    DummyArray = Split(ResultPeriodFiles(Counter), "_(")
                    DummyArray = Split(DummyArray(DummyArray.Length - 1), ")")

                    Select Case DummyArray(0).ToUpper

                        Case "C".ToUpper
                            Country = "Chateaudun"

                        Case "H".ToUpper
                            Country = "Hamburg"

                        Case "J".ToUpper
                            Country = "Jokioinen"

                        Case "K".ToUpper
                            Country = "Kremsmuenster"

                        Case "N".ToUpper
                            Country = "Okehampton"

                        Case "P".ToUpper
                            Country = "Piacenza"

                        Case "O".ToUpper
                            Country = "Porto"

                        Case "S".ToUpper
                            Country = "Sevilla"

                        Case "T".ToUpper
                            Country = "Thiva"

                        Case Else

                            .Add("No Valid Scenario Name " & DummyArray(0).ToUpper)
                            SaveLog_Click(Me, Nothing)
                            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                            Exit Sub

                    End Select

                    .Add("Country : " & Country)

                    Try
                        File.Copy(ResultPeriodFiles(Counter), _
                                  Path.Combine(TargetRootFolder, CropNo & "_" & TargetCrop & "_" & Country & ".plm"), True)
                    Catch ex As Exception

                        MsgBox("Can't copy file '" & ResultPeriodFiles(Counter) & " to " & vbCrLf & _
                               Path.Combine(TargetRootFolder, CropNo & "_" & TargetCrop & "_" & Country & ".plm"), _
                                                            MsgBoxStyle.Critical)


                        .Add("Can't copy file '" & ResultPeriodFiles(Counter) & " to " & vbCrLf & _
                               Path.Combine(TargetRootFolder, CropNo & "_" & TargetCrop & "_" & Country & ".plm"))
                        .Add(ex.Message.ToString)
                        Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                        SaveLog_Click(Me, Nothing)

                    End Try

                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                    Dummy = Country & Delimiter

                    'add active substance
                    IndexSearchString = "80 Perc."
                    StartIndex = Array.FindIndex(PSMArray, AddressOf getIndex) + 1

                    If StartIndex = -1 Then

                        MsgBox("Can't find '80 Perc.'", MsgBoxStyle.Critical)
                        .Add("Can't find '80 Perc.'")
                        Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                        SaveLog_Click(Me, Nothing)
                        Exit Sub

                    End If



                    DummyArray = Split(PSMArray(StartIndex - 1), vbTab)
                    Dummy &= DummyArray(DummyArray.Length - 1) & Delimiter

                    'add results for substances
                    For SubstCounter As Integer = 1 To Substances.Length - 1

                        IndexSearchString = "Metab." & Substances(SubstCounter)
                        StartIndex = Array.FindIndex(PSMArray, AddressOf getIndex) + 1

                        If StartIndex = -1 Then

                            MsgBox("Can't find 'Metab.'", MsgBoxStyle.Critical)
                            .Add("Can't find 'Metab.'")
                            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                            SaveLog_Click(Me, Nothing)
                            Exit Sub

                        Else


                            Do While InStr(PSMArray(StartIndex), "80 Perc.") = 0
                                StartIndex += 1
                                If StartIndex >= PSMArray.Count - 1 Then
                                    MsgBox("Can't find 'Metab.' for subst no " & SubstCounter, MsgBoxStyle.Critical)
                                    .Add("Can't find 'Metab.' for subst no " & SubstCounter)
                                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                                    SaveLog_Click(Me, Nothing)
                                End If
                            Loop

                            'StartIndex += 32
                            DummyArray = Split(PSMArray(StartIndex), vbTab)

                            If SubstCounter <> Substances.Length - 1 Then
                                Dummy &= DummyArray(DummyArray.Length - 1) & Delimiter
                            Else
                                Dummy &= DummyArray(DummyArray.Length - 1)
                            End If

                        End If

                    Next

                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                    'add to result list
                    ResList.Add(Dummy)

                Next

                Dummy = Directory.GetParent(ResultPeriodFiles(0)).FullName
                Dummy = Directory.GetParent(Dummy).FullName
                Dummy = Directory.GetParent(Dummy).FullName
                Dummy = Directory.GetParent(Dummy).FullName
                Dummy = Path.Combine(Dummy, CropNo & "_" & TargetCrop & ".res")

                Try
                    File.WriteAllLines(Dummy, ResList.ToArray)
                    .Add("Result file : '" & Dummy & "'")
                    .AddRange(ResList.ToArray)
                Catch ex As Exception

                    MsgBox("Can't write '" & Dummy & "'" & vbCrLf & ex.Message.ToString, MsgBoxStyle.Critical)

                    .Add("Can't write '" & Dummy)
                    .Add(ex.Message.ToString)
                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                    SaveLog_Click(Me, Nothing)

                End Try

                ResList.Clear()

                Dummy = ""

                Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

            Next

            Me.ToolStripStatusLabel.Visible = False
            Me.ToolStripProgressBar.Visible = False


        End With

    End Sub

    Private Sub btnEvaluatePEARL_Click(ByVal sender As System.Object, _
                                       ByVal e As System.EventArgs) Handles btnEvaluatePEARL.Click


        Dim CropNo As String = ""
        Dim DirectoryList As String() = {}
        Dim TargetRootFolder As String = ""
        Dim TargetCrop As String = ""
        Dim DummyArray As String() = {}
        Dim StartIndex As Integer = -1
        Dim EndIndex As Integer = -1
        Dim PEARLAppFileArray As String() = {}
        Dim Substances As String() = {}
        Dim Dummy As String = ""
        Dim Result As String = ""
        Dim PSMArray As String() = {}

        Dim Delimiter As String = ";"
        Dim ResultList As New List(Of String)
        Dim Country As String = ""
        Dim SumSourcePath As String = ""
        Dim ResList As New List(Of String)
        Dim TargetFolder As String = ""
        Dim SumFiles As String() = {}
        Dim SumArray As String() = {}
        Dim Deli As Char() = {" "c}
        Dim SumFileInfo As FileInfo

        Dim EmtySumFile As Boolean = False

        SumSourcePath = Path.GetDirectoryName(Me.lbxApp.Items(0).ToString)


        If Directory.GetFiles(txtMasterPath.Text, "*.sum", SearchOption.AllDirectories).Length = 0 Then

            MsgBox("No PEARL .sum Files to Proceede", MsgBoxStyle.Critical)
            Exit Sub

        End If


        If Filter(Directory.GetFiles(txtMasterPath.Text, "*.prl", SearchOption.AllDirectories), "Crop", True).Length <> _
           Filter(Directory.GetFiles(txtMasterPath.Text, "*.sum", SearchOption.AllDirectories), "Crop", True).Length Then


            MsgBox("No of .prl files doesn't match no of .sum files", MsgBoxStyle.Critical)
            Exit Sub

        End If

        'Dim a As Object
        'Dim b As Object
        'a = Filter(Directory.GetFiles(txtMasterPath.Text, "*.prl", SearchOption.AllDirectories), "Crop", True)
        'b = Filter(Directory.GetFiles(txtMasterPath.Text, "*.sum", SearchOption.AllDirectories), "Crop", True)


        With Me.lsbLog.Items

            .Add("***************** PEARL Evaluation ***************************")
            SaveLog_Click(Me, Nothing)

            With Me.ToolStripProgressBar

                .Minimum = 0
                .Value = 0
                .Maximum = lsbLog.Items.Count
                .Visible = True

            End With
            Me.ToolStripStatusLabel.Visible = True



            For Each Crop As String In Me.lbxApp.Items

                Me.ToolStripProgressBar.Value += 1
                Me.ToolStripStatusLabel.Text = "App File : " & Crop
                Me.Refresh()

                'get appfile content(
                PEARLAppFileArray = File.ReadAllLines(Crop)

                'only PEARL part of it
                IndexSearchString = "#"
                StartIndex = 0
                EndIndex = Array.FindIndex(PEARLAppFileArray, AddressOf getIndex) - 1

                ReDim Preserve PEARLAppFileArray(EndIndex - StartIndex)

                SumSourcePath = Path.GetDirectoryName(Crop)



                'get crop and apprepeat
                TargetCrop = PEARLAppFileArray(0)
                CropNo = Path.GetFileNameWithoutExtension(Crop)

                Substances = Split(PEARLAppFileArray(2), Delimiter)

                SumFiles = Directory.GetFiles(SumSourcePath, CropNo & "_" & TargetCrop & "*.sum")


                TargetFolder = Path.Combine(Path.GetDirectoryName(Crop), _
                                            CropNo & "_" & TargetCrop)

                TargetFolder = Path.Combine(TargetFolder, "PEARL" &
                                            txtPEARLPath.text.Substring(txtPEARLPath.text.Length - 3, 3))


                'move sum files
                .Add("Move sum files")
                Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                Try

                    For Each Sumfile In SumFiles

                        Try
                            File.Delete(Path.Combine(TargetFolder, Path.GetFileName(Sumfile)))
                        Catch ex As Exception

                            .Add("IO-error" & vbCrLf & ex.Message)
                            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                            SaveLog_Click(Me, Nothing)

                        End Try

                        Try
                            File.Move(Sumfile, Path.Combine(TargetFolder, Path.GetFileName(Sumfile)))
                        Catch ex As Exception
                            .Add("IO-error" & vbCrLf & ex.Message)
                            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                            SaveLog_Click(Me, Nothing)
                        End Try


                    Next


                Catch ex As Exception
                    .Add("IO-error" & vbCrLf & ex.Message)
                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                    SaveLog_Click(Me, Nothing)
                End Try

                .Add("Move sum files OK!")
                SaveLog_Click(Me, Nothing)
                Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                SumFiles = Directory.GetFiles(TargetFolder, CropNo & "_" & TargetCrop & "*.sum")

                ResultList.Clear()

                'sort sum files
                Dim dummylist As New List(Of String)
                Dim TargetLoc As String = ""
                Dim TempDummy As String = ""

                For dummycounter As Integer = 3 To PEARLAppFileArray.Count - 1

                    TempDummy = PEARLAppFileArray(dummycounter)
                    TargetLoc = (Split(PEARLAppFileArray(dummycounter), vbTab)).First
                    TargetLoc = TargetLoc.Substring(0, 4).ToUpper & ".sum"
                    TempDummy = (Filter(SumFiles, TargetLoc)).First
                    dummylist.Add(TempDummy)

                Next

                SumFiles = dummylist.ToArray


                For Each Sumfile In SumFiles

                    .Add("Sumfile : " & Sumfile)
                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                    SumArray = File.ReadAllLines(Sumfile)

                    SumFileInfo = New FileInfo(Sumfile)


                    If SumFileInfo.Length < CDbl(11) * 1024 Then

                        .Add("Sumfile corrupt ! :  " & Sumfile)
                        Me.Refresh()
                        MsgBox("Sumfile corrupt ! :  " & Sumfile, MsgBoxStyle.Critical)
                        Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                        Exit Sub

                    End If

                    If SumArray.Length < 60 Then

                        MsgBox("Resultfile " & Sumfile & " is empty !!", MsgBoxStyle.Critical)
                        .Add("Resultfile " & Sumfile & " is empty !!")
                        EmtySumFile = True

                    End If

                    DummyArray = Split(Path.GetFileNameWithoutExtension(Sumfile), "_")
                    DummyArray = Split(DummyArray(DummyArray.Length - 1), ".sum")

                    Select Case DummyArray(0).ToUpper

                        Case "Chat".ToUpper
                            Country = "Chateaudun"

                        Case "Hamb".ToUpper
                            Country = "Hamburg"

                        Case "Joki".ToUpper
                            Country = "Jokioinen"

                        Case "Krem".ToUpper
                            Country = "Kremsmuenster"

                        Case "Okeh".ToUpper
                            Country = "Okehampton"

                        Case "Piac".ToUpper
                            Country = "Piacenza"

                        Case "Port".ToUpper
                            Country = "Porto"

                        Case "Sevi".ToUpper
                            Country = "Sevilla"

                        Case "Thiv".ToUpper
                            Country = "Thiva"

                        Case Else

                            .Add("No Valid Scenarioname" & DummyArray(0).ToUpper)
                            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                            SaveLog_Click(Me, Nothing)
                            Exit Sub

                    End Select


                    Dummy = Country & Delimiter
                    .Add("Country : " & Country)
                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                    For Each Substance As String In Substances

                        If EmtySumFile Then
                            Dummy &= -99
                            Continue For
                        End If
                        .Add("Subst: " & Substance)

                        ' in order to be able to differentiate between something like _DA and _DADK, we have to add
                        ' space after the name
                        ' the output has several spaces after the Result_CODE anyway
                        DummyArray = Filter(SumArray, "Result_" & Substance & " ")

                        If DummyArray.Length = 0 Then

                            MsgBox("Wrong Subst name " & Substance, MsgBoxStyle.Critical)
                            .Add("Wrong Subst name " & Substance)
                            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                            SaveLog_Click(Me, Nothing)
                            Exit Sub

                        End If

                        DummyArray = DummyArray(0).Split(Deli, StringSplitOptions.RemoveEmptyEntries)

                        If Substance <> Substances(Substances.Length - 1) Then
                            Dummy &= DummyArray(DummyArray.Length - 1) & Delimiter
                        Else
                            Dummy &= Math.Round(CDbl(DummyArray(DummyArray.Length - 1)), 4)
                        End If

                        Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                    Next

                    ResultList.Add(Dummy)
                    Dummy = ""
                    EmtySumFile = False

                    Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                Next


                File.WriteAllLines(Path.Combine(TargetFolder, CropNo & "_" & TargetCrop & ".res"), ResultList.ToArray)

                .AddRange(ResultList.ToArray)

                ResList.Clear()
                Dummy = ""

                Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

            Next

            Me.ToolStripStatusLabel.Visible = False
            Me.ToolStripProgressBar.Visible = False

        End With

        Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

    End Sub

    Private Sub btnSubstInfoPEARL_Click(ByVal sender As System.Object, _
                                        ByVal e As System.EventArgs) Handles btnSubstInfoPEARL.Click

        Dim CMPArray As String() = {}
        Dim TargetCMP As String() = {}
        Dim DummyArray As String() = {}
        Dim CompoundListPEARL As String() = {}
        Dim CompoundListPELMO As String() = {}

        Dim Delimiter As Char() = {" "c}

        Dim OutputList As New List(Of String)

        Dim MolMas As String = ""
        Dim DT50Ref As String = ""
        Dim TemRefTra As String = ""
        Dim MolEntTra As String = ""
        Dim KomEql As String = ""
        Dim KSorEql As String = ""
        Dim ExpFre As String = ""
        Dim ExpLiqTra As String = ""
        Dim PreVapRef As String = ""
        Dim TemRefVap As String = ""
        Dim SlbWatRef As String = ""
        Dim FacUpt As String = ""
        Dim TemRefSlb As String = ""
        Dim CofDesRat As String = ""
        Dim FacSorNeqEql As String = ""
        Dim DummyValue As String = ""
        Dim StartIndex As Integer = 0
        Dim FraPrtDau As New List(Of String)
        Dim DummyString As String = ""
        Dim Test As String = ""
        OutputList.Clear()

        With Me.lsbLog.Items



            .Add("***************** PEARL SubstData ***************************")
            .Add("DART-No : '" & lblMNumberPEARL.Text & "'")

            Try
                File.WriteAllLines(Path.Combine(Me.txtMasterPath.Text, "DartNo.txt"), {lblMNumberPEARL.Text})
                .Add("File write OK '" & Path.Combine(Me.txtMasterPath.Text, "DartNo.txt") & "'")
            Catch ex As Exception
                MsgBox("Can't write 'DATRNo.txt" & vbNewLine & ex.Message, vbCritical)
                Exit Sub
            End Try


            SaveLog_Click(Me, Nothing)

            CMPArray = Directory.GetFiles(Me.txtPEARLTemplate.Text, "*.cmp")

            TargetCMP = File.ReadAllLines(CMPArray(0))
            .Add("Source file : '" & CMPArray.First & "'")

            Try
                DummyArray = File.ReadAllLines(Me.lbxApp.Items(0).ToString)
            Catch ex As Exception
                MsgBox("Select an .app file first", MsgBoxStyle.Critical)
                Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                Exit Sub
            End Try


            CompoundListPEARL = Split(DummyArray(2), ";")

            IndexSearchString = "Active Substance"
            StartIndex = Array.FindIndex(DummyArray, AddressOf getIndex)

            If StartIndex = -1 Then

                MsgBox("Can't find 'Active Substance'", MsgBoxStyle.Critical)
                .Add("Can't find 'Active Substance'")
                Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                SaveLog_Click(Me, Nothing)

                Exit Sub

            End If


            CompoundListPELMO = Split(DummyArray(StartIndex), ";")


            For Each member As String In CompoundListPEARL


                DummyValue &= "- "

                'molemass
                DummyArray = Filter(TargetCMP, "MolMas_" & member & " ")
                MolMas &= Split(DummyArray(0), " ").First & " "

                'dt50
                DummyArray = Filter(TargetCMP, "DT50Ref_" & member & " ")
                DT50Ref &= Split(DummyArray(0), " ").First & " "

                'dt50 at temp ? 
                DummyArray = Filter(TargetCMP, "TemRefTra_" & member & " ")
                TemRefTra &= Split(DummyArray(0), " ").First & " "

                'act. energy
                DummyArray = Filter(TargetCMP, "MolEntTra_" & member & " ")
                MolEntTra &= Split(DummyArray(0), " ").First & " "

                'Kom
                DummyArray = Filter(TargetCMP, "KomEql_" & member & " ")
                If DummyArray.Length = 1 Then
                    KomEql &= Split(DummyArray(0), " ").First & " "
                Else
                    KomEql &= "- "
                End If

                'KF
                DummyArray = Filter(TargetCMP, "KSorEql_" & member & " ")
                If DummyArray.Length = 1 Then
                    KSorEql &= Split(DummyArray(0), " ").First & " "
                Else
                    KSorEql &= "- "
                End If

                'Freundlich exponent
                DummyArray = Filter(TargetCMP, "ExpFre_" & member & " ")
                ExpFre &= Split(DummyArray(0), " ").First & " "

                'Walker exponent
                DummyArray = Filter(TargetCMP, "ExpLiqTra_" & member & " ")
                ExpLiqTra &= Split(DummyArray(0), " ").First & " "

                'vp
                DummyArray = Filter(TargetCMP, "PreVapRef_" & member & " ")
                PreVapRef &= Split(DummyArray(0), " ").First & " "

                'vp temp
                DummyArray = Filter(TargetCMP, "TemRefVap_" & member & " ")
                TemRefVap &= Split(DummyArray(0), " ").First & " "

                'solubility
                DummyArray = Filter(TargetCMP, "SlbWatRef_" & member & " ")
                SlbWatRef &= Split(DummyArray(0), " ").First & " "

                'solubility temp
                DummyArray = Filter(TargetCMP, "TemRefSlb_" & member & " ")
                TemRefSlb &= Split(DummyArray(0), " ").First & " "

                'plant uptake
                DummyArray = Filter(TargetCMP, "FacUpt_" & member & " ")
                FacUpt &= Split(DummyArray(0), " ").First & " "


                'desorption rate
                DummyArray = Filter(TargetCMP, "CofDesRat_" & member & " ")
                CofDesRat &= Split(DummyArray(0), " ").First & " "

                'equ. factor
                DummyArray = Filter(TargetCMP, "FacSorNeqEql_" & member & " ")
                FacSorNeqEql &= Split(DummyArray(0), " ").First & " "

            Next


            IndexSearchString = "table FraPrtDau (mol.mol-1)"
            StartIndex = Array.FindIndex(TargetCMP, AddressOf getIndex) + 1

            If StartIndex = -1 Then

                MsgBox("Can't find 'table FraPrtDau (mol.mol-1)'", MsgBoxStyle.Critical)
                .Add("Can't find 'table FraPrtDau (mol.mol-1)'")
                Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                SaveLog_Click(Me, Nothing)

                Exit Sub

            End If

            Dim tmpFracStr As String
            Dim tmpFracArr As String()
            Do While TargetCMP(StartIndex) <> "end_table"
                'FraPrtDau.Add(TargetCMP(StartIndex))
                tmpFracArr = TargetCMP(StartIndex).Split(New Char() {" "c})
                tmpFracStr = ""
                tmpFracStr = tmpFracArr(1) & " -> " & tmpFracArr(3) & ": " & tmpFracArr(0)

                DummyString &= tmpFracStr & CStr(IIf(TargetCMP(StartIndex + 1) <> "end_table", ";", ""))
                'DummyString &= TargetCMP(StartIndex) & CStr(IIf(TargetCMP(StartIndex + 1) <> "end_table", ";", ""))
                StartIndex += 1
            Loop



            OutputList.Add(MolMas)
            OutputList.Add(SlbWatRef)
            OutputList.Add(TemRefSlb)
            OutputList.Add(PreVapRef)
            OutputList.Add(TemRefVap)
            OutputList.Add(DT50Ref)
            OutputList.Add(DummyValue)
            OutputList.Add(MolEntTra)
            OutputList.Add(TemRefTra)
            OutputList.Add(ExpLiqTra)
            OutputList.Add(DummyValue)
            OutputList.Add(KomEql)
            OutputList.Add(KSorEql)
            OutputList.Add(ExpFre)
            OutputList.Add(FacUpt)
            OutputList.Add(CofDesRat)
            OutputList.Add(FacSorNeqEql)

            OutputList.Add(DummyString)


            If lblMNumberPEARL.Text <> "no coreinfo found" AndAlso
               Not File.Exists(Path.Combine(txtPEARLTemplate.Text,
                                            lblMNumberPEARL.Text & ".pdf")) Then

                If MsgBox("No CoreInfo found in " & txtPEARLTemplate.Text & vbCrLf &
                          "Expecting " & lblMNumberPEARL.Text & vbCrLf &
                                   "Continue ?",
                          vbYesNo) = MsgBoxResult.No Then
                    Exit Sub
                End If

            End If

            ' apparently replace("", ".pdf", "") returns nothing, which we don't want to have (problem with array.tostring())
            If lblMNumberPEARL.Text <> "no coreinfo found" Then
                OutputList.Add(Replace(lblMNumberPEARL.Text, ".pdf", ""))
            Else
                OutputList.Add("")
            End If
            File.WriteAllLines(Path.Combine(Path.GetDirectoryName(Me.lbxApp.Items(0).ToString), _
                                            "PEARL" &
                    txtPEARLPath.text.Substring(txtPEARLPath.text.Length - 3, 3) & ".cmp"),
                                        OutputList.ToArray)

            .AddRange(OutputList.ToArray)
            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
            SaveLog_Click(Me, Nothing)

        End With

    End Sub

    Private Sub btnSubstInfoPELMO_Click(ByVal sender As System.Object, _
                                        ByVal e As System.EventArgs) Handles btnSubstInfoPELMO.Click

        Dim CMPArray As String() = {}
        Dim TargetCMP As String() = {}
        Dim DummyArray As String() = {}
        Dim CompoundListPELMO As String() = {}

        Dim Delimiter As Char() = {" "c}

        Dim OutputList As New List(Of String)

        Dim MolMas As String = ""
        Dim DT50Ref As String = ""
        Dim degtemp As String = ""
        Dim Q10 As String = ""
        Dim degtemp_tot As String = ""
        Dim Q10_tot As String = ""
        Dim Koc As String = ""
        Dim pH As String = ""
        Dim pKa As String = ""
        Dim f_neq As String = ""
        Dim kdes As String = ""
        Dim moist_abs As String = ""
        Dim moist_rel As String = ""
        Dim moist_exp As String = ""
        Dim moist_abs_tot As String = ""
        Dim moist_rel_tot As String = ""
        Dim moist_exp_tot As String = ""
        Dim ExpFre As String = ""
        Dim vap_press As String = ""
        Dim solub As String = ""
        Dim plant_uptake_factor As String = ""
        Dim DummyValue As String = ""
        Dim StartIndex As Integer = 0
        Dim RateConst As Double = 0
        Dim RateConstString As String = ""

        With Me.lsbLog.Items


            .Add("***************** PELMO SubstData ***************************")

            .Add("DART-No : '" & lblMNumberPELMO.Text & "'")

            Try
                File.WriteAllLines(Path.Combine(Me.txtMasterPath.Text, "DartNo.txt"), {lblMNumberPELMO.Text})
                .Add("File write OK '" & Path.Combine(Me.txtMasterPath.Text, "DartNo.txt") & "'")
            Catch ex As Exception
                MsgBox("Can't write 'DATRNo.txt" & vbNewLine & ex.Message, vbCritical)
                Exit Sub
            End Try


            OutputList.Clear()

            CMPArray = Directory.GetFiles(Me.txtPELMOTemplate.Text, "*.psm")

            TargetCMP = File.ReadAllLines(CMPArray.First)
            .Add("Source file : '" & CMPArray.First & "'")
            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

            Try
                DummyArray = File.ReadAllLines(Me.lbxApp.Items(0).ToString)
            Catch ex As Exception
                If Me.lbxApp.Items.Count = 0 Then
                    MsgBox("Defins apps first", vbCritical)
                    Exit Sub

                Else

                    MsgBox("Error" & vbNewLine & ex.Message, vbCritical)
                    Exit Sub
                End If
            End Try


            IndexSearchString = "Active Substance"
            StartIndex = Array.FindIndex(DummyArray, AddressOf getIndex)

            If StartIndex = -1 Then

                MsgBox("Can't find 'Active Substance'", MsgBoxStyle.Critical)
                .Add("Can't find 'Active Substance'")
                Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                Exit Sub

            End If

            CompoundListPELMO = Split(DummyArray(StartIndex), ";")


            IndexSearchString = "<VOLATILIZATION>"
            StartIndex = Array.FindIndex(TargetCMP, AddressOf getIndex)

            If StartIndex = -1 Then

                MsgBox("Can't find '<VOLATILIZATION>'", MsgBoxStyle.Critical)
                .Add("Can't find '<VOLATILIZATION>'")
                Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

                Exit Sub

            End If


            DummyArray = TargetCMP(StartIndex + 2).Split(Delimiter, StringSplitOptions.RemoveEmptyEntries)
            solub &= DummyArray(1) & " "
            MolMas &= DummyArray(2) & " "
            vap_press &= DummyArray(3) & " "


            For Each member As String In CompoundListPELMO

                If member <> "Active Substance" Then
                    solub &= "-" & " "
                    vap_press &= "-" & " "

                    Do While TargetCMP(StartIndex) <> "<MOLMASS>"
                        StartIndex += 1
                    Loop

                    MolMas &= Trim(TargetCMP(StartIndex + 1)) & " "

                Else

                    IndexSearchString = "<VOLATILIZATION>"
                    StartIndex = Array.FindIndex(TargetCMP, AddressOf getIndex)

                    If StartIndex = -1 Then

                        MsgBox("Can't find '<VOLATILIZATION>'", MsgBoxStyle.Critical)
                        .Add("Can't find '<VOLATILIZATION>'")
                        Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1
                        Exit Sub

                    End If

                End If

                Do While TargetCMP(StartIndex) <> "<PLANT UPTAKE>"
                    StartIndex += 1
                Loop

                DummyArray = TargetCMP(StartIndex + 1).Split(Delimiter, StringSplitOptions.RemoveEmptyEntries)
                plant_uptake_factor &= DummyArray.First & " "


                Do While TargetCMP(StartIndex) <> "<DEGRADATION>"
                    StartIndex += 1
                Loop

                StartIndex += 1

                Dim Dummy As String = ""

                Do While TargetCMP(StartIndex) <> "<END DEGRADATION>"

                    DummyArray = TargetCMP(StartIndex + 1).Split(Delimiter, StringSplitOptions.RemoveEmptyEntries)

                    Dummy = TargetCMP(StartIndex + 1)

                    If Not TargetCMP(StartIndex + 1).EndsWith(">") Then
                        Exit Do
                    End If


                    Try

                        RateConst += Double.Parse(DummyArray.First)

                        If Double.Parse(DummyArray.First) = 0 Then

                            StartIndex += 1
                            Continue Do

                        End If
                    Catch ex As Exception
                        MsgBox("Can 't parse " & DummyArray.First)
                    End Try


                    'DummyValue &= DummyArray.First & " " & member & " -> " & Replace(Replace(DummyArray.Last, "<Met ", ""), ">", "")
                    DummyValue &= member & " -> " & Replace(Replace(Replace(DummyArray.Last, "BR/CO2", "Met BR/CO2"), "<Met ", ""), ">", "") & ": " & DummyArray.First

                    If member <> CompoundListPELMO.Last Then
                        DummyValue &= ";"
                    End If


                    'degtemp
                    If degtemp <> "" AndAlso degtemp <> DummyArray(1) Then _
                                MsgBox("Error in " & CMPArray(0) & vbCrLf & _
                                        TargetCMP(StartIndex) & vbCrLf & _
                                        "degtemp differs !", MsgBoxStyle.Critical)

                    degtemp = DummyArray(1)

                    'q10
                    If Q10 <> "" AndAlso Q10 <> DummyArray(2) Then _
                                MsgBox("Error in " & CMPArray(0) & vbCrLf & _
                                        TargetCMP(StartIndex) & vbCrLf & _
                                        "Q10 differs !", MsgBoxStyle.Critical)

                    Q10 = DummyArray(2)

                    'moist_abs
                    If moist_abs <> "" AndAlso moist_abs <> DummyArray(3) Then _
                                MsgBox("Error in " & CMPArray(0) & vbCrLf & _
                                        TargetCMP(StartIndex) & vbCrLf & _
                                        "moist_abs differs !", MsgBoxStyle.Critical)

                    moist_abs = DummyArray(3)

                    'moist_rel
                    If moist_rel <> "" AndAlso moist_rel <> DummyArray(4) Then _
                                MsgBox("Error in " & CMPArray(0) & vbCrLf & _
                                        TargetCMP(StartIndex) & vbCrLf & _
                                        "moist_rel differs !", MsgBoxStyle.Critical)

                    moist_rel = DummyArray(4)

                    'moist_exp
                    If moist_exp <> "" AndAlso moist_exp <> DummyArray(5) Then _
                                MsgBox("Error in " & CMPArray(0) & vbCrLf & _
                                        TargetCMP(StartIndex) & vbCrLf & _
                                        "moist_exp differs !", MsgBoxStyle.Critical)

                    moist_exp = DummyArray(5)


                    StartIndex += 1

                Loop

                RateConstString &= CStr(RateConst) & " "
                RateConst = 0


                Do While TargetCMP(StartIndex) <> "<ADSORPTION>"
                    StartIndex += 1
                Loop

                DummyArray = TargetCMP(StartIndex + 2).Split(Delimiter, StringSplitOptions.RemoveEmptyEntries)


                Koc &= DummyArray(0) & " "
                ExpFre &= DummyArray(1) & " "
                pH &= DummyArray(2) & " "
                pKa &= DummyArray(3) & " "
                f_neq &= DummyArray(10) & " "
                kdes &= DummyArray(11) & " "


                degtemp_tot &= degtemp & " "
                Q10_tot &= Q10 & " "
                moist_abs_tot &= moist_abs & " "
                moist_rel_tot &= moist_rel & " "
                moist_exp_tot &= moist_exp & " "

                degtemp = ""
                Q10 = ""
                moist_abs = ""
                moist_rel = ""
                moist_exp = ""


                Do While TargetCMP(StartIndex) <> "###############################################"
                    StartIndex += 1
                    If StartIndex = TargetCMP.Length Then Exit For
                Loop
                StartIndex += 5


            Next

            OutputList.Add(MolMas)
            OutputList.Add(solub)
            OutputList.Add(vap_press)

            OutputList.Add(RateConstString)
            OutputList.Add(degtemp_tot)
            OutputList.Add(Q10_tot)

            OutputList.Add(moist_abs_tot)
            OutputList.Add(moist_rel_tot)
            OutputList.Add(moist_exp_tot)

            OutputList.Add(Koc)
            OutputList.Add(pH)
            OutputList.Add(pKa)
            OutputList.Add(ExpFre)
            OutputList.Add(plant_uptake_factor)
            OutputList.Add(f_neq)
            OutputList.Add(kdes)



            OutputList.Add(DummyValue)


            If lblMNumberPELMO.Text <> "no coreinfo found" AndAlso
               Not File.Exists(Path.Combine(txtPELMOTemplate.Text, lblMNumberPELMO.Text & ".pdf")) Then

                If MsgBox("No CoreInfo found in " & txtPELMOTemplate.Text & vbCrLf &
                          "Expecting " & lblMNumberPELMO.Text & vbCrLf &
                                   "Continue ?",
                          vbYesNo) = MsgBoxResult.No Then
                    Exit Sub
                End If

            End If

            'Dim x As String = "abcdef"

            'x = Replace(x, ".pdf", "")
            'x = Replace(lblMNumberPELMO.Text, ".pdf", "")
            ' apparently replace("", ".pdf", "") returns Nothing!
            If lblMNumberPELMO.Text <> "no coreinfo found" Then
                OutputList.Add(Replace(lblMNumberPELMO.Text, ".pdf", ""))
            Else
                OutputList.Add("")
            End If

            File.WriteAllLines(Path.Combine(Path.GetDirectoryName(Me.lbxApp.Items(0).ToString),
                                            "PELMO" & txtPELMOPath.Text.Substring(txtPELMOPath.Text.Length - 3, 3) & ".cmp"),
                                        OutputList.ToArray)

            .AddRange(OutputList.ToArray)
            Me.lsbLog.SelectedIndex = Me.lsbLog.Items.Count - 1

        End With

    End Sub


    Private Sub btnMakePELMObat_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Dim OldPELMOBat As String = ""
        Dim OldPELMObatArray As String() = {}
        Dim NoOfBatches As Integer = 0
        Dim JobList As New List(Of String)
        Dim JobsPerBatch As Integer = 0
        Dim ActBatchNo As Integer = 1
        Dim HelpCounter As Integer = 0


        Try
            OldPELMOBat = Path.Combine(txtPELMOPath.Text, "FOCUS\batch.bat")
            OldPELMObatArray = File.ReadAllLines(OldPELMOBat, System.Text.Encoding.Default)
            OldPELMObatArray = Filter(OldPELMObatArray, "if exist ", False)
            File.WriteAllLines(OldPELMOBat, OldPELMObatArray, System.Text.Encoding.Default)
        Catch ex As Exception

        End Try


    End Sub

    Private Sub btnLoadFromConfig_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoadFromConfig.Click



        Dim SettingsPath As String = Path.Combine(Me.txtMasterPath.Text, "FOCUSGWToolSettings.xml")

        If Not File.Exists(SettingsPath) Then

            Dim myOFD As New OpenFileDialog

            With myOFD

                .Reset()
                .Multiselect = False
                .CheckFileExists = True
                .InitialDirectory = Path.Combine(PROUTTMasterpath, "Projects")

                .Filter = "FOCUSGWToolSettings files (FOCUSGWToolSettings.xml)|FOCUSGWToolSettings.xml|All files (*.*)|*.*"


                If .ShowDialog = DialogResult.OK Then
                    SettingsPath = .FileName

                Else
                    Exit Sub
                End If


            End With



        End If

        Try
            MyConfig = CType(mySettings.LoadXML2Class(GetType(mySettings),
                                                             Path.Combine(Me.txtMasterPath.Text, "FOCUSGWToolSettings.xml")), 
                                                         mySettings)
        Catch ex As Exception
            MsgBox("IO error reading settings" & vbNewLine & ex.Message)
        End Try

        With MyConfig

            Me.txtMasterPath.Text = .Materpath

            Me.txtPEARLTemplate.Text = .PEARLTemplate
            Me.txtPELMOTemplate.Text = .PELMOTemplate


            lblMNumberPEARL_Click(Me, Nothing)
            lblMNumberPELMO_Click(Me, Nothing)

            Me.txtPELMOPath.Text = .PELMOPath

        End With





    End Sub

    Private Sub btnSave2Config_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave2Config.Click


        With MyConfig

            .Materpath = Me.txtMasterPath.Text

            .PEARLTemplate = Me.txtPEARLTemplate.Text
            .PELMOTemplate = Me.txtPELMOTemplate.Text

            .PELMOPath = Me.txtPELMOPath.Text

        End With



        Try
            mySettings.SaveClass2XML(MyConfig, GetType(mySettings), Path.Combine(Me.txtMasterPath.Text, "FOCUSGWToolSettings.xml"))
        Catch ex As Exception
            MsgBox("IO error saving settings" & vbNewLine & ex.Message)
        End Try


    End Sub

    <DebuggerStepThrough()> _
    Private Sub SaveLog_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveLog.Click

        Dim dummylist As New List(Of String)

        For Each member As String In Me.lsbLog.Items
            dummylist.Add(member)
        Next

        File.WriteAllLines(Path.Combine(Me.txtMasterPath.Text, "PROUTT.log"), dummylist.ToArray)

    End Sub

    'Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    '    Dim fileinfoi As FileInfo

    '    fileinfoi = New FileInfo("Z:\PFMEY\Training\Masterpath\Crop01_TOBACCO\PEARL333\Crop01_TOBACCO_THIV.sum")

    'End Sub


    Private Sub Form1_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed

        SaveLog_Click(Me, Nothing)


    End Sub


    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub lblMNumberPEARL_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lblMNumberPEARL.Click

        Dim countMDocs As Integer

        Try
            countMDocs = Directory.GetFiles(txtPEARLTemplate.Text, "*.pdf").Count
            If countMDocs > 1 Then
                MsgBox("Only one CoreInfo is allowed (PEARL)", vbCritical)
                Exit Sub
            ElseIf countMDocs = 0 Then
                MsgBox("No core info found (PEARL)", vbCritical)
                Exit Sub
            End If

            lblMNumberPEARL.Text = Path.GetFileName(Directory.GetFiles(txtPEARLTemplate.Text, "*.pdf").First)

        Catch ex As Exception
            MsgBox("Error getting CoreInfo", vbCritical)
        End Try


    End Sub

    Private Sub lblMNumberPELMO_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lblMNumberPELMO.Click

        Dim countMDocs As Integer

        Try
            countMDocs = Directory.GetFiles(txtPELMOTemplate.Text, "*.pdf").Count
            If countMDocs > 1 Then
                MsgBox("Only one CoreInfo is allowed (PELMO)", vbCritical)
                Exit Sub
            ElseIf countMDocs = 0 Then
                MsgBox("No core info found (PELMO)", vbCritical)
                Exit Sub
            End If

            lblMNumberPELMO.Text = Path.GetFileName(Directory.GetFiles(txtPELMOTemplate.Text, "*.pdf").First)

        Catch ex As Exception
            MsgBox("Error getting CoreInfo", vbCritical)
        End Try

    End Sub

    Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReset.Click
        ' perform reset!
        Me.DialogResult = DialogResult.Retry
        Me.Close()
    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
        myCaller.cForm = Nothing
    End Sub

    Private Sub GroupBoxCMPData_Enter(sender As Object, e As EventArgs) Handles GroupBoxCMPData.Enter

    End Sub

End Class


Public Class mySettings

    Public Sub New()

    End Sub

    Public Sub New(ByVal Materpath As String,
                   ByVal PELMOPath As String,
                   ByVal PEARLTemplate As String,
                   ByVal PELMOTemplate As String)

        Me.Materpath = Materpath
        Me.PELMOPath = PELMOPath
        Me.PEARLTemplate = PEARLTemplate
        Me.PELMOTemplate = PELMOTemplate

    End Sub

    Public Property Materpath As String

    Public Property PELMOPath As String

    Public Property PEARLTemplate As String

    Public Property PELMOTemplate As String


#Region "XML Load/Save"

    <DebuggerStepThrough()>
    Shared Sub SaveClass2XML(ByVal Class2Save As Object, _
                             ByVal ClassType As Type, _
                             ByVal XMLFileName As String)

        If Not Directory.Exists(Path.GetDirectoryName(XMLFileName)) Then _
            Throw New DirectoryNotFoundException("No valid XML Path")

        Try

            Dim mySerializer As Xml.Serialization.XmlSerializer = _
                            New Xml.Serialization.XmlSerializer(ClassType)

            Dim myWriter As IO.StreamWriter = _
                        New IO.StreamWriter(XMLFileName)

            mySerializer.Serialize(myWriter, Class2Save)
            myWriter.Close()

        Catch ex As Exception
            Throw (ex)
        End Try

    End Sub

    <DebuggerStepThrough()>
    Shared Function LoadXML2Class(ByVal ClassType As Type, _
                                  ByVal XMLFileName As String) As Object

        Dim TargetClass As New Object

        Try

            Dim mySerializer As Xml.Serialization.XmlSerializer = _
                                    New Xml.Serialization.XmlSerializer(ClassType)

            ' To read the file, create a FileStream.
            Dim myFileStream As IO.FileStream = _
                            New IO.FileStream(XMLFileName, IO.FileMode.Open)

            ' Call the Deserialize method and cast to the object type.
            TargetClass = mySerializer.Deserialize(myFileStream)


            myFileStream.Close()

            Return TargetClass

        Catch ex As Exception
            Throw New ArgumentException(ex.Message)
        End Try

    End Function

#End Region

End Class