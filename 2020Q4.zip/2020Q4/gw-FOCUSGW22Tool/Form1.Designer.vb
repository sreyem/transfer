﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnPEARL333 = New System.Windows.Forms.Button()
        Me.btnPELMO32 = New System.Windows.Forms.Button()
        Me.btnGetApp = New System.Windows.Forms.Button()
        Me.txtMasterPath = New System.Windows.Forms.TextBox()
        Me.lblMasterPath = New System.Windows.Forms.Label()
        Me.lbxApp = New System.Windows.Forms.ListBox()
        Me.lblPEARLPath = New System.Windows.Forms.Label()
        Me.lblPELMOPath = New System.Windows.Forms.Label()
        Me.txtPEARLTemplate = New System.Windows.Forms.TextBox()
        Me.txtPELMOTemplate = New System.Windows.Forms.TextBox()
        Me.lblPEARLTemplate = New System.Windows.Forms.Label()
        Me.lblPELMOTemplate = New System.Windows.Forms.Label()
        Me.btnStartPELMO = New System.Windows.Forms.Button()
        Me.btnEvaluatePELMO = New System.Windows.Forms.Button()
        Me.btnEvaluatePEARL = New System.Windows.Forms.Button()
        Me.btnSubstInfoPEARL = New System.Windows.Forms.Button()
        Me.btnSubstInfoPELMO = New System.Windows.Forms.Button()
        Me.btnSave2Config = New System.Windows.Forms.Button()
        Me.btnLoadFromConfig = New System.Windows.Forms.Button()
        Me.lsbLog = New System.Windows.Forms.ListBox()
        Me.ContextMenuStriplsblog = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.SaveLog = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBoxFOCUSExecPaths = New System.Windows.Forms.GroupBox()
        Me.txtPELMOPath = New System.Windows.Forms.TextBox()
        Me.txtPEARLPath = New System.Windows.Forms.TextBox()
        Me.GroupBoxCMPData = New System.Windows.Forms.GroupBox()
        Me.lblValPelmo = New System.Windows.Forms.Label()
        Me.lblValPearl = New System.Windows.Forms.Label()
        Me.btnValPearl = New System.Windows.Forms.Button()
        Me.btnValPelmo = New System.Windows.Forms.Button()
        Me.lblMNumberPEARL = New System.Windows.Forms.Label()
        Me.lblMNumberPELMO = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripProgressBar = New System.Windows.Forms.ToolStripProgressBar()
        Me.ToolStripStatusLabel = New System.Windows.Forms.ToolStripStatusLabel()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.chkKeepPelmoData = New System.Windows.Forms.CheckBox()
        Me.btnValMaster = New System.Windows.Forms.Button()
        Me.lblValMaster = New System.Windows.Forms.Label()
        Me.ContextMenuStriplsblog.SuspendLayout()
        Me.GroupBoxFOCUSExecPaths.SuspendLayout()
        Me.GroupBoxCMPData.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnPEARL333
        '
        Me.btnPEARL333.Enabled = False
        Me.btnPEARL333.Location = New System.Drawing.Point(15, 456)
        Me.btnPEARL333.Name = "btnPEARL333"
        Me.btnPEARL333.Size = New System.Drawing.Size(106, 34)
        Me.btnPEARL333.TabIndex = 4
        Me.btnPEARL333.Text = "PEARL"
        Me.btnPEARL333.UseVisualStyleBackColor = True
        '
        'btnPELMO32
        '
        Me.btnPELMO32.Enabled = False
        Me.btnPELMO32.Location = New System.Drawing.Point(132, 456)
        Me.btnPELMO32.Name = "btnPELMO32"
        Me.btnPELMO32.Size = New System.Drawing.Size(106, 34)
        Me.btnPELMO32.TabIndex = 4
        Me.btnPELMO32.Text = "PELMO"
        Me.btnPELMO32.UseVisualStyleBackColor = True
        '
        'btnGetApp
        '
        Me.btnGetApp.Enabled = False
        Me.btnGetApp.Location = New System.Drawing.Point(132, 366)
        Me.btnGetApp.Name = "btnGetApp"
        Me.btnGetApp.Size = New System.Drawing.Size(106, 34)
        Me.btnGetApp.TabIndex = 4
        Me.btnGetApp.Text = "get *.app files"
        Me.btnGetApp.UseVisualStyleBackColor = True
        '
        'txtMasterPath
        '
        Me.txtMasterPath.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMasterPath.Location = New System.Drawing.Point(136, 56)
        Me.txtMasterPath.Name = "txtMasterPath"
        Me.txtMasterPath.Size = New System.Drawing.Size(438, 20)
        Me.txtMasterPath.TabIndex = 6
        Me.txtMasterPath.Text = "C:\Temp\testFOCUSgw\B1"
        '
        'lblMasterPath
        '
        Me.lblMasterPath.AutoSize = True
        Me.lblMasterPath.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMasterPath.Location = New System.Drawing.Point(23, 59)
        Me.lblMasterPath.Name = "lblMasterPath"
        Me.lblMasterPath.Size = New System.Drawing.Size(75, 13)
        Me.lblMasterPath.TabIndex = 7
        Me.lblMasterPath.Text = "Master Path"
        '
        'lbxApp
        '
        Me.lbxApp.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbxApp.FormattingEnabled = True
        Me.lbxApp.Location = New System.Drawing.Point(266, 323)
        Me.lbxApp.Name = "lbxApp"
        Me.lbxApp.Size = New System.Drawing.Size(446, 121)
        Me.lbxApp.TabIndex = 8
        '
        'lblPEARLPath
        '
        Me.lblPEARLPath.AutoSize = True
        Me.lblPEARLPath.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPEARLPath.Location = New System.Drawing.Point(14, 21)
        Me.lblPEARLPath.Name = "lblPEARLPath"
        Me.lblPEARLPath.Size = New System.Drawing.Size(67, 13)
        Me.lblPEARLPath.TabIndex = 7
        Me.lblPEARLPath.Text = "PEARL Path"
        '
        'lblPELMOPath
        '
        Me.lblPELMOPath.AutoSize = True
        Me.lblPELMOPath.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPELMOPath.Location = New System.Drawing.Point(14, 47)
        Me.lblPELMOPath.Name = "lblPELMOPath"
        Me.lblPELMOPath.Size = New System.Drawing.Size(69, 13)
        Me.lblPELMOPath.TabIndex = 7
        Me.lblPELMOPath.Text = "PELMO Path"
        '
        'txtPEARLTemplate
        '
        Me.txtPEARLTemplate.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPEARLTemplate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPEARLTemplate.Location = New System.Drawing.Point(121, 22)
        Me.txtPEARLTemplate.Name = "txtPEARLTemplate"
        Me.txtPEARLTemplate.Size = New System.Drawing.Size(438, 20)
        Me.txtPEARLTemplate.TabIndex = 6
        Me.txtPEARLTemplate.Text = "C:\Temp\testFOCUSgw\B1\CompoundTemplates\PEARL444"
        Me.ToolTip1.SetToolTip(Me.txtPEARLTemplate, "testtooltip")
        '
        'txtPELMOTemplate
        '
        Me.txtPELMOTemplate.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPELMOTemplate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPELMOTemplate.Location = New System.Drawing.Point(121, 66)
        Me.txtPELMOTemplate.Name = "txtPELMOTemplate"
        Me.txtPELMOTemplate.Size = New System.Drawing.Size(438, 20)
        Me.txtPELMOTemplate.TabIndex = 6
        Me.txtPELMOTemplate.Text = "C:\Temp\testFOCUSgw\B1\CompoundTemplates\PELMO553"
        '
        'lblPEARLTemplate
        '
        Me.lblPEARLTemplate.AutoSize = True
        Me.lblPEARLTemplate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPEARLTemplate.Location = New System.Drawing.Point(15, 25)
        Me.lblPEARLTemplate.Name = "lblPEARLTemplate"
        Me.lblPEARLTemplate.Size = New System.Drawing.Size(90, 13)
        Me.lblPEARLTemplate.TabIndex = 7
        Me.lblPEARLTemplate.Text = "PEARL cmp Path"
        '
        'lblPELMOTemplate
        '
        Me.lblPELMOTemplate.AutoSize = True
        Me.lblPELMOTemplate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPELMOTemplate.Location = New System.Drawing.Point(15, 69)
        Me.lblPELMOTemplate.Name = "lblPELMOTemplate"
        Me.lblPELMOTemplate.Size = New System.Drawing.Size(91, 13)
        Me.lblPELMOTemplate.TabIndex = 7
        Me.lblPELMOTemplate.Text = "PELMO psm Path"
        '
        'btnStartPELMO
        '
        Me.btnStartPELMO.Enabled = False
        Me.btnStartPELMO.Location = New System.Drawing.Point(132, 496)
        Me.btnStartPELMO.Name = "btnStartPELMO"
        Me.btnStartPELMO.Size = New System.Drawing.Size(106, 34)
        Me.btnStartPELMO.TabIndex = 4
        Me.btnStartPELMO.Text = "Start PELMO"
        Me.btnStartPELMO.UseVisualStyleBackColor = True
        '
        'btnEvaluatePELMO
        '
        Me.btnEvaluatePELMO.Enabled = False
        Me.btnEvaluatePELMO.Location = New System.Drawing.Point(132, 585)
        Me.btnEvaluatePELMO.Name = "btnEvaluatePELMO"
        Me.btnEvaluatePELMO.Size = New System.Drawing.Size(106, 34)
        Me.btnEvaluatePELMO.TabIndex = 4
        Me.btnEvaluatePELMO.Text = "Evaluate PELMO"
        Me.btnEvaluatePELMO.UseVisualStyleBackColor = True
        '
        'btnEvaluatePEARL
        '
        Me.btnEvaluatePEARL.Enabled = False
        Me.btnEvaluatePEARL.Location = New System.Drawing.Point(15, 585)
        Me.btnEvaluatePEARL.Name = "btnEvaluatePEARL"
        Me.btnEvaluatePEARL.Size = New System.Drawing.Size(106, 34)
        Me.btnEvaluatePEARL.TabIndex = 4
        Me.btnEvaluatePEARL.Text = "Evaluate PEARL"
        Me.btnEvaluatePEARL.UseVisualStyleBackColor = True
        '
        'btnSubstInfoPEARL
        '
        Me.btnSubstInfoPEARL.Enabled = False
        Me.btnSubstInfoPEARL.Location = New System.Drawing.Point(15, 625)
        Me.btnSubstInfoPEARL.Name = "btnSubstInfoPEARL"
        Me.btnSubstInfoPEARL.Size = New System.Drawing.Size(106, 34)
        Me.btnSubstInfoPEARL.TabIndex = 4
        Me.btnSubstInfoPEARL.Text = "Subst Info PEARL"
        Me.btnSubstInfoPEARL.UseVisualStyleBackColor = True
        '
        'btnSubstInfoPELMO
        '
        Me.btnSubstInfoPELMO.Enabled = False
        Me.btnSubstInfoPELMO.Location = New System.Drawing.Point(132, 625)
        Me.btnSubstInfoPELMO.Name = "btnSubstInfoPELMO"
        Me.btnSubstInfoPELMO.Size = New System.Drawing.Size(106, 34)
        Me.btnSubstInfoPELMO.TabIndex = 4
        Me.btnSubstInfoPELMO.Text = "Subst Info PELMO"
        Me.btnSubstInfoPELMO.UseVisualStyleBackColor = True
        '
        'btnSave2Config
        '
        Me.btnSave2Config.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSave2Config.Location = New System.Drawing.Point(319, 12)
        Me.btnSave2Config.Name = "btnSave2Config"
        Me.btnSave2Config.Size = New System.Drawing.Size(135, 30)
        Me.btnSave2Config.TabIndex = 9
        Me.btnSave2Config.Text = "Save to Config"
        Me.btnSave2Config.UseVisualStyleBackColor = True
        Me.btnSave2Config.Visible = False
        '
        'btnLoadFromConfig
        '
        Me.btnLoadFromConfig.Location = New System.Drawing.Point(137, 12)
        Me.btnLoadFromConfig.Name = "btnLoadFromConfig"
        Me.btnLoadFromConfig.Size = New System.Drawing.Size(135, 30)
        Me.btnLoadFromConfig.TabIndex = 9
        Me.btnLoadFromConfig.Text = "Load from Config"
        Me.btnLoadFromConfig.UseVisualStyleBackColor = True
        Me.btnLoadFromConfig.Visible = False
        '
        'lsbLog
        '
        Me.lsbLog.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lsbLog.ContextMenuStrip = Me.ContextMenuStriplsblog
        Me.lsbLog.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lsbLog.FormattingEnabled = True
        Me.lsbLog.ItemHeight = 18
        Me.lsbLog.Location = New System.Drawing.Point(266, 456)
        Me.lsbLog.Name = "lsbLog"
        Me.lsbLog.Size = New System.Drawing.Size(447, 238)
        Me.lsbLog.TabIndex = 10
        '
        'ContextMenuStriplsblog
        '
        Me.ContextMenuStriplsblog.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SaveLog})
        Me.ContextMenuStriplsblog.Name = "ContextMenuStriplsblog"
        Me.ContextMenuStriplsblog.Size = New System.Drawing.Size(119, 26)
        '
        'SaveLog
        '
        Me.SaveLog.Name = "SaveLog"
        Me.SaveLog.Size = New System.Drawing.Size(118, 22)
        Me.SaveLog.Text = "SaveLog"
        '
        'GroupBoxFOCUSExecPaths
        '
        Me.GroupBoxFOCUSExecPaths.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBoxFOCUSExecPaths.Controls.Add(Me.txtPELMOPath)
        Me.GroupBoxFOCUSExecPaths.Controls.Add(Me.txtPEARLPath)
        Me.GroupBoxFOCUSExecPaths.Controls.Add(Me.lblPEARLPath)
        Me.GroupBoxFOCUSExecPaths.Controls.Add(Me.lblPELMOPath)
        Me.GroupBoxFOCUSExecPaths.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxFOCUSExecPaths.Location = New System.Drawing.Point(15, 99)
        Me.GroupBoxFOCUSExecPaths.Name = "GroupBoxFOCUSExecPaths"
        Me.GroupBoxFOCUSExecPaths.Size = New System.Drawing.Size(698, 76)
        Me.GroupBoxFOCUSExecPaths.TabIndex = 11
        Me.GroupBoxFOCUSExecPaths.TabStop = False
        Me.GroupBoxFOCUSExecPaths.Text = "FOCUS  PEARL/PELMO Environment (weather data, soil data , executables etc.)"
        '
        'txtPELMOPath
        '
        Me.txtPELMOPath.Enabled = False
        Me.txtPELMOPath.Location = New System.Drawing.Point(122, 44)
        Me.txtPELMOPath.Name = "txtPELMOPath"
        Me.txtPELMOPath.Size = New System.Drawing.Size(317, 20)
        Me.txtPELMOPath.TabIndex = 11
        Me.txtPELMOPath.Text = "Z:\_PROUTT\_software\FOCUSPELMO553"
        '
        'txtPEARLPath
        '
        Me.txtPEARLPath.Enabled = False
        Me.txtPEARLPath.Location = New System.Drawing.Point(122, 18)
        Me.txtPEARLPath.Name = "txtPEARLPath"
        Me.txtPEARLPath.Size = New System.Drawing.Size(317, 20)
        Me.txtPEARLPath.TabIndex = 10
        Me.txtPEARLPath.Text = "Z:\_PROUTT\_software\FOCUSPEARL444"
        '
        'GroupBoxCMPData
        '
        Me.GroupBoxCMPData.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBoxCMPData.Controls.Add(Me.lblValPelmo)
        Me.GroupBoxCMPData.Controls.Add(Me.lblValPearl)
        Me.GroupBoxCMPData.Controls.Add(Me.btnValPearl)
        Me.GroupBoxCMPData.Controls.Add(Me.btnValPelmo)
        Me.GroupBoxCMPData.Controls.Add(Me.lblMNumberPEARL)
        Me.GroupBoxCMPData.Controls.Add(Me.txtPEARLTemplate)
        Me.GroupBoxCMPData.Controls.Add(Me.lblMNumberPELMO)
        Me.GroupBoxCMPData.Controls.Add(Me.lblPEARLTemplate)
        Me.GroupBoxCMPData.Controls.Add(Me.txtPELMOTemplate)
        Me.GroupBoxCMPData.Controls.Add(Me.lblPELMOTemplate)
        Me.GroupBoxCMPData.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxCMPData.Location = New System.Drawing.Point(15, 191)
        Me.GroupBoxCMPData.Name = "GroupBoxCMPData"
        Me.GroupBoxCMPData.Size = New System.Drawing.Size(698, 115)
        Me.GroupBoxCMPData.TabIndex = 12
        Me.GroupBoxCMPData.TabStop = False
        Me.GroupBoxCMPData.Text = "PEARL/PELMO Compound Data (*.prl, *.cmp, Complete.psm)"
        '
        'lblValPelmo
        '
        Me.lblValPelmo.AutoSize = True
        Me.lblValPelmo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblValPelmo.ForeColor = System.Drawing.Color.Red
        Me.lblValPelmo.Location = New System.Drawing.Point(656, 69)
        Me.lblValPelmo.Name = "lblValPelmo"
        Me.lblValPelmo.Size = New System.Drawing.Size(37, 13)
        Me.lblValPelmo.TabIndex = 18
        Me.lblValPelmo.Text = "invalid"
        '
        'lblValPearl
        '
        Me.lblValPearl.AutoSize = True
        Me.lblValPearl.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblValPearl.ForeColor = System.Drawing.Color.Red
        Me.lblValPearl.Location = New System.Drawing.Point(656, 25)
        Me.lblValPearl.Name = "lblValPearl"
        Me.lblValPearl.Size = New System.Drawing.Size(37, 13)
        Me.lblValPearl.TabIndex = 19
        Me.lblValPearl.Text = "invalid"
        '
        'btnValPearl
        '
        Me.btnValPearl.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnValPearl.Location = New System.Drawing.Point(565, 20)
        Me.btnValPearl.Name = "btnValPearl"
        Me.btnValPearl.Size = New System.Drawing.Size(85, 23)
        Me.btnValPearl.TabIndex = 17
        Me.btnValPearl.Text = "Validate path"
        Me.btnValPearl.UseVisualStyleBackColor = True
        '
        'btnValPelmo
        '
        Me.btnValPelmo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnValPelmo.Location = New System.Drawing.Point(565, 64)
        Me.btnValPelmo.Name = "btnValPelmo"
        Me.btnValPelmo.Size = New System.Drawing.Size(85, 23)
        Me.btnValPelmo.TabIndex = 18
        Me.btnValPelmo.Text = "Validate path"
        Me.btnValPelmo.UseVisualStyleBackColor = True
        '
        'lblMNumberPEARL
        '
        Me.lblMNumberPEARL.AutoSize = True
        Me.lblMNumberPEARL.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMNumberPEARL.ForeColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblMNumberPEARL.Location = New System.Drawing.Point(119, 45)
        Me.lblMNumberPEARL.Name = "lblMNumberPEARL"
        Me.lblMNumberPEARL.Size = New System.Drawing.Size(90, 13)
        Me.lblMNumberPEARL.TabIndex = 8
        Me.lblMNumberPEARL.Text = "no coreinfo found"
        '
        'lblMNumberPELMO
        '
        Me.lblMNumberPELMO.AutoSize = True
        Me.lblMNumberPELMO.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMNumberPELMO.ForeColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblMNumberPELMO.Location = New System.Drawing.Point(119, 89)
        Me.lblMNumberPELMO.Name = "lblMNumberPELMO"
        Me.lblMNumberPELMO.Size = New System.Drawing.Size(90, 13)
        Me.lblMNumberPELMO.TabIndex = 9
        Me.lblMNumberPELMO.Text = "no coreinfo found"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripProgressBar, Me.ToolStripStatusLabel})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 703)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(732, 22)
        Me.StatusStrip1.TabIndex = 13
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripProgressBar
        '
        Me.ToolStripProgressBar.Name = "ToolStripProgressBar"
        Me.ToolStripProgressBar.Size = New System.Drawing.Size(100, 16)
        Me.ToolStripProgressBar.Visible = False
        '
        'ToolStripStatusLabel
        '
        Me.ToolStripStatusLabel.Name = "ToolStripStatusLabel"
        Me.ToolStripStatusLabel.Size = New System.Drawing.Size(0, 17)
        Me.ToolStripStatusLabel.Visible = False
        '
        'btnReset
        '
        Me.btnReset.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnReset.Location = New System.Drawing.Point(577, 12)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(135, 30)
        Me.btnReset.TabIndex = 14
        Me.btnReset.Text = "Reset Tool"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'chkKeepPelmoData
        '
        Me.chkKeepPelmoData.AutoSize = True
        Me.chkKeepPelmoData.Location = New System.Drawing.Point(132, 536)
        Me.chkKeepPelmoData.Name = "chkKeepPelmoData"
        Me.chkKeepPelmoData.Size = New System.Drawing.Size(117, 43)
        Me.chkKeepPelmoData.TabIndex = 15
        Me.chkKeepPelmoData.Text = "Keep all data in" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "calculation folder" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "(not recommended)"
        Me.chkKeepPelmoData.UseVisualStyleBackColor = True
        '
        'btnValMaster
        '
        Me.btnValMaster.Location = New System.Drawing.Point(580, 54)
        Me.btnValMaster.Name = "btnValMaster"
        Me.btnValMaster.Size = New System.Drawing.Size(85, 23)
        Me.btnValMaster.TabIndex = 16
        Me.btnValMaster.Text = "Validate path"
        Me.btnValMaster.UseVisualStyleBackColor = True
        '
        'lblValMaster
        '
        Me.lblValMaster.AutoSize = True
        Me.lblValMaster.ForeColor = System.Drawing.Color.Red
        Me.lblValMaster.Location = New System.Drawing.Point(671, 59)
        Me.lblValMaster.Name = "lblValMaster"
        Me.lblValMaster.Size = New System.Drawing.Size(37, 13)
        Me.lblValMaster.TabIndex = 17
        Me.lblValMaster.Text = "invalid"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(732, 725)
        Me.Controls.Add(Me.lblValMaster)
        Me.Controls.Add(Me.btnValMaster)
        Me.Controls.Add(Me.chkKeepPelmoData)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.GroupBoxCMPData)
        Me.Controls.Add(Me.GroupBoxFOCUSExecPaths)
        Me.Controls.Add(Me.btnLoadFromConfig)
        Me.Controls.Add(Me.lsbLog)
        Me.Controls.Add(Me.lblMasterPath)
        Me.Controls.Add(Me.lbxApp)
        Me.Controls.Add(Me.txtMasterPath)
        Me.Controls.Add(Me.btnSave2Config)
        Me.Controls.Add(Me.btnGetApp)
        Me.Controls.Add(Me.btnSubstInfoPELMO)
        Me.Controls.Add(Me.btnSubstInfoPEARL)
        Me.Controls.Add(Me.btnEvaluatePEARL)
        Me.Controls.Add(Me.btnPELMO32)
        Me.Controls.Add(Me.btnPEARL333)
        Me.Controls.Add(Me.btnEvaluatePELMO)
        Me.Controls.Add(Me.btnStartPELMO)
        Me.MaximizeBox = False
        Me.MinimumSize = New System.Drawing.Size(740, 740)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ContextMenuStriplsblog.ResumeLayout(False)
        Me.GroupBoxFOCUSExecPaths.ResumeLayout(False)
        Me.GroupBoxFOCUSExecPaths.PerformLayout()
        Me.GroupBoxCMPData.ResumeLayout(False)
        Me.GroupBoxCMPData.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnPEARL333 As System.Windows.Forms.Button
    Friend WithEvents btnPELMO32 As System.Windows.Forms.Button
    Friend WithEvents btnGetApp As System.Windows.Forms.Button
    Friend WithEvents txtMasterPath As System.Windows.Forms.TextBox
    Friend WithEvents lblMasterPath As System.Windows.Forms.Label
    Friend WithEvents lbxApp As System.Windows.Forms.ListBox
    Friend WithEvents lblPEARLPath As System.Windows.Forms.Label
    Friend WithEvents lblPELMOPath As System.Windows.Forms.Label
    Friend WithEvents txtPEARLTemplate As System.Windows.Forms.TextBox
    Friend WithEvents txtPELMOTemplate As System.Windows.Forms.TextBox
    Friend WithEvents lblPEARLTemplate As System.Windows.Forms.Label
    Friend WithEvents lblPELMOTemplate As System.Windows.Forms.Label
    Friend WithEvents btnStartPELMO As System.Windows.Forms.Button
    Friend WithEvents btnEvaluatePELMO As System.Windows.Forms.Button
    Friend WithEvents btnEvaluatePEARL As System.Windows.Forms.Button
    Friend WithEvents btnSubstInfoPEARL As System.Windows.Forms.Button
    Friend WithEvents btnSubstInfoPELMO As System.Windows.Forms.Button
    Friend WithEvents btnSave2Config As System.Windows.Forms.Button
    Friend WithEvents btnLoadFromConfig As System.Windows.Forms.Button
    Friend WithEvents lsbLog As System.Windows.Forms.ListBox
    Friend WithEvents ContextMenuStriplsblog As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents SaveLog As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBoxFOCUSExecPaths As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBoxCMPData As System.Windows.Forms.GroupBox
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripProgressBar As System.Windows.Forms.ToolStripProgressBar
    Friend WithEvents ToolStripStatusLabel As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents lblMNumberPELMO As System.Windows.Forms.Label
    Friend WithEvents lblMNumberPEARL As System.Windows.Forms.Label
    Friend WithEvents chkKeepPelmoData As System.Windows.Forms.CheckBox
    Friend WithEvents txtPELMOPath As System.Windows.Forms.TextBox
    Friend WithEvents txtPEARLPath As System.Windows.Forms.TextBox
    Friend WithEvents btnValPearl As System.Windows.Forms.Button
    Friend WithEvents btnValPelmo As System.Windows.Forms.Button
    Friend WithEvents btnValMaster As System.Windows.Forms.Button
    Friend WithEvents lblValPelmo As System.Windows.Forms.Label
    Friend WithEvents lblValPearl As System.Windows.Forms.Label
    Friend WithEvents lblValMaster As System.Windows.Forms.Label

End Class
