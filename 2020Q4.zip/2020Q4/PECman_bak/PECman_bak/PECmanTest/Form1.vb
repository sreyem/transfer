﻿

Imports System.ComponentModel
Imports System.Drawing.Design
Imports core
Imports PECman

Public Class Form1

    Public Sub New()

        InitializeComponent()



        showClassInFormEditor.showClassInForm(class2Show:=test)
        End

    End Sub

    Public Property test As New testclass

End Class
Public Class testclass

    Inherits startClass



    Public Sub New()

    End Sub

    Private _testarray As yearlyPECs()

    <Editor(GetType(ButtonEmulatorArray), GetType(UITypeEditor))>
    Public Property testarray As yearlyPECs()
        Get

            _testarray =
              showListInFormEditor.showArray(Of yearlyPECs)(
                targetArray:=_testarray,
                member:=New yearlyPECs)

            Return _testarray
        End Get
        Set
            _testarray = Value
        End Set
    End Property

End Class

