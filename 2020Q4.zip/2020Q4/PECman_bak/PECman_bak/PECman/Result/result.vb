﻿
Imports core

Public Class result

    Inherits startClass

    Public Sub New()

    End Sub

    Public Overrides Function checkInputComplete() As String
        Throw New NotImplementedException()
    End Function





End Class
