﻿

Imports System.ComponentModel
Imports System.Drawing.Design
Imports System.Text
Imports System.Xml.Serialization
Imports System.Web.Script.Serialization
Imports core
Imports PECman._FOCUSGWdb

Public Class yearlyPECs

    Inherits startClass

    Public Sub New()

    End Sub


    <Browsable(False)>
    Public Shadows Property name As String
        Get
            Return code.PadRight(6) & vbCrLf & endPoints.name
        End Get
        Set

        End Set
    End Property

    Public Shadows Function addNew() As yearlyPECs
        Return New yearlyPECs
    End Function

    Private _code As String = String.Empty

    Public Property code As String
        Get
            Return _code
        End Get
        Set

            Dim numbertest As String = Value.Substring(0, 1)

            Select Case numbertest
                Case "1", "2", "3", "4", "5",
                     "6", "7", "8", "9", "0"
                    Value = "_" & Value
            End Select

            If Value.Length > 5 Then
                Value = Value.Substring(
                            startIndex:=0,
                            length:=5)
            End If

            _code = Value.ToUpper

        End Set
    End Property

    Public Property endPoints As New endPoint

    Private _details As statistic() = {}


    <Editor(GetType(ButtonEmulatorArray), GetType(UITypeEditor))>
    Public Property details As statistic()
        Get

            _details =
              showListInFormEditor.showArray(Of statistic)(
                targetArray:=_details,
                member:=New statistic)

            Return _details
        End Get
        Set
            _details = Value
        End Set
    End Property

End Class


''' <summary>
''' FOCUS GW result data for 20 years
''' incl. statistic
''' </summary>
<Serializable>
Public Class statistic

    Inherits descriptiveStatistic

    Public Sub New()

    End Sub

    <Category(descriptiveStatistic.CATBasic)>
    Public Property gwModel As eGWModels

    <Browsable(False)>
    Public Shadows Property name As String
        Get
            Return gwModel.ToString
        End Get
        Set(value As String)

        End Set
    End Property


    Public Shadows Function addNew() As statistic
        Return New statistic
    End Function

End Class

Public Class endPoint

    Inherits startClass

    Public Sub New()

    End Sub

    '<Browsable(False)>
    <XmlIgnore> <ScriptIgnore>
    Public Shadows Property name As String
        Get

            Dim temp As New StringBuilder

            If percentiles Is Nothing OrElse percentiles.Count = 0 Then
                Return "No values"
            End If

            temp.Clear()

            For model As eGWModels = eGWModels.PEARL To eGWModels.MACRO

                If percentiles.Count > model Then

                    temp.Append(model.ToString)
                    temp.Append(" : ")
                    temp.Append(
                        convertPECdouble2String(
                            PEC:=percentiles(model),
                            alinged:=True))

                    If model <> eGWModels.MACRO AndAlso model < percentiles.Count - 1 Then temp.Append(vbCrLf)

                End If

            Next

            Return temp.ToString

        End Get
        Set(value As String)

        End Set
    End Property

    <Editor(GetType(MultiLineDoubleArrayEditor), GetType(UITypeEditor))>
    Public Property percentiles As Double() = {Double.NaN, Double.NaN, Double.NaN}

    Public Sub addPEC(PEC As Double)

        Dim temp As New List(Of Double)
        temp.AddRange(percentiles)
        temp.Add(PEC)

        Me.percentiles = temp.ToArray

    End Sub

End Class

