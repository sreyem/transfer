﻿


Imports System.ComponentModel
Imports System.Globalization
Imports System.Reflection
Imports System.IO
Imports System.Text

Imports core

Public Class _FOCUSGWdb

    Public Sub New()

    End Sub

#Region "    Common"

    Public Shared endpointType As String = "80th perc."
    Public Const resultUnitPECgw As String = "µg/L"
    Public Const minPECgw As Double = 0.0001
    Public Const numberFormatPECgw As String = "0.0000"

    Public Shared Function convertPECdouble2String(
                              PEC As Double,
                              Optional resultUnitPECgw As String = resultUnitPECgw,
                              Optional minPECgw As Double = minPECgw,
                              Optional numberFormatPECgw As String = numberFormatPECgw,
                              Optional alinged As Boolean = False) As String

        Dim temp As New StringBuilder

        temp.Clear()
        If Double.IsNaN(PEC) Then

            If alinged Then
                temp.Append(" - ".PadLeft(("<" & minPECgw).Length))
            Else
                temp.Append(" - ")
            End If

            temp.Append(resultUnitPECgw)

            Return temp.ToString

        ElseIf PEC < minPECgw Then
            temp.Append("<")
            temp.Append(minPECgw.ToString(numberFormatPECgw))
        Else
            If alinged Then temp.Append(" ")
            temp.Append(PEC.ToString(numberFormatPECgw))
        End If



        temp.Append(resultUnitPECgw)

        Return temp.ToString

    End Function

    ''' <summary>
    ''' The three common used FOCUS Gw models
    ''' PEARL, PELMO and MACRO
    ''' </summary>
    Public Enum eGWModels

        ''' <summary>
        ''' Pesticide Emission Assessment at Regional and Local scales
        ''' </summary>
        PEARL


        ''' <summary>
        ''' Pesticide Leaching Model
        ''' </summary>
        PELMO


        ''' <summary>
        ''' Macro-pore Model
        ''' </summary>
        MACRO

    End Enum


    ''' <summary>
    ''' Runtime in years for appln every 
    '''     year = 26
    ''' 2nd year = 46
    ''' 3rd year = 66
    ''' </summary>
    <TypeConverter(GetType(EnumConverter_eYearlyRepeat))>
    Public Enum eYearlyRepeat
        <Description("year")>
        EveryYear

        <Description("2nd year")>
        EverySecondYear

        <Description("3rd year")>
        EveryThirdYear
    End Enum

    Public Shared sYearlyRepeat As String() =
        {
        "every year",
        "every second year",
        "every third year"
         }

    Public Const warmUp As Integer = 6

    ''' <summary>
    ''' Runtime in years + 6 warm up for appln every 
    '''     year = 20
    ''' 2nd year = 40
    ''' 3rd year = 60
    ''' </summary>
    Public Shared runTimeInYears As Integer() =
    {
        20 + warmUp,
        40 + warmUp,
        60 + warmUp
    }

    ''' <summary>
    ''' Appln mode : 
    '''   to crop canopy
    '''   to soil or
    '''   via incorporation
    ''' </summary>
    <TypeConverter(GetType(EnumConverter_eApplnMode))>
    Public Enum eApplnMode

        ''' <summary>
        ''' to crop canopy
        ''' </summary>
        <Description("to crop canopy")>
        AppCrpUsr

        ''' <summary>
        ''' to soil
        ''' </summary>
        <Description("to soil")>
        AppSolSur

        ''' <summary>
        ''' via incorporation, depth info needed
        ''' </summary>
        <Description("via incorporation")>
        AppSolTil

        ''' <summary>
        ''' via injection to a certain depth, seldom used!
        ''' </summary>
        <Description("via injection to a certain depth")>
        AppSolTInj

    End Enum

    Public Shared sApplnMode As String() =
        {
        "to crop canopy",
        "to soil",
        "via incorporation",
        "via injection to a certain depth"
        }

    'enum 1st or 2nd season
    Public Enum eSeason
        first
        second
    End Enum


#End Region

#Region "    PEARL"


    ''' <summary>
    ''' Supported PEARL versions
    ''' 4.4.4
    ''' 5.5.5
    ''' </summary>
    <TypeConverter(GetType(EnumConverter_ePEARLVersion))>
    Public Enum ePEARLVersion
        <Description("4.4.4")>
        PEARL444
        <Description("5.5.5")>
        PEARL555
    End Enum

    ''' <summary>
    ''' Supported PEARL versions
    ''' 5.5.3
    ''' 6.6.4
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property PEARLVersionString As String() =
    {
        "4.4.4",
        "5.5.5"
    }


    ''' <summary>
    ''' creates ScenarioCrop.prl files out of all possible
    ''' combinations. Scenario is always 4 letters long
    ''' </summary>
    ''' <param name="origPRLFolder">
    ''' all possible Scenario x Crop combinations out of PEARL
    ''' </param>
    ''' <param name="resPRLFolder">
    ''' target folder for the re-named prl files
    ''' </param>
    Public Shared Sub createPEARLSources(
                                        origPRLFolder As String,
                                        resPRLFolder As String,
                               Optional delimiter As Char = "",
                               Optional newExtension As String = ".res")

        Dim origPRLFilePaths As String() = {}
        Dim prlFile As String() = {}
        Dim targetRow As String = ""

        Const searchCropScenario As String = " CropCalendar"

        'init, clear 'resPRLFolder' folder
        Try

            If Directory.Exists(resPRLFolder) Then
                My.Computer.FileSystem.DeleteDirectory(
                    directory:=resPRLFolder,
                    onDirectoryNotEmpty:=FileIO.DeleteDirectoryOption.DeleteAllContents)
            End If

            My.Computer.FileSystem.CreateDirectory(directory:=resPRLFolder)

        Catch ex As Exception

        End Try

        'get all *.prl files in origPRLFolder
        Try

            origPRLFilePaths =
                Directory.GetFiles(
                path:=origPRLFolder,
                searchPattern:="*.prl",
                searchOption:=SearchOption.TopDirectoryOnly)

        Catch ex As Exception

        End Try

        'for ~125 prl files
        For Each member As String In origPRLFilePaths

            'read prl file to array
            Try
                prlFile = File.ReadAllLines(path:=member)
            Catch ex As Exception

            End Try

            'find 'CropCalendar' row
            targetRow =
                Array.Find(
                array:=prlFile,
                Function(s)
                    Return s.EndsWith(searchCropScenario)
                End Function)

            'delete 'CropCalendar'
            targetRow =
                Replace(
                Expression:=targetRow,
                Find:=searchCropScenario,
                Replacement:="",
                Compare:=CompareMethod.Text)

            'delete '-'
            targetRow =
               Trim(Replace(
                Expression:=targetRow,
                Find:="-",
                Replacement:=delimiter,
                Compare:=CompareMethod.Text))

            'write prl file with new name and 'newExtension' to 'resPRLFolder'
            Try

                File.Copy(
                    sourceFileName:=member,
                    destFileName:=Path.Combine(
                                        path1:=resPRLFolder,
                                        path2:=targetRow & newExtension),
                    overwrite:=True)

            Catch ex As Exception

            End Try

        Next

    End Sub

#End Region

#Region "    PELMO"

#Region "    Version"

    ''' <summary>
    ''' Supported PELMO versions
    ''' 5.5.3
    ''' 6.6.4
    ''' </summary>
    <TypeConverter(GetType(EnumConverter_ePELMOVersion))>
    Public Enum ePELMOVersion
        <Description("5.5.3")>
        PELMO553
        <Description("6.6.4")>
        PELMO664
    End Enum

    ''' <summary>
    ''' Supported PELMO versions
    ''' 5.5.3
    ''' 6.6.4
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property PELMOVersionString As String() =
    {
        "5.5.3",
        "6.6.4"
    }

#End Region

#Region "    appln row end"

    ''' <summary>
    ''' Description of appln row incl. std. zero values
    ''' for both PELMO versions
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property PELMOxxxApplnRest As String() =
    {
        "    0    0    0    < DD MM YY, Rate (kg/ha), Depth (cm), ?, frpex, hour >",
        "    0    0    0    0    < DD MM YY, Rate (kg/ha), upper, lower Depth (cm), ?, Ffield, frpex, hour >"
    }

    ''' <summary>
    ''' four (5.5.3) or fife (6.6.4) times '    0' 
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property commentStart As String() =
    {
        "    0    0    0    < ",
        "    0    0    0    0    < "
    }

#End Region


    Public Shared Function createPELMOresources(
                                    origPELMOpath As String,
                                    newPELMOpath As String) As Boolean

        Dim cropsList As New List(Of String)
        Dim cropDirs As New List(Of String)
        Dim newCropDir As String
        Dim crops2TXT As New List(Of String)
        Dim targetCrop As String
        Dim scenarioDirs As New List(Of String)

        Dim source As String
        Dim destination As String

        'init, re-create 'newPELMOpath'
        Try

            If Directory.Exists(newPELMOpath) Then
                My.Computer.FileSystem.DeleteDirectory(
                    directory:=newPELMOpath,
                    onDirectoryNotEmpty:=FileIO.DeleteDirectoryOption.DeleteAllContents)
            End If

            My.Computer.FileSystem.CreateDirectory(directory:=newPELMOpath)

        Catch ex As Exception

        End Try

        Try

            cropDirs.AddRange(Directory.GetDirectories(
                              path:=origPELMOpath,
                              searchPattern:="*",
                              searchOption:=SearchOption.TopDirectoryOnly))

        Catch ex As Exception

        End Try


        For Each cropdir As String In cropDirs

            crops2TXT.Add(Path.GetFileName(cropdir))
            source = cropdir
            destination = String.Empty

            For Each member As String In _FOCUSGWdb.PELMOCrops

                If cropdir.EndsWith(member.Split("|").First) Then

                    destination =
                        Path.Combine(
                             newPELMOpath,
                             member.Split("|").Last & ".run")

                    Exit For

                End If

            Next

            If destination = String.Empty Then
                Console.WriteLine()
                Return False
            End If

            My.Computer.FileSystem.CopyDirectory(
                         sourceDirectoryName:=source,
                         destinationDirectoryName:=destination)

            scenarioDirs.Clear()
            scenarioDirs.AddRange(Directory.GetDirectories(path:=destination))

            For Each scenarioDir As String In scenarioDirs

                source = scenarioDir

                destination = Path.Combine(
                    path1:=Path.GetDirectoryName(scenarioDir),
                    path2:=Path.GetFileName(scenarioDir).Substring(0, 4).ToUpper & ".run")

                destination = Replace(
                    Expression:=destination,
                    Find:="â",
                    Replacement:="A",
                    Compare:=CompareMethod.Text)

                My.Computer.FileSystem.RenameDirectory(
                    directory:=scenarioDir,
                    newName:=Path.GetFileName(destination))

            Next

        Next

        File.WriteAllLines(
            path:=Path.Combine(
                path1:=newPELMOpath,
                path2:="Crops.txt"),
            contents:=crops2TXT.ToArray)


        Return True

    End Function

#End Region

#Region "    MACRO"

    ''' <summary>
    ''' Supported PEARL versions
    ''' 4.4.4
    ''' 5.5.5
    ''' </summary>
    <TypeConverter(GetType(EnumConverter_eMACROVersion))>
    Public Enum eMACROVersion

        <Description("5.5.4")>
        MACRO554
    End Enum

    ''' <summary>
    ''' Supported MACRO versions
    ''' 5.5.3
    ''' 6.6.4
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property MACROVersionString As String() =
    {
        "5.5.4"
    }





#End Region

#Region "    GW Crops"

    ''' <summary>
    ''' FOCUS gw Crops
    ''' </summary>
    <TypeConverter(GetType(EnumConverter_eCropsGW))>
    Public Enum eCropsGW

        <Description(
"apples                 CHJKNPOST")>
        APPLES

        <Description(
"beans (field)            	H KN    ")>
        FLDBEANS

        <Description(
"beans (vegetables) 2nd       O T")>
        VEGBEANS

        <Description(
"bush berries             J      ")>
        BUSHBERR

        <Description(
"cabbage            2nd CHJK  OST")>
        CABBAGE

        <Description(
"carrots            2nd CHJK  O T")>
        CARROTS

        <Description(
"citrus                      POST")>
        CITRUS

        <Description(
"cotton                        ST")>
        COTTON

        <Description(
"grass                  CHJKNPOST")>
        GRASS

        <Description(
"linseed                    N    ")>
        LINSEED

        <Description(
"maize                  CH KNPOST")>
        MAIZE

        <Description(
"oil seed rape (summer)   J N O  ")>
        SOILSEED

        <Description(
"oil seed rape (winter) CH KNPO  ")>
        WOILSEED

        <Description(
"onions                 CHJK  O T")>
        ONIONS

        <Description(
"peas                   CHJ N    ")>
        PEAS

        <Description(
"potatoes               CHJKNPOST")>
        SPOTATOES

        <Description(
"soybean                     P   ")>
        SOYBEAN

        <Description(
"spring cereals         CHJKN O  ")>
        SCEREALS

        <Description(
"strawberries            HJK   S ")>
        STRAWBER

        <Description(
"sugarbeets             CHJKNPOST")>
        SUGARBEET

        <Description(
"sunflower                   P S ")>
        SUNFLOWER

        <Description(
"tobacco                     P  ")>
        TOBACCO

        <Description(
"tomatoes               C    POST")>
        TOMATOES

        <Description(
"vines                  CH K POST")>
        VINES

        <Description(
"winter cereals         CHJKNPOST")>
        WCEREALS

        <Description(
"bare soil              CHJKNPOST")>
        BARESOIL

        <Description(" - ")>
        notDef


    End Enum

    ''' <summary>
    ''' Converts a string to FOCUS crop enum
    ''' </summary>
    ''' <param name="cropString">
    ''' string that contains crop info
    ''' </param>
    ''' <returns>
    ''' enum eCropsGW
    ''' </returns>
    Public Shared Function getCropByString(cropString As String) As eCropsGW

        Dim index As Integer = -1

        Try
            index =
                Array.FindIndex(array:=dbCropsGW, match:=Function(x) x.ToLower.Contains(cropString.ToLower))
            Return _
                [Enum].Parse(
                enumType:=GetType(eCropsGW),
                value:=dbCropsGW(index).Split(",")(1))
        Catch ex As Exception
            Return eCropsGW.notDef
        End Try

    End Function

    ''' <summary>
    ''' FOCUS gw crop db
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property dbCropsGW As String() =
        {
"pp,APPLES,App,apples",
"ld,FLDBEANS,Bfl,beans (field)",
"veg,VEGBEANS,Bvg,beans (vegetables)",
"err,BUSHBERR,Bbr,bushberries",
"bb,CABBAGE,Cab,cabbage",
"arr,CARROTS,Car,carrots",
"cit,CITRUS,Cit,citrus",
"tt,COTTON,Cot,cotton",
"ss,GRASS,Grs,grass",
"lin,LINSEED,Lin,linseed",
"maize,MAIZE,Maz,maize",
"mm,SOILSEED,Oss,oil seed rape (summer)",
"(winter),WOILSEED,Osw,oil seed rape (winter)",
"onions,ONIONS,Oni,onions",
"peas,PEAS,Pea,peas",
"pot,SPOTATOES,Pot,potatoes",
"soy,SOYBEAN,Soy,soybean",
"spring,SCEREALS,Sce,spring cereals",
"straw,STRAWBER,Str,strawberries",
"sug,SUGARBEET,Sug,sugarbeets",
"sun,SUNFLOWER,Sun,sunflower",
"tob,TOBACCO,Tob,tobacco",
"tom,TOMATOES,Tom,tomatoes",
"vin,VINES,Vin,vines",
"winter,WCEREALS,Wce,winter cereals",
"ll,BARESOIL,Bso,bare soil"
    }

    ''' <summary>
    ''' emergence, maturity and harvest dates
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property dbCropTimming As String() =
        {
"Chateaudun,Apples,01.Apr,31.May,01.Oct",
"Hamburg,Apples,15.Apr,01.Jul,30.Oct",
"Jokioinen,Apples,10.May,25.May,15.Oct",
"Kremsmuenster,Apples,15.Apr,01.Jul,30.Oct",
"Okehampton,Apples,25.Mar,15.Jun,15.Sep",
"Piacenza,Apples,01.Apr,31.May,01.Nov",
"Porto,Apples,15.Mar,30.Jun,31.Oct",
"Sevilla,Apples,15.Mar,31.May,15.Oct",
"Thiva,Apples,15.Mar,30.Jun,20.Oct",
"Chateaudun,Bare Soil,15.Apr,15.Jun,31.Dec",
"Hamburg,Bare Soil,15.Apr,15.Jun,31.Dec",
"Jokioinen,Bare Soil,15.Apr,15.Jun,31.Dec",
"Kremsmuenster,Bare Soil,15.Apr,15.Jun,31.Dec",
"Okehampton,Bare Soil,15.Apr,15.Jun,31.Dec",
"Piacenza,Bare Soil,15.Apr,15.Jun,31.Dec",
"Porto,Bare Soil,15.Apr,15.Jun,31.Dec",
"Sevilla,Bare Soil,15.Apr,15.Jun,31.Dec",
"Thiva,Bare Soil,15.Apr,15.Jun,31.Dec",
"Hamburg,Beans (field),10.Apr,10.Jul,25.Aug",
"Kremsmuenster,Beans (field),10.Apr,10.Jul,25.Aug",
"Okehampton,Beans (field),15.Mar,07.Jun,15.Sep",
"Porto,Beans (vegetables),10.Mar,15.May,31.Aug",
"Thiva,Beans (vegetables),01.Apr,01.May,15.Jun",
"Thiva,Beans (vegetables),08.Jul,08.Aug,30.Sep",
"Jokioinen,Bushberries,10.May,25.May,25.Oct",
"Chateaudun,Cabbage,20.Apr,31.May,15.Jul",
"Hamburg,Cabbage,20.Apr,31.May,15.Jul",
"Jokioinen,Cabbage,20.May,05.Sep,20.Sep",
"Kremsmuenster,Cabbage,20.Apr,31.May,15.Jul",
"Porto,Cabbage,28.Feb,15.May,01.Jul",
"Sevilla,Cabbage,01.Mar,01.May,01.Jun",
"Thiva,Cabbage,15.Aug,30.Sep,30.Nov",
"Chateaudun,Cabbage,31.Jul,05.Sep,15.Oct",
"Hamburg,Cabbage,31.Jul,05.Sep,15.Oct",
"Kremsmuenster,Cabbage,31.Jul,05.Sep,15.Oct",
"Porto,Cabbage,31.Jul,31.Aug,15.Nov",
"Sevilla,Cabbage,15.Jun,15.Aug,15.Sep",
"Chateaudun,Carrots,10.Mar,20.Apr,31.May",
"Hamburg,Carrots,10.Mar,20.Apr,31.May",
"Jokioinen,Carrots,01.Jun,05.Sep,05.Oct",
"Kremsmuenster,Carrots,10.Mar,20.Apr,31.May",
"Porto,Carrots,28.Feb,01.May,31.May",
"Thiva,Carrots,15.Mar,15.Apr,22.May",
"Chateaudun,Carrots,10.Jul,10.Aug,20.Sep",
"Hamburg,Carrots,10.Jul,10.Aug,20.Sep",
"Kremsmuenster,Carrots,10.Jul,10.Aug,20.Sep",
"Porto,Carrots,22.Jul,15.Sep,15.Oct",
"Thiva,Carrots,15.Jun,15.Jul,10.Sep",
"Piacenza,Citrus,01.Jan,01.Jan,01.Jan",
"Porto,Citrus,01.Jan,01.Jan,01.Jan",
"Sevilla,Citrus,01.Jan,01.Jan,01.Jan",
"Thiva,Citrus,01.Jan,01.Jan,01.Jan",
"Sevilla,Cotton,05.Apr,30.Apr,31.Jul",
"Thiva,Cotton,15.Jun,31.Jul,30.Sep",
"Chateaudun,Grass,01.Apr,30.Sep,30.Sep",
"Hamburg,Grass,25.Mar,31.Aug,31.Aug",
"Jokioinen,Grass,15.Apr,25.Aug,25.Aug",
"Kremsmuenster,Grass,10.Apr,20.Sep,20.Sep",
"Okehampton,Grass,10.Feb,15.Sep,15.Sep",
"Piacenza,Grass,28.Feb,20.Sep,20.Sep",
"Porto,Grass,28.Feb,20.Sep,20.Sep",
"Sevilla,Grass,31.Jan,15.Oct,15.Oct",
"Thiva,Grass,15.Apr,15.Nov,15.Nov",
"Okehampton,Linseed,30.Mar,25.Jun,25.Sep",
"Chateaudun,Maize,01.May,15.Aug,01.Oct",
"Hamburg,Maize,05.May,30.Jul,20.Sep",
"Kremsmuenster,Maize,05.May,30.Jul,20.Sep",
"Okehampton,Maize,25.May,15.Jul,07.Oct",
"Piacenza,Maize,15.May,31.Jul,30.Oct",
"Porto,Maize,01.May,15.Aug,01.Oct",
"Sevilla,Maize,07.Mar,15.Jun,31.Jul",
"Thiva,Maize,20.Apr,15.Jun,15.Sep",
"Jokioinen,Oil Seed Rape (summer),20.May,05.Jul,30.Aug",
"Okehampton,Oil Seed Rape (summer),30.Mar,15.May,20.Aug",
"Porto,Oil Seed Rape (summer),22.Mar,31.May,25.Aug",
"Chateaudun,Oil Seed Rape (winter),07.Sep,20.Apr,10.Jul",
"Hamburg,Oil Seed Rape (winter),02.Sep,05.May,28.Jul",
"Kremsmuenster,Oil Seed Rape (winter),02.Sep,05.May,28.Jul",
"Okehampton,Oil Seed Rape (winter),14.Aug,30.Apr,21.Jul",
"Piacenza,Oil Seed Rape (winter),05.Oct,15.Apr,20.Jun",
"Porto,Oil Seed Rape (winter),07.Sep,20.Apr,10.Jul",
"Chateaudun,Onions,25.Apr,30.Jun,01.Sep",
"Hamburg,Onions,25.Apr,30.Jun,01.Sep",
"Jokioinen,Onions,20.May,25.Jun,15.Aug",
"Kremsmuenster,Onions,25.Apr,30.Jun,01.Sep",
"Porto,Onions,28.Feb,15.May,31.May",
"Thiva,Onions,10.Apr,15.Jun,30.Jun",
"Chateaudun,Peas,05.Apr,07.Jun,15.Aug",
"Hamburg,Peas,10.Apr,10.Jul,25.Aug",
"Jokioinen,Peas,25.May,30.Jun,25.Aug",
"Okehampton,Peas,05.Apr,07.Jun,15.Aug",
"Chateaudun,Potatoes,30.Apr,15.Jun,01.Sep",
"Hamburg,Potatoes,10.May,20.Jul,15.Sep",
"Jokioinen,Potatoes,05.Jun,30.Aug,25.Sep",
"Kremsmuenster,Potatoes,10.May,20.Jul,15.Sep",
"Okehampton,Potatoes,30.Apr,15.Jul,01.Sep",
"Piacenza,Potatoes,20.Apr,01.Jun,10.Sep",
"Porto,Potatoes,15.Mar,30.May,15.Jun",
"Sevilla,Potatoes,31.Jan,31.Mar,31.May",
"Thiva,Potatoes,01.Mar,30.Apr,30.Jul",
"Piacenza,Soybean,10.May,31.Jul,05.Oct",
"Chateaudun,Spring Cereals,10.Mar,10.Jun,20.Jul",
"Hamburg,Spring Cereals,01.Apr,05.Jun,20.Aug",
"Jokioinen,Spring Cereals,18.May,30.Jun,25.Aug",
"Kremsmuenster,Spring Cereals,01.Apr,05.Jun,20.Aug",
"Okehampton,Spring Cereals,01.Apr,22.May,20.Aug",
"Porto,Spring Cereals,10.Mar,10.Jun,20.Jul",
"Hamburg,Strawberries,15.Mar,30.Apr,31.Aug",
"Jokioinen,Strawberries,15.May,25.Jun,15.Sep",
"Kremsmuenster,Strawberries,15.Mar,30.Apr,31.Aug",
"Sevilla,Strawberries,30.Nov,30.Apr,31.Aug",
"Chateaudun,Sugarbeets,16.Apr,15.Jul,15.Oct",
"Hamburg,Sugarbeets,15.Apr,30.Aug,08.Oct",
"Jokioinen,Sugarbeets,25.May,10.Aug,15.Oct",
"Kremsmuenster,Sugarbeets,15.Apr,30.Aug,10.Oct",
"Okehampton,Sugarbeets,25.Apr,30.Aug,25.Oct",
"Piacenza,Sugarbeets,20.Mar,30.Jun,15.Sep",
"Porto,Sugarbeets,15.Mar,30.Apr,01.Aug",
"Sevilla,Sugarbeets,10.Nov,15.Apr,01.Jul",
"Thiva,Sugarbeets,01.May,30.Jun,30.Sep",
"Piacenza,Sunflower,20.Apr,20.Jun,20.Sep",
"Sevilla,Sunflower,10.Mar,15.Jun,15.Jul",
"Piacenza,Tobacco,20.May,20.Jul,05.Oct",
"Thiva,Tobacco,01.May,15.Aug,30.Sep",
"Chateaudun,Tomatoes,10.May,30.Jun,25.Aug",
"Piacenza,Tomatoes,10.May,30.Jun,25.Aug",
"Porto,Tomatoes,15.Mar,15.Jun,31.Aug",
"Sevilla,Tomatoes,15.Apr,30.May,01.Jul",
"Thiva,Tomatoes,10.Apr,30.May,10.Sep",
"Chateaudun,Vines,01.Apr,31.Jul,01.Nov",
"Hamburg,Vines,01.May,15.Jul,30.Oct",
"Kremsmuenster,Vines,01.May,15.Jul,30.Oct",
"Piacenza,Vines,01.Apr,31.Jul,01.Nov",
"Porto,Vines,15.Mar,31.Jul,30.Sep",
"Sevilla,Vines,31.Mar,15.Jun,30.Nov",
"Thiva,Vines,15.Mar,30.Jun,20.Oct",
"Chateaudun,Winter Cereals,26.Oct,31.May,15.Jul",
"Hamburg,Winter Cereals,01.Nov,01.Jun,10.Aug",
"Jokioinen,Winter Cereals,20.Sep,25.Jun,15.Aug",
"Kremsmuenster,Winter Cereals,05.Nov,05.Jun,10.Aug",
"Okehampton,Winter Cereals,17.Oct,15.May,01.Aug",
"Piacenza,Winter Cereals,01.Dec,10.May,01.Jul",
"Porto,Winter Cereals,30.Nov,30.Apr,30.Jun",
"Sevilla,Winter Cereals,30.Nov,28.Feb,31.May",
"Thiva,Winter Cereals,30.Nov,30.Mar,30.Jun"
    }

    Public Shared Function KX2KD(KX As Double, baseXPerc As Double) As Double
        Return KX * (baseXPerc / 100)
    End Function

    Public Const Space As Integer = 12
    Public Const headerStart As String = " **** "
    Public Const DT50andSorptionRow As Integer = 6
    Public Const DT50andSorptionDelimiter As String = " | "
    Public Const NHORIZONrow As Integer = 4

    Public Const fileNameDelimiter As String = "_"
    Public Const GAProw As Integer = 7

    Public Shared Function resetSorption(
                              ByRef resfile As String(),
                                    Sorption As Double,
                                    Freundlich As Double,
                           Optional reset As Boolean = True,
                           Optional Format As String = "G7") As Boolean


#Region "    Definitions"

        Dim temp As String() = {}
        Dim base As New List(Of Double)

        Dim KOCindex As Integer = 100
        Dim freundlichIndex As Integer
        Dim ZKDindex As Integer

        Dim NHORIZON As Integer
        Dim SorptionInfo As String

#End Region

#Region "    init"

        NHORIZON = CInt(resfile(NHORIZONrow).Split(vbTab).Last)

        'reset
        If reset Then

            Sorption = 999
            Freundlich = 1

        End If

        mylog(LogTxtArray:=
              {
                "ChangeSorption for " & NHORIZON & " horizons",
                "Sorption    : " & Sorption & " L/kg",
                "    base    : " & "OC",
                "1/n         : " & Freundlich
              })

#End Region

#Region "    KOC"

        'find KOC
        Try

            KOCindex =
                    Array.FindIndex(
                        array:=resfile,
                        startIndex:=KOCindex,
                        match:=Function(x) x.StartsWith("KOC"))

            If KOCindex = -1 Then

                mylog(LogTxt:="Can't find 'KOC' in par file")
                Return False

            End If

            ' and change
            resfile(KOCindex) = "KOC".PadRight(Space) & vbTab & Sorption.ToString

        Catch ex As Exception

            mylog(
                LogTxtArray:=parseExceptionMsg(
                    Exception:=ex,
                    UserErrorDescription:="Error during changing KOC"))
            Return False

        End Try

#End Region

#Region "    ZKD"

        'get base for correction ORGC, CLAY or user setting

        Try

            temp =
            Array.FindAll(
                array:=resfile,
                match:=Function(x) x.StartsWith("ORGC"))


            If temp.Count = 0 Then
                mylog(LogTxt:="Can't find '" & "ORGC" & "' in par file")
            End If

        Catch ex As Exception

            mylog(
                LogTxtArray:=parseExceptionMsg(
                    Exception:=ex,
                    UserErrorDescription:="Error changing ZKD"))

            Return False

        End Try

        'the last part is the value if *.res files are used
        For Each member As String In temp
            base.Add(Double.Parse(member.Split(vbTab).Last))
        Next

        'find ZKD
        Try

            ZKDindex =
                Array.FindIndex(
                    array:=resfile,
                    startIndex:=freundlichIndex,
                    match:=Function(x) x.StartsWith("ZKD"))

            If ZKDindex = -1 Then
                mylog(LogTxt:="Can't find 'ZKD' in par file")
                Return False
            End If

        Catch ex As Exception

            mylog(
                LogTxtArray:=parseExceptionMsg(
                    Exception:=ex,
                    UserErrorDescription:="Error getting ZKD"))

            Return False

        End Try

        'reset : ZKD = ORGC
        If reset Then

            mylog(LogTxt:="KOC =  " & Sorption & "L/kg ZKD")

            '(re)set ZKD = ORGC
            For counter As Integer = 0 To base.Count - 1

                'get ZKD row as array
                temp = resfile(ZKDindex + counter).Split(vbTab)

                'exchange the value as last part or the string with ORGC corr. value
                temp(temp.Count - 1) = base(counter).ToString

                'recombine the parFile row
                resfile(ZKDindex + counter) = Join(SourceArray:=temp, Delimiter:=vbTab)

                mylog(
                    LogTxt:=" " & resfile(ZKDindex + counter).Split(vbTab).Last,
                    Add2PreviousRow:=True)

            Next

        Else

            If Double.IsNaN(Sorption) Then

                mylog(LogTxt:="Sorption value is not defined")
                Return False

            End If

            mylog(LogTxt:="KOC =  " & Sorption & "L/kg ZKD")

            'set ZKD defined by base
            For counter As Integer = 0 To base.Count - 1

                'get ZKD row as array
                temp = resfile(ZKDindex + counter).Split(vbTab)

                'exchange the value as last array item with ORGC/CLAY corr. value
                temp(temp.Count - 1) =
                  KX2KD(
                        KX:=Sorption,
                        baseXPerc:=base(counter)).ToString(Format)

                'recombine the parFile row
                resfile(ZKDindex + counter) = Join(SourceArray:=temp, Delimiter:=vbTab)

                mylog(
                    LogTxt:=" " & resfile(ZKDindex + counter).Split(vbTab).Last,
                    Add2PreviousRow:=True)

            Next

        End If

#End Region

#Region "    Freundlich 1/n : FREUND"

        'find FREUND
        Try

            freundlichIndex =
                    Array.FindIndex(
                        array:=resfile,
                        startIndex:=KOCindex,
                        match:=Function(x) x.StartsWith("FREUND"))

            If freundlichIndex = -1 Then
                mylog(LogTxt:="Can't find 'FREUND' in par file")
                Return False
            End If

        Catch ex As Exception

            mylog(
                LogTxtArray:=parseExceptionMsg(
                    Exception:=ex,
                    UserErrorDescription:="Error finding FREUND"))

            Return False

        End Try


        'FREUND user setting
        '(re) set FREUND to 1 for all horizons
        If reset Then
            Freundlich = 1
        End If


        mylog(LogTxt:="FREUND = " & Freundlich.ToString)

        If Double.IsNaN(Freundlich) Then

            mylog(LogTxt:="Freundlich value is not defined")
            Return False

        End If

        'always the same 1/n
        For counter As Integer = 0 To NHORIZON - 1

            'get old freundlich row
            temp = resfile(freundlichIndex + counter).Split(vbTab)

            'exchange the value as last part or the string with always the same 1/n
            temp(temp.Count - 1) = Freundlich.ToString

            'recombine the parFile row
            resfile(freundlichIndex + counter) = Join(SourceArray:=temp, Delimiter:=vbTab)

        Next

#End Region

#Region "    write info to the 6th row"

        Try

            SorptionInfo = " KOC : " & Sorption & "L/kg, base = ORGC, " & " 1/n : " & Freundlich

            If Not resfile(DT50andSorptionRow).Contains(DT50andSorptionDelimiter) Then

                resfile(DT50andSorptionRow) =
                        headerStart & DT50andSorptionDelimiter &
                        DT50andSorptionDelimiter &
                        SorptionInfo & DT50andSorptionDelimiter
            Else

                temp = {}
                temp = resfile(DT50andSorptionRow).Split(DT50andSorptionDelimiter)

                resfile(DT50andSorptionRow) =
                    Join(
                        SourceArray:=
                            {
                            temp(0),
                            temp(1),
                            SorptionInfo
                            },
                        Delimiter:=DT50andSorptionDelimiter)

            End If

        Catch ex As Exception

        End Try

        Return True

#End Region

    End Function

    Public Shared Function resetDT50soil(
                    ByRef resFile As String(),
                    ByVal DT50soil As Double,
                    Optional TempCorr As Boolean = True,
                    Optional MoistCorr As Boolean = True,
                    Optional reset As Boolean = True,
                    Optional Format As String = "G7") As Boolean

#Region "    Definitions"

        Dim DEGxxx As String() = {}
        Dim DEGxxxIndex As Integer = 140
        Dim DEGxxx100perc As Double
        Dim DEGxxxactual As Double
        Dim DEGrow As String() = {}
        Dim MALMASMILMIS As String() = {"DEGMAL", "DEGMAS", "DEGMIL", "DEGMIS"}

        Dim index As Integer = 100
        Dim tempMoistParameters As String() = {"EXPB", "PF1", "TREF", "TRESP"}
        Dim onoff As Double(,) = {{0.49, 0}, {2, 1}, {20, 0}, {0.0948, 1}}
        Dim searchItem As String = ""

        Dim TRESP As String = "TRESP"
        Dim PF As String = "PF1"
        Dim NHORIZON As Integer

        Dim temp As String() = {}
        Dim DT50Info As String = ""

#End Region

#Region "    Init, check # horizons"

        NHORIZON = CInt(resFile(NHORIZONrow).Split(vbTab).Last)

        If reset Then

            DT50soil = 999
            TempCorr = True
            MoistCorr = True

        End If

        mylog(LogTxtArray:=
              {
                "ChangeDT50soil for " & NHORIZON & " horizons",
                "DT50        : " & DT50soil & " days",
                "  TempCorr  : " & TempCorr.ToString,
                "  MoistCorr : " & MoistCorr.ToString
              })

#End Region

#Region "    Change DEGxx"

        'find 'DEGMAL'
        Try

            DEGxxxIndex =
                           Array.FindIndex(
                               array:=resFile,
                               startIndex:=DEGxxxIndex,
                               match:=Function(x) x.StartsWith(MALMASMILMIS.First))

            If DEGxxxIndex = -1 Then
                mylog(LogTxt:="Can't find 'DEGMAL' in par file")
                Return False
            End If

        Catch ex As Exception

            mylog(
               LogTxtArray:=parseExceptionMsg(
                   Exception:=ex,
                   UserErrorDescription:="Error during finding DEGMAL"))
            Return False

        End Try

        'for  DEGMAL, DEGMAS, DEGMIL and DEGMIS
        For DEGcounter As Integer = 0 To MALMASMILMIS.Count - 1

            'for each horizon
            For counter As Integer = 1 To NHORIZON

                DEGrow = resFile(DEGxxxIndex).Split(vbTab)

                'first horizon, if reset then = 1 = 100%
                If counter = 1 AndAlso reset Then

                    DEGxxx100perc = Double.Parse(DEGrow.Last)
                    DEGrow(DEGrow.Count - 1) = 1

                Else

                    DEGxxxactual = Double.Parse(DEGrow.Last)

                    If reset Then
                        DEGxxxactual =
                                Math.Round(DEGxxxactual / DEGxxx100perc, digits:=1)
                    Else
                        DEGxxxactual = (Math.Log(2) / DT50soil * DEGxxxactual)
                    End If

                    DEGrow(DEGrow.Count - 1) = DEGxxxactual.ToString(Format)

                End If

                resFile(DEGxxxIndex) = Join(SourceArray:=DEGrow, Delimiter:=vbTab)
                DEGxxxIndex += 1

            Next

        Next

#End Region

#Region "    Temp and Moist corr."

        If reset Then
            TempCorr = True
            MoistCorr = True
        End If

        'change "EXPB", "PF1", "TREF", "TRESP"
        For corrCounter As Integer = 0 To tempMoistParameters.Count - 1

            'find "EXPB", "PF1", "TREF", "TRESP"
            Try

                searchItem = tempMoistParameters(corrCounter)

                index =
                Array.FindIndex(
                    array:=resFile,
                    startIndex:=index,
                    match:=Function(x) x.StartsWith(searchItem))

                If index = -1 Then
                    mylog(LogTxt:="Can't find " & searchItem & " in par file")
                    Return False
                End If

            Catch ex As Exception

                mylog(
               LogTxtArray:=parseExceptionMsg(
                   Exception:=ex,
                   UserErrorDescription:="Error during finding " & searchItem))
                Return False

            End Try

            resFile(index) = searchItem.PadRight(Space) & vbTab

            '"EXPB", "PF1", "TREF", "TRESP"

            If corrCounter < 2 Then

                Select Case MoistCorr

                    Case True
                        resFile(index) &= onoff(corrCounter, 0)
                    Case False
                        resFile(index) &= onoff(corrCounter, 1)

                End Select

            Else

                Select Case TempCorr

                    Case True
                        resFile(index) &= onoff(corrCounter, 0)
                    Case False
                        resFile(index) &= onoff(corrCounter, 1)

                End Select

            End If

        Next

#End Region

#Region "    write info to the 6th row"

        Try

            DT50Info = "DT50 : " & DT50soil & "d, TempMoist = on"

            If Not resFile(DT50andSorptionRow).Contains(DT50andSorptionDelimiter) Then

                resFile(DT50andSorptionRow) =
                            headerStart & DT50andSorptionDelimiter &
                            DT50Info & DT50andSorptionDelimiter & DT50andSorptionDelimiter

            Else

                temp = {}
                temp = resFile(DT50andSorptionRow).Split(Trim(DT50andSorptionDelimiter))

                resFile(DT50andSorptionRow) =
                Join(
                    SourceArray:=
                        {
                        headerStart,
                        DT50Info,
                        Trim(temp(2))
                        },
                    Delimiter:=DT50andSorptionDelimiter)
            End If

            mylog(LogTxt:=DT50Info)

        Catch ex As Exception

        End Try

#End Region

        Return True

    End Function


    Public Shared sParIntMet As String() = {"Par", "Int", "Met"}

    Public Shared PELMOCrops As String() =
        {
"Apples.run|APPLES",
"Beans_-_(field).run|FLDBEANS",
"Beans_-_(vegetables).run|VEGBEANS",
"Bushberries.run|BUSHBERR",
"Cabbage.run|CABBAGE",
"Carrots.run|CARROTS",
"Citrus.run|CITRUS",
"Cotton.run|COTTON",
"Grass_-_and_-_alfalfa.run|GRASS",
"Linseed.run|LINSEED",
"Maize.run|MAIZE",
"Oil_-_seed_-_rape_-_(summer).run|SOILSEED",
"Oil_-_seed_-_rape_-_(winter).run|WOILSEED",
"Onions.run|ONIONS",
"Peas_-_(animals).run|PEAS",
"Potatoes.run|SPOTATOES",
"Soybeans.run|SOYBEAN",
"Spring_-_cereals.run|SCEREALS",
"Strawberries.run|STRAWBER",
"Sugar_-_beets.run|SUGARBEET",
"Sunflower.run|SUNFLOWER",
"Tobacco.run|TOBACCO",
"Tomatoes.run|TOMATOES",
"Vines.run|VINES",
"Winter_-_cereals.run|WCEREALS"
    }


    Public Shared MACROCrops As String() =
        {
             "Cereals, winter|WCEREALS",
             "Cereals, spring|SCEREALS",
             "Oil seed rape, winter|WOILSEED",
             "Sugar beets|SUGARBEET",
             "Potatoes|SPOTATOES",
             "Vegetables, root|CARROTS",
             "Vegetables, leafy|CABBAGE",
             "Vegetables, bulb|ONIONS",
             "Legumes|PEAS",
             "Vegetables, fruiting|TOMATOES",
             "Maize|MAIZE",
             "Vines|VINES",
             "Pome/stone fruit|APPLES",
             "Grass/alfalfa|GRASS",
             "Oil seed rape, spring|SOILSEED",
             "Strawberries|STRAWBER",
             "Bush berries|BUSHBERR"
    }


    Public Shared Function createMACROresources(
                            parFolder As String,
                            resFolder As String,
                            Optional resPathclear As Boolean = True) As Boolean


#Region "    Definitions"

        Dim parFiles As New List(Of String)
        Dim parFile As String() = {}
        Dim row As New List(Of String)

        Dim resFiles As String() = {}
        Dim resFile As String() = {}
        Dim resName As String = ""

        Dim ParMetInt As String = ""

        Const searchScenario As String = "Scenario :  "
        Const searchCrop As String = "Crop :"
        Const searchPath As String = "Output File ="

        Dim Scenario As String = ""
        Dim Crop As String = ""

        Dim tempArray As String() = {}

        Dim skipOUTPUTS As Boolean = False

        Dim oldScenario As String = ""
        Dim MacroCropList As New List(Of String)

#End Region

        'get par files
        Try

            parFiles.AddRange(Directory.GetFiles(
                       path:=parFolder,
                       searchPattern:="macro*.par"))

            parFiles.AddRange(Directory.GetFiles(
                       path:=parFolder,
                       searchPattern:="input*.par"))

            parFiles.AddRange(Directory.GetFiles(
                       path:=parFolder,
                       searchPattern:="metab*.par"))


            mylog(LogTxt:=parFiles.Count & " par files found in " & parFolder)

        Catch ex As Exception
            mylog(LogTxtArray:=parseExceptionMsg(ex))
            Return False
        End Try

        'clear res path
        If resPathclear Then

            Try
                resFiles =
                    Directory.GetFiles(
                        path:=resFolder,
                        searchPattern:="*.res",
                        searchOption:=SearchOption.TopDirectoryOnly)

                For Each member As String In resFiles
                    Try
                        File.Delete(member)
                    Catch ex As Exception
                        mylog(LogTxtArray:=parseExceptionMsg(ex))
                    End Try
                Next
            Catch ex As Exception
                mylog(LogTxtArray:=parseExceptionMsg(ex))
            End Try

        End If

        mylog(LogTxt:=" ")

        For Each member As String In parFiles

            'read file
            Try
                parFile = File.ReadAllLines(path:=member)
            Catch ex As Exception
                mylog(LogTxtArray:=parseExceptionMsg(Exception:=ex))
            End Try

            'crop
            Crop = ""
            Try

                Crop = Trim(Array.Find(
                                  array:=parFile,
                                  match:=Function(x) (x.StartsWith(searchCrop))).Split(":").Last)

                Crop = Trim(Replace(
                            Expression:=Crop,
                            Find:=", not irrigated",
                            Replacement:=""))

                Crop = Trim(Replace(
                            Expression:=Crop,
                            Find:=", irrigated",
                            Replacement:=""))

                If Not MacroCropList.Contains(Crop) Then
                    MacroCropList.Add(Crop)
                End If

                For cropCounter As Integer = 0 To MACROCrops.Count - 1
                    If Crop.Contains(MACROCrops(cropCounter).Split("|")(0)) Then
                        Crop = MACROCrops(cropCounter).Split("|")(1)
                        Exit For
                    End If
                Next

                If Crop.Length < 2 Then
                    MsgBox("")
                    Return False
                End If

            Catch ex As Exception
                mylog(LogTxtArray:=parseExceptionMsg(Exception:=ex))
            End Try


            'scenario
            Try

                Scenario = Trim(Array.Find(
                                  array:=parFile,
                                  match:=Function(x) (x.StartsWith(searchScenario))).Split(":").Last)

                Scenario = Trim(Scenario).Substring(0, 4).ToUpper

            Catch ex As Exception
                mylog(LogTxtArray:=parseExceptionMsg(Exception:=ex))
            End Try

            'progress bar
            If Scenario <> oldScenario Then
                mylog(LogTxt:=Scenario & " " & Crop,
                      Log2Console:=eLog2Console.Only)
                oldScenario = Scenario
            Else
                mylog(LogTxt:=" " & Crop,
                      Add2PreviousRow:=True,
                      Log2Console:=eLog2Console.Only)
            End If

            'parent, metabolite or intermediate run
            ParMetInt = Path.GetFileNameWithoutExtension(member).Substring(0, 5)

            'par, met or int defines the RUNID 1,2 or 3
            Select Case ParMetInt.ToLower

                Case "macro"
                    ParMetInt = sParIntMet(0)
                    parFile(2) =
                        "RUNID".PadRight("NUMERICAL LAYERS".Length) & vbTab & "1"

                Case "input"
                    ParMetInt = sParIntMet(1)
                    parFile(2) =
                        "RUNID".PadRight("NUMERICAL LAYERS".Length) & vbTab & "2"

                Case "metab"
                    ParMetInt = sParIntMet(2)
                    parFile(2) =
                        "RUNID".PadRight("NUMERICAL LAYERS".Length) & vbTab & "3"

                Case Else
                    ParMetInt = "III"
                    parFile(2) =
                        "RUNID".PadRight("NUMERICAL LAYERS".Length) & vbTab & "999"

            End Select

            'prepare DT50 and Sorption row
            parFile(DT50andSorptionRow) =
                headerStart &
                DT50andSorptionDelimiter & "DT50 : " &
                DT50andSorptionDelimiter & "Sorption : "

            'prepare GAP row
            parFile(GAProw) = headerStart & " |  GAP : "

            'reset sorption to 999L/kg as 1/n = 1
            If Not resetSorption(
                        resfile:=parFile,
                        Sorption:=999,
                        Freundlich:=1,
                        reset:=True) Then
                mylog(LogTxt:="Can't reset sorption")

                Return False

            End If

            'reset DT50 to 999 days and tempmoist on
            If Not resetDT50soil(
                resFile:=parFile,
                DT50soil:=999,
                TempCorr:=True,
                MoistCorr:=True,
                reset:=True) Then
                mylog(LogTxt:="Can't reset DEGMAL/MAS/MIL/MIS")

                Return False

            End If


            resName = Scenario & fileNameDelimiter &
                      Crop & fileNameDelimiter &
                      ParMetInt.ToUpper & ".res"

            'header  = Scenario, Crop, ParMetInt

            parFile(1) =
                        headerStart &
                        Join(SourceArray:={Scenario, Crop, ParMetInt}, Delimiter:=" ")

            parFile(0) =
                        headerStart &
                        My.Application.Info.AssemblyName & " v" &
                        Assembly.GetExecutingAssembly().GetName().Version.ToString() & " on " &
                        Now.ToLongDateString

            're-align par file
            For counter As Integer = 3 To parFile.Count - 1

                row.Clear()
                row.AddRange(parFile(counter).Split(vbTab))

                'header section with bigger alignment
                If counter < 6 Then
                    parFile(counter) = row.First.PadRight(Space + 6) & vbTab & row.Last
                    Continue For
                End If

                'just three numbers
                If resName.Contains("INT") Then

                    Try

                        If Integer.TryParse(s:=row.First, result:=-1) = -1 Then
                            parFile(counter) = row.First.PadRight(3) & vbTab
                            row.RemoveAt(0)
                            parFile(counter) &= Join(SourceArray:=row.ToArray, Delimiter:=vbTab)
                            Continue For
                        End If

                    Catch ex As Exception
                        mylog(LogTxtArray:=parseExceptionMsg(ex))
                    End Try
                End If

                'special rows, delete pathnames, no OUTPUTS to align
                Select Case row.First

                    'can't align OUTPUTS
                    Case "OUTPUTS"
                        skipOUTPUTS = True

                    Case "BOUNDARY AND INITIAL CONDITIONS"
                        skipOUTPUTS = False

                    Case "DRIVINGFILE"
                        parFile(counter) = "DRIVINGFILE".PadRight(Space) & vbTab & "macro999.bin"
                        Continue For

                    Case "OUTPUTFILE"
                        Try
                            parFile(counter) = "OUTPUTFILE".PadRight(Space) & vbTab &
                               Path.GetFileName(parFile(counter).Split(vbTab).Last)
                        Catch ex As Exception
                            mylog(LogTxtArray:=parseExceptionMsg(ex))
                        End Try

                    Case "METFILE"
                        Try
                            parFile(counter) = "METFILE".PadRight(Space) & vbTab &
                               Path.GetFileName(parFile(counter).Split(vbTab).Last)

                            parFile(1) = parFile(1) & " " &
                                Path.GetFileName(parFile(counter).Split(vbTab).Last)

                        Catch ex As Exception
                            mylog(LogTxtArray:=parseExceptionMsg(ex))
                        End Try

                    Case "RAINFALLFILE"
                        Try

                            parFile(counter) = "RAINFALLFILE".PadRight(Space) & vbTab &
                               Path.GetFileName(parFile(counter).Split(vbTab).Last)

                            parFile(1) = parFile(1) & " " &
                                Path.GetFileName(parFile(counter).Split(vbTab).Last)

                            'parFile(1) = parFile(1) & " " &
                            '    FOCUSPath

                        Catch ex As Exception
                            mylog(LogTxtArray:=parseExceptionMsg(ex))
                        End Try

                        Continue For

                    Case Else

                        If row.Count = 1 Then
                            parFile(counter) = row.First
                            Continue For
                        End If

                        If Not skipOUTPUTS Then
                            parFile(counter) = row.First.PadRight(Space) & vbTab
                            row.RemoveAt(0)
                            parFile(counter) &= Join(SourceArray:=row.ToArray, Delimiter:=vbTab)
                        End If


                End Select

            Next

            '2nd season?
            If secVegetationPeriodMACRO.Contains(
            Path.GetFileNameWithoutExtension(resName).Substring(
                            startIndex:=0,
                            length:=5)) Then
                '1st
                Try
                    File.WriteAllLines(
                        path:=Path.Combine(
                                    path1:=resFolder,
                                    path2:=Scenario & fileNameDelimiter &
                                           Crop & fileNameDelimiter &
                                           ParMetInt.ToUpper & fileNameDelimiter &
                                           "1st.res"),
                        contents:=parFile)
                Catch ex As Exception
                    mylog(LogTxtArray:=parseExceptionMsg(Exception:=ex))
                End Try

                '2nd
                Try
                    File.WriteAllLines(
                        path:=Path.Combine(
                                    path1:=resFolder,
                                    path2:=Scenario & fileNameDelimiter &
                                           Crop & fileNameDelimiter &
                                           ParMetInt.ToUpper & fileNameDelimiter &
                                           "2nd.res"),
                        contents:=parFile)
                Catch ex As Exception
                    mylog(LogTxtArray:=parseExceptionMsg(Exception:=ex))
                End Try

            Else

                Try
                    File.WriteAllLines(
                        path:=Path.Combine(
                                        path1:=resFolder,
                                        path2:=resName),
                        contents:=parFile)
                Catch ex As Exception
                    mylog(LogTxtArray:=parseExceptionMsg(Exception:=ex))
                End Try

            End If

        Next


        File.WriteAllLines(path:=Path.Combine(
                                        path1:=resFolder,
                                        path2:="Crops.txt"), contents:=MacroCropList.ToArray)

        Return True

    End Function

    Public Shared secVegetationPeriodMACRO As String() =
        {
        "D3_VL",
        "D6_FB",
        "D6_VB",
        "D6_PO"}

#End Region

#Region "    GW Scenarios"

    'All nine FOCUS scenarios, incl. not def
    <TypeConverter(GetType(EnumConverter_eScenariosGW))>
    Public Enum eScenariosGW

        Chateaudun
        Hamburg
        Jokioinen
        Kremsmuenster
        Okehampton
        Piacenza
        Porto
        Sevilla
        Thiva

        <Description(" - ")>
        notdef

    End Enum

    ''' <summary>
    ''' Converts a string to FOCUS scenario enum
    ''' </summary>
    ''' <param name="scenarioString">
    ''' string that contains scenario info
    ''' </param>
    ''' <returns>
    ''' enum eScenariosGW
    ''' </returns>
    Public Shared Function getScenarioByString(scenarioString As String) As eScenariosGW

        Dim search As String()

        Try

            For rowCounter As Integer = 0 To dbScenariosGW.Count - 1

                search = dbScenariosGW(rowCounter).Split(",")

                If scenarioString.Contains(search.First) Then

                    Return _
                    [Enum].Parse(
                        enumType:=GetType(eScenariosGW),
                        value:=search(1))

                End If

            Next

        Catch ex As Exception

            mylog(
                LogTxtArray:=
                parseExceptionMsg(
                    Exception:=ex,
                    UserErrorDescription:=
                        "Error parsing scenario string" & vbCrLf &
                        scenarioString))

        End Try

        Return eScenariosGW.notdef

    End Function


    Public Shared Property dbScenariosGW As String() =
        {
"eau,Chateaudun, Cha,C",
"ham,Hamburg,Ham,H",
"jok,Jokioinen,JOK,J",
"krem,Kremsmuenster,Krm,K",
"oke,Okehampton,Oke,N",
"pia,Piacenza,Pia,P",
"por,Porto,Por,O",
"sev,Sevilla,Sev,S",
"thiv,Thiva,Thi,T"
        }

#End Region

#Region "    Scenarios per Crop"

    Public Shared isNotEmptyDate As New Date(year:=1901, month:=1, day:=1)

    'Public Shared Function getScenariosPerCrop(
    '                            ByRef test As scenarioApplnDates,
    '                            crop As eCropsGW,
    '                            Optional season As eSeason = eSeason.first) As Boolean

    '    Dim row As String = String.Empty
    '    Dim out As New List(Of String)


    '    If crop = eCropsGW.notDef Then Return True

    '    If IsNothing(test) Then test = New scenarioApplnDates

    '    If season = eSeason.first Then
    '        row =
    '            Array.Find(
    '            array:=cropXscenario1st,
    '            Function(s) s.ToLower.Contains(crop.ToString.ToLower))
    '    Else
    '        row =
    '            Array.Find(
    '            array:=cropXscenario2nd,
    '            Function(s) s.ToLower.Contains(crop.ToString.ToLower))
    '    End If

    '    If IsNothing(row) Then
    '        test = Nothing
    '        Return True
    '    Else

    '        out.AddRange(row.Split(","))
    '        out.RemoveAt(0)

    '        With test

    '            For counter As Integer = eScenariosGW.Chateaudun To eScenariosGW.Thiva
    '                If out(counter).Length > 3 Then
    '                    .applnDates(counter) = isNotEmptyDate
    '                End If
    '            Next

    '        End With

    '        Return True

    '    End If

    'End Function


    Public Shared Property cropXscenario1st As String() =
        {
"APPLES,Chateaudun,Hamburg,Jokioinen,Kremsmuenster,Okehampton,Piacenza,Porto,Sevilla,Thiva",
"FLDBEANS, ,Hamburg, ,Kremsmuenster,Okehampton, , , ,",
"VEGBEANS, , , , , , ,Porto, ,Thiva",
"BUSHBERR, , ,Jokioinen, , , , , ,",
"CABBAGE,Chateaudun,Hamburg,Jokioinen,Kremsmuenster, , ,Porto,Sevilla,Thiva",
"CARROTS,Chateaudun,Hamburg,Jokioinen,Kremsmuenster, , ,Porto, ,Thiva",
"CITRUS, , , , , ,Piacenza,Porto,Sevilla,Thiva",
"COTTON, , , , , , , ,Sevilla,Thiva",
"GRASS,Chateaudun,Hamburg,Jokioinen,Kremsmuenster,Okehampton,Piacenza,Porto,Sevilla,Thiva",
"LINSEED, , , , ,Okehampton, , , ,",
"MAIZE,Chateaudun,Hamburg, ,Kremsmuenster,Okehampton,Piacenza,Porto,Sevilla,Thiva",
"SOILSEED, , ,Jokioinen, ,Okehampton, ,Porto, , ",
"WOILSEED,Chateaudun,Hamburg, ,Kremsmuenster,Okehampton,Piacenza,Porto, , ",
"ONIONS,Chateaudun,Hamburg,Jokioinen,Kremsmuenster, , ,Porto, ,Thiva",
"PEAS,Chateaudun,Hamburg,Jokioinen, ,Okehampton, , , , ",
"POTATOES,Chateaudun,Hamburg,Jokioinen,Kremsmuenster,Okehampton,Piacenza,Porto,Sevilla,Thiva",
"SOYBEAN, , , , , ,Piacenza, , , ",
"SCEREALS,Chateaudun,Hamburg,Jokioinen,Kremsmuenster, , ,Porto, , ",
"STRAWBER, ,Hamburg,Jokioinen,Kremsmuenster, , , ,Sevilla, ",
"SUGARBEET,Chateaudun,Hamburg,Jokioinen,Kremsmuenster,Okehampton,Piacenza,Porto,Sevilla,Thiva",
"SUNFLOWER, , , , , ,Piacenza, ,Sevilla, ",
"TOBACCO, , , , , ,Piacenza, , ,Thiva",
"TOMATOES,Chateaudun, , , , ,Piacenza,Porto,Sevilla,Thiva",
"VINES,Chateaudun,Hamburg, ,Kremsmuenster, ,Piacenza,Porto,Sevilla,Thiva",
"WCEREALS,Chateaudun,Hamburg,Jokioinen,Kremsmuenster,Okehampton,Piacenza,Porto,Sevilla,Thiva",
"BARESOIL,Chateaudun,Hamburg,Jokioinen,Kremsmuenster,Okehampton,Piacenza,Porto,Sevilla,Thiva"
    }

    Public Shared Property cropXscenario2nd As String() =
        {
"CABBAGE,Chateaudun,Hamburg, ,Kremsmuenster, , ,Porto,Sevilla, ,",
"CARROTS,Chateaudun,Hamburg, ,Kremsmuenster, , ,Porto, ,Thiva",
"VEGBEANS, , , , , , , , ,Thiva"
    }

#End Region


#Region "PERSAM"


    Public Shared washOffDB As String() =
       {
    "apples,BBCH 00-09,0.55",
"apples,BBCH 10-69,0.6",
"apples,BBCH 71-75,0.6",
"apples,BBCH 76-89,0.55",
"beans,BBCH 00-09,0",
"beans,BBCH 10-19,0.6",
"beans,BBCH 20-39,0.75",
"beans,BBCH 40-89,0.8",
"beans,BBCH 90-99,0.35",
"bushBerries,BBCH 00-09,0.5",
"bushBerries,BBCH 10-69,0.6",
"bushBerries,BBCH 71-89,0.55",
"cabbage,BBCH 00-09,0",
"cabbage,BBCH 10-19,0.6",
"cabbage,BBCH 20-39,0.8",
"cabbage,BBCH 40-49,0.4",
"cabbage,BBCH 50-89,0",
"cabbage,BBCH 90-99,0",
"carrots,BBCH 00-09,0",
"carrots,BBCH 10-19,0.75",
"carrots,BBCH 20-39,0.85",
"carrots,BBCH 40-49,0.5",
"carrots,BBCH 50-89,0",
"carrots,BBCH 90-99,0",
"cotton,BBCH 00-09,0",
"cotton,BBCH 10-19,0.65",
"cotton,BBCH 20-39,0.75",
"cotton,BBCH 40-89,0.65",
"cotton,BBCH 90-99,0.45",
"fallow,BBCH 00-99,0",
"hops,BBCH 00-09,0.5",
"hops,BBCH 11-13,0.55",
"hops,BBCH 14-19,0.55",
"hops,BBCH 20-52,0.55",
"hops,BBCH 53-69,0.55",
"hops,BBCH 71-89,0.6",
"linseed,BBCH 00-09,0",
"linseed,BBCH 10-19,0.55",
"linseed,BBCH 20-39,0.75",
"linseed,BBCH 40-89,0.6",
"linseed,BBCH 90-99,0.3",
"maize,BBCH 00-09,0",
"maize,BBCH 10-19,0.45",
"maize,BBCH 20-39,0.65",
"maize,BBCH 40-89,0.7",
"maize,BBCH 90-99,0.55",
"oilseedRapeSummer,BBCH 00-09,0",
"oilseedRapeSummer,BBCH 10-19,0.4",
"oilseedRapeSummer,BBCH 20-39,0.5",
"oilseedRapeSummer,BBCH 40-89,0.6",
"oilseedRapeSummer,BBCH 90-99,0.5",
"oilseedRapeWinter,BBCH 00-09,0",
"oilseedRapeWinter,BBCH 10-19,0.1",
"oilseedRapeWinter,BBCH 20-39,0.4",
"oilseedRapeWinter,BBCH 40-89,0.55",
"oilseedRapeWinter,BBCH 90-99,0.3",
"onions,BBCH 00-09,0",
"onions,BBCH 10-19,0.6",
"onions,BBCH 20-39,0.75",
"onions,BBCH 40-49,0.55",
"onions,BBCH 50-89,0",
"onions,BBCH 90-99,0",
"peas,BBCH 00-09,0",
"peas,BBCH 10-19,0.4",
"peas,BBCH 20-39,0.6",
"peas,BBCH 40-89,0.65",
"peas,BBCH 90-99,0.35",
"potatoes,BBCH 00-09,0",
"potatoes,BBCH 10-19,0.3",
"potatoes,BBCH 20-39,0.5",
"potatoes,BBCH 40-89,0.6",
"potatoes,BBCH 90-99,0.35",
"soybean,BBCH 00-09,0",
"soybean,BBCH 10-19,0.55",
"soybean,BBCH 20-39,0.75",
"soybean,BBCH 40-89,0.8",
"soybean,BBCH 90-99,0.35",
"springCereals,BBCH 00-09,0",
"springCereals,BBCH 10-19,0.4",
"springCereals,BBCH 20-29,0.5",
"springCereals,BBCH 30-39,0.5",
"springCereals,BBCH 40-69,0.65",
"springCereals,BBCH 70-89,0.65",
"springCereals,BBCH 90-99,0.55",
"strawberries,BBCH 00-09,0",
"strawberries,BBCH 10-19,0.5",
"strawberries,BBCH 20-39,0.7",
"strawberries,BBCH 40-89,0.75",
"strawberries,BBCH 90-99,0.5",
"sugarBeets,BBCH 00-09,0",
"sugarBeets,BBCH 10-19,0.4",
"sugarBeets,BBCH 20-39,0.6",
"sugarBeets,BBCH 40-49,0.6",
"sugarBeets,BBCH 50-89,0",
"sugarBeets,BBCH 90-99,0",
"sunflowers,BBCH 00-09,0",
"sunflowers,BBCH 10-19,0.6",
"sunflowers,BBCH 20-39,0.75",
"sunflowers,BBCH 40-89,0.8",
"sunflowers,BBCH 90-99,0.55",
"tobacco,BBCH 00-09,0",
"tobacco,BBCH 10-19,0.55",
"tobacco,BBCH 20-39,0.75",
"tobacco,BBCH 40-89,0.8",
"tobacco,BBCH 90-99,0.85",
"tomatoes,BBCH 00-09,0",
"tomatoes,BBCH 10-19,0.55",
"tomatoes,BBCH 20-39,0.75",
"tomatoes,BBCH 40-89,0.7",
"tomatoes,BBCH 90-99,0.35",
"vines,BBCH 00-09,0.45",
"vines,BBCH 11-13,0.4",
"vines,BBCH 14-19,0.5",
"vines,BBCH 53-69,0.55",
"vines,BBCH 71-89,0.6",
"winterCereals,BBCH 00-09,0",
"winterCereals,BBCH 10-19,0.1",
"winterCereals,BBCH 20-29,0.4",
"winterCereals,BBCH 30-39,0.6",
"winterCereals,BBCH 40-69,0.55",
"winterCereals,BBCH 70-89,0.6",
"winterCereals,BBCH 90-99,0.4",
"applesInRow,Jan-Mar,0.45",
"applesInRow,Apr-Jun,0.55",
"applesInRow,Jul-Sep,0.55",
"applesInRow,Oct-Dec,0.5",
"bushBerriesInRow,Jan-Mar,0.45",
"bushBerriesInRow,Apr-Jun,0.55",
"bushBerriesInRow,Jul-Sep,0.55",
"bushBerriesInRow,Oct-Dec,0.5",
"citrusInRow,Jan-Mar,0",
"citrusInRow,Apr-Jun,0",
"citrusInRow,Jul-Sep,0",
"citrusInRow,Oct-Dec,0",
"hopsInRow,Jan-Mar,0",
"hopsInRow,Apr-Jun,0",
"hopsInRow,Jul-Sep,0",
"hopsInRow,Oct-Dec,0",
"olivesInRow,Jan-Mar,0",
"olivesInRow,Apr-Jun,0",
"olivesInRow,Jul-Sep,0",
"olivesInRow,Oct-Dec,0",
"vinesInRow,Jan-Mar,0",
"vinesInRow,Apr-Jun,0",
"vinesInRow,Jul-Sep,0",
"vinesInRow,Oct-Dec,0",
"citrus,Jan-Mar,0.5",
"citrus,Apr-Jun,0.3",
"citrus,Jul-Sep,0.15",
"citrus,Oct-Dec,0.55",
"olives,Jan-Mar,0.5",
"olives,Apr-Jun,0.3",
"olives,Jul-Sep,0.15",
"olives,Oct-Dec,0.5",
"grass,Jan-Mar,0.45",
"grass,Apr-Jun,0.55",
"grass,Jul-Sep,0.55",
"grass,Oct-Dec,0.5"
    }

    Public Shared Function getPossibleBBCH(PERSAMcrop As ePERSAMcrops) As String()

        Dim out As String()

        out =
            Filter(
            Source:=washOffDB,
            Match:=PERSAMcrop.ToString,
            Include:=True,
            Compare:=CompareMethod.Text)

        If PERSAMcrop.ToString.EndsWith("InRow") Then
            out =
                Filter(
                Source:=out,
                Match:="InRow",
                Include:=True,
                Compare:=CompareMethod.Text)
        Else
            out =
                Filter(
                Source:=out,
                Match:="InRow",
                Include:=False,
                Compare:=CompareMethod.Text)
        End If


        Return out

    End Function

    <TypeConverter(GetType(EnumConverter_ePERSAMCrop))>
    Public Enum ePERSAMcrops

        <Description("Apples (application on crop in row)")>
        applesInRow
        <Description("Apples (between crop in row. grass)")>
        apples
        <Description("Beans (field. veg.)")>
        beans
        <Description("Bush berries (application on crop in row)")>
        bushBerriesInRow
        <Description("Bush berries (between crop in row. grass)")>
        bushBerries
        <Description("Cabbage")>
        cabbage
        <Description("Carrots")>
        carrots
        <Description("Citrus (application on crop in row)")>
        citrusInRow
        <Description("Citrus (between crop in row. bare soil)")>
        citrus
        <Description("Cotton")>
        cotton
        <Description("Fallow")>
        fallow
        <Description("Grass (pasture)")>
        grass
        <Description("Hops (application on crop in row)")>
        hopsInRow
        <Description("Hops (between crop in row. bare soil)")>
        hops
        <Description("Linseed")>
        linseed
        <Description("Maize")>
        maize
        <Description("Oilseed rape (summer)")>
        oilseedRapeSummer
        <Description("Oilseed rape (winter)")>
        oilseedRapeWinter
        <Description("Olives (application on crop in row)")>
        olivesInRow
        <Description("Olives (between crop in row. bare soil)")>
        olives
        <Description("Onions")>
        onions
        <Description("Peas")>
        peas
        <Description("Potatoes")>
        potatoes
        <Description("Soybean")>
        soybean
        <Description("Spring cereals")>
        springCereals
        <Description("Strawberries")>
        strawberries
        <Description("Sugar beets")>
        sugarBeets
        <Description("Sunflowers")>
        sunflowers
        <Description("Tobacco")>
        tobacco
        <Description("Tomatoes")>
        tomatoes
        <Description("Vines (application on crop in row)")>
        vinesInRow
        <Description("Vines (between crop in row. bare soil)")>
        vines
        <Description("Winter cereals")>
        winterCereals
        <Description(" - ")>
        notDef

    End Enum

    Public Shared translateGW2PERSAMdb As String() =
        {
            "APPLES", "apples", "applesInRow",
            "FLDBEANS", "beans", "",
            "VEGBEANS", "beans", "",
            "BUSHBERR", "bushBerries", "bushBerriesInRow",
            "CABBAGE", "cabbage", "",
            "CARROTS", "carrots", "",
            "CITRUS", "citrus", "citrusInRow",
            "COTTON", "cotton", "",
            "GRASS", "grass", "",
            "LINSEED", "linseed", "",
            "MAIZE", "maize", "",
            "SOILSEED", "oilseedRapeSummer", "",
            "WOILSEED", "oilseedRapeWinter", "",
            "ONIONS", "onions", "",
            "PEAS", "peas", "",
            "SPOTATOES", "potatoes", "",
            "SOYBEAN", "soybean", "",
            "SCEREALS", "springCereals", "",
            "STRAWBER", "strawberries", "",
            "SUGARBEET", "sugarBeets", "",
            "SUNFLOWER", "sunflowers", "",
            "TOBACCO", "tobacco", "",
            "TOMATOES", "tomatoes", "",
            "VINES", "vines", "vinesInRow",
            "WCEREALS", "winterCereals", "",
            "BARESOIL", "fallow", ""
        }

    Public Enum eOnOrBetweenCrop
        onCrop
        betweenCrop
    End Enum

#End Region


End Class

#Region " enum converter"


Public Class EnumConverter_eMACROVersion

    Inherits EnumConverter

    'usage :  <TypeConverter(GetType(EnumConverter_eFOCUSswScenario))>

    Public Shared notDef As String() = {}

    Public Shared _enumType As Type

    Public Shared Function isdefined(value As Integer) As Boolean

        Dim fi As FieldInfo = _enumType.GetField([Enum].GetName(_enumType, value))

        Dim dna As DescriptionAttribute = DirectCast(
            Attribute.GetCustomAttribute(fi, GetType(DescriptionAttribute)), DescriptionAttribute)

        If dna IsNot Nothing Then

            If notDef.Contains(dna.Description) Then
                Return False
            Else
                Return True
            End If

        Else

            Return True

        End If

    End Function


    ''' <summary>
    ''' Initializing instance
    ''' </summary>
    ''' <param name="type">
    ''' this is only one function, that you must
    ''' change. All another functions for enums
    ''' you can use by Ctrl+C/Ctrl+V
    ''' </param>
    ''' <remarks></remarks>
    Public Sub New(type As Type)
        MyBase.New(type)
        _enumType = type
    End Sub

    Public Overrides Function CanConvertTo(context As ITypeDescriptorContext, destType As Type) As Boolean
        Return destType = GetType(String)
    End Function

    Public Overrides Function ConvertTo(
                                    context As ITypeDescriptorContext,
                                    culture As CultureInfo,
                                    value As Object,
                                    destType As Type) As Object

        Dim fi As FieldInfo = _enumType.GetField([Enum].GetName(_enumType, value))
        Dim dna As DescriptionAttribute = DirectCast(
            Attribute.GetCustomAttribute(fi, GetType(DescriptionAttribute)), DescriptionAttribute)

        If dna IsNot Nothing Then

            If notDef.Contains(dna.Description) Then

                Return dna.Description & " not def."
            Else
                Return dna.Description
            End If

        Else
            Return value.ToString()
        End If
    End Function

    Public Overrides Function CanConvertFrom(
                                            context As ITypeDescriptorContext,
                                            srcType As Type) As Boolean
        Return srcType = GetType(String)
    End Function

    Public Overrides Function ConvertFrom(context As ITypeDescriptorContext,
                                          culture As CultureInfo,
                                          value As Object) As Object

        For Each fi As FieldInfo In _enumType.GetFields()

            Dim dna As DescriptionAttribute =
                DirectCast(Attribute.GetCustomAttribute(fi,
                                                        GetType(DescriptionAttribute)),
                                    DescriptionAttribute)


            'If DirectCast(value, String).Contains("not def") Then Return -1

            If (dna IsNot Nothing) AndAlso (DirectCast(value, String).StartsWith(dna.Description)) Then
                Return [Enum].Parse(_enumType, fi.Name)
            End If

        Next

        Return [Enum].Parse(_enumType, DirectCast(value, String))

    End Function

End Class


Public Class EnumConverter_ePEARLVersion

    Inherits EnumConverter

    'usage :  <TypeConverter(GetType(EnumConverter_eFOCUSswScenario))>

    Public Shared notDef As String() = {}

    Public Shared _enumType As Type

    Public Shared Function isdefined(value As Integer) As Boolean

        Dim fi As FieldInfo = _enumType.GetField([Enum].GetName(_enumType, value))

        Dim dna As DescriptionAttribute = DirectCast(
            Attribute.GetCustomAttribute(fi, GetType(DescriptionAttribute)), DescriptionAttribute)

        If dna IsNot Nothing Then

            If notDef.Contains(dna.Description) Then
                Return False
            Else
                Return True
            End If

        Else

            Return True

        End If

    End Function


    ''' <summary>
    ''' Initializing instance
    ''' </summary>
    ''' <param name="type">
    ''' this is only one function, that you must
    ''' change. All another functions for enums
    ''' you can use by Ctrl+C/Ctrl+V
    ''' </param>
    ''' <remarks></remarks>
    Public Sub New(type As Type)
        MyBase.New(type)
        _enumType = type
    End Sub

    Public Overrides Function CanConvertTo(context As ITypeDescriptorContext, destType As Type) As Boolean
        Return destType = GetType(String)
    End Function

    Public Overrides Function ConvertTo(
                                    context As ITypeDescriptorContext,
                                    culture As CultureInfo,
                                    value As Object,
                                    destType As Type) As Object

        Dim fi As FieldInfo = _enumType.GetField([Enum].GetName(_enumType, value))
        Dim dna As DescriptionAttribute = DirectCast(
            Attribute.GetCustomAttribute(fi, GetType(DescriptionAttribute)), DescriptionAttribute)

        If dna IsNot Nothing Then

            If notDef.Contains(dna.Description) Then

                Return dna.Description & " not def."
            Else
                Return dna.Description
            End If

        Else
            Return value.ToString()
        End If
    End Function

    Public Overrides Function CanConvertFrom(
                                            context As ITypeDescriptorContext,
                                            srcType As Type) As Boolean
        Return srcType = GetType(String)
    End Function

    Public Overrides Function ConvertFrom(context As ITypeDescriptorContext,
                                          culture As CultureInfo,
                                          value As Object) As Object

        For Each fi As FieldInfo In _enumType.GetFields()

            Dim dna As DescriptionAttribute =
                DirectCast(Attribute.GetCustomAttribute(fi,
                                                        GetType(DescriptionAttribute)),
                                    DescriptionAttribute)


            'If DirectCast(value, String).Contains("not def") Then Return -1

            If (dna IsNot Nothing) AndAlso (DirectCast(value, String).StartsWith(dna.Description)) Then
                Return [Enum].Parse(_enumType, fi.Name)
            End If

        Next

        Return [Enum].Parse(_enumType, DirectCast(value, String))

    End Function

End Class
Public Class EnumConverter_ePELMOVersion

    Inherits EnumConverter

    'usage :  <TypeConverter(GetType(EnumConverter_eFOCUSswScenario))>

    Public Shared notDef As String() = {}

    Public Shared _enumType As Type

    Public Shared Function isdefined(value As Integer) As Boolean

        Dim fi As FieldInfo = _enumType.GetField([Enum].GetName(_enumType, value))

        Dim dna As DescriptionAttribute = DirectCast(
            Attribute.GetCustomAttribute(fi, GetType(DescriptionAttribute)), DescriptionAttribute)

        If dna IsNot Nothing Then

            If notDef.Contains(dna.Description) Then
                Return False
            Else
                Return True
            End If

        Else

            Return True

        End If

    End Function


    ''' <summary>
    ''' Initializing instance
    ''' </summary>
    ''' <param name="type">
    ''' this is only one function, that you must
    ''' change. All another functions for enums
    ''' you can use by Ctrl+C/Ctrl+V
    ''' </param>
    ''' <remarks></remarks>
    Public Sub New(type As Type)
        MyBase.New(type)
        _enumType = type
    End Sub

    Public Overrides Function CanConvertTo(context As ITypeDescriptorContext, destType As Type) As Boolean
        Return destType = GetType(String)
    End Function

    Public Overrides Function ConvertTo(
                                    context As ITypeDescriptorContext,
                                    culture As CultureInfo,
                                    value As Object,
                                    destType As Type) As Object

        Dim fi As FieldInfo = _enumType.GetField([Enum].GetName(_enumType, value))
        Dim dna As DescriptionAttribute = DirectCast(
            Attribute.GetCustomAttribute(fi, GetType(DescriptionAttribute)), DescriptionAttribute)

        If dna IsNot Nothing Then

            If notDef.Contains(dna.Description) Then

                Return dna.Description & " not def."
            Else
                Return dna.Description
            End If

        Else
            Return value.ToString()
        End If
    End Function

    Public Overrides Function CanConvertFrom(
                                            context As ITypeDescriptorContext,
                                            srcType As Type) As Boolean
        Return srcType = GetType(String)
    End Function

    Public Overrides Function ConvertFrom(context As ITypeDescriptorContext,
                                          culture As CultureInfo,
                                          value As Object) As Object

        For Each fi As FieldInfo In _enumType.GetFields()

            Dim dna As DescriptionAttribute =
                DirectCast(Attribute.GetCustomAttribute(fi,
                                                        GetType(DescriptionAttribute)),
                                    DescriptionAttribute)


            'If DirectCast(value, String).Contains("not def") Then Return -1

            If (dna IsNot Nothing) AndAlso (DirectCast(value, String).StartsWith(dna.Description)) Then
                Return [Enum].Parse(_enumType, fi.Name)
            End If

        Next

        Return [Enum].Parse(_enumType, DirectCast(value, String))

    End Function

End Class
Public Class EnumConverter_eYearlyRepeat

    Inherits EnumConverter

    'usage :  <TypeConverter(GetType(EnumConverter_eFOCUSswScenario))>

    Public Shared notDef As String() = {}

    Public Shared _enumType As Type

    Public Shared Function isdefined(value As Integer) As Boolean

        Dim fi As FieldInfo = _enumType.GetField([Enum].GetName(_enumType, value))

        Dim dna As DescriptionAttribute = DirectCast(
            Attribute.GetCustomAttribute(fi, GetType(DescriptionAttribute)), DescriptionAttribute)

        If dna IsNot Nothing Then

            If notDef.Contains(dna.Description) Then
                Return False
            Else
                Return True
            End If

        Else

            Return True

        End If

    End Function


    ''' <summary>
    ''' Initializing instance
    ''' </summary>
    ''' <param name="type">
    ''' this is only one function, that you must
    ''' change. All another functions for enums
    ''' you can use by Ctrl+C/Ctrl+V
    ''' </param>
    ''' <remarks></remarks>
    Public Sub New(type As Type)
        MyBase.New(type)
        _enumType = type
    End Sub

    Public Overrides Function CanConvertTo(context As ITypeDescriptorContext, destType As Type) As Boolean
        Return destType = GetType(String)
    End Function

    Public Overrides Function ConvertTo(
                                    context As ITypeDescriptorContext,
                                    culture As CultureInfo,
                                    value As Object,
                                    destType As Type) As Object

        Dim fi As FieldInfo = _enumType.GetField([Enum].GetName(_enumType, value))
        Dim dna As DescriptionAttribute = DirectCast(
            Attribute.GetCustomAttribute(fi, GetType(DescriptionAttribute)), DescriptionAttribute)

        If dna IsNot Nothing Then

            If notDef.Contains(dna.Description) Then

                Return dna.Description & " not def."
            Else
                Return dna.Description
            End If

        Else
            Return value.ToString()
        End If
    End Function

    Public Overrides Function CanConvertFrom(
                                            context As ITypeDescriptorContext,
                                            srcType As Type) As Boolean
        Return srcType = GetType(String)
    End Function

    Public Overrides Function ConvertFrom(context As ITypeDescriptorContext,
                                          culture As CultureInfo,
                                          value As Object) As Object

        For Each fi As FieldInfo In _enumType.GetFields()

            Dim dna As DescriptionAttribute =
                DirectCast(Attribute.GetCustomAttribute(fi,
                                                        GetType(DescriptionAttribute)),
                                    DescriptionAttribute)


            'If DirectCast(value, String).Contains("not def") Then Return -1

            If (dna IsNot Nothing) AndAlso (DirectCast(value, String).StartsWith(dna.Description)) Then
                Return [Enum].Parse(_enumType, fi.Name)
            End If

        Next

        Return [Enum].Parse(_enumType, DirectCast(value, String))

    End Function

End Class
Public Class EnumConverter_eApplnMode

    Inherits EnumConverter

    'usage :  <TypeConverter(GetType(EnumConverter_eFOCUSswScenario))>

    Public Shared notDef As String() = {}

    Public Shared _enumType As Type

    Public Shared Function isdefined(value As Integer) As Boolean

        Dim fi As FieldInfo = _enumType.GetField([Enum].GetName(_enumType, value))

        Dim dna As DescriptionAttribute = DirectCast(
            Attribute.GetCustomAttribute(fi, GetType(DescriptionAttribute)), DescriptionAttribute)

        If dna IsNot Nothing Then

            If notDef.Contains(dna.Description) Then
                Return False
            Else
                Return True
            End If

        Else

            Return True

        End If

    End Function


    ''' <summary>
    ''' Initializing instance
    ''' </summary>
    ''' <param name="type">
    ''' this is only one function, that you must
    ''' change. All another functions for enums
    ''' you can use by Ctrl+C/Ctrl+V
    ''' </param>
    ''' <remarks></remarks>
    Public Sub New(type As Type)
        MyBase.New(type)
        _enumType = type
    End Sub

    Public Overrides Function CanConvertTo(context As ITypeDescriptorContext, destType As Type) As Boolean
        Return destType = GetType(String)
    End Function

    Public Overrides Function ConvertTo(
                                    context As ITypeDescriptorContext,
                                    culture As CultureInfo,
                                    value As Object,
                                    destType As Type) As Object

        Dim fi As FieldInfo = _enumType.GetField([Enum].GetName(_enumType, value))
        Dim dna As DescriptionAttribute = DirectCast(
            Attribute.GetCustomAttribute(fi, GetType(DescriptionAttribute)), DescriptionAttribute)

        If dna IsNot Nothing Then

            If notDef.Contains(dna.Description) Then

                Return dna.Description & " not def."
            Else
                Return dna.Description
            End If

        Else
            Return value.ToString()
        End If
    End Function

    Public Overrides Function CanConvertFrom(
                                            context As ITypeDescriptorContext,
                                            srcType As Type) As Boolean
        Return srcType = GetType(String)
    End Function

    Public Overrides Function ConvertFrom(context As ITypeDescriptorContext,
                                          culture As CultureInfo,
                                          value As Object) As Object

        For Each fi As FieldInfo In _enumType.GetFields()

            Dim dna As DescriptionAttribute =
                DirectCast(Attribute.GetCustomAttribute(fi,
                                                        GetType(DescriptionAttribute)),
                                    DescriptionAttribute)


            'If DirectCast(value, String).Contains("not def") Then Return -1

            If (dna IsNot Nothing) AndAlso (DirectCast(value, String).StartsWith(dna.Description)) Then
                Return [Enum].Parse(_enumType, fi.Name)
            End If

        Next

        Return [Enum].Parse(_enumType, DirectCast(value, String))

    End Function

End Class
Public Class EnumConverter_eCropsGW

    Inherits EnumConverter

    'usage :  <TypeConverter(GetType(EnumConverter_eFOCUSswScenario))>

    Public Shared notDef As String() = {}

    Public Shared _enumType As Type

    Public Shared Function isdefined(value As Integer) As Boolean

        Dim fi As FieldInfo = _enumType.GetField([Enum].GetName(_enumType, value))

        Dim dna As DescriptionAttribute = DirectCast(
            Attribute.GetCustomAttribute(fi, GetType(DescriptionAttribute)), DescriptionAttribute)

        If dna IsNot Nothing Then

            If notDef.Contains(dna.Description) Then
                Return False
            Else
                Return True
            End If

        Else

            Return True

        End If

    End Function


    ''' <summary>
    ''' Initializing instance
    ''' </summary>
    ''' <param name="type">
    ''' this is only one function, that you must
    ''' change. All another functions for enums
    ''' you can use by Ctrl+C/Ctrl+V
    ''' </param>
    ''' <remarks></remarks>
    Public Sub New(type As Type)
        MyBase.New(type)
        _enumType = type
    End Sub

    Public Overrides Function CanConvertTo(context As ITypeDescriptorContext, destType As Type) As Boolean
        Return destType = GetType(String)
    End Function

    Public Overrides Function ConvertTo(
                                    context As ITypeDescriptorContext,
                                    culture As CultureInfo,
                                    value As Object,
                                    destType As Type) As Object

        Dim fi As FieldInfo = _enumType.GetField([Enum].GetName(_enumType, value))
        Dim dna As DescriptionAttribute = DirectCast(
            Attribute.GetCustomAttribute(fi, GetType(DescriptionAttribute)), DescriptionAttribute)

        If dna IsNot Nothing Then

            If notDef.Contains(dna.Description) Then

                Return dna.Description & " not def."
            Else
                Return dna.Description
            End If

        Else
            Return value.ToString()
        End If
    End Function

    Public Overrides Function CanConvertFrom(
                                            context As ITypeDescriptorContext,
                                            srcType As Type) As Boolean
        Return srcType = GetType(String)
    End Function

    Public Overrides Function ConvertFrom(context As ITypeDescriptorContext,
                                          culture As CultureInfo,
                                          value As Object) As Object

        For Each fi As FieldInfo In _enumType.GetFields()

            Dim dna As DescriptionAttribute =
                DirectCast(Attribute.GetCustomAttribute(fi,
                                                        GetType(DescriptionAttribute)),
                                    DescriptionAttribute)


            'If DirectCast(value, String).Contains("not def") Then Return -1

            If (dna IsNot Nothing) AndAlso (DirectCast(value, String).StartsWith(dna.Description)) Then
                Return [Enum].Parse(_enumType, fi.Name)
            End If

        Next

        Return [Enum].Parse(_enumType, DirectCast(value, String))

    End Function

End Class
Public Class EnumConverter_eScenariosGW

    Inherits EnumConverter

    'usage :  <TypeConverter(GetType(EnumConverter_eFOCUSswScenario))>

    Public Shared notDef As String() = {}

    Public Shared _enumType As Type

    Public Shared Function isdefined(value As Integer) As Boolean

        Dim fi As FieldInfo = _enumType.GetField([Enum].GetName(_enumType, value))

        Dim dna As DescriptionAttribute = DirectCast(
            Attribute.GetCustomAttribute(fi, GetType(DescriptionAttribute)), DescriptionAttribute)

        If dna IsNot Nothing Then

            If notDef.Contains(dna.Description) Then
                Return False
            Else
                Return True
            End If

        Else

            Return True

        End If

    End Function


    ''' <summary>
    ''' Initializing instance
    ''' </summary>
    ''' <param name="type">
    ''' this is only one function, that you must
    ''' change. All another functions for enums
    ''' you can use by Ctrl+C/Ctrl+V
    ''' </param>
    ''' <remarks></remarks>
    Public Sub New(type As Type)
        MyBase.New(type)
        _enumType = type
    End Sub

    Public Overrides Function CanConvertTo(context As ITypeDescriptorContext, destType As Type) As Boolean
        Return destType = GetType(String)
    End Function

    Public Overrides Function ConvertTo(
                                    context As ITypeDescriptorContext,
                                    culture As CultureInfo,
                                    value As Object,
                                    destType As Type) As Object

        Dim fi As FieldInfo = _enumType.GetField([Enum].GetName(_enumType, value))
        Dim dna As DescriptionAttribute = DirectCast(
            Attribute.GetCustomAttribute(fi, GetType(DescriptionAttribute)), DescriptionAttribute)

        If dna IsNot Nothing Then

            If notDef.Contains(dna.Description) Then

                Return dna.Description & " not def."
            Else
                Return dna.Description
            End If

        Else
            Return value.ToString()
        End If
    End Function

    Public Overrides Function CanConvertFrom(
                                            context As ITypeDescriptorContext,
                                            srcType As Type) As Boolean
        Return srcType = GetType(String)
    End Function

    Public Overrides Function ConvertFrom(context As ITypeDescriptorContext,
                                          culture As CultureInfo,
                                          value As Object) As Object

        For Each fi As FieldInfo In _enumType.GetFields()

            Dim dna As DescriptionAttribute =
                DirectCast(Attribute.GetCustomAttribute(fi,
                                                        GetType(DescriptionAttribute)),
                                    DescriptionAttribute)


            'If DirectCast(value, String).Contains("not def") Then Return -1

            If (dna IsNot Nothing) AndAlso (DirectCast(value, String).StartsWith(dna.Description)) Then
                Return [Enum].Parse(_enumType, fi.Name)
            End If

        Next

        Return [Enum].Parse(_enumType, DirectCast(value, String))

    End Function

End Class


Public Class EnumConverter_ePERSAMCrop

    Inherits EnumConverter

    'usage :  <TypeConverter(GetType(EnumConverter_ePERSAMCrop))>

    Public Shared notDef As String() = {}

    Public Shared _enumType As Type

    Public Shared Function isdefined(value As Integer) As Boolean

        Dim fi As FieldInfo = _enumType.GetField([Enum].GetName(_enumType, value))

        Dim dna As DescriptionAttribute = DirectCast(
            Attribute.GetCustomAttribute(fi, GetType(DescriptionAttribute)), DescriptionAttribute)

        If dna IsNot Nothing Then

            If notDef.Contains(dna.Description) Then
                Return False
            Else
                Return True
            End If

        Else

            Return True

        End If

    End Function


    ''' <summary>
    ''' Initializing instance
    ''' </summary>
    ''' <param name="type">
    ''' this is only one function, that you must
    ''' change. All another functions for enums
    ''' you can use by Ctrl+C/Ctrl+V
    ''' </param>
    ''' <remarks></remarks>
    Public Sub New(type As Type)
        MyBase.New(type)
        _enumType = type
    End Sub

    Public Overrides Function CanConvertTo(context As ITypeDescriptorContext, destType As Type) As Boolean
        Return destType = GetType(String)
    End Function

    Public Overrides Function ConvertTo(
                                    context As ITypeDescriptorContext,
                                    culture As CultureInfo,
                                    value As Object,
                                    destType As Type) As Object

        Dim fi As FieldInfo = _enumType.GetField([Enum].GetName(_enumType, value))
        Dim dna As DescriptionAttribute = DirectCast(
            Attribute.GetCustomAttribute(fi, GetType(DescriptionAttribute)), DescriptionAttribute)

        If dna IsNot Nothing Then

            If notDef.Contains(dna.Description) Then

                Return dna.Description & " not def."
            Else
                Return dna.Description
            End If

        Else
            Return value.ToString()
        End If
    End Function

    Public Overrides Function CanConvertFrom(
                                            context As ITypeDescriptorContext,
                                            srcType As Type) As Boolean
        Return srcType = GetType(String)
    End Function

    Public Overrides Function ConvertFrom(context As ITypeDescriptorContext,
                                          culture As CultureInfo,
                                          value As Object) As Object

        For Each fi As FieldInfo In _enumType.GetFields()

            Dim dna As DescriptionAttribute =
                DirectCast(Attribute.GetCustomAttribute(fi,
                                                        GetType(DescriptionAttribute)),
                                    DescriptionAttribute)


            'If DirectCast(value, String).Contains("not def") Then Return -1

            If (dna IsNot Nothing) AndAlso (DirectCast(value, String).StartsWith(dna.Description)) Then
                Return [Enum].Parse(_enumType, fi.Name)
            End If

        Next

        Return [Enum].Parse(_enumType, DirectCast(value, String))

    End Function

End Class


#End Region