﻿
Imports core

Public Class _00_PECman

    Inherits startClass

    Public Sub New()

    End Sub


    Public Shared endpointType As String = "80th perc."
    Public Shared resultUnit As String = "µg/L"


    Public Overrides Function checkInputComplete() As String
        Throw New NotImplementedException()
    End Function

End Class
