﻿================================================================================
WHAT IS FreeCommander
================================================================================
FreeCommander is an easy-to-use alternative to the standard Windows file manager. 
You can configure almost everything. Supported Windows versions: Windows XP and above.
FreeCommander XE is in two versions 32 and 64 bit. 
Please check the info about using FreeCommander XE 32 bit on 64 bit Windows http://freecommander.com/en/version-summary/    



================================================================================
AFTER YOU HAVE INSTALLED FreeCommander XE
================================================================================

If you have worked with the FreeCommander 2009.02b:
- the settings of the FreeCommander 2009.02b are not compatible with the settings of the FreeCommander XE
- do not copy the old settings to the new settings folder

If you have worked with the FreeCommander XE 32 bit version and now you want use 64 bit version
- the settings are compatible; you can use the settings from the 32 bit version in the 64 bit version
- for moving the settings you can use Tools->Backup all settings, Tools->Restore all settings


The available help files you can download from the site http://freecommander.com/en/languages/  

Trouble with the help file
==========================
When viewing your CHM documentation, Microsoft's HTML Help Viewer is showing an error page saying either that:
 - The action has been canceled 
 - The page cannot be displayed
 
Solutions
 - Launch help file from local drive and not from a network path or via a mapped networked drive.  
 - Make sure your help file isn't in a path with symbols such as "#" (sharp).  
 - In some cases, you can have access to an "unblock" button in the properties page of the help file. Right click on the file then go to its properties and click the "unblock" button. This button is not available in all systems though. 
 - Try the HHReg utility http://www.ec-software.com/products_hhreg.html or read this technical note from the Microsoft Knowledge Base http://support.microsoft.com/kb/896054/.

================================================================================
FEEDBACK & SUGGESTIONS
================================================================================

Direct your feedback, suggestions and bug reports to the FreeCommander forum http://www.forum.freecommander.com
or directly to me marek@freecommander.com but please do not expect that you get an answer immediately :). 


I hope you will enjoy FreeCommander 

MAREK JASINSKI


================================================================================
Important changes and bug fixes in the release 840
================================================================================
- Bug fix: Exception may occurs on switching between one and two panels

================================================================================
Important changes and bug fixes in the release 835
================================================================================
- Bug fix: Program freezes on startup if the drive last used is no longer connected and  plain view mode was used on program close. https://freecommander.com/forum/viewtopic.php?f=19&p=34572#p34572
- Bug fix: Focus is lost on refresh if option "Switch view mode automatically ..." is active https://freecommander.com/forum/viewtopic.php?f=7&t=11288
- Bug fix: Tree maybe not shown if switching from single-panel to dual-panel mode https://freecommander.com/forum/viewtopic.php?f=7&p=34584#p34584
- Bug fix: Sorting is wrong if auto selectable view is active and all options are set to "No change" https://freecommander.com/forum/viewtopic.php?f=7&p=34598#p34598 

================================================================================
Important changes and bug fixes in the release 834
================================================================================
- Bug fix: Exception on maximize window in one panel mode (introduced in 833)

================================================================================
Important changes and bug fixes in the release 833
================================================================================
- Bug fix: Dialog display issue after FC restart with 'Defined font' for dialogs https://freecommander.com/forum/viewtopic.php?f=7&t=11152
- Bug fix: File list display issues after renaming https://freecommander.com/forum/viewtopic.php?f=7&t=11150
- Bug fix: Quick filter delete/backspace bug  https://freecommander.com/forum/viewtopic.php?f=7&p=34195#p34195
- Bug fix: File container drag&drop and cut refresh issue  https://freecommander.com/forum/viewtopic.php?f=7&t=11185
- Bug fix: Automatic view may not work if the "View type" option is set to <No change>
- Bug fix: Some tabs are not created when the layout is restored https://freecommander.com/forum/viewtopic.php?f=19&t=11224&p=34408#p34408
- Bug fix: Quick search does not work properly if some other options are active https://freecommander.com/forum/viewtopic.php?p=34405#p34405 
- Implemented: New action added - Show layouts popup menu 
- Implemented: New action added - Change to last active tab (Ctrl+PgUp)
- Implemented: New timestamp formats added for the definition of the screenshot file name 
- Implemented: New option for quick filter - Keep filter on tab change
- Implemented: New placeholder for using in the status bar: [fc_columnProfile] - name of the used column profile 


================================================================================
Important changes and bug fixes in the release 832
================================================================================
- Bug fix: Focus is lost if going back from archive file (introduced in 831)
- Bug fix: Focus is lost after disabling quick filter (only when using plain view) https://freecommander.com/forum/viewtopic.php?f=7&t=11085
- Bug fix: Few stay on top issues  https://freecommander.com/forum/viewtopic.php?p=33954#p33954
- Bug fix: Exception in search dialog https://freecommander.com/forum/viewtopic.php?f=19&p=34028#p34028
- Bug fix: Bug in saving settings (FavoritesTreeColorSelectedNodeInactive) https://freecommander.com/forum/viewtopic.php?f=7&t=11044
- Bug fix: Selection maybe broken if hover time is used
- Bug fix: Position issue when switching modes in plain view https://freecommander.com/forum/viewtopic.php?f=7&t=11101
- Bug fix: Quick viewer and status bar is not updated when using "focus previous/next item" https://freecommander.com/forum/viewtopic.php?f=7&t=11080
- Bug fix: Language defined as command line parameter is not correctly set https://freecommander.com/forum/viewtopic.php?f=7&t=11136
- Bug fix: Multi rename problem https://freecommander.com/forum/viewtopic.php?f=7&t=10701
- Implemented: Thumbnail size 1024 added (for high resolution monitors) 
- Implemented: Volume buttons added for VLC player



================================================================================
Important changes and bug fixes in the release 831
================================================================================
- Bug fix: Position of active item is not updated when using quick viewer https://freecommander.com/forum/viewtopic.php?f=7&t=11028
- Bug fix: Column width in list view mode is wrong after switching from other view (introduced in 829) 
- Bug fix: If we press backspace in a subfolder, FC goes to parent folder, but sometimes fails to focus on the subfolder (when folders are sorted at the end of the list and extension ist not showed in the name column)
- Bug fix: Selection by hover time and Shift/Ctrl is broken
- Implemented: Tab context menu - new menu item added "Switch locked path to current" 

================================================================================
Important changes and bug fixes in the release 830
================================================================================
- Bug fix: Exception in Folder->Synchronize function (introduced in 829)
- Bug fix: Viewer - mouse wheel zoom function is inverted 
- Bug fix: New status bar item can not be created if program started with default settings parameter https://freecommander.com/forum/viewtopic.php?f=7&t=10993
- Bug fix: Minor Toolbars dialog filter vs icons issue https://freecommander.com/forum/viewtopic.php?f=7&t=10991
- Bug fix: Existent 1st keyboard shortcut is not removed if new one is assigned https://freecommander.com/forum/viewtopic.php?f=7&t=10989


================================================================================
Important changes and bug fixes in the release 829
================================================================================
- Bug fix: Viewer - "fit to window" sometimes is broken
- Bug fix: The position of the scroll bar may be wrong after switching from detailed view to thumbnail view. https://freecommander.com/forum/viewtopic.php?p=33408#p33408
- Bug fix: Temporary and not locked file container TAB not always removed on program closing
- Bug fix: Aborting the drag&drop operation with ESC can lead to an unwanted selection of files/folders (NC selection mode)
- Bug fix: Viewer form (F3) option "Stay on top" does not work correctly
- Implemented: New action - focus newest file/item in the list (by last access timestamp)
- Implemented: New action - focus next/previous item in the list
- Implemented: Attributes/Timestamp dialog - set file timestamp from EXIF
- Implemented: Settings->Tree - new color can be defined "Selection - Inactive"
- Implemented: Settings->Tree - new color can be defined "Background - Inactive"
- Implemented: Viewer form (F3) - set window to foreground if already open and use last saved size/position if multiple window allowed. 


================================================================================
Important changes and bug fixes in the release 828
================================================================================
Changing compiler version to Delphi 10.4 patch 2
I recommend using this version.
With the new compiler version, the unspecific errors in versions 825, 826, 827 have been fixed.


================================================================================
Important changes and bug fixes in the release 827
================================================================================
- Bug fix: Exception on main window activating if only one pane visible and refresh option "Refresh when FreeCommander is activated" is checked
- Bug fix: The window position saving does not work when you are not on the main screen (multi screen) https://freecommander.com/forum/viewtopic.php?f=7&t=10845
- Bug fix: Program start is faulty and program can not be closed - this behavior only appears when the program is started from a shortcut that has "Properties/Shortcut/Run: Maximized" https://freecommander.com/forum/viewtopic.php?f=7&t=10838 
- Bug fix: Overlay symbol in the file operation dialogs is not showed (status symbol for operation result)
- Bug fix: Manipulate files with emojis in their name is not possible https://freecommander.com/forum/viewtopic.php?p=33397#p33397

================================================================================
Important changes and bug fixes in the release 826
================================================================================
- Bug fix: Default action issue with multiple files https://freecommander.com/forum/viewtopic.php?f=7&t=10797
- Bug fix: Function "Same folder Ctrl+E" sometime does not switch the folder properly
- Bug fix: The context menu for Bitlocker "Unlock drive" may not work (introduced in 825)
- Changed: Viewer settings - "Ignore list" changed to "Ignore files - filter list"

================================================================================
Important changes and bug fixes in the release 825
================================================================================
- Bug fix: Window size and position lost when exit from fullscreen https://freecommander.com/forum/viewtopic.php?f=7&t=10777
- Bug fix: Tabs drag&drop - always active tab is dropped if the option "With click on the active tab - change to the last active" is active
- Bug fix: Color picker is to small on 4K monitors
- Bug fix: Column caption maybe wrong (introduced in 824)
- Implemented: Make folder/file list - timestamp format added on Settings tab

================================================================================
Important changes and bug fixes in the release 824
================================================================================
- Bug fix: Wrong data populating (right-shifted columns) after F10 (top/bottom split) https://freecommander.com/forum/viewtopic.php?f=7&t=10764
- Bug fix: Column width not remembered across close/re-open https://freecommander.com/forum/viewtopic.php?f=7&t=10763
- Bug fix: Recycle Bin panel switch issue https://freecommander.com/forum/viewtopic.php?f=7&t=10070


================================================================================
Important changes and bug fixes in the release 823
================================================================================
- Bug fix: The definition of the font size for dialogs (Tools->Settings->View) does not work for Settings dialog 
- Bug fix: "Layouts edit" dialog - after deleting of the last layout the OK button is not active (it is not possible to delete all layouts)
- Bug fix: Problems with the top/bottom orientation fixed (introduced in 820, 821)
- Bug fix: Mounted volume size is not properly shown in progress bar of the drive bar
- Bug fix: Search dialog doesn't find content of folder with semicolon in its name https://freecommander.com/forum/viewtopic.php?f=19&t=10755
- Implemented: Drive panel - width of the volume name button is definable in the setting 
- Implemented: Support for 4K monitors 


================================================================================
Important changes and bug fixes in the release 822
================================================================================
- Bug fix: Favortite tools broken if no parameter used in the favorite tool definition - introduced in the release 821


================================================================================
Important changes and bug fixes in the release 821
================================================================================
- Bug fix: Focus is lost if deleting a file in the thumb view mode  https://freecommander.com/forum/viewtopic.php?p=32735#p32735
- Bug fix: Next/previous tab shortcuts broken when using some context menu options https://freecommander.com/forum/viewtopic.php?p=32727#p32727
- Bug fix: Tab name maybe not updated https://freecommander.com/forum/viewtopic.php?f=7&t=10628
- Bug fix: Tooltip for button in the action toolbar maybe wrong if custom icon is used
- Bug fix: Renaming a file that is open in Quick View can break the display in Quick View. 
- Implemented: Quick Viewer - Copy selected text to the clipboard with the shortcut Ctrl+C.
- Implemented: SFTP (64 bit only) - public key login is possible now 

================================================================================
Important changes and bug fixes in the release 820
================================================================================
- Bug fix: A new tab is created when the favorite is opened using a hotkey (introduced in 819)
- Bug fix: Status info for '..' item was never used
- Bug fix: Keyboard shortcuts maybe lost when using "Desktop Snapshot" https://freecommander.com/forum/viewtopic.php?f=7&t=10595
- Bug fix: Sorting Windows columns of date type does not work properly for many timestamp formats (e.g. in recycle bin)
- Bug fix: Opening program links from the FreeCommander Desktop is broken https://freecommander.com/forum/viewtopic.php?f=6&p=32684#p32684
- Implemented: When started "As Admin": Warning symbol is added to the program icon - new option in Settings->View
- Implemented: New variable added %ActivSelOrDir% - same as %ActivSel% but return current path if nothing is selected in the file list (for example when selecting ".." in file list)
- Implemented: New action added - Close all tabs in both panels; Closes all not locked folder tabs in both panels
- Implemented: New action added - Close all tabs with confirmation; Closes all folder tabs with confirmation dialog
- Implemented: New action added - Select the first file / folder; Select first file (if currently focused item is a folder) or folder (if currently focused item is a file) in the list

================================================================================
Important changes and bug fixes in the release 819
================================================================================

- Bug fix: Keyboard shortcuts do not work in Quick View pane
- Bug fix: Unassigning secondary keyboard does not get saved https://freecommander.com/forum/viewtopic.php?f=7&t=10510
- Bug fix: Secondary keyboard shortcuts not always being saved https://freecommander.com/forum/viewtopic.php?f=7&t=10513
- Bug fix: Exception possible if copy/move files from library 
- Implemented: When started "As Admin": Warning symbol is added to the program icon and the word "(Admin)" appears in the title bar.
- Implemented: Thumbnails for SVG files
- Implemented: SFTP - Symbolic links are properly handled now
- Implemented: "Attributes/Timestamp..." dialog - new attribute "Recall on data access" added (e.g. for not local OneDrive files)
- Implemented: "Settings->File/folder list - Items color" - definig color for attribute "Recall on data access" is possible now

================================================================================
Important changes and bug fixes in the release 818
================================================================================

- Bug fix: Exception in "About" dialog - "Path info" button https://freecommander.com/forum/viewtopic.php?p=32354#p32354
- Bug fix: Keybord shortcuts problem introduced in the release 817 https://freecommander.com/forum/viewtopic.php?p=32350#p32350

================================================================================
Important changes and bug fixes in the release 817
================================================================================

- Bug fix: The defined 2nd shortcuts are not loaded after program restart  https://freecommander.com/forum/viewtopic.php?f=7&p=32203#p32203
- Bug fix: Internal viewer issues after clicking buttons to change view https://freecommander.com/forum/viewtopic.php?f=7&t=10379
- Bug fix: Deleting/copying a file from the desktop can throw an exception
- Bug fix: Opening ftp/sftp path from favorite folders tree broken
- Implemented: Search dialog - the quick view pane is restored when the form is opened
- Implemented: "Define action toolbars" dialog - defined custom symbols are now visible in the list
- Implemented: Thumbnail view for .wmf and .emf files
- Implemented: The visibility of the favorite toolbars is now per Layout definable
- Implemented: New item added to the tab context menu: Close all not locked folder tabs; If clicked with CTRL key - close not locked tabs in both panels
- Implemented: About dialog resizeable; More paths info added
- Implemented: Overwrite dialog for copy/move FreeCommander operation - rename in place is now possible

================================================================================
Important changes and bug fixes in the release 816
================================================================================

- Bug fix: Context menu function "Rename" partially broken
- bug fix: Toolbar separator - details definable: not properly implemented in some cases 

================================================================================
Important changes and bug fixes in the release 815
================================================================================

- Bug fix: Empty favorite toolbar will be shown if all toolbar items are defined as visible only in menu
- Bug fix: Auto refresh partially broken - introduced in 814
- Bug fix: Opened tree pane may slow down some operations 
- Implemented: Toolbar separator - details definable 

================================================================================
Important changes and bug fixes in the release 814
================================================================================

- Bug fix: Multirename form - tooltip always on top  https://freecommander.com/forum/viewtopic.php?f=7&p=31690#p31690
- Bug fix: Color issue in the setting dialog https://freecommander.com/forum/viewtopic.php?f=7&t=10328
- Bug fix: Tree pane - rename with F2 key is partially broken if the option "Allow rename on slow double click" is disabled https://freecommander.com/forum/viewtopic.php?f=7&p=31854#p31854
- Bug fix: Thumbnail of the text file is blurry if dark background is used https://freecommander.com/forum/viewtopic.php?f=7&t=10357
- Bug fix: Text thumbnails with unicode format broken   https://freecommander.com/forum/viewtopic.php?p=31867#p31867
- Bug fix: Deleting the item '..' from context menu may cause freezing  https://freecommander.com/forum/viewtopic.php?f=7&p=31895#p31895
- Bug fix: Plain view is not preserved after FC restart on left panel   https://freecommander.com/forum/viewtopic.php?p=31793#p31793
- Bug fix: Problem with text color of the active tab https://freecommander.com/forum/viewtopic.php?f=6&p=31915#p31915
- Implemented: "Tools -> Define keyboard shortcuts" - it is possible to define the second shortcut for each action
- Implemented: New column is posible "Relative path"
- Implemented: New columns category for pictures added: EXIF
- Implemented: Option available in the freecommander.ini file: TreeSortNodesType=X (0->like so far; 1->sort by path name; 2->sort by display name)
- Implemented: Quick filter accept '*.' for selecting items without dot
- Implemented: Compare folders - new option added "Ignore extension"
- Implemented: Search files/folders - menu item added "Edit -> Copyname without extension"
- Changed: Folder->Open focused->In the other pane (new Tab)/In the same pane (new Tab) - these functions are implemented now for several selected elements

================================================================================
Important changes and bug fixes in the release 813
================================================================================

- Bug fix: Customize favorite toolbars - Changing the order of the buttons has no effect if you add a separator https://freecommander.com/forum/viewtopic.php?f=7&t=10235 
- Bug fix: Rar archives cannot be opened if encryption for file names has been activated. Workaround - first open an archive without encryption.

- Implemented: "Tools -> Dos box" selecting the item with pressed SHIFT key opens the dos box as admin
- Implemented: Address bar toolbar - big icons allowed
- Implemented: New option for viewer - Use mouse wheel for: zooming/switching files 
- Implemented: New option to define in the [Form] section of the freecommander.ini - ThumbOpenAndSelectMode=1 ; 
               When this line is defined, a click on the symbol opens the file / folder and a click on the label selects the file / folder.
- Implemented: Context menu in viewer (images) - new item added "Save - overwrite without confirmation"                
- Changed: Long path support improved
- Changed: Address bar editing - spaces at the end of the path are removed now


================================================================================
Important changes and bug fixes in the release 812
================================================================================

- Bug fix: Attributes/Timestamp dialog - "Save/Load timestamp" function show empty message on "save"
- Bug fix: Define action toolbars - option "Show drop down arrow only" is broken 


================================================================================
Important changes and bug fixes in the release 811
================================================================================

- Bug fix: Search files/folders - The same file can exist several times in the result list if the search location is not correctly defined https://freecommander.com/forum/viewtopic.php?f=7&p=31283#p31283
- Bug fix: Search files/folders - cancellation of the deletion dialog is not handled correctly https://freecommander.com/forum/viewtopic.php?f=7&t=10173
- Bug fix: Search files/folders - file selection in the result list maybe wrong after deleting of some files from the list https://freecommander.com/forum/viewtopic.php?f=7&t=10174

- Implemented: Favorite tool button - new item added for context menu: Run - With "Run as" dialog
- Implemented: Define favorite tool - new placeholder parameter  %ActivItemNoExt% added 
- Implemented: Attributes/Timestamp dialog - "Save/Load timestamp" function added
- Implemented: Multirename - new EXIF property added: Focal length of lens in mm, Lens model name, Orientation of the camera


- Changed: Folder synchronize - comparison with only two options "Name" and "Size" is now possible. Until now comparison with only these two options always provided "?" as a result.
- Changed: The unit "kB" will be no more shown in the column "Size kB"

================================================================================
Important changes and bug fixes in the release 810a
================================================================================
- Bug fix: Exception when saving the settings if only one file pane is visible.


================================================================================
Important changes and bug fixes in the release 810
================================================================================
- Bug fix: Rename in the tree: DEL key want delete the renamed folder
- Bug fix: Option "Show drives as button bar - Use large icons" does not work if the option "Show drive bar per panel" is not active  


================================================================================
Important changes and bug fixes in the release 808
================================================================================

- Bug fix: Plain view is lost if used with quick filter on tab switch  https://freecommander.com/forum/viewtopic.php?f=7&t=10066
- Bug fix: Recycle Bin panel switch issue https://freecommander.com/forum/viewtopic.php?f=7&t=10070
- Bug fix: Recycle Bin refresh issue https://freecommander.com/forum/viewtopic.php?f=7&t=10071
- Bug fix: Quick viewer focus issue https://freecommander.com/forum/viewtopic.php?f=7&t=10073
- Bug fix: Sorting by Bit rate wrong https://freecommander.com/forum/viewtopic.php?f=7&t=10049

================================================================================
Important changes and bug fixes in the release 807
================================================================================

- Bug fix: Layout definition - the option 'Ignore main window size and position' will be unchecked if "Auto save current layout" is used.https://freecommander.com/forum/viewtopic.php?f=7&p=30814#p30814
- Bug fix: Multirename dialog - deleting a file in quick viewer doesn't remove it from the list  
- Bug fix: Search dialog - deleting a file in quick viewer doesn't remove it from the list  
- Bug fix: Some columns in the left panel may be empty on program start  (introduced in 806) https://freecommander.com/forum/viewtopic.php?p=30848#p30848
- Bug fix: Thumbnails view doesn't work with "Auto selectable views" + Plain view https://freecommander.com/forum/viewtopic.php?f=7&t=10000
- Bug fix: Plain view mode - deleteing a file from context menu doesn't remove it from the list  https://freecommander.com/forum/viewtopic.php?f=7&t=9972
- Bug fix: A slow double click on a folder in the tree view allows the renaming of the folder even though the option "Allow rename on slow double click" is not set
- Bug fix: "Keep expanded nodes per Tab": does not work when closing a tab https://freecommander.com/forum/viewtopic.php?f=19&t=10012
- Bug fix: Multi rename dialog, "Search for" field - the help after klick on "?" picture is wrong
- Bug fix: Adding a profile to a search filter doesn't immediately show paths https://freecommander.com/forum/viewtopic.php?f=7&t=10057
- Bug fix: Sorting by "Bit rate" may be wrong https://freecommander.com/forum/viewtopic.php?f=7&t=10049
- Bug fix: Lock view issue https://freecommander.com/forum/viewtopic.php?f=7&t=10041
- Bug fix: Auto selectable views - minor sorting issue https://freecommander.com/forum/viewtopic.php?f=7&t=9983
- BUg fix: Start Folder behavior changed https://freecommander.com/forum/viewtopic.php?f=7&t=10056
- Changed: Define columns dialog - default button changed from Cancel to OK https://freecommander.com/forum/viewtopic.php?f=7&t=10023

================================================================================
Important changes and bug fixes in the release 806
================================================================================
- Bug fix: Multirename in the release 805 broken. The changes are not written to disk. 

================================================================================
Important changes and bug fixes in the release 805
================================================================================

- Bug fix: Selecting files via commandline may not work for network paths https://freecommander.com/forum/viewtopic.php?f=7&p=30622#p30622 
- Bug fix: Deleting a file in the rename dialog from the context menu doesn't remove it from the list https://freecommander.com/forum/viewtopic.php?f=7&p=30631#p30631
- Bug fix: Deleting a file in the search dialog from the context menu doesn't remove it from the list
- Bug fix: Search dialog list - multiple items delete issue https://freecommander.com/forum/viewtopic.php?f=7&t=9909
- Bug fix: Sorting broken on delete https://freecommander.com/forum/viewtopic.php?f=7&t=9926
- Bug fix: Selecting files in "Synchronize" dialog broken https://freecommander.com/forum/viewtopic.php?f=7&t=9905

- Implemented: New action added - "Select all folders"
- Implemented: New action added - "Lock view ; Locks view and disable automatic views"
- Implemented: Search dialog - new option added: "Use big icons"
- Implemented: Multirename dialog - "Options->Select columns" added 
- Implemented: "Tools->Settings->Programs->Default action" - %InternalViewer%  can be used as program for default acion (double click; Enter key) 

================================================================================
Important changes and bug fixes in the release 804 
================================================================================

- Bug fix: Mouse double click may not work properly https://freecommander.com/forum/viewtopic.php?f=7&t=9879

================================================================================
Important changes and bug fixes in the release 803
================================================================================

- Bug fix: Release 802 does not run on Windows XP


================================================================================
Important changes and bug fixes in the release 802
================================================================================

- Bug fix: Scrolling in the details view is slower as in the previous version https://freecommander.com/forum/viewtopic.php?f=19&p=30356#p30356
- Bug fix: Sorting by any column in the search dialog changes the width of the columns https://freecommander.com/forum/viewtopic.php?f=7&p=30358#p30358
- Bug fix: Viewer - zoom with mouse wheel is broken
- Bug fix: Main menu minor issue https://freecommander.com/forum/viewtopic.php?f=7&t=9772
- Bug fix: Minor issue when using multi rename button/hotkey https://freecommander.com/forum/viewtopic.php?f=7&t=9789
- Bug fix: Create new folder tab from file container tab https://freecommander.com/forum/viewtopic.php?p=30437
- Changed: Drag&drop key modifier for move (favortite folders tree) changed from CTRL to SHIFT  https://freecommander.com/forum/viewtopic.php?f=7&t=9795
- Implemented: Option "Ignore diacritical marks" added (quick filter, quick search, filter, multirename)
- Implemented: New command line parameters: -LQF (left quick filter, e.g. -LQF=*.png ), -RQF (right quick filter) 
- Implemented: Multirename dialog - new command "Copy old name without extension" added
- Implemented: Multirename dialog - new option "Use big icons" added
- Implemented: Viewer, VLC Player - "Play loop" option added


================================================================================
Important changes and bug fixes in the release 801
================================================================================

- Bug fix: Filenames that start with periods (e.g.: .config) are not displayed correctly if the "Right align extension ..." option is active. 
- Bug fix: Toolbar buttons for List, Details, Thumbnails stay in down state if "Small icons" or "Large icons" is in menu selected 
- Bug fix: Rename of the volume drive does not work if rename operation with dialog is defined
- Bug fix: Search files - Find duplicate files may provide false result https://freecommander.com/forum/viewtopic.php?f=7&t=9669
- Bug fix: Search for files/folders does not work with ";" in path. Use " to enclose path with ";" https://freecommander.com/forum/viewtopic.php?f=7&t=9699
- Bug fix: Quick viewer close button does not work in multi rename dialog https://freecommander.com/forum/viewtopic.php?f=7&t=9707
- Bug fix: New added column profile is not visible on "Auto selectable views" tab https://freecommander.com/forum/viewtopic.php?f=6&t=9678
- Bug fix: Multi rename dialog - "Activate profiles combo box first" broken with quick view https://freecommander.com/forum/viewtopic.php?f=7&p=30211#p30211
- Bug fix: When using a toolbar button "Show main menu as popup menu" some submenus may not work (e.g. Color schemes, Favorite tools)
- Bug fix: Search files dialog - selecting files in the result list does not count selected (if Shift key is used) https://freecommander.com/forum/viewtopic.php?f=7&t=9717
- Bug fix: Favorite folder tree - drop on node with folder is broken
- Bug fix: Favorite folder dialog - active item color is unreadable https://freecommander.com/forum/viewtopic.php?f=7&t=9624 
- Bug fix: Chosen custom column profile "A" changes to custom profile "B" when a file is moved  https://freecommander.com/forum/viewtopic.php?p=30087#p30087
- Implemented: Protection against "right to left override" characters in the file name. https://krebsonsecurity.com/2011/09/right-to-left-override-aids-email-attacks/
- Implemented: Drop operation (while holding down the SHIFT key) on a Folder button in the Favorite toolbar works as "Move".
- Implemented: New condition for "Automatic views": <newtab>; if defined is always active 
- Implemented: Settings->Programs - define %AcceptOnlyFiles% as Parameter if you want to ignore the program start for folders 
- Implemented: "Alt+Left Click" on folder or archive file opens new tab in other pane
- Changed: Loading of the favorite tools faster when many favorite tools (more than 100) are defined.
- Changed: Item colors are no longer set in the background but directly while loading of the file list.

================================================================================
Important changes and bug fixes in the release 800
================================================================================
- Implemented: Multirename dialog - profiles sorted by name
- Implemented: Quick viewer - close button in the title bar added
- Implemented: Additional options for "Close all folder tabs": Close locked tabs too, Apply for both panels
- Implemented: Tab property dialog - icon definition is possible now 
- Implemented: Settings - new tab option "Use large images"
- Implemented: Setting for menu font size (Settings->View)
- Implemented: Search dialog - new options for searched text: As entered, Any term, All terms 
- Implemented: Search in file container
- Implemented: Quick filter field - with Ctrl+Enter apply quick filter for both panels
- Changed: Active option "Open folder with one click" opens the link to folder too
- Changed: Tab properties dialog - now the field 'Tab name' is always empty unless you define your own tab name.
- Changed: Address bar alow input of the file URI as suggested https://freecommander.com/forum/viewtopic.php?f=18&p=29991#p29991
- Bug fix: From version 793, thumbnail view is slower.
- Bug fix: Synchronize folders - the Quick Viewer does not follow the changes made to the selection in the file list.
- Bug fix: When using "Copy name without extension as text" to copy name of the folder with dot (e.g. aaa.bbbcccddd), only the first part is copied (e.g. aaa)

================================================================================
Important changes and bug fixes in the release 799
================================================================================
- Bug fix: Multirename on smartphone works again
- Changed: Buttons alignmet for left and right toolbar if buttons caption visible 
- Implemented: Search dialog - file editing from archive file is possible now
- Implemented: Background color of the file list in the search dialog changes if searching is active; line "BusyColor=" in freecommander.find.ini 
- Implemented: Multirename dialog - using substring (enclosed with \) for the option "Upper first letter following any of defined characters" is now possible
- Implemented: New command in multirename dialog added - "Copy old name"
- Implemented: New option for "File/folder list" added "Ignore size of link folder (reparse point)"; default value is false; https://freecommander.com/forum/viewtopic.php?f=6&p=29686&sid=ebcde0131eafec4ccc9ada14c4a8b621#p29686


================================================================================
Important changes and bug fixes in the release 798
================================================================================
- Implemented: Option to define in the freecommander.ini for deactivating of the color scheme in viewer - "ViewerUseColorScheme=0"
- Bug fix: Color scheme "MyDefaultColorSchema" does not deactivate color scheme in viewer

================================================================================
Important changes and bug fixes in the release 797
================================================================================
- Bug fix: Tree is not updated correctly after restart; https://freecommander.com/forum/viewtopic.php?f=7&t=9444
- Implemented: Now color scheme is used in Viewer and quick viewer
- Implemented: Two options in "Attributes/Timestamp" dialog added: 'Copy date "modified" to "created" for each file', 'Copy date "created" to "modified" for each file'
- Changed: Computing of folder Size - the size of the symbolic link folder is now always 0; https://freecommander.com/forum/viewtopic.php?f=6&p=29616#p29616 
 
================================================================================
Important changes and bug fixes in the release 796
================================================================================
- Bug fix: If the option "Quick filter bar always visible" is not active then exception appears on click in main menu

================================================================================
Important changes and bug fixes in the release 795
================================================================================
- Bug fix: Opening multiple files causes a crash  https://freecommander.com/forum/viewtopic.php?f=7&t=9317
- Implemented: Position of the settings dialog is saved
- Implemented: Unpacking the archive file from the desktop to another desktop folder is now possible.
- Implemented: New quick filter option added: Clear edit field when quick filter is deactivated
- Implemented: Color scheme menu icons can now be used https://freecommander.com/forum/viewtopic.php?f=20&t=9329  
- Implemented: Thanks to Dreamer for new color schemes: Solarized_Dark_Flat_by_Dreamer, Light_Beige_Flat_by_Dreamer; more color schemes https://freecommander.com/forum/viewtopic.php?f=18&t=8332
 
================================================================================
Important changes and bug fixes in the release 794
================================================================================
- Bug fix: Exception on program start if small icons used in the splitter toolbar

================================================================================
Important changes and bug fixes in the release 793
================================================================================
- Bug fix: Layout switching may cause the exception
- Bug fix: Program start fail on Windows 2003 https://freecommander.com/forum/viewtopic.php?f=19&p=29009#p29009
- Bug fix: Path change through DOS prompt writes the path to the address bar with trailing delimiter.
- Bug fix: After opening the zip file with the internal plugin fc_internal_zip, different unspecific exceptions can occur later.
- Changed: "Attributes/Timestamp..." dialog - "Copy Created -> Modified" changed as suggested https://freecommander.com/forum/viewtopic.php?f=7&t=9199#p29099
- Implemented: New action for main splitter added "Split 0/100 %" and "Split 100/0%" (Compatibility with old version)
- Implemented: JPG as screenshot format added 

================================================================================
Important changes and bug fixes in the release 792
================================================================================
- Bug fix: NC-Mode (sticky selection) with the active option "Select with right mouse button" - File selection under cursor is lost if using right mouse button for context menu 
- Bug fix: If thumbnail view is active before closing the program, then an error message will appear on the next startup
- Bug fix: No auto refresh after deleting file from smartphone
- Bug fix: Exception in internal viewer https://freecommander.com/forum/viewtopic.php?f=7&p=28890#p28890
- Bug fix: If the options "One tree per panel" and "Keep expanded nodes per tab" are active:  by switching between left and right pane - the expanded folders in the inactive tree are closed
- Implemented: New action "Set Quick Filter from clipboard"
- Implemented: New menu item "Edit -> Filter files with same ext." (Set quick filter to the extension of the focused item in the current panel )
- Implemented: Confirm overwrite dialog - file version info is showed now
- Implemented: Exif info in viewer - Context menu "Copy to clipboard" (selected lines)
- Implemented: Folder view in viewer - Context menu "Copy to clipboard" (selected text)
- Implemented: New option "Always open in new tab" for shell menu settings added 
- Implemented: "Redirect Win+E to FreeCommander" function opens the program in the foreground  
- Implemented: Create checksum - space characters are ignored in the field "Compare with the pattern sum"
- Implemented: "Make folder/file list..." now possible for archive files and SFTP folders
- Implemented: Thumbnails for epub files
- Changed: Multirename dialog - auto-completion disabled for date field
- Changed: Dos-Prompt field - auto-completion disabled 


================================================================================
Important changes and bug fixes in the release 788
================================================================================
- Bug fix: File/folder selection is lost when cancel delete operation (NC-Selection and "Use Freecommander" for delete)
- Bug fix: Screenshot in systems with multiple monitors and different resolutions is faulty.   
- Implemented: Viewer - new option for images added "Show frames" (in the context menu of the picture)
- Implemented: Quick filter option now available in the settings dialog "Also use for folder names"

================================================================================
Important changes and bug fixes in the release 787
================================================================================
- Bug fix: Multi rename option "Activate profiles combo box first" is broken https://freecommander.com/forum/viewtopic.php?f=7&t=9025
- Bug fix: Plain View does not remember selection after switching to another tab 
- Bug fix: Quick filter does not see some country-specific uppercase letters https://freecommander.com/forum/viewtopic.php?f=19&t=9022
- Bug fix: Drag&drop operation fails if it was started from plain view and some country-specific letters exist in the file name
- Bug fix: Color schemes saving is broken https://freecommander.com/forum/viewtopic.php?f=7&t=9054
- Bug fix: Folder synchronize (with compare by content) may stops after comparing the very last file 
- Implemented: Possibility to define text label in the favorite toolbar 
- Implemented: Search dialog - new option added "Open first profile on start"

================================================================================
Important changes and bug fixes in the release 786
================================================================================
- Bug fix: Copy&paste in the tree does not refresh the tree
- Bug fix: An internal error in the thumbnail display may slow down the display, especially from the network.

================================================================================
Important changes and bug fixes in the release 785
================================================================================
- Bug fix: Option "Keep expanded nodes per Tab" broken
- Bug fix: RAR files created on Android can not be extracted
- Bug fix: Column profiles - added Windows column can get wrong title
- Bug fix: Message "The system cannot find the path specified" can be showed twice https://freecommander.com/forum/viewtopic.php?f=7&t=9004
- Bug fix: Drive icons may be not correctly displayed in toolbars https://freecommander.com/forum/viewtopic.php?f=7&p=28430#p28430
- Changed: Tab caption - UNC-paths are displayed with "1:" instead of the server name https://freecommander.com/forum/viewtopic.php?f=7&t=7244
- Changed: Freecommander.ini option "ThumbsNoClipCaption" can be defined now in the settings dialog: "Draw caption without clipping" 
- Implemented: Search duplicates in archives
- Implemented: Multirename - new options for case processing "Upper first letter following any of defined characters:", "Keep current case"

================================================================================
Important changes and bug fixes in the release 784
================================================================================
- Bug fix: Rename with slow double click does not work if the option "Hot track only" is active
- Bug fix: Sorting on shell columns does not work properly
- Bug fix: Searching for the hex string does not work properly (viewer and search dialog)
- Bug fix: Copy to SFtp folder - "Overwrite older", "Overwrite smaller", "Auto rename target item" options does not work
- Implemented: Currently we can switch to the desired drive with Shift+drive-letter. If no root folder is active after switching, then using again Shift+drive-letter will switch to the root folder.
- Implemented: Quick starter settings - selection color added
- Implemented: Main menu items added "Edit -> Save selection" and "Edit -> Restore selection"
- Implemented: When navigating in the folder history (Alt + Left, Alt + Right), non-existent folders are ignored.
- Implemented: Searching duplicates 

================================================================================
Important changes and bug fixes in the release 783
================================================================================
- Bug fix: Exception on program start if thumbnail view is active in one pane
- Bug fix: Exception on drives reload if drive button was added to toolbar

================================================================================
Important changes and bug fixes in the release 782
================================================================================
- Bug fix: Quick starter - In order to search with quick filter first focus must be set in the field. That was not necessary in the old version.
- Bug fix: Automatic views - few minor bugs fixed https://freecommander.com/forum/viewtopic.php?f=7&t=8838
- Bug fix: Different behavior of selected items when deleting with the Windows method https://freecommander.com/forum/viewtopic.php?f=19&p=28073#p28073

================================================================================
Important changes and bug fixes in the release 781
================================================================================
- Bug fix: Compare folders - takes a long time if there are several thousand files in folders.
- Bug fix: Tree view is not updated when deleting a folder in the file list via context menu.
- Implemented: Quick starter settings - item colors by file type
- Implemented: Quick starter -  in "Repository -> Reorganize" function you will be asked, if non existing elements should be removed.
- Implemented: Switch view mode automatically on folder change - "Settings -> Column profiles/Automatic views"
- Implemented: If the favorite tree option "Full row select" is active, the double click (or click) will also work if the mouse is not over the name

================================================================================
Important changes and bug fixes in the release 777
================================================================================
- Bug fix: Internal viewer - the option "Enable adjust orientation" does not work correctly if "Show Exif" is switched on/off
- Bug fix: Main menu disappear if defined as "Show menu as toolbar" https://freecommander.com/forum/viewtopic.php?f=18&t=8715
- Bug fix: Queue button is always default for pack operation
- Implemented: Viewer settings - ignore list added
- Implemented: Action for reverse quick filter added
- Implemented: Layout option "Ignore main window size and position" now is defined per layout and not global https://freecommander.com/forum/viewtopic.php?f=18&t=8369
- Implemented: "Settings - Shell menu" new option added "Apply to: Current user, All users"
- Implemented: Quick starter - quick filter field use the settings color now
- Implemented: New action added - Close duplicate Tabs
- Implemented: "Define favorite toolbars" dialog - "Duplicate" function added; Drag&drop for moving to another toolbar 

================================================================================
Important changes and bug fixes in the release 776
================================================================================
- Bug fix: Quick filter - exclude multiple extensions does not work https://freecommander.com/forum/viewtopic.php?f=7&t=8654
- Bug fix: Building of the zip file name broken https://freecommander.com/forum/viewtopic.php?f=7&t=8662
- Implemented: Quick filter field - select all with Ctrl+A is now possible https://freecommander.com/forum/viewtopic.php?f=7&t=8612
- Implemented: New action added "Copy name without extension as text"
- Implemented: Delete operation (Windows) non blocking now
- Changed: Quick starter repository files now saved in UTF8 format


================================================================================
Important changes and bug fixes in the release 775
================================================================================
- Bug fix: Zip naming issue http://forum.freecommander.com/viewtopic.php?f=7&t=8596
- Bug fix: Search function - size filter is ignored sometimes https://freecommander.com/forum/viewtopic.php?f=7&t=8650
- Bug fix: View of the PDF files does not work for some installed PDF programs
- Implemented: Quick filter popup menu - new item added: Clear edit field
- Implemented: Quick filter - click on quick filter button with pressed CTRL key: edit field will be cleared 
- Implemented: Quick starter - context menu for the line added
- Implemented: Version checker form - frequency of checking can be set here too
- Implemented: Basic functions for SFTP client (use first with test data!)

================================================================================
Important changes and bug fixes in the release 774
================================================================================
-Bug fix: Rename on smartphons broken for current Windows 10
-Bug fix: Some tab icons are not displayed correctly http://forum.freecommander.com/viewtopic.php?f=7&t=8545
-Bug fix: Refresh of 'Network' goes to 'Desktop' http://forum.freecommander.com/viewtopic.php?f=7&t=8530
-Bug fix: When using Linked browsing and quick view for both panels, item in the file list (inactive panel) is updated, but quick view for inactive panel is not updated. http://forum.freecommander.com/viewtopic.php?f=6&t=8583
-Implemented: Column profile definition - new option added: 'All subfolder levels for columns:  Files, Items, Folders'
-Implemented: Internal viewer - basic functions for image editing added
-Implemented: Favorite tools - if folder is defined as favorite tool, than parameters %RightDir%, %LeftDir%, %InactivDir% can be used if you want to open the folder not in the active pane

================================================================================
Important changes and bug fixes in the release 773
================================================================================
- Bug fix: Drive buttons in toolbar have no icons on program start
- Bug fix: If the Explorer option "Hide extensions for known types" is active, then files can not be deleted from the desktop (FC Method).
- Bug fix: Command line does not work if current tab is ::Computer http://forum.freecommander.com/viewtopic.php?f=7&t=8518#p27282
- Bug fix: Unpacking multiple archive files at once - if the destination path is empty, the folder of the first file will always be used as destination. http://forum.freecommander.com/viewtopic.php?f=6&t=8515
- Bug fix: Viewer - searching in hex mode does not work for properly
- Bug fix: "Make folder/file list.."  dialog - selected predefined filter is ignored
- Bug fix: Auto save settings broken
- Implemented: NOT operator for quick filter: \~
- Implemented: Multirename - pattern for parent folder (level 1 to 9) added
- Implemented: "Customize action toolbars" dialog - quick filter added

================================================================================
Important changes and bug fixes in the release 772
================================================================================
- Bug fix: Drag&Drop in thumbnail view broken in 771
- Bug fix: Search dialog - "Attribute/Timestamp..." dialog can not be opened
- Bug fix: Full path is showed for  "Network shortcut" http://forum.freecommander.com/viewtopic.php?f=19&t=8432 
- Bug fix: Define toolbar items dialog - dialog is opened for the false item if the list of toolbar items was scrolled. http://forum.freecommander.com/viewtopic.php?f=7&t=8496
- Changed: The drop-down menu for the Desktop button in the toolbar has been changed. Now no submenus are loaded. This avoids delays in starting of the program.
- Implemented: Option for search dialog to define in the section [fcSearchForm] of the file FreeCommander.find.ini:   OpenLocationChangeShortcut=1 if the shortcut should be changed from Ctrl+Space to Alt+Space
- Implemented: New action added "Collapse all nodes, except selected node, in the tree view"
- Implemented: Admin plugin for locking some functions of the program


================================================================================
Important changes and bug fixes in the release 771
================================================================================
- Bug fix: "Check for updates" drop list items are duplicated after changing of the language http://www.forum.freecommander.com/viewtopic.php?f=7&t=8428
- Bug fix: Possible exception if editing viewer settings from general settings dialog
- Changed: "Color schema" changed to "Color scheme"
- Changed: Hotkeys (Ctrl+Up, Ctrl+Down) for changing search result splitter changed to Alt+Down, Alt+Up http://www.forum.freecommander.com/viewtopic.php?f=7&t=8446
- Changed: Handling of the favorites LNK files changed. Now target path will be handled.  
-Implemented: New option in copy dialog "Use last overwrite options"
-Implemented: New drag&drop option "Start dragging on label or icon only"

================================================================================
Important changes and bug fixes in the release 768
================================================================================

- Bug fix: Quick filter option (only in freecommander.ini) "QuickFilterFolderNamesToo" broken if set to "0"
- Bug fix: The size of the tree pane may be wrong after program restart http://www.forum.freecommander.com/viewtopic.php?f=7&t=8389
- Bug fix: Start minimize option broken
- Bug fix: Color for hot (focused and selected) item may be wrong http://www.forum.freecommander.com/viewtopic.php?f=7&t=8338

================================================================================
Important changes and bug fixes in the release 767
================================================================================

- Bug fix: "Folder - > Synchronize..." same files can be marked as unresolved
- Bug fix: Check for updates on Windows XP fail
- Bug fix: Filter in the plain view can fail 

================================================================================
Important changes and bug fixes in the release 766
================================================================================
- Bug fix: Possible exception in the search dialog when quick view is switched off.
- Implemented: Option to define in the [Form] section of the freecommander.ini: LayoutsIgnoreMainWindowSize; 1 - in layout saved window size is ignored; 0 - in layout saved window size is used 
- Implemented: "Check for update" option defined under Tools->Settings->General

================================================================================
Important changes and bug fixes in the release 765
================================================================================
- Bug fix: Favorite tool shortcut for changing location fail in some cases http://forum.freecommander.com/viewtopic.php?f=19&t=8318
- Bug fix: Switching from layout with one pane to layout with two panes fail http://forum.freecommander.com/viewtopic.php?f=7&t=8348
- Bug fix: Copy file from the disk folder to the smartphone card with Shift+F5 fail - copied file ends up in desktop folder. 

================================================================================
Important changes and bug fixes in the release 764
================================================================================
- Bug fix: Exception on program start if "Show drives as popup button" option is used
- Bug fix: Tree may be not visible http://www.forum.freecommander.com/viewtopic.php?f=7&t=8333

================================================================================
Important changes and bug fixes in the release 763
================================================================================
- Bug fix: Errors may appears if open multiple files simultaneously (with Enter key) http://www.forum.freecommander.com/viewtopic.php?f=7&t=7863#p26390
- Implemented: Font color for quick filter
- Implemented: "Only border" option added for "Focused item inactive list"
- Implemented: Restore last used color schema
- Implemented: Color schemas saved in settings backup 
- Implemented: "Exposure time" added to EXIF info (multirename and status row)
- Implemented: New options for the tree added: "Full rows select", "Theme off"
- Changed: Menu "Tools -> View style" moved to "View -> View style" 

================================================================================
Important changes and bug fixes in the release 762
================================================================================

- Bug fix: Error message "No colors..." on program start if starting with saved layout http://www.forum.freecommander.com/viewtopic.php?f=7&t=8223
- Bug fix: Color schema adds color by file type http://www.forum.freecommander.com/viewtopic.php?f=7&t=8241
- Implemented: Custom style dialog - definition for menu added
- Implemented: "Settings -> Folder Tabs" more colors for tabs added

================================================================================
Important changes and bug fixes in the release 761
================================================================================

- Bug fix: Renaming operation may fail for some languages http://www.forum.freecommander.com/viewtopic.php?f=7&t=8204
- Bug fix: Exception on program start if last used view was "Thumbnails"
- Implemented: Color schema can be saved and restored View->Color schemas
- Implemented: Color schema can be saved with layout too
- Implemented: Loading drive icons in background - program start may be faster

================================================================================
Important changes and bug fixes in the release 760 compared to 740
================================================================================

- Bug fix: Some russian chars does not work in quick search http://www.forum.freecommander.com/viewtopic.php?f=7&t=7750
- Bug fix: '\&' operator in quick filter does not work 
- Bug fix: Using ENTER while editing the options in "Settings -> Programs" closes the entire dialog http://www.forum.freecommander.com/viewtopic.php?f=19&t=7740
- Bug fix: View->Swap function may cause exception
- Bug fix: Favorite tool icon is not visible if favorite tool is integrated in splitter toolbar
- Bug fix: "Windows preview" icon is not created in the default viewer toolbar
- Bug fix: Using ENTER while editing the options in "Column Profiles" or "Status Bar" closes the entire dialog  http://www.forum.freecommander.com/viewtopic.php?p=25041#p25041
- Bug fix: Selection problem if extension not showed in the Name column http://www.forum.freecommander.com/viewtopic.php?f=19&t=7231
- Bug fix: Wrong file highlighting when NC-style selection is enabled http://www.forum.freecommander.com/viewtopic.php?f=19&t=7810
- Bug fix: Selection duplicated in other tabs http://www.forum.freecommander.com/viewtopic.php?f=19&t=7809
- Bug fix: Favorites command "Open all in tabs" may fail http://www.forum.freecommander.com/viewtopic.php?f=19&t=7797
- Bug fix: Plain view - Opening multiple selected files does not always work http://www.forum.freecommander.com/viewtopic.php?f=7&t=5887 
- Bug fix: Program may crash if base folder tree is set to drive and a DVD drive without disk will be selected
- Bug fix: Column profiles "File container <cart>" issue http://www.forum.freecommander.com/viewtopic.php?f=7&t=7848
- Bug fix: Open default program broken http://www.forum.freecommander.com/viewtopic.php?f=7&t=7859
- Bug fix: Copy files from nested archive broken 
- Bug fix: Loading the toolbar icons at the program start can lead to the endless loop.
- Bug fix: Searching for Zero Byte Files does not work http://www.forum.freecommander.com/viewtopic.php?f=18&t=7869
- Bug fix: After deleting the last element in the list, the cursor jumps to the first element http://www.forum.freecommander.com/viewtopic.php?f=7&t=7851
- Bug fix: Current folder is not used if perform default action http://www.forum.freecommander.com/viewtopic.php?f=7&t=7882
- Bug fix: Prefered sort direction (column definition in the detail view) is not used if sorting started with toolbar button or shortcut http://www.forum.freecommander.com/viewtopic.php?f=7&t=7899
- Bug fix: Quick viewer - wrong panel focused http://www.forum.freecommander.com/viewtopic.php?f=7&t=7894
- Bug fix: Quick viewer zoom state lost http://www.forum.freecommander.com/viewtopic.php?f=7&t=7893
- Bug fix: Quick viewer does not show file if already open on program start 
- Bug fix: Font color for quick starter is not used
- Bug fix: Maximized start is not possible if the option "Handle closing as minimization" is active
- Bug fix: File container favorite does not open at container contents http://www.forum.freecommander.com/viewtopic.php?f=19&t=7979  
- Bug fix: Locked path of MTP device is lost when device is not connected http://www.forum.freecommander.com/viewtopic.php?f=19&t=7968
- Bug fix: Second favorites sets' items cannot be opened from pulldown http://www.forum.freecommander.com/viewtopic.php?f=7&t=7986
- Bug fix: It is possible to define duplicate keyboard shortcut http://www.forum.freecommander.com/viewtopic.php?f=7&t=7966
- Bug fix: Tree option "Show Windows archive files" broken 
- Bug fix: Search history is not always saved http://www.forum.freecommander.com/viewtopic.php?f=19&t=7995
- Bug fix: Exception in Folder Synchronize dialog if 'Empty folders' option is active
- Bug fix: FTP is not case sensitive
- Bug fix: "Use Vista+ delete method" option broken on Windows 10 http://www.forum.freecommander.com/viewtopic.php?f=7&t=8101
- Bug fix: Using of the large icons in the favorite toolbar broken http://www.forum.freecommander.com/viewtopic.php?f=6&t=8116
- Bug fix: "Go To Folder" history always empty http://www.forum.freecommander.com/viewtopic.php?f=7&t=8114
- Bug fix: The width of the tree pane is not correctly restored on start
- Bug fix: Folder size can be not correctly if contains files > 4 GB
- Bug fix: Multirename not working when making consecutive rename operations http://www.forum.freecommander.com/viewtopic.php?f=7&t=8019
- Bug fix: Synchronize folder dialog - filter fields does not accept space character

- Changed: Multirename - negative value for counter "Start at" allowed again   
- Changed: Select item options: "By click on extension..." and "By click on item icon" now separated for Windows-mode and NC-mode
- Changed: Color by attributes - now any set of attributes is possible
- Changed: Copy/Paste operation is now performed asynchronously (set CopyPasteInThread=0 for old behavior)
- Changed: Font color is not changed now if "Only border" for focused item is active in NC-Mode http://www.forum.freecommander.com/viewtopic.php?f=6&t=7853
- Changed: "Define filter" dialog - option for "Older than" added 
- Changed: Temporary filter in "Set filter" dialog extended by condition for date modified 
- Changed: Due to a bug in Windows 10 1607 the operations on portable devices was broken. 
	 The internal treatment of these devices has been revised. Now the basic functions works with the portable devices (from Windows 7). 
- Changed: Better performace for copy operation in network (FreeCommander method)

- Implemented: Report missing files for "Verify MD5-checksums"  http://www.forum.freecommander.com/viewtopic.php?f=19&t=7755   
- Implemented: New system tree option for excluding some nodes from the tree 
- Implemented: Status bar - File Container filter http://www.forum.freecommander.com/viewtopic.php?f=20&t=7847
- Implemented: Split file command
- Implemented: Combine files command
- Implemented: Action toolbar for the left and right border of the main window
- Implemented: New thumbnail option "No thumbnails for the files:"
- Implemented: Option "Color by attributes" extended to "Color by attributes and timestamp"
- Implemented: New property "Font color" added for favorite folder 
- Implemented: In viewer: Multiframe images (tiff, ico, avi), EXIF info can be showed, Saving images in many formats (popup menu), Print preview for images (popup menu)
- Implemented: Search dialog - time interval filter accept multiplier now; e.g. |day*4, |hour*2, |month*3, -|week*5, -|year*2
- Implemented: The width of the input dialog (e.g. for new folder F7) is changeable now
- Implemented: VLC media player (videolan.org) integrated in viewer and quick viewer 
- Implemented: Checksum dialog - new sum methods added (SHA1, SHA2)
- Implemented: Completion of renaming operation with TAB key opens the next item ready for renaming 


================================================================================
Important changes and bug fixes in the release 740 compared to 715
================================================================================
    - Bug fix: Search profile doesn't retain Timestamp "Not older option" forum.freecommander.com/viewtopic.php?f=7&t=7108
    - Bug fix: Main window is always hidden if starting FreeCommander with the options "Minimize to system tray" and "Start minimized"
    - Bug fix: '[' and ']' does not works in quick filter
    - Bug fix: Invert selection - the first element of the list is not selected if no parent folder '..' is visible in the file list
    - Bug fix: The column titles may be not translated if the option "Start minimized" is active
    - Bug fix: Locked tab "D:\My Folder" with "Navigation to subfolders" - navigation is possible to "D:\My Folder is locked"
    - Bug fix: "Save container to file..." broken forum.freecommander.com/viewtopic.php?f=7&t=7160
    - Bug fix: On some PCs all timestamps shows as 1899.12.30 00:00 forum.freecommander.com/viewtopic.php?f=7&t=7197#p23091
    - Bug fix: Active layout is not checked in menu if more as 10 layouts defined
    - Bug fix: Settings->General "Start minimized" option broken
    - Bug fix: Selection problem fixed forum.freecommander.com/viewtopic.php?f=7&t=7073
    - Bug fix: Checked state is initial not visible on splitter button forum.freecommander.com/viewtopic.php?f=19&t=7249
    - Bug fix: FTP connections are not listed if connection name has special chacter (e.g. German ö,ä,ü,...)
    - Bug fix: When changing folders in network shares, when you go back one level up, the cursor jumps to the top forum.freecommander.com/viewtopic.php?f=19&t=7270
    - Bug fix: Drop folder to Deskop button - the content of the folder is dropped but not the folder self
    - Bug fix: Customized button caption (toolbar buttons) is ignored for layouts and favorites forum.freecommander.com/viewtopic.php?f=6&t=7282
    - Bug fix: Splitter position is not restored after hiding/opening inactive panel (F10) forum.freecommander.com/viewtopic.php?f=19&t=7292
    - Bug fix: The state of "go to the next history item" toolbar botton is not changed forum.freecommander.com/viewtopic.php?f=19&t=7291
    - Bug fix: Item list Icons do not follow Item list Names upon change of sort type forum.freecommander.com/viewtopic.php?f=19&t=7317
    - Bug fix: Actions "Set active panel to X%" broken
    - Bug fix: Plain views icons do not toggle when in address bar forum.freecommander.com/viewtopic.php?f=7&t=7345
    - Bug fix: Selection in NC-Mode broken forum.freecommander.com/viewtopic.php?f=6&t=7390
    - Bug fix: Folder size consolidation toggle ("KB") unpredictable state forum.freecommander.com/viewtopic.php?f=19&t=7080
    - Bug fix: Del key issue with rename in "Favorites - edit..." forum.freecommander.com/viewtopic.php?f=7&t=7408
    - Bug fix: Search result: Open location shortcut changed to original value - Space (Shift+Space supported too) forum.freecommander.com/viewtopic.php?f=6&t=7400
    - Bug fix: Linked browsing broken on the way "up" forum.freecommander.com/viewtopic.php?f=7&t=7410
    - Bug fix: The main window opens on the primary monitor although closed on the second monitor - only if maximized
    - Bug fix: Folder synchronize problems forum.freecommander.com/viewtopic.php?f=7&t=7445
    - Bug fix: Unwanted selection in NC-Mode forum.freecommander.com/viewtopic.php?f=7&t=7362
    - Bug fix: "Auto add wildcards" option in quick filter is broken forum.freecommander.com/viewtopic.php?f=7&t=7360
    - Bug fix: New folder should allow path with more than one directory forum.freecommander.com/viewtopic.php?f=20&t=6969
    - Bug fix: "Quick viewer size by file type" option broken for jpg files
    - Bug fix: Thumbnails may be false if using refresh function or if switching tabs with thumbnails view
    - Bug fix: Multirename dialog - not correctly displayed for bigger fonts (150%) if profiles defined
    - Bug fix: Compare folders is broken if UNC path is used
    - Bug fix: Toolbar position is not saved if using "Tools->Save settings"
    - Bug fix: Wrong tab order in "Define favorite toolbars" dialog forum.freecommander.com/viewtopic.php?f=7&t=7499
    - Bug fix: Delete button not working in Laouts edit dialog forum.freecommander.com/viewtopic.php?f=7&t=7500
    - Bug fix: Maximized/normal state of the main window not correctly restored in layouts forum.freecommander.com/viewtopic.php?f=7&t=7496
    - Bug fix: Popup menu is not showing by drop on address bar although the setting for showing popup menu is active forum.freecommander.com/viewtopic.php?f=19&t=7507
    - Bug fix: Show/hide main menu in the status bar context menu doesn't work always forum.freecommander.com/viewtopic.php?f=7&t=7518
    - Bug fix: Exception on closing of the layout dialog forum.freecommander.com/viewtopic.php?f=7&t=7497
    - Bug fix: Incorrect file name suggested in Pack files dialog forum.freecommander.com/viewtopic.php?f=7&t=7204
    - Bug fix: Favorites set dialog - rename does not work
    - Bug fix: FTP - set timestamp for the uploaded file does not work
    - Bug fix: File container - many problems solved forum.freecommander.com/viewtopic.php?f=6&t=7549
    - Bug fix: Tree position is not correct restored when "Show menu as toolbar" active is (only if main window is maximized)
    - Bug fix: Tree is not refreshed if context menu delete command is used
    - Bug fix: View option for favorite folder does not work always http://www.forum.freecommander.com/viewtopic.php?p=24465#p24465 
    - Bug fix: Toggle betwwen current and thumbnail view (Ctrl+I) does not work properly if folder was changed http://www.forum.freecommander.com/viewtopic.php?f=7&t=7609
    - Bug fix: Exception if you try to open folder in the file container but the folder does not exist http://www.forum.freecommander.com/viewtopic.php?p=24456#p24456
    - Bug fix: Quick viewer resize problem if "top" is used for "Align in panel"  http://www.forum.freecommander.com/viewtopic.php?f=7&t=7641
    - Bug fix: Exception on some PCs, e.g. on usb drive add/remove (introduced in 731)
    - Bug fix: Deleting the folder in the tree causes error messages http://www.forum.freecommander.com/viewtopic.php?p=24730#p24730 
    - Bug fix: File names may be not fully visible on high DPI screen http://www.forum.freecommander.com/viewtopic.php?f=7&t=7622
    - Bug fix: Command line option "-Layout=" does not work if one instance option is active
    - Bug fix: Color items by predefined filter does not work properly http://www.forum.freecommander.com/viewtopic.php?f=19&t=7727

    - Implemented: It is possible now to add: Layouts, Favorite tools, Favorites and Drives to action toolbars. Only items with assigned shortcut works in action toolbar.
    - Implemented: New method Copy/Move operation performed by FC added (Vista+ only)
    - Implemeneted: New tree option "Keep expanded nodes if tree per Tab"
    - Implemented: Sorting by Windows columns improved ("Data type" added to the column definition )
    - Implemented: Elevation prompt (admin rights) will be showed for unpack operation if needed
    - Implemented: New Option in search dialog - Run in external process
    - Implemented: Middle button click on favorite item in toolbar opens favorite target folder in new tab forum.freecommander.com/viewtopic.php?f=20&t=7174
    - Implemented: Delete operation improved; option "Use Vista+ delete method" added
    - Implemented: Loading of network shares improved forum.freecommander.com/viewtopic.php?f=6&t=6288
    - Implemented: New command line option added -StartMinimized
    - Implemented: Address bar edit field - accept button added
    - Implemented: FTP - unicode support added forum.freecommander.com/viewtopic.php?f=7&t=7041
    - Implemented: New option in the search form - Use left/right for "Open location"
    - Implemented: Attributes/Timestamp dialog - new options for "Set timestamp as in target folder" added: "Created from Modified" and "Modified from Created"
    - Implemented: Favorite items edit dialog - shortcuts for rename, delete, up, down added
    - Implemented: Icons for favorite tools now loaded in background (important for not existend or slow network paths )
    - Implemented: Click on button with the folder in the favorite tools toolbar - added Ctrl+Click (open folder in new tab), Alt+Click (open folder in the opposite pane), Ctrl+Alt+Click (open folder in new tab in the opposite pane)
    - Implemented: Click on folder in the favorite folders tree - added Ctrl+Click (open folder in new tab), Alt+Click (open folder in the opposite pane), Ctrl+Alt+Click (open folder in new tab in the opposite pane)
    - Implemented: Click on folder in system folder popup menu - added Ctrl+Click (open folder in new tab) forum.freecommander.com/viewtopic.php?f=6&t=7283
    - Implemented: New options for "Select with mouse pointer" added - Action by click on free space in label, action by click on item icon (these options was till now available only in freecommander.ini )
    - Implemented: Left click in the free area of the address bar start the editing if the option "Show history popup menu on free area click" is not set
    - Implemented: Additional option for auto size of the 'Name' column - Fill remaining space
    - Implemented: Operations queue for operations ("Use FreeCommander" operations)
    - Implemented: New action added "Paste address from clipboard and reload" Shift+Alt+G
    - Implemented: Main menu item added Edit->Address bar
    - Implemented: Mouse "Snap to" implemented
    - Implemented: Searching in the office files (docx, xlsx, odt)
    - Implemented: Option to set in the freecommander.ini: CopyFullPath_AddLastDelimiter=0 - set the value to 1 if you want to add trailing backslash if copy folder paths to clipboard
    - Implemented: New action added "Toggle toolbars visibility"
    - Implemented: Favorite folder sets
    - Implemented: New option added "Always perform copy operation for left button drag&drop"
    - Implemented: Last position of the layout dialog will be saved
    - Implemented: Doubleclick on the line in the layout dialog perform "Apply" command
    - Implemented: 'Settings->Shell Menu' - options for adding "Open with Freecommander" item to shell context menu
    - Implemented: New option "Show basket icon" for splitter toolbar added 
    - Implemented: New command line option added (set active panel to left/top or right/bottom) "-Panel=L" or "-Panel=R"
    - Implemented: New thumbnail size added (512)
    

    - Changed: Last selected layout is marked as checked (till now - only if "Auto save current layot" was active)
    - Changed: Deley befor opening of the rename dialog removed forum.freecommander.com/viewtopic.php?f=6&t=7287
    - Changed: Multirename - mouse scrolling in the fields is allowed now only if the mouse cursor is in the filed forum.freecommander.com/viewtopic.php?f=19&t=7301
    - Changed: Settings dialog - OK, Cancel, Apply buttons moved to the right site of the dialog forum.freecommander.com/viewtopic.php?f=20&t=7421
    - Changed: Quick search support special characters forum.freecommander.com/viewtopic.php?f=7&t=7414
    - Changed: Splitter toolbar should be visible if hot spot buttons are used forum.freecommander.com/viewtopic.php?f=20&t=7516
    - Changed: Mouse wheel scroll for details view follows now Windows settings
    - Changed: Click on basket icon in splitter loads the Bin Tray in the active panel
    - Changed: Subfolder filter in search dialog simplified
    - Changed: Modifications for high resolution screens
    - Changed: Suppress message when global shortcut can not be registered (only if second or further program instance is started)   
    - Changed: Redirect Win+E to FreeCommander now permanent and not only per sesion

Full history you can find here http://www.forum.freecommander.com/viewtopic.php?f=6&t=775&start=165


            