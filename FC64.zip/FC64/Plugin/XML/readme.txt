xmltab 0.9.9

Lister plugin to view XML files.

Features
* Mixed tree and grid view
* Column filters
* Sort data by column click
* Beautifier and highlighting
* Supports ANSI, UTF8 and UTF16

Homepage: https://github.com/little-brother/xmltab-wlx
Wiki: https://github.com/little-brother/xmltab-wlx/wiki
Contact: lb.im@ya.ru