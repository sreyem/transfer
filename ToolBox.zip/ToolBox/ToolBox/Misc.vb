﻿
Imports System.Windows.Forms
Imports System.ComponentModel

Public Module Misc


#Region "Enums and constants"

    Public Enum eClick
        Dblclick
        OK
    End Enum

#End Region


#Region "Strings"

    ''' <summary>
    ''' change the first char 2 upper and the others 2 lower case
    ''' </summary>
    ''' <param name="String2Change">
    ''' The string you want to change to first char 2 upper and the others 2 lower case
    ''' </param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function changeFirst2UpperRest2LowerCase(String2Change As String) As String

        Dim TempString As String = String.Empty

        If String2Change = "" Then Return ""
        If String2Change.Length = 1 Then Return String2Change.ToUpper

        Try
            With String2Change

                TempString = .Substring(0, 1).ToUpper &
                             .Substring(1, .Length - 1).ToLower

            End With
        Catch ex As Exception
            Return ex.Message
        End Try

        Return TempString

    End Function


#End Region



    ''' <summary>
    ''' Send around an Email
    ''' </summary>
    ''' <param name="EmailAddress">
    ''' Somebody@abc.com
    ''' </param>
    ''' <param name="Subject">
    ''' Short Header
    ''' </param>
    ''' <param name="Body">
    ''' Msg you want to send
    ''' </param>
    ''' <returns>
    ''' True, if everything went well, otherwise false
    ''' </returns>
    ''' <remarks>
    ''' Last Edit: 2015:Nov:24
    ''' by       : Horatio
    ''' </remarks>
    Public Function OpenEmail(ByVal EmailAddress As String,
                              ByVal Subject As String,
                              ByVal Body As String) As String

        Dim ParameterString As String

        Try

            ParameterString = EmailAddress

            'add a mailto: to the email address if necessary
            If LCase(Strings.Left(ParameterString, 7)) <> "mailto:" Then
                ParameterString = "mailto:" & ParameterString
            End If

            'subject
            ParameterString = ParameterString &
                      "?subject=" & Subject

            'body
            ParameterString = ParameterString &
                      CStr(IIf(Subject = "", "?", "&")) &
                      "body=" & Body

            'start relevant email prog.
            System.Diagnostics.Process.Start(ParameterString)

        Catch FatalException As Exception

            Return Join(SourceArray:=parseExceptionMsg(Exception:=FatalException,
                                            UserErrorDescription:="Error creating Email " & vbCrLf &
                                                                  "Address : " & EmailAddress & vbCrLf &
                                                                  "Subject : " & Subject & vbCrLf &
                                                                  "Body    : " & Body),
                          Delimiter:=vbCrLf)
        End Try

        Return ""

    End Function


#Region "Files and Directories"

    ''' <summary>
    ''' get the result from a file open dialog
    ''' </summary>
    ''' <param name="Filter">
    ''' format : Description (*.extension) + *.extension
    ''' </param>
    ''' <param name="Extension">
    ''' default extension, added automatically
    ''' </param>
    ''' <param name="Title">
    ''' title of the dialog
    ''' </param>
    ''' <param name="InitialDirectory">
    ''' directory to start from
    ''' </param>
    ''' <param name="Multiselect">
    ''' select more than one file
    ''' </param>
    Public Function getOpenFileName(Optional Filter As List(Of String) = Nothing,
                                    Optional Extension As String = "",
                                    Optional Title As String = "",
                                    Optional InitialDirectory As String = "",
                                    Optional Multiselect As Boolean = False) As String()

        Dim OpenFileName As String = Nothing
        Dim myOpenFileDialog As New OpenFileDialog

        'init filter
        If IsNothing(Filter) Then Filter = New List(Of String)


        'add option 'All files' to filter
        Filter.AddRange({"All files (*.*)", "*.*"})


        With myOpenFileDialog

            If InitialDirectory <> "" Then
                .Reset()
                .InitialDirectory = InitialDirectory
            End If

            'check for extension
            If Extension <> "" Then
                .AddExtension = True
                .DefaultExt = Extension
            End If


            If Title = "" Then Title = "IO File Dialog"

            .Title = Title
            .Filter = Join(SourceArray:=Filter.ToArray,
                        Delimiter:="|")

            .CheckPathExists = True
            .CheckFileExists = False
            .Multiselect = Multiselect

            If .ShowDialog = DialogResult.OK Then

                If Multiselect Then
                    Return .FileNames
                Else
                    Return {.FileName}
                End If

            Else
                Return {""}
            End If

        End With


    End Function


    ''' <summary>
    ''' get the result from a file open dialog
    ''' </summary>
    ''' <param name="Filter">
    ''' format : Description (*.extension) + *.extension
    ''' </param>
    ''' <param name="Extension">
    ''' default extension, added automatically
    ''' </param>
    ''' <param name="Title">
    ''' title of the dialog
    ''' </param>
    ''' <param name="InitialDirectory">
    ''' directory to start from
    ''' </param>
    Public Function getSaveFileName(Optional Filter As List(Of String) = Nothing,
                                    Optional Extension As String = "",
                                    Optional Title As String = "",
                                    Optional InitialDirectory As String = "") As String()

        Dim SaveFileName As String = Nothing
        Dim mySaveFileDialog As New SaveFileDialog

        'init filter
        If IsNothing(Filter) Then Filter = New List(Of String)


        'add option 'All files' to filter
        Filter.AddRange({"All files (*.*)", "*.*"})


        With mySaveFileDialog

            If InitialDirectory <> "" Then
                .Reset()
                .InitialDirectory = InitialDirectory
            End If

            'check for extension
            If Extension <> "" Then
                .AddExtension = True
                .DefaultExt = Extension
            End If


            If Title = "" Then Title = "IO File Dialog"

            .Title = Title
            .Filter = Join(SourceArray:=Filter.ToArray,
                        Delimiter:="|")

            .CheckPathExists = True


            If .ShowDialog = DialogResult.OK Then
                Return {.FileName}
            Else
                Return {""}
            End If

        End With


    End Function

#End Region

End Module


''' <summary>
''' Meta Data 
''' User Name, Version and Comments
''' </summary>
<Serializable>
<DescriptionAttribute("Meta Data")>
<DefaultProperty("Comments")>
<DisplayName("Meta Data")>
<TypeConverter(GetType(cMetaData.PGridConverter))>
Public Class cMetaData


#Region "Constructor"

    Public Sub New()

    End Sub

#End Region

#Region "PGrid Stuff"

    ''' <summary>
    ''' makes the class browsable for property grid
    ''' PGridItemName = name to display
    ''' </summary>
    Public Class PGridConverter

        Inherits ExpandableObjectConverter

        <RefreshProperties(RefreshProperties.All)>
        Public Shared Property PGridItemName As String = "Meta data"
        Public Shared Property ClassType As Type


#Region "Overloads Overrides"

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                         ByVal destinationType As Type) As Boolean

            Try
                If (destinationType Is ClassType) Then
                    Return True
                End If
            Catch ex As Exception

            End Try

            Return MyBase.CanConvertTo(context,
                                       destinationType)

        End Function

        Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

            If (destinationType Is GetType(System.String)) Then

                If value.GetType Is ClassType Then
                    Return PGridItemName
                End If

            End If

            Return MyBase.ConvertTo(context,
                                    culture,
                                    value,
                                    destinationType)

        End Function

#End Region

    End Class



    Public Sub showClassInPGrid()

        Dim dummy As String = ""
        Dim frmPgrid As New ToolBox.frmPGrid



        frmPgrid.Text = PGridConverter.PGridItemName
        frmPgrid.PGrid.SelectedObject = Me

        frmPgrid.ShowDialog()

    End Sub

#End Region



    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_Comments As String() = {"Add some comments here"}

    ''' <summary>
    ''' Comments
    ''' </summary>
    <Category("")>
    <DisplayName("Comments")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue({"Add some comments here"})>
    Public Property Comments As String()
        Get
            Return m_Comments
        End Get
        Set(vComments As String())
            m_Comments = vComments
        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_User As String = ""

    ''' <summary>
    ''' User
    ''' </summary>
    <Category("")>
    <DisplayName("User")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    <DefaultValue("")>
    Public Property User As String
        Get
            Return m_User
        End Get
        Set(vUser As String)
            m_User = vUser
        End Set
    End Property



    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_Version As String = ""

    ''' <summary>
    ''' Version
    ''' </summary>
    <Category("")>
    <DisplayName("Version")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    <DefaultValue("")>
    Public Property Version As String
        Get
            Return m_Version
        End Get
        Set(vVersion As String)
            m_Version = vVersion
        End Set
    End Property




End Class

