﻿
Imports System.Windows.Forms
Imports Toolbox.MailMerge


Public Class frmMailMerge

    Public Sub New()

        InitializeComponent()

    End Sub

    Public Sub New(Names As String(),
                   Values As String(),
                   AutoCompleteHeaderList As AutoCompleteStringCollection,
                   AutoCompleteValueList As AutoCompleteStringCollection)

        InitializeComponent()

        tsslblEntries.Text = Names.Count.ToString & " Entries"

        Me.AutoCompleteHeaderList = AutoCompleteHeaderList
        Me.AutoCompleteValueList = AutoCompleteValueList

        Me.cbxNamesValues.SelectedItem = "Names"

        With Me.txtSearchString
            .AutoCompleteMode = AutoCompleteMode.Suggest
            .AutoCompleteSource = AutoCompleteSource.CustomSource
            .AutoCompleteCustomSource = AutoCompleteHeaderList
        End With


        MMEntries.Clear()

        For counter As Integer = 0 To Names.Count - 1
            MMEntries.Add(New MMEntry(Names(counter),
                                      Values(counter)))
        Next

        tsslblEntries.Text = "Entries : " & Names.Count

        With dgvMailmerge

            .Font = New Drawing.Font("Courier New", 12)
            ttcbxFontSize.Text = "12"

            With .AlternatingRowsDefaultCellStyle
                .BackColor = Drawing.Color.Beige
                .ForeColor = Drawing.Color.Black
            End With

            .DataSource = Me.MMEntries
            .Columns(0).AutoSizeMode = DataGridViewAutoSizeColumnMode.None
            .Columns(.Columns.Count - 1).AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill

            .RowsDefaultCellStyle.WrapMode = DataGridViewTriState.False
            .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells

        End With


    End Sub


    Public Property Names As New List(Of String)
    Public Property Values As New List(Of String)


    Public Property MMEntries As New List(Of MMEntry)
    Public Property DummyEntries As New List(Of MMEntry)

    Public AutoCompleteValueList As AutoCompleteStringCollection
    Public AutoCompleteHeaderList As AutoCompleteStringCollection

    Public LinqMailMergeEntries As IEnumerable(Of MMEntry)


    Private Sub btnReset_Click(sender As Object,
                               e As EventArgs) Handles btnReset.Click

        Me.dgvMailmerge.DataSource = Me.MMEntries

    End Sub

    Private Sub btnUpdate_Click(sender As Object,
                                e As EventArgs) Handles btnUpdate.Click


        If cbxNamesValues.SelectedItem Is "Names" Then
            LinqMailMergeEntries =
                       From Result In MMEntries
                       Where Result.Name.ToUpper Like "*" & txtSearchString.Text.ToUpper & "*"
                       Order By Result.Name
        Else

            LinqMailMergeEntries =
                      From Result In MMEntries
                      Where Result.Value Like "*" & txtSearchString.Text & "*"
                      Order By Result.Name

        End If

        DummyEntries.Clear()
        DummyEntries.AddRange(LinqMailMergeEntries)

        Me.dgvMailmerge.DataSource = Me.DummyEntries

    End Sub

    Private Sub txtSearchString_TextChanged(sender As Object,
                                            e As EventArgs) Handles _
                                        txtSearchString.Leave

        

    End Sub

    Private Sub cbxNamesValues_SelectedIndexChanged(sender As System.Object,
                                                    e As System.EventArgs) Handles _
                                                cbxNamesValues.SelectedIndexChanged

        If cbxNamesValues.SelectedItem Is "Values" Then
            Me.txtSearchString.AutoCompleteCustomSource = AutoCompleteValueList
        Else
            Me.txtSearchString.AutoCompleteCustomSource = AutoCompleteHeaderList
        End If

        Me.txtSearchString.Text = ""

    End Sub

    Private Sub tsmiSavePMM_Click(sender As Object, e As EventArgs) Handles tsmiSavePMM.Click

        Dim mySaveFileDialog As New SaveFileDialog

        Dim MailMergeDB As New List(Of String)

        Dim ClearEmptyEntries As Boolean = False

        If MsgBox(Prompt:="Clear empty entries",
                 Buttons:=MsgBoxStyle.YesNo,
                   Title:="Delete unused entries") = MsgBoxResult.Yes Then ClearEmptyEntries = True

        For Each member As MMEntry In Me.MMEntries

            If member.Value = "" AndAlso ClearEmptyEntries Then Continue For
            Names.Add(member.Name)
            Values.Add(member.Value)

        Next


        'add  dummy entry & creation date  
        MailMergeDB.Add("Start" & MM_FieldDelimiter &
                        "MMCreationDate" & MM_FieldDelimiter &
                        Join(Me.Names.ToArray, MM_FieldDelimiter) &
                        MM_RecordDelimiter)

        MailMergeDB.Add("Start" & MM_FieldDelimiter &
                        Now.ToLongDateString & " " & Now.ToLongTimeString & MM_FieldDelimiter &
                        Join(Me.Values.ToArray, MM_FieldDelimiter) &
                        MM_RecordDelimiter)


        With mySaveFileDialog

            .AutoUpgradeEnabled = True
            .CheckPathExists = True
            .CreatePrompt = True

            .Title = "Select file to store Mail merge db"

            .Filter = "Mail merge db file (*.mm)|*.mm|" &
                      "Plain text files (*.txt)|*.txt|" &
                      "All files (*.*)|*.*"

            .FilterIndex = 0


            If .ShowDialog = Windows.Forms.DialogResult.OK Then

                Try
                    System.IO.File.WriteAllLines(.FileName, MailMergeDB.ToArray)
                    MsgBox(Prompt:="Mail merge db file write OK" & vbCrLf & .FileName,
                          Buttons:=MsgBoxStyle.Information,
                            Title:="Write mail merge db")
                Catch ex As Exception

                    MsgBox(Prompt:="Mail merge db file write ERROR" & vbCrLf &
                                   .FileName & vbCrLf & Join(SourceArray:=parseExceptionMsg(ex),
                                                               Delimiter:=vbCrLf),
                          Buttons:=MsgBoxStyle.Critical,
                          Title:="ERROR Write mail merge db")


                End Try
            End If



        End With

    End Sub


    Public Class MMEntry

        Public Sub New(Name As String,
                       Value As String)

            Me.Name = Name
            Me.Value = Value

        End Sub

        Public Property Name As String = ""
        Public Property Value As String = ""

    End Class

    Private Sub FontSize_Change(sender As Object,
                                e As EventArgs) Handles ttcbxFontSize.SelectedIndexChanged

        dgvMailmerge.Font = New Drawing.Font(familyName:="Courier New",
                                                  emSize:=CInt(ttcbxFontSize.Text))

    End Sub

    Private Sub ttsmiLoad_Click(sender As Object, e As EventArgs) Handles ttsmiLoad.Click




    End Sub

    Private Sub tsmiExit_Click(sender As Object,
                               e As EventArgs) Handles tsmiExit.Click

        Me.Close()

    End Sub

End Class

