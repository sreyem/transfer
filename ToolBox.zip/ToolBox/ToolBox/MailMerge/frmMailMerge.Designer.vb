﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMailMerge
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.dgvMailmerge = New System.Windows.Forms.DataGridView()
        Me.StatusStrip = New System.Windows.Forms.StatusStrip()
        Me.tsslblEntries = New System.Windows.Forms.ToolStripStatusLabel()
        Me.MenuStrip = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiSavePMM = New System.Windows.Forms.ToolStripMenuItem()
        Me.FontsizeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ttcbxFontSize = New System.Windows.Forms.ToolStripComboBox()
        Me.txtSearchString = New System.Windows.Forms.TextBox()
        Me.cbxNamesValues = New System.Windows.Forms.ComboBox()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.ttsmiLoad = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiExit = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.dgvMailmerge, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.StatusStrip.SuspendLayout()
        Me.MenuStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'dgvMailmerge
        '
        Me.dgvMailmerge.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgvMailmerge.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText
        Me.dgvMailmerge.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvMailmerge.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgvMailmerge.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnF2
        Me.dgvMailmerge.Location = New System.Drawing.Point(0, 62)
        Me.dgvMailmerge.Margin = New System.Windows.Forms.Padding(2)
        Me.dgvMailmerge.Name = "dgvMailmerge"
        Me.dgvMailmerge.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvMailmerge.RowTemplate.Height = 24
        Me.dgvMailmerge.Size = New System.Drawing.Size(869, 1070)
        Me.dgvMailmerge.TabIndex = 0
        '
        'StatusStrip
        '
        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsslblEntries})
        Me.StatusStrip.Location = New System.Drawing.Point(0, 1130)
        Me.StatusStrip.Name = "StatusStrip"
        Me.StatusStrip.Padding = New System.Windows.Forms.Padding(1, 0, 10, 0)
        Me.StatusStrip.Size = New System.Drawing.Size(869, 22)
        Me.StatusStrip.TabIndex = 1
        Me.StatusStrip.Text = "StatusStrip1"
        '
        'tsslblEntries
        '
        Me.tsslblEntries.Name = "tsslblEntries"
        Me.tsslblEntries.Size = New System.Drawing.Size(40, 17)
        Me.tsslblEntries.Text = "Entries"
        '
        'MenuStrip
        '
        Me.MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.FontsizeToolStripMenuItem})
        Me.MenuStrip.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip.Name = "MenuStrip"
        Me.MenuStrip.Padding = New System.Windows.Forms.Padding(4, 2, 0, 2)
        Me.MenuStrip.Size = New System.Drawing.Size(869, 24)
        Me.MenuStrip.TabIndex = 2
        Me.MenuStrip.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmiSavePMM, Me.ttsmiLoad, Me.tsmiExit})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(35, 20)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'tsmiSavePMM
        '
        Me.tsmiSavePMM.Name = "tsmiSavePMM"
        Me.tsmiSavePMM.Size = New System.Drawing.Size(152, 22)
        Me.tsmiSavePMM.Text = "&Save"
        '
        'FontsizeToolStripMenuItem
        '
        Me.FontsizeToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ttcbxFontSize})
        Me.FontsizeToolStripMenuItem.Name = "FontsizeToolStripMenuItem"
        Me.FontsizeToolStripMenuItem.Size = New System.Drawing.Size(59, 20)
        Me.FontsizeToolStripMenuItem.Text = "Fontsize"
        '
        'ttcbxFontSize
        '
        Me.ttcbxFontSize.Items.AddRange(New Object() {"7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17"})
        Me.ttcbxFontSize.Name = "ttcbxFontSize"
        Me.ttcbxFontSize.Size = New System.Drawing.Size(121, 21)
        '
        'txtSearchString
        '
        Me.txtSearchString.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtSearchString.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchString.Location = New System.Drawing.Point(128, 27)
        Me.txtSearchString.Margin = New System.Windows.Forms.Padding(2)
        Me.txtSearchString.Name = "txtSearchString"
        Me.txtSearchString.Size = New System.Drawing.Size(582, 26)
        Me.txtSearchString.TabIndex = 3
        '
        'cbxNamesValues
        '
        Me.cbxNamesValues.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxNamesValues.FormattingEnabled = True
        Me.cbxNamesValues.Items.AddRange(New Object() {"Names", "Values"})
        Me.cbxNamesValues.Location = New System.Drawing.Point(11, 27)
        Me.cbxNamesValues.Margin = New System.Windows.Forms.Padding(2)
        Me.cbxNamesValues.Name = "cbxNamesValues"
        Me.cbxNamesValues.Size = New System.Drawing.Size(102, 26)
        Me.cbxNamesValues.TabIndex = 4
        Me.cbxNamesValues.Text = "Names"
        '
        'btnReset
        '
        Me.btnReset.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnReset.Location = New System.Drawing.Point(794, 27)
        Me.btnReset.Margin = New System.Windows.Forms.Padding(2)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(65, 26)
        Me.btnReset.TabIndex = 5
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnUpdate.Location = New System.Drawing.Point(725, 27)
        Me.btnUpdate.Margin = New System.Windows.Forms.Padding(2)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(65, 26)
        Me.btnUpdate.TabIndex = 5
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'ttsmiLoad
        '
        Me.ttsmiLoad.Name = "ttsmiLoad"
        Me.ttsmiLoad.Size = New System.Drawing.Size(152, 22)
        Me.ttsmiLoad.Text = "&Load"
        '
        'tsmiExit
        '
        Me.tsmiExit.Name = "tsmiExit"
        Me.tsmiExit.Size = New System.Drawing.Size(152, 22)
        Me.tsmiExit.Text = "&Exit"
        '
        'frmMailMerge
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(869, 1152)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.cbxNamesValues)
        Me.Controls.Add(Me.txtSearchString)
        Me.Controls.Add(Me.StatusStrip)
        Me.Controls.Add(Me.MenuStrip)
        Me.Controls.Add(Me.dgvMailmerge)
        Me.MainMenuStrip = Me.MenuStrip
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.MinimumSize = New System.Drawing.Size(650, 480)
        Me.Name = "frmMailMerge"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmMailMerge"
        CType(Me.dgvMailmerge, System.ComponentModel.ISupportInitialize).EndInit()
        Me.StatusStrip.ResumeLayout(False)
        Me.StatusStrip.PerformLayout()
        Me.MenuStrip.ResumeLayout(False)
        Me.MenuStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dgvMailmerge As System.Windows.Forms.DataGridView
    Friend WithEvents StatusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents MenuStrip As System.Windows.Forms.MenuStrip
    Friend WithEvents txtSearchString As System.Windows.Forms.TextBox
    Friend WithEvents cbxNamesValues As System.Windows.Forms.ComboBox
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents tsslblEntries As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmiSavePMM As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents FontsizeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ttcbxFontSize As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents ttsmiLoad As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmiExit As System.Windows.Forms.ToolStripMenuItem
End Class
