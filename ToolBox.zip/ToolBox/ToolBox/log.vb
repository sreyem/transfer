﻿
Imports System.Windows.Forms
Imports System.IO


<DebuggerStepThrough()>
Public Module log

    Public LogList As New List(Of String)

#Region "Settings"

    Public Enum eLogLevel
        init = 0
        one
        two
        three
    End Enum

    Public FileName As String = ""
    Public Level As eLogLevel = eLogLevel.init
    Public LevelIntent As Integer = 3
    Public TimeStampPattern As String = "hh:mm"

    Public Enum eLog2Console
        Yes
        No
        Only
    End Enum

    Public NotifyIcon As Windows.Forms.NotifyIcon
    Public Status As ToolStripStatusLabel = Nothing
    Public LogTextbox As New TextBox

    Public Const ErrorIndicatior As String = "Error : "
    Public Const InfoIndicatior As String = "Info : "
    Public Const WarningIndicatior As String = "Warning : "

    Public Enum eLog2StatusAndNotify
        errorMsg
        info
        warning
        none
    End Enum

#End Region

#Region "Log and friends"

    '<DebuggerStepThrough>
    Function mylog(
                     LogTxt As String,
            Optional Log2Console As eLog2Console = eLog2Console.Yes,
            Optional Log2File As Boolean = True,
            Optional Log2Msgbox As Boolean = False,
            Optional MsgBoxBtn As MsgBoxStyle = MsgBoxStyle.Exclamation,
            Optional MsgTitle As String = "",
            Optional Add As Boolean = False,
            Optional WithoutTimeStamp As Boolean = False,
            Optional Log2lblStatus As eLog2StatusAndNotify = eLog2StatusAndNotify.none,
            Optional Log2NotifyIcon As eLog2StatusAndNotify = eLog2StatusAndNotify.none) As MsgBoxResult


        Dim NewLog As Boolean = True

        Dim TempList As New List(Of String)
        Dim TempString As String = ""
        Dim TimeStamp As String = ""

        Dim Lastlines As New List(Of String)

        Dim Txt2Log As String = ""

        'format time stamp + log level
        TimeStamp = Format(Now,
                           TimeStampPattern) &
                       " ".PadRight((Level * LevelIntent))


        'multi row log text without repeating time stamp
        If LogTxt.Contains(vbCrLf) OrElse
           LogTxt.Contains(vbLf) Then

            TempList.Clear()
            TempList.AddRange(LogTxt.Split(CChar(vbCrLf)))

            '1st row with time stamp
            Txt2Log = Replace(
                        Replace(TimeStamp & TempList.First,
                                vbCrLf, ""),
                          vbLf, "")

            If Log2Console = eLog2Console.Only Then
                Console.WriteLine(Txt2Log)
            Else
                Console.WriteLine(Txt2Log)
                LogList.Add(Txt2Log)
            End If

            'all others without
            For counter As Integer = 1 To TempList.Count - 1

                If WithoutTimeStamp Then
                    Txt2Log = Replace(Replace(TempList(counter),
                                              vbCrLf, ""),
                                     vbLf, "")
                Else
                    Txt2Log = "".PadLeft(TimeStamp.Length) &
                                        Replace(
                                            Replace(TempList(counter),
                                                    vbCrLf, ""),
                                                vbLf, "")

                End If

                'log 2 console
                Select Case Log2Console

                    Case eLog2Console.Yes

                        Console.WriteLine(Txt2Log)
                        LogList.Add(Txt2Log)

                    Case eLog2Console.Only

                        Console.WriteLine(Txt2Log)

                    Case eLog2Console.No
                        LogList.Add(Txt2Log)

                End Select

            Next

            'log 2 status label
            Try
                Status.Text = Replace(LogTxt, vbCrLf, " || ")
            Catch ex As Exception

            End Try

            Select Case Log2lblStatus

                Case eLog2StatusAndNotify.errorMsg
                    Try
                        Status.Text = ErrorIndicatior & Status.Text
                    Catch ex As Exception

                    End Try

                Case eLog2StatusAndNotify.warning
                    Try
                        Status.Text = WarningIndicatior & Status.Text
                    Catch ex As Exception

                    End Try

                Case eLog2StatusAndNotify.info
                    Try
                        Status.Text = InfoIndicatior & Status.Text
                    Catch ex As Exception

                    End Try

                Case eLog2StatusAndNotify.none

            End Select


        Else

            'single row log text
            If Add Then
                LogList(LogList.Count - 1) = LogList.Last & LogTxt
            Else
                If WithoutTimeStamp Then
                    LogList.Add(LogTxt)
                Else
                    LogList.Add(TimeStamp & LogTxt)
                End If
            End If

            'log 2 console
            Select Case Log2Console

                Case eLog2Console.Yes

                    If Add Then Console.CursorTop = Console.CursorTop - 1
                    Console.WriteLine(LogTxt)
                    LogList.Add(LogTxt)

                Case eLog2Console.Only

                    If Add Then Console.CursorTop = Console.CursorTop - 1
                    Console.WriteLine(LogTxt)

                Case eLog2Console.No
                    LogList.Add(Txt2Log)

            End Select

            'log 2 status label
            With Status

                Select Case Log2lblStatus

                    Case eLog2StatusAndNotify.errorMsg
                        Try
                            .Text = ErrorIndicatior & LogTxt
                        Catch ex As Exception

                        End Try

                    Case eLog2StatusAndNotify.warning
                        Try
                            .Text = WarningIndicatior & LogTxt
                        Catch ex As Exception

                        End Try

                    Case eLog2StatusAndNotify.info
                        Try
                            .Text = InfoIndicatior & LogTxt
                        Catch ex As Exception

                        End Try

                    Case eLog2StatusAndNotify.none

                End Select

            End With



            'log 2 notify icon
            With NotifyIcon

                Select Case Log2NotifyIcon

                    Case eLog2StatusAndNotify.errorMsg
                        Try
                            .BalloonTipText = LogTxt
                            .BalloonTipIcon = ToolTipIcon.Error
                        Catch ex As Exception

                        End Try

                    Case eLog2StatusAndNotify.warning
                        Try
                            .BalloonTipText = LogTxt
                            .BalloonTipIcon = ToolTipIcon.Warning
                        Catch ex As Exception

                        End Try

                    Case eLog2StatusAndNotify.info
                        Try
                            .BalloonTipText = LogTxt
                            .BalloonTipIcon = ToolTipIcon.Info
                        Catch ex As Exception

                        End Try

                    Case eLog2StatusAndNotify.none


                End Select

            End With

        End If

        Try

            If FileName <> "" Then
                File.WriteAllLines(path:=FileName,
                           contents:=LogList.ToArray)
            End If

        Catch ex As Exception

            Console.WriteLine("Can't write to log file" & vbCrLf &
                              FileName & vbCrLf &
                             Join(SourceArray:=ErrorHandling.parseExceptionMsg(ex),
                                    Delimiter:=vbCrLf))

            MsgBox(Prompt:="Can't write to log file" & vbCrLf &
                              FileName & vbCrLf &
                             Join(SourceArray:=ErrorHandling.parseExceptionMsg(ex),
                                    Delimiter:=vbCrLf),
                  Buttons:=MsgBoxStyle.Exclamation,
                    Title:="IO Error writing log file")

        End Try

        If Log2Msgbox Then

            Return MsgBox(Prompt:=LogTxt,
                         Buttons:=MsgBoxBtn,
                           Title:=MsgTitle)

        End If

        LogTextbox.Lines = LogList.ToArray

        Return MsgBoxResult.Ok

    End Function


    Public Function mylog(
                   LogTxtArray As String(),
          Optional Log2Msgbox As Boolean = False,
          Optional MsgBoxBtn As MsgBoxStyle = MsgBoxStyle.Exclamation,
          Optional MsgTitle As String = "",
          Optional WithoutTimeStamp As Boolean = False,
          Optional Log2Console As eLog2Console = eLog2Console.Yes,
          Optional Log2lblStatus As eLog2StatusAndNotify = eLog2StatusAndNotify.none) As MsgBoxResult

        Return mylog(
                LogTxt:=Join(LogTxtArray, vbCrLf),
            Log2Msgbox:=Log2Msgbox,
             MsgBoxBtn:=MsgBoxBtn,
              MsgTitle:=MsgTitle,
      WithoutTimeStamp:=WithoutTimeStamp,
           Log2Console:=Log2Console,
         Log2lblStatus:=Log2lblStatus)

    End Function

    Public Function mylog(
                   LogTxtList As List(Of String),
          Optional Log2Msgbox As Boolean = False,
          Optional MsgBoxBtn As MsgBoxStyle = MsgBoxStyle.Exclamation,
          Optional MsgTitle As String = "",
          Optional WithoutTimeStamp As Boolean = False,
          Optional Log2Console As eLog2Console = eLog2Console.Yes,
          Optional Log2lblStatus As eLog2StatusAndNotify = eLog2StatusAndNotify.none) As MsgBoxResult

        Return mylog(
                    LogTxt:=Join(LogTxtList.ToArray, vbCrLf),
                Log2Msgbox:=Log2Msgbox,
                 MsgBoxBtn:=MsgBoxBtn,
                  MsgTitle:=MsgTitle,
          WithoutTimeStamp:=WithoutTimeStamp,
               Log2Console:=Log2Console,
             Log2lblStatus:=Log2lblStatus)

    End Function


#End Region

    Public Sub showLogInNotepad()

        If FileName = "" Then Exit Sub

        Try
            Process.Start(FileName)
        Catch ex As Exception
            MsgBox(Prompt:="Can't show log file '" & FileName & "'" & vbCrLf & ex.Message,
                  Buttons:=MsgBoxStyle.Critical,
                    Title:="IO Error")
        End Try

    End Sub

    ''' <summary>
    ''' Reset the log file
    ''' </summary>
    ''' <param name="LogFileName"></param>
    ''' <param name="Clear"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function resetLog(Optional LogFileName As String = "",
                             Optional Clear As Boolean = True) As String()

        If LogFileName = "" Then
            LogFileName = Path.Combine(My.Application.Info.DirectoryPath,
                                       My.Application.Info.ProductName & "_log.txt")
        Else
            If Not Directory.Exists(Path.GetDirectoryName(LogFileName)) Then
                Return {"Error resetting log file",
                        "Invalid directory " & Path.GetDirectoryName(LogFileName)}
            End If
        End If


        Try
            If File.Exists(LogFileName) Then File.Delete(LogFileName)
        Catch ex As Exception
            Return parseExceptionMsg(UserErrorDescription:="Error resetting log file" & vbCrLf &
                                                            LogFileName,
                                                Exception:=ex)
        End Try


        FileName = LogFileName

        If Clear Then LogList.Clear()

        Return {}

    End Function




End Module
