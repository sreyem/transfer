﻿
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Drawing.Design
Imports System.Reflection
Imports System.Windows.Forms.Design


''' <summary>
''' Calculation of PECsw from FOCUSsw PRZM output file (*.zts)
''' </summary>
<Serializable>
<DescriptionAttribute("PGrid extensions")>
<DefaultProperty("ZTSFilePath")>
<TypeConverter(GetType(PGridExt.PGridConverter))>
Public Class PGridExt


    ''' <summary>
    ''' makes the class browsable for property grid
    ''' Change PGridExt as DisplayName
    ''' </summary>
    Public Class PGridConverter

        Inherits ExpandableObjectConverter

        'display name in a list
        Public Shared DisplayName As String = ""

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                         ByVal destinationType As Type) As Boolean

            Try
                If (destinationType Is GetType(PGridExt)) Then
                    Return True
                End If
            Catch ex As Exception

            End Try

            Return MyBase.CanConvertTo(context,
                                       destinationType)

        End Function

        Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

            If (destinationType Is GetType(System.String)) Then

                If value.GetType Is GetType(PGridExt) Then
                    Return DisplayName
                End If

            End If

            Return MyBase.ConvertTo(context,
                                    culture,
                                    value,
                                    destinationType)

        End Function

    End Class


    ''' <summary>
    ''' creates a drop down list from a string array
    ''' DropDownEntries = list to display
    ''' </summary>
    Public Class DropDownList

        Inherits StringConverter

        Public Shared Property DropDownEntries As String() = {"a", "s", "c"}

#Region "Overloads Overrides"

        Public Overloads Overrides Function GetStandardValuesSupported(ByVal context As ITypeDescriptorContext) As Boolean
            Return True
        End Function

        Public Overloads Overrides Function GetStandardValues(ByVal context As ITypeDescriptorContext) As StandardValuesCollection
            Return New StandardValuesCollection(DropDownEntries)
        End Function

        Public Overloads Overrides Function GetStandardValuesExclusive(ByVal context As ITypeDescriptorContext) As Boolean
            Return False
        End Function

#End Region

    End Class


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_TestDropDown As String = ""

    ''' <summary>
    ''' TestDropDown
    ''' </summary>
    <Category("")>
    <DisplayName("TestDropDown")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue("")>
    <TypeConverter(GetType(PGridExt.DropDownList))>
    Public Property TestDropDown As String
        Get
            Return m_TestDropDown
        End Get
        Set(vTestDropDown As String)
            m_TestDropDown = vTestDropDown
        End Set
    End Property

    
    ''' <summary>
    ''' shows an open file name editor
    ''' OpenFileDialog  = OpenFileDialog to set filter etc.
    ''' </summary>
    Public Class OpenFileNameEditor

        Inherits UITypeEditor

        Public Shared OpenFileDialog As New OpenFileDialog()

#Region "Overloads Overrides"

        Public Overrides Function GetEditStyle(context As ITypeDescriptorContext) As UITypeEditorEditStyle
            Return UITypeEditorEditStyle.Modal
        End Function

        Public Overrides Function EditValue(context As ITypeDescriptorContext,
                                            provider As IServiceProvider,
                                            value As Object) As Object

            Try

                If OpenFileDialog.ShowDialog() = DialogResult.OK Then
                    Return OpenFileDialog.FileName
                End If

            Catch ex As Exception
                Return ex.Message
            End Try


            Return MyBase.EditValue(context,
                                    provider,
                                    value)

        End Function

#End Region

    End Class


    Class StringEditor

        Inherits UITypeEditor

        Public Overrides Function GetEditStyle(context As ITypeDescriptorContext) As UITypeEditorEditStyle
            Return UITypeEditorEditStyle.Modal
        End Function

        Public Overrides Function EditValue(context As ITypeDescriptorContext, provider As IServiceProvider, value As Object) As Object

            Dim svc As IWindowsFormsEditorService = DirectCast(provider.GetService(GetType(IWindowsFormsEditorService)), IWindowsFormsEditorService)
            If svc IsNot Nothing Then
                ' update etc
                svc.ShowDialog(New Form())
            End If

            Return value
        End Function

    End Class


    <Editor(GetType(StringEditor), GetType(UITypeEditor))>
    Public Property test As String = ""


    Public Shared Sub SetLabelColumnWidth(PGrid As PropertyGrid,
                                          Width As Integer)

     

        ' get the grid view
        Dim view As Control =
            DirectCast(PGrid.[GetType]().GetField(name:="gridView",
                                          bindingAttr:=BindingFlags.Instance Or
                                                       BindingFlags.NonPublic).GetValue(PGrid), 
                       Control)

        ' set label width
        Dim fi As FieldInfo = view.[GetType]().GetField(name:="labelWidth",
                                                        bindingAttr:=BindingFlags.Instance Or
                                                                     BindingFlags.NonPublic)
        fi.SetValue(
                obj:=view,
              value:=Width)

        ' refresh
        view.Invalidate()

    End Sub



    Public Class MultiLineTextEditor

        Inherits UITypeEditor
        Private _editorService As IWindowsFormsEditorService

        Public Overrides Function GetEditStyle(context As ITypeDescriptorContext) As UITypeEditorEditStyle
            Return UITypeEditorEditStyle.DropDown
        End Function

        Public Overrides Function EditValue(context As ITypeDescriptorContext, provider As IServiceProvider, value As Object) As Object
            _editorService = DirectCast(provider.GetService(GetType(IWindowsFormsEditorService)), IWindowsFormsEditorService)

            Dim textEditorBox As New TextBox()
            textEditorBox.Multiline = True
            textEditorBox.ScrollBars = ScrollBars.Vertical
            textEditorBox.Width = 250
            textEditorBox.Height = 150
            textEditorBox.BorderStyle = BorderStyle.None
            textEditorBox.AcceptsReturn = True

            textEditorBox.Text = TryCast(value, String)

            _editorService.DropDownControl(textEditorBox)

            Return textEditorBox.Text

        End Function

    End Class


    <Editor(GetType(MultiLineTextEditor), GetType(UITypeEditor))>
    Public Property Bar() As String
        Get
            Return m_Bar
        End Get
        Set(value As String)
            Try
                m_Bar = value
            Catch ex As Exception

            End Try

        End Set
    End Property
    Private m_Bar As String


    ''' <summary>
    ''' set read only property
    ''' </summary>
    Public Sub SetReadOnlyProperty(ByVal propertyName As String,
                                  ByVal [readOnly] As Boolean)

        Dim descriptor As PropertyDescriptor =
                TypeDescriptor.GetProperties([GetType]())(propertyName)
        Dim attribute As ReadOnlyAttribute =
            DirectCast(descriptor.Attributes(GetType(ReadOnlyAttribute)), ReadOnlyAttribute)



        Dim fieldToChange As Reflection.FieldInfo =
                    attribute.[GetType]().GetField("isReadOnly",
                                                System.Reflection.BindingFlags.NonPublic Or
                                                System.Reflection.BindingFlags.Instance)

        fieldToChange.SetValue(attribute, [readOnly])

    End Sub

    ''' <summary>
    ''' set browsable property
    ''' </summary>
    Public Sub SetBrowsableProperty(ByVal propertyName As String,
                                  ByVal [browsable] As Boolean)

        Dim descriptor As PropertyDescriptor =
                TypeDescriptor.GetProperties([GetType]())(propertyName)
        Dim attribute As BrowsableAttribute =
            DirectCast(descriptor.Attributes(GetType(BrowsableAttribute)), BrowsableAttribute)



        Dim fieldToChange As Reflection.FieldInfo =
                    attribute.[GetType]().GetField("isBrowsable",
                                                System.Reflection.BindingFlags.NonPublic Or
                                                System.Reflection.BindingFlags.Instance)

        fieldToChange.SetValue(attribute, [browsable])

    End Sub


End Class

Public Module PGridMethods

    

End Module



''' <summary>
''' Calculation of PECsw from FOCUSsw PRZM output file (*.zts)
''' </summary>
<Serializable>
<DescriptionAttribute("ZTS2PECsw")>
<DefaultProperty("ZTSFilePath")>
<TypeConverter(GetType(ZTS2PECsw.PGridConverter))>
Public Class ZTS2PECsw


#Region "Constructor"

    Public Sub New()


    End Sub

#End Region

#Region "Property Grid Stuff"

    ''' <summary>
    ''' makes the class browsable for property grid
    ''' </summary>
    Public Class PGridConverter

        Inherits ExpandableObjectConverter

        'display name in a list
        Public Shared DisplayName As String = ""

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                         ByVal destinationType As Type) As Boolean

            Try
                If (destinationType Is GetType(ZTS2PECsw)) Then
                    Return True
                End If
            Catch ex As Exception

            End Try

            Return MyBase.CanConvertTo(context,
                                       destinationType)

        End Function

        Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

            If (destinationType Is GetType(System.String)) Then

                If value.GetType Is GetType(ZTS2PECsw) Then
                    Return DisplayName
                End If

            End If

            Return MyBase.ConvertTo(context,
                                    culture,
                                    value,
                                    destinationType)

        End Function

    End Class



    ''' <summary>
    ''' shows an open file name editor for FOCUSsw PRZM ZTS files
    ''' </summary>
    Public Class OpenFileNameEditor_PRZMDataFile

        Inherits UITypeEditor

        Private OpenFileDialog As New OpenFileDialog()

#Region "Overloads Overrides"

        Public Overrides Function GetEditStyle(context As ITypeDescriptorContext) As UITypeEditorEditStyle
            Return UITypeEditorEditStyle.Modal
        End Function

        Public Overrides Function EditValue(context As ITypeDescriptorContext,
                                            provider As IServiceProvider,
                                            value As Object) As Object

            With OpenFileDialog

                .Reset()
                .Multiselect = False
                .AddExtension = True
                .DefaultExt = ".zts"
                .CheckFileExists = True

                '.InitialDirectory = "x:\"
                .Title = "Select PRZM output (*.zts)  file"
                .Filter = "PRZM output files (*.zts)|*.zts|" &
                          "All files (*.*)|*.*"

                Try

                    If .ShowDialog() = DialogResult.OK Then
                        Return OpenFileDialog.FileName
                    End If

                Catch ex As Exception
                    Return "Select PRZM data file *.zts"
                End Try

            End With

            Return MyBase.EditValue(context,
                                    provider,
                                    value)

        End Function

#End Region

    End Class

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_FOCUSswPRZMZTSFilePath As String = "FOCUSsw PRZM output file (*.zts)"

    ''' <summary>
    ''' Full file path to the PRZM output (*.zts) file
    ''' </summary>
    <Category("Test")>
    <DisplayName("FOCUSsw PRZM *.zts File Path")>
    <Description("Full file path to the " & vbCrLf &
                 "FOCUSsw PRZM output file (*.zts)")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue("FOCUSsw PRZM output file (*.zts)")>
    <Editor(GetType(OpenFileNameEditor_PRZMDataFile), GetType(UITypeEditor))>
    Public Property FOCUSswPRZMZTSFilePath As String
        Get
            Return m_FOCUSswPRZMZTSFilePath
        End Get
        Set(vFOCUSswPRZMZTSFilePath As String)

            If System.IO.File.Exists(vFOCUSswPRZMZTSFilePath) Then
                m_FOCUSswPRZMZTSFilePath = vFOCUSswPRZMZTSFilePath
            Else
                mylog(
                    LogTxt:="FOCUSsw PRZM *.zts file" & vbCrLf &
                             vFOCUSswPRZMZTSFilePath &
                            " does NOT exist",
                Log2Msgbox:=True,
                 MsgBoxBtn:=MsgBoxStyle.Critical,
                  MsgTitle:="IO Error")

            End If

        End Set
    End Property



    ''' <summary>
    ''' shows an open file name editor for FOCUSsw PRZM ZTS files
    ''' </summary>
    Public Class OpenFileNameEditor_VFSmodDataFile

        Inherits UITypeEditor

        Private OpenFileDialog As New OpenFileDialog()

#Region "Overloads Overrides"

        Public Overrides Function GetEditStyle(context As ITypeDescriptorContext) As UITypeEditorEditStyle
            Return UITypeEditorEditStyle.Modal
        End Function

        Public Overrides Function EditValue(context As ITypeDescriptorContext,
                                            provider As IServiceProvider,
                                            value As Object) As Object

            With OpenFileDialog

                .Reset()
                .Multiselect = False
                .AddExtension = True
                .DefaultExt = ".zts"
                .CheckFileExists = True

                '.InitialDirectory = "x:\"
                .Title = "Select VFSmod output (VFSmod.csv)  file"
                .Filter = "PRZM output files (VFSmod.csv)|VFSmod.csv|" &
                          "All files (*.*)|*.*"

                Try

                    If .ShowDialog() = DialogResult.OK Then
                        Return OpenFileDialog.FileName
                    End If

                Catch ex As Exception
                    Return "Select VFSmod output (VFSmod.csv)  file"
                End Try

            End With

            Return MyBase.EditValue(context,
                                    provider,
                                    value)

        End Function

#End Region

    End Class



    ''' <summary>
    ''' shows an save file name editor for FOCUSsw PRZM to TOXSWA interface files
    ''' </summary>
    Public Class SaveFileNameEditor_P2TFile

        Inherits UITypeEditor

        Private SaveFileDialog As New SaveFileDialog()

#Region "Overloads Overrides"

        Public Overrides Function GetEditStyle(context As ITypeDescriptorContext) As UITypeEditorEditStyle
            Return UITypeEditorEditStyle.Modal
        End Function

        Public Overrides Function EditValue(context As ITypeDescriptorContext,
                                            provider As IServiceProvider,
                                            value As Object) As Object

            With SaveFileDialog

                .Reset()

                .AddExtension = True
                .DefaultExt = ".P2T"
                .OverwritePrompt = True
                .CheckFileExists = False



                '.InitialDirectory = "x:\"
                .Title = "Save PRZM to TOXSWA interface file"
                .Filter = "PRZM 2 TOXSWA interface file (*.P2T)|*.P2T|" &
                          "All files (*.*)|*.*"

                Try

                    If .ShowDialog() = DialogResult.OK Then
                        Return SaveFileDialog.FileName
                    End If

                Catch ex As Exception
                    Return "Save PRZM to TOXSWA interface file"
                End Try

            End With

            Return MyBase.EditValue(context,
                                    provider,
                                    value)

        End Function

#End Region

    End Class


    ''' <summary>
    ''' creates a drop down list from a string array
    ''' DropDownEntries = list to display
    ''' </summary>
    Public Class DropDownList

        Inherits StringConverter

        Public Shared Property DropDownEntries As String() = {"sdfsdf", "5555", "KKKKK"}

#Region "Overloads Overrides"

        Public Overloads Overrides Function GetStandardValuesSupported(ByVal context As ITypeDescriptorContext) As Boolean
            Return True
        End Function

        Public Overloads Overrides Function GetStandardValues(ByVal context As ITypeDescriptorContext) As StandardValuesCollection
            Return New StandardValuesCollection(DropDownEntries)
        End Function

        Public Overloads Overrides Function GetStandardValuesExclusive(ByVal context As ITypeDescriptorContext) As Boolean
            Return False
        End Function

#End Region

    End Class


#End Region

End Class


