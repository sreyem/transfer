﻿





#Region "System"

Imports System.IO
Imports System.Xml.Serialization

'Imports System.Reflection
Imports System.Runtime.Serialization

#End Region

Imports Toolbox.log

''' <summary>
''' Serialize a class to XML/SOAP or 
''' De serialize a class from XML/SOAP
''' </summary>
''' <remarks>
''' HM 20121113
''' </remarks>
Public Module DeSerialize

#Region "XML De-Serialization"


    ''' <summary>
    ''' Serializes a class to an xml file
    ''' </summary>
    ''' <param name="Class2Save">
    ''' The class to serialize
    ''' </param>
    ''' <param name="ClassType">
    ''' = gettype(Class2Save)
    ''' </param>
    ''' <param name="XMLFileName">
    ''' Target filename for the xml
    ''' </param>
    ''' <remarks></remarks>
    <DebuggerStepThrough()>
    Public Function Class2XML(ByVal Class2Save As Object,
                              ByVal ClassType As Type,
                              ByVal XMLFileName As String) As Boolean

        Dim ErrorMsg As String = ""

        If Not Directory.Exists(Path.GetDirectoryName(XMLFileName)) Then

            Try
                My.Computer.FileSystem.CreateDirectory(Path.GetDirectoryName(XMLFileName))
            Catch ex As Exception
                mylog(LogTxt:=Join(SourceArray:=parseExceptionMsg(Exception:=ex),
                                     Delimiter:=vbCrLf))
            End Try

            mylog(LogTxtArray:={"Not a valid XML Path",
                                XMLFileName},
                  Log2Console:=eLog2Console.Only)

        End If


        Try

            Dim mySerializer As XmlSerializer = _
                            New XmlSerializer(ClassType)

            Dim myWriter As IO.StreamWriter = _
                        New IO.StreamWriter(XMLFileName)

            mySerializer.Serialize(myWriter, Class2Save)

            myWriter.Close()
            myWriter = Nothing

            mylog(
                 LogTxt:="OK : Serializing " & Class2Save.ToString & " to " & XMLFileName,
            Log2Console:=eLog2Console.Only)

        Catch ex As Exception

            mylog(LogTxtArray:=parseExceptionMsg(ex))
            Return False

        End Try

        Return True

    End Function


    ''' <summary>
    ''' De-serializes an xml file to a class 
    ''' </summary>
    ''' <param name="ClassType">
    ''' = gettype(Class2Fill)
    ''' </param>
    ''' <param name="XMLFileName">
    ''' Target filename for the xml
    ''' </param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <DebuggerStepThrough()>
    Public Function XML2Class(ByVal ClassType As Type,
                              ByVal XMLFileName As String) As Object

        Dim TargetClass As New Object
        Dim ErrorMsg As String = ""

        If Not Directory.Exists(Path.GetDirectoryName(XMLFileName)) Then

            log.mylog(LogTxt:="Not a valid path : '" & XMLFileName & "'",
                    Log2Msgbox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical)

            Return Nothing

        End If

        Try

            Dim mySerializer As XmlSerializer = _
                            New XmlSerializer(ClassType)

            ' To read the file, create a FileStream.
            Dim myFileStream As IO.FileStream = _
                            New IO.FileStream(XMLFileName, IO.FileMode.Open)

            ' Call the Deserialize method and cast to the object type.
            TargetClass = mySerializer.Deserialize(myFileStream)

            myFileStream.Close()

            Console.WriteLine("OK : De-serialize " & XMLFileName & " to " & ClassType.ToString)

            Return TargetClass

        Catch ex As Exception

            log.mylog(LogTxt:=Join(SourceArray:=parseExceptionMsg(ex),
                                   Delimiter:=vbCrLf))
            Return Nothing

        End Try

    End Function


#End Region

#Region "SOAP De-Serialization"

    ''' <summary>
    ''' Serializes a class to a binary file
    ''' </summary>
    ''' <param name="Class2Save">
    ''' The class to serialize
    ''' </param>
    ''' <param name="BINFileName">
    ''' Target filename for the binary file
    ''' </param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <DebuggerStepThrough>
    Public Function Class2SOAP(Class2Save As Object,
                                      BINFileName As String) As Boolean

        Dim formatter As IFormatter
        Dim fileStream As FileStream = Nothing
        Dim strObject As String = ""

        Try


            fileStream = New FileStream(
                        path:=BINFileName,
                        mode:=FileMode.Create,
                      access:=FileAccess.Write)

            formatter = New Formatters.Binary.BinaryFormatter
            formatter.Serialize(
                    serializationStream:=fileStream,
                                  graph:=Class2Save)

        Catch ex As Exception

            log.mylog(
                    LogTxt:=Join(SourceArray:=parseExceptionMsg(ex),
                                   Delimiter:=vbCrLf))
            Return False

        Finally

            If fileStream IsNot Nothing Then
                fileStream.Close()
            End If

        End Try

        Return True

    End Function


    ''' <summary>
    ''' De-serializes an binary file to a class
    ''' </summary>
    ''' <param name="BINFileName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <DebuggerStepThrough>
    Public Function SOAP2Class(BINFileName As String) As Object

        Dim formatter As IFormatter
        Dim fileStream As FileStream = Nothing
        Dim objectFromSoap As Object = Nothing

        Try

            fileStream = New FileStream(
                     path:=BINFileName,
                     mode:=FileMode.Open,
                   access:=FileAccess.Read)

            formatter = New Formatters.Binary.BinaryFormatter
            objectFromSoap = formatter.Deserialize(serializationStream:=fileStream)

        Catch exception As Exception

            log.mylog(
                    LogTxt:=Join(SourceArray:=parseExceptionMsg(exception),
                                   Delimiter:=vbCrLf))
            Return Nothing

        Finally

            If fileStream IsNot Nothing Then
                fileStream.Close()
            End If

        End Try

        Return objectFromSoap

    End Function


#End Region

End Module
