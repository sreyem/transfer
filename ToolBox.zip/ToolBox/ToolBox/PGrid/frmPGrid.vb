﻿

Imports System.Windows.Forms

Public Class frmPGrid

    Public Sub New()
        InitializeComponent()
    End Sub

    Public Sub New(FileMenueItem As Boolean)

        InitializeComponent()

        Me.miLoad.Visible = False
        Me.miSave.Visible = False

    End Sub



    Public Property Class2ShowType As Type



    Private Sub FontSizeChanged(sender As Object,
                                e As EventArgs) Handles cmbFontSize.SelectedIndexChanged

        Me.PGrid.Font = New Drawing.Font(familyName:="Courier New",
                                             emSize:=CInt(cmbFontSize.SelectedItem.ToString))

    End Sub

    Private Sub PGrid_PropertyValueChanged(s As Object,
                                           e As Windows.Forms.PropertyValueChangedEventArgs) Handles PGrid.PropertyValueChanged

        If e.OldValue.ToString.ToLower = "dblclick" Then Exit Sub

        lblStatus.Text = "Value changed: " &
                         e.ChangedItem.Label &
                         " from " & e.OldValue.ToString &
                         " to " & e.ChangedItem.Value.ToString

    End Sub

    Private Sub miSave_Click(sender As Object,
                             e As EventArgs) Handles miSave.Click

        Dim mySaveFileDialog As New SaveFileDialog

        With mySaveFileDialog


            .Filter = "XML file (*.xml)|*.xml|" &
                      "Binary file (*.bin)|*.bin"

            .FilterIndex = 0 'std. = xml

            .AddExtension = True
            .AutoUpgradeEnabled = True
            .CheckFileExists = False
            .CheckPathExists = True
            .CreatePrompt = False
            .OverwritePrompt = True

            If .ShowDialog = Windows.Forms.DialogResult.OK Then

                If System.IO.Path.GetExtension(.FileName).ToLower = ".xml" Then

                    DeSerialize.Class2XML(
                                        Class2Save:=Me.PGrid.SelectedObject,
                                         ClassType:=Class2ShowType,
                                       XMLFileName:=.FileName)

                ElseIf System.IO.Path.GetExtension(.FileName).ToLower = ".bin" Then

                    DeSerialize.Class2SOAP(
                                        Class2Save:=Me.PGrid.SelectedObject,
                                       BINFileName:=.FileName)



                Else
                    'ToDo

                End If


            End If

        End With



    End Sub

    Private Sub miLoad_Click(sender As Object,
                             e As EventArgs) Handles miLoad.Click


        Dim myOpenFileDialog As New OpenFileDialog

        With myOpenFileDialog


            .Filter = "XML file (*.xml)|*.xml|" &
                      "Binary file (*.bin)|*.bin"

            .FilterIndex = 0

            .AddExtension = True
            .AutoUpgradeEnabled = True

            .CheckFileExists = False
            .CheckPathExists = True


            If .ShowDialog = Windows.Forms.DialogResult.OK Then


                If System.IO.Path.GetExtension(.FileName).ToLower = ".xml" Then

                    Me.PGrid.SelectedObject = Nothing
                    Me.PGrid.SelectedObject = DeSerialize.XML2Class(
                                     ClassType:=Class2ShowType,
                                   XMLFileName:=.FileName)

                   

                ElseIf System.IO.Path.GetExtension(.FileName).ToLower = ".bin" Then

                    Me.PGrid.SelectedObject = DeSerialize.SOAP2Class(BINFileName:=.FileName)

                Else
                    'ToDo

                End If


            End If


            RaiseEvent LoadClass2PGrid(Class2Load:=Me.PGrid.SelectedObject)

        End With


    End Sub


    Private Sub miExit_Click(sender As Object,
                             e As EventArgs) Handles miExit.Click


        RaiseEvent Request4Exit()
        Me.Close()


    End Sub

    Private Sub PGrid_SelectedGridItemChanged(sender As Object,
                                              e As SelectedGridItemChangedEventArgs) Handles PGrid.SelectedGridItemChanged

        Dim dummy As String = ""
        Dim DummyGrid As New System.Windows.Forms.PropertyGrid

        Me.PGrid.SuspendLayout()

        DummyGrid = CType(sender, System.Windows.Forms.PropertyGrid)


        'ToolBox.PGridExt.SetLabelColumnWidth(Me.PGrid, CInt(Me.PGrid.Font.Size * (2 + dummy.Length)))

        RaiseEvent SelectedGridItemChanged(sender:=sender, e:=e)

        Me.PGrid.ResumeLayout()

        Me.Refresh()

    End Sub



#Region "Events"

    Public Event Request4Exit()

    Public Event SelectedGridItemChanged(sender As Object, e As SelectedGridItemChangedEventArgs)

    Public Event LoadClass2PGrid(Class2Load As Object)

#End Region


    Private Sub miExpand_Click(sender As Object, e As EventArgs) Handles miExpand.Click
        Me.PGrid.ExpandAllGridItems()
    End Sub

    Private Sub miCollapse_Click(sender As Object, e As EventArgs) Handles miCollapse.Click
        Me.PGrid.CollapseAllGridItems()
    End Sub

End Class