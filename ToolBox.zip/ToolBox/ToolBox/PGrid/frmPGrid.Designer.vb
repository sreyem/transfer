﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPGrid
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()

        Me.StatusStrip = New System.Windows.Forms.StatusStrip()
        Me.lblStatus = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ProgressBar = New System.Windows.Forms.ToolStripProgressBar()
        Me.MenuStrip = New System.Windows.Forms.MenuStrip()

        Me.miFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.miLoad = New System.Windows.Forms.ToolStripMenuItem()
        Me.miSave = New System.Windows.Forms.ToolStripMenuItem()
        Me.miExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.miExpand = New System.Windows.Forms.ToolStripMenuItem()
        Me.miCollapse = New System.Windows.Forms.ToolStripMenuItem()

        Me.miSettings = New System.Windows.Forms.ToolStripMenuItem()
        Me.cmbFontSize = New System.Windows.Forms.ToolStripComboBox()
        Me.PGrid = New System.Windows.Forms.PropertyGrid()

        Me.StatusStrip.SuspendLayout()
        Me.MenuStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'StatusStrip
        '
        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lblStatus, Me.ProgressBar})
        Me.StatusStrip.Location = New System.Drawing.Point(0, 679)
        Me.StatusStrip.Name = "StatusStrip"
        Me.StatusStrip.Padding = New System.Windows.Forms.Padding(1, 0, 19, 0)
        Me.StatusStrip.Size = New System.Drawing.Size(656, 26)
        Me.StatusStrip.TabIndex = 0
        Me.StatusStrip.Text = "StatusStrip1"
        '
        'lblStatus
        '
        Me.lblStatus.Font = New System.Drawing.Font("Tahoma", 10.0!)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(47, 21)
        Me.lblStatus.Text = "Status"
        '
        'ProgressBar
        '
        Me.ProgressBar.Font = New System.Drawing.Font("Tahoma", 10.0!)
        Me.ProgressBar.Name = "ProgressBar"
        Me.ProgressBar.Size = New System.Drawing.Size(400, 20)
        Me.ProgressBar.Style = System.Windows.Forms.ProgressBarStyle.Continuous
        Me.ProgressBar.ToolTipText = "just be patient ;-)"
        '
        'MenuStrip
        '
        Me.MenuStrip.Font = New System.Drawing.Font("Tahoma", 10.0!)
        Me.MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miFile,
                                                                              Me.miSettings,
                                                                              Me.cmbFontSize})
        Me.MenuStrip.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip.Name = "MenuStrip"
        Me.MenuStrip.Padding = New System.Windows.Forms.Padding(8, 2, 0, 2)
        Me.MenuStrip.Size = New System.Drawing.Size(656, 29)
        Me.MenuStrip.TabIndex = 1
        Me.MenuStrip.Text = "MenuStrip1"
        '
        'miFile
        '
        Me.miFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miLoad,
                                                                                   Me.miSave,
                                                                                   Me.miExit})
        Me.miFile.Name = "miFile"
        Me.miFile.Size = New System.Drawing.Size(38, 25)
        Me.miFile.Text = "&File"
        '
        'miSettings
        '
        Me.miSettings.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.cmbFontSize,
                                                                                       Me.miExpand,
                                                                                       Me.miCollapse})
        Me.miSettings.Name = "miSettings"
        Me.miSettings.Size = New System.Drawing.Size(69, 25)
        Me.miSettings.Text = "Settings"
        '
        'cmbFontSize
        '
        Me.cmbFontSize.AutoToolTip = True
        Me.cmbFontSize.Font = New System.Drawing.Font("Tahoma", 10.0!)
        Me.cmbFontSize.Items.AddRange(New Object() {"9", "10", "11", "12", "13", "14", "15"})
        Me.cmbFontSize.Name = "cmbFontSize"
        Me.cmbFontSize.Size = New System.Drawing.Size(75, 25)
        Me.cmbFontSize.Text = "Font Size"
        Me.cmbFontSize.ToolTipText = "Select Font Size for Property Grid"
        '
        'PGrid
        '
        Me.PGrid.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PGrid.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PGrid.Location = New System.Drawing.Point(0, 33)
        Me.PGrid.Margin = New System.Windows.Forms.Padding(4)
        Me.PGrid.Name = "PGrid"
        Me.PGrid.PropertySort = System.Windows.Forms.PropertySort.Categorized
        Me.PGrid.Size = New System.Drawing.Size(656, 641)
        Me.PGrid.TabIndex = 2
        Me.PGrid.ToolbarVisible = False
        '
        'miLoad
        '
        Me.miLoad.Name = "miLoad"
        Me.miLoad.Size = New System.Drawing.Size(152, 22)
        Me.miLoad.Text = "&Load"
        '
        'miSave
        '
        Me.miSave.Name = "miSave"
        Me.miSave.Size = New System.Drawing.Size(152, 22)
        Me.miSave.Text = "&Save"
        '
        'miExit
        '
        Me.miExit.Name = "miExit"
        Me.miExit.Size = New System.Drawing.Size(152, 22)
        Me.miExit.Text = "&Exit"

        '
        'miExpand
        '
        Me.miExpand.Name = "miExpand"
        Me.miExpand.Size = New System.Drawing.Size(152, 22)
        Me.miExpand.Text = "E&xpand Grid"

        '
        'miExpand
        '
        Me.miCollapse.Name = "miCollapse"
        Me.miCollapse.Size = New System.Drawing.Size(152, 22)
        Me.miCollapse.Text = "&Collapse"


        '
        'frmPGrid
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(656, 705)
        Me.Controls.Add(Me.PGrid)
        Me.Controls.Add(Me.StatusStrip)
        Me.Controls.Add(Me.MenuStrip)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!,
                                          System.Drawing.FontStyle.Regular,
                                          System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MainMenuStrip = Me.MenuStrip
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmPGrid"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmPGrid"
        Me.StatusStrip.ResumeLayout(False)
        Me.StatusStrip.PerformLayout()
        Me.MenuStrip.ResumeLayout(False)
        Me.MenuStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents StatusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents lblStatus As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents MenuStrip As System.Windows.Forms.MenuStrip
    Public WithEvents PGrid As System.Windows.Forms.PropertyGrid
    Friend WithEvents ProgressBar As System.Windows.Forms.ToolStripProgressBar
    Friend WithEvents miFile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miSettings As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmbFontSize As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents miLoad As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miSave As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miExit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miExpand As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miCollapse As System.Windows.Forms.ToolStripMenuItem
End Class
