﻿
Imports System.IO


''' <summary>
''' parseExceptionMsg(Exception As Exception) As String()            : See where the error originates, returns an array
''' getStartInfo() As String()                                       : Basic app. infos
''' </summary>
''' <remarks></remarks>
<DebuggerStepThrough>
Public Module ErrorHandling

    ''' <summary>
    ''' Complete ex description with error origin
    ''' </summary>
    ''' <param name="Exception">
    ''' Error object from 'try catch'
    ''' </param>
    ''' <param name="UserErrorDescription">
    ''' Optional user comment, will be out in the 1st row
    ''' </param>
    ''' <returns>
    ''' Error description as string array
    ''' </returns>
    ''' <remarks>
    ''' Last Edit: 2015:Nov:24
    ''' by       : Horatio
    ''' </remarks>
    Public Function parseExceptionMsg(Exception As Exception,
                             Optional UserErrorDescription As String = "") As String()

        Const TargetAllignSpace As Integer = 15

        Dim Delimiter As String = ""
        Dim ModuleDelimiter As String = ""
        Dim RowDelimiter As String = ""

        Dim StackTraceArray As String() = {}
        Dim ErrorLineArray As String() = {}
        Dim Output As New List(Of String)

        If UserErrorDescription <> "" Then Output.Add(UserErrorDescription)

        Output.Add(Exception.Message)

        'check if German or English error MSG
        If Exception.StackTrace.Contains("at ") Then

            'english
            Delimiter = "at "
            ModuleDelimiter = " in "
            RowDelimiter = ":line"

        ElseIf Exception.StackTrace.Contains("bei ") Then

            'german
            Delimiter = "bei "
            ModuleDelimiter = " in "
            RowDelimiter = ":Zeile"

        Else

            With Output

                .Add("Unknown language. can't parse error msg!")
                .Add("ErrorMsg".PadRight(TargetAllignSpace) & ": " & Exception.Message.ToString)
                .Add("StackTrace")
                .Add(Exception.StackTrace.ToString)

            End With

            Return Output.ToArray

        End If

        Try

            StackTraceArray = Split(Exception.StackTrace,
                                    Delimiter)
            StackTraceArray = Filter(StackTraceArray,
                                     ModuleDelimiter)

            'parse each msg
            For Each ErrorLine As String In StackTraceArray

                With Output

                    'Module name
                    ErrorLineArray = Split(ErrorLine,
                                           ModuleDelimiter)
                    .Add("Module".PadRight(TargetAllignSpace) & ": " &
                         Trim(ErrorLineArray.First))

                    ErrorLineArray = Split(ErrorLineArray.Last,
                                           RowDelimiter)

                    'Where is the problem
                    .Add("in".PadRight(TargetAllignSpace) & ": " &
                         Trim(ErrorLineArray.First))

                    .Add("at row".PadRight(TargetAllignSpace) & ": " &
                         Trim(Replace(ErrorLineArray.Last,
                                      ".", "")))

                End With

            Next

        Catch FatalException As Exception

            With Output

                .Add("Can't parse error msg!")
                .Add("ErrorMsg".PadRight(TargetAllignSpace) & ": " &
                                Exception.Message.ToString)
                .Add("StackTrace")
                .Add(Exception.StackTrace.ToString)
                .Add(FatalException.StackTrace.ToString)

            End With

            Return Output.ToArray

        End Try

        Return Output.ToArray

    End Function


    ''' <summary>
    ''' Complete ex description with error origin
    ''' </summary>
    ''' <param name="Exception">
    ''' Error object from 'try catch'
    ''' </param>
    ''' <param name="Delimiter">
    ''' Delimiter to join the string array, std. = vbCrLf
    ''' </param>
    ''' <param name="UserErrorDescription">
    ''' Optional user comment, will be out in the 1st row
    ''' </param>
    ''' <returns>
    ''' Error description as string, joined with Delimiter
    ''' </returns>
    ''' <remarks></remarks>
    Public Function parseExceptionMsg(Exception As Exception,
                                      Delimiter As String,
                             Optional UserErrorDescription As String = "") As String


        Return Join(parseExceptionMsg(Exception:=Exception,
                           UserErrorDescription:=UserErrorDescription),
                       Delimiter:=Delimiter)


    End Function

    Public Enum eDeployment
        Local
        Network
        unknown
    End Enum

    ''' <summary>
    ''' Basic app. infos
    ''' </summary>
    Public Function getStartInfo(Optional LeadingString As String = "",
                                 Optional Deployment As eDeployment = eDeployment.unknown,
                                 Optional Version As String = "",
                                 Optional AppTitle As String = "",
                                 Optional SVN As Boolean = False) As String()

        Dim InfoList As New List(Of String)
        Dim SVNInfo As String() = {}

        Try
            If Version = "" Then Version = My.Application.Info.Title.ToString
            If AppTitle = "" Then AppTitle = My.Application.Info.Title.ToString
        Catch ex As Exception

        End Try



        With InfoList

            .Add(LeadingString & "Appl.      " & AppTitle & " v" & Version)

            Try

                If SVN Then SVNInfo = getSVNInfo()

                If SVNInfo.Count <> 0 Then

                    .Add(LeadingString & "SVN rev.   " & SVNInfo(0))
                    .Add(LeadingString & "        by " & SVNInfo(1))
                    .Add(LeadingString & "        at " & SVNInfo(2))

                End If

            Catch ex As Exception
                'no svn installed
            End Try



            .Add(LeadingString & "Started on " & Format(Now, "dddd, dd.MMM.yy"))
            .Add(LeadingString & "        at " & Format(Now, "hh:mm:ss"))
            .Add(LeadingString & "        by " & Environment.UserName)
            .Add(LeadingString & "on machine " & Environment.MachineName & _
                                          " (" & Environment.ProcessorCount & " CPUs)")
            .Add(LeadingString & "        OS " & Environment.OSVersion.VersionString)

            .Add(LeadingString & "Deployment " & Deployment.ToString)

            If Deployment = eDeployment.Local Then _
                        .Add(LeadingString & "Exec.  Dir " & My.Application.Info.DirectoryPath.ToString)

            .Add(LeadingString & "Net avail. " & My.Computer.Network.IsAvailable.ToString &
                                                " (" & Environment.UserDomainName & ")")

        End With

        Return InfoList.ToArray

    End Function

    ''' <summary>
    ''' Say whats wrong and die
    ''' </summary>
    ''' <param name="Exception">
    ''' Error object from 'try catch'
    ''' </param>
    ''' <param name="LogFileName">
    ''' Optional filename to save the error MSG
    ''' </param>
    ''' <remarks>
    ''' Last Edit: 2015:Nov:24
    ''' by       : Horatio
    ''' </remarks>
    Public Sub showErrorAndStop(Exception As Exception,
                       Optional LogFileName As String = "C:\Temp\Error.txt")

        Dim Output As New List(Of String)

        Try

            Output.AddRange(getStartInfo)
            Output.AddRange(parseExceptionMsg(Exception))

            File.WriteAllLines(path:=LogFileName,
                           contents:=Output.ToArray)


            Console.WriteLine(Join(Output.ToArray, vbCrLf))

            Process.Start(LogFileName)
            Environment.Exit(1)

        Catch FatalException As Exception

            MsgBox(FatalException.Message)
            Environment.Exit(1)

        End Try

    End Sub

   

    ''' <summary>
    ''' Kill a running process by its name
    ''' </summary>
    ''' <param name="ProcessName">
    ''' The name of the process to kill, please have a look at your task manager
    ''' </param>
    ''' <param name="WaitPeriod">
    ''' Optional waiting period in ms for every process related operation, std. 3000ms
    ''' </param>
    ''' <returns></returns>
    ''' <remarks>
    ''' Last Edit: 2015:Nov:24
    ''' by       : Horatio
    ''' </remarks>
    Public Function killProcessByName(ProcessName As String,
                             Optional WaitPeriod As Integer = 3000) As String

        Dim myProcesses As Process() = {}
        Dim Output As New List(Of String)

        Try

            myProcesses = {}
            myProcesses = Process.GetProcessesByName(ProcessName)

            If myProcesses.Count <> 0 Then

                'wait for proccess to finish
                Output.Add("Wait for " & WaitPeriod / 1000 & " sec. for " &
                                        ProcessName & " to shutdown; ID = " & myProcesses.First.Id)

                Threading.Thread.Sleep(WaitPeriod)

                'search again
                myProcesses = {}
                myProcesses = Process.GetProcessesByName(ProcessName)

                'and kill it
                For Each TargetProcess As Process In myProcesses

                    Try

                        Output.Add("Shutdown " & ProcessName & " ID = " & TargetProcess.Id)
                        TargetProcess.Kill()
                        Threading.Thread.Sleep(WaitPeriod)
                        Output(Output.Count - 1) = Output(Output.Count - 1) & " OK"

                    Catch FatalException As Exception

                        Return Join(SourceArray:=parseExceptionMsg(Exception:=FatalException,
                                                        UserErrorDescription:="Error killing a process by name" & vbCrLf &
                                                                              "Name : " & ProcessName & vbCrLf &
                                                                              "Wait : " & WaitPeriod.ToString & "ms" & vbCrLf &
                                                                              Join(SourceArray:=Output.ToArray, Delimiter:=vbCrLf)),
                                     Delimiter:=vbCrLf)

                    End Try

                Next

            End If

            'check if every instance is killed
            myProcesses = {}
            myProcesses = Process.GetProcessesByName(ProcessName)

            If myProcesses.Count <> 0 Then

                Output.Add("Error killing a process by name" & vbCrLf &
                           "Name : " & ProcessName & vbCrLf &
                           "Wait : " & WaitPeriod.ToString & "ms")
                Output.Add(ProcessName & " takes forever to kill")

                Return Join(SourceArray:=Output.ToArray,
                              Delimiter:=vbCrLf)

            End If

        Catch FatalException As Exception

            Return Join(SourceArray:=parseExceptionMsg(Exception:=FatalException,
                                                       UserErrorDescription:="Error killing a process by name" & vbCrLf &
                                                                             "Name : " & ProcessName & vbCrLf &
                                                                             "Wait : " & WaitPeriod.ToString & "ms"),
                                    Delimiter:=vbCrLf)

        End Try

        Return ""

    End Function


    ''' <summary>
    ''' Retriefes the SVN information
    ''' </summary>
    ''' <param name="SVNPath">
    ''' 
    ''' </param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function getSVNInfo(Optional SVNPath As String = "https://by-stsvn.bayer-ag.com/svn/EnSa/PROUTT/Pv3") As String()


        Const LastChangedRev As String = "Last Changed Rev"
        Const LastChangedAuthor As String = "Last Changed Author"
        Const LastChangedDate As String = "Last Changed Date: "
        Const SVNFileName As String = "svn.exe"


        Dim Output As New List(Of String)

        'start svn.exe
        Dim SVNprocess As New Process()

        With SVNprocess.StartInfo
            .FileName = SVNFileName
            .Arguments = " info " & SVNPath
            .UseShellExecute = False
            .RedirectStandardOutput = True
        End With

        Try
            SVNprocess.Start()
        Catch ex As Exception
            Return {}
        End Try


        'read the standard output of the svn process.  
        Dim Reader As StreamReader = SVNprocess.StandardOutput
        Dim SVNOutput As String = Reader.ReadToEnd()
        Dim Parameter As String() = {}
        Dim Dummy As String = ""

        Parameter = SVNOutput.Split(CChar(vbCrLf))

        'wait for svn process to exit
        SVNprocess.WaitForExit()
        SVNprocess.Close()

        'parse svn output
        'SVNRevision
        Dummy = Filter(Source:=Parameter,
                        Match:=LastChangedRev,
                      Compare:=CompareMethod.Text,
                      Include:=True).First


        Output.Add(Trim(Dummy.Split({":"c},
                           StringSplitOptions.RemoveEmptyEntries).Last))


        'SVNRevBy
        Dummy = Filter(Source:=Parameter,
                        Match:=LastChangedAuthor,
                      Compare:=CompareMethod.Text,
                      Include:=True).First

        Output.Add(Trim(Dummy.Split({":"c},
                        StringSplitOptions.RemoveEmptyEntries).Last))

        'SVNRevDate
        Dummy = Filter(Source:=Parameter,
                        Match:=LastChangedDate,
                      Compare:=CompareMethod.Text,
                      Include:=True).First

        Output.Add(Trim(Replace(Expression:=Dummy,
                                    Find:=LastChangedDate,
                             Replacement:="",
                                 Compare:=CompareMethod.Text)).Substring(1, "2015-05-06 14:06:16".Length + 1))



        Return Output.ToArray


    End Function


End Module
