﻿
Imports System.ComponentModel
Imports System.Xml.Serialization
Imports System.Windows.Forms
Imports System.IO
Imports System.Reflection



''' <summary>
''' Everything you need to make your class 'mailmerge-ready'
''' </summary>
''' <remarks>
''' Last Edit: 2015:Nov:24
''' by       : Horatio
''' </remarks>
<DebuggerStepThrough()>
Public Class MailMerge

#Region "Constructor"

    Public Sub New()

    End Sub

#End Region


    Public Enum eClick
        ok
        dblclick
    End Enum

    'mail merge is always first entry in property grid
    Const MM_CatMailMerge As String = "MailMerge Output"

    'show the mail merge properties in the property grid
    Const MM_ShowMMDetails As Boolean = False


#Region "Prefix"

    Private MM_mPrefix As String = ""

    ''' <summary>
    ''' Prefix for mail merge header like 'Mix00FSW...'
    ''' </summary>
    <Category(MM_CatMailMerge)>
    <Browsable(False)>
    <XmlIgnore()>
    Public Property MM_Prefix As String
        Get
            Return MM_mPrefix
        End Get
        Set(vPrefix As String)
            MM_mPrefix = vPrefix
            RaiseEvent MM_PrefixChange()
        End Set
    End Property

    Public Event MM_PrefixChange()

#End Region

#Region "Property Names & Values"

    Public Const MM_FieldDelimiter As Char = "@"c
    Public Const MM_RecordDelimiter As Char = "#"c

    Public Enum eReflInfo
        PropName
        PropValue
    End Enum

    ''' <summary>
    ''' An array of PropertyNames not to include in the mail merge db
    ''' </summary>
    ''' <remarks></remarks>
    <XmlIgnore()>
    <Browsable(MM_ShowMMDetails)>
    <Category(MM_CatMailMerge)>
    Public MM_BlackListPropertyNames As String() = {}


    ''' <summary>
    ''' An array of type names not to include in the mail merge db
    ''' </summary>
    ''' <remarks></remarks>
    <XmlIgnore()>
    <Browsable(MM_ShowMMDetails)>
    <Category(MM_CatMailMerge)>
    Public MM_BlackListTypes As String() = {}


    <XmlIgnore()>
    <Browsable(False)>
    <Category(MM_CatMailMerge)>
    Public Overridable ReadOnly Property MM_PropertyNames As String()
        Get

            Try

                Dim TempPropertyNames As New List(Of String)



                TempPropertyNames.AddRange(
                       getPropertyInfo(TargetClass:=Me,
                                          ReflInfo:=eReflInfo.PropName,
                                         BlackList:=MM_BlackListPropertyNames,
                                            Prefix:=Me.MM_Prefix))

                Return TempPropertyNames.ToArray

            Catch ex As Exception
                Return {""}
            End Try

        End Get
    End Property

    <XmlIgnore()>
    <Browsable(False)>
    <Category(MM_CatMailMerge)>
    Public Overridable ReadOnly Property MM_PropertyValues As String()
        Get

            Try

                Dim TempPropertyValues As New List(Of String)



                TempPropertyValues.AddRange(
                       getPropertyInfo(TargetClass:=Me,
                                          ReflInfo:=eReflInfo.PropValue,
                                         BlackList:=MM_BlackListPropertyNames))

                Return TempPropertyValues.ToArray

            Catch ex As Exception
                Return {""}
            End Try

        End Get
    End Property

    Public Function getPropertyInfo(ByVal TargetClass As Object,
                                    ByVal ReflInfo As eReflInfo,
                           Optional ByVal BlackList As String() = Nothing,
                           Optional ByVal Prefix As String = "") As String()

        Dim ReturnList As New List(Of String)

        Dim PropName As String = ""
        Dim PropValue As String = ""
        Dim PropValueList As New List(Of String)

        For Each p As System.Reflection.PropertyInfo In TargetClass.GetType().GetProperties()

            Try

                If p.CanRead Then

                    'skip the mailmerge base properties
                    If p.Name = "PropertyNames" OrElse
                       p.Name = "PropertyValues" OrElse
                       p.Name = "SaveMailMergedb" OrElse
                       p.Name = "MMdbNames" OrElse
                       p.Name = "MMdbValues" OrElse
                       p.Name = "SaveMailMergedb" OrElse
                       p.Name = "ShowMM" OrElse
                       p.Name = "MM_Prefix" Then Continue For

                    Try

                        'check for blacklist
                        If Not BlackList Is Nothing Then If BlackList.Contains(p.Name) Then Continue For

                    Catch ex As Exception

                    End Try

                    'property types we never want to have in our mailmerge db
                    If p.PropertyType.Name.ToLower = "eclick" Then Continue For


                    'check for different property types
                    '    string
                    If p.PropertyType Is GetType(String) Then
                        PropName = p.Name
                        PropValue = p.GetValue(obj:=TargetClass,
                                             index:=Nothing).ToString
                        'integer
                    ElseIf p.PropertyType Is GetType(Integer) Then
                        PropName = p.Name
                        PropValue = CType(p.GetValue(obj:=TargetClass,
                                                   index:=Nothing), Integer).ToString
                        'double
                    ElseIf p.PropertyType Is GetType(Double) Then
                        PropName = p.Name
                        PropValue = CType(p.GetValue(obj:=TargetClass,
                                                   index:=Nothing), Double).ToString
                        'decimal
                    ElseIf p.PropertyType Is GetType(Decimal) Then
                        PropName = p.Name
                        PropValue = CType(p.GetValue(obj:=TargetClass,
                                                   index:=Nothing), Decimal).ToString
                        'boolean
                    ElseIf p.PropertyType Is GetType(Boolean) Then
                        PropName = p.Name
                        PropValue = CType(p.GetValue(obj:=TargetClass,
                                                   index:=Nothing), Boolean).ToString
                        'enum
                    ElseIf p.PropertyType.BaseType.Name = "Enum" Then
                        PropName = p.Name
                        PropValue = p.GetValue(obj:=TargetClass,
                                             index:=Nothing).ToString


                    End If


                    If PropName <> "" Then

                        Select Case ReflInfo

                            Case eReflInfo.PropName
                                ReturnList.Add(Prefix & PropName)

                            Case eReflInfo.PropValue
                                ReturnList.Add(PropValue)

                        End Select

                    End If

                End If

                PropName = ""
                PropValue = ""

            Catch ex As Exception
                Debug.Print(Join(SourceArray:=parseExceptionMsg(Exception:=ex),
                                   Delimiter:=vbCrLf))

            End Try


        Next

        Return ReturnList.ToArray

    End Function

#End Region

#Region "DataGridView"

    Public Function AutoCompleteHeaderList() As AutoCompleteStringCollection

        Dim Temp As New AutoCompleteStringCollection

        Temp.AddRange(Me.MM_PropertyNames)

        Return Temp

    End Function

    Public Function AutoCompleteValueList() As AutoCompleteStringCollection

        Dim Temp As New AutoCompleteStringCollection

        Temp.AddRange(Me.MM_PropertyValues)

        Return Temp

    End Function


    Public Function dgvMailMergeEntries() As List(Of dgvMailMergeEntry)

        Dim MailMergeEntries As New List(Of dgvMailMergeEntry)


        Try
            If Me.MM_PropertyNames.Count = 0 OrElse
                Me.MM_PropertyNames.Count <> Me.MM_PropertyValues.Count Then

                Return MailMergeEntries

            End If
        Catch ex As Exception

        End Try

        For Counter As Integer = 0 To Me.MM_PropertyNames.Count - 1

            MailMergeEntries.Add(New dgvMailMergeEntry(
                            PropertyName:=Me.MM_PropertyNames(Counter),
                            PropertyValue:=Me.MM_PropertyValues(Counter)))

        Next

        Return MailMergeEntries

    End Function

    Public Class dgvMailMergeEntry

        Public Sub New()

        End Sub

        Public Sub New(ByVal PropertyName As String, ByVal PropertyValue As String)

            Me.PropertyName = PropertyName
            Me.PropertyValue = PropertyValue

        End Sub

        <XmlIgnore()>
        <Browsable(MM_ShowMMDetails)>
        <Category(MM_CatMailMerge)>
        Public Property PropertyName As String = ""

        <XmlIgnore()>
        <Browsable(MM_ShowMMDetails)>
        <Category(MM_CatMailMerge)>
        Public Property PropertyValue As String = ""

    End Class

#End Region

#Region "GUI"

    <XmlIgnore()>
    <Browsable(MM_ShowMMDetails)>
    <Category(MM_CatMailMerge)>
    <DisplayName("Refresh MM Entries")>
    Public Property refreshMM As eClick
        Get
            Return eClick.dblclick
        End Get
        Set(value As eClick)

            If value = eClick.dblclick Then Exit Property
            MMdbNames = Join(Me.MM_PropertyNames, vbCrLf)
            MMdbValues = Join(Me.MM_PropertyValues, vbCrLf)

        End Set
    End Property


    <XmlIgnore()>
    <Browsable(MM_ShowMMDetails)>
    <Category(MM_CatMailMerge)>
    <DisplayName("Mail-Merge DB P_Names")>
    Public Property MMdbNames As String
        

    <XmlIgnore()>
    <Browsable(MM_ShowMMDetails)>
    <Category(MM_CatMailMerge)>
    <DisplayName("Mail-Merge DB P_Values")>
    Public Property MMdbValues As String
        

    <XmlIgnore()>
    <Browsable(True)>
    <DisplayName("_Show Mail-Merge DB ")>
    <Category("_GUI")>
    Public Property ShowMM As eClick
        Get
            Return eClick.dblclick
        End Get
        Set(value As eClick)

            If value = eClick.dblclick Then Exit Property

            Dim MMfrom As New frmMailMerge(Me.MM_PropertyNames,
                                           Me.MM_PropertyValues,
                                           Me.AutoCompleteHeaderList,
                                           Me.AutoCompleteValueList)
            MMfrom.Show()

        End Set
    End Property

    <XmlIgnore()>
    <Browsable(True)>
    <DisplayName("_Show in Property grid")>
    <Category("_GUI")>
    Public Property ShowPGrid As eClick
        Get
            Return eClick.dblclick
        End Get
        Set(value As eClick)

            If value = eClick.dblclick Then Exit Property
            Dim frm As New frmPGrid

            With frm.PGrid

                .SelectedObject = Me
                .Refresh() 

            End With

            frm.Show()

        End Set
    End Property

    <XmlIgnore()>
    <Browsable(MM_ShowMMDetails)>
    <Category(MM_CatMailMerge)>
    <DisplayName("Mail-Merge DB save")>
    Public Overridable Property MM_SaveDB As eClick
        Get
            Return eClick.dblclick
        End Get
        Set(vMM_SaveDB As eClick)

            If vMM_SaveDB = eClick.dblclick Then Exit Property

            MM_writeDB()

        End Set
    End Property

    Public Function MM_writeDB() As String

        Dim MailMergeDB As New List(Of String)
        Dim mySaveFileDialog As New SaveFileDialog


        'add creation date
        MailMergeDB.Add("PMMCreationDate" &
                        MailMerge.MM_FieldDelimiter &
                        Join(SourceArray:=Me.MM_PropertyNames,
                               Delimiter:=MailMerge.MM_FieldDelimiter) & MailMerge.MM_RecordDelimiter)

        MailMergeDB.Add(Now.ToLongDateString & " " & Now.ToLongTimeString & MailMerge.MM_FieldDelimiter &
                        Join(SourceArray:=Me.MM_PropertyValues,
                               Delimiter:=MailMerge.MM_FieldDelimiter) & MailMerge.MM_RecordDelimiter)


        'add dummy entry 'start' 
        MailMergeDB.Add("Start" &
                        Join(SourceArray:=Me.MM_PropertyNames,
                               Delimiter:=MailMerge.MM_FieldDelimiter) & MailMerge.MM_RecordDelimiter)

        MailMergeDB.Add("Start" &
                        Join(SourceArray:=Me.MM_PropertyValues,
                               Delimiter:=MailMerge.MM_FieldDelimiter) & MailMerge.MM_RecordDelimiter)

        With mySaveFileDialog

            .AutoUpgradeEnabled = True
            .CheckPathExists = True
            .CreatePrompt = True

            .Title = "Select file to store Mail merge db"

            .Filter = "Mail merge db file (*.mmb)|*.mmb|" &
                      "Plain text files (*.txt)|*.txt|" &
                      "All files (*.*)|*.*"

            .FilterIndex = 0


            If .ShowDialog = Windows.Forms.DialogResult.OK Then

                Try
                    File.WriteAllLines(path:=.FileName,
                                   contents:=MailMergeDB.ToArray)

                    MsgBox(Prompt:="Mail merge db file write OK" & vbCrLf & .FileName,
                          Buttons:=MsgBoxStyle.Information,
                            Title:="Write mail merge db")

                Catch ex As Exception

                    Dim Output As String = "ERROR Mail merge db file write" & vbCrLf &
                                            .FileName & vbCrLf &
                                            Join(SourceArray:=parseExceptionMsg(Exception:=ex),
                                                   Delimiter:=vbCrLf)

                    MsgBox(Prompt:=Output,
                          Buttons:=MsgBoxStyle.Critical,
                            Title:="ERROR Write mail merge db")

                    Return Output

                End Try
            End If

            Return .FileName

        End With

    End Function

#End Region

End Class
