﻿

#Region "System"

Imports System.ComponentModel
Imports System.Xml.Serialization
Imports System.Windows.Forms
Imports System.IO
Imports System.Drawing.Design
Imports System.Windows.Forms.Design
Imports System.Drawing


#End Region




''' <summary>
''' Prototype for the perfect class
''' Just Shadow the Summary() property
''' Horatio Meyer 2017.01.16
''' </summary>
<Serializable>
<DescriptionAttribute("Prototype for the perfect " & vbCrLf &
                      "Property Grid Ready Class")>
<DefaultProperty("")>
<DisplayName("Perfect PGrid Class")>
<TypeConverter(GetType(cPerfectClass.cPGridConverter))>
<Editor(GetType(cPerfectClass.cShowClassInSeparateWindow), GetType(UITypeEditor))>
Public MustInherit Class cPerfectClass


    Inherits MailMerge

#Region "Constructor"

    Public Sub New()

        cPerfectClass.cPGridConverter.PGridItemName = {Name,
                                                       Join(Summary, vbCrLf)}
    End Sub

#End Region

#Region "PGrid Stuff"

    ''' <summary>
    ''' Makes the class browsable for property grid
    ''' PGridItemName = name to display
    ''' </summary>

    Public Class cPGridConverter

        Inherits ExpandableObjectConverter

        '<RefreshProperties(RefreshProperties.All)>
        Public Shared Property PGridItemName As String() = {"PGrid Item Name"}

        Public Shared Property Class2ShowType As Type


#Region "Overloads Overrides"

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                         ByVal destinationType As Type) As Boolean

            Try
                If (destinationType Is GetType(cPerfectClass)) Then
                    Return True
                End If
            Catch ex As Exception

            End Try

            Return MyBase.CanConvertTo(context,
                                       destinationType)

        End Function

        Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

            If (destinationType Is GetType(System.String)) Then

                Return Join(PGridItemName, vbCrLf)

            End If

            Return MyBase.ConvertTo(context,
                                    culture,
                                    value,
                                    destinationType)

        End Function


#End Region

    End Class


    Public Class cShowClassInSeparateWindow

        Inherits UITypeEditor

        Private _editorService As IWindowsFormsEditorService

        Public Overrides Function GetEditStyle(context As ITypeDescriptorContext) As UITypeEditorEditStyle
            Return UITypeEditorEditStyle.Modal
        End Function

        Public Overrides Function EditValue(context As ITypeDescriptorContext,
                                            provider As IServiceProvider,
                                            value As Object) As Object

            Dim editorService As IWindowsFormsEditorService = Nothing

            If provider IsNot Nothing Then
                editorService = TryCast(provider.GetService(GetType(IWindowsFormsEditorService)), 
                    IWindowsFormsEditorService)
            End If

            If editorService IsNot Nothing Then

                Dim frmTest As New frmPGrid


                frmTest.Class2ShowType = cPerfectClass.cPGridConverter.Class2ShowType

                With frmTest.PGrid

                    .Dock = DockStyle.Fill
                    .Font = New Font(familyName:="Courier New", emSize:=12)
                    .PropertySort = PropertySort.Categorized
                    .SelectedObject = value

                End With




                'frmTest.Controls.Add(PGrid)

                frmTest.ShowDialog()

            End If

            Return value

        End Function

    End Class

#End Region

    Private m_Name As String = " test "

    <XmlIgnore>
    <Browsable(True)>
    Public Property Name As String
        Get

            cPerfectClass.cPGridConverter.PGridItemName = {m_Name,
                                                       Join(Summary, vbCrLf)}

            Return m_Name


        End Get
        Set(value As String)

            m_Name = value

            cPerfectClass.cPGridConverter.PGridItemName = {m_Name,
                                                       Join(Summary, vbCrLf)}

        End Set
    End Property

    Public Shared Property Summary As String() = {"Summary", "werwr", "dfgdfgdg", "22222"}

End Class



''' <summary>
''' Template inheriting form the 'Perfect class
''' Just Shadow the Summary() property
''' Horatio Meyer 2017.01.16
''' </summary>
<Serializable>
<DescriptionAttribute("Prototype for the perfect " & vbCrLf &
                      "Property Grid Ready Class")>
<DefaultProperty("")>
<DisplayName("Perfect PGrid Class")>
<TypeConverter(GetType(cPerfectClass.cPGridConverter))>
<Editor(GetType(cPerfectClass.cShowClassInSeparateWindow), GetType(UITypeEditor))>
Public Class cPerfectClassTemplate

    Inherits cPerfectClass

#Region "Constructor"

    Public Sub New()

        cPerfectClass.cPGridConverter.PGridItemName = {Name,
                                                       Join(Summary, vbCrLf)}
    End Sub

#End Region


#Region "Output"


    <Category()>
    <Browsable(False)>
    Public Shadows ReadOnly Property Summary As String()
        Get

            cPerfectClassTemplate.cPGridConverter.PGridItemName = getSummary()

            Return getSummary()

        End Get
    End Property

    Private Function getSummary()

        Dim out As New List(Of String)

        With out

            .Add(Me.Name)
            .Add("Name")
            .Add("2nd row")
            .Add("last row")


        End With

        Return out.ToArray

    End Function

#End Region


End Class


