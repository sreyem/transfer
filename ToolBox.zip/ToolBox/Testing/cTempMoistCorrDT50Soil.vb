﻿












#Region "Imports System"

Imports System.ComponentModel
Imports System.Xml.Serialization

#End Region

#Region "Imports Toolbox"

Imports ToolBox
Imports FOCUSswBasic
Imports FOCUSswBasic.Step34

#End Region


''' <summary>
''' SOIL degradation 
''' temperature and moisture correction  
''' </summary>
<Serializable>
<DescriptionAttribute("SOIL degradation temp and moist. correction")>
<DefaultProperty("ModelTempCorrOnOFF")>
<DisplayName("Temp. and Moist. Correction")>
<TypeConverter(GetType(cTempMoistCorrDT50Soil.PGridConverter))>
Public Class cTempMoistCorrDT50Soil

#Region "Constructor"

    Public Sub New()

    End Sub

#End Region

#Region "PGrid Stuff"

    ''' <summary>
    ''' makes the class browsable for property grid
    ''' PGridItemName = name to display
    ''' </summary>
    Public Class PGridConverter

        Inherits ExpandableObjectConverter

        <RefreshProperties(RefreshProperties.All)>
        Public Shared Property PGridItemName As String = "Moisture and Temperature correction"
        Public Shared Property ClassType As Type


#Region "Overloads Overrides"

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                         ByVal destinationType As Type) As Boolean

            Try
                If (destinationType Is GetType(cTempMoistCorrDT50Soil)) Then
                    Return True
                End If
            Catch ex As Exception

            End Try

            Return MyBase.CanConvertTo(context,
                                       destinationType)

        End Function

        Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

            If (destinationType Is GetType(System.String)) Then

                If value.GetType Is ClassType Then
                    Return PGridItemName
                End If

            End If

            Return MyBase.ConvertTo(context,
                                    culture,
                                    value,
                                    destinationType)

        End Function

#End Region

    End Class

#End Region


#Region "Categories"

    Private Const CATModelTempSettings As String = "01  Temperature correction"
    Private Const CATModelMoistSettings As String = "02  Moisture correction"

    Private Const CATOutput As String = "03  Output"

#End Region


#Region "Std. model values"

    ''' <summary>
    ''' Molar activation energy
    ''' in kJ/mol, on = 65.4 kJ/mol| off = 0 kJ/mol 
    ''' </summary>
    Public Const stdMolarActivationEnergy As Double = 65.4

    ''' <summary>
    ''' Exponent for temperature response
    ''' in 1/K, on = 0.0948 1/K| off = 0 1/K 
    ''' </summary>
    Public Const stdMACROTempResponse As Double = 0.0948

    ''' <summary>
    ''' Q10 factor for temperature correction in PRZM/PELMO
    ''' on = 2.58 (old value = 2.2) | off = 0 
    ''' </summary>
    Public Const stdQ10TempCorr As Double = 2.58

    ''' <summary>
    ''' Walker exponent for the effect of liquid
    ''' min 0 (off) - max 5, std. = 0.7 (on)
    ''' </summary>
    Public Const stdWalkerExponent As Double = 0.7

    ''' <summary>
    ''' Calibrated exponent for the effect of liquid in MACRO
    ''' min 0 (off) - max 5, std. = 0.49 (on)
    ''' </summary>
    Public Const stdMACROWalkerExponent As Double = 0.49

    ''' <summary>
    ''' pF at which DT50 was measured
    ''' in log(cm), min 1 log(cm) - max 2 log(cm), std. = 2 log(cm)
    ''' </summary>
    Public Const stdpF As Double = 2

    ''' <summary>
    ''' Moisture content at which half-life was measured
    ''' in %, min 0% - max 100%, std. = 100%
    ''' </summary>
    Public Const stdRelativeMoistCont As Double = 100

    ''' <summary>
    ''' Moisture entry is relative or absolute
    ''' to field capacity (SWASH to SOIL or to FIELD), std = relative/FIELD 
    ''' </summary>
    Public Const stdMSFLG As eMSFLG = eMSFLG.relative

    ''' <summary>
    ''' Temperature at which half-life in soil was measured
    ''' min 5°C - max 30°C, std. = 20°C
    ''' </summary>
    Public Const stdSoilDegTemp As Double = 20

    ''' <summary>
    ''' Absolute min temp in °C = 0 °K
    ''' </summary>
    ''' <remarks></remarks>
    Public Const AbsoluteMinTemp As Double = 273.15

    ''' <summary>
    ''' Liq. content at which DT50 is measured [0|1]
    ''' </summary>
    Public Const stdLiqContentDT50Measurement As Double = 1.0

    ''' <summary>
    ''' OptimumConditions or NonOptimumConditions in PEARL
    ''' </summary>
    Public Const stdNonOrOptimumConditions As eNonOrOptimumConditions =
        eNonOrOptimumConditions.OptimumConditions

    Public Enum eOnOff

        _On
        _Off

        user_specific

    End Enum

#End Region

#Region "01  Model settings temp. corr."

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_ModelTempCorrOnOFF As eOnOff = eOnOff._On

    ''' <summary>
    ''' Switch temp. corr. ON/OFF
    ''' </summary>
    <Category(CATModelTempSettings)>
    <DisplayName("Switch temp. corr. ON/OFF")>
    <Description("Click to switch from 0 (OFF)" & vbCrLf &
                 "to std. value for temp. corr (ON) and vice versa")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <XmlIgnore>
    Public Property ModelTempCorrOnOFF As eOnOff
        Get


            If _
                MolarActivationEnergy = stdMolarActivationEnergy AndAlso
                    MACROTempResponse = stdMACROTempResponse AndAlso
                      Q10TempCorr = stdQ10TempCorr Then

                m_ModelTempCorrOnOFF = eOnOff._On

            ElseIf _
                MolarActivationEnergy = 0 AndAlso
                    MACROTempResponse = 0 AndAlso
                      Q10TempCorr = 1 Then

                m_ModelTempCorrOnOFF = eOnOff._Off

            Else

                m_ModelTempCorrOnOFF = eOnOff.user_specific

            End If

            Return m_ModelTempCorrOnOFF

        End Get
        Set(vModelTempCorrOnOFF As eOnOff)

            If vModelTempCorrOnOFF = eOnOff._On Then

                MolarActivationEnergy = stdMolarActivationEnergy
                MACROTempResponse = stdMACROTempResponse
                Q10TempCorr = stdQ10TempCorr



            ElseIf vModelTempCorrOnOFF = eOnOff._Off Then

                MolarActivationEnergy = 0
                MACROTempResponse = 0
                Q10TempCorr = 1

            ElseIf vModelTempCorrOnOFF = eOnOff.user_specific Then

            End If

            m_ModelMoistCorrOnOFF = vModelTempCorrOnOFF

        End Set
    End Property



    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_MolarActivationEnergy As Double = stdMolarActivationEnergy

    ''' <summary>
    ''' Molar activation energy
    ''' in kJ/mol, on = 65.4 kJ/mol| off = 0 kJ/mol
    ''' MolEntTra
    ''' </summary>
    <Category(CATModelTempSettings)>
    <DisplayName("Molar activation energy")>
    <Description("Molar activation energy for Arrhenius equation in PEARL/TOXSWA" & vbCrLf &
                 "in kJ/mol, on = 65.4 kJ/mol (old 56.0 kJ/mol)| off = 0 kJ/mol, MolEntTra")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(stdMolarActivationEnergy)>
    Public Property MolarActivationEnergy As Double
        Get
            Return m_MolarActivationEnergy
        End Get
        Set(vMolarActivationEnergy As Double)
            m_MolarActivationEnergy = vMolarActivationEnergy
            RaiseEvent Data_Change()
        End Set
    End Property

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_MACROTempResponse As Double = stdMACROTempResponse

    ''' <summary>
    ''' Exponent for temperature response for MACRO
    ''' in 1/K, on = 0.0948 1/K| off = 0 1/K 
    ''' TRESP
    ''' </summary>
    <Category(CATModelTempSettings)>
    <DisplayName("Exponent for temp. response")>
    <Description("Effect of temperature on degradation in MACRO" & vbCrLf &
                 "in 1/K, on = 0.0948 1/K| off = 0 1/K, TRESP")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(stdMACROTempResponse)>
    Public Property MACROTempResponse As Double
        Get
            Return m_MACROTempResponse
        End Get
        Set(vMACROTempResponse As Double)
            m_MACROTempResponse = vMACROTempResponse
            RaiseEvent Data_Change()
        End Set
    End Property

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_Q10TempCorr As Double = stdQ10TempCorr

    ''' <summary>
    ''' Q10 factor for temperature correction in PRZM/PELMO
    ''' "on = 2.58 (old value = 2.2) | off = 1 "
    ''' QFAC 
    ''' </summary>
    <Category(CATModelTempSettings)>
    <DisplayName("Q10 factor")>
    <Description("Q10 factor for temperature correction in PRZM/PELMO" & vbCrLf &
                 "on = 2.58 (old value = 2.2) | off = 1, QFAC ")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(stdQ10TempCorr)>
    Public Property Q10TempCorr As Double
        Get
            Return m_Q10TempCorr
        End Get
        Set(vQ10TempCorr As Double)
            m_Q10TempCorr = vQ10TempCorr
            RaiseEvent Data_Change()
        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_SoilDegTemp As Double = stdSoilDegTemp

    ''' <summary>
    ''' Temperature at which half-life in soil was measured
    ''' min 5°C - max 30°C, std. = 20°C
    ''' TemRefTra (PEARL), TBASE (PRZM), TREF (MACRO)
    ''' </summary>
    <Category(CATModelTempSettings)>
    <DisplayName("Soil temperature")>
    <Description("Temperature at which half-life in SOIL was measured" & vbCrLf &
                 "min 5°C - max 30°C, std. = 20°C, TemRefTra")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(stdSoilDegTemp)>
    Public Property SoilDegTemp As Double
        Get
            Return m_SoilDegTemp
        End Get
        Set(vSoilDegTemp As Double)

            If vSoilDegTemp >= 5 AndAlso vSoilDegTemp <= 30 Then
                m_SoilDegTemp = vSoilDegTemp
                RaiseEvent Data_Change()
            Else
                mylog(
                        LogTxt:="Temperature at which half-life in SOIL was measured" & vbCrLf &
                               "min 5°C - max 30°C, std. = 20°C" & vbCrLf &
                               "Your input is not valid : " & vSoilDegTemp,
                       Log2File:=False,
                       Log2Msgbox:=True,
                       MsgBoxBtn:=MsgBoxStyle.Critical)
            End If

        End Set
    End Property


#End Region

#Region "02  Model settings moist. corr."


    Private m_ModelMoistCorrOnOFF As eOnOff = eOnOff._On

    ''' <summary>
    ''' Switch Moist corr. ON/OFF
    ''' </summary>
    <Category(CATModelMoistSettings)>
    <DisplayName("Switch moist. corr ON/OFF")>
    <Description("Click to switch from 0 (OFF)" & vbCrLf &
                 "to std. value for moist. corr (ON) and vice versa")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(True)>
    <XmlIgnore>
    Public Property ModelMoistCorrOnOFF As eOnOff
        Get

            If _
                WalkerExponent = stdWalkerExponent AndAlso
                MACROWalkerExponent = stdMACROWalkerExponent Then

                m_ModelMoistCorrOnOFF = eOnOff._On

            ElseIf _
                     WalkerExponent = 0 AndAlso
                MACROWalkerExponent = 0 Then

                m_ModelMoistCorrOnOFF = eOnOff._Off

            Else

                m_ModelMoistCorrOnOFF = eOnOff.user_specific

            End If

            Return m_ModelMoistCorrOnOFF

        End Get
        Set(vModelMoistCorrOnOFF As eOnOff)

            If vModelMoistCorrOnOFF = eOnOff._On Then

                WalkerExponent = stdWalkerExponent
                MACROWalkerExponent = stdMACROWalkerExponent

            ElseIf vModelMoistCorrOnOFF = eOnOff._Off Then

                WalkerExponent = 0
                MACROWalkerExponent = 0

            End If

            m_ModelMoistCorrOnOFF = vModelMoistCorrOnOFF

        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_WalkerExponent As Double = stdWalkerExponent

    ''' <summary>
    ''' Walker exponent for the effect of liquid
    ''' min 0 (off) - max 5, std. = 0.7 (on)
    ''' </summary>
    <Category(CATModelMoistSettings)>
    <DisplayName("Walker Exponent")>
    <Description("Walker exponent for the effect of liquid" & vbCrLf &
                 "min 0 (off) - max 5, std. = 0.7 (on)")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(stdWalkerExponent)>
    Public Property WalkerExponent As Double
        Get
            Return m_WalkerExponent
        End Get
        Set(vWalkerExponent As Double)

            If vWalkerExponent >= 0 AndAlso vWalkerExponent <= 5 Then
                m_WalkerExponent = vWalkerExponent
                RaiseEvent Data_Change()
            Else
                MsgBox("Walker exponent for the effect of liquid" & vbCrLf &
                       "min 0 (off) - max 5, std. = 0.7 (on)" & vbCrLf &
                       "Your input is not valid : " & vWalkerExponent,
                       MsgBoxStyle.Exclamation)
            End If

        End Set
    End Property

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_MACROWalkerExponent As Double = stdMACROWalkerExponent

    ''' <summary>
    ''' Calibrated exponent for the effect of liquid in MACRO
    ''' min 0 (off) - max 5, std. = 0.49 (on)
    ''' EXPB
    ''' </summary>
    <Category(CATModelMoistSettings)>
    <DisplayName("Calibrated Walker exponent")>
    <Description("Calibrated exponent for the effect of liquid in MACRO" & vbCrLf &
                 "min 0 (off) - max 5, std. = 0.49 (on), EXPB")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(stdMACROWalkerExponent)>
    Public Property MACROWalkerExponent As Double
        Get
            Return m_MACROWalkerExponent
        End Get
        Set(vMACROWalkerExponent As Double)

            If vMACROWalkerExponent >= 0 AndAlso vMACROWalkerExponent <= 5 Then
                m_MACROWalkerExponent = vMACROWalkerExponent
                RaiseEvent Data_Change()
            Else
                MsgBox("Calibrated exponent for the effect of liquid in MACRO" & vbCrLf &
                       "min 0 (off) - max 5, std. = 0.49 (on)" & vbCrLf &
                       "Your input is not valid : " & vMACROWalkerExponent,
                       MsgBoxStyle.Exclamation)
            End If

        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_pF As Double = stdpF

    ''' <summary>
    ''' pF at which DT50 was measured
    ''' in log(cm), min 1 log(cm) - max 2 log(cm), std. = 2 log(cm)
    ''' PF1 (MACRO), MSFLG (PRZM)
    ''' </summary>
    <Category(CATModelMoistSettings)>
    <DisplayName("pF")>
    <Description("pF at which DT50 was measured" & vbCrLf &
                 "in log(cm), min 1 log(cm) - max 2 log(cm), std. = 2 log(cm)")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(stdpF)>
    Public Property pF As Double
        Get
            Return m_pF
        End Get
        Set(vpF As Double)

            If vpF >= 1 AndAlso vpF <= 2 Then
                m_pF = vpF
                RaiseEvent Data_Change()
            Else
                MsgBox("pF at which DT50 was measured" & vbCrLf &
                       "in log(cm), min 1 log(cm) - max 2 log(cm), std. = 2 log(cm)" & vbCrLf &
                       "Your input is not valid : " & vpF,
                       MsgBoxStyle.Exclamation)
            End If

        End Set
    End Property



    Public Enum eMSFLG
        absolute = 1 ' in SWASH relative to soil
        relative = 2 ' in SWASH relative to field, std!
    End Enum


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_MSFLG As eMSFLG = stdMSFLG

    ''' <summary>
    ''' Moisture entry is relative or absolute
    ''' to field capacity (SWASH to SOIL or to FIELD), std = relative/FIELD 
    ''' </summary>
    <Category(CATModelMoistSettings)>
    <DisplayName("Relative or absolute moisture")>
    <Description("Moisture entry is relative or absolute to field capacity" & vbCrLf &
                 "(SWASH/PRZM/PELMO = to SOIL or to FIELD), std = relative (FIELD  = 2)")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(CInt(stdMSFLG))>
    Public Property MSFLG As eMSFLG
        Get
            Return m_MSFLG
        End Get
        Set(vMSFLG As eMSFLG)
            m_MSFLG = vMSFLG
            RaiseEvent Data_Change()
        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_RelativeMoistCont As Double = stdRelativeMoistCont

    ''' <summary>
    ''' Moisture content at which half-life was measured
    ''' in %, min 0% - max 100%, std. = 100%
    ''' </summary>
    <Category(CATModelMoistSettings)>
    <DisplayName("Relative Soil moisture ")>
    <Description("Soil Moisture content relative to FC at which half-life" & vbCrLf &
                 " was measured in %, min 0% - max 100%, std. = 100%")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(stdRelativeMoistCont)>
    Public Property RelativeMoistCont As Double
        Get
            Return m_RelativeMoistCont
        End Get
        Set(vRelativeMoistCont As Double)

            If vRelativeMoistCont >= 0 AndAlso vRelativeMoistCont <= 100 Then
                m_RelativeMoistCont = vRelativeMoistCont
                RaiseEvent Data_Change()
            Else
                MsgBox("Soil Moisture content at which half-life was measured" & vbCrLf &
                       "in %, min 0% - max 100%, std. = 100%" & vbCrLf &
                       "Your input is not valid : " & vRelativeMoistCont,
                       MsgBoxStyle.Exclamation)
            End If

        End Set
    End Property

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_AbsoluteMoistCont As Double = 1

    <Category(CATModelMoistSettings)>
    <DisplayName("Absolute Soil moisture")>
    <Description("Absolute Soil moisture content value" & vbCrLf &
                 "in V/V ; std. = 1.00")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(1)>
    Public Property AbsoluteMoistCont As Double
        Get
            Return m_AbsoluteMoistCont
        End Get
        Set(vAbsoluteMoistCont As Double)
            m_AbsoluteMoistCont = vAbsoluteMoistCont
        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_LiqContentDT50Measurement As Double = stdLiqContentDT50Measurement

    ''' <summary>
    ''' Liq. content at which DT50 is measured
    ''' in kg/kg, std  = 1.0 kg/kg  [0|1]
    ''' </summary>
    <Category(CATModelMoistSettings)>
    <DisplayName("Liq. content")>
    <Description("Liq. content at which DT50 is measured in PEARL/TOXSWA" & vbCrLf &
                 "iin kg/kg, std  = 1.0 kg/kg  [0|1]")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(stdLiqContentDT50Measurement)>
    Public Property LiqContentDT50Measurement As Double
        Get
            Return m_LiqContentDT50Measurement
        End Get
        Set(vLiqContentDT50Measurement As Double)
            m_LiqContentDT50Measurement = vLiqContentDT50Measurement
            RaiseEvent Data_Change()
        End Set
    End Property


    Public Enum eNonOrOptimumConditions
        OptimumConditions = 0
        NonOptimumConditions
    End Enum


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_NonOrOptimumConditions As eNonOrOptimumConditions = stdNonOrOptimumConditions

    ''' <summary>
    ''' OptimumConditions or NonOptimumConditions in PEARL
    ''' std = OptimumConditions
    ''' </summary>
    <Category(CATModelMoistSettings)>
    <DisplayName("Non / OptimumConditions")>
    <Description("OptimumConditions or NonOptimumConditions in PEARL" & vbCrLf &
                 "std = OptimumConditions")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(CInt(stdNonOrOptimumConditions))>
    Public Property NonOrOptimumConditions As eNonOrOptimumConditions
        Get
            Return m_NonOrOptimumConditions
        End Get
        Set(vNonOrOptimumConditions As eNonOrOptimumConditions)
            m_NonOrOptimumConditions = vNonOrOptimumConditions
            RaiseEvent Data_Change()
        End Set
    End Property




#End Region

#Region "03  Output"

#Region "Summary"

    Public Const Click2EditString As String = "soil half-life temp. and moist. correction"

    ''' <summary>
    ''' Summary temp. and moist. corr. 
    ''' click 1st line to edit
    ''' </summary>
    <Category(CATOutput)>
    <DisplayName("Summary")>
    <Browsable(False)>
    Public ReadOnly Property Summary As String()
        Get
            Return getDT50Soil_Correction_Summary()
        End Get
    End Property

    Public Function getDT50Soil_Correction_Summary() As String()

        Dim Summary As New List(Of String)
        Dim Dummy As String = " ** Temperature corr."
        Dim Dummy2 As String = " ** Moisture    corr."

        With Summary

            .Add("Click here to edit " & Click2EditString)

            'temperature correction
            If MolarActivationEnergy = stdMolarActivationEnergy AndAlso
                   MACROTempResponse = stdMACROTempResponse AndAlso
                         Q10TempCorr = stdQ10TempCorr Then

                .Add(Dummy & " switched on **")
            ElseIf MolarActivationEnergy = 0 AndAlso
                       MACROTempResponse = 0 AndAlso
                             Q10TempCorr = 1 Then

                .Add(Dummy & " switched off **")
            Else
                .Add(Dummy & " ! indiv. values ! **")
            End If

            Dim PadRight As Integer = "  Molar activation energy ".Length
            Dim PadLeft As Integer = " (PRZM/PELMO)".Length


            'moisture correction
            If WalkerExponent = stdWalkerExponent AndAlso
          MACROWalkerExponent = stdMACROWalkerExponent Then

                .Add(Dummy2 & " switched on **")

            ElseIf WalkerExponent = 0 AndAlso
              MACROWalkerExponent = 0 Then

                .Add(Dummy2 & " switched off **")
            Else
                .Add(Dummy2 & " ! indiv. values ! **")
            End If

            .Add(" *************************************************** ")

            .Add(" Temperature at measurement : " & SoilDegTemp & "°C (" & SoilDegTemp + AbsoluteMinTemp & "°K)")
            .Add("  Molar activation energy".PadRight(PadRight) & MolarActivationEnergy.ToString.PadLeft(PadLeft) & " kJ/mol" & " (PEARL)".PadRight(PadLeft))
            .Add("  Temp. response exponent".PadRight(PadRight) & MACROTempResponse.ToString.PadLeft(PadLeft) & " 1/K   " & " (MACRO)".PadRight(PadLeft))
            .Add("  Q10 factor".PadRight(PadRight) & Q10TempCorr.ToString.PadLeft(PadLeft) & " -     " & " (PRZM/PELMO)".PadRight(PadLeft))



            .Add("  Walker exponent".PadRight(PadRight) & WalkerExponent.ToString.PadLeft(PadLeft) & " (MACRO = " & MACROWalkerExponent & ")")
            .Add("  Half-life is measured at pF " & pF & " and ")
            .Add("  " & CStr(IIf(Me.MSFLG = eMSFLG.relative, Me.RelativeMoistCont & " % soil moisture ",
                                                             Me.AbsoluteMoistCont & " V/V soil moisture ")) &
                      Replace(MSFLG.ToString, "_", " ") & " to field capacity")

            .Add(" *************************************************** ")

        End With


        Return Summary.ToArray


    End Function

#End Region

#Region "User input"


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_inclDescription As Boolean = True

    ''' <summary>
    ''' Model parameter incl. description
    ''' </summary>
    <Category(CATOutput)>
    <DisplayName("incl Description")>
    <Description("Model parameter incl. description" & vbCrLf &
                 "std. = true ;-)")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(True)>
    <XmlIgnore>
    Public Property inclDescription As Boolean
        Get
            Return m_inclDescription
        End Get
        Set(vinclDescription As Boolean)
            m_inclDescription = vinclDescription
        End Set
    End Property

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_SubstanceCode As String = "IOP"

    ''' <summary>
    ''' Substance Code
    ''' Max. 5 letters, do not start with a number
    ''' no special chars like _ or ; Do not : 124_T but T124
    ''' </summary>
    <Category(CATOutput)>
    <DisplayName("Substance Code")>
    <Description("Max. 5 letters, do not start with a number" & vbCrLf &
                 "no special chars like _ or ; Do not : 124_T but T124")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue("IOP")>
    Public Property SubstanceCode As String
        Get
            Return m_SubstanceCode
        End Get
        Set(vSubstanceCode As String)

            If vSubstanceCode.Length > 5 Then Exit Property

            'check if 1st char is a number
            For CharCounter As Integer = 0 To vSubstanceCode.Length - 1
                If Asc(vSubstanceCode(CharCounter)) >= 48 AndAlso
                    Asc(vSubstanceCode(CharCounter)) <= 57 AndAlso
                    CharCounter = 0 Then
                    vSubstanceCode = "Error"
                End If

                'only A - Z and a - z
                If Not Asc(vSubstanceCode(CharCounter)) >= 65 AndAlso
                   Not Asc(vSubstanceCode(CharCounter)) <= 90 OrElse
                   Not Asc(vSubstanceCode(CharCounter)) >= 97 AndAlso
                   Not Asc(vSubstanceCode(CharCounter)) <= 122 Then

                    vSubstanceCode = "Error"

                End If


            Next

            m_SubstanceCode = vSubstanceCode

        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_RunOffScenario As ePRZMScenarios = ePRZMScenarios.not_defined

    ''' <summary>
    ''' FOCUS sw Runoff sceanrio R1 - R4
    ''' </summary>
    <Category(CATOutput)>
    <DisplayName("RunOff Scenario")>
    <Description("FOCUS sw Runoff sceanrio R1 - R4" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(CInt(ePRZMScenarios.not_defined))>
    Public Property RunOffScenario As ePRZMScenarios
        Get
            Return m_RunOffScenario
        End Get
        Set(vRunOffScenario As ePRZMScenarios)
            m_RunOffScenario = vRunOffScenario
        End Set
    End Property


#End Region

#Region "PEARL"

    ''' <summary>
    ''' PEARL, basic temp. and moist. correction parameters
    ''' </summary>
    <Category(CATOutput)>
    <DisplayName("PEARL, basic DT50 correction")>
    <Browsable(True)>
    Public ReadOnly Property PEARL_DT50Soil_CorrectionBasic As String()
        Get
            Return getPEARL_DT50Soil_CorrectionBasic(
                        SubstanceCode:=Me.SubstanceCode,
                        inclDescription:=Me.inclDescription)
        End Get
    End Property

    Public Function getPEARL_DT50Soil_CorrectionBasic(
                   Optional SubstanceCode As String = "IOP",
                   Optional PadValue As Integer = 20,
                   Optional PadUnit As Integer = 25,
                   Optional PadDescription As Integer = 10,
                   Optional inclDescription As Boolean = True) As String()

        Dim PEARL As New List(Of String)

        With PEARL

            .Add("* Basic Parameters for soil half-life temp. and moist. correction " & SubstanceCode)

            .Add(Me.SoilDegTemp.ToString.PadRight(PadValue) &
               ("TemRefTra_" & SubstanceCode).PadRight(PadUnit) &
               "(C)".PadRight(PadDescription) &
               IIf(inclDescription, "Temperature at which DT50 is measured [5|30]", "").ToString)

            .Add(Me.WalkerExponent.ToString.PadRight(PadValue) &
                 ("ExpLiqTra_" & SubstanceCode).PadRight(PadUnit) &
                 "(-)".PadRight(PadDescription) &
                 IIf(inclDescription, "Exponent for the effect of liquid [0|5]", "").ToString)

            .Add(Me.MolarActivationEnergy.ToString.PadRight(PadValue) &
                 ("MolEntTra_" & SubstanceCode).PadRight(PadUnit) &
                 "(kJ/mol)".PadRight(PadDescription) &
                 IIf(inclDescription, "Molar activation energy [0|200]", "").ToString)

        End With


        Return PEARL.ToArray

    End Function


    ''' <summary>
    ''' PEARL, std. temp. and moist. correction parameters
    ''' </summary>
    <Category(CATOutput)>
    <DisplayName("PEARL, std. DT50 correction")>
    <Browsable(True)>
    Public ReadOnly Property PEARL_DT50Soil_CorrectionStd As String()
        Get
            Return getPEARL_DT50Soil_CorrectionStd(
                        SubstanceCode:=Me.SubstanceCode,
                        inclDescription:=Me.inclDescription)
        End Get
    End Property


    Public Function getPEARL_DT50Soil_CorrectionStd(
                 Optional SubstanceCode As String = "IOP",
                 Optional PadValue As Integer = 20,
                 Optional PadUnit As Integer = 25,
                 Optional PadDescription As Integer = 10,
                 Optional inclDescription As Boolean = True) As String()

        Dim PEARL As New List(Of String)

        With PEARL

            .Add("* Std parameters for soil half-life temp. and moist. correction " & SubstanceCode)


            .Add(Me.NonOrOptimumConditions.ToString.PadRight(PadValue) &
                 ("OptCntLiqTraRef_" & SubstanceCode).PadRight(PadUnit) &
                 "(-)".PadRight(PadDescription) &
                 IIf(inclDescription, "OptimumConditions or NonOptimumConditions", "").ToString)

            .Add(Me.LiqContentDT50Measurement.ToString.PadRight(PadValue) &
                 ("CntLiqTraRef_" & SubstanceCode).PadRight(PadUnit) &
                 "(kg/kg)".PadRight(PadDescription) &
                 IIf(inclDescription, "Liq. content at which DT50 is measured [0|1]", "").ToString)

            .Add("EqlDom_Input".PadRight(PadValue) &
                 ("OptDT50_" & SubstanceCode).PadRight(PadUnit) &
                 "(-)".PadRight(PadDescription) &
                 IIf(inclDescription, "Input or Calc. in equil. domain or liquid phase [EqlDom|LiqPhs]", "").ToString)


        End With


        Return PEARL.ToArray

    End Function


#End Region

#Region "PRZM"

#Region "RECORD 31 + 32"

    ''' <summary>
    '''  --- RECORD 31 + 32 ---
    ''' 31 Surface albedo, reflectivity of soil surface and wind speed 
    ''' 32 Average monthly values of bottom boundary soil temperatures in °C
    ''' </summary>
    <Category(CATOutput)>
    <DisplayName("PRZM , --- RECORD 31 + 32 ---")>
    <Description("31 Surface albedo, reflectivity of soil surface and wind speed" & vbCrLf &
                 "32 Scenario dependent values of bottom boundary soil temperatures in °C")>
    <Browsable(True)>
    Public ReadOnly Property RECORD3132 As String()
        Get

            Return createRECORD3132(
                Scenario:=Me.RunOffScenario, inclDescription:=Me.inclDescription)

        End Get
    End Property


    ''' <summary>
    ''' creates RECORD3132
    ''' </summary>
    ''' <param name="Scenario">
    ''' FOCUS sw Runoff sceanrio R1 - R4
    ''' </param>
    ''' <returns>RECORD26</returns>
    Public Function createRECORD3132(Scenario As ePRZMScenarios,
                                   Optional inclDescription As Boolean = True) As String()


        Dim temp As New List(Of String)


        Dim Header31 As String() =
           {
       "*** ",
       "*** --- RECORD 31 --- surface albedo, reflectivity of soil surface and wind speed",
       "***   ALBEDO monthly values of soil surface albedo, std. = 0.18",
       "*** + EMMISS reflectivity of soil surface std = 0.96",
       "*** + ZWIND  height of wind speed std. = 10m"
           }

        If inclDescription Then temp.AddRange(Header31)
        temp.Add(" 0.18 0.18 0.18 0.18 0.18 0.18 0.18 0.18 0.18 0.18 0.18 0.18 0.96 10.0")


        Dim Header32 As String() =
           {
       "*** ",
       "*** --- RECORD 32 --- Std Soil temperature",
       "*** BBT average monthly values of bottom boundary soil temperatures in °C",
       "*** R1 = 10.0°C ; R2 = 14.8°C ; R3 = 13.5°C ; R4 = 14.0°C"
           }

        If inclDescription Then temp.AddRange(Header32)

        Select Case Scenario

            Case ePRZMScenarios.not_defined
                temp.Add("!!!! RunOff Scenario undefined !!!!")

            Case ePRZMScenarios.R1
                temp.Add(" 10.0 10.0 10.0 10.0 10.0 10.0 10.0 10.0 10.0 10.0 10.0 10.0")

            Case ePRZMScenarios.R2
                temp.Add(" 14.8 14.8 14.8 14.8 14.8 14.8 14.8 14.8 14.8 14.8 14.8 14.8")

            Case ePRZMScenarios.R3
                temp.Add(" 13.5 13.5 13.5 13.5 13.5 13.5 13.5 13.5 13.5 13.5 13.5 13.5")

            Case ePRZMScenarios.R4
                temp.Add(" 14.0 14.0 14.0 14.0 14.0 14.0 14.0 14.0 14.0 14.0 14.0 14.0")

        End Select


        Return temp.ToArray

    End Function



#End Region

#Region "RECORD 32a"

    ''' <summary>
    '''  --- RECORD 32a ---
    ''' DT50 temperature correction 
    ''' incl. std. values of bottom boundary soil temperatures
    ''' </summary>
    <Category(CATOutput)>
    <DisplayName("PRZM , --- RECORD 32a ---")>
    <Description("DT50 temperature correction")>
    <Browsable(True)>
    Public ReadOnly Property RECORD32a As String()
        Get

            Return createRECORD32a(
                                  ParMetParameter:=
                                        {Me.Q10TempCorr.ToString + "," +
                                         Me.SoilDegTemp.ToString},
                                  inclDescription:=Me.inclDescription)

        End Get
    End Property

    ''' <summary>
    ''' creates RECORD32a
    ''' </summary>
    ''' <param name="ParMetParameter">
    ''' createRECORD32a({Par.Q10TempCorr.ToString + "," + "," + Par.SoilDegTemp.ToString,
    '''                  Met.Q10TempCorr.ToString + "," + "," + Met.SoilDegTemp.ToString
    ''' </param>
    ''' <returns>RECORD26</returns>
    Public Function createRECORD32a(
                                   ParMetParameter As String(),
                                   Optional inclDescription As Boolean = True) As String()





        Dim Header32a As String() =
            {
        "*** ",
        "*** --- RECORD 32a --- DT50 temperature correction",
        "*** 01 QFAC  Q10 value: factor for rate increase when temperature increases by 10°C, std. = 2.58, old = 2.2",
        "*** 02 TBASE temperature during the test of degradation, std. = 20°C"
            }

        Dim temp As New List(Of String)
        Dim ParameterSet As String() = {}
        Dim HeaderNumber As String = ""
        Dim TempRow As String = ""
        Dim Parameter As Double = 0


        If inclDescription Then temp.AddRange(Header32a)

        'header
        'for each of the 3 parameter
        For ParCounter As Integer = 1 To 2

            'repeat counter
            For CompCounter As Integer = 1 To ParMetParameter.Count

                If ParCounter = 1 And CompCounter = 1 Then
                    HeaderNumber = "***   0" & ParCounter
                Else
                    HeaderNumber &= "      0" & ParCounter
                End If

            Next

        Next

        If inclDescription Then temp.Add(HeaderNumber)

        For ParCounter As Integer = 0 To 1

            'repeat counter
            For CompCounter As Integer = 0 To ParMetParameter.Count - 1

                ParameterSet = ParMetParameter(CompCounter).Split({","c})

                Parameter = CDbl(ParameterSet(ParCounter))
                TempRow &= Parameter.ToString("0.00").PadLeft(8)

            Next

        Next

        temp.Add(TempRow)

        Return temp.ToArray

    End Function

#End Region

#Region "RECORD 32b"

    ''' <summary>
    '''  --- RECORD 32b ---
    ''' DT50 moisture correction
    ''' </summary>
    <Category(CATOutput)>
    <DisplayName("PRZM , --- RECORD 32b ---")>
    <Description("DT50 moisture correction")>
    <Browsable(True)>
    Public ReadOnly Property RECORD32b As String()
        Get

            Return createRECORD32b(
                                  ParMetParameter:=
                                        {CInt(Me.MSFLG).ToString + "," +
                                         Me.WalkerExponent.ToString + "," +
                                         Me.AbsoluteMoistCont.ToString("0.00"),
                                         CInt(Me.MSFLG).ToString + "," +
                                         Me.WalkerExponent.ToString + "," +
                                         Me.AbsoluteMoistCont.ToString("0.00")},
                                  inclDescription:=Me.inclDescription)

        End Get
    End Property

    ''' <summary>
    ''' creates RECORD32b DT50 moisture correction
    ''' </summary>
    ''' <param name="ParMetParameter">
    ''' createRECORD32b({Par.MSFLG.ToString + "," + "," + Par.WalkerExponent.ToString + "," + Par.MSLAB,
    '''                  Met.MSFLG.ToString + "," + "," + Met.WalkerExponent.ToString + "," + Met.MSLAB
    ''' </param>
    ''' <returns>RECORD26</returns>
    Public Function createRECORD32b(ParMetParameter As String(),
                                   Optional inclDescription As Boolean = True) As String()

        Dim Header As String() =
            {
        "*** ",
        "*** --- RECORD 32b --- DT50 temperature correction",
        "*** 01 MSFLG  Moisture entry is relative (1) or absolute (2) to field capacity, std = 2",
        "*** 02 Walker Exponent of moisture corrected degradation, std. = 0.7",
        "*** 03 MSLAB  reference soil moisture, std. = 1.00"
            }

        Dim temp As New List(Of String)
        Dim ParameterSet As String() = {}
        Dim HeaderNumber As String = ""
        Dim TempRow As String = ""
        Dim Parameter As Double = 0

        If inclDescription Then temp.AddRange(Header)

        'header
        'for each of the 3 parameter
        For CompCounter As Integer = 1 To ParMetParameter.Count
            For ParCounter As Integer = 1 To 3

                'repeat counter


                If ParCounter = 1 And CompCounter = 1 Then
                    HeaderNumber = "***   0" & ParCounter
                Else
                    HeaderNumber &= "      0" & ParCounter
                End If

            Next

        Next

        If inclDescription Then temp.Add(HeaderNumber)
        For CompCounter As Integer = 0 To ParMetParameter.Count - 1

            For ParCounter As Integer = 0 To 2

                'repeat counter


                ParameterSet = ParMetParameter(CompCounter).Split({","c})

                If ParCounter = 0 Then
                    Parameter = CInt(ParameterSet(ParCounter))
                    TempRow &= Parameter.ToString("0").PadLeft(8)

                Else
                    Parameter = CDbl(ParameterSet(ParCounter))
                    TempRow &= Parameter.ToString("0.00").PadLeft(8)
                End If

            Next

        Next

        temp.Add(TempRow)

        Return temp.ToArray

    End Function

#End Region

#End Region

#Region "PELMO"

    Public Const PELMO_Degrate As String = "<  degrate"
    Public Const PELMO_RelDegNeq As String = "  rel deg neq"
    Public Const PELMO_Sites As String = "    sites>"

    ''' <summary>
    '''  DEGRADATION section in PELMO
    ''' </summary>
    ''' <value></value>
    <Category(CATOutput)>
    <DisplayName("PELMO , --- DEGRADATION ---")>
    <Description("DT50 moisture correction")>
    <Browsable(True)>
    Public ReadOnly Property PELMOTempMoistCorrString As String()
        Get

            Dim temp As String = PELMO_Degrate
            Dim Header As String = "<  degrate  degtemp   q10  moist-abs  moist-rel  moist-exp  rel deg neq    sites>"

            temp &= Me.SoilDegTemp.ToString("0.0").PadLeft("  degtemp".Length)
            temp &= Me.Q10TempCorr.ToString("0.00").PadLeft("   q10".Length)

            If Me.MSFLG = eMSFLG.relative Then
                temp &= 0.ToString("0.00").PadLeft("  moist-abs".Length)
                temp &= Me.RelativeMoistCont.ToString("0.00").PadLeft("  moist-rel".Length)
            Else
                temp &= Me.AbsoluteMoistCont.ToString("0.000").PadLeft("  moist-abs".Length)
                temp &= 0.ToString("0.00").PadLeft("  moist-rel".Length)
            End If

            temp &= Me.WalkerExponent.ToString("0.00").PadLeft("  moist-exp".Length)


            temp &= PELMO_RelDegNeq & PELMO_Sites

            Return {Header, temp}

        End Get
    End Property


#End Region

#End Region

#Region "Events"

    <Category(CATOutput)>
    <DisplayName("Input Complete ?")>
    Public ReadOnly Property InputComplete As Boolean
        Get
            Return True
        End Get
    End Property

    Public Event Data_Change()

#End Region


End Class


