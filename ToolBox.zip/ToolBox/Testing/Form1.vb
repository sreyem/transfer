﻿


Imports ToolBox
Imports System.ComponentModel
Imports System.Xml.Serialization
Imports System.Globalization
Imports System.IO

Public Class Form1

    Public Sub New()

        ' Dieser Aufruf ist für den Designer erforderlich.
        InitializeComponent()

        ' Fügen Sie Initialisierungen nach dem InitializeComponent()-Aufruf hinzu.




        'Dim zfint As New FOCUSswBasic.frmZFINT

        ' zfint.ShowDialog()




        test.FOCUSPRZMStd.fillStd(MasterPath:="X:\AutpPRZM\project_XXX")


        'test.FOCUSPRZMStd.saveFOCUSStd2SOAP(FilePath:="FOCUSStd.bin")

        'test.FOCUSPRZMStd.loadFOCUStdFromSOAP(FilePath:="FOCUSStd.bin")


        'test.FOCUSPRZMStd.saveFOCUSStd2XML(FilePath:="X:\AutpPRZM\FOCUSStd.xml")

        'test.FOCUSPRZMStd.loadFOCUStdFromXML(FilePath:=Path.Combine(Path.GetDirectoryName(Application.ExecutablePath),
        '                                                            "FOCUSStd.xml"))


        'test.FOCUSPRZMStd.createINPFiles4Crop(PRZMCrop:=FOCUSswBasic.Step34.ePRZMCrop.Cereals_Winter,
        '                                      inclDescription:=False)
        'init()

        ' Me.test.FreunflichSorption.showClassInPGrid()




        'With testttip

        '    .AutomaticDelay = 200
        '    .AutoPopDelay = 5000
        '    .InitialDelay = 200
        '    .ToolTipIcon = ToolTipIcon.Info
        '    .ToolTipTitle = "that's the title"
        '    .UseAnimation = True
        '    .UseFading = True
        '    .SetToolTip(control:=Me, caption:="juhu")


        'End With


        Me.PropertyGrid.SelectedObject = testettt





    End Sub

    Public testttip As New ToolTip


    'Public WithEvents DT50Soil_Correction As New cTempMoistCorrDT50Soil

    Public Property TemplateTest As New cPerfectClassTemplate


    <Category("Substance Data")>
    Public Property test As New cTest()

    Public Property FreundlichSorption As New cFreundlichSorption
    Public Property PRZMSorption As New cPRZM_FreundlichSorption
    Public Property testettt As New cFOCUSPRZMStd

    Public WithEvents firstgen_frmPgrid As New ToolBox.frmPGrid
    Public WithEvents secondgen_frmPgrid As New ToolBox.frmPGrid(FileMenueItem:=False)
    Public WithEvents thirdgen_frmPgrid As New ToolBox.frmPGrid(FileMenueItem:=False)

    Public Sub init()

      

        With firstgen_frmPgrid.PGrid

            .SelectedObject = test

            .Refresh()


        End With



    End Sub

    Private Sub firstgen_frmPgrid_LoadClass2PGrid(Class2Load As Object) Handles firstgen_frmPgrid.LoadClass2PGrid

        Me.test = CType(Class2Load, cTest)



    End Sub

    Private Sub firstgen_SelectedGridItemChanged(sender As Object,
                   e As SelectedGridItemChangedEventArgs) Handles firstgen_frmPgrid.SelectedGridItemChanged

        Dim dummy As String = ""

        Try
            'If e.NewSelection.Expandable Then
            '    e.NewSelection.Expanded = Not e.NewSelection.Expanded
            'End If

            'If e.OldSelection.Expandable Then
            '    e.OldSelection.Expanded = Not e.OldSelection.Expanded
            'End If

        Catch ex As Exception

        End Try
        ' e.NewSelection.Expanded = True

        dummy = e.NewSelection.Value.ToString

        If dummy.Contains(cDegradation.Click2EditString) Then

            secondgen_frmPgrid.Text = e.NewSelection.Parent.Label
            secondgen_frmPgrid.PGrid.SelectedObject = test.Degradation

            secondgen_frmPgrid.ShowDialog()
            firstgen_frmPgrid.PGrid.SelectedObject = Nothing
            firstgen_frmPgrid.PGrid.SelectedObject = test

        ElseIf dummy.Contains(cPhysChemProp.Click2EditString) Then

            secondgen_frmPgrid.Text = e.NewSelection.Parent.Label
            secondgen_frmPgrid.PGrid.SelectedObject = test.PhysChemProp

            secondgen_frmPgrid.ShowDialog()
            firstgen_frmPgrid.PGrid.SelectedObject = Nothing
            firstgen_frmPgrid.PGrid.SelectedObject = test

        ElseIf dummy.Contains(cTDS.Click2EditString) Then

            secondgen_frmPgrid.Text = e.NewSelection.Parent.Label
            secondgen_frmPgrid.PGrid.SelectedObject = test.TDS

            secondgen_frmPgrid.ShowDialog()
            firstgen_frmPgrid.PGrid.SelectedObject = Nothing
            firstgen_frmPgrid.PGrid.SelectedObject = test


        ElseIf dummy.Contains(cFreundlichSorption.Click2EditString) Then


            secondgen_frmPgrid.Text = e.NewSelection.Parent.Label
            secondgen_frmPgrid.PGrid.SelectedObject = test.FreundlichSorption

            secondgen_frmPgrid.ShowDialog()
            firstgen_frmPgrid.PGrid.SelectedObject = Nothing
            firstgen_frmPgrid.PGrid.SelectedObject = test

        End If

    End Sub

    Private Sub secondgen_SelectedGridItemChanged(sender As Object,
                      e As SelectedGridItemChangedEventArgs) Handles secondgen_frmPgrid.SelectedGridItemChanged


        Dim dummy As String = ""

        dummy = e.NewSelection.Value.ToString

        If dummy.Contains(cPRZM_FreundlichSorption.Click2EditString) Then


            thirdgen_frmPgrid.Text = e.NewSelection.Parent.Label
            thirdgen_frmPgrid.PGrid.SelectedObject = test.FreundlichSorption.PRZM_FreundlichSorption

            thirdgen_frmPgrid.ShowDialog()
            secondgen_frmPgrid.PGrid.SelectedObject = Nothing
            secondgen_frmPgrid.PGrid.SelectedObject = test.FreundlichSorption

        ElseIf dummy.Contains(cTempMoistCorrDT50Soil.Click2EditString) Then

            secondgen_frmPgrid.Text = e.NewSelection.Parent.Label
            secondgen_frmPgrid.PGrid.SelectedObject = test.Degradation.TempMoistCorrDT50Soil

            secondgen_frmPgrid.ShowDialog()
            firstgen_frmPgrid.PGrid.SelectedObject = Nothing
            firstgen_frmPgrid.PGrid.SelectedObject = test.Degradation

        End If

    End Sub

    Private Sub PropertyGrid_SelectedGridItemChanged(sender As Object, e As SelectedGridItemChangedEventArgs) Handles PropertyGrid.SelectedGridItemChanged

        testttip.Show("dfgdfg", Me.PropertyGrid)

    End Sub
End Class

<TypeConverter(GetType(cTest.PGridConverter))>
<Category("Substance Data")>
Public Class cTest


    Public Sub New()

    End Sub



#Region "PGrid Stuff"

    '<XmlIgnore>
    '<Browsable(False)>
    'Private WithEvents myPGrid As New PropertyGrid

    '<XmlIgnore>
    '<Browsable(False)>
    'Private PGridForm As New Form
    '<XmlIgnore>
    '<Browsable(False)>
    'Private PGridSub As New PropertyGrid

    '<XmlIgnore>
    '<Browsable(False)>
    'Private WithEvents ExitButton As New ToolStripButton(text:="&Exit")

    'Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
    '    PGridForm.Close()
    'End Sub

    'Private Sub PGrid_SelectedGridItemChanged(
    '                            sender As Object,
    '                                 e As SelectedGridItemChangedEventArgs) _
    '                                     Handles myPGrid.SelectedGridItemChanged


    '    Dim dummy As String = ""
    '    Dim frmPgrid As New ToolBox.frmPGrid

    '    dummy = e.NewSelection.Value.ToString


    '    If dummy.Contains(cTempMoistCorrDT50Soil.Click2EditString) Then

    '        frmPgrid.Text = e.NewSelection.Parent.Label
    '        frmPgrid.PGrid.SelectedObject = Me.TempMoistCorrDT50Soil

    '        frmPgrid.ShowDialog()


    '    ElseIf dummy.Contains(cPhysChemProp.Click2EditString) Then

    '        frmPgrid.Text = e.NewSelection.Parent.Label
    '        frmPgrid.PGrid.SelectedObject = Me.PhysChemProp

    '        frmPgrid.ShowDialog()

    '    ElseIf dummy.Contains(cTDS.Click2EditString) Then

    '        frmPgrid.Text = e.NewSelection.Parent.Label
    '        frmPgrid.PGrid.SelectedObject = Me.TDS

    '        frmPgrid.ShowDialog()


    '    End If


    '    myPGrid.Refresh()

    'End Sub



    'Public Function getPGridToolStrip(PGrid As PropertyGrid) As ToolStrip


    '    Dim ToolStrip As New ToolStrip

    '    For Each Control As Control In PGrid.Controls

    '        ToolStrip = TryCast(Control, ToolStrip)

    '        If ToolStrip IsNot Nothing Then Return ToolStrip

    '    Next

    '    Return Nothing

    'End Function

    'Public Sub clearPGridToolstrip(ToolStrip As ToolStrip)

    '    ToolStrip.Items.Clear()


    'End Sub


    ''' <summary>
    ''' makes the class browsable for property grid
    ''' PGridItemName = name to display
    ''' </summary>
    Public Class PGridConverter

        Inherits ExpandableObjectConverter

        <RefreshProperties(RefreshProperties.All)>
        Public Shared Property PGridItemName As String = "Moisture and Temperature correction"
        Public Shared Property ClassType As Type


#Region "Overloads Overrides"

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                         ByVal destinationType As Type) As Boolean

            Try
                If (destinationType Is GetType(cTest)) Then
                    Return True
                End If
            Catch ex As Exception

            End Try

            Return MyBase.CanConvertTo(context,
                                       destinationType)

        End Function

        Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

            If (destinationType Is GetType(System.String)) Then

                If value.GetType Is ClassType Then
                    Return PGridItemName
                End If

            End If

            Return MyBase.ConvertTo(context,
                                    culture,
                                    value,
                                    destinationType)

        End Function

#End Region

    End Class

#End Region

    'Public Property teda As String = "sdfsdf"



    <Browsable(False)>
   <DisplayName("Temp. and Moisture Correction")>
   <RefreshProperties(RefreshProperties.All)>
    Public Property TempMoistCorrDT50Soil As New cTempMoistCorrDT50Soil


    <DisplayName("Temp. and Moist. Correction")>
    <RefreshProperties(RefreshProperties.All)>
    Public ReadOnly Property TempMoistCorrDT50SoilSummary As String()
        Get
            Return TempMoistCorrDT50Soil.Summary
        End Get
    End Property


    <Browsable(True)>
    Public Property PhysChemProp As New cPhysChemProp

    <DisplayName("Phys-Chem Properties")>
    <RefreshProperties(RefreshProperties.All)>
    Public ReadOnly Property PhysChemPropSummary As String()
        Get
            Return PhysChemProp.Summary
        End Get
    End Property

    <Browsable(False)>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName("Time Dependent Sorption")>
    Public Property TDS As New cTDS


    <DisplayName("Time dependent sorption")>
    <RefreshProperties(RefreshProperties.All)>
    Public ReadOnly Property TDSSummary As String()
        Get
            Return TDS.Summary
        End Get
    End Property



    <DisplayName("Freundlich Sorption")>
    <RefreshProperties(RefreshProperties.All)>
    Public ReadOnly Property FreundlichSorptionSummary As String()
        Get
            Return FreundlichSorption.Summary
        End Get
    End Property

    <Browsable(False)>
    <DisplayName("Soil Degradation")>
    <RefreshProperties(RefreshProperties.All)>
    Public ReadOnly Property DegradationSummary As String()
        Get
            Return Degradation.Summary
        End Get
    End Property


    <DisplayName("Degradation")>
   <RefreshProperties(RefreshProperties.All)>
   <Browsable(False)>
    Public Property Degradation As New cDegradation


    <DisplayName("Overview")>
    <Description("dfdfg")>
    <Browsable(True)>
    Public ReadOnly Property Suma As cSummary
        Get

            Dim out As New cSummary

            out.Overview = Me.Degradation.Summary
            cSummary.PGridConverter.PGridItemName = Join(Me.Degradation.Summary, vbCrLf)

            Return out

        End Get
    End Property


    <DisplayName("FOCUSPRZMStd")>
    <Browsable(False)>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore>
    Public Property FOCUSPRZMStd As New cFOCUSPRZMStd

    <DisplayName("fs3appln")>
    <Browsable(False)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property fs3appln As New cPRZMApplns

    <DisplayName("sorption")>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(False)>
    Public Property FreundlichSorption As New cFreundlichSorption





    <DisplayName("Input Complete ?")>
    <[ReadOnly](True)>
    Public ReadOnly Property InputComplete As Boolean
        Get
            If _
                    Me.Degradation.TempMoistCorrDT50Soil.InputComplete AndAlso
                    Me.PhysChemProp.InputComplete AndAlso
                    Me.TDS.InputComplete Then

                Return True
            Else
                Return False

            End If

        End Get
    End Property

End Class






