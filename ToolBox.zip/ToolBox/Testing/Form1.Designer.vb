﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.PropertyGrid = New System.Windows.Forms.PropertyGrid()
        Me.cms = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.MaskedTextBox1 = New System.Windows.Forms.MaskedTextBox()
        Me.CheckedListBox1 = New System.Windows.Forms.CheckedListBox()
        Me.SuspendLayout()
        '
        'PropertyGrid
        '
        Me.PropertyGrid.ContextMenuStrip = Me.cms
        Me.PropertyGrid.Location = New System.Drawing.Point(55, 235)
        Me.PropertyGrid.Name = "PropertyGrid"
        Me.PropertyGrid.Size = New System.Drawing.Size(659, 324)
        Me.PropertyGrid.TabIndex = 0
        '
        'cms
        '
        Me.cms.Name = "cms"
        Me.cms.Size = New System.Drawing.Size(61, 4)
        Me.cms.Text = "dfgdfgdfg"
        '
        'MaskedTextBox1
        '
        Me.MaskedTextBox1.Location = New System.Drawing.Point(138, 105)
        Me.MaskedTextBox1.Mask = "a x aa.aaa kg/h\a, aa d interv\al"
        Me.MaskedTextBox1.Name = "MaskedTextBox1"
        Me.MaskedTextBox1.Size = New System.Drawing.Size(345, 20)
        Me.MaskedTextBox1.TabIndex = 1
        '
        'CheckedListBox1
        '
        Me.CheckedListBox1.FormattingEnabled = True
        Me.CheckedListBox1.Items.AddRange(New Object() {"dfgdfg", "dfgdfg", "dfwewe", "werwe"})
        Me.CheckedListBox1.Location = New System.Drawing.Point(131, 152)
        Me.CheckedListBox1.Name = "CheckedListBox1"
        Me.CheckedListBox1.Size = New System.Drawing.Size(244, 19)
        Me.CheckedListBox1.TabIndex = 2
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(788, 625)
        Me.Controls.Add(Me.CheckedListBox1)
        Me.Controls.Add(Me.MaskedTextBox1)
        Me.Controls.Add(Me.PropertyGrid)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

End Sub
    Friend WithEvents PropertyGrid As System.Windows.Forms.PropertyGrid
    Friend WithEvents cms As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents MaskedTextBox1 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents CheckedListBox1 As System.Windows.Forms.CheckedListBox

End Class
