﻿




#Region "Imports System"

Imports System.ComponentModel
Imports System.Xml.Serialization

#End Region

#Region "Imports Toolbox"

Imports ToolBox
Imports FOCUSswBasic
Imports FOCUSswBasic.Step34

#End Region


''' <summary>
''' SOIL degradation 
''' temperature and moisture correction  
''' </summary>
<Serializable>
<DescriptionAttribute("SOIL degradation temp and moist. correction")>
<DefaultProperty("ModelTempCorrOnOFF")>
<DisplayName("appln")>
<TypeConverter(GetType(cTempMoistCorrDT50Soil.PGridConverter))>
Public Class cPRZMApplns

#Region "Constructor"

    Public Sub New()

    End Sub

#End Region

#Region "PGrid Stuff"

    ''' <summary>
    ''' makes the class browsable for property grid
    ''' PGridItemName = name to display
    ''' </summary>
    Public Class PGridConverter

        Inherits ExpandableObjectConverter

        <RefreshProperties(RefreshProperties.All)>
        Public Shared Property PGridItemName As String = "FOCUS Step3 PAT"
        Public Shared Property ClassType As Type


#Region "Overloads Overrides"

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                         ByVal destinationType As Type) As Boolean

            Try
                If (destinationType Is GetType(cTempMoistCorrDT50Soil)) Then
                    Return True
                End If
            Catch ex As Exception

            End Try

            Return MyBase.CanConvertTo(context,
                                       destinationType)

        End Function

        Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

            If (destinationType Is GetType(System.String)) Then

                If value.GetType Is ClassType Then
                    Return PGridItemName
                End If

            End If

            Return MyBase.ConvertTo(context,
                                    culture,
                                    value,
                                    destinationType)

        End Function

#End Region

    End Class

#End Region


#Region "Categories"

    Private Const CATModelTempSettings As String = "01  Temperature correction"
    Private Const CATModelMoistSettings As String = "02  Moisture correction"

    Private Const CATOutput As String = "03  Output"

#End Region





    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_Crop As ePRZMCrop = ePRZMCrop.Cereals_Winter

    ''' <summary>
    ''' Crop
    ''' </summary>
    <Category("")>
    <DisplayName("Crop")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(CInt(ePRZMCrop.Cereals_Winter))>
    Public Property Crop As ePRZMCrop
        Get
            Return m_Crop
        End Get
        Set(vCrop As ePRZMCrop)
            m_Crop = vCrop
            ApplnMethod = m_ApplnMethod
        End Set
    End Property



    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_ApplnMethod As eAppMethodStep03 = eAppMethodStep03.GroundSpray

    ''' <summary>
    ''' ApplnMethod
    ''' </summary>
    <Category("")>
    <DisplayName("ApplnMethod")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(CInt(eAppMethodStep03.GroundSpray))>
    Public Property ApplnMethod As eAppMethodStep03
        Get
            Return m_ApplnMethod
        End Get
        Set(vApplnMethod As eAppMethodStep03)

            Select Case Crop

                'Case ePRZMCrop.Vines_early_applns,
                '     ePRZMCrop.Vines_late_applns,
                '     ePRZMCrop.Pome_stone_fruit_early_applns,
                '     ePRZMCrop.Pome_stone_fruit_late_applns,
                '     ePRZMCrop.Hops, ePRZMCrop.Citrus, ePRZMCrop.Olives

                '    If vApplnMethod = eAppMethodStep03.AirBlast Then
                '        m_ApplnMethod = vApplnMethod
                '    Else
                '        m_ApplnMethod = eAppMethodStep03.AirBlast
                '    End If

            End Select


            m_ApplnMethod = vApplnMethod
        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_CAM As eCAM = eCAM.FoliarLinear_2

    ''' <summary>
    ''' CAM
    ''' </summary>
    <Category("")>
    <DisplayName("CAM")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(CInt(eCAM.FoliarLinear_2))>
    Public Property CAM As eCAM
        Get
            Return m_CAM
        End Get
        Set(vCAM As eCAM)
            m_CAM = vCAM
        End Set
    End Property



End Class
