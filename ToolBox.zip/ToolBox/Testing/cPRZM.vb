﻿







#Region "Imports System"

Imports System.ComponentModel
Imports System.Xml.Serialization

#End Region

#Region "Imports Toolbox"

Imports ToolBox

#End Region



<Serializable>
<DescriptionAttribute("PRZM")>
<DefaultProperty("PRZM")>
<DisplayName("PRZM")>
<TypeConverter(GetType(cPRZM.PGridConverter))>
Public Class cPRZM

#Region "Constructor"

    Public Sub New()

    End Sub

#End Region

#Region "PGrid Stuff"

    ''' <summary>
    ''' makes the class browsable for property grid
    ''' PGridItemName = name to display
    ''' </summary>
    Public Class PGridConverter

        Inherits ExpandableObjectConverter

        <RefreshProperties(RefreshProperties.All)>
        Public Shared Property PGridItemName As String = "PRZM"
        Public Shared Property ClassType As Type


#Region "Overloads Overrides"

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                         ByVal destinationType As Type) As Boolean

            Try
                If (destinationType Is GetType(cTempMoistCorrDT50Soil)) Then
                    Return True
                End If
            Catch ex As Exception

            End Try

            Return MyBase.CanConvertTo(context,
                                       destinationType)

        End Function

        Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

            If (destinationType Is GetType(System.String)) Then

                If value.GetType Is ClassType Then
                    Return PGridItemName
                End If

            End If

            Return MyBase.ConvertTo(context,
                                    culture,
                                    value,
                                    destinationType)

        End Function

#End Region

    End Class

#End Region


#Region "Categories"

    Private Const CATModelTempSettings As String = "01  Temperature correction"
    Private Const CATModelMoistSettings As String = "02  Moisture correction"

    Private Const CATOutput As String = "03  Output"

#End Region

#Region "std values"

    Public Const PRZM_Versionstring As String = "FOCUS_PRZM_SW_4.3.1, 27 Apr. 2015                       PRZM 4.63 Apr. 2015"

    Public Shared RECORD_03_Description As String() =
    {"   *** ---- RECORD 03 ----",
     "PRZM_INPUT",
    "*** PFAC    SFAC  IPEIND   ANETD  INICRP  ISCOND",
    "***",
    "*** PFAC   pan factor used to estimate daily evapo-transpiration, crop dependent, 0.69 < PFAC < 1",
    "*** SFAC   snow melt factor in cm/degrees Celsius above freezing FOCUS std. =0.2",
    "*** IPEIND pan factor flag 0=pan_data_read (std), 1=temperature_data_read, 2=either_available_used",
    "*** ANETD  minimum depth of which evaporation is extracted (cm)",
    "*** INICRP & ISCOND  = crop number = 1 ",
    "*** "
    }


#End Region



End Class
