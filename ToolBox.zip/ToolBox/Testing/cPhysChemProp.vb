﻿









#Region "Imports System"

Imports System.ComponentModel
Imports System.Xml.Serialization

#End Region

#Region "Imports Toolbox"

Imports ToolBox

#End Region


''' <summary>
''' Phys-Chem Data
''' Molar mass, Solubility, VP etc.
''' </summary>
<Serializable>
<DescriptionAttribute("Phys-Chem Properties")>
<DefaultProperty("MolMass")>
<DisplayName("Phys-Chem Properties")>
Public Class cPhysChemProp

    Inherits cPerfectClass


#Region "Constructor"

    Public Sub New()

        cPerfectClass.cPGridConverter.PGridItemName = {Name & vbCrLf &
                                                       Join(Summary, vbCrLf)}

        cPerfectClass.cPGridConverter.Class2ShowType = GetType(cPhysChemProp)

    End Sub

#End Region

    '#Region "PGrid Stuff"

    '    ''' <summary>
    '    ''' makes the class browsable for property grid
    '    ''' PGridItemName = name to display
    '    ''' </summary>
    '    Public Class PGridConverter

    '        Inherits ExpandableObjectConverter

    '        <RefreshProperties(RefreshProperties.All)>
    '        Public Shared Property PGridItemName As String = "PhysChem Properties"
    '        Public Shared Property ClassType As Type


    '#Region "Overloads Overrides"

    '        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
    '                                                         ByVal destinationType As Type) As Boolean

    '            Try
    '                If (destinationType Is ClassType) Then
    '                    Return True
    '                End If
    '            Catch ex As Exception

    '            End Try

    '            Return MyBase.CanConvertTo(context,
    '                                       destinationType)

    '        End Function

    '        Public Overloads Overrides Function ConvertTo(
    '                             ByVal context As ITypeDescriptorContext,
    '                             ByVal culture As Globalization.CultureInfo,
    '                             ByVal value As Object,
    '                             ByVal destinationType As System.Type) As Object

    '            If (destinationType Is GetType(System.String)) Then

    '                If value.GetType Is ClassType Then
    '                    Return PGridItemName
    '                End If

    '            End If

    '            Return MyBase.ConvertTo(context,
    '                                    culture,
    '                                    value,
    '                                    destinationType)

    '        End Function

    '#End Region

    '    End Class


    '    Public Sub showClassInPGrid()

    '        Dim dummy As String = ""
    '        Dim frmPgrid As New ToolBox.frmPGrid



    '        frmPgrid.Text = cPhysChemProp.PGridConverter.PGridItemName
    '        frmPgrid.PGrid.SelectedObject = Me

    '        frmPgrid.ShowDialog()

    '    End Sub


    '#End Region

#Region "Categories"

    Private Const CATPhysChem2Change As String = "01  Phys-Chem Data you must enter"
    Private Const CATPhysChemNOT2Change As String = "02  Phys-Chem Data you should not change"
    Private Const CATOutput As String = "03  Output"

#End Region

#Region "01  Phys-Chem Data you must enter"

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_MolMass As Double = 9999

    ''' <summary>
    ''' Molar mass in g/mol
    ''' 10 - 10000 g/mol, enter 0 for website
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <Category(CATPhysChem2Change)>
    <DisplayName("Molar mass")>
    <Description("Molar mass in g/mol" & vbCrLf &
                 "10 - 10000 g/mol, enter 0 for website")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(9999)>
    Public Property MolMass As Double
        Get
            Return m_MolMass
        End Get
        Set(vMolMass As Double)

            If vMolMass = 0 Then
                Process.Start("http://therminfo.lasige.di.fc.ul.pt/mw.php")
            Else

                If vMolMass < 10 OrElse vMolMass > 10000 Then

                    If MsgBox(Prompt:="10 g/mol > Molar mass > 10000 g/mol is strange" & vbCrLf &
                              "Your input: " & vMolMass & " g/mol seems to be wrong, continue?",
                             Buttons:=MsgBoxStyle.YesNo,
                               Title:="User Input seems to be wrong") = MsgBoxResult.No Then

                        Process.Start("http://therminfo.lasige.di.fc.ul.pt/mw.php")

                        Exit Property

                    End If

                End If

                m_MolMass = vMolMass

            End If
        End Set
    End Property


#Region "Vapor pressure"

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_VP As Double = 0.9999

    ''' <summary>
    ''' Saturated vapor pressure
    ''' in Pascal, 0 - 2.0e+05 Pa, std.  =  1.0e-03
    ''' </summary>
    <Category(CATPhysChem2Change)>
    <DisplayName("Vapor pressure")>
    <Description("Saturated vapor pressure" & vbCrLf &
                 "in Pascal, 0 - 2.0e+05 Pa, std.  = < 1.0e-03")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0.9999)>
    Public Property VP As Double
        Get
            Return m_VP
        End Get
        Set(vVP As Double)

            If vVP >= 0 AndAlso vVP <= 200000 Then

                If vVP > 0.001 Then

                    If MsgBox(Prompt:="Vapor pressure > 1.0e-03 is strange, continue?",
                          Buttons:=MsgBoxStyle.OkCancel,
                            Title:="User Input seems to be wrong") = MsgBoxResult.Cancel Then
                        Exit Property

                    End If
                End If

                m_VP = vVP

                RaiseEvent DataChange()
            Else
                MsgBox("Saturated vapor pressure" & vbCrLf &
                       "in Pascal, 0 - 2.0e+05 Pa, std.  = < 1.0e-03" & vbCrLf &
                       "Your input is not valid : " & vVP,
                       MsgBoxStyle.Exclamation)
            End If

        End Set
    End Property



    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_VPRefTemp As Double = 20

    ''' <summary>
    ''' VP ref. temp.
    ''' in °C, 0 - 20°C, std. = 20°C
    ''' </summary>
    <Category(CATPhysChem2Change)>
    <DisplayName("   ref. temp.")>
    <Description("Temperature at which saturated vapor pressure is measured" & vbCrLf &
                 "in °C, 0 - 40°C, std. = 20°C")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(20)>
    Public Property VPRefTemp As Double
        Get
            Return m_VPRefTemp
        End Get
        Set(vVPRefTemp As Double)

            If vVPRefTemp >= 0 AndAlso vVPRefTemp <= 40 Then
                m_VPRefTemp = vVPRefTemp
                RaiseEvent DataChange()
            Else
                MsgBox("Temperature at which saturated vapor pressure is measured" & vbCrLf &
                       "in °C, 0 - 40°C, std. = 20°C" & vbCrLf &
                       "Your input is not valid : " & vVPRefTemp,
                       MsgBoxStyle.Exclamation)
            End If
        End Set
    End Property


    Public Enum eEVAClassification

        non_volatile
        semi_low
        semi_medium
        volatile

    End Enum

    <XmlIgnore>
    <Browsable(False)>
    Public Shared Property VPClassificationDB As String() =
     {"non volatile =           VP <  1.0e-5",
      "semi low     = 1.0e-5 <= VP <  1.0e-4",
      "semi medium  = 1.0e-4 <  VP <  5.0e-3",
      "volatile     =           VP >= 5.0e-3"}


    ''' <summary>
    ''' EVA vapor pressure classification
    ''' on volatile, semi volatile low/medium(std) or volatile
    ''' </summary>
    <Category(CATPhysChem2Change)>
    <DisplayName("EVA VP Class")>
    <Description("EVA vapor pressure classification" & vbCrLf &
                 "non volatile, semi volatile low/medium(std) or volatile")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public ReadOnly Property EVA_VPClassification As String
        Get

            If Double.IsNaN(m_VP) Then Return "not_defined"

            Select Case m_VP

                Case Is < 0.00001
                    Return Replace(VPClassificationDB(eEVAClassification.non_volatile).ToString, "  ", "")

                Case Is <= 0.0001
                    Return Replace(VPClassificationDB(eEVAClassification.semi_low).ToString, "  ", "")

                Case Is < 0.005
                    Return Replace(VPClassificationDB(eEVAClassification.semi_medium).ToString, "  ", "")

                Case Else
                    Return Replace(VPClassificationDB(eEVAClassification.volatile).ToString, "  ", "")


                    'non volatile =           VP <  1.0e-5
                    'semi low     = 1.0e-5 <= VP <  1.0e-4
                    'semi medium  = 1.0e-4 <  VP <  5.0e-3
                    'volatile     =           VP >= 5.0e-3

            End Select
        End Get
    End Property

#End Region


#Region "Solubility"

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_Solubility As Double = 9999

    ''' <summary>
    ''' Solubility in Water
    ''' in mg/L; 0.001 = Solubility = 1.0e6
    ''' attention : mg/L, not g/L !!, std. >> 100 mg/L
    ''' </summary>
    <Category(CATPhysChem2Change)>
    <DisplayName("Solubility in Water")>
    <Description("in mg/L; 0.001 < Solubility < 1.0e6" & vbCrLf &
                 "attention : mg/L, not g/L !!, std. >> 100 mg/L")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(9999)>
    Public Property Solubility As Double
        Get
            Return m_Solubility
        End Get
        Set(vSolubility As Double)

            If vSolubility >= 0.001 AndAlso vSolubility <= 1000000.0 Then

                If vSolubility < 100 Then

                    If MsgBox(Prompt:="Solubility in Water in mg/L" & vbCrLf &
                              vSolubility & " mg/L seems to be to low, continue?",
                            Buttons:=MsgBoxStyle.YesNo,
                              Title:="User Input seems to be wrong") = MsgBoxResult.No Then
                        Exit Property

                    End If

                End If

                m_Solubility = vSolubility
                RaiseEvent DataChange()

            Else
                MsgBox("Solubility in Water in mg/L" & vbCrLf &
                       "0.001 < Solubility < 1.0e6" & vbCrLf &
                       "Your input is not valid : " & vSolubility,
                       MsgBoxStyle.Exclamation)
            End If

        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_SolRefTemp As Double = 20

    ''' <summary>
    ''' Solubility ref. temp.
    ''' in °C, 0 - 20°C, std. = 20°C
    ''' </summary>
    <Category(CATPhysChem2Change)>
    <DisplayName("   ref. temp.")>
    <Description("Temperature at which solubility in water is measured" & vbCrLf &
                 "in °C, 0 - 40°C, std. = 20°C")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(20)>
    Public Property SolRefTemp As Double
        Get
            Return m_SolRefTemp
        End Get
        Set(vSolRefTemp As Double)


            If vSolRefTemp >= 0 AndAlso vSolRefTemp <= 40 Then
                m_SolRefTemp = vSolRefTemp
                RaiseEvent DataChange()
            Else
                MsgBox("Temperature at which solubility in water is measured" & vbCrLf &
                       "in °C, 0 - 40°C, std. = 20°C" & vbCrLf &
                       "Your input is not valid : " & vSolRefTemp,
                       MsgBoxStyle.Exclamation)
            End If

        End Set
    End Property


#End Region

#End Region

#Region "02  Phys-Chem Data you should not change"

#Region "PRZM"

    ''' <summary>
    ''' Henry's law constant of the pesticide in Pa*m^3/J
    ''' (VP * MolMass / Sol.) / (R = 8.3143 J/(mol*K) * Tref in K)
    ''' </summary>
    <Category(CATPhysChem2Change)>
    <DisplayName("Henry's Law Constant")>
    <Description("Henry's law constant in Pa*m^3/J for PRZM Record 26" & vbCrLf &
                 "(VP * MolMass / Sol.) / (R = 8.3143 J/(mol*K) * Tref in K)")>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore>
    Public ReadOnly Property HENRYK As String
        Get

            Try
                Return ((VP * MolMass / Solubility) / _
                (8.3143 * (m_VPRefTemp + 273.15))).ToString(".00E+00")
            Catch ex As Exception
                Return ex.Message
            End Try

        End Get
    End Property


#End Region


    Public Function stdValues_Unchanged() As Boolean

        If m_MolEntVap = 95 AndAlso
            m_MolEntSlb = 27 AndAlso
            m_CofDiffWatRef = 0.000043 AndAlso
            m_CofDiffAirRef = 0.43 AndAlso
            m_TemRefDif = 20 Then

            Return True
        Else
            Return False

        End If

    End Function


#Region "Molar Enthalpy"

    <Category(CATPhysChemNOT2Change)>
    <DisplayName("Molar Enthalpy")>
    <XmlIgnore>
    Public Property MolarEnthalpyHeader As String = "   DO NOT TOUCH   "

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_MolEntVap As Double = 95

    ''' <summary>
    ''' Molar Enthalpy of Vaporisation
    ''' in kJ/mol, DO NOT TOUCH !
    ''' -200 - 200 kJ/mol, std. = 95 kJ/mol
    ''' </summary>
    <Category(CATPhysChemNOT2Change)>
    <DisplayName("   of Vaporisation (PEARL)")>
    <Description("in kJ/mol" & vbCrLf &
                 "-200 - 200 kJ/mol, std. = 95 kJ/mol")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(95)>
    Public Property MolEntVap As Double
        Get
            Return m_MolEntVap
        End Get
        Set(vMolEntVap As Double)


            If vMolEntVap >= -200 AndAlso vMolEntVap <= 200 Then

                If MsgBox(Prompt:="Do you really want to change this parameter?",
                         Buttons:=MsgBoxStyle.YesNo,
                           Title:="Warning: Do not touch this parameter if you're not 100% sure!!!") =
                       MsgBoxResult.No Then

                    Exit Property

                End If


                m_MolEntVap = vMolEntVap
                RaiseEvent DataChange()
            Else
                MsgBox("Molar enthalpy of vaporisation" & vbCrLf &
                       "in kJ/mol, DO NOT TOUCH !" & vbCrLf &
                       "-200 - 200 kJ/mol, std. = 95 kJ/mol" & vbCrLf &
                       "Your input is not valid : " & vMolEntVap,
                       MsgBoxStyle.Exclamation)
            End If

        End Set
    End Property


    ''' <summary>
    ''' Molar Enthalpy of Vaporisation for PRZM
    ''' in kcal/mol, DO NOT TOUCH !
    ''' std. = 22.7 kcal/mol ; 1 kcal = 4.185 kJ
    ''' </summary>
    <Category(CATPhysChemNOT2Change)>
    <DisplayName("   of Vaporisation (PRZM)")>
    <Description("in kcal/mol, Record 26" & vbCrLf &
                 "1 kcal = 4.185 kJ, std. = 22.7 kcal/mol")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(22.7)>
    Public ReadOnly Property ENPY As Double
        Get
            Return Math.Round(MolEntVap / 4.185, 2)
        End Get
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_MolEntSlb As Double = 27

    ''' <summary>
    ''' Molar Enthalpy of Dissolution
    ''' in kJ/mol, DO NOT TOUCH !
    ''' -200 - 200 kJ/mol, std. = 27 kJ/mol
    ''' </summary>
    <Category(CATPhysChemNOT2Change)>
    <DisplayName("   of Dissolution")>
    <Description("in kJ/mol" & vbCrLf &
                 "-200 - 200 kJ/mol, std. = 27 kJ/mol")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(27)>
    Public Property MolEntSlb As Double
        Get
            Return m_MolEntSlb
        End Get
        Set(vMolEntSlb As Double)


            If vMolEntSlb >= -200 AndAlso vMolEntSlb <= 200 Then

                If MsgBox(Prompt:="Do you really want to change this parameter?",
                         Buttons:=MsgBoxStyle.YesNo,
                           Title:="Warning: Do not touch this parameter if you 're not 100% sure!!!") =
                       MsgBoxResult.No Then

                    Exit Property

                End If


                m_MolEntSlb = vMolEntSlb
                RaiseEvent DataChange()
            Else
                MsgBox("Molar enthalpy of dissolution" & vbCrLf &
                       "in kJ/mol, DO NOT TOUCH !" & vbCrLf &
                       "-200 - 200 kJ/mol, std. = 27 kJ/mol" & vbCrLf &
                       "Your input is not valid : " & vMolEntSlb,
                       MsgBoxStyle.Exclamation)
            End If

        End Set
    End Property


#End Region

#Region "Diffusion Coefficient"

    <XmlIgnore>
    <Category(CATPhysChemNOT2Change)>
    <DisplayName("Diffusion Coefficient")>
    Public Property DiffusionCoefficientHeader As String = "   DO NOT TOUCH   "


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_CofDiffWatRef As Double = 0.000043

    ''' <summary>
    ''' Reference diffusion coefficient in water
    ''' in m2/d, DO NOT TOUCH !
    ''' 0 - 0.002 m2/d, std. = 4.3e-5 m2/d
    ''' </summary>
    <Category(CATPhysChemNOT2Change)>
    <DisplayName("   in Water")>
    <Description("Diffusion Coefficient in m2/d, DO NOT TOUCH !" & vbCrLf &
                 "0 - 0.002 m2/d, std. = 4.3e-5 m2/d")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0.000043)>
    Public Property CofDiffWatRef As Double
        Get
            Return m_CofDiffWatRef
        End Get
        Set(vCofDiffWatRef As Double)


            If vCofDiffWatRef >= 0 AndAlso vCofDiffWatRef <= 0.002 Then

                If MsgBox(Prompt:="Do you really want to change this parameter?",
                         Buttons:=MsgBoxStyle.YesNo,
                           Title:="Warning: Do not touch this parameter if you're not 100% sure!!!") =
                       MsgBoxResult.No Then

                    Exit Property

                End If


                m_CofDiffWatRef = vCofDiffWatRef
                RaiseEvent DataChange()
            Else
                MsgBox("Reference diffusion coefficient in water" & vbCrLf &
                       "in m2/d, DO NOT TOUCH !" & vbCrLf &
                       "0 - 0.002 m2/d, std. = 4.3e-5 m2/d" & vbCrLf &
                       "Your input is not valid : " & vCofDiffWatRef,
                       MsgBoxStyle.Exclamation)
            End If

        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_CofDiffAirRef As Double = 0.43

    ''' <summary>
    ''' Reference diffusion coefficient in air
    ''' in m2/d, DO NOT TOUCH !
    ''' 0.1 - 3 m2/d, std. = 0.43 m2/d
    ''' </summary>
    <Category(CATPhysChemNOT2Change)>
    <DisplayName("   in Air (PEARL)")>
    <Description("Diffusion Coefficient in air in m2/d" & vbCrLf &
                 "0.1 - 3 m2/d, std. = 0.43 m2/d")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0.43)>
    Public Property CofDiffAirRef As Double
        Get
            Return m_CofDiffAirRef
        End Get
        Set(vCofDiffAirRef As Double)


            If vCofDiffAirRef >= 0.1 AndAlso vCofDiffAirRef <= 3 Then

                If MsgBox(Prompt:="Do you really want to change this parameter?",
                         Buttons:=MsgBoxStyle.YesNo,
                           Title:="Warning: Do not touch this parameter if you're not 100% sure!!!") =
                       MsgBoxResult.No Then

                    Exit Property

                End If


                m_CofDiffAirRef = vCofDiffAirRef
                RaiseEvent DataChange()
            Else
                MsgBox("Reference diffusion coefficient in air" & vbCrLf &
                       "in m2/d, DO NOT TOUCH !" & vbCrLf &
                       "0.1 - 3 m2/d, std. = 0.43 m2/d" & vbCrLf &
                       "Your input is not valid : " & vCofDiffAirRef,
                       MsgBoxStyle.Exclamation)
            End If

        End Set
    End Property



    ''' <summary>
    ''' Diffusion coefficient in air for PRZM
    ''' in cm2/d, DO NOT TOUCH !
    ''' std. = 4300 cm2/d ; 1m2  =10000 cm2
    ''' </summary>
    <Category(CATPhysChemNOT2Change)>
    <DisplayName("   in Air (PRZM)")>
    <Description("Diffusion Coefficient in air in cm2/d PRZM Record 26" & vbCrLf &
                 "1000 - 30000 cm2/d, std. = 4300 cm2/d")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(4300)>
    Public ReadOnly Property DAIR As Double
        Get
            Return CofDiffAirRef * 10000
        End Get
    End Property




    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_TemRefDif As Double = 20

    ''' <summary>
    ''' Diff. coeff  ref. temp.
    ''' in °C, 10 - 30°C, std. = 20°C
    ''' </summary>
    <Category(CATPhysChemNOT2Change)>
    <DisplayName("   ref. temp.")>
    <Description("Diff. coeff measured at temperature [10|30]" & vbCrLf &
                 "in °C, 10 - 30°C, std. = 20°C")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(20)>
    Public Property TemRefDif As Double
        Get
            Return m_VPRefTemp
        End Get
        Set(vTemRefDif As Double)

            If vTemRefDif >= 10 AndAlso vTemRefDif <= 30 Then
                m_VPRefTemp = vTemRefDif
                RaiseEvent DataChange()
            Else
                MsgBox("Temperature at which diff. coeff is measured" & vbCrLf &
                       "in °C, 10 - 30°C, std. = 20°C" & vbCrLf &
                       "Your input is not valid : " & vTemRefDif,
                       MsgBoxStyle.Exclamation)
            End If
        End Set
    End Property



#End Region

#End Region

#Region "03  Output"

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_inclDescription As Boolean = True

    ''' <summary>
    ''' Model parameter incl. description
    ''' </summary>
    <Category(CATOutput)>
    <DisplayName("incl Description")>
    <Description("Model parameter incl. description" & vbCrLf &
                 "std. = true ;-)")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(True)>
    <XmlIgnore>
    Public Property inclDescription As Boolean
        Get
            Return m_inclDescription
        End Get
        Set(vinclDescription As Boolean)
            m_inclDescription = vinclDescription
        End Set
    End Property

#Region "Summary"


    <Category(CATPhysChem2Change)>
    <Browsable(False)>
    Public Shadows ReadOnly Property Summary As String()
        Get

            cPhysChemProp.cPGridConverter.PGridItemName = getPhysChemSummary()

            Return getPhysChemSummary()
        End Get
    End Property


    Public Const Click2EditString As String = "phys-chem data"

    Public Function getPhysChemSummary() As String()

        Dim Summary As New List(Of String)
        Const PadLenght As Integer = 14
        Const PadLenghtUnit As Integer = 8

        With Summary


            .Add("Molar mass        : " & m_MolMass.ToString.PadRight(PadLenghtUnit) & " g/mol")
            .Add("Vapor pressure    : " & (m_VP.ToString("0.0E+00").PadRight(PadLenghtUnit) & " Pa").PadRight(PadLenght) & " at " & m_VPRefTemp & "°C" &
                                      (IIf(m_VPRefTemp = 20, "", " indiv. value!")).ToString & " (" & Me.EVA_VPClassification.ToString & ")")
            .Add("Solubility        : " & (m_Solubility.ToString("0.0").PadRight(PadLenghtUnit) & " mg/L").PadRight(PadLenght) & " at " & m_SolRefTemp & "°C" &
                                      (IIf(m_SolRefTemp = 20, "", " indiv. value!")).ToString)

            .Add("Henrys Law const. : 0" & HENRYK.ToString.PadRight(PadLenghtUnit - 1) & " Pa*m^3/J")

            If m_MolEntVap <> 95 OrElse
                m_MolEntSlb <> 27 OrElse
                m_CofDiffWatRef <> 0.000043 OrElse
                m_CofDiffAirRef <> 0.43 Then

                .Add("******************************************")
                .Add("WARNING : Change of std. Parameter values!")

                If m_MolEntVap <> 95 Then
                    .Add("Molar Enthalpy of Vaporisation           : " & m_MolEntVap & " kJ/mol (std. = 95 kJ/mol!!!!)")
                End If
                If m_MolEntSlb <> 27 Then
                    .Add("Molar Enthalpy of Dissolution            : " & m_MolEntSlb & " kJ/mol (std. = 27 kJ/mol!!!!)")
                End If
                If m_CofDiffWatRef <> 0.000043 Then
                    .Add("Reference diffusion coefficient in water : " & m_CofDiffWatRef & " m2/d (std. = 0.000043 m2/d!!!!)")
                End If
                If m_CofDiffAirRef <> 0.43 Then
                    .Add("Reference diffusion coefficient in air   : " & m_CofDiffAirRef & " m2/d (std. = 0.43 m2/d!!!!)")
                End If


            End If

        End With

        Return Summary.ToArray

    End Function

#End Region

#Region "Model Parameter File"

#Region "PEARL"


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_SubstanceCode As String = "IOP"

    ''' <summary>
    ''' Substance Code
    ''' Max. 5 letters, do not start with a number
    ''' no special chars like _ or ; Do not : 124_T but T124
    ''' </summary>
    <Category(CATOutput)>
    <DisplayName("Substance Code")>
    <Description("Max. 5 letters, do not start with a number" & vbCrLf &
                 "no special chars like _ or ; Do not : 124_T but T124")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue("IOP")>
    Public Property SubstanceCode As String
        Get
            Return m_SubstanceCode
        End Get
        Set(vSubstanceCode As String)

            If vSubstanceCode.Length > 5 Then Exit Property

            'check if 1st char is a number
            For CharCounter As Integer = 0 To vSubstanceCode.Length - 1
                If Asc(vSubstanceCode(CharCounter)) >= 48 AndAlso
                    Asc(vSubstanceCode(CharCounter)) <= 57 AndAlso
                    CharCounter = 0 Then
                    vSubstanceCode = "Error"
                End If

                'only A - Z and a - z
                If Not Asc(vSubstanceCode(CharCounter)) >= 65 AndAlso
                   Not Asc(vSubstanceCode(CharCounter)) <= 90 OrElse
                   Not Asc(vSubstanceCode(CharCounter)) >= 97 AndAlso
                   Not Asc(vSubstanceCode(CharCounter)) <= 122 Then

                    vSubstanceCode = "Error"

                End If


            Next

            m_SubstanceCode = vSubstanceCode

        End Set
    End Property




    ''' <summary>
    ''' PEARL Basic PhysChem Parameters
    ''' </summary>
    <Category(CATOutput)>
    <DisplayName("PEARL, Basic Parameters")>
    <Browsable(True)>
    Public ReadOnly Property PEARL_PhysChemBasic As String()
        Get
            Return getPEARL_PhysChemBasic(
                        SubstanceCode:=Me.SubstanceCode,
                        inclDescription:=Me.inclDescription)
        End Get
    End Property

    Public Function getPEARL_PhysChemBasic(
                   Optional SubstanceCode As String = "IOP",
                   Optional PadValue As Integer = 20,
                   Optional PadUnit As Integer = 25,
                   Optional inclDescription As Boolean = True) As String()

        Dim PEARL As New List(Of String)

        With PEARL

            .Add("* Basic Parameters for compound " & SubstanceCode)

            .Add(Me.MolMass.ToString.PadRight(PadValue) &
                 ("MolMas_" & SubstanceCode).PadRight(PadUnit) &
                 "(g.mol-1)".PadRight(10) &
                 IIf(inclDescription, " Molar mass [10|10000]", "").ToString)

            .Add(Me.VP.ToString.PadRight(PadValue) &
                 ("PreVapRef_" & SubstanceCode).PadRight(PadUnit) &
                 "(Pa)".PadRight(10) &
                 IIf(inclDescription, " Saturated vapour pressure [0|2e5]", "").ToString)

            .Add(Me.TemRefDif.ToString.PadRight(PadValue) &
                 ("TemRefVap_" & SubstanceCode).PadRight(PadUnit) &
                 "(C)".PadRight(10) &
                 IIf(inclDescription, " .. measured at [0|40]", "").ToString)

            .Add(Me.Solubility.ToString.PadRight(PadValue) &
                ("SlbWatRef_" & SubstanceCode).PadRight(PadUnit) &
                "(mg.L-1)".PadRight(10) &
                IIf(inclDescription, " Solubility in water [1e-9|1e6]", "").ToString)

            .Add(Me.TemRefDif.ToString.PadRight(PadValue) &
                 ("TemRefSlb_" & SubstanceCode).PadRight(PadUnit) &
                 "(C)".PadRight(10) &
                 IIf(inclDescription, " .. measured at [0|40]", "").ToString)

        End With


        Return PEARL.ToArray

    End Function


    ''' <summary>
    ''' PEARL Std PhysChem Parameters
    ''' </summary>
    <Category(CATOutput)>
    <DisplayName("PEARL, Std. Parameters")>
    <Browsable(True)>
    Public ReadOnly Property PEARL_PhysChemStd As String()
        Get
            Return getPEARL_PhysChemStd(
                SubstanceCode:=Me.SubstanceCode,
                inclDescription:=Me.inclDescription)
        End Get
    End Property

    Public Function getPEARL_PhysChemStd(
                   Optional SubstanceCode As String = "IOP",
                   Optional PadValue As Integer = 20,
                   Optional PadUnit As Integer = 25,
                   Optional inclDescription As Boolean = True) As String()

        Dim PEARL As New List(Of String)

        With PEARL

            .Add("* Std. Parameters for compound " & SubstanceCode)

            'Molar Enthalpy
            .Add(Me.MolEntVap.ToString.PadRight(PadValue) &
                 ("MolEntVap_" & SubstanceCode).PadRight(PadUnit) &
                 "(kJ.mol-1)".PadRight(10) &
                 IIf(inclDescription, " Molar enthalpy of vaporisation [-200|200], std. = 95 kJ.mol-1", "").ToString)

            .Add(Me.MolEntSlb.ToString.PadRight(PadValue) &
                 ("MolEntSlb_" & SubstanceCode).PadRight(PadUnit) &
                 "(kJ.mol-1)".PadRight(10) &
                 IIf(inclDescription, " ...            of dissolution  [-200|200], std. = 27 kJ.mol-1", "").ToString)

            'Diffusion Coefficient
            .Add(Me.CofDiffWatRef.ToString.PadRight(PadValue) &
                 ("CofDiffWatRefp_" & SubstanceCode).PadRight(PadUnit) &
                 "(m2.d-1)".PadRight(10) &
                 IIf(inclDescription, " Reference diff. coeff. in water [10e-5|3e-4], std. = 4.3e-5 m2.d-1", "").ToString)

            .Add(Me.CofDiffAirRef.ToString.PadRight(PadValue) &
                ("CofDifAirRef_" & SubstanceCode).PadRight(PadUnit) &
                "(m2.d-1)".PadRight(10) &
                IIf(inclDescription, " ...                    in air [0.1|3], std. = 0.43 m2.d-1", "").ToString)

            .Add(Me.TemRefDif.ToString.PadRight(PadValue) &
                ("TemRefDif_" & SubstanceCode).PadRight(PadUnit) &
                "(C)".PadRight(10) &
                IIf(inclDescription, " Reference diff. coeff. measured at [10|30], std. = 20 C", "").ToString)


        End With


        Return PEARL.ToArray

    End Function

#End Region

#Region "PRZM"

    <Category(CATOutput)>
    <DisplayName("PRZM , --- RECORD 26 ----")>
    <Browsable(True)>
    Public ReadOnly Property RECORD26 As String()
        Get

            Return createRECORD26(ParMetParameter:=
                                        {Me.DAIR.ToString + "," +
                                         Me.HENRYK + "," +
                                         Me.ENPY.ToString},
                                  inclDescription:=Me.inclDescription)



        End Get
    End Property

    ''' <summary>
    ''' creates RECORD26
    ''' </summary>
    ''' <param name="ParMetParameter">
    ''' createRECORD26({Par.DAIR.ToString + "," + Par.HENRYK + "," + Par.ENPY.ToString,
    '''                 Met.DAIR.ToString + "," + Met.HENRYK + "," + Met.ENPY.ToString
    ''' </param>
    ''' <returns>RECORD26</returns>
    Public Function createRECORD26(ParMetParameter As String(),
                                   Optional inclDescription As Boolean = True) As String()


        Dim Header As String() =
            {
        "*** --- RECORD 26 ----",
        "*** 01 DAIR    Parent diffusion coefficient for the pesticide(s) in the air std. = 4300 cm°2 day-1).",
        "*** 02 HENRYK  Parent Henry's law constant of the pesticide(s)",
        "*** 03 ENPY    Parent enthalpy of vaporization of the pesticide(s) std. = 22.7 kcal/mole",
        "*** Repeat for each compound: Par_DAIR Met_DAIR Par_HENRY Met_HENRY etc."
            }

        Dim temp As New List(Of String)
        Dim ParameterSet As String() = {}
        Dim HeaderNumber As String = ""
        Dim TempRow As String = ""
        Dim Parameter As Double = 0

        If inclDescription Then temp.AddRange(Header)

        'header
        'for each of the 3 parameter
        For ParCounter As Integer = 1 To 3

            'repeat counter
            For CompCounter As Integer = 1 To ParMetParameter.Count

                If ParCounter = 1 And CompCounter = 1 Then
                    HeaderNumber = "***   0" & ParCounter
                Else
                    HeaderNumber &= "      0" & ParCounter
                End If

            Next

        Next

        If inclDescription Then temp.Add(HeaderNumber)

        For ParCounter As Integer = 0 To 2

            'repeat counter
            For CompCounter As Integer = 0 To ParMetParameter.Count - 1

                ParameterSet = ParMetParameter(CompCounter).Split({","c})

                If ParCounter = 1 Then
                    TempRow &= ParameterSet(ParCounter).ToString.PadLeft(" .15E-06".Length)
                Else
                    Parameter = CDbl(ParameterSet(ParCounter))
                    TempRow &= Parameter.ToString("0.00").PadLeft(8)
                End If

            Next

        Next

        temp.Add(TempRow)

        Return temp.ToArray

    End Function


#End Region


#Region "PELMO"

    <Category(CATOutput)>
    <DisplayName("PELMO , <VOLATILIZATION> ")>
    <Browsable(True)>
    Public ReadOnly Property PELMO_VOLATILIZATION As String()
        Get
            Return createsPELMO_VOLATILIZATION()
        End Get
    End Property



    Public Function createsPELMO_VOLATILIZATION() As String()

        Dim temp As New List(Of String)
        Dim Header As String = "< henry"
        Dim LowTemp As String = "  calc."
        Dim HighTemp As String = "  calc."
        Dim actValue As String = ""
        Dim actHeader As String = ""
        Const minSpace As String = "  "

        temp.Add("<VOLATILIZATION>")

        'solub.
        actValue = minSpace & Me.Solubility.ToString
        actHeader = minSpace & "solub."

        If actValue.Length < actHeader.Length Then
            actValue = actValue.PadLeft(actHeader.Length)
        ElseIf actHeader.Length < actHeader.Length Then
            actHeader = actHeader.PadLeft(actValue.Length)
        End If

        Header &= actHeader

        LowTemp &= actValue
        HighTemp &= actValue


        'molmass
        actValue = minSpace & Me.MolMass.ToString
        actHeader = minSpace & "molmass"

        If actValue.Length < actHeader.Length Then
            actValue = actValue.PadLeft(actHeader.Length)
        ElseIf actHeader.Length < actHeader.Length Then
            actHeader = actHeader.PadLeft(actValue.Length)
        End If

        Header &= actHeader

        LowTemp &= actValue
        HighTemp &= actValue

        'vap.press
        actValue = minSpace & Me.VP.ToString("0.00E+00")
        actHeader = minSpace & "vap.press"

        If actValue.Length < actHeader.Length Then
            actValue = actValue.PadLeft(actHeader.Length)
        ElseIf actHeader.Length < actHeader.Length Then
            actHeader = actHeader.PadLeft(actValue.Length)
        End If

        Header &= actHeader

        LowTemp &= actValue
        HighTemp &= actValue

        'unknown parameters
        Header &= "  diff air  depth volat.     Hv"

        LowTemp &= "      0.05          0.1   98400"
        HighTemp &= "      0.05          0.1   98400"


        'temperature
        actHeader = minSpace & "Temperature"

        Header &= actHeader & " >"

        LowTemp &= (Math.Round((Me.VPRefTemp + Me.SolRefTemp) /
                                           2, 0) - 0.5).ToString.PadLeft(actHeader.Length)
        HighTemp &= (Math.Round((Me.VPRefTemp + Me.SolRefTemp) /
                                           2, 0) + 0.5).ToString.PadLeft(actHeader.Length)

        temp.Add(Header)
        temp.Add(LowTemp)
        temp.Add(HighTemp)
        temp.Add("<END VOLATILIZATION>")

        Return temp.ToArray

    End Function


#End Region

#End Region

    <Category(CATOutput)>
    <DisplayName("Input Complete ?")>
    Public ReadOnly Property InputComplete As Boolean
        Get

            If Me.MolMass = 9999 OrElse
            Me.VP = 0.9999 OrElse
            Me.Solubility = 9999 Then

                Return False

            Else
                Return True

            End If

        End Get
    End Property


#End Region

#Region "Events"

    Public Event DataChange()

#End Region

End Class

