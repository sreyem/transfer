﻿















#Region "Imports System"

Imports System.ComponentModel
Imports System.Reflection
Imports System.Xml.Serialization

Imports System.Drawing.Design
Imports System.Windows.Forms
Imports System.Windows.Forms.Design

#End Region

#Region "Imports Toolbox"

Imports ToolBox

#End Region

Imports Testing.cFreundlichSorption

''' <summary>
''' Freundlich Sorption
''' KOC/KOM Freundlich exponent etc.
''' </summary>
<Serializable>
<DescriptionAttribute("Freundlich Sorption")>
<DefaultProperty("KOC_KOM")>
<DisplayName("Freundlich Sorption")>
<TypeConverter(GetType(cFreundlichSorption.PGridConverter))>
Public Class cFreundlichSorption


#Region "Constructor"

    Public Sub New()

    End Sub

#End Region

#Region "PGrid Stuff"

    ''' <summary>
    ''' makes the class browsable for property grid
    ''' PGridItemName = name to display
    ''' </summary>
    Public Class PGridConverter

        Inherits ExpandableObjectConverter

        <RefreshProperties(RefreshProperties.All)>
        Public Shared Property PGridItemName As String = "Freundlich Sorption"
        Public Shared Property ClassType As Type


#Region "Overloads Overrides"

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                         ByVal destinationType As Type) As Boolean

            Try
                If (destinationType Is ClassType) Then
                    Return True
                End If
            Catch ex As Exception

            End Try

            Return MyBase.CanConvertTo(context,
                                       destinationType)

        End Function

        Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

            If (destinationType Is GetType(System.String)) Then

                If value.GetType Is ClassType Then
                    Return PGridItemName
                End If

            End If

            Return MyBase.ConvertTo(context,
                                    culture,
                                    value,
                                    destinationType)

        End Function

#End Region

    End Class

 

    Public Sub showClassInPGrid()

        Dim dummy As String = ""
        Dim frmPgrid As New ToolBox.frmPGrid



        'frmPgrid.Text = cPhysChemProp.PGridConverter.PGridItemName
        frmPgrid.PGrid.SelectedObject = Me

        frmPgrid.ShowDialog()

    End Sub

#End Region


#Region "Categories"

    Private Const CATBasic As String = "01 Basic"
    Private Const CATPRZM_Sorption As String = "02 PRZM sorption parameters"
    Private Const CATpHDependency As String = "04 pH Dependent Sorption"
    Private Const CATPEARL_Special As String = "03 PEARL special parameters"

    Private Const CATOutput As String = "05 Output"

#End Region

#Region "Std. model values"

    Public Const NoEntry As Double = 9999


    ''' <summary>
    ''' Molar Enthalpy of Sorption
    ''' in kJ/mol [-100|100]
    ''' std. = 0 kj/mol 
    ''' </summary>
    Public Const stdMolarEnthalpySorption As Double = 0

    ''' <summary>
    ''' Reference conc. in liquid phase
    ''' in mg/L [0.1|-] 
    ''' std. = 1 
    ''' </summary>
    Public Const stdConLiqRef As Double = 1

    ''' <summary>
    ''' pH dependence of Sorption
    ''' std. = pH independent 
    ''' </summary>
    Public Const stdOptCofFre As eOptCofFre = eOptCofFre.pH_independent


    ''' <summary>
    ''' Temperature at which sorptionL was measured
    ''' in °C, [0|40], std. = 20°C
    ''' </summary>
    Public Const stdSTemRefSor As Double = 20


#End Region


#Region "01 Basic"


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    WithEvents m_KOC_KOM As New cKOC_KOM

    ''' <summary>
    ''' KOC_KOM
    ''' </summary>
    <Category(CATBasic)>
    <DisplayName("KOC and KOM")>
    <Description("Organic Carbon/matter content normalized" & vbCrLf &
                 "distribution coefficient in L/kg [0|1e9]")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public Property KOC_KOM As cKOC_KOM
        Get
            Return m_KOC_KOM
        End Get
        Set(vKOC_KOM As cKOC_KOM)
            m_KOC_KOM = vKOC_KOM
        End Set
    End Property

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_Freundlich As Double = 0.9999

    ''' <summary>
    ''' Freundlich sorption exponent 1/n [0.1|1.3]
    ''' ExpFre (PEARL) FRNDCF (PRZM) FREUND (MACRO)
    ''' </summary>
    <Category(CATBasic)>
    <DisplayName("Freundlich")>
    <Description("Freundlich sorption exponent 1/n [0.1|1.3]" & vbCrLf &
                 "ExpFre (PEARL/TOXSWA) FRNDCF (PRZM, REC 30b) FREUND (MACRO)")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0.9999)>
    Public Property Freundlich As Double
        Get
            Return m_Freundlich
        End Get
        Set(vFreundlich As Double)

            If vFreundlich <= 1.3 AndAlso vFreundlich >= 0.1 Then

                If vFreundlich < 0.7 Then

                    If MsgBox(Prompt:="Freundlich exponent < 0.7 is strange, continue?",
                             Buttons:=MsgBoxStyle.OkCancel,
                               Title:="User Input seems to be wrong") = MsgBoxResult.Cancel Then
                        Exit Property

                    End If

                End If

                m_Freundlich = vFreundlich

            Else
                MsgBox("Freundlich exponent" & vbCrLf &
                       "without unit, 0.1 <= 1/n <= 1.3 , std.= 0.9" & vbCrLf &
                       "Your input is not valid : " & vFreundlich,
                       MsgBoxStyle.Exclamation)
            End If


        End Set
    End Property


    Public Enum eKdMode
        FOCUSstd
        Individual
        pH_Dependent
        not_defined
    End Enum



    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_KdMode As eKdMode = eKdMode.not_defined

    ''' <summary>
    ''' KdMode
    ''' </summary>
    <Category(CATBasic)>
    <DisplayName("Kd Mode")>
    <Description("Kd set regarding OC (FOCUS std) or pH dependent or" & vbCrLf &
                 "individual user specific values for each horizon")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    <DefaultValue(CInt(eKdMode.not_defined))>
    Public Property KdMode As eKdMode
        Get
            Return m_KdMode
        End Get
        Set(vKdMode As eKdMode)
            m_KdMode = vKdMode
        End Set
    End Property


#End Region


#Region "02 PEARL special parameters"

    Public Enum eOptCofFre
        pH_independent
        pH_dependent
        CofFre
    End Enum

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_OptCofFre As eOptCofFre = stdOptCofFre

    ''' <summary>
    ''' pH dependence of Sorption
    ''' std. = pH independent
    ''' </summary>
    <Category(CATPEARL_Special)>
    <DisplayName("pH dependence")>
    <Description("pH dependence of Sorption" & vbCrLf &
                 "OptCofFre, std.  = pH independent")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(CInt(stdOptCofFre))>
    Public Property OptCofFre As eOptCofFre
        Get
            Return m_OptCofFre
        End Get
        Set(vOptCofFre As eOptCofFre)
            m_OptCofFre = vOptCofFre
        End Set
    End Property

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_TemRefSor As Double = stdSTemRefSor

    ''' <summary>
    ''' Temperature at which sorption was measured
    ''' in °C, [0|40], std. = 20°C
    ''' TemRefSor (PEARL)
    ''' </summary>
    <Category(CATPEARL_Special)>
    <DisplayName("Sorption soil temperature")>
    <Description("Temperature at which sorption was measured" & vbCrLf &
                 "in °C, [0|40], std. = 20°C, TemRefSor")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(stdSTemRefSor)>
    Public Property TemRefSor As Double
        Get
            Return m_TemRefSor
        End Get
        Set(vTemRefSor As Double)

            If vTemRefSor >= 0 AndAlso vTemRefSor <= 40 Then
                If MsgBox(Prompt:="Do you really want to change this parameter?",
                         Buttons:=MsgBoxStyle.YesNo,
                           Title:="Warning: Do not touch this parameter if you're not 100% sure!!!") =
                       MsgBoxResult.No Then

                    Exit Property

                End If

                m_TemRefSor = vTemRefSor
            Else
                mylog(
                        LogTxt:="Temperature at which Sorption was measured" & vbCrLf &
                               "in °C, [0|40], std. = 20°C" & vbCrLf &
                               "Your input is not valid : " & vTemRefSor,
                       Log2File:=False,
                       Log2Msgbox:=True,
                       MsgBoxBtn:=MsgBoxStyle.Critical)
            End If

        End Set
    End Property

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_MolEntSor As Double = stdMolarEnthalpySorption

    ''' <summary>
    ''' Molar Enthalpy of Sorption
    ''' in kJ/mol, DO NOT TOUCH !
    ''' -100 - 100 kJ/mol, std. = 0 kJ/mol
    ''' </summary>
    <Category(CATPEARL_Special)>
    <DisplayName("Molar Enthalpy of Sorption")>
    <Description("in kJ/mol [-100|100]" & vbCrLf &
                 "std. = 0 kJ/mol, MolEntSor")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0.0)>
    Public Property MolEntSor As Double
        Get
            Return m_MolEntSor
        End Get
        Set(vMolEntSor As Double)

            If vMolEntSor >= -100 AndAlso vMolEntSor <= 100 Then

                If MsgBox(Prompt:="Do you really want to change this parameter?",
                         Buttons:=MsgBoxStyle.YesNo,
                           Title:="Warning: Do not touch this parameter if you're not 100% sure!!!") =
                       MsgBoxResult.No Then

                    Exit Property

                End If

                m_MolEntSor = vMolEntSor

            Else
                MsgBox("Molar enthalpy of Sorption" & vbCrLf &
                       "in kJ/mol [-100|100], DO NOT TOUCH !" & vbCrLf &
                       "std. = 0 kJ/mol" & vbCrLf &
                       "Your input is not valid : " & vMolEntSor,
                       MsgBoxStyle.Exclamation)
            End If

        End Set
    End Property

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_ConLiqRef As Double = stdConLiqRef

    ''' <summary>
    ''' Reference conc. in liquid phase [0.1|-]
    ''' in mg/L, DO NOT TOUCH !
    ''' std. = 1 mg/L
    ''' </summary>
    <Category(CATPEARL_Special)>
    <DisplayName("Reference conc. in liquid phase")>
    <Description("in mg/L [0.1|-]" & vbCrLf &
                 "std. = 1.0 mg/L")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(1.0)>
    Public Property ConLiqRef As Double
        Get
            Return m_ConLiqRef
        End Get
        Set(vConLiqRef As Double)

            If vConLiqRef >= 0.1 Then

                If MsgBox(Prompt:="Do you really want to change this parameter?",
                         Buttons:=MsgBoxStyle.YesNo,
                           Title:="Warning: Do not touch this parameter if you're not 100% sure!!!") =
                       MsgBoxResult.No Then

                    Exit Property

                End If

                m_ConLiqRef = vConLiqRef

            Else
                MsgBox("Reference conc. in liquid phase" & vbCrLf &
                       "in mg/L [0.1|-], DO NOT TOUCH !" & vbCrLf &
                       "std. = 0 kJ/mol" & vbCrLf &
                       "Your input is not valid : " & vConLiqRef,
                       MsgBoxStyle.Exclamation)
            End If

        End Set
    End Property


#End Region

#Region "03 PRZM sorption parameters"


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_PRZM_FreundlichSorption As New cPRZM_FreundlichSorption

    ''' <summary>
    ''' PRZM_FreundlichSorption
    ''' </summary>
    <Category(CATPRZM_Sorption)>
    <DisplayName("PRZM Freundlich Sorption")>
    <Description("PRZM Freundlich Sorption Parameters" & vbCrLf &
                 "FOCUS std., Scenario/Horizon specific or pH dependent")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(False)>
    <[ReadOnly](False)>
    Public Property PRZM_FreundlichSorption As cPRZM_FreundlichSorption
        Get
            Return m_PRZM_FreundlichSorption
        End Get
        Set(vPRZM_FreundlichSorption As cPRZM_FreundlichSorption)
            m_PRZM_FreundlichSorption = vPRZM_FreundlichSorption
        End Set
    End Property

    <Category(CATPRZM_Sorption)>
    <DisplayName("PRZM Freundlich Sorption")>
    <Description("PRZM Freundlich Sorption Parameters" & vbCrLf &
                 "FOCUS std., Scenario/Horizon specific or pH dependent")>
    <[ReadOnly](True)>
    Public ReadOnly Property PRZMSummary As String()
        Get
            Return PRZM_FreundlichSorption.Summary
        End Get
    End Property


#End Region

#Region "Output"

#Region "User input"


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_inclDescription As Boolean = True

    ''' <summary>
    ''' Model parameter incl. description
    ''' </summary>
    <Category(CATOutput)>
    <DisplayName("incl Description")>
    <Description("Model parameter incl. description" & vbCrLf &
                 "std. = true ;-)")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(True)>
    <XmlIgnore>
    Public Property inclDescription As Boolean
        Get
            Return m_inclDescription
        End Get
        Set(vinclDescription As Boolean)
            m_inclDescription = vinclDescription
        End Set
    End Property

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_SubstanceCode As String = "IOP"

    ''' <summary>
    ''' Substance Code
    ''' Max. 5 letters, do not start with a number
    ''' no special chars like _ or ; Do not : 124_T but T124
    ''' </summary>
    <Category(CATOutput)>
    <DisplayName("Substance Code")>
    <Description("Max. 5 letters, do not start with a number" & vbCrLf &
                 "no special chars like _ or ; Do not : 124_T but T124")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue("IOP")>
    Public Property SubstanceCode As String
        Get
            Return m_SubstanceCode
        End Get
        Set(vSubstanceCode As String)

            If vSubstanceCode.Length > 5 Then Exit Property

            'check if 1st char is a number
            For CharCounter As Integer = 0 To vSubstanceCode.Length - 1
                If Asc(vSubstanceCode(CharCounter)) >= 48 AndAlso
                    Asc(vSubstanceCode(CharCounter)) <= 57 AndAlso
                    CharCounter = 0 Then
                    vSubstanceCode = "Error"
                End If

                'only A - Z and a - z
                If Not Asc(vSubstanceCode(CharCounter)) >= 65 AndAlso
                   Not Asc(vSubstanceCode(CharCounter)) <= 90 OrElse
                   Not Asc(vSubstanceCode(CharCounter)) >= 97 AndAlso
                   Not Asc(vSubstanceCode(CharCounter)) <= 122 Then

                    vSubstanceCode = "Error"

                End If


            Next

            m_SubstanceCode = vSubstanceCode

        End Set
    End Property

#End Region

#Region "PEARL"


    ''' <summary>
    ''' PEARL, Basic Parameters for pH independent equilibrium sorption
    ''' </summary>
    <Category(CATOutput)>
    <DisplayName("PEARL, BASIC")>
    <Browsable(True)>
    Public ReadOnly Property PEARL_Sorption_Basic As String()
        Get
            Return getPEARL_Sorption_Basic(
                        SubstanceCode:=Me.SubstanceCode,
                        inclDescription:=Me.inclDescription)
        End Get
    End Property

    Public Function getPEARL_Sorption_Basic(
                   Optional SubstanceCode As String = "IOP",
                   Optional PadValue As Integer = 20,
                   Optional PadUnit As Integer = 25,
                   Optional PadDescription As Integer = 10,
                   Optional inclDescription As Boolean = True) As String()

        Dim PEARL As New List(Of String)

        With PEARL

            .Add("* Basic Parameters for pH independent equilibrium sorption " & SubstanceCode)

            .Add(Me.KOC_KOM.KOMeq.ToString.PadRight(PadValue) &
               ("KomEql_" & SubstanceCode).PadRight(PadUnit) &
               "(L.kg-1)".PadRight(PadDescription) &
               IIf(inclDescription, "Coef. eql. sorption on org. matter [0|1e9]", "").ToString)

            .Add(Me.Freundlich.ToString.PadRight(PadValue) &
                 ("ExpFre_" & SubstanceCode).PadRight(PadUnit) &
                 "(-)".PadRight(PadDescription) &
                 IIf(inclDescription, "Freundlich sorption exponent [0.1|1.3]", "").ToString)

        End With


        Return PEARL.ToArray

    End Function


    ''' <summary>
    ''' PEARL, Basic Parameters for pH independent equilibrium sorption
    ''' </summary>
    <Category(CATOutput)>
    <DisplayName("PEARL, SPECIAL")>
    <Description("DO NOT TOUCH")>
    <Browsable(True)>
    Public ReadOnly Property PEARL_Sorption_Special As String()
        Get
            Return getPEARL_Sorption_Special(
                        SubstanceCode:=Me.SubstanceCode,
                        inclDescription:=Me.inclDescription)
        End Get
    End Property


    Public Function getPEARL_Sorption_Special(
                  Optional SubstanceCode As String = "IOP",
                  Optional PadValue As Integer = 20,
                  Optional PadUnit As Integer = 25,
                  Optional PadDescription As Integer = 10,
                  Optional inclDescription As Boolean = True) As String()

        Dim PEARL As New List(Of String)

        With PEARL

            .Add("* SPECIAL Parameters for equilibrium sorption " & SubstanceCode)

            .Add((Replace(Me.OptCofFre.ToString, "_", "-").PadRight(PadValue) &
               ("OptCofFre_" & SubstanceCode).PadRight(PadUnit) &
               " ".PadRight(PadDescription) &
               IIf(inclDescription, "pH dependence, std. = pH independent", "").ToString))


            .Add(Me.KOC_KOM.KOMeq.ToString.PadRight(PadValue) &
               ("KomEqlMax_" & SubstanceCode).PadRight(PadUnit) &
               "(L.kg-1)".PadRight(PadDescription) &
               IIf(inclDescription, "Coef. eql. sorption on org. matter in dry soil [0|1e9]", "").ToString)

            .Add(Me.MolEntSor.ToString.PadRight(PadValue) &
                 ("MolEntSor_" & SubstanceCode).PadRight(PadUnit) &
                 "(kJ/mol)".PadRight(PadDescription) &
                 IIf(inclDescription, "Molar Enthalpy of Sorption [-100|100]", "").ToString)

            .Add(Me.TemRefSor.ToString.PadRight(PadValue) &
                 ("TemRefSor_" & SubstanceCode).PadRight(PadUnit) &
                 "(°C)".PadRight(PadDescription) &
                 IIf(inclDescription, "Temperature at which sorptionL was measured [0|40]", "").ToString)


            .Add(Me.ConLiqRef.ToString.PadRight(PadValue) &
                 ("ConLiqRef_" & SubstanceCode).PadRight(PadUnit) &
                 "(mg/L)".PadRight(PadDescription) &
                 IIf(inclDescription, "Reference conc. in liquid phase [0.1|-]", "").ToString)

        End With


        Return PEARL.ToArray

    End Function



#End Region



#Region "Summary"


    <Category(CATOutput)>
    <Browsable(True)>
    <RefreshProperties(RefreshProperties.All)>
    Public ReadOnly Property Summary As String()
        Get
            Return getFreundlichSorptionmSummary()
        End Get
    End Property


    Public Const Click2EditString As String = "freundlich sorption"

    Public Function getFreundlichSorptionmSummary() As String()

        Dim Summary As New List(Of String)
        'Const PadLenght As Integer = 14
        'Const PadLenghtUnit As Integer = 8

        Dim out As String = ""

        With KOC_KOM

            If .KOCeq = NoEntry OrElse .KOMeq = NoEntry Then
                out = "Entry incomlete!"
            Else
                If .KOM_KOC_Conversion.myFromTo =
                    cKOC_KOM.cKOM_KOC_Conversion.eConversionDirection.KOC_to_KOM Then
                    out = "KOC = " & .KOCeq & " L/kg (KOM = " & .KOMeq & " L/kg)"
                Else
                    out = "KOM = " & .KOMeq & " L/kg (KOC = " & .KOCeq & " L/kg)"
                End If
            End If
        End With


        cKOC_KOM.PGridConverter.PGridItemName = out
        cFreundlichSorption.PGridConverter.PGridItemName = "Freundlich Sorption"

        With Summary

            .Add("Click here to edit " & Click2EditString)
            .Add("***********    Basic Parameters    *****************")
            If Me.KdMode <> eKdMode.not_defined Then .Add("Kd Mode = " & Me.KdMode.ToString)
            .Add("Adsorption          : " & out)
            .Add("Freundlich exponent : " & Me.Freundlich)


            .Add("***********    PRZM Parameters    *****************")
            If Me.PRZM_FreundlichSorption.Summary.Count > 1 Then


                For counter As Integer = 1 To Me.PRZM_FreundlichSorption.Summary.Count - 1
                    .Add(Me.PRZM_FreundlichSorption.Summary(counter))
                Next

            End If

        End With

        Return Summary.ToArray

    End Function

#End Region

#End Region

#Region "Events"

    Public Sub change_KOC_KOM() Handles m_KOC_KOM.ConversionByUser

        With Me.PRZM_FreundlichSorption

            .KOC = Me.KOC_KOM.KOCeq
            .fillPRZMScenarioswithKOC(KOC:=Me.KOC_KOM.KOCeq)
            .KdMode = eKdMode.FOCUSstd

        End With

        Me.KdMode = eKdMode.FOCUSstd

    End Sub

#End Region

End Class



''' <summary>
''' PRZM Freundlich Sorption Parameters 
''' FOCUS std., Scenario/Horizon specific or pH dependent
''' </summary>
<Serializable>
<Description("PRZM Freundlich Sorption Parameters" & vbCrLf &
             "FOCUS std., Scenario/Horizon specific or pH dependent")>
<DefaultProperty("KOC")>
<DisplayName("PRZM Freundlich Sorption Parameters")>
<TypeConverter(GetType(cPRZM_FreundlichSorption.PGridConverter))>
Public Class cPRZM_FreundlichSorption


#Region "Constructor"

    Public Sub New()

    End Sub

#End Region

#Region "PGrid Stuff"

    ''' <summary>
    ''' makes the class browsable for property grid
    ''' PGridItemName = name to display
    ''' </summary>
    Public Class PGridConverter

        Inherits ExpandableObjectConverter

        <RefreshProperties(RefreshProperties.All)>
        Public Shared Property PGridItemName As String = ""
        Public Shared Property ClassType As Type


#Region "Overloads Overrides"

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                         ByVal destinationType As Type) As Boolean

            Try
                If (destinationType Is ClassType) Then
                    Return True
                End If
            Catch ex As Exception

            End Try

            Return MyBase.CanConvertTo(context,
                                       destinationType)

        End Function

        Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

            If (destinationType Is GetType(System.String)) Then

                If value.GetType Is ClassType Then
                    Return PGridItemName
                End If

            End If

            Return MyBase.ConvertTo(context,
                                    culture,
                                    value,
                                    destinationType)

        End Function

#End Region

    End Class



    Public Sub showClassInPGrid()

        Dim dummy As String = ""
        Dim frmPgrid As New ToolBox.frmPGrid



        'frmPgrid.Text = cPhysChemProp.PGridConverter.PGridItemName
        frmPgrid.PGrid.SelectedObject = Me

        frmPgrid.ShowDialog()

    End Sub

#End Region

#Region "Categories"

    Private Const CATFOCUSPRZMSorption As String = "01  FOCUS sorption values for PRZM"
    Private Const CATScenarioPRZMSorption As String = "02  Scenario specific sorption values for PRZM"
    Private Const CATpHDependendPRZM As String = "03  pH Dependent sorption values for PRZM"
    Private Const CATOutput As String = "04 Output"

    Private Const EXCELFilename As String = "RunOff_Sorption.xltm"

#End Region

#Region "std Values"



#End Region

#Region "01  FOCUS sorption values for PRZM"

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_KdMode As eKdMode = eKdMode.FOCUSstd

    ''' <summary>
    ''' Kd set regarding OC (FOCUS std) or pH dependent or
    ''' individual user specific values for each horizon
    ''' </summary>
    <Category(CATFOCUSPRZMSorption)>
    <DisplayName("Kd Mode")>
    <Description("Kd set regarding OC (FOCUS std) or pH dependent or" & vbCrLf &
                 "individual user specific values for each horizon")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(CInt(eKdMode.not_defined))>
    Public Property KdMode As eKdMode
        Get
            Return m_KdMode
        End Get
        Set(vKdMode As eKdMode)
            m_KdMode = vKdMode

            Select Case m_KdMode

                Case eKdMode.FOCUSstd
                    cPRZM_FreundlichSorption.PGridConverter.PGridItemName = "FOCUS std. values"

                Case eKdMode.Individual
                    cPRZM_FreundlichSorption.PGridConverter.PGridItemName = "Scenario specific values"

                Case eKdMode.pH_Dependent
                    cPRZM_FreundlichSorption.PGridConverter.PGridItemName = "pH dependent values"

            End Select

        End Set
    End Property

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_KOC As Double = NoEntry

    ''' <summary>
    ''' KOC
    ''' Organic Carbon content normalized
    ''' distribution coefficient in L/kg [0|1e9]
    ''' </summary>
    <Category(CATFOCUSPRZMSorption)>
    <DisplayName("KOC")>
    <Description("Organic Carbon content normalized" & vbCrLf &
                 "distribution coefficient in L/kg [0|1e9]")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(NoEntry)>
    Public Property KOC As Double
        Get
            Return m_KOC
        End Get
        Set(vKOC As Double)
            m_KOC = vKOC
            fillPRZMScenarioswithKOC(m_KOC)
        End Set
    End Property



    Public Function formatPRZMKd(Kd As Double) As String

        Dim FormatString As String = ""
        Dim Digits As Integer = 0
        Dim KdString As String = ""

        Select Case Kd

            Case Is >= 1000
                FormatString = " 0.00"
                Digits = 2

            Case Is >= 100
                FormatString = " 0.000"
                Digits = 3

            Case Is >= 10
                FormatString = " 0.0000"
                Digits = 4

            Case Is >= 0
                FormatString = " 0.00000"
                Digits = 5

            Case Else

                Return "?????"

        End Select

        Return Math.Round(Kd, Digits).ToString(FormatString)

    End Function

    Public Function fillPRZMScenarioswithKOC(KOC As Double) As String()


        Dim Transfer As New List(Of String)
        Dim FormatString As String = ""
        Dim Digits As Integer = 0

        Dim Kd As Double = 0
        Dim out As String() = {"R1 : ",
                               "R2 : ",
                               "R3 : ",
                               "R4 : "}


        If Me.KOC = NoEntry Then Return {}

        'R1, 3 Horizons
        Transfer.Clear()
        For counter As Integer = 0 To 2

            Kd = KOC * (cFOCUSPRZMStd.R1_OC(counter) / 100)
            Transfer.Add(formatPRZMKd(Kd:=Kd))

        Next
        out(0) &= Join(Transfer.ToArray, " ")


        'R2, 4 Horizons
        Transfer.Clear()
        For counter As Integer = 0 To 3

            Kd = KOC * (cFOCUSPRZMStd.R2_OC(counter) / 100)
            Transfer.Add(formatPRZMKd(Kd:=Kd))

        Next
        out(1) &= Join(Transfer.ToArray, " ")

        'R3, 4 Horizons
        Transfer.Clear()
        For counter As Integer = 0 To 3

            Kd = KOC * (cFOCUSPRZMStd.R3_OC(counter) / 100)
            Transfer.Add(formatPRZMKd(Kd:=Kd))

        Next
        out(2) &= Join(Transfer.ToArray, " ")

        'R4, 4 Horizons
        Transfer.Clear()
        For counter As Integer = 0 To 3

            Kd = KOC * (cFOCUSPRZMStd.R4_OC(counter) / 100)
            Transfer.Add(formatPRZMKd(Kd:=Kd))

        Next
        out(3) &= Join(Transfer.ToArray, " ")

        Return out

    End Function

  
    ''' <summary>
    ''' FOCUS PRZM sorption values for PRZM
    ''' </summary>
    <Category(CATFOCUSPRZMSorption)>
    <DisplayName("FOCUS PRZM Sorption")>
    <Description("FOCUS sorption values for PRZM" & vbCrLf &
                 "for each horizon in L/kg")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    Public ReadOnly Property FOCUSPRZMSorption As String()
        Get
            Return fillPRZMScenarioswithKOC(m_KOC)
        End Get
    End Property



#Region "PRZM Scenario Overview"



    ''' <summary>
    ''' PRZMocOverview
    ''' </summary>
    <Category(CATFOCUSPRZMSorption)>
    <DisplayName("OC Overview")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public ReadOnly Property PRZMocOverview As String()
        Get

            Dim out As New List(Of String)
            Dim Scenario As String = ""
            Dim Space As Integer = 5

            out.Add("Horizon  : " & "01".PadLeft(Space) &
                                    "02".PadLeft(Space) &
                                    "03".PadLeft(Space) &
                                    "04".PadLeft(Space) &
                                    "05".PadLeft(Space))

            Scenario = "      R1 : "
            For Each oc As Double In cFOCUSPRZMStd.R1_OC
                Scenario &= oc.ToString.PadLeft(Space)
            Next

            out.Add(Scenario)

            Scenario = "      R2 : "
            For Each oc As Double In cFOCUSPRZMStd.R2_OC
                Scenario &= oc.ToString.PadLeft(Space)
            Next

            out.Add(Scenario)

            Scenario = "      R3 : "
            For Each oc As Double In cFOCUSPRZMStd.R3_OC
                Scenario &= oc.ToString.PadLeft(Space)
            Next

            out.Add(Scenario)

            Scenario = "      R4 : "
            For Each oc As Double In cFOCUSPRZMStd.R4_OC
                Scenario &= oc.ToString.PadLeft(Space)
            Next

            out.Add(Scenario)


            Return out.ToArray
        End Get
    End Property



    <Category(CATFOCUSPRZMSorption)>
    <DisplayName("PRZM Scenario Overview")>
    <XmlIgnore>
    Public Property Overview As String() =
        {
"                                  R1 (Weiherbach, P/S)           ||          R2 (Porto, Stream)                   ||         R3 (Bologna, Stream)                  ||         R4 (Roujan, Stream)         ",
"  Layer                (-)        Ap     |    Bw     |    Bc     ||    Ap     |    Ah     |    Ab1    |    Ab2    ||    Ap1    |    Ap2    |    Bk     |     C     ||    Ap1    |    Ap2    |    2C1    |    2C2   ",
"  Depth                (cm)      0-30    |   30-60   |  60-100+  ||   0-20    |   20-45   |   45-65   |  65-100   ||   0-45    |   45-75   |  75-145   |  145-160  ||   0-30    |   30-60   |  60-170   |  170-300 ",
"  Thickness            (cm)       30     |    30     |    40+    ||    20     |    25     |    20     |    35     ||    45     |    30     |    70     |    15     ||    30     |    30     |    110    |    130   ",
"  Sand                 (%)         5     |     6     |     5     ||    67     |    72     |    75     |    74     ||    23     |    25     |    17     |    14     ||    53     |    53     |    69     |    65    ",
"  Silt                 (%)        82     |    83     |    84     ||    19     |    16     |    13     |    16     ||    43     |    42     |    48     |    50     ||    22     |    22     |    24     |    27    ",
"  Clay                 (%)        13     |    11     |    11     ||    14     |    12     |    12     |    20     ||    34     |    33     |    35     |    36     ||    25     |    25     |     7     |     8    ",
"  USDA class           (-)       silt    |   silt    |   silt    ||   sandy   |   sandy   |   sandy   |   sandy   ||   clay    |   clay    |   silty   |   silty   ||   sandy   |   sandy   |   sandy   |   sandy  ",
"                                 loam    |   loam    |   loam    ||   loam    |   loam    |   loam    |   loam    ||   loam    |   loam    | clay loam | clay loam || clay loam | clay loam |   loam    |   loam   ",
"  Organic carbon       (%)        1.2    |    0.3    |    0.1    ||     4     |    2.4    |    0.8    |    0.5    ||     1     |     1     |   0.35    |   0.29    ||    0.6    |    0.6    |   0.08    |   0.08   ",
"  Organic matter       (%)       2.07    |   0.52    |   0.17    ||    6.9    |   4.14    |   1.38    |   0.86    ||   1.72    |   1.72    |    0.6    |    0.5    ||   1.03    |   1.03    |   0.14    |   0.14   ",
"  Bulk density         (g/cm3)   1.35    |   1.45    |   1.48    ||   1.15    |   1.29    |   1.36    |   1.41    ||   1.46    |   1.49    |   1.52    |   1.54    ||   1.52    |    1.5    |   1.49    |    1.5   ",
"  pH                   (-)        7.3    |    7.6    |     8     ||    4.5    |    4.9    |    5.4    |    5.3    ||    7.9    |    7.9    |    8.3    |    8.3    ||    8.4    |    8.4    |    8.8    |    8.8   ",
"  Field capacity       (% vol)   33.8    |   28.6    |   27.7    ||    36     |    27     |    19     |    17     ||    37     |    35     |    36     |    36     ||    26     |    27     |   14.5    |    16    ",
"  Wilting point        (% vol)   13.1    |   10.1    |    9.8    ||    17     |    13     |     9     |     7     ||    22     |    21     |    21     |    22     ||    16     |    16     |     6     |     7    ",
"  Depth dep. degr. Fac.(-)         1     |     1     |     1     ||     1     |     1     |     1     |     1     ||     1     |     1     |     1     |     1     ||     1     |     1     |     1     |     1    ",
"-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------"
}

#End Region


#End Region


#Region "Scenario specific sorption values for PRZM"

    ''' <summary>
    ''' Get Scenario specific sorption values for PRZM
    ''' for each horizon, taken from EXCEL (Clipboard)
    ''' </summary>
    <Category(CATScenarioPRZMSorption)>
    <DisplayName("Get Scenario Specific Sorption")>
    <Description("Get Scenario specific sorption values for PRZM" & vbCrLf &
                 "for each horizon, taken from EXCEL (Clipboard)")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <XmlIgnore>
    Public Property getPRZMSorptionFromEXCEL As eClick
        Get
            Return eClick.Dblclick
        End Get
        Set(vgetPRZMSorptionFromEXCEL As eClick)

            If vgetPRZMSorptionFromEXCEL = eClick.Dblclick Then Exit Property

            Clipboard.SetText(Me.KOC.ToString)

            Try

                If MsgBox(Prompt:="Open template EXCEL spreadsheet?",
                          Buttons:=vbYesNo,
                          Title:="Open EXCEL Spreadsheet for input") = MsgBoxResult.No Then

                    Dim ofd As New OpenFileDialog

                    With ofd

                        .Reset()
                        .Multiselect = False

                        .Filter = "EXCEL Runoff-Sorption data sheet (*.xlsm)|*.xlsm|" & _
                                  "EXCEL Runoff-Sorption data template (*.xltm)|*.xlsm|" & _
                                  "All files (*.*)|*.*"


                        If .ShowDialog = DialogResult.OK Then
                            Process.Start(.FileName)
                        End If


                    End With


                Else
                    Process.Start(EXCELFilename)
                End If



            Catch ex As Exception

                MsgBox(Prompt:="Can't proceed getting sorption values from clipboard" & vbCrLf & ex.Message,
                       Buttons:=MsgBoxStyle.Critical,
                       Title:="Critical Error")
                Exit Property

            End Try


            If MsgBox(Prompt:="Just click OK to fill, otherwise click Cancel",
                      Title:="Scenario specific sorption values for PRZM",
                      Buttons:=MsgBoxStyle.OkCancel) = MsgBoxResult.Cancel Then Exit Property

            createPRZMSorptionFromCLP(
                                       CLPText:=Clipboard.GetText,
                                     pHorFOCUS:=epHorScenario.scenario)

            Me.KdMode = eKdMode.Individual


        End Set
    End Property

    Public Enum epHorScenario
        pH
        scenario
    End Enum

    ''' <summary>
    ''' get PRZM sorption values from clipboard created by EXCEL
    ''' </summary>
    ''' <param name="CLPText">
    ''' 22 entries, incl. comments and version
    ''' </param>
    ''' <param name="pHorFOCUS"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function createPRZMSorptionFromCLP(CLPText As String,
                                             pHorFOCUS As epHorScenario) As Boolean

        Dim CLP As String() = {}
        Dim Transfer As New List(Of String)
        Dim out As String() = {"R1 : ",
                               "R2 : ",
                               "R3 : ",
                               "R4 : "}

        CLP = CLPText.Split({" "c}, StringSplitOptions.RemoveEmptyEntries)

        If CLP.Count <> 15 AndAlso pHorFOCUS = epHorScenario.scenario Then

            MsgBox(Prompt:=15 - CLP.Count & " entries are missing!",
                   Title:="User input Error",
                   Buttons:=MsgBoxStyle.Critical)

            Return False
        End If

        If CLP.Count <> 30 AndAlso pHorFOCUS = epHorScenario.pH Then

            MsgBox(Prompt:=30 - CLP.Count & " entries are missing!",
                   Title:="User input Error",
                   Buttons:=MsgBoxStyle.Critical)

            Return False
        End If


        'Try
        '    CLP(CLP.Count - 1) = CLP(CLP.Count - 1).Substring(0, 8)
        'Catch ex As Exception

        'End Try

        'R1
        Transfer.Clear()
        For counter As Integer = 0 To 2
            Transfer.Add(CLP(counter))
        Next

        out(0) &= Join(Transfer.ToArray, " ")

        'R2
        Transfer.Clear()
        For counter As Integer = 3 To 6
            Transfer.Add(CLP(counter))
        Next

        out(1) &= Join(Transfer.ToArray, " ")


        Transfer.Clear()
        For counter As Integer = 7 To 10
            Transfer.Add(CLP(counter))
        Next

        out(2) &= Join(Transfer.ToArray, " ")

        Transfer.Clear()
        For counter As Integer = 11 To 14
            Transfer.Add(CLP(counter))
        Next

        out(3) &= Join(Transfer.ToArray, " ")


        If pHorFOCUS = epHorScenario.scenario Then
            ScenarioPRZMSorption = out
            Return True
        End If

        AcidPRZMSorption = out

        out =
                {"R1 : ",
                "R2 : ",
                "R3 : ",
                "R4 : "}

        Transfer.Clear()
        For counter As Integer = 15 To 17
            Transfer.Add(CLP(counter))
        Next

        out(0) &= Join(Transfer.ToArray, " ")

        'R2
        Transfer.Clear()
        For counter As Integer = 18 To 21
            Transfer.Add(CLP(counter))
        Next

        out(1) &= Join(Transfer.ToArray, " ")


        Transfer.Clear()
        For counter As Integer = 22 To 25
            Transfer.Add(CLP(counter))
        Next

        out(2) &= Join(Transfer.ToArray, " ")

        Transfer.Clear()
        For counter As Integer = 26 To 29
            Transfer.Add(CLP(counter))
        Next

        out(3) &= Join(Transfer.ToArray, " ")


        BasePRZMSorption = out


        Return True

    End Function

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_ScenarioPRZMSorption As String() = {""}

    ''' <summary>
    ''' Scenario specific sorption values for PRZM
    ''' for each horizon in L/kg
    ''' </summary>
    <Category(CATScenarioPRZMSorption)>
    <DisplayName("Scenario Specific Sorption")>
    <Description("Scenario specific sorption values for PRZM" & vbCrLf &
                 "for each horizon in L/kg")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    <DefaultValue({""})>
    Public Property ScenarioPRZMSorption As String()
        Get
            Return m_ScenarioPRZMSorption
        End Get
        Set(vScenarioPRZMSorption As String())
            m_ScenarioPRZMSorption = vScenarioPRZMSorption
        End Set
    End Property



#End Region


#Region "02 pH Dependent Sorption"

    

    ''' <summary>
    ''' set read only property
    ''' </summary>
    Public Sub SetReadOnlyProperty(ByVal propertyName As String,
                                  ByVal [readOnly] As Boolean)

        Dim descriptor As PropertyDescriptor =
                TypeDescriptor.GetProperties([GetType]())(propertyName)
        Dim attribute As ReadOnlyAttribute =
            DirectCast(descriptor.Attributes(GetType(ReadOnlyAttribute)), ReadOnlyAttribute)



        Dim fieldToChange As Reflection.FieldInfo =
                    attribute.[GetType]().GetField("isReadOnly",
                                                System.Reflection.BindingFlags.NonPublic Or
                                                System.Reflection.BindingFlags.Instance)

        fieldToChange.SetValue(attribute, [readOnly])

    End Sub

    ''' <summary>
    ''' Set the Browsable property.
    ''' NOTE: Be sure to decorate the property with [Browsable(true)]
    ''' </summary>
    ''' <param name="PropertyName">Name of the variable</param>
    ''' <param name="Browsable">Browsable Value</param>
    Private Sub setBrowsableProperty(PropertyName As String, Browsable As Boolean)
        ' Get the Descriptor's Properties
        Dim theDescriptor As PropertyDescriptor = TypeDescriptor.GetProperties(Me.[GetType]())(PropertyName)

        ' Get the Descriptor's "Browsable" Attribute
        Dim theDescriptorBrowsableAttribute As BrowsableAttribute = DirectCast(theDescriptor.Attributes(GetType(BrowsableAttribute)), BrowsableAttribute)
        Dim isBrowsable As System.Reflection.FieldInfo = theDescriptorBrowsableAttribute.[GetType]().GetField("Browsable", BindingFlags.IgnoreCase Or BindingFlags.NonPublic Or BindingFlags.Instance)

        ' Set the Descriptor's "Browsable" Attribute
        isBrowsable.SetValue(theDescriptorBrowsableAttribute, Browsable)
    End Sub




    ''' <summary>
    ''' get pH Dependent Scenario specific sorption values
    ''' </summary>
    <Category(CATpHDependendPRZM)>
    <DisplayName("PRZM pH Dependent Scenario Specific Sorption")>
    <Description("pH dependent scenario specific sorption values" & vbCrLf &
                 "for each horizon, taken from EXCEL (Clipboard)")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <XmlIgnore>
    Public Property getpHPRZMSorption As eClick
        Get
            Return eClick.Dblclick
        End Get
        Set(vgetpHPRZMSorption As eClick)

            If vgetpHPRZMSorption = eClick.Dblclick Then Exit Property

            'acid sorption values
            Clipboard.SetText(Me.KOC.ToString)

            Try

                If MsgBox(Prompt:="Open template EXCEL spreadsheet?",
                          Buttons:=vbYesNo,
                          Title:="Open EXCEL Spreadsheet for input") = MsgBoxResult.No Then

                    Dim ofd As New OpenFileDialog

                    With ofd

                        .Reset()
                        .Multiselect = False

                        .Filter = "EXCEL Runoff-Sorption data sheet (*.xlsm)|*.xlsm|" & _
                                  "EXCEL Runoff-Sorption data template (*.xltm)|*.xlsm|" & _
                                  "All files (*.*)|*.*"


                        If .ShowDialog = DialogResult.OK Then
                            Process.Start(.FileName)
                        End If


                    End With


                Else
                    Process.Start(EXCELFilename)
                End If



            Catch ex As Exception

                MsgBox(Prompt:="Can't proceed getting sorption values from clipboard" & vbCrLf & ex.Message,
                       Buttons:=MsgBoxStyle.Critical,
                       Title:="Critical Error")
                Exit Property

            End Try


            If MsgBox(Prompt:="Just click OK to fill pH dependent Sorption Values for PRZM" & vbCrLf &
                              "otherwise click Cancel",
                      Title:="+++++ pH Dependent Sorption Values for PRZM",
                      Buttons:=MsgBoxStyle.OkCancel) = MsgBoxResult.Cancel Then Exit Property


            createPRZMSorptionFromCLP(
                                       CLPText:=Clipboard.GetText,
                                     pHorFOCUS:=epHorScenario.pH)


            Me.KdMode = eKdMode.pH_Dependent

        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_AcidPRZMSorption As String() = {""}

    ''' <summary>
    ''' Acid (7 > pH) Scenario specific sorption values
    ''' for each horizon, taken from EXCEL (Clipboard)
    ''' </summary>
    <Category(CATpHDependendPRZM)>
    <DisplayName("ACID PRZM Sorption")>
    <Description("ACID (pH < 7) Scenario specific sorption values" & vbCrLf &
                 "for each horizon, taken from EXCEL (Clipboard)")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
     <DefaultValue({""})>
    Public Property AcidPRZMSorption As String()
        Get
            Return m_AcidPRZMSorption
        End Get
        Set(vAcidPRZMSorption As String())
            m_AcidPRZMSorption = vAcidPRZMSorption
        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_ACIDFreundlich As Double = 0.9999

    ''' <summary>
    ''' ACID Freundlich sorption exponent 1/n [0.1|1.3]
    ''' ExpFre (PEARL) FRNDCF (PRZM) FREUND (MACRO)
    ''' </summary>
    <Category(CATpHDependendPRZM)>
    <DisplayName("ACID Freundlich")>
    <Description("ACID Freundlich sorption exponent 1/n [0.1|1.3]" & vbCrLf &
                 "ExpFre (PEARL/TOXSWA) FRNDCF (PRZM, REC 30b) FREUND (MACRO)")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0.9999)>
    Public Property ACIDFreundlich As Double
        Get
            Return m_ACIDFreundlich
        End Get
        Set(vACIDFreundlich As Double)

            If vACIDFreundlich <= 1.3 AndAlso vACIDFreundlich >= 0.1 Then

                If vACIDFreundlich < 0.7 Then

                    If MsgBox(Prompt:="ACID Freundlich exponent < 0.7 is strange, continue?",
                             Buttons:=MsgBoxStyle.OkCancel,
                               Title:="User Input seems to be wrong") = MsgBoxResult.Cancel Then
                        Exit Property

                    End If

                End If

                m_ACIDFreundlich = vACIDFreundlich

            Else
                MsgBox("ACID Freundlich exponent" & vbCrLf &
                       "without unit, 0.1 <= 1/n <= 1.3 , std.= 0.9" & vbCrLf &
                       "Your input is not valid : " & vACIDFreundlich,
                       MsgBoxStyle.Exclamation)
            End If


        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_BasePRZMSorption As String() = {""}

    ''' <summary>
    ''' Base (pH > 7) Scenario specific sorption values
    ''' for each horizon, taken from EXCEL (Clipboard)
    ''' </summary>
    <Category(CATpHDependendPRZM)>
    <DisplayName("BASE PRZM Sorption")>
    <Description("BASE (pH > 7) Scenario specific sorption values" & vbCrLf &
                 "for each horizon, taken from EXCEL (Clipboard)")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
     <DefaultValue({""})>
    Public Property BasePRZMSorption As String()
        Get
            Return m_BasePRZMSorption
        End Get
        Set(vBasePRZMSorption As String())
            m_BasePRZMSorption = vBasePRZMSorption
        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_BASEFreundlich As Double = 0.9999

    ''' <summary>
    ''' BASE Freundlich sorption exponent 1/n [0.1|1.3]
    ''' ExpFre (PEARL) FRNDCF (PRZM) FREUND (MACRO)
    ''' </summary>
    <Category(CATpHDependendPRZM)>
    <DisplayName("BASE Freundlich")>
    <Description("BASE Freundlich sorption exponent 1/n [0.1|1.3]" & vbCrLf &
                 "ExpFre (PEARL/TOXSWA) FRNDCF (PRZM, REC 30b) FREUND (MACRO)")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0.9999)>
    Public Property BASEFreundlich As Double
        Get
            Return m_BASEFreundlich
        End Get
        Set(vBASEFreundlich As Double)

            If vBASEFreundlich <= 1.3 AndAlso vBASEFreundlich >= 0.1 Then

                If vBASEFreundlich < 0.7 Then

                    If MsgBox(Prompt:="BASE Freundlich exponent < 0.7 is strange, continue?",
                             Buttons:=MsgBoxStyle.OkCancel,
                               Title:="User Input seems to be wrong") = MsgBoxResult.Cancel Then
                        Exit Property

                    End If

                End If

                m_BASEFreundlich = vBASEFreundlich

            Else
                MsgBox("BASE Freundlich exponent" & vbCrLf &
                       "without unit, 0.1 <= 1/n <= 1.3 , std.= 0.9" & vbCrLf &
                       "Your input is not valid : " & vBASEFreundlich,
                       MsgBoxStyle.Exclamation)
            End If


        End Set
    End Property

#End Region


#Region "Summary"

    Public Const Click2EditString As String = "PRZM Freundlich Sorption"

    ''' <summary>
    ''' Summary temp. and moist. corr. 
    ''' click 1st line to edit
    ''' </summary>
    <Category(CATOutput)>
    <DisplayName("Summary")>
    <Browsable(False)>
    Public ReadOnly Property Summary As String()
        Get
            Return getPRZM_FreundlichSorption_Summary()
        End Get
    End Property

    Public Function getPRZM_FreundlichSorption_Summary() As String()

        Dim Summary As New List(Of String)


        cPRZM_FreundlichSorption.PGridConverter.PGridItemName = "PRZM Freundlich Sorption Settings"

        With Summary

            .Add("Click here to edit " & Click2EditString)


            Select Case Me.KdMode

                Case eKdMode.FOCUSstd


                    If Me.KOC = NoEntry Then

                        .Add("No KOC is set, please check in then parent dialog")

                    Else

                        .Add("FOCUS std. sorption values according to OC content")
                        .Add("KOC = " & Me.KOC & " L/kg")
                        .Add("      Layer01  Layer02  Layer03  Layer04")

                        .AddRange(Me.FOCUSPRZMSorption)

                    End If

                Case eKdMode.Individual

                    If Me.ScenarioPRZMSorption.First.Length < 5 Then Return Summary.ToArray

                    .Add("Scenario specific sorption values ")
                    .Add("      Layer01  Layer02  Layer03  Layer04")

                    .AddRange(Me.ScenarioPRZMSorption)

                Case eKdMode.pH_Dependent

                    If Me.AcidPRZMSorption.First.Length < 5 Then Return Summary.ToArray


                    .Add("pH dependent sorption values")
                    .Add("Acid scenario")
                    .Add("      Layer01  Layer02  Layer03  Layer04")

                    .AddRange(Me.AcidPRZMSorption)

                    .Add("Base scenario")
                    .Add("      Layer01  Layer02  Layer03  Layer04")

                    .AddRange(Me.BasePRZMSorption)

            End Select

        End With


        Return Summary.ToArray


    End Function

#End Region


End Class



Public Class DepthDepDegSor


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_FacZTra As Double = -99

    ''' <summary>
    ''' FacZTra
    ''' </summary>
    <Category("")>
    <DisplayName("FacZTra")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(-99)>
    Public Property FacZTra As Double
        Get
            Return m_FacZTra
        End Get
        Set(vFacZTra As Double)
            m_FacZTra = vFacZTra
        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_FacZSor As Double = -99

    ''' <summary>
    ''' FacZSor
    ''' </summary>
    <Category("")>
    <DisplayName("FacZSor")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(-99)>
    Public Property FacZSor As Double
        Get
            Return m_FacZSor
        End Get
        Set(vFacZSor As Double)
            m_FacZSor = vFacZSor
        End Set
    End Property



End Class

