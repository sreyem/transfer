﻿


#Region "Imports System"

Imports System.ComponentModel
Imports System.Xml.Serialization

Imports System.Drawing.Design
Imports System.Windows.Forms
Imports System.Windows.Forms.Design

#End Region

#Region "Imports Toolbox"

Imports ToolBox

#End Region

Imports Testing.cFreundlichSorption

''' <summary>
''' Degradation in Soil
''' KOC/KOM Freundlich exponent etc.
''' </summary>
<Serializable>
<DescriptionAttribute("Degradation in Soil")>
<DefaultProperty("KOC_KOM")>
<DisplayName("Degradation in Soil")>
<TypeConverter(GetType(cDegradation.PGridConverter))>
Public Class cDegradation


#Region "Constructor"

    Public Sub New()

    End Sub

#End Region

#Region "PGrid Stuff"

    ''' <summary>
    ''' makes the class browsable for property grid
    ''' PGridItemName = name to display
    ''' </summary>
    Public Class PGridConverter

        Inherits ExpandableObjectConverter

        <RefreshProperties(RefreshProperties.All)>
        Public Shared Property PGridItemName As String = "Degradation in Soil"
        Public Shared Property ClassType As Type


#Region "Overloads Overrides"

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                         ByVal destinationType As Type) As Boolean

            Try
                If (destinationType Is GetType(cDegradation)) Then
                    Return True
                End If
            Catch ex As Exception

            End Try

            Return MyBase.CanConvertTo(context,
                                       destinationType)

        End Function

        Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

            If (destinationType Is GetType(System.String)) Then

                If value.GetType Is ClassType Then
                    Return PGridItemName
                End If

            End If

            Return MyBase.ConvertTo(context,
                                    culture,
                                    value,
                                    destinationType)

        End Function

#End Region

    End Class



    Public Sub showClassInPGrid()

        Dim dummy As String = ""
        Dim frmPgrid As New ToolBox.frmPGrid



        ' frmPgrid.Text = cPhysChemProp.PGridConverter.PGridItemName
        frmPgrid.PGrid.SelectedObject = Me

        frmPgrid.ShowDialog()

    End Sub

#End Region


#Region "Categories"



#End Region

    Public Property Degradation As Double = 9999

    <Browsable(False)>
    <DisplayName("Temp. and Moisture Correction")>
    <RefreshProperties(RefreshProperties.All)>
    Public Property TempMoistCorrDT50Soil As New cTempMoistCorrDT50Soil


    <DisplayName("Temp. and Moist. Correction")>
    <RefreshProperties(RefreshProperties.All)>
    Public ReadOnly Property TempMoistCorrDT50SoilSummary As String()
        Get
            Return TempMoistCorrDT50Soil.Summary
        End Get
    End Property



    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_SFO As New cSFO

    ''' <summary>
    ''' SFO
    ''' </summary>
    <Category("")>
    <DisplayName("SFO")>
    <Description("Single first order degradation" & vbCrLf &
                 "M(t)=M0*exp(-k*t)")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public Property SFO As cSFO
        Get
            Return m_SFO
        End Get
        Set(vSFO As cSFO)
            m_SFO = vSFO
        End Set
    End Property

   

#Region "Summary"


    <Category()>
    <Browsable(False)>
    Public ReadOnly Property Summary As String()
        Get
            Return getSoilDegradationSummary()
        End Get
    End Property


    Public Const Click2EditString As String = "soil degradation"

    Public Function getSoilDegradationSummary() As String()

        Dim Summary As New List(Of String)
       

        With Summary

            .Add("Click here to edit " & Click2EditString)
            .Add("")
            .Add(Me.TempMoistCorrDT50SoilSummary(1))
            .Add(Me.TempMoistCorrDT50SoilSummary(2))
        End With

        Return Summary.ToArray

    End Function

    



#End Region



End Class



''' <summary>
''' Degradation in Soil
''' KOC/KOM Freundlich exponent etc.
''' </summary>
<Serializable>
<DescriptionAttribute("Single First Order")>
<DefaultProperty("DT50")>
<DisplayName("Single First Order")>
<TypeConverter(GetType(cSFO.PGridConverter))>
Public Class cSFO


#Region "Constructor"

    Public Sub New()
        cSFO.PGridConverter.PGridItemName = "Please define DT50"
    End Sub

#End Region




#Region "PGrid Stuff"

    ''' <summary>
    ''' makes the class browsable for property grid
    ''' PGridItemName = name to display
    ''' </summary>
    Public Class PGridConverter

        Inherits ExpandableObjectConverter

        <RefreshProperties(RefreshProperties.All)>
        Public Shared Property PGridItemName As String = "Single First Order"
        Public Shared Property ClassType As Type


#Region "Overloads Overrides"

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                         ByVal destinationType As Type) As Boolean

            Try
                If (destinationType Is GetType(cSFO)) Then
                    Return True
                End If
            Catch ex As Exception

            End Try

            Return MyBase.CanConvertTo(context,
                                       destinationType)

        End Function

        Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

            If (destinationType Is GetType(System.String)) Then

                If value.GetType Is GetType(cSFO) Then
                    Return PGridItemName
                End If

            End If

            Return MyBase.ConvertTo(context,
                                    culture,
                                    value,
                                    destinationType)

        End Function

#End Region

    End Class



    Public Sub showClassInPGrid()

        Dim dummy As String = ""
        Dim frmPgrid As New ToolBox.frmPGrid



        'frmPgrid.Text = cPhysChemProp.PGridConverter.PGridItemName
        frmPgrid.PGrid.SelectedObject = Me

        frmPgrid.ShowDialog()

    End Sub

#End Region




    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_DT50 As Double = 9999

    ''' <summary>
    ''' DT50
    ''' </summary>
    <Category("")>
    <DisplayName("DT50")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(9999)>
    Public Property DT50 As Double
        Get
            Return m_DT50
        End Get
        Set(vDT50 As Double)
            m_DT50 = vDT50
            RaiseEvent UserInput(m_DT50)
        End Set
    End Property

    <RefreshProperties(RefreshProperties.All)>
   <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
   <Browsable(True)>
   <[ReadOnly](True)>
    Public ReadOnly Property DT90 As String
        Get

            Return Math.Round(Math.Log(10) / (Math.Log(2) / DT50), 1).ToString("0.0")

        End Get
    End Property
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    Public ReadOnly Property RateConstant As String
        Get
            Return Math.Round(Math.Log(2) / DT50, 5).ToString("0.00000")
        End Get
    End Property




    Public Event UserInput(DT50 As Double)



    Private Sub cSFO_UserInput(DT50 As Double) Handles Me.UserInput

        If DT50 = 9999 Then
            cSFO.PGridConverter.PGridItemName = "Please define DT50"
        Else
            cSFO.PGridConverter.PGridItemName = "DT50 = " & Me.DT50 & " days (DT90 = " & Me.DT90 & " days)"
        End If



    End Sub
End Class



''' <summary>
''' Summary
''' Summary 
''' </summary>
<Serializable>
<DescriptionAttribute("Summary to show in PGrid")>
<DefaultProperty("Summary")>
<DisplayName("Summary test name")>
<TypeConverter(GetType(cSummary.PGridConverter))>
Public Class cSummary


#Region "Constructor"

    Public Sub New()

    End Sub

#End Region


#Region "PGrid Stuff"

    ''' <summary>
    ''' makes the class browsable for property grid
    ''' PGridItemName = name to display
    ''' </summary>
    Public Class PGridConverter

        Inherits ExpandableObjectConverter

        <RefreshProperties(RefreshProperties.All)>
        Public Shared Property PGridItemName As String = "Summary"
        Public Shared Property ClassType As Type


#Region "Overloads Overrides"

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                         ByVal destinationType As Type) As Boolean

            Try
                If (destinationType Is GetType(cSummary)) Then
                    Return True
                End If
            Catch ex As Exception

            End Try

            Return MyBase.CanConvertTo(context,
                                       destinationType)

        End Function

        Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

            If (destinationType Is GetType(System.String)) Then

                If value.GetType Is GetType(cSummary) Then
                    Return PGridItemName
                End If

            End If

            Return MyBase.ConvertTo(context,
                                    culture,
                                    value,
                                    destinationType)

        End Function

#End Region

    End Class



    Public Sub showClassInPGrid()

        Dim dummy As String = ""
        Dim frmPgrid As New ToolBox.frmPGrid



        'frmPgrid.Text = cPhysChemProp.PGridConverter.PGridItemName
        frmPgrid.PGrid.SelectedObject = Me

        frmPgrid.ShowDialog()

    End Sub

#End Region

    Public ReadOnly Property test As String
        Get
            Return Join(Overview, vbCrLf)
        End Get
    End Property

    Public Property Overview As String()





End Class

