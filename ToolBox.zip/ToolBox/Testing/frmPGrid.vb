﻿

















Public Class frmPGrid


    Public Property testTemplate As New ToolBox.cPerfectClassTemplate

    Public Sub New()




        ' Dieser Aufruf ist für den Designer erforderlich.
        InitializeComponent()

        ' Fügen Sie Initialisierungen nach dem InitializeComponent()-Aufruf hinzu.


        Dim frmtest As New frmPGrid

        frmtest.PGrid.SelectedObject = testTemplate




    End Sub

End Class