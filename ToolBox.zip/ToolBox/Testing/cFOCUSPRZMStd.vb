﻿











#Region "System Imports"

Imports System.IO
Imports System.Xml.Serialization
Imports System.ComponentModel

#End Region


Imports FOCUSswBasic.Step34

<Serializable>
<DescriptionAttribute("PRZM")>
<DefaultProperty("")>
<DisplayName("PRZM")>
<TypeConverter(GetType(cFOCUSPRZMStd.PGridConverter))>
Public Class cFOCUSPRZMStd

#Region "Constructor"

    Public Sub New()


    End Sub

#End Region

#Region "PGrid Stuff"

    ''' <summary>
    ''' makes the class browsable for property grid
    ''' PGridItemName = name to display
    ''' </summary>
    Public Class PGridConverter

        Inherits ExpandableObjectConverter

        <RefreshProperties(RefreshProperties.All)>
        Public Shared Property PGridItemName As String = "PRZM"
        Public Shared Property ClassType As Type


#Region "Overloads Overrides"

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                         ByVal destinationType As Type) As Boolean

            Try
                If (destinationType Is GetType(cTempMoistCorrDT50Soil)) Then
                    Return True
                End If
            Catch ex As Exception

            End Try

            Return MyBase.CanConvertTo(context,
                                       destinationType)

        End Function

        Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

            If (destinationType Is GetType(System.String)) Then

                If value.GetType Is ClassType Then
                    Return PGridItemName
                End If

            End If

            Return MyBase.ConvertTo(context,
                                    culture,
                                    value,
                                    destinationType)

        End Function

#End Region

    End Class

#End Region


#Region "GUI"

    Public Const NoMet As String = "not defined"

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_ParentName As String = "Parent"

    ''' <summary>
    ''' ParentName
    ''' </summary>
    <Category("")>
    <DisplayName("ParentName")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue("Parent")>
    Public Property ParentName As String
        Get
            Return m_ParentName
        End Get
        Set(vParentName As String)
            m_ParentName = vParentName
        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_Met01Name As String = NoMet

    ''' <summary>
    ''' Met01Name
    ''' </summary>
    <Category("")>
    <DisplayName("Met01Name")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(NoMet)>
    Public Property Met01Name As String
        Get
            Return m_Met01Name
        End Get
        Set(vMet01Name As String)
            m_Met01Name = vMet01Name
        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_Met02Name As String = NoMet

    ''' <summary>
    ''' Met02Name
    ''' </summary>
    <Category("")>
    <DisplayName("Met02Name")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(NoMet)>
    Public Property Met02Name As String
        Get
            Return m_Met01Name
        End Get
        Set(vMet01Name As String)
            m_Met01Name = vMet01Name
        End Set
    End Property


    Public Enum ePathWay
        sequentiel
        parallel
        not_defined
    End Enum


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_PathWay As ePathWay = ePathWay.not_defined

    ''' <summary>
    ''' PathWay
    ''' </summary>
    <Category("")>
    <DisplayName("PathWay")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(CInt(ePathWay.not_defined))>
    Public Property PathWay As ePathWay
        Get
            Return m_PathWay
        End Get
        Set(vPathWay As ePathWay)
            m_PathWay = vPathWay
        End Set
    End Property



    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_PRZMCrop As ePRZMCrop = ePRZMCrop.Cereals_Winter

    ''' <summary>
    ''' PRZMCrop
    ''' </summary>
    <Category("")>
    <DisplayName("PRZMCrop")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(CInt(ePRZMCrop.Cereals_Winter))>
    <XmlIgnore>
    Public Property PRZMCrop As ePRZMCrop
        Get
            Return m_PRZMCrop
        End Get
        Set(vPRZMCrop As ePRZMCrop)
            m_PRZMCrop = vPRZMCrop
        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_inclDescription As Boolean = True

    ''' <summary>
    ''' inclDescription
    ''' </summary>
    <Category("")>
    <DisplayName("inclDescription")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(True)>
    Public Property inclDescription As Boolean
        Get
            Return m_inclDescription
        End Get
        Set(vinclDescription As Boolean)
            m_inclDescription = vinclDescription
        End Set
    End Property


    ''' <summary>
    ''' FOCUSStdINIParts
    ''' </summary>
    <Category("")>
    <DisplayName("FOCUSStdINIParts")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public ReadOnly Property FOCUSStdINIParts As List(Of cFOCUSStdINPParts)
        Get
            Return getFOCUSStdINPParts(PRZMCrop)
        End Get
    End Property

    Public Enum eNo
        _01
        _02
        _03
        _04
        _05
        _06
        _07
        _08
    End Enum

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_Number As eNo = eNo._01

    ''' <summary>
    ''' Number
    ''' </summary>
    <Category("")>
    <DisplayName("Number")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(eNo._01)>
    Public Property Number As eNo
        Get
            Return m_Number
        End Get
        Set(vNumber As eNo)

            If vNumber < FOCUSStdINIParts.Count Then
                m_Number = vNumber
            Else
                m_Number = eNo._01
            End If

            Dim temp As New List(Of String())
            temp = createINPFiles4Crop(Me.PRZMCrop, Me.inclDescription)

            Try
                FirstINIPart = temp(Number)
            Catch ex As Exception
                FirstINIPart = temp(eNo._01)
            End Try

        End Set
    End Property



    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_FirstINIPart As New List(Of String())

    ''' <summary>
    ''' FirstINIPart
    ''' </summary>
    <Category("")>
    <DisplayName("FirstINIPart")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    Public Property FirstINIPart As String()



#End Region


#Region "Constants"

    'run file
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    <XmlIgnore>
    Public Const PRZM_ZONES_SearchString As String = "PRZM ZONES"
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    <XmlIgnore>
    Public Const WeatherFileSearchString As String = "  METEOROLOGY"

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    <XmlIgnore>
    Public Const PRZMStdVersionString As String =
        "FOCUS_PRZM_SW_4.3.1, 27 Apr. 2015                       PRZM 4.63 Apr. 2015"

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    <XmlIgnore>
    Public Const SoilSeriesSearchString As String = "Soil Series:"


    'inp file
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    <XmlIgnore>
    Public Const RECORD02_Pos As Integer = 1

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    <XmlIgnore>
    Public Const RECORD03_Pos As Integer = 2

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    <XmlIgnore>
    Public Const RECORD07_Pos As Integer = 4

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    <XmlIgnore>
    Public Const RECORD09_Pos As Integer = 6

    Public Const COVMAX_Pos As Integer = 3

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    <XmlIgnore>
    Public Const RECORD09b_Pos As Integer = 8

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    <XmlIgnore>
    Public Const RECORD09c_Pos As Integer = 9

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    <XmlIgnore>
    Public Const RECORD09d_Pos As Integer = 10

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    <XmlIgnore>
    Public Const RECORD09e_Pos As Integer = 11

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    <XmlIgnore>
    Public Const RECORD16MetPart As String = " 1 0.000.0000 0.00 0.00"


    'relative position to 'Soil Series'

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    <XmlIgnore>
    Public Const RECORD20_RelPos As Integer = 1

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    <XmlIgnore>
    Public Const RECORD31_RelPos As Integer = 4

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    <XmlIgnore>
    Public Const RECORD32_RelPos As Integer = 5

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
   <XmlIgnore>
    Public Const HorizonStart_RelPos As Integer = 8

#End Region



#Region "Descriptions RECORD03 - RECORD09e"

    Public Property RECORD01 As String =
        "FOCUS_PRZM_SW_4.3.1, 27 Apr. 2015                       PRZM 4.63 Apr. 2015"

    Public Property RECORD03_06_Description As String() =
    {
        "*** PFAC    SFAC  IPEIND   ANETD  INICRP  ISCOND",
        "***",
        "*** PFAC   pan factor used to estimate daily evapo-transpiration, crop dependent, 0.69 < PFAC < 1",
        "*** SFAC   snow melt factor in cm/degrees Celsius above freezing FOCUS std. = 0.20",
        "*** IPEIND pan factor flag 0=pan_data_read (std), 1=temperature_data_read, 2=either_available_used",
        "*** ANETD  minimum depth of which evaporation is extracted (cm)",
        "*** INICRP & ISCOND  = crop number = 1",
        "*** ",
        "*** ---- RECORD 06 ----  ERFLAG  flag to calculate erosion, std. = 4 = MUSS",
        "4",
        "*** ---- RECORD 07 ----"
    }


    Public Property RECORD07_08_Description As String() =
   {
       "*** USLEK   USLELS  USLEP   AFIELD             IREG  SLP      HL",
       "***",
       "*** USLEK  universal soil loss equation (K) of soil erodibility,",
       "***        USDA soil class and oc dependend, 0.02 < USLEK < 0.6",
       "*** USLELS universal soil loss equation (LS) topographic factor, FOCUS std. 0.66",
       "*** USLEP  universal soil loss equation (P) practice factor, FOCUS std. 0.5",
       "*** ANETD  area of field or plot in hectares FOCUS std. = 0.45h",
       "*** IREG   location of NRCS 24-hour hyetograph",
       "*** SLP    land slope (%)",
       "*** HL     hydraulic length (m)",
       "*** ",
       "*** ---- RECORD 08 ----",
       "       1",
       "***  NDC No of different crops, std. = 1",
       "*** ",
       "*** ---- RECORD 09 ----"
   }

    Public Property RECORD09_9b_Description As String() =
   {
       "***  CPN  CINTCP   AMXDR  COVMAX   ICNAH          CN   WFMAX   HTMAX",
       "*** ",
       "*** CPN Crop number",
       "*** CINTCP maximum interception storage of the crop (cm)",
       "*** AMXDR  maximum rooting depth of the crop (cm)",
       "*** COVMAX maximum areal coverage of the canopy (percent)",
       "*** ICNAH  is ignored when ERFLAG > 0, set to 3",
       "*** CN     runoff curve numbers of antecedent moisture condition II for fallow,",
       "***        cropping, and residue (3 values)",
       "*** WFMAX  maximum dry weight of the crop at full canopy (kg m/2)",
       "***        required if CAM = 3, else = 0",
       "*** HTMAX  max. canopy height at maturation date (cm)",
       "*** ",
       "*** ---- RECORD 09a ----",
       "       1       4",
       "*** Crop  NUSLEC  =  number of USLEC factors std. = 4",
       "*** ",
       "*** ---- RECORD 09b ---- ddMM of Emergence, Maturity, Harvest",
       "***                      and Fallow of USLEC Manning's N and curve numbers"
   }


    Public Property RECORD9c_Description As String() =
  {
      "*** ",
      "*** ---- RECORD 09c ---- USLEC "
  }

    Public Property RECORD9d_9e_Description As String() =
   {
       "*** ",
       "*** ---- RECORD 09d ---- Manning's N",
       "0.10 0.10 0.10 0.10",
       "*** ---- RECORD 09e ---- Curve # from 1st horizon"
   }

    Public Property RECORD10_11_Description As String() =
   {
       "*** ",
       " ---- RECORD 10  ---- NCPDS = Number of cropping periods",
       "      20",
       "*** ",
       "*** ---- RECORD 11  ---- Crop Events",
       "***  EMG     MAT     HAR  crop #"
   }

    Public Property RECORD13_Description As String() =
  {
      "*** ",
      "Chemical Input Data:",
      "*** ---- RECORD 13 ----"
  }



    Public Property RECORD16_Description As String() =
{
      "*** ",
      "*** ---- RECORD 16 ---- ",
      "*** ",
      "*** 01     WINDAY  number of days in which to check soil moisture values, std. = 0 (off)",
      "*** 02     CAM",
      "*** DEPI   depth of the pesticide(s) application (cm) std. = 4cm",
      "*** TAPP   target application rate of the pesticide(s) (kg/ha)",
      "*** APPEFF application efficiency (fraction) std. = 1.00",
      "*** DRFT   spray drift (fraction) std = 0",
      "*** ",
      "*** Date 0102 DEPI  TAPP  Eff DRFT"
}


    Public Property RECORD20_Description As String() =
 {
     "*** ",
     "*** ---- RECORD  20 ----",
     "*** CORED  total depth of soil core in cm",
     "*** BD     bulk density flag. 0 = std. = use values from RECORD 33, 1 = mineral value entered ",
     "*** TH     field capacity and wilting point flag. 0 = std. = user values, 1 = calculated by the model ",
     "*** KD     soil/pesticide adsorption coefficient 2 = std. = user input RECORD 37, 1/n = RECORD 30A",
     "*** HS     drainage flag, 0 = std. = free draining, 1 = restricted",
     "*** MOC    method of characteristics flag. 1=yes, 0 = std. = no ",
     "*** IR     irrigation flag 0 = std. = no irrigation, 1 = year round, 2 = during cropping period only",
     "*** IT     soil temperature simulation flag. 1 or 2 = std. = yes, 0=no ",
     "*** ID     thermal conductivity and heat capacity flag. 2 = std. = on, 0 = off ",
     "*** BIO    biodegradation flag. 1  = on, 0 = std. = off",
     "*** ",
     "*** CORED         BD  TH  KD  HS MOC  IR  IT  ID BIO"
 }

    Public Property RECORD26_Description As String() =
{
    "*** ",
    "*** ---- RECORD 26  ----",
    "*** 01 DAIR    Parent diffusion coefficient for the pesticide(s) in the air ",
    "***            std. = 4300 cm^2/day)",
    "*** 02 HENRYK  Parent Henry's law constant of the pesticide(s)",
    "*** 03 ENPY    Parent enthalpy of vaporization of the pesticide(s) std. = 22.7 kcal/mole"
}

    Public Property RECORD31_Description As String() =
{
   "*** ",
   "*** ---- RECORD 31  ----",
   "***   ALBEDO monthly values of soil surface albedo",
   "*** + EMMISS reflectivity of soil surface std = 0.96",
   "*** + ZWIND  height of wind speed std. = 10ms"
}


    Public Property RECORD32_Description As String() =
{
    "*** ",
    "*** ---- RECORD 32   ----",
    "*** Average monthly values of bottom boundary soil temperatures in °C, std. = 10°C"
}


    Public Property RECORD34_38_Description As String() =
  {
        "*** ",
        "*** ---- RECORD 34  ----",
        "*** HOR#  horizon number in relation to NHORIZ",
        "*** THKNS thickness of the horizon in cm",
        "*** BD    bulk density in kg/L ",
        "*** THETO initial soil water content in the horizon in cm^3/cm^3",
        "*** AD    soil drainage parameter if HSWZT = 1, else set to 0.0 ",
        "*** DISP  pesticide(s) hydrodynamic solute dispersion coefficient for each NCHEM, std. = 0 ",
        "*** ADL   lateral soil drainage parameter if HSWZT = 1, std. = 0",
        "*** ",
        "*** ---- RECORD 36  ----",
        "*** PAR/MET_RATE  dissolved phase pesticide(s) decay rate in 1/day",
        "*** ",
        "*** ---- RECORD 37  ----",
        "*** DPN   thickness of compartments in the horizon in cm",
        "*** THEFC field capacity in the horizon in cm^3/cm^3",
        "*** THEWP wilting point in the horizon in cm^3/cm^3",
        "*** OC    organic carbon in the horizon in %",
        "*** KD    pesticide(s) partition coefficient for each NCHEM. Required if",
        "***       KDFLAG = 0, 2, or 3 (see record 20), else set to 0.0 (cm-3 g-1) ",
        "*** Parent KOC = 43 no Metabolite",
        "*** ",
        "*** ---- RECORD 38  ----",
        "*** SPT    initial temp. of the horizon (Celsius)",
        "*** SAND   sand content in the horizon (percent)",
        "*** CLAY   clay content in the horizon (percent)",
        "*** THCOND thermal conductivity of the horizon (cm-1 day-1) std. = 0.00",
        "*** VHTCAP heat capacity per unit volume of the soil horizon (cm-3 Celsius-1) std. = 0.00",
        "*** ",
        "*** ----------------------------------------------------------------------------"
  }



#End Region


#Region "functions"


    Public Sub fillStd(MasterPath As String)

        Dim INPFilePaths As String() = {}
        Dim INPFilePath As String = ""
        Dim INPFile As String() = {}
        Dim RunFilePath As String = ""
        Dim RunFile As String() = {}
        Dim Temp As String = ""

        Dim SoilSeriesPos As Integer = 0
        Dim NoOfHorizons As Integer = 0
        Dim HorRowCounter As Integer = 0

        Const EarlyAppln As String = "_early_applns"
        Const LateAppln As String = "_late_applns"

        Const FirstSeason As String = "_1st"
        Const SecondSeason As String = "_2nd"

        Try

            INPFilePaths = Directory.GetFiles(
                                        path:=MasterPath,
                                        searchPattern:="*.inp",
                                        searchOption:=SearchOption.AllDirectories)

        Catch ex As Exception

            MsgBox(ex.Message)
            Exit Sub

        End Try

        For Counter As Integer = 0 To INPFilePaths.Count - 1


            INPFilePath = INPFilePaths(Counter)
            RunFilePath = Path.ChangeExtension(INPFilePath, ".run")

            'skip late appns
            If INPFilePath.Contains(LateAppln) Then Continue For


            Try
                INPFile = File.ReadAllLines(INPFilePath)
            Catch ex As Exception

                Debug.WriteLine(ex.Message)
                Exit Sub

            End Try

            'get 'Soil Series' position
            Do While SoilSeriesPos < INPFile.Count - 1
                If INPFile(SoilSeriesPos).StartsWith(SoilSeriesSearchString) Then Exit Do
                SoilSeriesPos += 1
            Loop


            Try
                RunFile = File.ReadAllLines(RunFilePath)
            Catch ex As Exception

                Debug.WriteLine(ex.Message)
                Exit Sub

            End Try


            If Not File.Exists(path:=RunFilePath) Then

                Debug.WriteLine("Not File.Exists(path:=RunFilePath)")
                Exit Sub
            End If

            Me.stdList.Add(New cFOCUSStdINPParts)


            With stdList(stdList.Count - 1)

                'PRZM_ZONES
                Try

                    .PRZM_ZONES = Filter(
                                     Source:=RunFile,
                                      Match:=PRZM_ZONES_SearchString,
                                    Include:=True).First

                Catch ex As Exception

                    Debug.WriteLine(ex.Message)
                    Exit Sub

                End Try


                'scenario
                Temp = Path.GetFileName(INPFilePath)

                Try

                    .PRZMScenario = CType([Enum].Parse(
                                        enumType:=GetType(ePRZMScenarios),
                                           value:=Temp.Substring(0, 2),
                                      ignoreCase:=True), ePRZMScenarios)

                Catch ex As Exception

                    Debug.WriteLine(ex.Message)
                    Exit Sub

                End Try


                'crop
                Temp = Path.GetDirectoryName(INPFilePath)

                If Temp.Contains("_2nd") Then
                    .Season = eSeasons.second
                Else
                    .Season = eSeasons.first
                End If

                'FOCUSStdPath & Filename
                .FOCUSStdPath = Replace(Expression:=Temp, Find:=MasterPath, Replacement:="")
                .FOCUSStdFilename = Path.GetFileNameWithoutExtension(INPFilePath)

                'clear season part of path
                Temp = Replace(Expression:=Temp, Find:=FirstSeason, Replacement:="")
                Temp = Replace(Expression:=Temp, Find:=SecondSeason, Replacement:="")


                'clear 
                Temp = Replace(Expression:=Temp, Find:=EarlyAppln, Replacement:="")

                Try
                    .PRZMCrop = CType([Enum].Parse(
                                        enumType:=GetType(ePRZMCrop),
                                           value:=Temp.Split({"\"c}).Last,
                                      ignoreCase:=True), ePRZMCrop)

                Catch ex As Exception

                    Debug.WriteLine(ex.Message)
                    Exit Sub

                End Try


                'weather file
                Try

                    .WeatherFile = Trim(Filter(Source:=RunFile,
                                           Match:=WeatherFileSearchString,
                                         Include:=True).First).Split.Last

                Catch ex As Exception

                    Debug.WriteLine(ex.Message)
                    Exit Sub

                End Try

                'INP file
                .RECORD02 = INPFile(RECORD02_Pos)
                .RECORD03 = INPFile(RECORD03_Pos)
                .RECORD07 = INPFile(RECORD07_Pos)
                .RECORD09 = INPFile(RECORD09_Pos)
                .RECORD09b = INPFile(RECORD09b_Pos)
                .RECORD09c = INPFile(RECORD09c_Pos)
                .RECORD09d = INPFile(RECORD09d_Pos)
                .RECORD09e = INPFile(RECORD09e_Pos)

                .RECORD20 = INPFile(SoilSeriesPos + RECORD20_RelPos)
                .RECORD31 = INPFile(SoilSeriesPos + RECORD31_RelPos)
                .RECORD32 = INPFile(SoilSeriesPos + RECORD32_RelPos)


                NoOfHorizons = Integer.Parse(Trim(INPFile(SoilSeriesPos + HorizonStart_RelPos)))


                For HorizonCounter As Integer = 1 To NoOfHorizons

                    .PRZMSoilHorizons.Add(New cPRZMSoilHorizon)

                    HorRowCounter = (SoilSeriesPos + HorizonStart_RelPos + 1) + ((HorizonCounter - 1) * 5)
                    With .PRZMSoilHorizons(.PRZMSoilHorizons.Count - 1)

                        .SoilPar01 = INPFile(HorRowCounter)
                        HorRowCounter += 2

                        .SoilPar02 = INPFile(HorRowCounter).Substring(0, 40)
                        .OC = Double.Parse(.SoilPar02.Split.Last)

                        HorRowCounter += 1
                        .SoilPar03 = INPFile(HorRowCounter)

                    End With


                Next




            End With

        Next

        updateOC()

    End Sub


    Public Function createINPFiles4Crop(PRZMCrop As ePRZMCrop,
                               Optional inclDescription As Boolean = True) As List(Of String())

        Dim Parts4Crop As New List(Of cFOCUSStdINPParts)
        Dim out As New List(Of String())
        Dim temp As New List(Of String)


        Parts4Crop = getFOCUSStdINPParts(PRZMCrop:=PRZMCrop)

        For FileCounter As Integer = 0 To Parts4Crop.Count - 1

            out.Add({})

            out(FileCounter) = createINP_FirstPart(
                    FOCUSStdINPParts:=Parts4Crop(FileCounter),
                     inclDescription:=inclDescription)

        Next


        Return out


    End Function


    Private Function createINP_FirstPart(ByRef FOCUSStdINPParts As cFOCUSStdINPParts,
                                      Optional inclDescription As Boolean = True) As String()

        Dim out As New List(Of String)

        Dim CropEvents As String() = {}
        Dim CropEventDates As New List(Of Date)
        Dim YearShift As New List(Of Integer)

        Dim TempRow As String = ""

        With FOCUSStdINPParts

            'my header
            If inclDescription Then
                out.Add("***")
                out.AddRange(ToolBox.ErrorHandling.getStartInfo(LeadingString:="*** "))
                out.Add("***")
            End If



            'RECORD 01 WINPRZM Version info
            If inclDescription Then
                out.Add("*** ---- RECORD 01 ----")
                out.Add("Version WINPRZM : PRZM 4.63 Apr. 2015")
                out.Add("***")
            Else
                out.Add(PRZMStdVersionString)
            End If


            'RECORD 02 Run info
            If inclDescription Then
                out.Add("*** ---- RECORD 02 ----")
                out.Add("Scenario : " & .PRZMScenario.ToString &
                        "    Crop : " & Replace(Expression:=.PRZMCrop.ToString,
                                                      Find:="_",
                                               Replacement:=" ") & ", " & .Season.ToString & " Season")
                out.Add("***")
            Else
                out.Add("                    Simulation Location: " & .PRZMScenario.ToString &
                        "Crop: " & Replace(Expression:=.PRZMCrop.ToString,
                                                 Find:="_",
                                          Replacement:=" "))
            End If



            If inclDescription Then out.Add("*** ---- RECORD 03 ----")
            out.Add(.RECORD03)
            If inclDescription Then out.AddRange(Me.RECORD03_06_Description)
            out.Add(.RECORD07)

            If inclDescription Then
                out.AddRange(Me.RECORD07_08_Description)
            Else
                out.Add("       1")
            End If

            out.Add(.RECORD09)


            FOCUSStdINPParts.MaxInterception =
                                CDbl(.RECORD09.Split({" "c},
                                                     StringSplitOptions.RemoveEmptyEntries)(COVMAX_Pos))
            If inclDescription Then
                out.AddRange(Me.RECORD09_9b_Description)
                out.Add(.RECORD09b)
            Else
                out.Add("       1       4")
            End If


            CropEvents = .RECORD09b.Split({" "c},
                                          StringSplitOptions.RemoveEmptyEntries)


            'emergency
            CropEventDates.Add(New Date(year:=1975,
                                        month:=CInt(CropEvents(0).Substring(2, 2)),
                                        day:=CInt(CropEvents(0).Substring(0, 2))))

            FOCUSStdINPParts.EMG = CropEventDates.Last

            YearShift.Add(0)

            If inclDescription Then out.Add("*** Emg = " & CropEventDates.Last.ToString("dd. MMM"))

            'maturity
            CropEventDates.Add(New Date(year:=1975,
                                        month:=CInt(CropEvents(1).Substring(2, 2)),
                                        day:=CInt(CropEvents(1).Substring(0, 2))))



            If CropEventDates(0).DayOfYear > CropEventDates(1).DayOfYear Then

                YearShift.Add(1)

                If inclDescription Then out.Add("*** Mat = " & CropEventDates.Last.ToString("dd. MMM") & " Year +1 !")
            Else
                YearShift.Add(0)
                If inclDescription Then out.Add("*** Mat = " & CropEventDates.Last.ToString("dd. MMM"))
            End If
            FOCUSStdINPParts.MAT = New Date(
                                year:=CropEventDates.Last.Year + YearShift.Last,
                               month:=CropEventDates.Last.Month,
                                 day:=CropEventDates.Last.Day)


            'harvest
            CropEventDates.Add(New Date(year:=1975,
                                        month:=CInt(CropEvents(2).Substring(2, 2)),
                                        day:=CInt(CropEvents(2).Substring(0, 2))))


            If CropEventDates(1).DayOfYear > CropEventDates(2).DayOfYear Then
                If inclDescription Then out.Add("*** Har = " & CropEventDates.Last.ToString("dd. MMM") & " Year +1 !")
                YearShift.Add(YearShift.Last + 1)
            Else
                If inclDescription Then out.Add("*** Har = " & CropEventDates.Last.ToString("dd. MMM") &
                        IIf(YearShift(1) = 1, " Year +1 !", "").ToString)

                YearShift.Add(YearShift.Last)
            End If

            FOCUSStdINPParts.HAR = New Date(
                              year:=CropEventDates.Last.Year + YearShift.Last,
                             month:=CropEventDates.Last.Month,
                               day:=CropEventDates.Last.Day)


            If inclDescription Then out.AddRange(Me.RECORD9c_Description)
            out.Add(.RECORD09c)
            If inclDescription Then out.AddRange(Me.RECORD9d_9e_Description)
            out.Add(.RECORD09e)
            If inclDescription Then out.AddRange(Me.RECORD10_11_Description)

            For YearCounter As Integer = 75 To 94

                TempRow = (CropEvents(0) & YearCounter.ToString).PadLeft("  010570".Length)

                out.Add((CropEvents(0) & (YearShift(0) + YearCounter).ToString).PadLeft("  010570".Length) &
                        (CropEvents(1) & (YearShift(1) + YearCounter).ToString).PadLeft("  010570".Length) &
                        (CropEvents(2) & (YearShift(2) + YearCounter).ToString).PadLeft("  010570".Length) &
                        "       1")

            Next

        End With

        Return out.ToArray

    End Function

    Private Function createApplnPart(Applns As List(Of cPRZMAppln),
                                Optional inclDescription As Boolean = True) As String()

        Dim out As New List(Of String)



        Return out.ToArray

    End Function


    Private Function getFOCUSStdINPParts(PRZMCrop As ePRZMCrop) As List(Of cFOCUSStdINPParts)

        Dim test = From res In Me.stdList
                     Where res.PRZMCrop = PRZMCrop
                     Order By res.PRZMScenario Ascending, res.Season Ascending
                     Select res


        Dim out As New List(Of cFOCUSStdINPParts)

        For Each temp In test

            out.Add(CType(temp, cFOCUSStdINPParts))

        Next


        Return out

    End Function


#End Region

#Region "XML in/out"


    Public Function saveFOCUSStd2XML(FilePath As String) As Boolean

        Try

            Return ToolBox.DeSerialize.Class2XML(
                         Class2Save:=Me,
                          ClassType:=GetType(cFOCUSPRZMStd),
                        XMLFileName:=FilePath)

            Return True

        Catch ex As Exception
            Return False
        End Try

    End Function

    Public Function loadFOCUStdFromXML(FilePath As String) As Boolean

        Dim Temp As New cFOCUSPRZMStd

        Try

            Temp = CType(ToolBox.DeSerialize.XML2Class(
                                    ClassType:=GetType(cFOCUSPRZMStd),
                                  XMLFileName:=FilePath), 
                              cFOCUSPRZMStd)


            Me.stdList.Clear()
            Me.stdList.AddRange(Temp.stdList)
            updateOC()

            Return True

        Catch ex As Exception
            Return False
        End Try

    End Function


    Public Function saveFOCUSStd2SOAP(FilePath As String) As Boolean

        Try

            Return ToolBox.DeSerialize.Class2SOAP(
                        Class2Save:=Me,
                       BINFileName:=FilePath)

            Return True

        Catch ex As Exception
            Return False
        End Try

    End Function

    Public Function loadFOCUStdFromSOAP(FilePath As String) As Boolean

        Dim Temp As New cFOCUSPRZMStd

        Try
            Temp = CType(ToolBox.DeSerialize.SOAP2Class(BINFileName:=FilePath), 
                                            cFOCUSPRZMStd)


            Me.stdList.Clear()
            Me.stdList.AddRange(Temp.stdList)
            updateOC()

            Return True

        Catch ex As Exception
            Return False
        End Try

    End Function


    Public Sub updateOC()

        Dim OC As New List(Of Double)

        For counter As Integer = 0 To Me.stdList.Count - 1

            With Me.stdList(counter)

                'veg. leafy with all R scenarios
                If .PRZMCrop = ePRZMCrop.Vegetables_leafy Then

                    OC.Clear()

                    For Each PRZMSoilHorizon As cPRZMSoilHorizon In .PRZMSoilHorizons
                        OC.Add(PRZMSoilHorizon.OC)
                    Next

                    If .PRZMScenario = ePRZMScenarios.R1 Then
                        R1_OC = OC.ToArray
                    End If

                    If .PRZMScenario = ePRZMScenarios.R2 Then
                        R2_OC = OC.ToArray
                    End If

                    If .PRZMScenario = ePRZMScenarios.R3 Then
                        R3_OC = OC.ToArray
                    End If

                    If .PRZMScenario = ePRZMScenarios.R4 Then
                        R4_OC = OC.ToArray
                        Exit For
                    End If

                    OC.Clear()

                End If

            End With

        Next

    End Sub

#End Region


    Public Property stdList As New List(Of cFOCUSStdINPParts)

    Public Shared Property R1_OC As Double() = {}
    Public Shared Property R2_OC As Double() = {}
    Public Shared Property R3_OC As Double() = {}
    Public Shared Property R4_OC As Double() = {}


    Public Property ApplnList As New List(Of cPRZMAppln)

End Class

<Serializable>
<DescriptionAttribute("PRZM")>
<DefaultProperty("")>
<DisplayName("PRZM")>
<TypeConverter(GetType(cFOCUSStdINPParts.PGridConverter))>
<DebuggerStepThrough>
Public Class cFOCUSStdINPParts

#Region "Constructor"

    Public Sub New()

    End Sub

#End Region

#Region "PGrid Stuff"

    ''' <summary>
    ''' makes the class browsable for property grid
    ''' PGridItemName = name to display
    ''' </summary>
    Public Class PGridConverter

        Inherits ExpandableObjectConverter

        <RefreshProperties(RefreshProperties.All)>
        Public Shared Property PGridItemName As String = "PRZM"
        Public Shared Property ClassType As Type


#Region "Overloads Overrides"

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                         ByVal destinationType As Type) As Boolean

            Try
                If (destinationType Is GetType(cTempMoistCorrDT50Soil)) Then
                    Return True
                End If
            Catch ex As Exception

            End Try

            Return MyBase.CanConvertTo(context,
                                       destinationType)

        End Function

        Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

            If (destinationType Is GetType(System.String)) Then

                If value.GetType Is ClassType Then
                    Return PGridItemName
                End If

            End If

            Return MyBase.ConvertTo(context,
                                    culture,
                                    value,
                                    destinationType)

        End Function

#End Region

    End Class

#End Region


    Public Property PRZMScenario As ePRZMScenarios = ePRZMScenarios.not_defined

    Public Property PRZMCrop As ePRZMCrop = ePRZMCrop.not_defined

    Public Property Season As eSeasons = eSeasons.first

    Public Property PRZM_ZONES As String = ""

    Public Property WeatherFile As String = ""

    Public Property FOCUSStdPath As String = ""

    Public Property FOCUSStdFilename As String = ""

    Public Property RECORD02 As String = ""

    Public Property RECORD03 As String = ""

    Public Property RECORD07 As String = ""

    Public Property RECORD09 As String = ""

    Public Property MaxInterception As Double = 0

    Public Property RECORD09b As String = ""

    Public Property EMG As New Date(year:=1975, month:=2, day:=5)
    Public Property MAT As New Date(year:=1975, month:=4, day:=15)
    Public Property HAR As New Date(year:=1975, month:=6, day:=20)

    Public Property RECORD09c As String = ""

    Public Property RECORD09d As String = ""

    Public Property RECORD09e As String = ""


    Public Property RECORD20 As String = ""

    Public Property RECORD31 As String = ""

    Public Property RECORD32 As String = ""

    Public Property PRZMSoilHorizons As New List(Of cPRZMSoilHorizon)

End Class

<Serializable>
<DescriptionAttribute("PRZM")>
<DefaultProperty("")>
<DisplayName("PRZM")>
<TypeConverter(GetType(cPRZMSoilHorizon.PGridConverter))>
<DebuggerStepThrough>
Public Class cPRZMAppln

#Region "Constructor"

    Public Sub New()

    End Sub

#End Region

#Region "PGrid Stuff"

    ''' <summary>
    ''' makes the class browsable for property grid
    ''' PGridItemName = name to display
    ''' </summary>
    Public Class PGridConverter

        Inherits ExpandableObjectConverter

        <RefreshProperties(RefreshProperties.All)>
        Public Shared Property PGridItemName As String = "PRZM"
        Public Shared Property ClassType As Type


#Region "Overloads Overrides"

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                         ByVal destinationType As Type) As Boolean

            Try
                If (destinationType Is GetType(cTempMoistCorrDT50Soil)) Then
                    Return True
                End If
            Catch ex As Exception

            End Try

            Return MyBase.CanConvertTo(context,
                                       destinationType)

        End Function

        Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

            If (destinationType Is GetType(System.String)) Then

                If value.GetType Is ClassType Then
                    Return PGridItemName
                End If

            End If

            Return MyBase.ConvertTo(context,
                                    culture,
                                    value,
                                    destinationType)

        End Function

#End Region

    End Class

#End Region

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_ApplnDate As Date = New Date(year:=1975, month:=1, day:=1)

    ''' <summary>
    ''' ApplnDate
    ''' </summary>
    <Category("")>
    <DisplayName("ApplnDate")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public Property ApplnDate As Date
        Get
            Return m_ApplnDate
        End Get
        Set(vApplnDate As Date)
            m_ApplnDate = vApplnDate
        End Set
    End Property



    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_CAM As eCAM = eCAM.FoliarLinear_2

    ''' <summary>
    ''' CAM
    ''' </summary>
    <Category("")>
    <DisplayName("CAM")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(CInt(eCAM.FoliarLinear_2))>
    Public Property CAM As eCAM
        Get
            Return m_CAM
        End Get
        Set(vCAM As eCAM)
            m_CAM = vCAM
        End Set
    End Property



    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_Depth As Double = 4.0

    ''' <summary>
    ''' Depth
    ''' </summary>
    <Category("")>
    <DisplayName("Depth")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(4.0)>
    Public Property Depth As Double
        Get
            Return m_Depth
        End Get
        Set(vDepth As Double)
            m_Depth = vDepth
        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_Rate As Double = 0.9999

    ''' <summary>
    ''' Rate
    ''' </summary>
    <Category("")>
    <DisplayName("Rate")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0.9999)>
    Public Property Rate As Double
        Get
            Return m_Rate
        End Get
        Set(vRate As Double)
            m_Rate = vRate
        End Set
    End Property


    Public ReadOnly Property Output As String
        Get
            Dim out As String = ""

            out = "  "

            If Me.ApplnDate.Day < 10 Then  out &= " "          
            out &= Me.ApplnDate.Day.ToString

            If Me.ApplnDate.Month < 10 Then out &= " "
            out &= Me.ApplnDate.Month.ToString


            out &= Me.ApplnDate.Year.ToString.Substring(2, 2)
            out &= "  0"
            out &= " " & CInt(Me.CAM).ToString & " "
            out &= Me.Depth.ToString("0.00")
            out &= Me.Rate.ToString("0.0000")
            out &= " 1.00 0.00"

            Return out

        End Get
    End Property


End Class


<Serializable>
<DescriptionAttribute("PRZM")>
<DefaultProperty("")>
<DisplayName("PRZM")>
<TypeConverter(GetType(cPRZMSoilHorizon.PGridConverter))>
<DebuggerStepThrough>
Public Class cPRZMSoilHorizon

#Region "Constructor"

    Public Sub New()

    End Sub

#End Region

#Region "PGrid Stuff"

    ''' <summary>
    ''' makes the class browsable for property grid
    ''' PGridItemName = name to display
    ''' </summary>
    Public Class PGridConverter

        Inherits ExpandableObjectConverter

        <RefreshProperties(RefreshProperties.All)>
        Public Shared Property PGridItemName As String = "PRZM"
        Public Shared Property ClassType As Type


#Region "Overloads Overrides"

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                         ByVal destinationType As Type) As Boolean

            Try
                If (destinationType Is GetType(cTempMoistCorrDT50Soil)) Then
                    Return True
                End If
            Catch ex As Exception

            End Try

            Return MyBase.CanConvertTo(context,
                                       destinationType)

        End Function

        Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

            If (destinationType Is GetType(System.String)) Then

                If value.GetType Is ClassType Then
                    Return PGridItemName
                End If

            End If

            Return MyBase.ConvertTo(context,
                                    culture,
                                    value,
                                    destinationType)

        End Function

#End Region

    End Class

#End Region


    Public Property OC As Double = 0

    Public Property SoilPar01 As String = ""

    Public Property SoilPar02 As String = ""

    Public Property SoilPar03 As String = ""

End Class


<Serializable>
<DescriptionAttribute("PRZM")>
<DefaultProperty("")>
<DisplayName("PRZM")>
<TypeConverter(GetType(cPRZMSoilHorizon.PGridConverter))>
<DebuggerStepThrough>
Public Class cPRZMWeather

#Region "Constructor"

    Public Sub New()

    End Sub

#End Region

#Region "PGrid Stuff"

    ''' <summary>
    ''' makes the class browsable for property grid
    ''' PGridItemName = name to display
    ''' </summary>
    Public Class PGridConverter

        Inherits ExpandableObjectConverter

        <RefreshProperties(RefreshProperties.All)>
        Public Shared Property PGridItemName As String = "PRZM"
        Public Shared Property ClassType As Type


#Region "Overloads Overrides"

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                         ByVal destinationType As Type) As Boolean

            Try
                If (destinationType Is GetType(cTempMoistCorrDT50Soil)) Then
                    Return True
                End If
            Catch ex As Exception

            End Try

            Return MyBase.CanConvertTo(context,
                                       destinationType)

        End Function

        Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

            If (destinationType Is GetType(System.String)) Then

                If value.GetType Is ClassType Then
                    Return PGridItemName
                End If

            End If

            Return MyBase.ConvertTo(context,
                                    culture,
                                    value,
                                    destinationType)

        End Function

#End Region

    End Class

#End Region




End Class


