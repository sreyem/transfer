﻿




#Region "Imports System"

Imports System.ComponentModel
Imports System.Xml.Serialization

#End Region

#Region "Imports Toolbox"

Imports ToolBox

#End Region



''' <summary>
''' SOIL degradation 
''' temperature and moisture correction  
''' </summary>
<Serializable>
<DescriptionAttribute("Time dependent Sorption")>
<DefaultProperty("CofDesRat")>
<TypeConverter(GetType(cTDS.PGridConverter))>
<DisplayName("Time dependent Sorption")>
Public Class cTDS



#Region "Constructor"

    Public Sub New()

    End Sub

#End Region

#Region "PGrid Stuff"

    ''' <summary>
    ''' makes the class browsable for property grid
    ''' PGridItemName = name to display
    ''' </summary>
    Public Class PGridConverter

        Inherits ExpandableObjectConverter

        <RefreshProperties(RefreshProperties.All)>
        Public Shared Property PGridItemName As String = "Moisture and Temperature correction"
        Public Shared Property ClassType As Type


#Region "Overloads Overrides"

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                         ByVal destinationType As Type) As Boolean

            Try
                If (destinationType Is GetType(cTempMoistCorrDT50Soil)) Then
                    Return True
                End If
            Catch ex As Exception

            End Try

            Return MyBase.CanConvertTo(context,
                                       destinationType)

        End Function

        Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

            If (destinationType Is GetType(System.String)) Then

                If value.GetType Is ClassType Then
                    Return PGridItemName
                End If

            End If

            Return MyBase.ConvertTo(context,
                                    culture,
                                    value,
                                    destinationType)

        End Function

#End Region

    End Class

#End Region


#Region "Categories"


    Public Const frmTitle As String = "Time dependent sorption Parameters"
    Private Const CATPartitionCoefficient As String = "01 Partition Coefficient"
    Private Const CATPEARL As String = "02  PEARL "
    Private Const CATMACRO As String = "03  MACRO"
    Private Const CATPRZM As String = "04  PRZM"

    Private Const CATOutput As String = "05  Output"



#End Region


    Public Property Sorption As New cKOC_KOM


#Region "PEARL"


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_DT50eq As Double = 9999

    ''' <summary>
    ''' DT50eq
    ''' The degradation half-life
    ''' in the equilibrium compartment
    ''' </summary>
    <Category(CATPEARL)>
    <DisplayName("DT50eq")>
    <Description("The degradation half-life" & vbCrLf &
                 "in the equilibrium compartment")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(9999)>
    Public Property DT50eq As Double
        Get
            Return m_DT50eq
        End Get
        Set(vDT50eq As Double)
            m_DT50eq = vDT50eq
        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_KOMeq As Double = 9999

    ''' <summary>
    ''' KOMeq in L/kg
    ''' Organic MATTER normalized distribution coefficient
    ''' in the equilibrium compartment
    ''' </summary>
    <Category(CATPEARL)>
    <DisplayName("KOMeq")>
    <Description("Organic MATTER normalized distribution coefficient" & vbCrLf &
                 "in the equilibrium compartment in L/kg [0|1e9]")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(9999)>
    Public Property KOMeq As Double
        Get
            Return m_KOMeq
        End Get
        Set(vKOMeq As Double)


            If vKOMeq <= 0 AndAlso vKOMeq >= 1000000000.0 Then

                If vKOMeq > 10000.0 Then

                    If MsgBox(Prompt:="KOMeq > 10,000 is strange, continue?",
                             Buttons:=MsgBoxStyle.OkCancel,
                               Title:="User Input seems to be wrong") = MsgBoxResult.Cancel Then
                        Exit Property

                    End If

                End If

                m_KOMeq = vKOMeq
                m_KOCeq = Math.Round(m_KOMeq * 1.724, Me.Digits)

            Else
                MsgBox("Organic MATTER normalized distribution coefficient" & vbCrLf &
                       "in L/kg, 0 <= KOMeq <= 1e9" & vbCrLf &
                       "Your input is not valid : " & vKOMeq,
                       MsgBoxStyle.Exclamation)
            End If

        End Set
    End Property



    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_Freundlich As Double = 0.9999

    ''' <summary>
    ''' Freundlich sorption exponent 1/n [0.1|1.3]
    ''' ExpFre (PEARL) FRNDCF (PRZM) FREUND (MACRO)
    ''' </summary>
    <Category(CATPEARL)>
    <DisplayName("Freundlich")>
    <Description("Freundlich sorption exponent 1/n [0.1|1.3]" & vbCrLf &
                 "ExpFre (PEARL/TOXSWA) FRNDCF (PRZM) FREUND (MACRO)")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0.9999)>
    Public Property Freundlich As Double
        Get
            Return m_Freundlich
        End Get
        Set(vFreundlich As Double)

            If vFreundlich <= 1.3 AndAlso vFreundlich >= 0.1 Then

                If vFreundlich > 0.7 Then

                    If MsgBox(Prompt:="Freundlich exponent < 0.7 is strange, continue?",
                             Buttons:=MsgBoxStyle.OkCancel,
                               Title:="User Input seems to be wrong") = MsgBoxResult.Cancel Then
                        Exit Property

                    End If

                End If

                m_Freundlich = vFreundlich

            Else
                MsgBox("Freundlich exponent" & vbCrLf &
                       "without unit, 0.1 <= 1/n <= 1.3 , std.= 0.9" & vbCrLf &
                       "Your input is not valid : " & vFreundlich,
                       MsgBoxStyle.Exclamation)
            End If


        End Set
    End Property




    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_kDes As Double = 0.0

    ''' <summary>
    ''' kDes
    ''' Desorption rate coefficient in PEARL
    ''' per day , off = 0 [0|0.5]
    ''' CofDesRat
    ''' </summary>
    <Category(CATPEARL)>
    <DisplayName("Kdes")>
    <Description("Desorption rate coefficient Kdes in PEARL" & vbCrLf &
                 "per day , off = 0 [0|0.5], CofDesRat")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0.0)>
    Public Property kDes As Double
        Get
            Return m_kDes
        End Get
        Set(vkDes As Double)
            m_kDes = vkDes
            RaiseEvent Data_Change()
        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_fNE As Double = 0.0

    ''' <summary>
    ''' fNE
    ''' FacSorNeqEql CofFreNeq/CofFreEql in PEARL  
    ''' no unit, off = 0 [0|-]
    ''' </summary>
    <Category(CATPEARL)>
    <DisplayName("fNE")>
    <Description("CofFreNeq/CofFreEql fNE in PEARL" & vbCrLf &
                 "no unit, off = 0 [0|-], FacSorNeqEql")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0.0)>
    Public Property fNE As Double
        Get
            Return m_fNE
        End Get
        Set(vfNE As Double)
            m_fNE = vfNE
            RaiseEvent Data_Change()
        End Set
    End Property



#End Region


#Region "MACRO"

    
    ''' <summary>
    ''' Digits for conversion of 
    ''' KOC to KOM and vice versa
    ''' std. = 2
    ''' </summary>
    <Category(CATMACRO)>
    <DisplayName("KOCvsKOM Digits")>
    <Description("Digits for conversion of" & vbCrLf &
                 "KOC to KOM and vice versa, std. = 2")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(2)>
    Public Property Digits As Integer = 2


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_KOCeq As Double = 9999

    ''' <summary>
    ''' KOCeq
    ''' Organic CARBON CONTENT normalized distribution coefficient
    ''' in the equilibrium compartment
    ''' </summary>
    <Category(CATMACRO)>
    <DisplayName("KOCeq")>
    <Description("Organic CARBON CONTENT normalized distribution coefficient" & vbCrLf &
                 "in the equilibrium compartment")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(9999)>
    Public Property KOCeq As Double
        Get
            Return m_KOCeq
        End Get
        Set(vKOCeq As Double)

            m_KOCeq = vKOCeq
            m_KOMeq = Math.Round(m_KOCeq / 1.724, Me.Digits)

        End Set
    End Property


    ''' <summary>
    ''' KINETIC
    ''' Switch TDS on (1) or off (0)
    ''' </summary>
    <Category(CATMACRO)>
    <DisplayName("KINETIC")>
    <Description("Switch TDS on (1) or off (0)")>
    Public ReadOnly Property KINETIC As String
        Get

            If FRACEQ <> 0 AndAlso SORPRATE <> 0 Then
                Return "KINETIC	1"
            Else
                Return "KINETIC	0"
            End If

        End Get
    End Property


    ''' <summary>
    ''' FRACEQ
    ''' no unit
    ''' </summary>
    ''' <remarks>
    '''             1
    ''' FRACEQ  = --------
    '''           1 + fNE
    '''
    ''' </remarks> 
    <Category(CATMACRO)>
    <DisplayName("FRACEQ")>
    <Description("FRACEQ  = 1 / (1+fNE), no unit")>
    Public ReadOnly Property FRACEQ As Double
        Get
            Return Math.Round(1 / (1 + fNE), 4)
        End Get
    End Property


    ''' <summary>
    ''' SORPRATE
    ''' in 1/day
    ''' </summary>
    ''' <remarks>          
    ''' SORPRATE  = Kdes * FRACEQ
    ''' </remarks> 
    <Category(CATMACRO)>
    <DisplayName("SORPRATE")>
    <Description("SORPRATE  = Kdes * FRACEQ, 1/day")>
    Public ReadOnly Property SORPRATE As Double
        Get
            Return Math.Round(kDes * FRACEQ, 4)
        End Get
    End Property


#End Region


#Region "PRZM"

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_TestOC As Double = 1.5

    ''' <summary>
    ''' Test OC
    ''' </summary>
    <Category(CATPRZM)>
    <DisplayName("Test OC")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <XmlIgnore>
    Public Property TestOC As Double
        Get
            Return m_TestOC
        End Get
        Set(vTestOC As Double)
            m_TestOC = vTestOC
        End Set
    End Property


    Public ReadOnly Property Kd As Double
        Get
            Return 2
        End Get
    End Property



    ''' <summary>
    ''' Kf
    ''' </summary>
    <Category(CATPRZM)>
    <DisplayName("Kf")>
    <Description("" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public ReadOnly Property Kf As Double
        Get
            Return KOCeq * (TestOC / 100) * (1 + fNE)
        End Get
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_fEQ As Double = 0.0

    ''' <summary>
    ''' CofFreNeq/CofFreEql in PEARL
    '''   
    '''           1
    ''' fEQ  = -------
    '''         1+fNE
    ''' 
    ''' </summary>
    <Category(CATPRZM)>
    <DisplayName("fEQ")>
    <Description("CofFreNeq/CofFreEql fEQ in PRZM" & vbCrLf &
                 "fEQ = 1/(1+fNE), Streck")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0.0)>
    Public ReadOnly Property fEQ As Double
        Get
            Return Math.Round(1 / (1 + m_fNE), 4)
        End Get
    End Property




    ''' <summary>
    ''' a (alpha)
    ''' Desorption rate coefficient a in PRZM
    ''' = Kdes in PEARL per day , off = 0 [0|0.5]
    ''' </summary>
    <Category(CATPRZM)>
    <DisplayName("a (alpha)")>
    <Description("Desorption rate coefficient a in PRZM" & vbCrLf &
                 "= Kdes in PEARL per day , off = 0 [0|0.5], CofDesRat")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public ReadOnly Property a As Double
        Get
            Return m_kDes
        End Get
    End Property


#End Region


#Region "Output"


#Region "Summary"

    Public Const Click2EditString As String = "time dependent sorption"


    <Category(CATOutput)>
    <Browsable(True)>
    Public ReadOnly Property Summary As String()
        Get
            Return getTDS_Summary()
        End Get
    End Property

    Public Function getTDS_Summary() As String()

        Dim Summary As New List(Of String)
        Dim Dummy As String = " ** PEARL"
        Dim Dummy2 As String = " **  MACRO"

        With Summary

            .Add("Click here to edit " & Click2EditString)
            .Add(" ** PEARL ** ")

            


        End With


        Return Summary.ToArray


    End Function




#End Region

#Region "PEARL"



#End Region

#Region "PELMO"

    Public Const PELMO_ADSORPTION_Header As String = "< Koc-value  Fr.exp.Koc  pH  pKa  limit for Freundl.  ann.incr.>  <k_doc>  <% change>  KOC2  pH2   f_neq    kdes >"


    <Category(CATOutput)>
    <Browsable(True)>
    <DisplayName("PELMO, TDS")>
    Public ReadOnly Property PELMO_TDS As String()
        Get

            Dim temp As New List(Of String)
            Dim row As String = ""

            temp.Add("<ADSORPTION>")
            temp.Add(PELMO_ADSORPTION_Header)

            row &= Me.KOCeq.ToString().PadLeft("< Koc-value".Length)
            row &= Me.Freundlich.ToString().PadLeft("  Fr.exp.Koc".Length)
            row &= " -99   20                0.01           0        0           1   -99  -99"
            row &= Me.fNE.ToString().PadLeft("   f_neq".Length)
            row &= Me.kDes.ToString().PadLeft("    kdes".Length)

            temp.Add(row)
            temp.Add("<END ADSORPTION>")

            Return temp.ToArray

        End Get
    End Property

#End Region


#End Region

#Region "Events"

    <Category(CATOutput)>
    <DisplayName("Input Complete ?")>
    Public ReadOnly Property InputComplete As Boolean
        Get
            Return True
        End Get
    End Property

    Public Event Data_Change()

#End Region

End Class
