﻿
#Region "Imports System"

Imports System.ComponentModel
Imports System.Xml.Serialization

#End Region

#Region "Imports Toolbox"

Imports ToolBox
Imports FOCUSswBasic
Imports FOCUSswBasic.Step34

#End Region


''' <summary>
''' KOC/KOM 
''' Adsorption Partition Coefficient  
''' </summary>
<Serializable>
<DescriptionAttribute("KOM and KOC")>
<DefaultProperty("KOMeq")>
<DisplayName("KOM and KOC")>
<TypeConverter(GetType(cKOC_KOM.PGridConverter))>
Public Class cKOC_KOM


#Region "Constructor"

    Public Sub New()

    End Sub

#End Region

#Region "PGrid Stuff"

    ''' <summary>
    ''' makes the class browsable for property grid
    ''' PGridItemName = name to display
    ''' </summary>
    Public Class PGridConverter

        Inherits ExpandableObjectConverter

        <RefreshProperties(RefreshProperties.All)>
        Public Shared Property PGridItemName As String = "Please enter KOC/KOM in L/kg"
        Public Shared Property ClassType As Type


#Region "Overloads Overrides"

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                         ByVal destinationType As Type) As Boolean

            Try
                If (destinationType Is GetType(cKOC_KOM)) Then
                    Return True
                End If
            Catch ex As Exception

            End Try

            Return MyBase.CanConvertTo(context,
                                       destinationType)

        End Function

        Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

            If (destinationType Is GetType(System.String)) Then

                Return PGridItemName

            End If

            Return MyBase.ConvertTo(context,
                                    culture,
                                    value,
                                    destinationType)

        End Function

#End Region

    End Class

#End Region


#Region "KOM <-> KOC"


    Public Const CATKOMKOC As String = "KOM <-> KOC"

    ''' <summary>
    ''' Conversion between KOCeq and KOMeq
    ''' std. conversion factor is 1.724
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <Category(CATKOMKOC)>
    <Description("Conversion between KOCeq and KOMeq" & vbCrLf &
                 "std. conversion factor is 1.724")>
    Public WithEvents KOM_KOC_Conversion As New cKOM_KOC_Conversion


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_KOMeq As Double = 9999

    ''' <summary>
    ''' KOMeq in L/kg  (PEARL/TOXSWA)
    ''' Organic MATTER content normalized distribution coefficient
    ''' in the equilibrium compartment
    ''' </summary>
    <Category(CATKOMKOC)>
    <DisplayName("KOMeq (PEARL/TOXSWA)")>
    <Description("Organic MATTER content normalized distribution coefficient" & vbCrLf &
                 "in the equilibrium compartment in L/kg [0|1e9]")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(9999)>
    Public Property KOMeq As Double
        Get
            Return m_KOMeq
        End Get
        Set(vKOMeq As Double)

            If vKOMeq >= 0 AndAlso vKOMeq <= 1000000000.0 Then

                If vKOMeq > 10000.0 Then

                    If MsgBox(Prompt:="KOMeq > 10,000 is strange, continue?",
                             Buttons:=MsgBoxStyle.OkCancel,
                               Title:="User Input seems to be wrong") = MsgBoxResult.Cancel Then
                        Exit Property

                    End If

                End If

                m_KOMeq = vKOMeq

                Me.KOM_KOC_Conversion.KOMeq = m_KOMeq
                Me.KOM_KOC_Conversion.myFromTo = cKOM_KOC_Conversion.eConversionDirection.KOM_to_KOC


                'm_KOCeq = m_KOMeq * KOCvsKOM_ConversionFactor

            Else
                MsgBox("Organic MATTER normalized distribution coefficient" & vbCrLf &
                       "in L/kg, 0 <= KOMeq <= 1e9" & vbCrLf &
                       "Your input is not valid : " & vKOMeq,
                       MsgBoxStyle.Exclamation)
            End If

        End Set
    End Property



    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_KOCeq As Double = 9999

    ''' <summary>
    ''' KOCeq in L/kg (PELMO/MACRO)
    ''' Organic CARBON content normalized distribution coefficient
    ''' in the equilibrium compartment
    ''' </summary>
    <Category(CATKOMKOC)>
    <DisplayName("KOCeq (PELMO/MACRO)")>
    <Description("Organic CARBON content normalized distribution coefficient" & vbCrLf &
                 "in the equilibrium compartment in L/kg [0|1e9]")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(9999)>
    Public Property KOCeq As Double
        Get
            Return m_KOCeq
        End Get
        Set(vKOCeq As Double)


            If vKOCeq >= 0 AndAlso vKOCeq <= 1000000000.0 Then

                If vKOCeq > 10000.0 Then

                    If MsgBox(Prompt:="KOCeq > 10,000 is strange, continue?",
                             Buttons:=MsgBoxStyle.OkCancel,
                               Title:="User Input seems to be wrong") = MsgBoxResult.Cancel Then
                        Exit Property

                    End If

                End If

                m_KOCeq = vKOCeq
                Me.KOM_KOC_Conversion.KOCeq = m_KOCeq
                Me.KOM_KOC_Conversion.myFromTo = cKOM_KOC_Conversion.eConversionDirection.KOC_to_KOM
                'm_KOMeq = m_KOCeq / KOCvsKOM_ConversionFactor


            Else
                MsgBox("Organic MATTER normalized distribution coefficient" & vbCrLf &
                       "in L/kg, 0 <= KOCeq <= 1e9" & vbCrLf &
                       "Your input is not valid : " & vKOCeq,
                       MsgBoxStyle.Exclamation)
            End If

        End Set
    End Property


#Region "KOM <-> KOC"

    ''' <summary>
    ''' KOM vs KOC Conversion
    ''' </summary>
    <Serializable>
    <TypeConverter(GetType(cKOM_KOC_Conversion.PGridConverter))>
    <DescriptionAttribute("Convert KOM <-> KOC")>
    Public Class cKOM_KOC_Conversion

#Region "Constructor"

        Public Sub New()

        End Sub

#End Region

#Region "PGrid Stuff"

        ''' <summary>
        ''' makes the class browsable for property grid
        ''' PGridItemName = name to display
        ''' </summary>
        Public Class PGridConverter

            Inherits ExpandableObjectConverter

            <RefreshProperties(RefreshProperties.All)>
            Public Shared Property PGridItemName As String = "KOM <-> KOC"
            Public Shared Property ClassType As Type


#Region "Overloads Overrides"

            Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                             ByVal destinationType As Type) As Boolean

                Try
                    If (destinationType Is GetType(cKOM_KOC_Conversion)) Then
                        Return True
                    End If
                Catch ex As Exception

                End Try

                Return MyBase.CanConvertTo(context,
                                           destinationType)

            End Function

            Public Overloads Overrides Function ConvertTo(
                                 ByVal context As ITypeDescriptorContext,
                                 ByVal culture As Globalization.CultureInfo,
                                 ByVal value As Object,
                                 ByVal destinationType As System.Type) As Object

                Return PGridItemName

                Return MyBase.ConvertTo(context,
                                        culture,
                                        value,
                                        destinationType)

            End Function

#End Region

        End Class

#End Region



#Region "Settings"

        Public Enum eConversionDirection
            KOC_to_KOM
            KOM_to_KOC
        End Enum

        <DisplayName("Select conversion direction")>
        <Description("KOCeq -> KOMeq or KOMeq -> KOCeq")>
        <XmlIgnore>
        Public Property myFromTo As eConversionDirection = eConversionDirection.KOC_to_KOM


        ''' <summary>
        ''' Factor for conversion of 
        ''' KOC to KOM and vice versa
        ''' std. = 1.724
        ''' </summary>
        <Category()>
        <DisplayName("KOC <-> KOM Factor")>
        <Description("Factor for conversion of" & vbCrLf &
                     "KOC to KOM and vice versa, std. = 1.724")>
        <RefreshProperties(RefreshProperties.All)>
        <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
        <Browsable(True)>
        <[ReadOnly](False)>
        <DefaultValue(1.724)>
        <XmlIgnore>
        Public Property KOC_KOM_ConversionFactor As Double = 1.724


        Public Enum eDigits
            _00
            _01
            _02
            _03
            _04
        End Enum

        <DisplayName("Digits for rounding")>
        <XmlIgnore>
        Public Property Digits As eDigits = eDigits._02

        ''' <summary>
        ''' dblClick to start conversion
        ''' </summary>
        <DisplayName("Start Conversion")>
        <Description("dblClick to start conversion")>
        <XmlIgnore>
        Public Property Convert As eClick
            Get
                Return eClick.Dblclick
            End Get
            Set(value As eClick)
                If value = eClick.Dblclick Then Exit Property

                If myFromTo = eConversionDirection.KOC_to_KOM Then
                    KOMeq = Math.Round(KOCeq / KOC_KOM_ConversionFactor, Me.Digits)
                Else
                    KOCeq = Math.Round(KOMeq * KOC_KOM_ConversionFactor, Me.Digits)
                End If

                RaiseEvent KOMvsKOC_Change(KOCeq:=Me.KOCeq,
                                           KOMeq:=Me.KOMeq)

                RaiseEvent ConversionByUser()

            End Set
        End Property


#End Region

#Region "Values"

        ''' <summary>
        ''' KOMeq in L/kg
        ''' Organic MATTER content normalized distribution coefficient
        ''' in the equilibrium compartment
        ''' </summary>
        <Category()>
        <DisplayName("KOMeq (PEARL/TOXSWA)")>
        <Description("Organic MATTER content normalized distribution coefficient" & vbCrLf &
                     "in the equilibrium compartment in L/kg [0|1e9]")>
        <RefreshProperties(RefreshProperties.All)>
        <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
        <Browsable(False)>
        <[ReadOnly](True)>
        <XmlIgnore>
        Public Property KOMeq As Double = 9999

        ''' <summary>
        ''' KOCeq
        ''' Organic CARBON content normalized distribution coefficient
        ''' in the equilibrium compartment
        ''' </summary>
        <Category()>
        <DisplayName("KOCeq (PELMO/MACRO)")>
        <Description("Organic CARBON content normalized distribution coefficient" & vbCrLf &
                     "in the equilibrium compartment")>
        <RefreshProperties(RefreshProperties.All)>
        <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
        <Browsable(False)>
        <[ReadOnly](True)>
        <XmlIgnore>
        Public Property KOCeq As Double = 9999

#End Region

#Region "Events"

        Public Event KOMvsKOC_Change(KOCeq As Double,
                                     KOMeq As Double)

        Public Event ConversionByUser()

#End Region


    End Class

    Private Sub KOM_KOC_Conversion_ConversionByUser() Handles KOM_KOC_Conversion.ConversionByUser
        RaiseEvent ConversionByUser()
    End Sub


    Private Sub connversion_Sorption_Change(KOCeq As Double,
                                            KOMeq As Double) Handles KOM_KOC_Conversion.KOMvsKOC_Change

        Me.KOCeq = KOCeq
        Me.KOMeq = KOMeq


        Dim out As String = ""

        If m_KOCeq = 9999 OrElse m_KOMeq = 9999 Then
            out = "Entry incomlete!"
        Else
            If KOM_KOC_Conversion.myFromTo = cKOM_KOC_Conversion.eConversionDirection.KOC_to_KOM Then
                out = "KOC = " & m_KOCeq & " L/kg (KOM = " & m_KOMeq & " L/kg)"
            Else
                out = "KOM = " & m_KOMeq & " L/kg (KOC = " & m_KOCeq & " L/kg)"
            End If
        End If

        cKOC_KOM.PGridConverter.PGridItemName = out

    End Sub


#End Region


#End Region


#Region "Events"

    Public Event ConversionByUser()

#End Region


End Class
