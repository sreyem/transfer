﻿



#Region "Imports System"

Imports System.ComponentModel
Imports System.Xml.Serialization

Imports System.Windows.Forms.DataVisualization.Charting

#End Region

#Region "Imports Toolbox"

Imports ToolBox
Imports FOCUSswBasic.Step34

#End Region



Public Class frmZFINT


    Public WithEvents ZFINT As New cZFINT

    Public Sub New()

        InitializeComponent()

        With Me.PGrid

            .Font = New Drawing.Font("Courier New", 12)
            .PropertySort = Windows.Forms.PropertySort.Categorized

            .SelectedObject = Me.ZFINT
            .Refresh()

        End With

        ZFINT_Data_Change()

    End Sub




    Private Sub ZFINT_Data_Change() Handles ZFINT.Data_Change

        With Me.Chart.Series("ZFINT")

            .Points.Clear()

            For DayCounter As Integer = 0 To 365


                .Points.AddXY(
                           xValue:=DayCounter,
                           yValue:=getZFINT(
                               idmax:=CInt(Me.ZFINT.Parameter(eZINT_DataMember.idmax)),
                               idstart:=CInt(Me.ZFINT.Parameter(eZINT_DataMember.idstart)),
                               iharv:=CInt(Me.ZFINT.Parameter(eZINT_DataMember.iharv)),
                               laimin:=CDbl(Me.ZFINT.Parameter(eZINT_DataMember.laimin)),
                               laimax:=CDbl(Me.ZFINT.Parameter(eZINT_DataMember.laimax)),
                               cform:=CDbl(Me.ZFINT.Parameter(eZINT_DataMember.cform)),
                               maxint:=CDbl(Me.ZFINT.Parameter(eZINT_DataMember.maxint)),
                               zdatemin:=CInt(Me.ZFINT.Parameter(eZINT_DataMember.zdatemin)),
                               irrday:=DayCounter))

            Next

        End With


    End Sub
End Class

''' <summary>
''' Calculation of crop interception for MACRO (ZFINT)   
''' </summary>
<Serializable>
<DescriptionAttribute("Calculation of crop interception for MACRO (ZFINT)")>
<DefaultProperty("DrainageScenario")>
<DisplayName("Crop Interception for MACRO")>
<TypeConverter(GetType(cZFINT.PGridConverter))>
Public Class cZFINT


#Region "Constructor"

    Public Sub New()

        Me.DrainageScenario = eMACROScenarios.D1
        Me.Crop = eMACROCrops.Cereals_winter
        Me.ApplnDay = 150

    End Sub

    Public Sub New(DrainageScenario As eMACROScenarios,
                   Crop As eMACROCrops,
                   ApplnDay As Integer)

        Me.DrainageScenario = DrainageScenario
        Me.Crop = Crop
        Me.ApplnDay = ApplnDay

    End Sub


#End Region

#Region "PGrid Stuff"

    ''' <summary>
    ''' makes the class browsable for property grid
    ''' PGridItemName = name to display
    ''' </summary>
    Public Class PGridConverter

        Inherits ExpandableObjectConverter

        <RefreshProperties(RefreshProperties.All)>
        Public Shared Property PGridItemName As String = "Moisture and Temperature correction"
        Public Shared Property ClassType As Type


#Region "Overloads Overrides"

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext,
                                                         ByVal destinationType As Type) As Boolean

            Try
                If (destinationType Is GetType(cZFINT)) Then
                    Return True
                End If
            Catch ex As Exception

            End Try

            Return MyBase.CanConvertTo(context,
                                       destinationType)

        End Function

        Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

            If (destinationType Is GetType(System.String)) Then

                If value.GetType Is ClassType Then
                    Return PGridItemName
                End If

            End If

            Return MyBase.ConvertTo(context,
                                    culture,
                                    value,
                                    destinationType)

        End Function

#End Region

    End Class

#End Region



#Region "Categroies"

    Public Const CATUserInput As String = "01  User Input"
    Public Const CATParameter As String = "02  Parameter"

#End Region

#Region "01  User Input"


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_DrainageScenario As eMACROScenarios = eMACROScenarios.not_defined

    ''' <summary>
    ''' FOCUS SWASH Drainage Scenario
    ''' D1 - D6
    ''' </summary>
    <Category(CATUserInput)>
    <DisplayName("Drainage Scenario")>
    <Description("FOCUS SWASH Drainage Scenario" & vbCrLf &
                 "D1 - D6")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public Property DrainageScenario As eMACROScenarios
        Get
            Return m_DrainageScenario
        End Get
        Set(vDrainageScenario As eMACROScenarios)

            Parameter = getParameter(
                DrainageScenario:=vDrainageScenario,
                            Crop:=m_Crop)

            If IsNothing(Parameter) Then

                m_Crop = eMACROCrops.not_defined
            Else
                m_DrainageScenario = vDrainageScenario
            End If

            m_DrainageScenario = vDrainageScenario
            If m_DrainageScenario <> eMACROScenarios.not_defined Then RaiseEvent Data_Change()

        End Set
    End Property

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_Crop As eMACROCrops = eMACROCrops.not_defined


    ''' <summary>
    ''' FOCUS MACRO Crop
    ''' Scenario independent : Citrus = 0.7, Grass = 0.9
    ''' </summary>
    <Category(CATUserInput)>
    <DisplayName("FOCUS MACRO Crop")>
    <Description("Scenario independent : Citrus = 0.7, Grass = 0.9")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public Property Crop As eMACROCrops
        Get
            Return m_Crop
        End Get
        Set(vCrop As eMACROCrops)

            If vCrop <> eMACROCrops.not_defined Then

                Parameter = getParameter(
                DrainageScenario:=m_DrainageScenario,
                            Crop:=vCrop)

                If IsNothing(Parameter) Then

                    vCrop = eMACROCrops.not_defined
                End If

            End If

            m_Crop = vCrop
            If m_Crop <> eMACROCrops.not_defined Then RaiseEvent Data_Change()


        End Set
    End Property



    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_ApplnDay As Integer = 1


    ''' <summary>
    ''' Julian Appln Day
    ''' 1 - 365
    ''' </summary>
    <Category(CATUserInput)>
    <DisplayName("Julian Appln Day")>
    <Description("1 - 365")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public Property ApplnDay As Integer
        Get
            Return m_ApplnDay
        End Get
        Set(vApplnDay As Integer)

            If vApplnDay < 1 OrElse vApplnDay > 365 Then
                vApplnDay = 150
            Else
                m_ApplnDay = vApplnDay
            End If

        End Set
    End Property

    ''' <summary>
    ''' Appln Date
    ''' dd-MMM
    ''' </summary>
    <Category(CATUserInput)>
    <DisplayName("Appln Date")>
    <Description("dd-MMM")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    Public ReadOnly Property ApplnDate As String
        Get
            Return New Date(year:=1975,
                           month:=1,
                             day:=1).AddDays(m_ApplnDay - 1).ToString("dd-MMM")
        End Get
    End Property

    ''' <summary>
    ''' Interception
    ''' ZFINT as fraction
    ''' </summary>
    <Category(CATUserInput)>
    <DisplayName("Interception")>
    <Description("ZFINT as fraction")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    Public ReadOnly Property ZFINT As Double
        Get

            Return Math.Round(getZFINT(
                    DrainageScenario:=Me.DrainageScenario,
                                Crop:=Me.Crop,
                            ApplnDay:=Me.ApplnDay
                            ), 2)
        End Get
    End Property

#End Region


#Region "02  Parameter"

    <Browsable(False)>
    Public Property Parameter As String() = {}


    ''' <summary>
    ''' idmax
    ''' Day of maximum leaf area/root depth
    ''' </summary>
    <Category(CATParameter)>
    <DisplayName("idmax")>
    <Description("Maximum leaf area" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    Public ReadOnly Property idmax As String
        Get

            Dim temp As Integer = 0
            temp = CInt(Parameter(eZINT_DataMember.idmax))

            Return temp.ToString.PadLeft(3) & " : " &
                New Date(
                        year:=1975,
                       month:=1,
                         day:=1).AddDays(temp - 1).ToString("dd-MMM")
        End Get
    End Property


    ''' <summary>
    ''' idstart
    ''' Day of crop emergence
    ''' </summary>
    <Category(CATParameter)>
    <DisplayName("idstart")>
    <Description("Harvest" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    Public ReadOnly Property idstart As String
        Get

            Dim temp As Integer = 0
            temp = CInt(Parameter(eZINT_DataMember.idstart))

            Return temp.ToString.PadLeft(3) & " : " &
                New Date(
                        year:=1975,
                       month:=1,
                         day:=1).AddDays(temp - 1).ToString("dd-MMM")
        End Get
    End Property

    ''' <summary>
    ''' iharv
    ''' Day of crop emergence
    ''' </summary>
    <Category(CATParameter)>
    <DisplayName("iharv")>
    <Description("Harvest" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    Public ReadOnly Property iharv As String
        Get

            Dim temp As Integer = 0
            temp = CInt(Parameter(eZINT_DataMember.iharv))

            Return temp & " : " &
                New Date(
                        year:=1975,
                       month:=1,
                         day:=1).AddDays(temp - 1).ToString("dd-MMM")
        End Get
    End Property

    ''' <summary>
    ''' laimin
    ''' Leaf area index at ZDATEMIN
    ''' </summary>
    <Category(CATParameter)>
    <DisplayName("laimin")>
    <Description("Leaf area index at ZDATEMIN" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    Public ReadOnly Property laimin As Double
        Get
            Return CDbl(Parameter(eZINT_DataMember.laimin))
        End Get
    End Property

    ''' <summary>
    ''' laimax
    ''' Maximum leaf area index
    ''' </summary>
    <Category(CATParameter)>
    <DisplayName("laimax")>
    <Description("Maximum leaf area index" & vbCrLf &
                 "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    Public ReadOnly Property laimax As Double
        Get
            Return CDbl(Parameter(eZINT_DataMember.laimax))
        End Get
    End Property


    ''' <summary>
    ''' cform
    ''' Leaf development factor, growth
    ''' </summary>
    <Category(CATParameter)>
    <DisplayName("cform")>
    <Description("Leaf development factor, growth" & vbCrLf &
                 "1.5 - 2.0")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    Public ReadOnly Property cform As Double
        Get
            Return CDbl(Parameter(eZINT_DataMember.cform))
        End Get
    End Property

    ''' <summary>
    ''' maxint
    ''' Maximum crop interception of pesticide
    ''' </summary>
    <Category(CATParameter)>
    <DisplayName("maxint")>
    <Description("Maximum crop interception of pesticide" & vbCrLf &
                 "Calculated from LAIMAX")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    Public ReadOnly Property maxint As Double
        Get
            Return CDbl(Parameter(eZINT_DataMember.maxint))
        End Get
    End Property

#End Region


#Region "04  Methods"

    Private Function getParameter(DrainageScenario As eMACROScenarios,
                                  Crop As eMACROCrops) As String()


        Dim DataArray As String() = {}

        Try

            DataArray = Filter(
                            Source:=MACRO_ZINT_Data,
                             Match:=DrainageScenario.ToString,
                           Include:=True)


            DataArray = Filter(
                            Source:=DataArray,
                             Match:=MacroCropTranslationMatrix(Crop),
                           Include:=True)

            DataArray = DataArray.First.Split(CChar("|"))


        Catch ex As Exception
            'crop not defined for this scenario
            DataArray = Nothing
        End Try

        Return DataArray


    End Function


    Public Function calcTimeVsInterception() As Series


        Dim TempChart As New Chart

        TempChart.Series.Add("ZFINT")


        With TempChart.Series("ZFINT")

            .XValueType = ChartValueType.DateTime


            For DayCounter As Integer = 0 To 365


                .Points.AddXY(
                            xValue:=New Date(
                                       year:=1975,
                                      month:=1,
                                        day:=1).AddDays(DayCounter - 1).ToOADate,
                            yValue:=getZFINT(
                                idmax:=CInt(Parameter(eZINT_DataMember.idmax)),
                                idstart:=CInt(Parameter(eZINT_DataMember.idstart)),
                                iharv:=CInt(Parameter(eZINT_DataMember.iharv)),
                                laimin:=CDbl(Parameter(eZINT_DataMember.laimin)),
                                laimax:=CDbl(Parameter(eZINT_DataMember.laimax)),
                                cform:=CDbl(Parameter(eZINT_DataMember.cform)),
                                maxint:=CDbl(Parameter(eZINT_DataMember.maxint)),
                                zdatemin:=CInt(Parameter(eZINT_DataMember.zdatemin)),
                                irrday:=DayCounter))

            Next


        End With

        Return TempChart.Series("ZFINT")


    End Function

#End Region

#Region "Events"

    Public Event Data_Change()

#End Region

End Class