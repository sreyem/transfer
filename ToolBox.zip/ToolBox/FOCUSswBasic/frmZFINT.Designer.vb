﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmZFINT
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim ChartArea1 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Series1 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Me.SplitContainer = New System.Windows.Forms.SplitContainer()
        Me.PGrid = New System.Windows.Forms.PropertyGrid()
        Me.Chart = New System.Windows.Forms.DataVisualization.Charting.Chart()
        CType(Me.SplitContainer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer.Panel1.SuspendLayout()
        Me.SplitContainer.Panel2.SuspendLayout()
        Me.SplitContainer.SuspendLayout()
        CType(Me.Chart, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SplitContainer
        '
        Me.SplitContainer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer.Name = "SplitContainer"
        '
        'SplitContainer.Panel1
        '
        Me.SplitContainer.Panel1.Controls.Add(Me.PGrid)
        '
        'SplitContainer.Panel2
        '
        Me.SplitContainer.Panel2.Controls.Add(Me.Chart)
        Me.SplitContainer.Size = New System.Drawing.Size(592, 508)
        Me.SplitContainer.SplitterDistance = 197
        Me.SplitContainer.TabIndex = 0
        '
        'PGrid
        '
        Me.PGrid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PGrid.Location = New System.Drawing.Point(0, 0)
        Me.PGrid.Name = "PGrid"
        Me.PGrid.Size = New System.Drawing.Size(197, 508)
        Me.PGrid.TabIndex = 0
        '
        'Chart
        '
        ChartArea1.AxisX.Maximum = 365.0R
        ChartArea1.AxisX.Minimum = 0.0R
        ChartArea1.AxisX.Title = "Julian Date"
        ChartArea1.Name = "ChartArea"
        Me.Chart.ChartAreas.Add(ChartArea1)
        Me.Chart.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Chart.Location = New System.Drawing.Point(0, 0)
        Me.Chart.Name = "Chart"
        Series1.ChartArea = "ChartArea"
        Series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine
        Series1.Name = "ZFINT"
        Me.Chart.Series.Add(Series1)
        Me.Chart.Size = New System.Drawing.Size(391, 508)
        Me.Chart.TabIndex = 0
        Me.Chart.Text = "Chart1"
        '
        'frmZFINT
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6!, 13!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(592, 508)
        Me.Controls.Add(Me.SplitContainer)
        Me.Name = "frmZFINT"
        Me.Text = "frmZFINT"
        Me.SplitContainer.Panel1.ResumeLayout(false)
        Me.SplitContainer.Panel2.ResumeLayout(false)
        CType(Me.SplitContainer,System.ComponentModel.ISupportInitialize).EndInit
        Me.SplitContainer.ResumeLayout(false)
        CType(Me.Chart,System.ComponentModel.ISupportInitialize).EndInit
        Me.ResumeLayout(false)

End Sub
    Friend WithEvents SplitContainer As System.Windows.Forms.SplitContainer
    Friend WithEvents PGrid As System.Windows.Forms.PropertyGrid
    Friend WithEvents Chart As System.Windows.Forms.DataVisualization.Charting.Chart
End Class
