﻿

Imports Toolbox
Imports Toolbox.log
Imports Toolbox.ErrorHandling

Imports System.ComponentModel

Public Class General

#Region "Enums"

    Public Enum eSWSed
        SW
        Sed
    End Enum

    Public Enum eSiMuAppln
        Singl
        Multi
    End Enum

    Public Enum eParMet
        Par
        Met
    End Enum

    Public Enum eFOCUSResultDays

        _0 = 0
        _1 = 1
        _2 = 2
        _4 = 4
        _7 = 7
        _14 = 14
        _21 = 21
        _28 = 28
        _42 = 42
        _50 = 50
        _100 = 100

    End Enum

#End Region

#Region "DBs"

    Public SWSedString As String() =
     {"Surface water",
      "Sediment"}

    Public SiMuString As String() =
       {"Single",
        "Multi."}

    Public ParMetStringLong As String() =
        {"Parent",
         "Metabolite"}

#End Region

End Class

Public Class Step12

#Region "Enums"

    Public Enum eCrop

        SpringCereals
        WinterCereals
        Citrus
        Cotton
        FieldBeans
        Grass
        Hops
        Legumes
        Maize
        SpringOSR
        WinterOSR
        Olives
        AppleEarly
        AppleLate
        Potatoes
        Soybeans
        SugarBeets
        Sunflowers
        Tobacco
        VegBulb
        VegFruiting
        VegLeafy
        VegRoot
        VinesEarly
        VinesLate
        Aerial
        HandAppLow
        HandAppHigh
        NoDrift

    End Enum

    Public Enum eInterceptionClass

        No_Interception     'no interception
        Minimal_Crop_Cover  'min crop cover
        Average_Crop_Cover  'average crop cover
        Full_Canopy         'full canopy

    End Enum

    Public Enum eRegion

        NEU = 0 'Northern Europe
        SEU = 3 'Southern Europe

        NRD = 6 'No Runoff or Drainage

        NSE = 7 'Northern & Southern Europe

    End Enum

    Public Enum eSeason

        Autumn = 0 ' Oct. - Feb.
        Spring = 1 ' Mar. - May
        Summer = 2 ' Jun. - Sep.

    End Enum

    Public Enum eMaxEntryPath

        'Spray Drift, RunOff or Erosion
        SprayDrift
        RunOff
        Erosion

    End Enum

#End Region

#Region "DBs"

#Region "Interception Values"

    Public Shared InterceptionClassString As String() =
       {
       "no interception",
       "min crop cover",
       "average crop cover",
       "full canopy"
       }

    Public Shared InterceptionValues As Double(,) =
    {
    {0, 0, 0.2, 0.7},
    {0, 0, 0.2, 0.7},
    {0, 0.8, 0.8, 0.8},
    {0, 0.3, 0.6, 0.75},
    {0, 0.25, 0.4, 0.7},
    {0, 0.4, 0.6, 0.75},
    {0, 0.2, 0.5, 0.7},
    {0, 0.25, 0.5, 0.7},
    {0, 0.25, 0.5, 0.75},
    {0, 0.4, 0.7, 0.75},
    {0, 0.4, 0.7, 0.75},
    {0, 0.7, 0.7, 0.7},
    {0, 0.2, 0.4, 0.65},
    {0, 0.2, 0.4, 0.65},
    {0, 0.15, 0.5, 0.7},
    {0, 0.2, 0.5, 0.75},
    {0, 0.2, 0.7, 0.75},
    {0, 0.2, 0.5, 0.75},
    {0, 0.2, 0.7, 0.75},
    {0, 0.1, 0.25, 0.4},
    {0, 0.25, 0.5, 0.7},
    {0, 0.25, 0.4, 0.7},
    {0, 0.25, 0.5, 0.7},
    {0, 0.4, 0.5, 0.6},
    {0, 0.4, 0.5, 0.6},
    {0, 0.2, 0.5, 0.7},
    {0, 0.2, 0.5, 0.7},
    {0, 0.2, 0.5, 0.7},
    {0, 0, 0, 0}
    }

#End Region

#Region "Region"

    Public RegionStringShort As String() =
        {
        "N-Europe",
        "",
        "",
        "S-Europe",
        "",
        "",
        "No ROFF/Drain.",
        "N/S-Europe"
        }

    Public RegionStringLong As String() =
        {
        "Northern Europe",
        "",
        "",
        "Southern Europe",
        "",
        "",
        "No runoff or drainage",
        "Northern and Southern Europe"
        }

#End Region


    Public Shared Property Seasons As String() =
      {
          "Oct. - Feb.",
          "Mar. - May",
          "Jun. - Sep."
      }

    'Autumn ,Spring, Summer



    Public Shared EntryPathString As String() =
      {"Spray drift", "Runoff", "Erosion"}

    Public Shared ROffDraingagePercValues As Integer() =
       {5, 2, 2, 4, 4, 3, 0}

    'NEU AUT,SPR,SUM SEU AUT,SPR,SUM NRD

#Region "Drift Values"

    Public Shared DriftValues As Double(,) =
    {
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {15.725, 12.129, 11.011, 10.124, 9.743, 9.204, 9.102, 8.656},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {19.326, 17.723, 15.928, 15.378, 15.114, 14.902, 14.628, 13.52},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {15.725, 12.129, 11.011, 10.124, 9.743, 9.204, 9.102, 8.656},
    {29.197, 25.531, 23.96, 23.603, 23.116, 22.76, 22.69, 22.241},
    {15.725, 12.129, 11.011, 10.124, 9.743, 9.204, 9.102, 8.656},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {2.699, 2.496, 2.546, 2.499, 2.398, 2.336, 2.283, 2.265},
    {8.028, 7.119, 6.898, 6.631, 6.636, 6.431, 6.227, 6.173},
    {33.2, 33.2, 33.2, 33.2, 33.2, 33.2, 33.2, 33.2},
    {2.759, 2.438, 2.024, 1.862, 1.794, 1.631, 1.578, 1.512},
    {8.028, 7.119, 6.898, 6.631, 6.636, 6.431, 6.227, 6.173},
    {0, 0, 0, 0, 0, 0, 0, 0}
    }

#End Region

#Region "Crops"

    

    Public Shared CropsString As String() =
     {
    "Cereals, spring",
    "Cereals, winter",
    "Citrus",
    "Cotton",
    "Field beans",
    "Grass / alfalfa",
    "Hops",
    "Legumes",
    "Maize",
    "Oil seed rape, spring",
    "Oil seed rape, winter",
    "Olives",
    "Pome / stone fruit, early applns",
    "Pome / stone fruit, late applns",
    "Potatoes",
    "Soybeans",
    "Sugar beet",
    "Sunflower",
    "Tobacco",
    "Vegetables, bulb",
    "Vegetables, fruiting",
    "Vegetables, leafy",
    "Vegetables, root",
    "Vines, early applns",
    "Vines, late applns",
    "Appln, aerial",
    "Appln, hand (crop < 50 cm)",
    "Appln, hand (crop > 50 cm)",
    "No drift (incorp or seed trtmt)"
    }



    Public Shared Ganzelmeier As String() =
    {
    "Arable crops",
    "Arable crops",
    "Fruit crops / late",
    "Arable crops",
    "Arable crops",
    "Arable crops",
    "Hops",
    "Arable crops",
    "Arable crops",
    "Arable crops",
    "Arable crops",
    "Fruit crops / late",
    "Fruit crops / early",
    "Fruit crops / late",
    "Arable crops",
    "Arable crops",
    "Arable crops",
    "Arable crops",
    "Arable crops",
    "Arable crops",
    "Arable crops",
    "Arable crops",
    "Arable crops",
    "Vines / early",
    "Vines / late",
    "Aerial application",
    "Arable crops",
    "Vines / late",
    "No drift",
    "not defined"
    }

#End Region

#Region "pesticide.txt header row"

    Public Shared Property pesticidetxtHeaderRow2 As String() =
    {
    "AI".PadRight(20),
    "Comp".PadRight("PMT01 PSD00 NEU SPR ACC".Length),
    "",
    "MMass AI.",
    "MMass Comp.",
    "WS",
    "KOC L/kg",
    "DT50 Step01",
    "Max. SwSed",
    "Max. Soil",
    "App. Rate",
    "No of App.",
    "Interval",
    "App. Type",
    "DT50 soil",
    "DT50 water",
    "DT50 sediment",
    "Reg / Season",
    "Interc."
    }


    Public Shared Property pesticidetxtHeaderRow3 As String() =
     {
    "AI",
    "            Compound",
    "",
    "MMass AI.",
    "MMass Comp.",
    "Water Sol.",
    "KOC Comp.",
    "KOC parent compound",
    "DT50 Step01",
    "Max. SwSed",
    "Max. Soil",
    "App. Rate",
    "No",
    "Int",
    "Type",
    "DT50 soil parent compound",
    "DT50 soil",
    "DT50 sw",
    "DT50 sed",
    "R/S",
    "Int"
    }


    Public Enum ePesticidetxtHeaderMember2

        ActiveSubstance
        CompoundCalculated
        Comment
        AI_Molmass
        MET_Molmass
        Watersolubility
        KOC
        DT50totalSystem
        MaxinWaterSediment
        MaxinSoil
        AppRate
        NumberofApp
        Timebetweenapp
        AppType
        DT50soil
        DT50water
        DT50sediment
        RegionSeason
        Interceptionclass

    End Enum

    Public Enum ePesticidetxtHeaderMember3

        ActiveSubstance
        CompoundCalculated
        Comment
        AI_Molmass
        MET_Molmass
        Watersolubility
        MET_KOC
        AI_KOC
        DT50totalSystem
        MaxinWaterSediment
        MaxinSoil
        AppRate
        NumberofApp
        Timebetweenapp
        AppType
        AI_DT50soil
        MET_DT50soil
        DT50water
        DT50sediment
        RegionSeason
        Interceptionclass

    End Enum


#End Region

#End Region

#Region "Methods"

    ''' <summary>
    ''' Get interception value regarding to Step12Crop and Step12Interception class
    ''' </summary>
    ''' <param name="Crop">
    ''' FOCUSStep12 Crop as enum
    ''' </param>
    ''' <param name="IntercClass">
    ''' Step12 InterceptionClass as enum
    ''' </param>
    ''' <returns>
    ''' Interception as double
    ''' </returns>
    ''' <remarks></remarks>
    Public Shared Function getInterceptionValue(Crop As eCrop,
                                         IntercClass As eInterceptionClass) As Double

        Try
            Return InterceptionValues(Crop, IntercClass)
        Catch ex As Exception
            Return Double.NaN
        End Try

    End Function


    ''' <summary>
    ''' Get runoff and drainage percentage regarding region and season
    ''' </summary>
    ''' <param name="Region">
    ''' NEU, SEU, 
    ''' </param>
    ''' <param name="Season"></param>
    ''' <returns>
    ''' runoff and drainage percentage as double
    ''' </returns>
    ''' <remarks></remarks>
    Public Shared Function getRoffDrainagePercValue(Region As eRegion,
                                             Season As eSeason) As Double

        Try

            Select Case Region

                Case eRegion.NEU, eRegion.SEU
                    'NEU  = 5, 2, 2; SEU = 4, 4, 3)
                    Return ROffDraingagePercValues(Region + Season)
                Case eRegion.NRD
                    'no runoff or drainage
                    Return 0
                Case Else
                    Return Double.NaN

            End Select

        Catch ex As Exception
            Return Double.NaN
        End Try

    End Function

#End Region

End Class

Public Class Step34

#Region "Misc"

#Region "Constants"

#Region "SWASH *_report.txt"



    Public Shared SWASHReportDATAHeader As String() =
   {
   "      **********************************************************************************************************************************",
   "      *  CREATED RUNS",
   "      **********************************************************************************************************************************",
   "      *",
   "      *                                                     |--------------- APPLICATION -----------------|------ on Water Surface ------|",
   "      * -ID------Crop(1st/2nd)-------Scenario-WaterbodyType-|-Method--------First/Last/Interval--#---Rate-|-Mean Deposition-Mass Loading-|",
   "                                                                                      (d)          (kg/ha) (% of Appl. Rate)    (mg/m2)",
   "      *"
   }

    Public Shared RowStart As String = "      *"

    Public Shared ReportTXTEnd As String =
        "      ************************************************** Surface WAter Scenarios Help **************************************************"


    Public Enum eSWASReportRows2Change
        ProgrammName = 4
        FileName = 6
        Description = 7
        Substance = 8
        CreationDate = 10
    End Enum


    Public Shared SWASHReportMetaData As String() =
        {"", "", "",
        "      * SWASH report file",
        "      * made by FOCUS-SWASH UI v. 5 (internal version 5.1.0, 02 April 2015) ",
        "      *",
        "      * File Name   : ",
        "      * Description : ",
        "      * Substance   : ",
        "      *",
        "      * Creation    : ",
        "      *",
        "      * Remarks : SWASH report helps you to set up the needed runs to calculate the PECsw and PECsed, occuring in the EU",
        "      *           for the selected substance, used on the selected crop. The scenario code informs you which models you need to",
        "      *           run for this scenario.",
        "      *           D1-D6: drainage entries calculated by the MACRO model, fate in surface water calculated by the TOXSWA model",
        "      *                  ",
        "      *           R1-R4: runoff and erosion entries calculated by the PRZM model, fate in surface water calculated by the TOXSWA model",
        "      *                  ",
        "      *",
        "      *           For STREAMS the Mean Deposition and Mass Loading, as calculated by the FOCUS Drift Calculator, have been multiplied by a ",
        "      *           factor 1.2 to account for pesticide mass incoming from the upstream catchment as decided by the FOCUS Surface Water ",
        "      *           Scenarios Working Group.",
        "      *",
        "      *"
            }

#End Region

#End Region


    Public Enum eUSDAClass

        Clay = 0
        Sandy_clay
        Silty_clay
        Loam
        Clay_loam
        Silty_clay_loam
        Silt_loam
        Silt
        Sandy_clay_loam
        Sandy_loam
        Sand
        Loamy_sand

        not_available

    End Enum

    Public Enum eFOCUSswScenarios

        D1
        D2
        D3
        D4
        D5
        D6

        R1
        R2
        R3
        R4

        not_defined

    End Enum

    Public Enum eSWASHCrops

        Cereals_spring
        Cereals_winter

        Citrus
        Cotton

        Field_beans
        Grass_alfalfa

        Hops

        Legumes
        Maize

        Oil_seed_rape_spring
        Oil_seed_rape_winter

        Olives

        Pome_stone_fruit_early_applns
        Pome_stone_fruit_late_applns

        Potatoes
        Soybeans
        Sugar_beets
        Sunflowers
        Tobacco

        Vegetables_bulb
        Vegetables_fruiting
        Vegetables_leafy
        Vegetables_root

        Vines_early_applns
        Vines_late_applns

        not_Defined

    End Enum

    Public Enum eGanzelmeierCropGroups

        ArableCrops = 0

        Fruitcropsearly
        Fruitcropslate

        Hops

        Vinesearly
        Vineslate

        Aerialappln

        not_Defined

    End Enum

    Public Enum eCropEvents

        emergence
        maturity
        harvest
        fall

        PHI

        not_defined

    End Enum



    Public Enum eWaterBody

        Ditch
        Pond
        Stream

        Ditch_Stream
        Pond_Stream

        not_defined

    End Enum

    Public Enum eSeasons

        first
        second

    End Enum

    Public Shared SeasonStringShort As String() =
      {"1st", "2nd"}

    Public Shared SeasonStringLong As String() =
        {"First", "Second"}

    Public Enum eAppMethodStep03

        Aerial
        AirBlast
        Granular
        GroundSpray
        SoilIncorp

        not_defined

    End Enum

    Public Shared ApplnMethods As String() =
      {
          "aerial appl.",
          "air blast",
          "granular appl.",
          "ground spray",
          "soil incorp."
      }


    Public Enum ePATMethod
        relative
        absolute
        PHI
    End Enum


    Public Shared ScenarioXWaterbody As String() =
        {
            "D1	Ditch_Stream",
            "D2	Ditch_Stream",
            "D3	Ditch",
            "D4	Pond_Stream",
            "D5	Pond_Stream",
            "D6	Ditch",
            "R1	Pond_Stream",
            "R2	Stream",
            "R3	Stream",
            "R4	Stream"
        }


#Region "CropDBs"

    Public Shared SWASHCrops2Ganzelmeier As eGanzelmeierCropGroups() =
{
    eGanzelmeierCropGroups.ArableCrops,
     eGanzelmeierCropGroups.ArableCrops,
     eGanzelmeierCropGroups.Fruitcropslate,
     eGanzelmeierCropGroups.ArableCrops,
     eGanzelmeierCropGroups.ArableCrops,
     eGanzelmeierCropGroups.ArableCrops,
     eGanzelmeierCropGroups.Hops,
     eGanzelmeierCropGroups.ArableCrops,
     eGanzelmeierCropGroups.ArableCrops,
     eGanzelmeierCropGroups.ArableCrops,
     eGanzelmeierCropGroups.ArableCrops,
     eGanzelmeierCropGroups.Fruitcropslate,
     eGanzelmeierCropGroups.Fruitcropsearly,
     eGanzelmeierCropGroups.Fruitcropslate,
     eGanzelmeierCropGroups.ArableCrops,
     eGanzelmeierCropGroups.ArableCrops,
     eGanzelmeierCropGroups.ArableCrops,
     eGanzelmeierCropGroups.ArableCrops,
     eGanzelmeierCropGroups.ArableCrops,
     eGanzelmeierCropGroups.ArableCrops,
     eGanzelmeierCropGroups.ArableCrops,
     eGanzelmeierCropGroups.ArableCrops,
     eGanzelmeierCropGroups.ArableCrops,
     eGanzelmeierCropGroups.Vinesearly,
     eGanzelmeierCropGroups.Vineslate,
     eGanzelmeierCropGroups.Aerialappln
}


    Public Shared SWASHCropNames As String() =
           {
               "Cereals, spring",
               "Cereals, winter",
               "Citrus",
               "Cotton",
               "Field beans",
               "Grass/alfalfa",
               "Hops",
               "Legumes",
               "Maize",
               "Oil seed rape, spring",
               "Oil seed rape, winter",
               "Olives",
               "Pome/stone fruit, early applns",
               "Pome/stone fruit, late applns",
               "Potatoes",
               "Soybeans",
               "Sugar beets",
               "Sunflowers",
               "Tobacco",
               "Vegetables, bulb",
               "Vegetables, fruiting",
               "Vegetables, leafy",
               "Vegetables, root",
               "Vines, early applns",
               "Vines, late applns",
               "not defined"
           }


#End Region


#End Region

#Region "Drainage"

#Region "Enums"

    Public Enum eMACROScenarios

        D1
        D2
        D3
        D4
        D5
        D6

        not_defined

    End Enum

    Public Enum eMACROCrops

        Cereals_winter
        Cereals_spring
        Oil_seed_rape_winter
        Oil_seed_rape_spring
        Sugar_beets
        Potatoes
        Field_beans
        Vegetables_root
        Vegetables_leafy
        Vegetables_bulb
        Legumes
        Vegetables_fruiting
        Maize
        Vines
        Pome_stone_fruit
        Grass_alfalfa
        Sunflowers
        Citrus
        Olives
        Cotton

        not_defined

    End Enum

#End Region

#Region "DB"

#Region "ZFINT"


    Public Shared Function getZFINT(DrainageScenario As eMACROScenarios,
                                    Crop As eMACROCrops,
                                    ApplnDay As Integer) As Double


        Dim ZFINT As Double = -1

        Dim DataArray As String() = {}

        Try

            DataArray = Filter(
                            Source:=MACRO_ZINT_Data,
                             Match:=DrainageScenario.ToString,
                           Include:=True,
                           Compare:=CompareMethod.Text)


            DataArray = Filter(
                            Source:=DataArray,
                             Match:=MacroCropTranslationMatrix(Crop),
                           Include:=True,
                           Compare:=CompareMethod.Text)

        Catch ex As Exception
            ZFINT = -1
        End Try


        Select Case Crop

            Case eMACROCrops.Citrus
                ZFINT = 0.7

            Case eMACROCrops.Grass_alfalfa
                ZFINT = 0.9

            Case Else

                If DataArray.Count = 0 Then

                    ZFINT = -1

                Else

                    DataArray = DataArray.First.Split(CChar("|"))

                    ZFINT = getZFINT(
                                  irrday:=ApplnDay,
                                   idmax:=CInt(DataArray(eZINT_DataMember.idmax)),
                                   cform:=CDbl(DataArray(eZINT_DataMember.cform)),
                                 idstart:=CInt(DataArray(eZINT_DataMember.idstart)),
                                   iharv:=CInt(DataArray(eZINT_DataMember.iharv)),
                                  laimax:=CDbl(DataArray(eZINT_DataMember.laimax)),
                                  laimin:=CDbl(DataArray(eZINT_DataMember.laimin)),
                                  maxint:=CDbl(DataArray(eZINT_DataMember.maxint)),
                                zdatemin:=CInt(DataArray(eZINT_DataMember.zdatemin)))

                End If

        End Select

        Return ZFINT

    End Function

    <DebuggerStepThrough>
    Public Shared Function getZFINT(
                           idmax As Integer,
                           idstart As Integer,
                           irrday As Integer,
                           iharv As Integer,
                           zdatemin As Integer,
                           laimin As Double,
                           laimax As Double,
                           cform As Double,
                           maxint As Double) As Double

        Dim LAI As Double = 0
        Dim dummy As Double = 0

        If idmax > idstart Then
            If irrday > zdatemin And irrday <= idmax Then
                LAI = laimin + (laimax - laimin) * ((irrday - idstart) / (idmax - idstart)) ^ cform
            ElseIf irrday <= idstart Or irrday > iharv Then
                LAI = 0
            ElseIf irrday = zdatemin Then
                LAI = laimin
            Else
                LAI = laimax
            End If
        Else
            If irrday <= idstart And irrday > iharv Then
                LAI = 0
            ElseIf irrday > idstart Then
                LAI = laimin * ((irrday - idstart) / (zdatemin + 365 - idstart))
            ElseIf irrday < zdatemin Then
                LAI = laimin * ((irrday - idstart + 365) / (zdatemin + 365 - idstart))
            Else
                If irrday < idmax Then
                    LAI = laimin + (laimax - laimin) * ((irrday - zdatemin) / (idmax - zdatemin)) ^ cform
                Else
                    LAI = laimax
                End If
            End If
        End If

        dummy = (LAI / laimax) * maxint

        Return (LAI / laimax) * maxint


    End Function



    Public Enum eZINT_DataMember
        location
        name
        cform
        idstart
        idmax
        iharv
        laimax
        laimin
        zdatemin
        maxint
    End Enum

    Public Shared MACRO_ZINT_Data As String() =
        {
"D1|Cereals, winter|2|268|174|238|6|1|84|0.9",
"D1|Oil seed rape, spring|1.7|139|185|251|4|0.01|140|0.9",
"D1|Cereals, spring|2|125|179|247|4|0.01|126|0.9",
"D2|Oil seed rape, winter|2|258|166|196|5|1|69|0.9",
"D2|Cereals, winter|2|298|181|219|6|1|94|0.9",
"D3|Cereals, winter|2|325|205|227|6|1|106|0.9",
"D3|Maize|1.7|125|222|263|5|0.01|126|0.9",
"D3|Potatoes|1.7|130|201|258|4|0.01|131|0.8",
"D3|Sugar beets|1.7|115|206|291|5|0.01|116|0.9",
"D3|Oil seed rape, winter|2|245|145|201|5|1|51|0.9",
"D3|Pome/stone fruit|1.5|105|182|303|4|0.01|106|0.8",
"D3|Field beans|1.7|120|196|253|4|0.01|121|0.8",
"D3|Vegetables, leafy|1.5|115|156|201|3|0.01|116|0.9",
"D3|Legumes|2|105|166|222|4|0.01|106|0.85",
"D3|Vegetables, root|1.5|115|181|227|3|0.01|116|0.8",
"D3|Vegetables, bulb|1.5|115|181|244|3|0.01|116|0.6",
"D4|Cereals, winter|2|265|172|233|6|1|77|0.9",
"D4|Cereals, spring|2|116|170|238|4|0.01|117|0.9",
"D4|Maize|1.7|130|230|255|5|0.01|131|0.9",
"D4|Potatoes|1.7|142|233|266|4|0.01|143|0.8",
"D4|Sugar beets|1.7|124|209|298|5|0.01|125|0.9",
"D4|Oil seed rape, winter|2|246|156|221|5|1|60|0.9",
"D4|Oil seed rape, spring|1.7|121|168|243|4|0.01|122|0.9",
"D4|Legumes|2|113|171|222|4|0.01|114|0.85",
"D4|Field beans|1.7|105|191|237|4|0.01|106|0.8",
"D5|Cereals, winter|2|314|135|196|6|1|74|0.9",
"D5|Maize|1.7|130|196|258|5|0.01|131|0.9",
"D5|Cereals, spring|2|74|135|201|4|0.01|75|0.9",
"D5|Legumes|2|74|150|196|4|0.01|75|0.85",
"D5|Oil seed rape, spring|1.7|74|145|211|4|0.01|75|0.9",
"D5|Oil seed rape, winter|2|263|130|186|5|1|60|0.9",
"D5|Pome/stone fruit|1.5|91|151|283|4|0.01|92|0.8",
"D6|Cereals, winter|2|334|89|181|6|1|46|0.9",
"D6|Maize|1.7|110|166|258|5|0.01|111|0.9",
"D6|Vegetables, leafy|1.5|227|273|334|3|0.01|228|0.9",
"D6|Field beans|1.7|91|121|166|4|0.01|92|0.8",
"D6|Vegetables, bulb|1.5|130|181|212|3|0.01|131|0.6",
"D6|Vegetables, fruiting|1.5|100|150|222|3|0.01|101|0.8",
"D6|Citrus|0|0|0|0|0|0|0|0.7",
"D6|Olives|0|0|0|0|0|0|0|0.8",
"D3|Cereals, spring|2|91|156|232|4|0.01|92|0.9",
"D6|Potatoes|1.7|100|150|196|4|0.01|101|0.8",
"D2|Field beans|1.7|316|180|258|4|1|100|0.8",
"D1|Grass/alfalfa|0|0|0|0|0|0|0|0.9",
"D2|Grass/alfalfa|0|0|0|0|0|0|0|0.9",
"D3|Oil seed rape, spring|1.7|100|166|237|4|0.01|101|0.9",
"D3|Grass/alfalfa|0|0|0|0|0|0|0|0.9",
"D4|Grass/alfalfa|0|0|0|0|0|0|0|0.9",
"D4|Vegetables, leafy|1.5|130|201|269|3|0.01|131|0.9",
"D4|Vegetables, bulb|1.5|113|191|256|3|0.01|114|0.6",
"D4|Pome/stone fruit|1.5|110|186|303|4|0.01|111|0.8",
"D6|Vines|1.5|31|121|314|5|0.01|33|0.85",
"D5|Grass/alfalfa|0|0|0|0|0|0|0|0.9",
"D6|Cotton|1.7|110|161|258|5|0.01|111|0.9",
"D6|Legumes|2|110|140|176|4|0.01|111|0.85",
"D6|Vegetables, root|1.5|56|105|133|3|0.01|56|0.8",
"D5|Sunflowers|1.7|121|191|243|4|0.01|122|0.9"
}

#End Region

#Region "CropData"



    Public Shared SWASH2MACROCrops As eMACROCrops() =
        {
            eMACROCrops.Cereals_spring,
            eMACROCrops.Cereals_winter,
            eMACROCrops.Citrus,
            eMACROCrops.Cotton,
            eMACROCrops.Field_beans,
            eMACROCrops.Grass_alfalfa,
            eMACROCrops.not_defined,
            eMACROCrops.Legumes,
            eMACROCrops.Maize,
            eMACROCrops.Oil_seed_rape_spring,
            eMACROCrops.Oil_seed_rape_winter,
            eMACROCrops.Olives,
            eMACROCrops.Pome_stone_fruit,
            eMACROCrops.Pome_stone_fruit,
            eMACROCrops.Potatoes,
            eMACROCrops.not_defined,
            eMACROCrops.Sugar_beets,
            eMACROCrops.Sunflowers,
            eMACROCrops.not_defined,
            eMACROCrops.Vegetables_bulb,
            eMACROCrops.Vegetables_fruiting,
            eMACROCrops.Vegetables_leafy,
            eMACROCrops.Vegetables_root,
            eMACROCrops.Vines,
            eMACROCrops.Vines,
            eMACROCrops.not_defined
            }




    Public Shared MacroCropTranslationMatrix As String() =
             {
                "Cereals, winter",
                "Cereals, spring",
                "Oil seed rape, winter",
                "Oil seed rape, spring",
                "Sugar beets",
                "Potatoes",
                "Field beans",
                "Vegetables, root",
                "Vegetables, leafy",
                "Vegetables, bulb",
                "Legumes",
                "Vegetables, fruiting",
                "Maize",
                "Vines",
                "Pome/stone fruit",
                "Grass/alfalfa",
                "Sunflowers",
                "Citrus",
                "Olives",
                "Cotton"
              }

    ''' <summary>
    ''' translation of MACRO crops and combobox location
    ''' </summary>
    ''' <remarks></remarks>
    Public Shared MacroCropNumber As Dictionary(Of String,
                                            Integer) = New Dictionary(Of String,
                                                                         Integer) From
            {{"Cereals, winter", 0},
            {"Cereals, spring", 1},
            {"Oil seed rape, winter", 2},
            {"Oil seed rape, spring", 3},
            {"Sugar beets", 4},
            {"Potatoes", 5},
            {"Field beans", 6},
            {"Vegetables, root", 7},
            {"Vegetables, leafy", 8},
            {"Vegetables, bulb", 9},
            {"Legumes", 10},
            {"Vegetables, fruiting", 11},
            {"Maize", 12},
            {"Vines, late applns", 13},
            {"Vines, early applns", 13},
            {"Pome/stone fruit, early applns", 14},
            {"Pome/stone fruit, late applns", 14},
            {"Grass/alfalfa", 15},
            {"Sunflowers", 16},
            {"Citrus", 17},
            {"Olives", 18},
            {"Cotton", 19}}


    Public Enum eDrainageCropDataMember

        Scenario
        CropName
        Season
        Emergence
        Maturity
        Harvest

    End Enum

    Public Shared DrainageCropData As String() =
   {
"D1 	Cereals, spring                 	1st 	010505 	010628 	010904",
"D1 	Cereals, winter                 	1st 	010925 	020623 	020826",
"D1 	Grass/alfalfa                   	1st 	010101 	010415 	011231",
"D1 	Oil seed rape, spring            	1st 	010519 	010704 	010908",
"D2 	Cereals, winter                 	1st 	011025 	020630 	020807",
"D2 	Field beans                     	1st 	011112 	020629 	020915",
"D2 	Grass/alfalfa                   	1st 	010101 	010415 	011231",
"D2 	Oil seed rape, winter            	1st 	010915 	020615 	020715",
"D3 	Cereals, spring                 	1st 	010401 	010605 	010820",
"D3 	Cereals, winter                 	1st 	011121 	020724 	020815",
"D3 	Field beans                     	1st 	010430 	010715 	010910",
"D3 	Grass/alfalfa                   	1st 	010101 	010415 	011231",
"D3 	Legumes                         	1st 	010415 	010615 	010810",
"D3 	Maize                           	1st 	010505 	010810 	010920",
"D3 	Oil seed rape, spring            	1st 	010410 	010615 	010825",
"D3 	Oil seed rape, winter            	1st 	010902 	020525 	020720",
"D3 	Pome/stone fruit, early applns  	1st 	010415 	010701 	011030",
"D3 	Pome/stone fruit, late applns   	1st 	010415 	010701 	011030",
"D3 	Potatoes                        	1st 	010510 	010720 	010915",
"D3 	Sugar beets                     	1st 	010425 	010725 	011018",
"D3 	Vegetables, bulb                	1st 	010425 	010630 	010901",
"D3 	Vegetables, leafy               	1st 	010425 	010605 	010720",
"D3 	Vegetables, leafy               	2nd 	010805 	010910 	011020",
"D3 	Vegetables, root                	1st 	010425 	010630 	010815",
"D4 	Cereals, spring                 	1st 	010426 	010619 	010826",
"D4 	Cereals, winter                 	1st 	010922 	020621 	020821",
"D4 	Field beans                     	1st 	010415 	010710 	010825",
"D4 	Grass/alfalfa                   	1st 	010101 	010415 	011231",
"D4 	Legumes                         	1st 	010423 	010620 	010810",
"D4 	Maize                           	1st 	010510 	010818 	010912",
"D4 	Oil seed rape, spring            	1st 	010501 	010617 	010831",
"D4 	Oil seed rape, winter            	1st 	010903 	020605 	020809",
"D4 	Pome/stone fruit, early applns  	1st 	010420 	010705 	011030",
"D4 	Pome/stone fruit, late applns   	1st 	010420 	010705 	011030",
"D4 	Potatoes                        	1st 	010522 	010821 	010923",
"D4 	Sugar beets                     	1st 	010504 	010728 	011025",
"D4 	Vegetables, bulb                	1st 	010423 	010710 	010913",
"D4 	Vegetables, leafy               	1st 	010510 	010720 	010926",
"D5 	Cereals, spring                 	1st 	010315 	010515 	010720",
"D5 	Cereals, winter                 	1st 	011110 	020515 	020715",
"D5 	Grass/alfalfa                   	1st 	010101 	010415 	011231",
"D5 	Legumes                         	1st 	010315 	010530 	010715",
"D5 	Maize                           	1st 	010510 	010715 	010915",
"D5 	Oil seed rape, spring            	1st 	010315 	010525 	010730",
"D5 	Oil seed rape, winter            	1st 	010920 	020510 	020705",
"D5 	Pome/stone fruit, early applns  	1st 	010401 	010531 	011010",
"D5 	Pome/stone fruit, late applns   	1st 	010401 	010531 	011010",
"D5 	Sunflowers                      	1st 	010501 	010710 	011031",
"D6 	Cereals, winter                 	1st 	011130 	020330 	020630",
"D6 	Citrus                          	1st 	010101 	010415 	011231",
"D6 	Cotton                          	1st 	010420 	010610 	010915",
"D6 	Field beans                     	1st 	010401 	010501 	010615",
"D6 	Field beans                     	2nd 	010708 	010808 	010930",
"D6 	Legumes                         	1st 	010420 	010520 	010625",
"D6 	Maize                           	1st 	010420 	010615 	010915",
"D6 	Olives                          	1st 	010330 	010609 	010820",
"D6 	Potatoes                        	1st 	010410 	010530 	010715",
"D6 	Potatoes                        	2nd 	010805 	010930 	011125",
"D6 	Vegetables, bulb                	1st 	010510 	010630 	010731",
"D6 	Vegetables, bulb                	2nd 	011020 	020310 	020410",
"D6 	Vegetables, fruiting            	1st 	010410 	010530 	010810",
"D6 	Vegetables, leafy               	1st 	010815 	010930 	011130",
"D6 	Vegetables, root                	1st 	010225 	010415 	010513",
"D6 	Vines, early applns             	1st 	010201 	010501 	011110",
"D6 	Vines, late applns              	1st 	010201 	010501 	011110"
    }



#End Region

#End Region

#End Region

#Region "RunOff"

#Region "Enums"

    Public Enum eCAM

        SoilLinear_1 = 1
        FoliarLinear_2 = 2

        IncorpUniform_4 = 4
        IncorpLinIncrease_5 = 5
        IncorpLinDecrease_6 = 6
        IncorpOneDepth_8 = 8

        not_defined

    End Enum

    Public Enum ePRZMScenarios

        R1
        R2
        R3
        R4

        not_defined

    End Enum

    Public Enum ePRZMCrop

        Cereals_Spring
        Cereals_Winter
        Citrus
        Field_beans
        Grass_alfalfa
        Hops
        Legumes
        Maize
        Oil_seed_rape_spring
        Oil_seed_rape_winter
        Olives
        Pome_stone_fruit
        Potatoes
        Soybeans
        Sugar_beets
        Sunflowers
        Tobacco
        Vegetables_bulb
        Vegetables_fruiting
        Vegetables_leafy
        Vegetables_root
        Vines

        not_defined

    End Enum

#End Region

#Region "DB"

#Region "File naming"

    Public Shared RunOffMetFiles As String(,) =
      {
      {"notDef", "notDef", "notDef", "R4noirr"},
      {"R1noirr", "notDef", "R3noirr", "R4noirr"},
      {"notDef", "notDef", "notDef", "R4citrs"},
      {"R1noirr", "R2noirr", "R3fldbn", "R4fldbn"},
      {"notDef", "R2noirr", "R3noirr", "notDef"},
      {"R1hops", "notDef", "notDef", "notDef"},
      {"R1legum", "R2noirr", "R3legum", "R4legum"},
      {"R1maize", "R2noirr", "R3maize", "R4maize"},
      {"R1noirr", "notDef", "notDef", "notDef"},
      {"R1noirr", "notDef", "R3noirr", "notDef"},
      {"notDef", "notDef", "notDef", "R4noirr"},
      {"R1noirr", "R2noirr", "R3noirr", "R4noirr"},
      {"R1potat", "R2noirr", "R3potat", "notDef"},
      {"notDef", "notDef", "R3soybn", "R4soybn"},
      {"R1sugbt", "notDef", "R3sugbt", "notDef"},
      {"R1sunfl", "notDef", "R3sunfl", "R4sunfl"},
      {"notDef", "notDef", "R3tobac", "notDef"},
      {"R1buveg", "R2noirr", "R3buveg", "R4buveg"},
      {"notDef", "R2noirr", "R3frveg", "R4frveg"},
      {"R1levveg", "R2noirr", "R3leveg", "R4leveg"},
      {"R1roveg", "R2noirr", "R3roveg", "R4roveg"},
      {"R1noirr", "R2noirr", "notDef", "R4noirr"}
      }

    Public Shared RunOffFOCUSCropAbreviation As String() =
        {
        "CS",
        "CW",
        "CI",
        "FB",
        "GA",
        "HP",
        "LG",
        "MZ",
        "OS",
        "OW",
        "OL",
        "PF",
        "PS",
        "SY",
        "SB",
        "SU",
        "TB",
        "VB",
        "VF",
        "VL",
        "VR",
        "VI"
        }

#End Region

    Public Shared RunOffOC As Double(,) =
          {
              {1.2, 1.2, 0.3, 0.1, Double.NaN},
              {4.0, 4.0, 2.4, 0.8, 0.5},
              {1.0, 1.0, 1.0, 0.35, 0.29},
              {0.6, 0.6, 0.6, 0.6, 0.08}
          }

#Region "Crop event data"


    Public Enum eRunOffCropDataMember

        Scenario
        CropName
        Season
        Emergence
        Maturity
        Harvest
        Fall

    End Enum

    Public Shared RunOffCropData As String() =
  {
"R1 	Cereals, winter                 	 1st 	011112 	020610 	020731	021101",
"R1 	Field beans                     	 1st 	010410 	010710 	010825	011101",
"R1 	Hops                            	 1st 	010415 	010827 	010901	011101",
"R1 	Legumes                         	 1st 	010415 	010612 	010815	011101",
"R1 	Maize                           	 1st 	010503 	010807 	010925	011101",
"R1 	Oil seed rape, spring           	 1st 	010410 	010607 	010815	011101",
"R1 	Oil seed rape, winter           	 1st 	010904 	020525 	020710	011101",
"R1 	Pome/stone fruit, early applns  	 1st 	010415 	010701 	011030	011101",
"R1 	Pome/stone fruit, late applns   	 1st 	010415 	010701 	011030	011101",
"R1 	Potatoes                        	 1st 	010505 	010625 	010908	011101",
"R1 	Sugar beets                     	 1st 	010416 	010715 	011010	011101",
"R1 	Sunflowers                      	 1st 	010501 	010705 	010831	011101",
"R1 	Vegetables, bulb                	 1st 	010420 	010625 	010825	011101",
"R1 	Vegetables, leafy               	 1st 	010420 	010531 	010715	010720",
"R1 	Vegetables, leafy               	 2nd 	010731 	010905 	011015	011101",
"R1 	Vegetables, root                	 1st 	010420 	010625 	010810	011101",
"R1 	Vines, early applns             	 1st 	010415 	010701 	011030	011101",
"R1 	Vines, late applns              	 1st 	010415 	010701 	011030	011101",
"R2 	Field beans                     	 1st 	010310 	010515 	010831	011101",
"R2 	Grass/alfalfa                   	 1st 	010102 	010103 	011230	011231",
"R2 	Legumes                         	 1st 	010420 	010520 	010625	011101",
"R2 	Maize                           	 1st 	010501 	010815 	011001	011101",
"R2 	Pome/stone fruit, early applns  	 1st 	010315 	010731 	010930	011101",
"R2 	Pome/stone fruit, late applns   	 1st 	010315 	010731 	010930	011101",
"R2 	Potatoes                        	 1st 	010315 	010530 	010615	011101",
"R2 	Vegetables, bulb                	 1st 	010228 	010515 	010531	011101",
"R2 	Vegetables, fruiting            	 1st 	010315 	010615 	010831	011101",
"R2 	Vegetables, leafy               	 1st 	010228 	010515 	010701	010715",
"R2 	Vegetables, leafy               	 2nd 	010731 	010831 	011115	011101",
"R2 	Vegetables, root                	 1st 	010228 	010501 	010531	010701",
"R2 	Vegetables, root                	 2nd 	010722 	010915 	011015	011101",
"R2 	Vines, early applns             	 1st 	010315 	010731 	010930	011101",
"R2 	Vines, late applns              	 1st 	010315 	010731 	010930	011101",
"R3 	Cereals, winter                 	 1st 	011201 	020510 	020701	011101",
"R3 	Field beans                     	 1st 	010402 	010501 	010615	011101",
"R3 	Grass/alfalfa                   	 1st 	010102 	010103 	011230	011231",
"R3 	Legumes                         	 1st 	010421 	010520 	010625	011101",
"R3 	Maize                           	 1st 	010501 	010725 	011001	011101",
"R3 	Oil seed rape, winter           	 1st 	011005 	020420 	020605	011101",
"R3 	Pome/stone fruit, early applns  	 1st 	010401 	010531 	011015	011101",
"R3 	Pome/stone fruit, late applns   	 1st 	010401 	010531 	011015	011101",
"R3 	Potatoes                        	 1st 	010410 	010530 	010901	011101",
"R3 	Soybeans                         	 1st 	010510 	010731 	011005	011101",
"R3 	Sugar beets                     	 1st 	010320 	010625 	010903	011101",
"R3 	Sunflowers                      	 1st 	010415 	010625 	010920	011101",
"R3 	Tobacco                         	 1st 	010520 	010720 	011005	011101",
"R3 	Vegetables, bulb                	 1st 	010301 	010515 	010531	011101",
"R3 	Vegetables, fruiting            	 1st 	010510 	010630 	010825	011101",
"R3 	Vegetables, leafy               	 1st 	010301 	010501 	010601	010610",
"R3 	Vegetables, leafy               	 2nd 	010615 	010815 	010915	011101",
"R3 	Vegetables, root                	 1st 	010226 	010415 	010513	011101",
"R3 	Vines, early applns             	 1st 	010401 	010731 	011101	011101",
"R3 	Vines, late applns              	 1st 	010401 	010731 	011101	011101",
"R4 	Cereals, spring                 	 1st 	010315 	010515 	010720	011101",
"R4 	Cereals, winter                 	 1st 	011110 	020515 	020715	011101",
"R4 	Citrus                          	 1st 	010315 	010630 	011015	011231",
"R4 	Field beans                     	 1st 	010402 	010501 	010615	011101",
"R4 	Legumes                         	 1st 	010421 	010520 	010625	011101",
"R4 	Maize                           	 1st 	010410 	010615 	010831	011101",
"R4 	Olives                          	 1st 	010330 	010609 	010820	011231",
"R4 	Pome/stone fruit, early applns  	 1st 	010315 	010531 	011015	011101",
"R4 	Pome/stone fruit, late applns   	 1st 	010315 	010531 	011015	011101",
"R4 	Soybeans                         	 1st 	010310 	010720 	010920	011101",
"R4 	Sunflowers                      	 1st 	010330 	010620 	010820	011101",
"R4 	Vegetables, bulb                	 1st 	010301 	010515 	010531	011101",
"R4 	Vegetables, fruiting            	 1st 	010420 	010610 	010715	011101",
"R4 	Vegetables, leafy               	 1st 	010301 	010501 	010601	010610",
"R4 	Vegetables, leafy               	 2nd 	010615 	010815 	010915	011101",
"R4 	Vegetables, root                	 1st 	010226 	010415 	010513	011101",
"R4 	Vines, early applns             	 1st 	010310 	010720 	010920	011101",
"R4 	Vines, late applns              	 1st 	010310 	010720 	010920	011101"
      }

#End Region

#Region "ApplnMethodXCAM"

    Public CAMSpray As String() =
        {
               "1 - appln soil linear",
               "2 - appln foliar linear"
        }

    Public CAMSoil As String() =
        {
             "1 - appln soil linear",
             "4 - incorp soil uniform",
             "5 - incorp soil lin. increase",
             "6 - incorp soil lin. decrease",
             "8 - incorp soil at one depth"
        }


    Public MethodXCam As String() =
        {
            "aerial appl.	1 - appln soil linear",
            "aerial appl.	2 - appln foliar linear",
            "air blast	1 - appln soil linear",
            "air blast	2 - appln foliar linear",
            "granular appl.	1 - appln soil linear",
            "granular appl.	4 - incorp soil uniform",
            "granular appl.	5 - incorp soil lin. increase",
            "granular appl.	6 - incorp soil lin. decrease",
            "granular appl.	8 - incorp soil at one depth",
            "ground spray	1 - appln soil linear",
            "ground spray	2 - appln foliar linear",
            "soil incorp.	1 - appln soil linear",
            "soil incorp.	4 - incorp soil uniform",
            "soil incorp.	5 - incorp soil lin. increase",
            "soil incorp.	6 - incorp soil lin. decrease",
            "soil incorp.	8 - incorp soil at one depth"
         }

#End Region

#End Region


#Region "Season"


    Public Shared Function getFOCUSp2tYearStart(RunOffScenario As ePRZMScenarios, ApplnMonth As Integer) As Date

        Select Case RunOffScenario

            Case ePRZMScenarios.R1

                Select Case ApplnMonth

                    Case 3, 4, 5
                        Return New Date(year:=1984,
                                       month:=3,
                                         day:=1)

                    Case 6, 7, 8, 9
                        Return New Date(year:=1978,
                                       month:=7,
                                         day:=1)

                    Case Else
                        Return New Date(year:=1978,
                                       month:=10,
                                         day:=1)

                End Select

            Case ePRZMScenarios.R2

                Select Case ApplnMonth

                    Case 3, 4, 5
                        Return New Date(year:=1977,
                                       month:=3,
                                         day:=1)

                    Case 6, 7, 8, 9
                        Return New Date(year:=1989,
                                       month:=7,
                                         day:=1)

                    Case Else
                        Return New Date(year:=1977,
                                       month:=10,
                                         day:=1)

                End Select

            Case ePRZMScenarios.R3

                Select Case ApplnMonth

                    Case 3, 4, 5
                        Return New Date(year:=1980,
                                       month:=3,
                                         day:=1)

                    Case 6, 7, 8, 9
                        Return New Date(year:=1975,
                                       month:=7,
                                         day:=1)

                    Case Else
                        Return New Date(year:=1980,
                                       month:=10,
                                         day:=1)

                End Select

            Case ePRZMScenarios.R4

                Select Case ApplnMonth

                    Case 3, 4, 5
                        Return New Date(year:=1984,
                                       month:=3,
                                         day:=1)

                    Case 6, 7, 8, 9
                        Return New Date(year:=1985,
                                       month:=7,
                                         day:=1)

                    Case Else
                        Return New Date(year:=1979,
                                       month:=10,
                                         day:=1)

                End Select

            Case Else

                Return New Date

        End Select

    End Function


    Public Shared Function getFOCUSp2tYearEnd(RunOffScenario As ePRZMScenarios, ApplnMonth As Integer) As Date



        Select Case RunOffScenario

            Case ePRZMScenarios.R1

                Select Case ApplnMonth

                    Case 3, 4, 5
                        Return New Date(year:=1985,
                                       month:=2,
                                         day:=28)

                    Case 6, 7, 8, 9
                        Return New Date(year:=1979,
                                       month:=5,
                                         day:=31)

                    Case Else
                        Return New Date(year:=1979,
                                       month:=9,
                                         day:=30)

                End Select

            Case ePRZMScenarios.R2

                Select Case ApplnMonth

                    Case 3, 4, 5
                        Return New Date(year:=1978,
                                       month:=2,
                                         day:=28)

                    Case 6, 7, 8, 9
                        Return New Date(year:=1990,
                                       month:=5,
                                         day:=31)

                    Case Else
                        Return New Date(year:=1978,
                                       month:=9,
                                         day:=30)

                End Select

            Case ePRZMScenarios.R3

                Select Case ApplnMonth

                    Case 3, 4, 5
                        Return New Date(year:=1981,
                                       month:=2,
                                         day:=28)

                    Case 6, 7, 8, 9
                        Return New Date(year:=1976,
                                       month:=5,
                                         day:=31)

                    Case Else
                        Return New Date(year:=1981,
                                       month:=9,
                                         day:=30)

                End Select

            Case ePRZMScenarios.R4

                Select Case ApplnMonth

                    Case 3, 4, 5
                        Return New Date(year:=1985,
                                       month:=2,
                                         day:=28)

                    Case 6, 7, 8, 9
                        Return New Date(year:=1986,
                                       month:=5,
                                         day:=31)

                    Case Else
                        Return New Date(year:=1980,
                                       month:=9,
                                         day:=30)

                End Select

            Case Else

                Return New Date

        End Select

    End Function


    Public Shared Function getP2TAppTiming(FOCUSStartDate As Date,
                                            FOCUSEndDate As Date) As String()

        Dim Result As New List(Of String)

        With Result

            .Add("*  Selected 50th percentile year:     " & FOCUSStartDate.Year)
            Select Case FOCUSStartDate.Month

                Case 3
                    .Add("*  Season of first application:       spring (Mar-May)")

                Case 7
                    .Add("*  Season of first application:       summer (Jun-Sep)")

                Case 10
                    .Add("*  Season of first application:       autumn (Oct-Feb)")

            End Select

            .Add("*  Selected 12 month period:          " &
                 FOCUSStartDate.ToString("dd-MMM-yyyy") & " to " & FOCUSEndDate.ToString("dd-MMM-yyyy"))

        End With

        Return Result.ToArray

    End Function

#End Region

#End Region


#Region "Methods"

    ''' <summary>
    ''' Get the date of the crop event for a given crop as scenario
    ''' </summary>
    ''' <param name="Crop">
    ''' FOCUS Step03 Crop
    ''' </param>
    ''' <param name="CropEvent">
    ''' Emergence, maturity or harvest
    ''' </param>
    ''' <param name="Scenario">
    ''' D1 to R4
    ''' </param>
    ''' <param name="Season">
    ''' Optional season , std. = 1st
    ''' </param>
    ''' <returns>Crop event as date</returns>
    ''' <remarks></remarks>
    Public Shared Function getCropTiming(Crop As eSWASHCrops,
                                  CropEvent As eCropEvents,
                                  Scenario As eFOCUSswScenarios,
                         Optional Season As eSeasons = eSeasons.first) As Date

        Dim RunArray As String() = {}
        Dim DateString As String = ""
        Dim ReturnDate As New Date
        Dim DateStringArray As String() = {}

        'get all possible runs for this crop
        RunArray = getRuns(Crop:=Crop,
                           ScenarioSelection:=eScenarioSelection.AllScenarios).ToArray

        'filter by scenario
        RunArray = Filter(Source:=RunArray,
                           Match:=Scenario.ToString,
                         Include:=True,
                         Compare:=CompareMethod.Text)

        'no runs for this crop and scenario
        If RunArray.Length = 0 Then
            mylog(LogTxt:="Can't get crop event " & CropEvent.ToString &
                                      " for " & Crop.ToString &
                                      " season " & Season.ToString &
                                      " and scenario " & Scenario.ToString)

            Return Nothing

        End If

        'first season is always there
        If Season = eSeasons.first Then
            DateString = RunArray.First
        Else
            'no second season
            If RunArray.Length = 1 Then
                mylog(LogTxt:="Can't get crop event " & CropEvent.ToString &
                                          " for " & Crop.ToString &
                                          " season " & Season.ToString &
                                          " and scenario " & Scenario.ToString & vbCrLf &
                                          " No 2nd season!")

                Return Nothing

            End If
            DateString = RunArray.Last
        End If


        DateStringArray = DateString.Split(CChar(vbTab))

        Try
            Select Case CropEvent

                Case eCropEvents.emergence
                    DateString = DateStringArray(eDrainageCropDataMember.Emergence)
                Case eCropEvents.maturity
                    DateString = DateStringArray(eDrainageCropDataMember.Maturity)
                Case eCropEvents.harvest
                    DateString = DateStringArray(eDrainageCropDataMember.Harvest)

                Case eCropEvents.fall
                    If Scenario.ToString.StartsWith("R") Then
                        DateString = DateStringArray(eDrainageCropDataMember.Harvest + 1)
                    End If

            End Select

            ReturnDate = New Date(1900 + Integer.Parse(DateString.Substring(0, 2)),
                                         Integer.Parse(DateString.Substring(2, 2)),
                                         Integer.Parse(DateString.Substring(4, 2)))


        Catch ex As Exception

            mylog(LogTxt:="Can't get crop event " & CropEvent.ToString &
                           " for " & Crop.ToString &
                           " season " & Season.ToString &
                           " and scenario " & Scenario.ToString &
                           vbCrLf & DateString & vbCrLf &
                           Join(ErrorHandling.parseExceptionMsg(ex), vbCrLf))

            Return Nothing

        End Try

        Return ReturnDate

    End Function


    Public Enum eScenarioSelection
        DrainageOnly
        RunOffOnly
        AllScenarios
    End Enum

    ''' <summary>
    ''' Get all drain. and runoff runs for this crop
    ''' </summary>
    ''' <param name="Crop">
    ''' FOCUS step03 crop
    ''' </param>
    ''' <returns>
    ''' List of strings with rundata
    ''' </returns>
    ''' <remarks></remarks>
    Public Shared Function getRuns(Crop As eSWASHCrops,
                        Optional ScenarioSelection As eScenarioSelection = eScenarioSelection.AllScenarios,
                        Optional Scenario As Step34.eFOCUSswScenarios = eFOCUSswScenarios.not_defined,
                        Optional Season As Step34.eSeasons = eSeasons.first) As List(Of String)

        Dim RunList As New List(Of String)
        Dim SourceList As New List(Of String)


        Select Case ScenarioSelection

            Case eScenarioSelection.DrainageOnly
                SourceList.AddRange(DrainageCropData)
                SourceList.AddRange(RunOffCropData)

            Case eScenarioSelection.DrainageOnly
                SourceList.AddRange(DrainageCropData)

            Case Else
                SourceList.AddRange(RunOffCropData)

        End Select

        RunList.AddRange(Filter(Source:=SourceList.ToArray,
                                     Match:=SWASHCropNames(Crop),
                                   Include:=True,
                                   Compare:=CompareMethod.Binary))

        If Scenario <> eFOCUSswScenarios.not_defined Then

            SourceList.Clear()
            SourceList.AddRange(RunList)
            RunList.Clear()

            RunList.AddRange(Filter(Source:=SourceList.ToArray,
                                     Match:=Scenario.ToString,
                                   Include:=True,
                                   Compare:=CompareMethod.Binary))

            If Season <> eSeasons.first And RunList.Count > 1 Then

                SourceList.Clear()
                SourceList.AddRange(RunList)
                RunList.Clear()

                RunList.AddRange(Filter(Source:=SourceList.ToArray,
                                     Match:="2nd",
                                   Include:=True,
                                   Compare:=CompareMethod.Binary))

            End If


        End If

        Return RunList

    End Function


    Public Shared Function getAllCropsForThisScenario(Scenario As Step34.ePRZMScenarios) As List(Of String)

        Dim RunList As New List(Of String)
        Dim CropData As String() = {}

        Dim OutList As New List(Of String)

        RunList.AddRange(Filter(Source:=RunOffCropData, Match:=Scenario.ToString, Include:=True, Compare:=CompareMethod.Text))

        For Each Run As String In RunList

            If Run.Contains("2nd") Then Continue For
            CropData = Run.Split({vbTab}, StringSplitOptions.RemoveEmptyEntries)

            OutList.Add(CropData(1))

        Next

        Return OutList

    End Function


    Public Shared Function getRuns(Crop As eSWASHCrops,
                                   Scenario As Step34.eFOCUSswScenarios,
                          Optional Season As eSeasons = eSeasons.first) As String

        Dim RunList As New List(Of String)


        Return RunList.First

    End Function

#End Region

#Region "Helper"

    Public Class ScenarioRunInfo


        Public Sub New()

        End Sub

        Public Enum eDBMember

            Scenario
            Crop
            Season

            EMG
            MAT
            HAR

        End Enum

        Public Sub New(ScenarioDBString As String)

            Me.ScenarioDBString = ScenarioDBString


            Dim ScenarioElements As String() = ScenarioDBString.Split(CChar(vbTab))

            Me.Scenario =
                       CType([Enum].Parse(
                                enumType:=GetType(Step34.eFOCUSswScenarios),
                              ignoreCase:=True,
                                   value:=ScenarioElements(eDBMember.Scenario)), 
                            Step34.eFOCUSswScenarios)

            Me.CropName = Trim(ScenarioElements(eDBMember.Crop))

            For CropCounter As Integer = 0 To Step34.SWASHCropNames.Count - 1

                If CropName.ToUpper = Trim(Step34.SWASHCropNames(CropCounter)).ToUpper Then

                    Me.CropEnum = CType(CropCounter, Step34.eSWASHCrops)
                    Exit For

                End If

            Next

            Me.Ganzelmeier = Step34.SWASHCrops2Ganzelmeier(Me.CropEnum)


            If ScenarioElements(eDBMember.Season).ToUpper.Contains("1st".ToUpper) Then
                Me.Season = Step34.eSeasons.first
            Else
                Me.Season = Step34.eSeasons.second
            End If

            Dim DateString As String = String.Empty

            DateString = ScenarioElements(eDBMember.EMG)

            Me.EMG = New Date(year:=(1900 + CInt(DateString.Substring(0, 2))),
                             month:=CInt(DateString.Substring(2, 2)),
                               day:=CInt(DateString.Substring(4, 2)))

            DateString = ScenarioElements(eDBMember.MAT)

            Me.MAT = New Date(year:=(1900 + CInt(DateString.Substring(0, 2))),
                             month:=CInt(DateString.Substring(2, 2)),
                               day:=CInt(DateString.Substring(4, 2)))

            DateString = ScenarioElements(eDBMember.HAR)

            Me.HAR = New Date(year:=(1900 + CInt(DateString.Substring(0, 2))),
                             month:=CInt(DateString.Substring(2, 2)),
                               day:=CInt(DateString.Substring(4, 2)))

        End Sub

        Public Property ScenarioDBString As String = String.Empty

        Public Property Scenario As Step34.eFOCUSswScenarios = Step34.eFOCUSswScenarios.not_defined

        Public Property CropName As String = String.Empty

        Public Property CropEnum As Step34.eSWASHCrops = Step34.eSWASHCrops.not_Defined

        Public Property Ganzelmeier As Step34.eGanzelmeierCropGroups = Step34.eGanzelmeierCropGroups.not_Defined

        Public Property Season As Step34.eSeasons = Step34.eSeasons.first

        Public Property EMG As New Date

        Public Property MAT As New Date

        Public Property HAR As New Date

        Public Property FAL As New Date

        Public Property MetFile As String

    End Class


#End Region

End Class
