﻿
Imports System.IO

Imports Tools
Imports ztsParser

Module main
    Sub main()

        start()

    End Sub

    Public Sub start()

restart:

        approxswaR = New approxswaR()

        showform = New FrmPropGrid(
            class2Show:=approxswaR,
             classType:=approxswaR.GetType,
               restart:=True)

        Try

            If Not IsNothing(showform) Then

                With showform

                    .Text = "approxswaR v" & My.Application.Info.Version.ToString

#If DEBUG Then
                    .Text &= "     ----- D * E * B * U * G ---- "

                    Dim easy As Boolean = True

                    If easy Then
                        ' approxswaR.ztsFileName = "C:\temp\ztsParserTest\2100309_cereals_spring_NOA61\R4-CS-.ZTS"
                        ' approxswaR.ztsFileName = "C:\temp\ztsParserTest\2100310_cereals_spring_CGA70\R4-CS-.ZTS"
                        'ztsFileData.ztsFileName = "C:\temp\ztsParserTest\2100311_cereals_spring_NOA63\R4-CS-.ZTS"
                        ' approxswaR.ztsFileName = "C:\temp\ztsParserTest\2100312_cereals_spring_CGA62\R4-CS-.ZTS"
                        'ztsFileData.ztsFileName = "C:\temp\ztsParserTest\2100313_cereals_spring_CGA18\R4-CS-.ZTS"
                        'ztsFileData.ztsFileName = "C:\temp\ztsParserTest\2100314_cereals_spring_CGA66\R4-CS-.ZTS"
                        approxswaR.ztsFileName = "C:\transfer\RRP1800088\DGR00\Fs3\PMT00\R00FPF01\PRZM\olives\R4-OL-.ZTS"

                    Else
                        'ztsFileData.readFromCsv = "C:\temp\ztsParserTest\R4-CS-GS-NA2-ST.csv"
                    End If
                    If approxswaR.ztsDataRowsList.Count > 0 Then approxswaR.calcPecs()

#Else
                    .Text &= " Release version"
#End If

                    .Width = 1200
                    .Height = 1000

                    If .ShowDialog() = Windows.Forms.DialogResult.Retry Then

                        showform.Close()
                        GoTo restart

                    End If

                End With

            End If

        Catch ex As Exception
            mylog(LogTxtArray:=parseExceptionMsg(Exception:=ex))
        End Try

        End
    End Sub

    Public showform As FrmPropGrid

    Public Property approxswaR As New approxswaR


End Module
