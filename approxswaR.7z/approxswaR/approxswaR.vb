﻿

Imports System.ComponentModel
Imports System.Drawing.Design
Imports System.IO
Imports System.Text
Imports System.Web.Script.Serialization
Imports System.Windows.Forms
Imports System.Xml.Serialization

Imports Tools
Imports ztsParser
Imports FOCUSswDrift.FOCUSswDB

Imports ztsParser.ztsDataRow

Public Class approxswaR

    Inherits ztsParser.ztsFileData

    Public Sub New()
        MyBase.New
    End Sub


    Private Sub approxswaR_ParsingDone() Handles Me.ParsingDone
        calcPecs()
    End Sub

    Public Sub calcPecs()

        Me.drift.nameOut = FOCUSswDrift.FOCUSswDrift.eNameOut.PEC
        Me.drift.waterDepthGUI = waterDepthPRZM(Me.scenario - eFOCUSswScenario.R1)
        Me.drift.inputs.waterDepth = waterDepthPRZM(Me.scenario - eFOCUSswScenario.R1)

        If Me.compounds.Count > 0 Then

            aquaMetFactor.Clear()

            For counter As Integer = 1 To Me.compounds.Count - 1

                aquaMetFactor.Add(New fraMetForUps)

                With aquaMetFactor(aquaMetFactor.Count - 1)

                    .cmpName = compounds(counter).name
                    .Scenario = Me.scenario

                    .parentDT50sw = compounds.First.DT50WatRef
                    .parentMolMas = compounds.First.MolMas
                    .fraPrtDauWat = compounds(counter).fraPrtDauWat

                    .metDT50sw = compounds(counter).DT50WatRef
                    .metMolMas = compounds(counter).MolMas

                    .calcFraMetForUps()

                End With

            Next

        End If



        Dim out As Double = stdDblEmpty
        Dim infl As Double = stdDblEmpty

        setStdFilter()

        For counter As Integer = 0 To Me.ztsDataRowsList.Count - 1

            With Me.ztsDataRowsList(counter)

                .results.Clear()

                If Me.monthlyAverageOrGWDischarge =
                    eMonthlyAverageOrGWDischarge.monthlyAverage Then
                    infl = .monthlyAverageINFL
                Else
                    infl = .gwDischarge
                End If


                For compoundCounter As Integer = 0 To compounds.Count - 1

                    out =
                    calcStep03PECsw(
                    RUNF:= .RUNF,
                    RFLX:= .flux(compoundCounter).RFLXxx,
                    IRRG:= .IRRG,
                    eventDuration:= .eventDuration,
                    valueINFL:=infl,
                    baseFlow:=Me.baseFlow,
                    ratioINFLWater:=Me.ratioINFLWater,
                    fractionAreaTreated:=Me.fractionAreaTreated,
                    scalingFactor:=Me.scalingFactor)

                    If inclAquMet And compoundCounter > 0 Then
                        out += .results(0).PEC * aquaMetFactor(compoundCounter - 1).totalAquaCorrFactor
                    End If

                    .results.Add(New PEC(name:=Me.compounds(compoundCounter).name.PadRight(6) & "FS3",
                                         PEC:=out))

                    out =
                    calcStep04LMPECsw(
                        ztsDataRow:=Me.ztsDataRowsList(counter), settingsLM:=eLMSettings.LML, compoundNumber:=compoundCounter,
                        FOCUSswScenario:=Me.scenario,
                        monthlyAverageOrGWDischarge:=Me.monthlyAverageOrGWDischarge,
                        scalingFactor:=Me.scalingFactor)

                    If inclAquMet And compoundCounter > 0 Then
                        out += .results(1).PEC * aquaMetFactor(compoundCounter - 1).totalAquaCorrFactor
                    End If

                    .results.Add(New PEC(name:=" ".PadRight(6) & "LML",
                                        PEC:=out))

                    out =
                   calcStep04LMPECsw(
                       ztsDataRow:=Me.ztsDataRowsList(counter), settingsLM:=eLMSettings.LMH, compoundNumber:=compoundCounter,
                       FOCUSswScenario:=Me.scenario,
                       monthlyAverageOrGWDischarge:=Me.monthlyAverageOrGWDischarge,
                       scalingFactor:=Me.scalingFactor)

                    If inclAquMet And compoundCounter > 0 Then
                        out += .results(2).PEC * aquaMetFactor(compoundCounter - 1).totalAquaCorrFactor
                    End If

                    .results.Add(New PEC(name:=" ".PadRight(6) & "LMH",
                                        PEC:=out))

                Next


            End With

        Next

        FOCUSseasonMax = createResultsOverview()
        readResultCSV()

    End Sub

    Public Sub readResultCSV()

        Dim fileName As String = ""
        Dim startPath As String = ""
        Dim filepaths As String()
        Dim filepathsFs4 As String()
        Dim csvFilePar As String() = {}
        Dim csvFileMet As String() = {}
        Dim rows As String()
        Dim PECs As New List(Of Double)
        Dim searchDateString As String
        Dim driftCSV As Double
        Dim driftCalc As Double
        Dim runOffCSV As Double
        Dim runOffCalc As Double
        Dim diff As Double
        Dim out As New List(Of String)
        Dim maxRowPar As ztsDataRow
        Dim maxRowMet As ztsDataRow
        Const searchAppln As String = "* Appln(s)"
        Dim applnSearchString As String = ""
        Dim nozzelFiles As String() = {}
        Dim nozzelCSV As String() = {}
        Dim nozzle As String = ""
        Const spaceFirst As Integer = 15
        Dim nozzel100 As Double
        Dim sed As Double
        Dim sed100 As Double

        startPath = Me.projectDir
        fileName = Me.compounds.First.name & "-" & Me.scenario.ToString & "S.csv"
        filepaths = Directory.GetFiles(path:=startPath,
                                       searchPattern:="*" & fileName,
                                       searchOption:=SearchOption.AllDirectories)

        Try



            If IsNothing(filepaths) OrElse filepaths.Count = 0 Then
                Exit Sub
            End If

            fileName = filepaths.First

            csvFilePar = File.ReadAllLines(fileName)

            If Me.compounds.Count > 1 Then

                fileName = Me.compounds(1).name & "-" & Me.scenario.ToString & "S.csv"
                filepaths = Directory.GetFiles(path:=startPath,
                                           searchPattern:="*" & fileName,
                                           searchOption:=SearchOption.AllDirectories)

                If IsNothing(filepaths) OrElse filepaths.Count = 0 Then
                    Exit Sub
                End If

                fileName = filepaths.First

                csvFileMet = File.ReadAllLines(fileName)

            End If

            Dim index As Integer = -1

            index = Array.FindIndex(array:=csvFilePar, match:=Function(x) x.StartsWith(searchAppln))

            If index <> -1 Then
                applnSearchString = csvFilePar(index).Split(",")(1)
            Else
                Me.FOCUSorAll = eFOCUSorAll.FOCUS
                Me.view = eView.applnsOnly

                applnSearchString =
                convDate2String(value:=Me.filteredZTSDataRowsArray.First.eventDate.AddDays(-1),
                                format:="yyyy-MM-dd", julian:=eJulian.none)
            End If

            rows = Filter(Source:=csvFilePar,
                          Match:=applnSearchString,
                          Include:=True,
                          Compare:=CompareMethod.Text)

            PECs.Clear()

            For Each member In rows
                If member.StartsWith(applnSearchString) Then
                    PECs.Add(CDbl(member.Split(",")(1)))
                End If
            Next

            If drift.Ganzelmeier <> eGanzelmeier.noDrift Then

                Me.drift.bufferWidth = eBufferWidth.FOCUSStep03
                Me.drift.nozzle = eNozzles.N00

                driftCSV = PECs.Max

                If Me.noOfApplns = eNoOfApplns._1 Then
                    driftCalc = Me.drift.PECs.singlePEC
                Else
                    driftCalc = Me.drift.PECs.multiPEC
                End If

                diff = driftCalc / driftCSV * 100

                '              0.0000 0.0000 
                out.Add("Mode".PadRight(spaceFirst) & "Calc   CSV       %")
                out.Add("Drift Fs3".PadRight(spaceFirst) &
                        driftCalc.ToString("0.0000") & " " &
                        driftCSV.ToString("0.0000") & " " &
                        diff.ToString("0.0").PadLeft(6) & "  " & applnSearchString)

            Else
                out.Add("Drift no drift")
            End If

            Me.FOCUSorAll = eFOCUSorAll.FOCUS
            Me.view = eView.eventsOnly

            'par
            maxRowPar = filterFOCUSseasonMax(allRows:=Me.filteredZTSDataRowsArray, 0)

            searchDateString =
            convDate2String(value:=maxRowPar.eventDate,
                            format:="yyyy-MM-dd", julian:=eJulian.none)

            rows = Filter(Source:=csvFilePar,
                          Match:=searchDateString,
                          Include:=True,
                          Compare:=CompareMethod.Text)

            PECs.Clear()

            For Each member In rows
                If member.StartsWith(searchDateString) Then
                    PECs.Add(CDbl(member.Split(",")(1)))
                End If
            Next

            runOffCSV = PECs.Max
            runOffCalc = maxRowPar.results.First.PEC
            diff = Math.Round(runOffCalc / runOffCSV * 100, 1)

            out.Add("Par   Fs3".PadRight(spaceFirst) & runOffCalc.ToString("0.0000") & " " &
                    runOffCSV.ToString("0.0000") & " " &
                    diff.ToString("0.0").PadLeft(6) & "  " & searchDateString)


            If Me.compounds.Count > 1 Then

                'met
                maxRowMet = filterFOCUSseasonMax(allRows:=Me.filteredZTSDataRowsArray, 1)

                searchDateString =
                convDate2String(value:=maxRowMet.eventDate,
                                format:="yyyy-MM-dd", julian:=eJulian.none)

                rows = Filter(Source:=csvFileMet,
                              Match:=searchDateString,
                              Include:=True, Compare:=CompareMethod.Text)

                PECs.Clear()

                For Each member In rows
                    If member.StartsWith(searchDateString) Then
                        PECs.Add(CDbl(member.Split(",")(1)))
                    End If
                Next

                runOffCSV = PECs.Max
                runOffCalc = maxRowMet.results(3).PEC
                diff = Math.Round(runOffCalc / runOffCSV * 100, 0)

                out.Add("Met".PadRight(spaceFirst) &
                        runOffCalc.ToString("0.0000") & " " &
                        runOffCSV.ToString("0.0000") & " " &
                        diff.ToString("0.0").PadLeft(6) & "  " & searchDateString)

            End If


            '----------------------------------------------------------

            Dim temp As String = ""
            startPath = Me.projectDir

            fileName = Me.compounds.First.name & "-" & Me.scenario.ToString & "S.csv"
            startPath = Replace(Expression:=startPath, "Fs3", "Fs4")

            Try

                If Directory.Exists(startPath) Then
                    filepathsFs4 = Directory.GetFiles(
                                path:=startPath,
                                searchPattern:="*" & fileName,
                                searchOption:=SearchOption.AllDirectories)
                Else
                    Me.compare = out.ToArray
                    Exit Sub
                End If


            Catch ex As Exception
                Me.compare = out.ToArray
                Exit Sub
            End Try



            Dim dummy As String() = {}

            '-------------------------------------------------

            nozzelFiles = Filter(Source:=filepathsFs4, Match:="\10m\N", Include:=True)

            Me.drift.bufferWidth = eBufferWidth.B10
            Me.drift.nozzle = eNozzles.N00

            If nozzelFiles.Count > 0 Then

                fileName = nozzelFiles.First

                csvFilePar = File.ReadAllLines(fileName)

                If Me.compounds.Count > 1 Then

                    startPath = Path.GetDirectoryName(fileName)
                    fileName = Me.compounds(1).name & "-" & Me.scenario.ToString & "S.csv"
                    filepaths = Directory.GetFiles(path:=startPath,
                                               searchPattern:="*" & fileName,
                                               searchOption:=SearchOption.TopDirectoryOnly)

                    If IsNothing(filepaths) OrElse filepaths.Count = 0 Then
                        Exit Sub
                    End If

                    fileName = filepaths.First

                    csvFileMet = File.ReadAllLines(fileName)

                End If

                If drift.Ganzelmeier <> eGanzelmeier.noDrift Then

                    nozzel100 = -1
                    sed100 = -1
                    For Each myNozzle As String In nozzelFiles

                        nozzelCSV = File.ReadAllLines(myNozzle)
                        dummy = myNozzle.Split(Path.DirectorySeparatorChar)
                        dummy = Filter(dummy, "N")

                        Me.drift.nozzle = CInt(Replace(dummy.First, "N", ""))

                        rows = Filter(Source:=nozzelCSV,
                                          Match:=applnSearchString,
                                          Include:=True,
                                          Compare:=CompareMethod.Text)

                        PECs.Clear()

                        For Each member In rows
                            If member.StartsWith(applnSearchString) Then
                                PECs.Add(CDbl(member.Split(",")(1)))
                            End If
                        Next

                        driftCSV = PECs.Max

                        PECs.Clear()

                        For Each member In rows
                            If member.StartsWith(applnSearchString) Then
                                PECs.Add(CDbl(member.Split(",").Last))
                            End If
                        Next

                        sed = PECs.Max


                        If Me.drift.nozzle = eNozzles.N00 Then
                            nozzel100 = driftCSV
                            sed100 = sed
                        End If

                        If Me.noOfApplns = eNoOfApplns._1 Then
                            driftCalc = Me.drift.PECs.singlePEC
                        Else
                            driftCalc = Me.drift.PECs.multiPEC
                        End If

                        diff = driftCalc / driftCSV * 100


                        out.Add(("Drift 10/" & CInt(Me.drift.nozzle).ToString).PadRight(spaceFirst) &
                                        driftCalc.ToString("0.0000") & " " &
                                        driftCSV.ToString("0.0000") & " " &
                                        diff.ToString("0.0").PadLeft(6) & "  " &
                                        searchDateString & " " &
                                        Math.Round(1 - driftCSV / nozzel100, digits:=2).ToString("0.00") & " " & Math.Round(1 - sed / sed100, digits:=2).ToString("0.00"))


                    Next

                End If


                'par
                searchDateString =
            convDate2String(value:=maxRowPar.eventDate,
                            format:="yyyy-MM-dd", julian:=eJulian.none)

                rows = Filter(Source:=csvFilePar,
                              Match:=searchDateString,
                              Include:=True,
                              Compare:=CompareMethod.Text)

                PECs.Clear()

                For Each member In rows
                    If member.StartsWith(searchDateString) Then
                        PECs.Add(CDbl(member.Split(",")(1)))
                    End If
                Next

                runOffCSV = PECs.Max

                runOffCalc = maxRowPar.results(1).PEC

                diff = Math.Round(runOffCalc / runOffCSV * 100, 0)

                out.Add("Par   LML".PadRight(spaceFirst) &
                        runOffCalc.ToString("0.0000") & " " &
                        runOffCSV.ToString("0.0000") & " " &
                        diff.ToString("0.0").PadLeft(6) & "  " & searchDateString)

                If Me.compounds.Count > 1 Then

                    'met
                    searchDateString =
                    convDate2String(value:=maxRowMet.eventDate,
                                    format:="yyyy-MM-dd", julian:=eJulian.none)

                    rows = Filter(Source:=csvFileMet,
                                  Match:=searchDateString,
                                  Include:=True,
                                  Compare:=CompareMethod.Text)

                    PECs.Clear()

                    For Each member In rows
                        If member.StartsWith(searchDateString) Then
                            PECs.Add(CDbl(member.Split(",")(1)))
                        End If
                    Next

                    runOffCSV = PECs.Max
                    runOffCalc = maxRowMet.results(4).PEC
                    diff = Math.Round(runOffCalc / runOffCSV * 100, 0)


                    out.Add("Met".PadRight(spaceFirst) &
                        runOffCalc.ToString("0.0000") & " " &
                        runOffCSV.ToString("0.0000") & " " &
                        diff.ToString("0.0").PadLeft(6) & "  " & searchDateString)

                End If

            End If

            '--------------------------------------------------------------



            nozzelFiles = Filter(Source:=filepathsFs4, Match:="\20m\N", Include:=True)

            Me.drift.bufferWidth = eBufferWidth.B20
            Me.drift.nozzle = eNozzles.N00

            If nozzelFiles.Count > 0 Then

                fileName = nozzelFiles.First

                csvFilePar = File.ReadAllLines(fileName)

                If Me.compounds.Count > 1 Then

                    startPath = Path.GetDirectoryName(fileName)
                    fileName = Me.compounds(1).name & "-" & Me.scenario.ToString & "S.csv"
                    filepaths = Directory.GetFiles(path:=startPath,
                                               searchPattern:="*" & fileName,
                                               searchOption:=SearchOption.TopDirectoryOnly)

                    If IsNothing(filepaths) OrElse filepaths.Count = 0 Then
                        Exit Sub
                    End If

                    fileName = filepaths.First

                    csvFileMet = File.ReadAllLines(fileName)

                End If


                If drift.Ganzelmeier <> eGanzelmeier.noDrift Then

                    nozzel100 = -1
                    sed100 = -1
                    For Each myNozzle As String In nozzelFiles

                        nozzelCSV = File.ReadAllLines(myNozzle)
                        dummy = myNozzle.Split(Path.DirectorySeparatorChar)
                        dummy = Filter(dummy, "N")

                        Me.drift.nozzle = CInt(Replace(dummy.First, "N", ""))

                        rows = Filter(Source:=nozzelCSV,
                                    Match:=applnSearchString,
                                    Include:=True,
                                    Compare:=CompareMethod.Text)

                        PECs.Clear()

                        For Each member In rows
                            If member.StartsWith(applnSearchString) Then
                                PECs.Add(CDbl(member.Split(",")(1)))
                            End If
                        Next

                        driftCSV = PECs.Max

                        For Each member In rows
                            If member.StartsWith(applnSearchString) Then
                                PECs.Add(CDbl(member.Split(",").Last))
                            End If
                        Next

                        sed = PECs.Max


                        If Me.drift.nozzle = eNozzles.N00 Then
                            nozzel100 = driftCSV
                            sed100 = sed
                        End If



                        If Me.noOfApplns = eNoOfApplns._1 Then
                            driftCalc = Me.drift.PECs.singlePEC
                        Else
                            driftCalc = Me.drift.PECs.multiPEC
                        End If

                        diff = driftCalc / driftCSV * 100


                        out.Add(("Drift 20/" & CInt(Me.drift.nozzle).ToString).PadRight(spaceFirst) &
                                driftCalc.ToString("0.0000") & " " &
                                driftCSV.ToString("0.0000") & " " &
                                diff.ToString("0.0").PadLeft(6) & "  " &
                                searchDateString & " " &
                                Math.Round(1 - driftCSV / nozzel100, digits:=2).ToString("0.00") & " " & Math.Round(1 - sed / sed100, digits:=2).ToString("0.00"))


                    Next

                End If


                'par
                searchDateString =
            convDate2String(value:=maxRowPar.eventDate,
                            format:="yyyy-MM-dd", julian:=eJulian.none)

                rows = Filter(Source:=csvFilePar, Match:=searchDateString, Include:=True, Compare:=CompareMethod.Text)

                PECs.Clear()

                For Each member In rows
                    If member.StartsWith(searchDateString) Then
                        PECs.Add(CDbl(member.Split(",")(1)))
                    End If
                Next

                runOffCSV = PECs.Max
                runOffCalc = maxRowPar.results(2).PEC
                diff = Math.Round(runOffCalc / runOffCSV * 100, 1)

                out.Add("Par    LMH".PadRight(spaceFirst) &
                        runOffCalc.ToString("0.0000") & " " &
                        runOffCSV.ToString("0.0000") & " " &
                        diff.ToString("0.0").PadLeft(6) & "  " & searchDateString)

                If Me.compounds.Count > 1 Then

                    'met
                    searchDateString =
                    convDate2String(value:=maxRowMet.eventDate,
                                    format:="yyyy-MM-dd", julian:=eJulian.none)

                    rows = Filter(Source:=csvFileMet, Match:=searchDateString, Include:=True, Compare:=CompareMethod.Text)

                    PECs.Clear()

                    For Each member In rows
                        If member.StartsWith(searchDateString) Then
                            PECs.Add(CDbl(member.Split(",")(1)))
                        End If
                    Next

                    runOffCSV = PECs.Max
                    runOffCalc = maxRowMet.results(5).PEC
                    diff = Math.Round(runOffCalc / runOffCSV * 100, 1)

                    out.Add("Met".PadRight(spaceFirst) &
                            runOffCalc.ToString("0.0000") & " " &
                            runOffCSV.ToString("0.0000") & " " &
                            diff.ToString("0.0").PadLeft(6) & "  " &
                            searchDateString)

                End If

            End If


        Catch ex As Exception
            MsgBox(ex.Message)
            Me.compare = out.ToArray
        End Try

        Me.compare = out.ToArray


    End Sub


    Private Function getCSVFileName(compoundCounter As Integer) As String

        Dim fileName As String = ""
        Dim filepaths As String()

        fileName = Me.compounds(compoundCounter).name & "-" & Me.scenario.ToString & "S.csv"
        filepaths = Directory.GetFiles(path:=Me.projectDir,
                                       searchPattern:="*" & fileName,
                                       searchOption:=SearchOption.AllDirectories)



    End Function

    Private Function getCSVPEC() As Double()

        Dim fileName As String = ""
        Dim filepaths As String()
        Dim csvFilePar As String() = {}
        Dim csvFileMet As String() = {}
        Dim rows As String()
        Dim PECs As New List(Of Double)
        Dim searchDateString As String
        Dim driftCSV As Double
        Dim driftCalc As Double
        Dim runOffCSV As Double
        Dim runOffCalc As Double
        Dim diff As Double
        Dim out As New List(Of String)
        Dim maxRow As ztsDataRow

        fileName = Me.compounds.First.name & "-" & Me.scenario.ToString & "S.csv"
        filepaths = Directory.GetFiles(path:=Me.projectDir,
                                       searchPattern:="*" & fileName,
                                       searchOption:=SearchOption.AllDirectories)

        If IsNothing(filepaths) OrElse filepaths.Count = 0 Then
            Return {Double.NaN}
        End If

        fileName = filepaths.First

        csvFilePar = File.ReadAllLines(fileName)

        If Me.compounds.Count > 1 Then

            fileName = Me.compounds(1).name & "-" & Me.scenario.ToString & "S.csv"
            filepaths = Directory.GetFiles(path:=Me.projectDir,
                                       searchPattern:="*" & fileName,
                                       searchOption:=SearchOption.AllDirectories)

            If IsNothing(filepaths) OrElse filepaths.Count = 0 Then
                Return {Double.NaN}
            End If

            fileName = filepaths.First

            csvFileMet = File.ReadAllLines(fileName)

        End If

        Dim index As Integer = -1

        Me.FOCUSorAll = eFOCUSorAll.FOCUS
        Me.view = eView.applnsOnly

        searchDateString =
        convDate2String(value:=Me.filteredZTSDataRowsArray.First.eventDate,
                        format:="yyyy-MM-dd", julian:=eJulian.none)

        rows = Filter(Source:=csvFilePar, Match:=searchDateString, Include:=True, Compare:=CompareMethod.Text)

        PECs.Clear()

        For Each member In rows
            If member.StartsWith(searchDateString) Then
                PECs.Add(CDbl(member.Split(",")(1)))
            End If
        Next

        If drift.Ganzelmeier <> eGanzelmeier.noDrift Then

            driftCSV = PECs.Max

            If Me.filteredZTSDataRowsArray.Count = 1 Then
                driftCalc = Me.drift.PECs.singlePEC
            Else
                driftCalc = Me.drift.PECs.multiPEC
            End If

            diff = Math.Round(driftCalc / driftCSV * 100, 1)

            '              0.0000 0.0000 
            out.Add("Mode  Calc   CSV    %")
            out.Add("Drift " & driftCalc.ToString("0.0000") & " " & driftCSV.ToString("0.0000") & " " & diff)

        Else
            out.Add("Drift no drift")
        End If

        Me.FOCUSorAll = eFOCUSorAll.FOCUS
        Me.view = eView.eventsOnly

        'par
        maxRow = filterFOCUSseasonMax(allRows:=Me.filteredZTSDataRowsArray, 0)

        searchDateString =
        convDate2String(value:=maxRow.eventDate,
                        format:="yyyy-MM-dd", julian:=eJulian.none)

        rows = Filter(Source:=csvFilePar, Match:=searchDateString, Include:=True, Compare:=CompareMethod.Text)

        PECs.Clear()

        For Each member In rows
            If member.StartsWith(searchDateString) Then
                PECs.Add(CDbl(member.Split(",")(1)))
            End If
        Next

        runOffCSV = PECs.Max
        runOffCalc = maxRow.results.First.PEC
        diff = Math.Round(runOffCalc / runOffCSV * 100, 1)

        out.Add("Par   " & runOffCalc.ToString("0.0000") & " " & runOffCSV.ToString("0.0000") & " " & diff & "  " & searchDateString)


    End Function

    Public Function createResultsOverview() As String()

        Dim targetRow As ztsDataRow
        Dim targetDate As New Date
        Dim dateString As String = ""
        Dim out As New List(Of String)
        Dim padPos As Integer = 22

        For counter As Integer = 0 To Me.compounds.Count - 1

            targetRow = filterFOCUSseasonMax(allRows:=ztsDataRowsList.ToArray, compoundNumber:=counter)

            If targetDate = New Date Then
                targetDate = targetRow.eventDate
                dateString = convDate2String(targetRow.eventDate, format:="dd-MMM-yy")
            Else
                If targetDate = targetRow.eventDate Then
                    dateString = " ".PadLeft(dateString.Length)
                Else
                    dateString = convDate2String(targetRow.eventDate, format:="dd-MMM-yy")
                End If
            End If

            out.Add(align2strings(dateString & " " &
                                  Me.compounds(counter).name,
                                  conv2String(targetRow.results(counter * 3).PEC), padPos:=padPos))

            out.Add(align2strings(" ".PadLeft(dateString.Length),
                                  conv2String(targetRow.results(counter * 3 + 1).PEC), padPos:=padPos))

            out.Add(align2strings(" ".PadLeft(dateString.Length),
                                  conv2String(targetRow.results(counter * 3 + 2).PEC), padPos:=padPos))

        Next

        Return out.ToArray

    End Function


    <DebuggerStepThrough>
    Public Function filterFOCUSseasonMax(
                                    allRows As ztsDataRow(), compoundNumber As Integer) As ztsDataRow

        Dim FOCUSRows As New List(Of ztsDataRow)

        ''only non empty entries
        Dim LINQ = From ztsDataRow As ztsDataRow In allRows
                   Where ztsDataRow.eventDate >= seasonStart AndAlso
                         ztsDataRow.eventDate <= seasonStart.AddYears(1).AddDays(-1)
                   Order By ztsDataRow.results(compoundNumber).PEC
                   Descending
                   Select ztsDataRow

        FOCUSRows.AddRange(LINQ)

        Return FOCUSRows.First

    End Function


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Public Const CATCalcParameter As String = "05  Meta TOXSWA"

#Region "    Meta Toxswa"

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Public Shared Property _scalingFactor As Double = 1

    ''' <summary>
    ''' Scaling Factor
    ''' </summary>
    <Category(CATCalcParameter)>
    <DisplayName(
    "Scaling Factor")>
    <Description(
    "Scaling factor to simulate different" & vbCrLf &
    "appln. rates or band appln.")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(1)>
    Public Property scalingFactor As Double
        Get
            Return _scalingFactor
        End Get
        Set
            _scalingFactor = Value
            calcPecs()
        End Set
    End Property


    <XmlIgnore> <ScriptIgnore>
    Public Shared _monthlyAverageOrGWDischarge As eMonthlyAverageOrGWDischarge =
        eMonthlyAverageOrGWDischarge.monthlyAverage

    <Category(CATCalcParameter)>
    <DisplayName("INFL Mode")>
    <Description("Infiltration as monthly aver. (FOCUS broken) or" & vbCrLf &
                 "GW discharge (FOCUS repair)")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(CInt(eMonthlyAverageOrGWDischarge.monthlyAverage))>
    Public Property monthlyAverageOrGWDischarge As eMonthlyAverageOrGWDischarge
        Get
            Return _monthlyAverageOrGWDischarge
        End Get
        Set(value As eMonthlyAverageOrGWDischarge)
            _monthlyAverageOrGWDischarge = value
            calcPecs()
        End Set
    End Property


    Public Property FOCUSseasonMax As String() = {}


    ''' <summary>
    ''' Base flow in L/m²/h
    ''' taken from FOCUS SW Final Report
    ''' </summary>
    <Category(CATCalcParameter)>
    <DisplayName(
    "Base Flow")>
    <Description(
    "Base flow in L/m²/h (mm/m²)" & vbCrLf &
    "taken from FOCUS SW Final Report")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    <DefaultValue(Double.NaN)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public ReadOnly Property baseFlow As Double
        Get
            If Me.scenario = eFOCUSswScenario.not_defined Then
                Return stdDblEmpty
            Else
                Return baseFlowDB(Me.scenario - eFOCUSswScenario.R1)
            End If
        End Get
    End Property



    ''' <summary>
    ''' Ratio of infiltration water added to runoff water
    ''' </summary>
    <Category(CATCalcParameter)>
    <DisplayName(
    "INFL/ROff water")>
    <Description(
    "Ratio of infiltration water" & vbCrLf &
    "added to runoff water")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    <DefaultValue(stdDblEmpty)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore>
    Public ReadOnly Property ratioINFLWater As Double
        Get
            If Me.scenario = eFOCUSswScenario.not_defined Then
                Return stdDblEmpty
            Else
                Return ratioINFLWaterDB(Me.scenario - eFOCUSswScenario.R1)
            End If
        End Get
    End Property


    ''' <summary>
    ''' Fraction of what area is treated
    ''' </summary>
    <Category(CATCalcParameter)>
    <DisplayName("FAT")>
    <Description("Fraction of what area is treated" & vbCrLf &
                 "std. stream = 21/101 ~ 0.208")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    <DefaultValue(stdDblEmpty)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format='G4'")>
    <XmlIgnore> <ScriptIgnore>
    Public ReadOnly Property fractionAreaTreated As Double
        Get
            Return fractionAreaTreatedStream
        End Get
    End Property

    <Browsable(False)>
    Public Property aquaMetFactor As New List(Of fraMetForUps)

    <Category(CATCalcParameter)>
    <DisplayName("Aquatic Met")>
    Public Property aquaticMetGUI As fraMetForUps()
        Get
            Return aquaMetFactor.ToArray
        End Get
        Set(value As fraMetForUps())
            aquaMetFactor.Clear()
            aquaMetFactor.AddRange(value)
        End Set
    End Property

    Private _inclAquMet As Boolean = True

    <Category(CATCalcParameter)>
    <DisplayName("    incl?")>
    Public Property inclAquMet As Boolean
        Get
            Return _inclAquMet
        End Get
        Set(value As Boolean)
            _inclAquMet = value
            calcPecs()
        End Set
    End Property

#End Region

    Public Property compare As String() = {}

#Region "calculations"


    ''' <summary>
    ''' *** Base function *** 
    ''' zts file based calculation of PECsw in µg/L
    ''' </summary>
    ''' ==============================================================
    ''' Parameters from zts file
    ''' ==============================================================
    ''' <param name="RUNF">
    ''' Runoff water flow  
    ''' in L/m²/d, 5th column
    ''' </param>
    ''' <param name="RFLX">
    ''' Runoff flux 
    ''' in mg as/m²/d, 9th column 
    ''' </param>
    ''' <param name="IRRG">
    ''' Irrigation, for FOCUSsw repair  
    ''' in L/m²/d
    ''' </param>
    ''' <param name="eventDuration">
    ''' Event duration in hours due to 
    ''' precipitation incl. irrigation 
    ''' </param>
    ''' <param name="valueINFL">
    ''' !!Monthly average!! of water flow at bottom of boundary 
    '''             or
    ''' GW discharge
    ''' in soil profile adjusted by 'RatioInfiltrationWater'
    ''' in L/m2/d, 8th column
    ''' </param>
    ''' ==============================================================
    ''' Parameters from FOCUS
    ''' ==============================================================
    ''' <param name="fractionAreaTreated">
    ''' For stream : area for pest. mass  = 20ha  upstream + 1ha field
    '''              area for water       = 100ha upstream + 1ha field
    '''                                   = 21/101 ~ 0.208
    ''' For ditch  : area for pest. mass  =  0ha  upstream + 1ha field
    '''              area for water       =  2ha  upstream + 1ha field
    '''                                   =  1/3   ~ 0.333
    ''' 
    ''' No support for ponds (yet ;-), so all scenarios are streams!!!
    ''' 
    ''' </param>
    ''' <param name="baseFlow">
    ''' Base flow in L/m2/h, taken from FOCUS  
    ''' R1 = 0.1918 / 24, R2 = 0.2803 / 24, 
    ''' R3 = 0.0762 / 24, R4 = 0.1927 / 24
    ''' </param>
    ''' <param name="ratioINFLWater">
    ''' Ratio of infiltration water added to runoff water
    ''' R1, R4 = 0.1; R2, R3 = 0.03 , taken from txw file 'RatInfDir'
    ''' </param>
    ''' <returns>
    ''' PECsw in µg/L
    ''' On error Double.NaN
    ''' </returns>
    ''' <remarks>
    ''' Calculation :
    ''' A  = total area: catchment + field : stream = 100ha + 1ha;
    '''                                       ditch =   0ha + 1ha
    ''' 
    ''' Assumption: Concentration in water body is equal to:
    '''  
    '''             sum of mass fluxes to water body 
    '''             ---------------------------------- 
    '''             sum of water fluxes to water body
    ''' 
    '''   * Mass fluxes to water body:
    '''        Sum of mass fluxes per m2 (only drain flow considered) : RFLX / N 
    '''        Total mass flux (over total treated area)              : FractionAreaTreated 
    '''     Mass flux = RFLX * A * FractionAreaTreated
    ''' 
    '''   * Water flows to the water body
    '''        runoff volume flux per m2 and h : RUNF 
    '''        const. base flow per m2 and h   : BaseFlow
    '''        const. + variable component     : (BaseFlow + RatInfDir * MonthlyAverageINFL + RUNF )  * A
    '''     Water flow  = (PestFluxToDrains + BaseFlow) * A
    ''' 
    '''
    '''   only const. base flow :
    '''   =======================
    ''' 
    '''                    RFLX * A * FractionAreaTreated
    ''' PECsw(mg/L) = -------------------------------------
    '''                      (BaseFlow  + RUNF) * A
    ''' 
    '''                 RFLX  * FractionAreaTreated
    ''' PECsw(mg/L) = ------------------------------
    '''                     (BaseFlow  + RUNF) 
    '''
    '''  
    '''   const. + variable flow :
    '''   ========================
    ''' 
    ''' 
    '''                               RFLX * A * FractionAreaTreated
    ''' PECsw(mg/L) = -----------------------------------------------------------------------
    '''                (BaseFlow + RUNF + (RatioInfiltrationWater * MonthlyAverageINFL )) * A
    ''' 
    ''' 
    '''                                RFLX * FractionAreaTreated
    ''' PECsw(mg/L) = ------------------------------------------------------------------------
    '''                (BaseFlow + RUNF + (RatioInfiltrationWater * MonthlyAverageINFL )) 
    ''' 
    '''</remarks>
    Public Shared Function calcStep03PECsw(
                            RUNF As Double,
                            RFLX As Double,
                            IRRG As Double,
                            eventDuration As Integer,
                            valueINFL As Double,
                            baseFlow As Double,
                            ratioINFLWater As Double,
                            fractionAreaTreated As Double,
                   Optional scalingFactor As Double = 1
                            ) As Double

        Dim PECsw As Double = -1

        'no Runoff flux => PECsw = 0 µg/L
        If RFLX = 0 Then Return 0

        Try

            're-calc volume and flux from /day to /hour
            RUNF /= eventDuration
            RFLX /= eventDuration

            'if no irrigation is defied (old przm version)
            If Double.IsNaN(IRRG) OrElse IRRG < 0 Then
                IRRG = 0
            Else
                IRRG /= eventDuration
            End If

            'scaling factor
            RFLX *= scalingFactor

            '1/day to 1/hour
            valueINFL /= 24

            PECsw =
                        RFLX * fractionAreaTreated /
                (RUNF + IRRG + baseFlow + (ratioINFLWater * valueINFL))

            'mg/L to µg/L
            PECsw *= 1000

        Catch ex As Exception
            Console.Write(ex.Message)
        End Try

        Return PECsw

    End Function



    ''' <summary>
    ''' Calculates the runoff volume from step03 to mitigation
    ''' 
    '''                               [Af * (1-frv) + Ac * (1 – F * frv)]
    ''' mitigationRUNF = Step03RUNF * ----------------------------------
    '''                                         [Af + Ac]
    ''' </summary>
    ''' <param name="step03RUNF">
    ''' The orig. Step03 Runoff volume value from zts file
    ''' </param>
    ''' <param name="frv_RunOffVolumeReductionFactor">
    ''' factor (0 - 1) for volume reduction
    ''' LM buffers shorter than 10m = 0.6, else 0.8, off = 0 
    ''' </param>
    ''' <returns>
    ''' Step04LMRUNF as Double, 
    ''' error =  Double.NaN
    ''' </returns>
    ''' <remarks></remarks>
    Public Shared Function calcMitigationRUNF(
                            step03RUNF As Double,
                            frv_RunOffVolumeReductionFactor As Double,
                            Optional pond As Boolean = False) As Double

        If step03RUNF = 0 Then Return 0

        Dim mitigationRUNF As Double

        If frv_RunOffVolumeReductionFactor = 0 Then Return step03RUNF

        Dim Ac As Double = Double.NaN               'area of up-gradient fields   (pond = 0.45ha, stream = 100ha)   
        Dim F As Double = Double.NaN                'fraction of catchment 
        '                                                     that is treated     (pond = 1,      stream = 0.2)
        Dim Af As Double = 1                        'area of treated field        (1 ha)


        Dim frv As Double = frv_RunOffVolumeReductionFactor   'fractional reduction in run-off volume

        'mittigationRUNF = Step03RUNF * [Af * (1-frv) + Ac * (1 – F * frv)] / [Af + Ac]

        If pond Then
            Ac = 0.45
            F = 1
        Else
            Ac = 100
            F = 0.2
        End If

        Try

            mitigationRUNF =
                step03RUNF * (Af * (1 - frv) + Ac * (1 - F * frv)) /
                                          (Af + Ac)
        Catch ex As Exception
            Return Double.NaN
        End Try

        Return mitigationRUNF

    End Function

    ''' <summary>
    ''' high 'frv/frf  =.8  frm/fef  =.95
    ''' low  'frv/frf  =.6  frm/fef  =.85 
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum eLMSettings

        LML  'frv/frf  =.6  frm/fef  =.85
        LMH  'frv/frf  =.8  frm/fef  =.95

    End Enum


    ''' <summary>
    ''' mitigation factors
    ''' frv, frf, fem, fef
    ''' </summary>
    <TypeConverter(GetType(enumConverter(Of eLMReductionParameter)))>
    Public Enum eLMReductionParameter

        ''' <summary>
        ''' run off volume
        ''' </summary>
        ''' <remarks></remarks>
        <Description("frv : run off volume")>
        frv

        ''' <summary>
        ''' run off flux
        ''' </summary>
        ''' <remarks></remarks>
        <Description("frf : run off flux")>
        frf

        ''' <summary>
        ''' erosion mass
        ''' </summary>
        ''' <remarks></remarks>
        <Description("fem : erosion mass")>
        fem

        ''' <summary>
        ''' erosion flux
        ''' </summary>
        ''' <remarks></remarks>
        <Description("fef : erosion flux")>
        fef

        <Description(enumConverter(Of Type).not_defined)>
        not_def = -1

    End Enum

    Public Shared mitigationSettingsDB As Double(,) =
        {
         {0.6, 0.6, 0.85, 0.85},
         {0.8, 0.8, 0.95, 0.95}
        }



    Public Shared Function calcStep04LMPECsw(
                                            ztsDataRow As ztsDataRow,
                                            settingsLM As eLMSettings,
                                            compoundNumber As Integer,
                                            FOCUSswScenario As eFOCUSswScenario,
                                   Optional baseFlow As Double = Double.NaN,
                                   Optional ratioINFLWater As Double = Double.NaN,
                                   Optional fractionAreaTreated As Double = Double.NaN,
                        Optional monthlyAverageOrGWDischarge As eMonthlyAverageOrGWDischarge =
                                  eMonthlyAverageOrGWDischarge.monthlyAverage,
                        Optional scalingFactor As Double = 1) As Double

        Dim step03RFLX As Double = Double.NaN
        Dim step04RFLX As Double = Double.NaN
        Dim step04RUNF As Double = Double.NaN
        Dim valueINFL As Double = Double.NaN



        If Double.IsNaN(baseFlow) Then
            baseFlow = baseFlowDB(FOCUSswScenario - eFOCUSswScenario.R1)
        End If

        If Double.IsNaN(ratioINFLWater) Then
            ratioINFLWater = ratioINFLWaterDB(FOCUSswScenario - eFOCUSswScenario.R1)
        End If

        If Double.IsNaN(fractionAreaTreated) Then
            fractionAreaTreated = fractionAreaTreatedStream
        End If

        With ztsDataRow

            step04RUNF =
                                            calcMitigationRUNF(
                                            step03RUNF:= .RUNF,
                       frv_RunOffVolumeReductionFactor:=mitigationSettingsDB(settingsLM, eLMReductionParameter.frv))

            step03RFLX = ztsDataRow.flux(compoundNumber).RFLXxx

            step04RFLX = step03RFLX * (1 - mitigationSettingsDB(settingsLM, eLMReductionParameter.frf))


            'monthlyAverage or GWDischarge for valueINFL
            If monthlyAverageOrGWDischarge =
                  eMonthlyAverageOrGWDischarge.monthlyAverage Then
                valueINFL = .monthlyAverageINFL
            Else
                valueINFL = .gwDischarge
            End If


            Return _
                calcStep03PECsw(
                    RUNF:= .RUNF,
                    RFLX:=step04RFLX,
                    IRRG:= .IRRG,
                    eventDuration:= .eventDuration,
                    valueINFL:=valueINFL,
                    baseFlow:=baseFlow,
                    ratioINFLWater:=ratioINFLWater,
                    fractionAreaTreated:=fractionAreaTreated,
                    scalingFactor:=scalingFactor)

        End With

    End Function

    ''' <summary>
    ''' Std. water depths for RunOff scenarios
    ''' </summary>
    Public Shared waterDepthPRZM As Double() =
        {0.41, 0.305, 0.29, 0.41}
    '     R1     R2    R3    R4

    ''' <summary>
    ''' Ratio of infiltration water added to runoff water
    ''' taken from txw parameter 'RatInfDir'
    ''' </summary>
    ''' <remarks>
    ''' R1, R4 = 0.1; R2, R3 = 0.03
    ''' </remarks>
    Public Shared ratioINFLWaterDB As Double() =
        {0.1, 0.03, 0.03, 0.1}
    '     R1    R2    R3   R4 

    ''' <summary>
    ''' Base flow in L/m²/h, taken from 
    ''' FOCUS SW Final Report, Table 4.3.3-1, Page 94
    ''' </summary>
    ''' <remarks>
    ''' R1 = 0.1918 / 24, R2 = 0.2803 / 24, 
    ''' R3 = 0.0762 / 24, R4 = 0.19274 / 24
    ''' </remarks>
    Public Shared baseFlowDB As Double() =
        {0.1918 / 24, 0.2803 / 24, 0.0762 / 24, 0.19274 / 24}
    '        R1           R2           R3            R4       

    ''' <summary>
    ''' Fraction of what area is treated
    ''' stream : 21/101 ~ 0.208
    ''' </summary>
    ''' <remarks>
    ''' For stream : area for pest. mass  = 20ha  upstream + 1ha field
    '''              area for water       = 100ha upstream + 1ha field
    '''                                   = 21/101 ~ 0.208
    ''' </remarks>
    Public Const fractionAreaTreatedStream As Double = 21 / 101

    ''' <summary>
    ''' Fraction of what area is treated
    ''' ditch : 1/3  ~ 0.333
    ''' </summary>
    ''' <remarks>
    ''' For ditch  : area for pest. mass  =  0ha  upstream + 1ha field
    '''              area for water       =  2ha  upstream + 1ha field
    '''                                   =  1/3  ~ 0.333
    ''' No support for ponds (yet ;-)  
    ''' </remarks>
    Public Const fractionAreaTreatedDitch As Double = 1 / 3



#End Region

End Class


<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class fraMetForUps

    Public Sub New()

    End Sub

    <Browsable(False)>
    <XmlIgnore> <ScriptIgnore>
    Public ReadOnly Property name As String
        Get
            If Double.IsNaN(totalAquaCorrFactor) OrElse totalAquaCorrFactor = 0 Then
                Return " - (" & cmpName & ")"
            Else
                Return conv2String(value:=totalAquaCorrFactor * 100, format:="G4", unit:=" % of par -> " & cmpName)
            End If
        End Get
    End Property


    Private _Scenario As eFOCUSswScenario = eFOCUSswScenario.not_defined

    Private _fraPrtDauWat As Double = stdDblEmpty

    Private _parentDT50sw As Double = stdDblEmpty
    Private _metDT50sw As Double = stdDblEmpty

    Private _parentMolMas As Double = stdDblEmpty
    Private _metMolMas As Double = stdDblEmpty



    Const catInput As String = "01  Inputs"

    ''' <summary>
    ''' PRZMsw Scenario
    ''' R1 - R4, not def.
    ''' </summary>
    <Category(catInput)>
    <DisplayName(
    "Scenario")>
    <Description(
    "FOCUS sw Scenario" & vbCrLf &
    "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(CInt(eFOCUSswScenario.not_defined))>
    Public Property Scenario As eFOCUSswScenario
        Get

            enumConverter(Of eFOCUSswScenario).DontShow =
                {
                getEnumDescription(eFOCUSswScenario.D3),
                getEnumDescription(eFOCUSswScenario.D6)
                }

            Return _Scenario
        End Get
        Set

            _Scenario = Value

            If Value <> eFOCUSswScenario.not_defined Then
                calcFraMetForUps()
            Else
                FraMetForUps = Double.NaN
            End If

        End Set
    End Property

    <Category(catInput)>
    <[ReadOnly](True)>
    Public Property cmpName As String = Misc.not_defined

    <Category(catInput)>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
    "Formation  Par -> Met")>
    <Description(
    "Parent-daughter relationships transformation in water" & vbCrLf &
    "'Formation fraction' in water")>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(stdDblEmpty)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("unit=' (-)'")>
    Public Property fraPrtDauWat As Double
        Get
            Return _fraPrtDauWat
        End Get
        Set
            _fraPrtDauWat = Value
        End Set
    End Property

    ''' <summary>
    ''' Parent half-life transformation in water
    ''' in days
    ''' </summary>
    ''' <returns></returns>
    <Category(catInput)>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
    "Parent     DT50sw")>
    <Description(
    "Parent half-life transformation in water" & vbCrLf &
    "in days")>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(stdDblEmpty)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("unit=' days'")>
    Public Property parentDT50sw As Double
        Get
            Return _parentDT50sw
        End Get
        Set
            _parentDT50sw = Value
        End Set
    End Property

    ''' <summary>
    ''' Molar mass of parent substance
    ''' in g/mol
    ''' </summary>
    ''' <returns></returns>
    <Category(catInput)>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
    "           Molar Mass")>
    <Description(
    "Molar mass of parent substance" & vbCrLf &
    "in g/mol")>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(stdDblEmpty)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("unit=' g/mol'")>
    Public Property parentMolMas As Double
        Get
            Return _parentMolMas
        End Get
        Set
            _parentMolMas = Value
        End Set
    End Property

    ''' <summary>
    ''' Metabolite half-life transformation in water
    ''' in days
    ''' </summary>
    ''' <returns></returns>
    <Category(catInput)>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
    "Metabolite DT50sw")>
    <Description(
    "Metabolite half-life transformation in water" & vbCrLf &
    "in days")>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(stdDblEmpty)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("unit=' days'")>
    Public Property metDT50sw As Double
        Get
            Return _metDT50sw
        End Get
        Set
            _metDT50sw = Value
        End Set
    End Property

    ''' <summary>
    ''' Molar mass of metabolite in g/mol
    ''' </summary>
    ''' <returns></returns>
    <Category(catInput)>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
    "           Molar Mass")>
    <Description(
    "Molar mass of metabolite" & vbCrLf &
    "in g/mol")>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(stdDblEmpty)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("unit=' g/mol'")>
    Public Property metMolMas As Double
        Get
            Return _metMolMas
        End Get
        Set
            _metMolMas = Value
        End Set
    End Property

    Const catOutput As String = "02  Output"


    <Category(catOutput)>
    <RefreshProperties(RefreshProperties.All)>
    <[ReadOnly](True)> <DefaultValue(stdDblEmpty)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
    "format= 'G3'|" & vbCrLf &
    "unit=' (-)'")>
    Public Property FraMetForUps As Double = Double.NaN

    <Category(catOutput)>
    <DisplayName("Mol Mass Correction")>
    <RefreshProperties(RefreshProperties.All)>
    <[ReadOnly](True)> <DefaultValue(stdDblEmpty)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
    "format= 'G7'|" & vbCrLf &
    "unit=' (-)'")>
    Public ReadOnly Property molMassCorr As Double
        Get

            If Not parentMolMas = stdDblEmpty AndAlso
               Not metMolMas = stdDblEmpty AndAlso
                     parentMolMas > 0 Then

                Return metMolMas / parentMolMas
            Else
                Return stdDblEmpty
            End If

        End Get
    End Property

    <Category(catOutput)>
    <DisplayName("Total Corr. Factor")>
    <RefreshProperties(RefreshProperties.All)>
    <[ReadOnly](True)> <DefaultValue(0)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
    "format= 'G7'|" & vbCrLf &
    "unit=' (-)'")>
    Public ReadOnly Property totalAquaCorrFactor As Double
        Get

            If FraMetForUps <> stdDblEmpty AndAlso
                molMassCorr <> stdDblEmpty AndAlso
                fraPrtDauWat <> stdDblEmpty Then

                Return FraMetForUps * molMassCorr * fraPrtDauWat

            Else
                Return 0
            End If

        End Get
    End Property


#Region "    Settings"

    Const catSettings As String = "03  Settings"
    Const showSettings As Boolean = False

    <Category(catSettings)>
    <Browsable(showSettings)>
    <DefaultValue(20)>
    Public Property parentTemRefTraWat As Double = 20

    <Category(catSettings)>
    <Browsable(showSettings)>
    <DefaultValue(20)>
    Public Property metTemRefTraWat As Double = 20

    <Category(catSettings)>
    <Browsable(showSettings)>
    <DefaultValue(65400)>
    Public Property parentMolEntTraWat As Double = 65400

    <Category(catSettings)>
    <Browsable(showSettings)>
    <DefaultValue(65400)>
    Public Property metMolEntTraWat As Double = 65400

#End Region


    Public Sub calcFraMetForUps()

        Try

            FraMetForUps =
                calcFraMetForUps(
                Scenario:=Scenario.ToString,
                parentDT50:=parentDT50sw,
                metDT50:=metDT50sw,
                parentMolEntTraWat:=parentMolEntTraWat,
                metMolEntTraWat:=metMolEntTraWat,
                parentTemRefTraWat:=parentTemRefTraWat,
                metTemRefTraWat:=metTemRefTraWat)

        Catch ex As Exception
            FraMetForUps = 0
        End Try

    End Sub


    Public Function calcFraMetForUps(
                                Scenario As String,
                                parentDT50 As Double,
                                metDT50 As Double,
                    Optional parentTemRefTraWat As Double = 20,
                    Optional metTemRefTraWat As Double = 20,
                    Optional parentMolEntTraWat As Double = 65400,
                    Optional metMolEntTraWat As Double = 65400) As Double

        Dim FraMetForUps As Double = Double.NaN

        Dim kPar As Double = Double.NaN
        Dim kMet As Double = Double.NaN
        Dim AvergeTemp As Double = Double.NaN
        Dim ResidenceTime As Double = Double.NaN

        Dim tMax As Double = Double.NaN



        Dim AvergeTempDB As String() =
            {
                    "D1 281.1",
                    "D2 282.3",
                    "D4 281.4",
                    "D5 283.8",
                    "R1 283.1",
                    "R2 288",
                    "R3 286.7",
                    "R4 286.8"
            }

        Dim ResidenceTimeDB As String() =
            {
                    "D1 23",
                    "D2 90",
                    "D4 7",
                    "D5 10",
                    "R1 5",
                    "R2 3",
                    "R3 10",
                    "R4 5"
            }

        Const K As Double = 273.15
        Const R As Double = 8.3144


        '°C -> K
        parentTemRefTraWat += K
        metTemRefTraWat += K

        'average scenario water temperature in K
        AvergeTemp =
            CDbl(Filter(
                    Source:=AvergeTempDB,
                     Match:=Scenario.ToString,
                   Include:=True,
                   Compare:=CompareMethod.Text).First.Split().Last)

        '
        ' transformation rate at average scenario water temperature in 1/day
        '
        '                           ActivationEnergy 
        'k(averageTemp) = k exp -------------------------- * (AverageTemp - Tref)
        '                         R * Tref * AverageTemp
        '

        kPar = Math.Log(2) / parentDT50
        kPar = kPar * Math.Exp(parentMolEntTraWat /
                          (R * parentTemRefTraWat * AvergeTemp) * (AvergeTemp - parentTemRefTraWat))

        kMet = Math.Log(2) / metDT50
        kMet = kMet * Math.Exp(metMolEntTraWat /
                          (R * metTemRefTraWat * AvergeTemp) * (AvergeTemp - metTemRefTraWat))


        If kPar = kMet Then
            kPar = kPar + kPar * 0.0001
        End If


        '
        ' time of occurrence of the max met mass in days
        '
        '         ln(kMet/kPar)
        'tMax = ------------------
        '          kMet - kPar
        '
        '

        tMax = Math.Log(kMet / kPar) /
                       (kMet - kPar)

        ' residence time in scenario
        ResidenceTime =
            CDbl(Filter(
                    Source:=ResidenceTimeDB,
                     Match:=Scenario.ToString,
                   Include:=True,
                   Compare:=CompareMethod.Text).First.Split().Last)

        'true residence time
        If ResidenceTime > tMax Then
            ResidenceTime = tMax
        End If


        '
        '                       kPar
        ' FraMetForUps  = ---------------- * ( exp(-kMet * ResidenceTime) -exp(-kPar * ResidenceTime) )
        '                   kPar - kMet
        '

        FraMetForUps =
                kPar /
            (kPar - kMet) * (Math.Exp(-kMet * ResidenceTime) - Math.Exp(-kPar * ResidenceTime))

        'allwayys roundup for 3 digits ;-)
        FraMetForUps =
                Math.Ceiling(a:=FraMetForUps * 10000) / 10000


        Return FraMetForUps

    End Function


End Class

