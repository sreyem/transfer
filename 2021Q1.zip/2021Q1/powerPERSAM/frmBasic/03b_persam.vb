﻿
Imports System.ComponentModel
Imports System.Xml.Serialization
Imports System.IO
Imports System.Web.Script.Serialization
Imports System.Drawing.Design
Imports System.Windows.Forms

Imports frmBasic
Imports System.Text

<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class powerPERSAM

#Region "    _methods"

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _tier As eTier = eTier.tier2
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _substanceType As eSubstanceType = eSubstanceType.other
    '<DebuggerBrowsable(DebuggerBrowsableState.Never)>
    'Private _outputFolder As String = String.Empty
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _endpoints As eEndPoint = eEndPoint.totalSoil
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _regions As eRegions = eRegions.central
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _gwCrop As eCropsGW = eCropsGW.notDef
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _gwApplnMode As eApplnMode
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _onOrBetweenCrop As eOnOrBetweenCrop = eOnOrBetweenCrop.onCrop
    '<DebuggerBrowsable(DebuggerBrowsableState.Never)>
    'Private _crop As ePERSAMcrops = ePERSAMcrops.notDef
    '<DebuggerBrowsable(DebuggerBrowsableState.Never)>
    'Private _applnType As eApplnType = eApplnType.cropCanopy
    '<DebuggerBrowsable(DebuggerBrowsableState.Never)>
    'Private _cropType As eCropType = eCropType.permanent
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _BBCHgw As New BBCH
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _name As String = String.Empty
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _BBCHPersam As String() = {}
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _regionType As eRegionType = eRegionType.zone
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _Country As eEUcountries = eEUcountries.zone
    '<DebuggerBrowsable(DebuggerBrowsableState.Never)>
    'Private _exportGeneratedMaps As Boolean = False
    '<DebuggerBrowsable(DebuggerBrowsableState.Never)>
    'Private _tavg As Integer = 0
    '<DebuggerBrowsable(DebuggerBrowsableState.Never)>
    'Private _tpostApp As Integer = 0
    '<DebuggerBrowsable(DebuggerBrowsableState.Never)>
    'Private _ftreated As Double = 1
    '<DebuggerBrowsable(DebuggerBrowsableState.Never)>
    'Private _zecoTotalSoil As Double = 5
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _zecoPoreWater As Double = 1
    '<DebuggerBrowsable(DebuggerBrowsableState.Never)>
    'Private _zinc As Double = 0
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _persamBBCH As String = String.Empty
    '<DebuggerBrowsable(DebuggerBrowsableState.Never)>
    'Private _yearlyRepeat As eYearlyRepeat = eYearlyRepeat.EveryYear
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _firstApplnDateGW As New Date
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _substanceDefinition As String = "custom"
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _code As String
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _kom As Double = Double.NaN
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _degT50 As Double = Double.NaN
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _m As Double = Double.NaN
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _e As Double = 65.4
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _racTotalSoil As Double = Double.NaN
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _racPoreWater As Double = Double.NaN
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _parentSubstance As New persam_Substance
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _noOfApplns As Integer = 0
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _interval As Integer = 1
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _applicationRate As Double = Double.NaN
    '<DebuggerBrowsable(DebuggerBrowsableState.Never)>
    'Private _yearlyRepeatGW As eYearlyRepeat = eYearlyRepeat.EveryYear
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _persam As New persam
    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _showJSONinEditor As Boolean = True

#End Region


#Region "    Constructor"

    Public Sub New()
        init()
    End Sub

    Public Sub init()

        substanceType = eSubstanceType.other
        endpoints = eEndPoint.totalSoil
        tier = eTier.tier2
        regions = eRegions.central
        cropType = eCropType.permanent
        applnType = eApplnType.cropCanopy
        regionType = eRegionType.zone

        tavg = 0
        tpostApp = 0
        ftreated = 1
        zecoTotalSoil = 5
        zecoPoreWater = 1
        zinc = Double.NaN
        firstApplnDateGW = Now

    End Sub

#End Region

    Public Const CATBasic As String = "01  Basic Parameters"
#Region "    Basic Parameters"

#Region "    Input Complete"

    ''' <summary>
    ''' Input Complete?
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(CATBasic)>
    <DisplayName("Input Complete?")>
    <DefaultValue("OK")>
    Public ReadOnly Property inputComplete As String
        Get
            Return checkInputComplete()
        End Get
    End Property

    Public Function checkInputComplete() As String

        If name = "" Then Return "Project name?"
        If outputFolder = "" Then Return "Output folder?"
        If crop = ePERSAMcrops.not_Def Then Return "Crop?"
        If persamBBCH = "" Then Return "BBCH?"
        If parent.inputComplete <> "OK" Then Return "Parent substance?"

        If Me.endpoints = eEndPoint.both OrElse Me.endpoints = eEndPoint.totalSoil AndAlso
                parent.racTotalSoil = 0 Then
            Return "Parent RAC Soil?"
        End If

        If Me.endpoints = eEndPoint.both OrElse Me.endpoints = eEndPoint.poreWater AndAlso
                parent.racPoreWater = 0 Then
            Return "Parent RAC Pore Water?"
        End If

        For Each member As persam_Substance In Me.primaryMetabolites

            If IsNothing(member) Then Continue For

            If Me.endpoints = eEndPoint.both OrElse Me.endpoints = eEndPoint.totalSoil AndAlso
                            member.racTotalSoil = 0 Then
                Return member.code & " :  RAC Soil?"
            End If

            If Me.endpoints = eEndPoint.both OrElse Me.endpoints = eEndPoint.poreWater AndAlso
                    member.racPoreWater = 0 Then
                Return member.code & " : RAC Pore Water?"
            End If

        Next

        For Each member As persam_Substance In Me.secondaryMetabolites

            If IsNothing(member) Then Continue For

            If Me.endpoints = eEndPoint.both OrElse Me.endpoints = eEndPoint.totalSoil AndAlso
                            member.racTotalSoil = 0 Then
                Return member.code & " :  RAC Soil?"
            End If

            If Me.endpoints = eEndPoint.both OrElse Me.endpoints = eEndPoint.poreWater AndAlso
                    member.racPoreWater = 0 Then
                Return member.code & " : RAC Pore Water?"
            End If

        Next

        Return "OK"

    End Function

#End Region

#Region "    Name and IO"

    ''' <summary>
    ''' Project Name
    ''' </summary>
    ''' <returns></returns>
    <DisplayName("Project Name")>
    <Category(CATBasic)>
    <RefreshProperties(RefreshProperties.All)>
    <Description("used also as json filename")>
    <DefaultValue("")>
    Public Property name As String
        Get
            Return _name
        End Get
        Set
            _name = Value
            Me.persam.name = _name
        End Set
    End Property

    ''' <summary>
    ''' Output Path
    ''' </summary>
    ''' <returns></returns>
    <DisplayName("Output Path")>
    <Category(CATBasic)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property outputFolder As String
        Get
            Return True
        End Get
        Set

            If Value.Contains("?") Then

                Dim fbd As New FolderBrowserDialog

                With fbd

                    .Description = "Select project master path"
                    .SelectedPath = Me.persam.outputFolder

                    If .ShowDialog <> DialogResult.OK Then Exit Property

                    Me.persam.outputFolder = .SelectedPath

                End With

            Else

                If Value = "" Then Exit Property

                If Directory.Exists(Value) Then
                    Me.persam.outputFolder = Value
                Else
                    MsgBox(Me.persam.outputFolder & " does NOT exists!")
                End If

            End If

        End Set
    End Property

    ''' <summary>
    ''' JSON Path
    ''' </summary>
    ''' <returns></returns>
    <DisplayName("JSON Path")>
    <Category(CATBasic)>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(False)>
    Public ReadOnly Property jsonPath As String
        Get
            Return Path.Combine(path1:=Me.outputFolder, Me.name & ".json")
        End Get
    End Property

    ''' <summary>
    ''' Save JSON
    ''' </summary>
    ''' <returns></returns>
    <DisplayName("Save JSON")>
    <Category(CATBasic)>
    <RefreshProperties(RefreshProperties.All)>
    <DefaultValue(True)>
    Public Property save2JSON As String
        Get
            Return ""
        End Get
        Set

            If Not Value.Contains("?") Then Exit Property

            'ToDo : Save as json

        End Set
    End Property

#End Region

    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore>
    <Browsable(True)>
    <DisplayName("PERSAM orig.")>
    <Category(CATBasic)>
    Public Property persam As persam
        Get
            Return _persam
        End Get
        Set
            _persam = Value
        End Set
    End Property


    <Category(CATBasic)>
    <XmlIgnore>
    Public Property persams As persam() = {}
#End Region

    Public Const CATRegion As String = "02  Region and Tiers"
#Region "    Region and Tiers"

    Public Enum eTier
        tier1
        tier2
    End Enum

    ''' <summary>
    ''' Calculation Tier
    ''' Tier 1 or Tier2/3
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(CATRegion)>
    <DisplayName("Calculation Tier")>
    <Description("Tier 1 or Tier2/3")>
    <DefaultValue(CInt(eTier.tier2))>
    Public Property tier As eTier
        Get
            Return _tier
        End Get
        Set
            _tier = Value
            Me.persam.properties.tier = _tier.ToString
            If Me.substanceType = eSubstanceType.microbialActive AndAlso
                    Me.tier = eTier.tier2 Then
                Me.substanceType = eSubstanceType.other
            End If
        End Set
    End Property

    Public Enum eSubstanceType
        microbialActive
        other
    End Enum

    ''' <summary>
    ''' Substance Type
    ''' Microbial active (only Tier 1), 
    ''' or 'other'
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(CATRegion)>
    <DisplayName("Substance Type")>
    <Description("Microbial active (only Tier 1), or 'other'")>
    <DefaultValue(CInt(eSubstanceType.other))>
    Public Property substanceType As eSubstanceType
        Get
            Return _substanceType
        End Get
        Set
            If tier = eTier.tier2 Then
                _substanceType = eSubstanceType.other
            Else
                _substanceType = Value
            End If

            Me.persam.properties.substanceType = _substanceType.ToString

        End Set
    End Property

    Public Enum eEndPoint
        totalSoil
        poreWater
        both
    End Enum

    ''' <summary>
    ''' Endpoint(s)
    ''' Concentration in soil or in pore water or both
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(CATRegion)>
    <DisplayName("Endpoint(s)")>
    <Description("Concentration in soil or in pore water or both")>
    <DefaultValue(CInt(eEndPoint.totalSoil))>
    Public Property endpoints As eEndPoint
        Get
            Return _endpoints
        End Get
        Set
            _endpoints = Value

            With Me.persam.properties

                Select Case _endpoints

                    Case eEndPoint.totalSoil
                        .endpoints = {"totalSoil"}

                    Case eEndPoint.poreWater
                        .endpoints = {"poreWater"}

                    Case Else
                        .endpoints = {"totalSoil", "poreWater"}

                End Select

            End With

        End Set
    End Property

    Public Enum eRegionType
        zone
        euMemberState
    End Enum

    ''' <summary>
    ''' Region type
    ''' Zone or country
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(CATRegion)>
    <DisplayName("Region type")>
    <Description("Zone or country")>
    <DefaultValue(CInt(eRegionType.zone))>
    Public Property regionType As eRegionType
        Get
            Return _regionType
        End Get
        Set
            _regionType = Value
            _regions = eRegions.central
            _Country = eEUcountries.zone

            Me.persam.properties.regionType = _regionType.ToString

        End Set
    End Property

    Public Enum eRegions

        north
        south
        central
        north_south
        north_central
        south_central
        north_south_central

    End Enum

    Public Enum eEUcountries

        Austria
        Belgium
        Bulgaria
        Cyprus
        CzechRepublic
        Denmark
        Estonia
        Finland
        France
        Germany
        Greece
        Hungary
        Ireland
        Italy
        Latvia
        Lithuania
        Luxembourg
        Malta
        Netherlands
        Poland
        Portugal
        Romania
        Slovakia
        Slovenia
        Spain
        Sweden
        UnitedKingdom

        zone

    End Enum

    ''' <summary>
    ''' Region(s) or ... 
    ''' North, south, central or combinations
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(CATRegion)>
    <DisplayName("Region(s) or ... ")>
    <Description("North, south, central or combinations or single countries")>
    <DefaultValue(CInt(eRegions.central))>
    Public Property regions As eRegions
        Get
            Return _regions
        End Get
        Set
            _regions = Value

            With Me.persam.properties

                Select Case _regions

                    Case eRegions.north
                        .regions = {"north"}

                    Case eRegions.south
                        .regions = {"south"}

                    Case eRegions.central
                        .regions = {"central"}

                    Case eRegions.north_central
                        .regions = {"north", "central"}

                    Case eRegions.south_central
                        .regions = {"south", "central"}

                    Case eRegions.north_south_central
                        .regions = {"north", "south", "central"}


                End Select

            End With

        End Set
    End Property

    ''' <summary>
    ''' ... Country
    ''' EU country (instead of zone)
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(CATRegion)>
    <DisplayName(" ... Country")>
    <Description("EU country (instead of zone)")>
    Public Property Country As eEUcountries
        Get
            Return _Country
        End Get
        Set

            If regionType = eRegionType.euMemberState Then

                _Country = Value
                Me.persam.properties.regions = {_Country.ToString}


            Else
                _Country = eEUcountries.zone
            End If

        End Set
    End Property

#End Region

    Public Const CATGW As String = "03  GW from *.gap file"
#Region "    GW from *gap"

#Region "GW Crop"

    ''' <summary>
    ''' FOCUSgw Crop, 
    ''' e.g. from *.gap file
    ''' </summary>
    ''' <returns></returns>
    <DisplayName("Crop")>
    <Category(CATGW)>
    <Description("FOCUSgw Crop, e.g. from *.gap file")>
    <DefaultValue(CInt(eCropsGW.notDef))>
    Public Property gwCrop As eCropsGW
        Get
            Return _gwCrop
        End Get
        Set

            _gwCrop = Value

            crop =
                translateGW2PERSAM(
                gwCrop:=_gwCrop)

        End Set
    End Property

    Public Shared Function translateGW2PERSAM(gwCrop As eCropsGW,
                        Optional onOrBetweenCrop As eOnOrBetweenCrop = eOnOrBetweenCrop.onCrop) As ePERSAMcrops

        Dim target As String = String.Empty
        Dim counter As Integer = 0

        Try
            For Each member In translateGW2PERSAMdb

                If member = gwCrop.ToString Then

                    If translateGW2PERSAMdb(counter + 2) <> "" Then
                        If onOrBetweenCrop = eOnOrBetweenCrop.onCrop Then
                            target = translateGW2PERSAMdb(counter + 1)
                        Else
                            target = translateGW2PERSAMdb(counter + 2)
                        End If

                    Else
                        target = translateGW2PERSAMdb(counter + 1)

                    End If

                    Exit For

                End If
                counter += 1
            Next

            If target = "" Then
                Console.WriteLine()
                Return ePERSAMcrops.not_Def
            Else

                Return [Enum].Parse(enumType:=GetType(ePERSAMcrops), value:=target)

            End If

        Catch ex As Exception
            Console.WriteLine(ex.Message)
            Return ePERSAMcrops.not_Def
        End Try

    End Function

#End Region

#Region "BBCH / appln date GW"

    ''' <summary>
    ''' BBCH Groundwater
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(CATGW)>
    <DisplayName(
    "BBCH")>
    <Description(
    "BBCH from PECgw assessment (*.gap file)")>
    <Browsable(True)>
    Public Property BBCHgw As BBCH
        Get
            Return _BBCHgw
        End Get
        Set

            _BBCHgw = Value
            persamBBCH = getPersamBBCH(BBCH:=Me.BBCHgw, possibleBBCH:=BBCHPersam)

        End Set
    End Property

    Public Function getPersamBBCH(BBCH As BBCH, possibleBBCH As String()) As String

        Dim persamMaxBBCH As Integer
        Dim persamMinBBCH As Integer
        Dim temp As String

        If possibleBBCH.Count = 0 Then Return String.Empty
        If crop.ToString.EndsWith("InRow") Then Return ""

        Dim out As New List(Of String)
        Dim outmax As New List(Of String)

        For Each member As String In possibleBBCH

            temp = "BBCH " & BBCH.Min.ToString("00") & "-" & BBCH.Max.ToString("00")

            If member.Contains(temp) Then
                Return member
            End If

        Next

        Try
            For Each member As String In possibleBBCH

                temp = member.Split(",")(1).Split.Last
                persamMinBBCH = CInt(temp.Split("-").First)
                persamMaxBBCH = CInt(temp.Split("-").Last)

                If BBCH.Min <= persamMinBBCH Then out.Add(member)

            Next
        Catch ex As Exception

        End Try

        If out.Count = 1 Then Return out.Last

        Try
            For Each member As String In out

                temp = member.Split(",")(1).Split.Last
                persamMinBBCH = CInt(temp.Split("-").First)
                persamMaxBBCH = CInt(temp.Split("-").Last)

                If BBCH.Max >= persamMaxBBCH Then outmax.Add(member)

            Next
        Catch ex As Exception

        End Try

        If outmax.Count = 0 Then Return out.First
        If outmax.Count = 1 Then Return outmax.First

        Dim maxWashOff As Double = -1
        out.Clear()

        'take BBCH with highest wash off factor
        For Each member As String In outmax

            temp = member.Split(",").Last
            If CDbl(temp) > maxWashOff Then
                maxWashOff = CDbl(temp)
                out.Add(member)
            End If

        Next

        Return out.Last

    End Function

    ''' <summary>
    ''' 1st appln date from GW
    ''' for crops applied in a row
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(CATGW)>
    <DisplayName(
    "1st Appln Date")>
    <Description(
    "1st appln date from GW" & vbCrLf &
    "for crops applied in a row")>
    Public Property firstApplnDateGW As Date
        Get
            Return _firstApplnDateGW
        End Get
        Set

            _firstApplnDateGW = Value
            Me.persamBBCH = getPersamApplnDate(
                firstApplnDay:=_firstApplnDateGW,
                possibleDates:=Me.BBCHPersam)

        End Set
    End Property

    Public Function getPersamApplnDate(firstApplnDay As Date, possibleDates As String()) As String

        Dim temp As String
        Dim minMonth As Integer
        Dim maxMonth As Integer

        If Not crop.ToString.EndsWith("InRow") Then Return String.Empty
        If possibleDates.Count = 0 Then Return String.Empty

        For Each member As String In possibleDates

            temp = member.Split(",")(1)

            minMonth = parseMonth(Trim(temp.Split("-").First))
            maxMonth = parseMonth(Trim(temp.Split("-").Last))

            If firstApplnDateGW.Month >= minMonth AndAlso
               firstApplnDateGW.Month <= maxMonth Then
                Return member
            End If

        Next

        Return String.Empty

    End Function

    <DebuggerStepThrough>
    Public Function parseMonth(Month As String) As Integer

        Select Case Month.ToLower

            Case "jan"
                Return 1
            Case "feb"
                Return 2
            Case "mar"
                Return 3
            Case "apr"
                Return 4
            Case "may"
                Return 5
            Case "jun"
                Return 6
            Case "jul"
                Return 7
            Case "aug"
                Return 8
            Case "sep"
                Return 9
            Case "oct"
                Return 10
            Case "nov"
                Return 11
            Case "dec"
                Return 12
            Case Else
                Return -1

        End Select

    End Function

    ''' <summary>
    ''' GW Appln Mode
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(CATGW)>
    <DisplayName(
    "Appln Mode")>
    <Description(
    "")>
    <DefaultValue(CInt(eApplnType.cropCanopy))>
    Public Property gwApplnMode As eApplnMode
        Get
            Return _gwApplnMode
        End Get
        Set
            _gwApplnMode = Value

            Select Case _gwApplnMode
                Case eApplnMode.AppCrpUsr
                    Me.applnType = eApplnType.cropCanopy
                Case eApplnMode.AppSolSur
                    Me.applnType = eApplnType.soilSurface
                Case eApplnMode.AppSolTil
                    Me.applnType = eApplnType.soilIncorporation
            End Select

        End Set
    End Property

#End Region


    ''' <summary>
    ''' Apply every
    ''' year, 2nd or third year
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Description()>
    <DisplayName("Apply every")>
    <Category(CATGW)>
    <DefaultValue(CInt(eYearlyRepeat.EveryYear))>
    Public Property yearlyRepeatGW As eYearlyRepeat
        Get
            Return Me.persam.applicationScheme.tcycle - 1
        End Get
        Set
            Me.persam.applicationScheme.tcycle = Value + 1
        End Set
    End Property


#End Region

    Public Const CATApplns As String = "04  Crop and Applications"
#Region "    Crop and Applications"

#Region "    Crop"

    ''' <summary>
    ''' PERSAM crop
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(CATApplns)>
    <DisplayName("Crop")>
    <Description("PERSAM crop")>
    <DefaultValue(CInt(ePERSAMcrops.not_Def))>
    Public Property crop As ePERSAMcrops
        Get

            If IsNothing(Me.persam.properties.crop) Then
                Return ePERSAMcrops.not_Def
            Else
                Return [Enum].Parse(
                        enumType:=GetType(ePERSAMcrops),
                        value:=Me.persam.properties.crop)
            End If

        End Get
        Set

            Me.persam.properties.crop = Value.ToString
            BBCHPersam = getPossibleBBCH(PERSAMcrop:=Value)

            'permanent crops
            If Value.ToString.Contains("apples") OrElse
               Value.ToString.Contains("vines") OrElse
               Value.ToString.Contains("olives") OrElse
               Value.ToString.Contains("citrus") OrElse
               Value.ToString.Contains("hops") OrElse
               Value.ToString.Contains("bush") Then

                cropType = eCropType.permanent

                persamBBCH =
                    getPersamApplnDate(
                        firstApplnDay:=Me.firstApplnDateGW,
                        possibleDates:=BBCHPersam)

                'annual crops
            Else

                cropType = eCropType.annual

                persamBBCH =
                    getPersamBBCH(
                        BBCH:=Me.BBCHgw,
                        possibleBBCH:=BBCHPersam)

            End If

        End Set
    End Property

    Public Enum eCropType
        permanent
        annual
    End Enum

    ''' <summary>
    ''' Crop Type
    ''' Permanent (e.g. vine, apples) or
    ''' annual crop (e.g. maize, cereals)
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(CATApplns)>
    <DisplayName(
    "Type")>
    <Description(
    "Permanent   (e.g. vine, apples) or" & vbCrLf &
    "annual crop (e.g. maize, cereals)")>
    <DefaultValue(CInt(eCropType.permanent))>
    Public Property cropType As eCropType
        Get
            Return [Enum].Parse(
                enumType:=GetType(eCropType),
                value:=Me.persam.properties.cropType)
        End Get
        Set
            Me.persam.properties.cropType = Value.ToString
        End Set
    End Property

#End Region

#Region "    Applications"

    ''' <summary>
    ''' BBCH
    ''' Possible BBCH settings for selected crop
    ''' incl. wash off factor
    ''' </summary>
    ''' <returns></returns>
    <DisplayName("Possible BBCH stages")>
    <Category(CATApplns)>
    <RefreshProperties(RefreshProperties.All)>
    <Description("Possible BBCH settings, incl. wash off factor")>
    <Browsable(False)>
    Public Property BBCHPersam As String()
        Get
            Return _BBCHPersam
        End Get
        Set
            _BBCHPersam = Value
        End Set
    End Property


    ''' <summary>
    ''' Used BBCH stage
    ''' BBCH stage used for PERSAM appln. settings
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
    "BBCH")>
    <Category(CATApplns)>
    <RefreshProperties(RefreshProperties.All)>
    <Description(
    "PERSAM BBCH stage used for appln. settings")>
    <DefaultValue("")>
    Public Property persamBBCH As String
        Get

            Return _persamBBCH
        End Get
        Set
            _persamBBCH = Value

            If _persamBBCH <> "" Then
                growthStage = _persamBBCH.Split(",")(1)

                For Each member As persam_application In Me.applns
                    member.growthStage = growthStage
                Next

            End If

        End Set
    End Property

    <Category(CATApplns)>
    <Browsable(False)>
    Public Property growthStage As String

    ''' <summary>
    ''' # of Applns
    ''' </summary>
    ''' <returns></returns>
    <Category(CATApplns)>
    <DisplayName("# of Applns")>
    Public Property noOfApplns As Integer
        Get
            Return _noOfApplns
        End Get
        Set
            _noOfApplns = Value
            If _noOfApplns = 0 Then
                Me.applns = {}
                Exit Property
            End If

            Dim temp As New List(Of persam_application)

            For counter As Integer = 0 To _noOfApplns - 1

                temp.Add(
                New persam_application(
                growthstage:=Me.growthStage,
                applnRate:=Me.applicationRate,
                dayIndex:=counter * interval))

            Next
            Me.applns = temp.ToArray

        End Set
    End Property

    ''' <summary>
    ''' Interval
    ''' </summary>
    ''' <returns></returns>
    <DisplayName("Interval")>
    <Category(CATApplns)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property interval As Integer
        Get
            Return _interval
        End Get
        Set
            If _noOfApplns = 1 Then
                _interval = 0
            Else
                _interval = Value

                For counter As Integer = 0 To applns.Count - 1

                    With applns(counter)
                        .dayIndex = counter * interval
                    End With

                Next

            End If

        End Set
    End Property

    ''' <summary>
    ''' applicationRate
    ''' </summary>
    ''' <returns></returns>
    <Category(CATApplns)>
    <DefaultValue(Double.NaN)>
    <DisplayName("Rate")>
    <Description("Appln. rate in kg/ha")>
    Public Property applicationRate As Double
        Get
            Return _applicationRate
        End Get
        Set

            _applicationRate = Value

            For counter As Integer = 0 To applns.Count - 1

                With applns(counter)
                    .applicationRate = _applicationRate
                End With

            Next

        End Set
    End Property

    <RefreshProperties(RefreshProperties.All)>
    <Category(CATApplns)>
    <DisplayName("Applications")>
    <Description("")>
    Public Property applns As persam_application()
        Get
            Return Me.persam.applicationScheme.applications
        End Get
        Set
            Me.persam.applicationScheme.applications = Value
        End Set
    End Property


    Public Enum eApplnType
        soilSurface
        cropCanopy
        soilDepth
        soilIncorporation
    End Enum

    ''' <summary>
    ''' Appln Type
    ''' to soil surface, 
    ''' crop canopy, 
    ''' incorporation or special depth
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(CATApplns)>
    <DisplayName(
    "Appln Type")>
    <Description(
    "to soil surface, crop canopy" & vbCrLf &
    "incorporation or special depth")>
    <DefaultValue(CInt(eApplnType.cropCanopy))>
    Public Property applnType As eApplnType
        Get
            Return [Enum].Parse(
                enumType:=GetType(eApplnType),
                value:=Me.persam.properties.applicationType)
        End Get
        Set

            Me.persam.properties.applicationType = Value.ToString

            Select Case Me.persam.properties.applicationType
                Case eApplnType.soilIncorporation
                    Me.persam.settings.zinc = stdSoilIncorporationDepth
                Case eApplnType.cropCanopy, eApplnType.soilSurface, eApplnType.soilDepth
                    Me.persam.settings.zinc = 0
            End Select

        End Set
    End Property

    Public Const stdSoilIncorporationDepth As Integer = 3

    ''' <summary>
    ''' Incorporation Depth
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
    "Incorporation Depth")>
    <Description(
    "depends on appln method and crop type" & vbCrLf &
    "")>
    <DefaultValue(0)>
    <Category(CATApplns)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property zinc As Double
        Get
            Return Me.persam.settings.zinc
        End Get
        Set
            Select Case applnType

                Case eApplnType.cropCanopy, eApplnType.soilSurface
                    Value = 0

                Case eApplnType.soilIncorporation

                    If Value < 1 Then Value = stdSoilIncorporationDepth
                    If Value > 30 Then Value = 30

                    If cropType = eCropType.permanent Then

                        If Value <> 1 Then

                            Value = Math.Round(Value / 5, 0) * 5

                            If Value < stdSoilIncorporationDepth Then
                                Value = stdSoilIncorporationDepth
                            End If

                        End If

                    End If

                Case eApplnType.soilDepth
                    If Value > 29 Then Value = 29

            End Select

            Me.persam.settings.zinc = Value

        End Set
    End Property



    ''' <summary>
    ''' Apply every
    ''' year, 2nd or third year
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Description()>
    <DisplayName("Apply every")>
    <Category(CATApplns)>
    <DefaultValue(CInt(eYearlyRepeat.EveryYear))>
    Public Property yearlyRepeat As eYearlyRepeat
        Get
            Return Me.persam.applicationScheme.tcycle - 1
        End Get
        Set
            Me.persam.applicationScheme.tcycle = Value + 1
        End Set
    End Property


#End Region

#End Region

    Public Const CATSubstances As String = "05  Substances"
#Region "     Substances"

    ''' <summary>
    ''' Parent Substance
    ''' </summary>
    ''' <returns></returns>
    <DisplayName("Parent Substance")>
    <Category(CATSubstances)>
    <RefreshProperties(RefreshProperties.All)>
    <Description("")>
    Public Property parent As persam_Substance
        Get
            Return Me.persam.substanceTree.parentSubstance
        End Get
        Set
            Me.persam.substanceTree.parentSubstance = Value
        End Set
    End Property

    ''' <summary>
    ''' Primary Metabolite(s)
    ''' Up to four primary metabolites
    ''' </summary>
    ''' <returns></returns>
    <DisplayName("Prim. Metabolite(s)")>
    <Category(CATSubstances)>
    <RefreshProperties(RefreshProperties.All)>
    <Description("Up to four primary metabolites")>
    Public Property primaryMetabolites As persam_Substance()
        Get
            Return Me.persam.substanceTree.primaryMetabolites
        End Get
        Set()

            If Value.Count <> 4 Then Exit Property
            Me.persam.substanceTree.primaryMetabolites = Value

        End Set
    End Property


    ''' <summary>
    ''' Primary Metabolite(s)
    ''' Up to four primary metabolites
    ''' </summary>
    ''' <returns></returns>
    <DisplayName("Sec.  Metabolite(s)")>
    <Category(CATSubstances)>
    <RefreshProperties(RefreshProperties.All)>
    <Description("Up to four secondary metabolites")>
    Public Property secondaryMetabolites As persam_Substance()
        Get
            Return Me.persam.substanceTree.secondaryMetabolites
        End Get
        Set(value As persam_Substance())
            Me.persam.substanceTree.secondaryMetabolites = value
        End Set
    End Property

#End Region

    Public Const CATFF As String = "06  Formation Fractions"
#Region "    Formation Fractions"

    'Private _primaryFF As Double() = {0, 0, 0, 0}

    ''' <summary>
    ''' Parent to primary metabolites 0 - 3
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
    "Par -> Prim 0-3")>
    <Category(CATFF)>
    <RefreshProperties(RefreshProperties.All)>
    <Description("Parent to primary metabolites 0 - 3")>
    Public Property primaryFF As Double()
        Get

            Dim temp As Double() = {0, 0, 0, 0}

            For counter As Integer = 0 To temp.Count - 1
                temp(counter) = CDbl(Me.persam.substanceTree.primaryFormationFractions(counter))
            Next

            Return temp

        End Get
        Set

            If Value.Count <> 4 Then Exit Property

            For counter = 0 To Value.Count - 1

                If Value(counter) > 0 Then
                    Me.persam.substanceTree.primaryFormationFractions(counter) = CObj(Value(counter))
                End If

            Next

            '_primaryFF = Value

        End Set
    End Property

    ''' <summary>
    ''' Prim 0 -> Sec 0-3
    ''' Formation fraction FIRST primary metabolite
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
    "Prim 0 -> Sec 0-3")>
    <Category(CATFF)>
    <RefreshProperties(RefreshProperties.All)>
    <Description(
    "Formation fraction FIRST primary metabolite " & vbCrLf &
    "to secondary metabolites 0 - 3")>
    Public Property primarySec00 As Double()
        Get

            Dim temp As Double() = {0, 0, 0, 0}
            Dim test As Object
            Dim objTest As String

            For counter As Integer = 0 To temp.Count - 1

                test = Me.persam.substanceTree.secondaryFormationFractions(0)(counter)

                If Not IsNothing(test) Then
                    objTest = test.ToString
                    If objTest <> "System.Object" Then
                        temp(counter) = DirectCast(test, Double)
                    End If
                End If
            Next

            Return temp

        End Get
        Set

            If Value.Count <> 4 Then Exit Property

            Dim temp As New List(Of Object)
            temp.Add(New Object) : temp.Add(New Object) : temp.Add(New Object) : temp.Add(New Object)

            For counter = 0 To Value.Count - 1

                If Value(counter) > 0 Then
                    temp(counter) = CObj(Value(counter))
                Else
                    temp(counter) = Nothing
                End If

            Next

            Me.persam.substanceTree.secondaryFormationFractions(0) = temp

        End Set
    End Property

    ''' <summary>
    ''' Prim 1 -> Sec 0-3
    ''' Formation fraction SECOND primary metabolite
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
    "Prim 1 -> Sec 0-3")>
    <Category(CATFF)>
    <RefreshProperties(RefreshProperties.All)>
    <Description(
    "Formation fraction SECOND primary metabolite " & vbCrLf &
    "to secondary metabolites 0 - 3")>
    Public Property primarySec01 As Double()
        Get

            Dim temp As Double() = {0, 0, 0, 0}
            Dim test As Object
            Dim objTest As String

            For counter As Integer = 0 To temp.Count - 1

                test = Me.persam.substanceTree.secondaryFormationFractions(1)(counter)

                If Not IsNothing(test) Then
                    objTest = test.ToString
                    If objTest <> "System.Object" Then
                        temp(counter) = DirectCast(test, Double)
                    End If
                End If
            Next

            Return temp
        End Get
        Set

            If Value.Count <> 4 Then Exit Property

            Dim temp As New List(Of Object)
            temp.Add(New Object) : temp.Add(New Object) : temp.Add(New Object) : temp.Add(New Object)

            For counter = 0 To Value.Count - 1

                If Value(counter) > 0 Then
                    temp(counter) = CObj(Value(counter))
                End If

            Next

            Me.persam.substanceTree.secondaryFormationFractions(1) = temp

        End Set
    End Property

    ''' <summary>
    ''' Prim 2 -> Sec 0-3
    ''' Formation fraction THIRD primary metabolite
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
    "Prim 2 -> Sec 0-3")>
    <Category(CATFF)>
    <RefreshProperties(RefreshProperties.All)>
    <Description(
    "Formation fraction THIRD primary metabolite " & vbCrLf &
    "to secondary metabolites 0 - 3")>
    Public Property primarySec02 As Double()
        Get

            Dim temp As Double() = {0, 0, 0, 0}
            Dim test As Object
            Dim objTest As String

            For counter As Integer = 0 To temp.Count - 1

                test = Me.persam.substanceTree.secondaryFormationFractions(2)(counter)

                If Not IsNothing(test) Then
                    objTest = test.ToString
                    If objTest <> "System.Object" Then
                        temp(counter) = DirectCast(test, Double)
                    End If
                End If
            Next

            Return temp

        End Get
        Set

            If Value.Count <> 4 Then Exit Property

            Dim temp As New List(Of Object)
            temp.Add(New Object) : temp.Add(New Object) : temp.Add(New Object) : temp.Add(New Object)

            For counter = 0 To Value.Count - 1

                If Value(counter) > 0 Then
                    temp(counter) = CObj(Value(counter))
                End If

            Next

            Me.persam.substanceTree.secondaryFormationFractions(2) = temp

        End Set
    End Property

    ''' <summary>
    ''' Prim 3 -> Sec 0-3
    ''' Formation fraction FOURTH primary metabolite
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
    "Prim 3 -> Sec 0-3")>
    <Category(CATFF)>
    <RefreshProperties(RefreshProperties.All)>
    <Description(
    "Formation fraction FOURTH primary metabolite " & vbCrLf &
    "to secondary metabolites 0 - 3")>
    Public Property primarySec03 As Double()
        Get

            Dim temp As Double() = {0, 0, 0, 0}
            Dim test As Object
            Dim objTest As String

            For counter As Integer = 0 To temp.Count - 1

                test = Me.persam.substanceTree.secondaryFormationFractions(3)(counter)

                If Not IsNothing(test) Then
                    objTest = test.ToString
                    If objTest <> "System.Object" Then
                        temp(counter) = DirectCast(test, Double)
                    End If
                End If
            Next

            Return temp

        End Get
        Set

            If Value.Count <> 4 Then Exit Property

            Dim temp As New List(Of Object)
            temp.Add(New Object) : temp.Add(New Object) : temp.Add(New Object) : temp.Add(New Object)

            For counter = 0 To Value.Count - 1

                If Value(counter) > 0 Then
                    temp(counter) = CObj(Value(counter))
                End If

            Next

            Me.persam.substanceTree.secondaryFormationFractions(3) = temp

        End Set
    End Property

#End Region

    Public Const CATSettings As String = "07  Settings"
#Region "    Settings"

    ''' <summary>
    ''' Export Maps?
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
    "Export Maps?")>
    <RefreshProperties(RefreshProperties.All)>
    <Category(CATSettings)>
    <Description(
    "" & vbCrLf &
    "")>
    <DefaultValue(False)>
    Public Property exportGeneratedMaps As Boolean
        Get
            Return Me.persam.settings.exportGeneratedMaps
        End Get
        Set
            Me.persam.settings.exportGeneratedMaps = Value
        End Set
    End Property

    ''' <summary>
    ''' Time weighted average tavg in days
    ''' The default value is 0 days
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
    "Time Weighted Average")>
    <RefreshProperties(RefreshProperties.All)>
    <Category(CATSettings)>
    <Description(
    "Time weighted average tavg in days" & vbCrLf &
    "The default value is 0 days")>
    <DefaultValue(0)>
    Public Property tavg As Integer
        Get
            Return Me.persam.settings.tavg
        End Get
        Set
            Me.persam.settings.tavg = Value
        End Set
    End Property

    ''' <summary>
    ''' Interval Post-Application PEC
    ''' This parameter is part of the PERSAM transfer file
    ''' </summary>
    ''' <returns></returns>
    <DisplayName("Post-Appln Interval")>
    <RefreshProperties(RefreshProperties.All)>
    <Category(CATSettings)>
    <Description(
    "tpostApp : Time interval for calculation of post-application PEC in days" & vbCrLf &
    "The default value is 0 days. This parameter is part of the PERSAM transfer file")>
    <DefaultValue(0)>
    Public Property tpostApp As Integer
        Get
            Return Me.persam.settings.tpostApp
        End Get
        Set
            Me.persam.settings.tpostApp = Value
        End Set
    End Property

    ''' <summary>
    ''' Fraction of Surface Area Treated
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
    "Surface Area Treated")>
    <Category(CATSettings)>
    <Description(
    "The fraction of surface area treated ftreated is disabled" & vbCrLf &
    "and fixed at the default 1.0 for permanent crops. For annual crops = user input")>
    <DefaultValue(1)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property ftreated As Double
        Get
            Return Me.persam.settings.ftreated
        End Get
        Set

            If cropType = eCropType.permanent Then
                Me.persam.settings.ftreated = 1
            Else
                Me.persam.settings.ftreated = Value
            End If

        End Set
    End Property

    ''' <summary>
    ''' Evaluation Depth Soil
    ''' default 5cm
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
    "Evaluation Depth Soil")>
    <Description(
    "Eco-toxicological evaluation depth Zeco for concentration in total soil" & vbCrLf &
    "by default: 5cm")>
    <DefaultValue(5)>
    <Category(CATSettings)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property zecoTotalSoil As Double
        Get
            Return Me.persam.settings.zecoTotalSoil
        End Get
        Set
            Me.persam.settings.zecoTotalSoil = Value
        End Set
    End Property

    ''' <summary>
    ''' Evaluation Depth Pore Water
    ''' default 1cm 
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
    "           Pore Water")>
    <Description(
    "Eco-toxicological evaluation depth Zeco for concentration in liquid phase" & vbCrLf &
    "by default: 1cm")>
    <DefaultValue(1)>
    <Category(CATSettings)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property zecoPoreWater As Double
        Get
            Return _zecoPoreWater
        End Get
        Set
            _zecoPoreWater = Value
            Me.persam.settings.zecoPoreWater = _zecoPoreWater
        End Set
    End Property

#End Region

#Region "    PERSAM db"

    Public Shared washOffDB As String() =
    {
        "apples,BBCH 00-09,0.55",
        "apples,BBCH 10-69,0.6",
        "apples,BBCH 71-75,0.6",
        "apples,BBCH 76-89,0.55",
        "beans,BBCH 00-09,0",
        "beans,BBCH 10-19,0.6",
        "beans,BBCH 20-39,0.75",
        "beans,BBCH 40-89,0.8",
        "beans,BBCH 90-99,0.35",
        "bushBerries,BBCH 00-09,0.5",
        "bushBerries,BBCH 10-69,0.6",
        "bushBerries,BBCH 71-89,0.55",
        "cabbage,BBCH 00-09,0",
        "cabbage,BBCH 10-19,0.6",
        "cabbage,BBCH 20-39,0.8",
        "cabbage,BBCH 40-49,0.4",
        "cabbage,BBCH 50-89,0",
        "cabbage,BBCH 90-99,0",
        "carrots,BBCH 00-09,0",
        "carrots,BBCH 10-19,0.75",
        "carrots,BBCH 20-39,0.85",
        "carrots,BBCH 40-49,0.5",
        "carrots,BBCH 50-89,0",
        "carrots,BBCH 90-99,0",
        "cotton,BBCH 00-09,0",
        "cotton,BBCH 10-19,0.65",
        "cotton,BBCH 20-39,0.75",
        "cotton,BBCH 40-89,0.65",
        "cotton,BBCH 90-99,0.45",
        "fallow,BBCH 00-99,0",
        "hops,BBCH 00-09,0.5",
        "hops,BBCH 11-13,0.55",
        "hops,BBCH 14-19,0.55",
        "hops,BBCH 20-52,0.55",
        "hops,BBCH 53-69,0.55",
        "hops,BBCH 71-89,0.6",
        "linseed,BBCH 00-09,0",
        "linseed,BBCH 10-19,0.55",
        "linseed,BBCH 20-39,0.75",
        "linseed,BBCH 40-89,0.6",
        "linseed,BBCH 90-99,0.3",
        "maize,BBCH 00-09,0",
        "maize,BBCH 10-19,0.45",
        "maize,BBCH 20-39,0.65",
        "maize,BBCH 40-89,0.7",
        "maize,BBCH 90-99,0.55",
        "oilseedRapeSummer,BBCH 00-09,0",
        "oilseedRapeSummer,BBCH 10-19,0.4",
        "oilseedRapeSummer,BBCH 20-39,0.5",
        "oilseedRapeSummer,BBCH 40-89,0.6",
        "oilseedRapeSummer,BBCH 90-99,0.5",
        "oilseedRapeWinter,BBCH 00-09,0",
        "oilseedRapeWinter,BBCH 10-19,0.1",
        "oilseedRapeWinter,BBCH 20-39,0.4",
        "oilseedRapeWinter,BBCH 40-89,0.55",
        "oilseedRapeWinter,BBCH 90-99,0.3",
        "onions,BBCH 00-09,0",
        "onions,BBCH 10-19,0.6",
        "onions,BBCH 20-39,0.75",
        "onions,BBCH 40-49,0.55",
        "onions,BBCH 50-89,0",
        "onions,BBCH 90-99,0",
        "peas,BBCH 00-09,0",
        "peas,BBCH 10-19,0.4",
        "peas,BBCH 20-39,0.6",
        "peas,BBCH 40-89,0.65",
        "peas,BBCH 90-99,0.35",
        "potatoes,BBCH 00-09,0",
        "potatoes,BBCH 10-19,0.3",
        "potatoes,BBCH 20-39,0.5",
        "potatoes,BBCH 40-89,0.6",
        "potatoes,BBCH 90-99,0.35",
        "soybean,BBCH 00-09,0",
        "soybean,BBCH 10-19,0.55",
        "soybean,BBCH 20-39,0.75",
        "soybean,BBCH 40-89,0.8",
        "soybean,BBCH 90-99,0.35",
        "springCereals,BBCH 00-09,0",
        "springCereals,BBCH 10-19,0.4",
        "springCereals,BBCH 20-29,0.5",
        "springCereals,BBCH 30-39,0.5",
        "springCereals,BBCH 40-69,0.65",
        "springCereals,BBCH 70-89,0.65",
        "springCereals,BBCH 90-99,0.55",
        "strawberries,BBCH 00-09,0",
        "strawberries,BBCH 10-19,0.5",
        "strawberries,BBCH 20-39,0.7",
        "strawberries,BBCH 40-89,0.75",
        "strawberries,BBCH 90-99,0.5",
        "sugarBeets,BBCH 00-09,0",
        "sugarBeets,BBCH 10-19,0.4",
        "sugarBeets,BBCH 20-39,0.6",
        "sugarBeets,BBCH 40-49,0.6",
        "sugarBeets,BBCH 50-89,0",
        "sugarBeets,BBCH 90-99,0",
        "sunflowers,BBCH 00-09,0",
        "sunflowers,BBCH 10-19,0.6",
        "sunflowers,BBCH 20-39,0.75",
        "sunflowers,BBCH 40-89,0.8",
        "sunflowers,BBCH 90-99,0.55",
        "tobacco,BBCH 00-09,0",
        "tobacco,BBCH 10-19,0.55",
        "tobacco,BBCH 20-39,0.75",
        "tobacco,BBCH 40-89,0.8",
        "tobacco,BBCH 90-99,0.85",
        "tomatoes,BBCH 00-09,0",
        "tomatoes,BBCH 10-19,0.55",
        "tomatoes,BBCH 20-39,0.75",
        "tomatoes,BBCH 40-89,0.7",
        "tomatoes,BBCH 90-99,0.35",
        "vines,BBCH 00-09,0.45",
        "vines,BBCH 11-13,0.4",
        "vines,BBCH 14-19,0.5",
        "vines,BBCH 53-69,0.55",
        "vines,BBCH 71-89,0.6",
        "winterCereals,BBCH 00-09,0",
        "winterCereals,BBCH 10-19,0.1",
        "winterCereals,BBCH 20-29,0.4",
        "winterCereals,BBCH 30-39,0.6",
        "winterCereals,BBCH 40-69,0.55",
        "winterCereals,BBCH 70-89,0.6",
        "winterCereals,BBCH 90-99,0.4",
        "applesInRow,Jan-Mar,0.45",
        "applesInRow,Apr-Jun,0.55",
        "applesInRow,Jul-Sep,0.55",
        "applesInRow,Oct-Dec,0.5",
        "bushBerriesInRow,Jan-Mar,0.45",
        "bushBerriesInRow,Apr-Jun,0.55",
        "bushBerriesInRow,Jul-Sep,0.55",
        "bushBerriesInRow,Oct-Dec,0.5",
        "citrusInRow,Jan-Mar,0",
        "citrusInRow,Apr-Jun,0",
        "citrusInRow,Jul-Sep,0",
        "citrusInRow,Oct-Dec,0",
        "hopsInRow,Jan-Mar,0",
        "hopsInRow,Apr-Jun,0",
        "hopsInRow,Jul-Sep,0",
        "hopsInRow,Oct-Dec,0",
        "olivesInRow,Jan-Mar,0",
        "olivesInRow,Apr-Jun,0",
        "olivesInRow,Jul-Sep,0",
        "olivesInRow,Oct-Dec,0",
        "vinesInRow,Jan-Mar,0",
        "vinesInRow,Apr-Jun,0",
        "vinesInRow,Jul-Sep,0",
        "vinesInRow,Oct-Dec,0",
        "citrus,Jan-Mar,0.5",
        "citrus,Apr-Jun,0.3",
        "citrus,Jul-Sep,0.15",
        "citrus,Oct-Dec,0.55",
        "olives,Jan-Mar,0.5",
        "olives,Apr-Jun,0.3",
        "olives,Jul-Sep,0.15",
        "olives,Oct-Dec,0.5",
        "grass,Jan-Mar,0.45",
        "grass,Apr-Jun,0.55",
        "grass,Jul-Sep,0.55",
        "grass,Oct-Dec,0.5"
    }

    Public Shared Function getPossibleBBCH(PERSAMcrop As ePERSAMcrops) As String()

        Dim out As String()

        out =
            Filter(
            Source:=washOffDB,
            Match:=PERSAMcrop.ToString,
            Include:=True,
            Compare:=CompareMethod.Text)

        If PERSAMcrop.ToString.EndsWith("InRow") Then
            out =
                Filter(
                Source:=out,
                Match:="InRow",
                Include:=True,
                Compare:=CompareMethod.Text)
        Else
            out =
                Filter(
                Source:=out,
                Match:="InRow",
                Include:=False,
                Compare:=CompareMethod.Text)
        End If


        Return out

    End Function


#Region "    enums"

    ''' <summary>
    ''' Runtime in years for appln every 
    '''     year = 26
    ''' 2nd year = 46
    ''' 3rd year = 66
    ''' </summary>
    Public Enum eYearlyRepeat
        <Description("year")>
        EveryYear

        <Description("2nd year")>
        EverySecondYear

        <Description("3rd year")>
        EveryThirdYear
    End Enum

    ''' <summary>
    ''' FOCUS gw Crops
    ''' </summary>
    Public Enum eCropsGW

        <Description(
"apples                 CHJKNPOST")>
        APPLES

        <Description(
"beans (field)            	H KN    ")>
        FLDBEANS

        <Description(
"beans (vegetables) 2nd       O T")>
        VEGBEANS

        <Description(
"bush berries             J      ")>
        BUSHBERR

        <Description(
"cabbage            2nd CHJK  OST")>
        CABBAGE

        <Description(
"carrots            2nd CHJK  O T")>
        CARROTS

        <Description(
"citrus                      POST")>
        CITRUS

        <Description(
"cotton                        ST")>
        COTTON

        <Description(
"grass                  CHJKNPOST")>
        GRASS

        <Description(
"linseed                    N    ")>
        LINSEED

        <Description(
"maize                  CH KNPOST")>
        MAIZE

        <Description(
"oil seed rape (summer)   J N O  ")>
        SOILSEED

        <Description(
"oil seed rape (winter) CH KNPO  ")>
        WOILSEED

        <Description(
"onions                 CHJK  O T")>
        ONIONS

        <Description(
"peas                   CHJ N    ")>
        PEAS

        <Description(
"potatoes               CHJKNPOST")>
        SPOTATOES

        <Description(
"soybean                     P   ")>
        SOYBEAN

        <Description(
"spring cereals         CHJKN O  ")>
        SCEREALS

        <Description(
"strawberries            HJK   S ")>
        STRAWBER

        <Description(
"sugarbeets             CHJKNPOST")>
        SUGARBEET

        <Description(
"sunflower                   P S ")>
        SUNFLOWER

        <Description(
"tobacco                     P  ")>
        TOBACCO

        <Description(
"tomatoes               C    POST")>
        TOMATOES

        <Description(
"vines                  CH K POST")>
        VINES

        <Description(
"winter cereals         CHJKNPOST")>
        WCEREALS

        <Description(
"bare soil              CHJKNPOST")>
        BARESOIL

        <Description(" - ")>
        notDef


    End Enum

    ''' <summary>
    ''' Appln mode : 
    '''   to crop canopy
    '''   to soil or
    '''   via incorporation
    ''' </summary>
    Public Enum eApplnMode

        ''' <summary>
        ''' to crop canopy
        ''' </summary>
        <Description("to crop canopy")>
        AppCrpUsr

        ''' <summary>
        ''' to soil
        ''' </summary>
        <Description("to soil")>
        AppSolSur

        ''' <summary>
        ''' via incorporation, depth info needed
        ''' </summary>
        <Description("via incorporation")>
        AppSolTil

        ''' <summary>
        ''' via injection to a certain depth, seldom used!
        ''' </summary>
        <Description("via injection to a certain depth")>
        AppSolTInj

    End Enum


    Public Enum ePERSAMcrops

        <Description("Apples (application on crop in row)")>
        applesInRow
        <Description("Apples (between crop in row. grass)")>
        apples
        <Description("Beans (field. veg.)")>
        beans
        <Description("Bush berries (application on crop in row)")>
        bushBerriesInRow
        <Description("Bush berries (between crop in row. grass)")>
        bushBerries
        <Description("Cabbage")>
        cabbage
        <Description("Carrots")>
        carrots
        <Description("Citrus (application on crop in row)")>
        citrusInRow
        <Description("Citrus (between crop in row. bare soil)")>
        citrus
        <Description("Cotton")>
        cotton
        <Description("Fallow")>
        fallow
        <Description("Grass (pasture)")>
        grass
        <Description("Hops (application on crop in row)")>
        hopsInRow
        <Description("Hops (between crop in row. bare soil)")>
        hops
        <Description("Linseed")>
        linseed
        <Description("Maize")>
        maize
        <Description("Oilseed rape (summer)")>
        oilseedRapeSummer
        <Description("Oilseed rape (winter)")>
        oilseedRapeWinter
        <Description("Olives (application on crop in row)")>
        olivesInRow
        <Description("Olives (between crop in row. bare soil)")>
        olives
        <Description("Onions")>
        onions
        <Description("Peas")>
        peas
        <Description("Potatoes")>
        potatoes
        <Description("Soybean")>
        soybean
        <Description("Spring cereals")>
        springCereals
        <Description("Strawberries")>
        strawberries
        <Description("Sugar beets")>
        sugarBeets
        <Description("Sunflowers")>
        sunflowers
        <Description("Tobacco")>
        tobacco
        <Description("Tomatoes")>
        tomatoes
        <Description("Vines (application on crop in row)")>
        vinesInRow
        <Description("Vines (between crop in row. bare soil)")>
        vines
        <Description("Winter cereals")>
        winterCereals

        not_Def = -1

    End Enum

    ''' <summary>
    ''' Appln on or between crops
    ''' </summary>
    Public Enum eOnOrBetweenCrop
        onCrop
        betweenCrop
    End Enum

#End Region

    Public Shared translateGW2PERSAMdb As String() =
        {
            "APPLES", "apples", "applesInRow",
            "FLDBEANS", "beans", "",
            "VEGBEANS", "beans", "",
            "BUSHBERR", "bushBerries", "bushBerriesInRow",
            "CABBAGE", "cabbage", "",
            "CARROTS", "carrots", "",
            "CITRUS", "citrus", "citrusInRow",
            "COTTON", "cotton", "",
            "GRASS", "grass", "",
            "LINSEED", "linseed", "",
            "MAIZE", "maize", "",
            "SOILSEED", "oilseedRapeSummer", "",
            "WOILSEED", "oilseedRapeWinter", "",
            "ONIONS", "onions", "",
            "PEAS", "peas", "",
            "SPOTATOES", "potatoes", "",
            "SOYBEAN", "soybean", "",
            "SCEREALS", "springCereals", "",
            "STRAWBER", "strawberries", "",
            "SUGARBEET", "sugarBeets", "",
            "SUNFLOWER", "sunflowers", "",
            "TOBACCO", "tobacco", "",
            "TOMATOES", "tomatoes", "",
            "VINES", "vines", "vinesInRow",
            "WCEREALS", "winterCereals", "",
            "BARESOIL", "fallow", ""
        }

#End Region

End Class

#Region "    Helper"

<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class BBCH

    Public Sub New()

    End Sub

    <Browsable(False)>
    Public ReadOnly Property Name As String
        Get
            Return Me.ToString
        End Get
    End Property

    Public Property Min As Integer = -1

    Public Property Max As Integer = 101

    Public Overrides Function ToString() As String
        Return Min.ToString("00") & " - " & Max.ToString("00")
    End Function

End Class

#End Region

#Region "PERSAM orig."

#Region "Main"

<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class persam

    Public Sub New()

    End Sub

    Public Property name As String = String.Empty
    Public Property outputFolder As String = String.Empty
    Public Property properties As New persam_properties
    Public Property settings As New persam_settings
    Public Property substanceTree As New persam_substanceTree
    Public Property applicationScheme As New persam_applicationScheme

End Class

#End Region

#Region "Properties and settings"

<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class persam_properties

    Public Sub New()

    End Sub

#Region "    const. settings : tier, substance type, region type"

    Public Const CATconstSettings As String = "'Constant' settings"

    <Category(CATconstSettings)>
    Public Property tier As String = "tier2"

    <Category(CATconstSettings)>
    Public Property substanceType As String = "other"

    <Category(CATconstSettings)>
    Public Property regionType As String = "zone"

#End Region

    Public Property regions As String() = {}

    Public Property cropType As String = "annual"
    Public Property crop As String
    Public Property endpoints As String() = {}
    Public Property applicationType As String

End Class

<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class persam_settings

    Public Sub New()

    End Sub

    Public Property exportGeneratedMaps As Boolean = False
    Public Property tavg As Integer
    Public Property tpostApp As Integer
    Public Property ftreated As Double
    Public Property zecoTotalSoil As Double
    Public Property zecoPoreWater As Double
    Public Property zinc As Double

End Class

#End Region

#Region "Substance"

<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class persam_substanceTree

    Public Sub New()

        Dim temp As New List(Of Object)
        temp.Add(Nothing) : temp.Add(Nothing) : temp.Add(Nothing) : temp.Add(Nothing)

        primaryMetabolites =
            {
            New persam_Substance,
            New persam_Substance,
            New persam_Substance,
            New persam_Substance
        }
        secondaryMetabolites =
            {
            New persam_Substance,
            New persam_Substance,
            New persam_Substance,
            New persam_Substance}


        primaryFormationFractions = temp.ToArray

        secondaryFormationFractions.Add(temp)
        secondaryFormationFractions.Add(temp)
        secondaryFormationFractions.Add(temp)
        secondaryFormationFractions.Add(temp)

    End Sub

    Public Property parentSubstance As New persam_Substance
    Public Property primaryMetabolites As persam_Substance() = {}
    Public Property secondaryMetabolites As persam_Substance() = {}
    Public Property primaryFormationFractions As Object() = {}
    Public Property secondaryFormationFractions As New List(Of List(Of Object))

End Class

<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class persam_Substance

    Public Sub New()

    End Sub

#Region "    _methods"

    Private _substanceDefinition As String = "custom"
    Private _code As String = String.Empty
    Private _kom As Double = Double.NaN
    Private _degT50 As Double = Double.NaN
    Private _m As Double = Double.NaN
    Private _e As Double = 65.4
    Private _racTotalSoil As Double = 0
    Private _racPoreWater As Double = 0

#End Region

    <ScriptIgnore>
    <XmlIgnore>
    <RefreshProperties(RefreshProperties.All)>
    <Category(CATSubstance)>
    Public ReadOnly Property inputComplete As String
        Get

            If code = String.Empty Then Return "Code?"

            If Double.IsNaN(kom) Then Return "Kom?"
            If Double.IsNaN(degT50) Then Return "DT50?"
            If Double.IsNaN(m) Then Return "Molar mass?"

            Return "OK"

        End Get
    End Property

    <Browsable(False)>
    <ScriptIgnore>
    Public ReadOnly Property Name As String
        Get
            Return Me.code
        End Get
    End Property

    Public Const CATSubstance As String = "01  Substance"

    ''' <summary>
    ''' Substance Definition
    ''' 'custom' or 'predefined1' - 'predefined18'
    ''' std. = 'custom'
    ''' </summary>
    ''' <returns></returns>
    <Category(CATSubstance)>
    <DisplayName(
    "Substance Definition")>
    <Description(
    "'custom' or 'predefined1' - 'predefined18'" & vbCrLf &
    "")>
    <DefaultValue("custom")>
    <Browsable(False)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property substanceDefinition As String
        Get
            Return _substanceDefinition
        End Get
        Set
            _substanceDefinition = Value
        End Set
    End Property

    ''' <summary>
    ''' Code
    ''' </summary>
    ''' <returns></returns>
    <Category(CATSubstance)>
    <DisplayName(
    "Code")>
    <Description(
    "" & vbCrLf &
    "")>
    <DefaultValue("")>
    <RefreshProperties(RefreshProperties.All)>
    Public Property code As String
        Get
            Return _code
        End Get
        Set
            _code = Value
        End Set
    End Property

    ''' <summary>
    ''' Kom
    ''' in L/kg
    ''' </summary>
    ''' <returns></returns>
    <Category(CATSubstance)>
    <DisplayName(
    "Kom")>
    <Description(
    "Organic matter/water distribution coefficient" & vbCrLf &
    "in l/kg")>
    <DefaultValue(Double.NaN)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property kom As Double
        Get
            Return _kom
        End Get
        Set
            _kom = Value
        End Set
    End Property

    ''' <summary>
    ''' Half life for degradation of the substance
    ''' in days
    ''' </summary>
    ''' <returns></returns>
    <Category(CATSubstance)>
    <DisplayName(
    "DT50")>
    <Description(
    "Half life for degradation of the substance" & vbCrLf &
    "in days")>
    <DefaultValue(Double.NaN)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property degT50 As Double
        Get
            Return _degT50
        End Get
        Set
            _degT50 = Value
        End Set
    End Property

    ''' <summary>
    ''' Molar mass
    ''' </summary>
    ''' <returns></returns>
    <Category(CATSubstance)>
    <DisplayName(
    "Molar Mass")>
    <Description(
    "Molar mass in g/mol" & vbCrLf &
    "")>
    <DefaultValue(Double.NaN)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property m As Double
        Get
            Return _m
        End Get
        Set
            _m = Value
        End Set
    End Property

    ''' <summary>
    ''' Arrhenius Activation Energy
    ''' std. = 65.4 kJ/mol
    ''' </summary>
    ''' <returns></returns>
    <Category(CATSubstance)>
    <DisplayName(
    "Activation Energy")>
    <Description(
    "Arrhenius activation energy in kJ/mol" & vbCrLf &
    "std. = 65.4 kJ/mol")>
    <DefaultValue(65.4)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property e As Double
        Get
            Return _e
        End Get
        Set
            _e = Value
        End Set
    End Property

    ''' <summary>
    ''' RAC Total Soil
    ''' </summary>
    ''' <returns></returns>
    <Category(CATSubstance)>
    <DisplayName(
    "RAC Total Soil")>
    <Description(
    "in mg/kg" & vbCrLf &
    "")>
    <DefaultValue(0)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property racTotalSoil As Double
        Get
            Return _racTotalSoil
        End Get
        Set
            _racTotalSoil = Value
        End Set
    End Property

    ''' <summary>
    ''' RAC Total Soil
    ''' </summary>
    ''' <returns></returns>
    <Category(CATSubstance)>
    <DisplayName(
    "RAC Pore Water")>
    <Description(
    "in mg/L" & vbCrLf &
    "")>
    <DefaultValue(0)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property racPoreWater As Double
        Get
            Return _racPoreWater
        End Get
        Set
            _racPoreWater = Value
        End Set
    End Property

End Class

#End Region

#Region "Application"

<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class persam_applicationScheme

    Public Sub New()

    End Sub

    Public Property applications As persam_application() = {}

    Public Property tcycle As Integer = 1

End Class

<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class persam_application

    Public Sub New()

    End Sub

    Public Sub New(growthstage As String, applnRate As Double, dayIndex As Integer)
        Me.growthStage = growthstage
        Me.applicationRate = applnRate
        Me.dayIndex = dayIndex
    End Sub

    <DisplayName("Rate in kg/ha")>
    <DefaultValue(Double.NaN)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property applicationRate As Double = Double.NaN

    <DisplayName("Days after 1st appln")>
    <RefreshProperties(RefreshProperties.All)>
    Public Property dayIndex As Integer = 0

    <DisplayName("Growth Stage")>
    <RefreshProperties(RefreshProperties.All)>
    Public Property growthStage As String = String.Empty

End Class

#End Region

#End Region

