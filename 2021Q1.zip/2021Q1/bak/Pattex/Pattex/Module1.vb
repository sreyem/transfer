﻿
Imports System.IO
Imports System.Text
Imports System.Text.RegularExpressions

Module Module1

    Sub Main()

        test()

        Dim testbin As New PAT

        'testbin.createDxCropPFile(resPath:="C:\_PROUTT\SP\RRP2000612\MACRO\Res")

        testbin.createPrecFileFromBin(MACRO_PbinFilePath:="C:\VS2020\MACROResources\ExeParFile554")


    End Sub

    Public Const PATrepairMasterPath As String = "C:\developer\DevID0002\2021Q1\PATex\PATex\pat"

    Public Sub test()


        Dim transferfile As New System.IO.FileInfo(
                            fileName:=Path.Combine(
                                    path1:=PATrepairMasterPath,
                                    path2:="inputpat.txt"))

        Dim PATexe As New PATExe.CPATExe(
            transferFile:=transferfile,
            rulesFile:=New System.IO.FileInfo(
                            fileName:=Path.Combine(
                                path1:=PATrepairMasterPath,
                                path2:="rules.txt")))

        Dim temp As String

        With PATexe

            .RunPAT()
            .LogPATRuns(filename:=Path.Combine(
                                path1:=PATrepairMasterPath,
                                path2:="pat.txt"))

            temp = .Log

        End With



        Dim Rainfall As New List(Of Single)
        Dim RainfallDates As New List(Of Date)



        Dim RainFilePath As String = Path.Combine(
                                path1:=PATrepairMasterPath,
                                path2:="R4NOIRR.MET")

        Dim met As String() = {}


        met = File.ReadAllLines(RainFilePath)


        For Each member As String In met

            Rainfall.Add(Single.Parse(member.Substring(13, 4)) * 10)
            RainfallDates.Add(New Date(year:=1900 + Integer.Parse(member.Substring(5, 2)),
                                   month:=Integer.Parse(member.Substring(1, 2)),
                                   day:=Integer.Parse(member.Substring(3, 2))))

        Next


        Dim PATrun As New PATCommon.CPATRun

        With PATrun

            .ID = 1
            .NoOfApplns = 3

            For counter As Integer = 0 To .NoOfApplns - 1
                .AppInterval(counter) = 7
            Next

            .ClimateFile = New FileInfo("C:\developer\DevID0002\2021Q1\bak\pat\inputpat_origineel.txt") 'RainFilePath)

            .Scenario = "R4"
            .Crop = "Maize"
            .Season = "1st"

            .PATStartDate = New Date(year:=1978, month:=5, day:=3)
            .PATEndDate = .PATStartDate.AddDays(27)

            .PATCalcLog = Path.Combine(PATrepairMasterPath, "PATtest.csv")

            .Rainfall = Rainfall.ToArray
            .RainfallDates = RainfallDates

        End With

        Dim PATCalc As New PATCalc.CPATCalculation(PATRun:=PATrun,
                                                  PATRule:=New PATCommon.CPATRule)



        PATCalc.SetAppDays()

        Dim fff As String

        fff = PATrun.SettingsToLog()

        File.WriteAllText(
            path:=Path.Combine(Environment.CurrentDirectory, "PATCalc.log"),
            contents:=fff)
        File.WriteAllText(
            path:=Path.Combine(Environment.CurrentDirectory, "PATCalc2.log"),
            contents:=PATCalc.Log)
        File.WriteAllLines("C:\VS2020\Q2\pat\inputpat.txt", {PATrun.ToString})

        Process.Start(Path.Combine(Environment.CurrentDirectory, "PATCalc2.log"))

    End Sub



End Module

Public Class PAT


    <DebuggerStepThrough>
    Public Class Column

        Public ReadOnly Index As Integer
        Public ReadOnly Name As String
        Public ReadOnly Label As String

        Public Sub New(ByVal index As Integer, ByVal name As String, ByVal label As String)
            Me.Index = index
            Me.Name = name
            Me.Label = label
        End Sub
    End Class

    <DebuggerStepThrough>
    Public Class cRow

        Public myDate As DateTime
        Public Values As Single()

        Default Public ReadOnly Property Item(ByVal i As Integer) As Single
            Get
                Return Values(i)
            End Get
        End Property
    End Class

    Public cols As List(Of Column) = New List(Of Column)()
    Public rows As List(Of cRow) = New List(Of cRow)()

    Public Sub createDxCropPFile(resPath As String)


        Dim resFiles As String() = {}
        Dim resFile As String() = {}
        Dim temp As String()
        Dim out As New List(Of String)

        resFiles = Directory.GetFiles(path:=resPath, searchPattern:="*_par*.par", searchOption:=SearchOption.TopDirectoryOnly)

        resFiles = Filter(Source:=resFiles, Match:="_2nd", Include:=False, Compare:=CompareMethod.Text)

        For Each member As String In resFiles

            resFile = File.ReadAllLines(member)
            temp = resFile(1).Split(separator:={" "c}, options:=StringSplitOptions.RemoveEmptyEntries)
            out.Add(Chr(34) & temp(1) & "," & temp(2) & "," & temp.Last & Chr(34) & ",")

        Next


        File.WriteAllLines(path:=Path.Combine(Environment.CurrentDirectory, "DxCropPFile.csv"), out)

    End Sub

    Public Sub createPrecFileFromBin(MACRO_PbinFilePath As String)


        Dim fileList As String() = {}
        Dim temp As String() = {}
        Const delimiter As String = ","

        Dim precCSV As String() = {}

        fileList =
            Directory.GetFiles(
            path:=MACRO_PbinFilePath,
            searchPattern:="*_p.bin",
            searchOption:=SearchOption.TopDirectoryOnly)

        For memberCounter As Integer = 0 To fileList.Count - 1

            temp = readBin(fileList(memberCounter))
            If memberCounter = 0 Then
                ReDim precCSV(temp.Count - 1)
            End If

            For entrycounter As Integer = 0 To temp.Count - 1

                If entrycounter < 2 AndAlso memberCounter = 0 Then
                    precCSV(entrycounter) = "*"
                End If

                precCSV(entrycounter) &= temp(entrycounter)

                If memberCounter < fileList.Count - 1 Then
                    precCSV(entrycounter) &= delimiter
                End If

            Next

        Next

        File.WriteAllLines(path:=Path.Combine(path1:=Environment.CurrentDirectory, path2:="prec.csv"), contents:=precCSV)

    End Sub


    Public Function readBin(
                        binFileName As String,
                        Optional parFileName As String = Nothing,
                        Optional header As String() = Nothing,
                        Optional m2tFileName As String = Nothing) As String()

#Region "        Definitions reading stream"

        Dim inputStream As Stream = Nothing
        Dim binReader As BinaryReader = Nothing
        Dim recordNo As Integer
        Dim recordLength As Integer
        Dim varNo As Integer
        Dim hdrPos As Integer

        Dim entry As String
        Dim label As String
        Dim name As String
        Dim m As Match

        Dim row As cRow
        Dim julDate As Integer

        Dim temp As New List(Of String)

        cols.Clear()
        rows.Clear()

#End Region

        'open stream
        Try

            inputStream =
                       File.Open(
                           path:=binFileName,
                           mode:=FileMode.Open,
                           access:=FileAccess.Read,
                           share:=FileShare.Read)

        Catch ex As Exception
            Return {""}
        End Try

        'create reader
        Try

            binReader =
                    New BinaryReader(
                        input:=inputStream,
                        encoding:=Encoding.ASCII,
                        leaveOpen:=False)

        Catch ex As Exception
            Return {""}
        End Try

        'init
        Try

            recordNo = binReader.ReadInt32()
            recordLength = binReader.ReadInt32()

            varNo = recordLength / 4
            hdrPos = (recordNo + 1) * recordLength

            inputStream.Seek(hdrPos, SeekOrigin.Begin)
            cols.Add(New Column(0, "Date", "Date"))

        Catch ex As Exception

            Return {""}

        End Try

        'get columns and their header
        Try

            For i As Integer = 1 To varNo - 1

                entry = New String(binReader.ReadChars(60))
                label = entry.Substring(0, 52).Trim()
                name = label.Split(New String() {" "}, StringSplitOptions.RemoveEmptyEntries).First()
                m = Regex.Match(label, "^(\S+(\s\S+)*\S*)")

                If m.Success Then
                    name = m.Groups(1).Value.Trim()
                End If

                cols.Add(New Column(i - 1, name, label))

            Next

        Catch ex As Exception
            Return {""}
        End Try

        temp.Add(Path.GetFileNameWithoutExtension(binFileName))


        'get rows
        Try

            inputStream.Seek(recordLength, SeekOrigin.Begin)

            For i As Integer = 1 To recordNo

                row = New cRow()
                julDate = binReader.ReadInt32()

                row.myDate = New DateTime(1, 1, 1, 0, 0, 0).AddMinutes(julDate - 2 * 24 * 60)
                row.Values = New Single(cols.Count - 1 - 1) {}

                For j As Integer = 1 To varNo - 1
                    row.Values(j - 1) = binReader.ReadSingle()
                Next

                rows.Add(row)

                If i = 1 Then
                    temp.Add(row.myDate.Year.ToString)
                End If

                temp.Add(row.Values.First.ToString)

            Next

        Catch ex As Exception
            Return {""}
        End Try

        'closing 
        Try

            With binReader
                .Close()
                .Dispose()
            End With

        Catch ex As Exception

        End Try

        Return temp.ToArray

    End Function


End Class
