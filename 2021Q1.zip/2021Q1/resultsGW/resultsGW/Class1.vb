﻿

Imports essentials
Imports DBs.FOCUSGWdb

Imports System.ComponentModel
Imports System.Xml.Serialization
Imports System.Web.Script.Serialization
Imports System.Text
Imports System.IO
Imports System.Drawing.Design
Imports System.Windows.Forms

<TypeConverter(GetType(propGridConverter))>
<DefaultProperty("")>
<Serializable>
Public Class espGW


    Public Sub New()

    End Sub

    Public Property groups As group() = {}

#Region "    Model versions"

    Public Shared _PELMOVersion As ePELMOVersion = ePELMOVersion.not_dev
    Public Shared _PEARLVersion As ePEARLVersion = ePEARLVersion.not_dev
    Public Shared _MACROVersion As eMACROVersion = eMACROVersion.not_dev

    <Browsable(True)>
    <[ReadOnly](True)>
    <Category()>
    <DisplayName(
        "PELMO Version")>
    <Description(
        "5.5.3 or 6.6.4" & vbCrLf &
        "")>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    <DefaultValue(CInt(ePELMOVersion.not_dev))>
    Public Property PELMOVersion As ePELMOVersion
        Get
            Return _PELMOVersion
        End Get
        Set
            _PELMOVersion = Value
        End Set
    End Property

    <Browsable(True)>
    <[ReadOnly](True)>
    <Category()>
    <DisplayName(
        "PEARL Version")>
    <Description(
        "4.4.4 or 5.5.5" & vbCrLf &
        "")>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    <DefaultValue(CInt(ePEARLVersion.not_dev))>
    Public Property PEARLVersion As ePEARLVersion
        Get
            Return _PEARLVersion
        End Get
        Set
            _PEARLVersion = Value
        End Set
    End Property

    <Browsable(True)>
    <[ReadOnly](True)>
    <Category()>
    <DisplayName(
        "MACRO Version")>
    <Description(
        "5.5.4" & vbCrLf &
        "")>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    <DefaultValue(CInt(eMACROVersion.not_dev))>
    Public Property MACROVersion As eMACROVersion
        Get
            Return _MACROVersion
        End Get
        Set
            _MACROVersion = Value
        End Set
    End Property

#End Region

End Class

''' <summary>
''' Results for all GAPs, that are grouped by e.g. same use
''' </summary>
<TypeConverter(GetType(propGridConverter))>
<DefaultProperty("")>
<Serializable>
Public Class group

    Public Sub New()

    End Sub

    Public Property GAPs As GAP() = {}

End Class

''' <summary>
''' Results for all Scenarios for one GAP
''' </summary>
<TypeConverter(GetType(propGridConverter))>
<DefaultProperty("crop")>
<Serializable>
Public Class GAP

    Public Sub New()

    End Sub

    Public Property crop As eCropsGW = eCropsGW.notDef

    Public Property runs As run() = {}

End Class

''' <summary>
''' Results for all AIs for one Scenario
''' </summary>
<TypeConverter(GetType(propGridConverter))>
<DefaultProperty("scenario")>
<Serializable>
Public Class run

#Region "    privates"

    Private _ai As New ai
    Private _scenario As eScenariosGW = eScenariosGW.not_def
    Private _filePathPEARLsum As String = String.Empty

#End Region

    Public Sub New()

    End Sub

    Public Sub New(PEARLsumFilePath As String)

        Me.ai = parsePEARLsumFile(PEARLsumFilePath)

    End Sub


    Public Property filePathPEARLsum As String
        Get
            Return _filePathPEARLsum
        End Get
        Set
            _filePathPEARLsum = Value
            Me.ai = parsePEARLsumFile(_filePathPEARLsum)
        End Set
    End Property



#Region "    parse PEARL sum file"

    Public Const searchPEARLScenario As String = "* Location"
    Public Const searchPEARLCompoundPercentiles As String = "* Result_"
    Public Const searchPEARLModelVersion As String = "PEARL was called from"
    Public Const minSumFileLength As Integer = 20000


    Private PEARLsumFile As String()

    Public Function parsePEARLsumFile(
                                PEARLsumFilePath As String) As ai

        Dim ai As New ai
        Dim PEARLsumFile As String()
        Dim compoundNames As String() = {}

        PEARLsumFile =
            readPEARLsumFile(
                PEARLsumFilePath:=PEARLsumFilePath)

        Try

            getPEARLVersion(PEARLsumFile)

            getPEARLScenario(PEARLsumFile)

        Catch ex As Exception

            Throw New ArgumentException(
                message:=
                    "PEARL sum file doesn't fit" & vbCrLf &
                    Join(parseExceptionMsg(ex), vbCrLf),
                innerException:=ex,
                paramName:=PEARLsumFilePath)

        End Try

        compoundnames = getCompoundNames(PEARLsumFile)





        ai = getPEARL_ai(
            PEARLsumFile:=PEARLsumFile)

        Return ai

    End Function

    <DebuggerStepThrough>
    Private Function readPEARLsumFile(PEARLsumFilePath As String) As String()

        Dim testPEARLsumFile As String()
        Dim PEARLsumFile As FileInfo

        Try

            PEARLsumFile = New _
                FileInfo(fileName:=PEARLsumFilePath)

            testPEARLsumFile =
                    File.ReadAllLines(
                        path:=PEARLsumFile.FullName)

        Catch ex As Exception

            Throw New IOException(
                    message:=
                            "Error reading PEARL sum file " &
                            PEARLsumFilePath & vbCrLf &
                            ex.Message,
                    innerException:=ex)

        End Try

        If PEARLsumFile.Length < minSumFileLength Then

            Throw New IOException(
                message:=
                "PEARL sum file corrupt" & vbCrLf &
                "Size : " & PEARLsumFile.Length / 1000 & "kb")

        End If

        Return testPEARLsumFile

    End Function

    <DebuggerStepThrough>
    Private Sub getPEARLVersion(PEARLsumFile As String(),
                                Optional ByRef oldVersion As ePEARLVersion = ePEARLVersion.not_dev)

        Dim index As Integer = -1
        Dim temp As String = String.Empty

        '* PEARL was called from      : FOCUSPEARL,version 4.4.4
        index =
            Array.FindIndex(
            array:=PEARLsumFile,
            match:=Function(x) _
                        x.Contains(searchPEARLModelVersion))

        If index = -1 Then
            Throw New ArgumentException(
                    message:="Can't find '" & searchPEARLModelVersion & "'")
        End If

        For PEARLVersion As ePEARLVersion = ePEARLVersion.PEARL444 To ePEARLVersion.PEARL555

            temp =
            enumConverter(Of ePEARLVersion).getEnumDescription(
                                                EnumConstant:=PEARLVersion)

            If PEARLsumFile(index).Contains(temp) Then

                Select Case oldVersion

                    Case ePEARLVersion.not_dev
                        oldVersion = PEARLVersion

                    Case oldVersion <> PEARLVersion
                        Throw New ArgumentException(
                    message:=
                    "Different PEARL version" & vbCrLf &
                    "Old :" & oldVersion.ToString & vbCrLf &
                    "New :" & PEARLVersion.ToString,
                    paramName:=searchPEARLModelVersion)

                End Select

            End If

        Next

        If oldVersion = ePEARLVersion.not_dev Then
            Throw New ArgumentException(
                message:="Can't get PEARL version",
                paramName:=searchPEARLModelVersion)
        End If

    End Sub

    <DebuggerStepThrough>
    Private Function getPEARLScenario(
                          PEARLsumFile As String()) As eScenariosGW

        Dim index As Integer = -1

        '* Location           : PIACENZA
        index =
                Array.FindIndex(
                array:=PEARLsumFile,
                match:=Function(x) _
                            x.StartsWith(searchPEARLScenario))

        If index = -1 Then
            Throw New ArgumentException(
                    message:="Can't find scenario",
                    paramName:=searchPEARLScenario)
        End If

        For scenarioCounter As eScenariosGW = eScenariosGW.Chateaudun To eScenariosGW.Thiva

            If PEARLsumFile(index).ToLower.Contains(
                scenarioCounter.ToString.ToLower.Substring(0, 4)) Then
                Return scenarioCounter
            End If

        Next

        Throw New ArgumentException(
            message:="Can't get scenario",
            paramName:=searchPEARLScenario)

    End Function

    Private Function getPEARL_ai(PEARLsumFile As String()) As ai


        Dim compoundNames As String()
        Dim ai As New ai


        compoundNames = getCompoundNames(PEARLsumFile)

        With ai

            .code = compoundNames.First
            .compounds = getPEARLCompounds(
                compoundNames:=compoundNames,
                    PEARLsumFile:=PEARLsumFile)

        End With

        Return ai

    End Function

    <DebuggerStepThrough>
    Public Function getCompoundNames(PEARLsumFile As String()) As String()

        Dim targetCompoundResultRows As String() = {}
        Dim compoundNames As New List(Of String)
        Dim tempList As New List(Of String)
        Dim tempRow As String

        Try

            targetCompoundResultRows =
                        Filter(
                            Source:=PEARLsumFile,
                            Match:=searchPEARLCompoundPercentiles,
                            Include:=True,
                            Compare:=CompareMethod.Text)

            targetCompoundResultRows =
                    Filter(
                    Source:=targetCompoundResultRows,
                    Match:="* Result_text",
                    Include:=False,
                    Compare:=CompareMethod.Text)

            If targetCompoundResultRows.Count = 0 Then
                Throw New ArgumentException(
                    message:="No results found",
                    paramName:=searchPEARLCompoundPercentiles)
            End If

        Catch ex As Exception
            Throw New ArgumentException(
                message:="Can't get compound names",
                innerException:=ex)
        End Try

        '* Result_FPF              0.203484
        '* Result_CNA_02           0.004401
        '* Result_DFA              0.580208
        For counter As Integer = 0 To targetCompoundResultRows.Count - 1

            With tempList

                .Clear()

                .AddRange(
                    targetCompoundResultRows(counter).Split(
                                separator:={" "c},
                                options:=StringSplitOptions.RemoveEmptyEntries))

                tempRow = tempList(1)

                .Clear()
                .AddRange(tempRow.Split("_"))
                .RemoveAt(0)

            End With

            tempRow = Join(tempList.ToArray, "_")

            compoundNames.Add(
                    targetCompoundResultRows(counter).Split("_").Last.Split().First)

        Next

        Return compoundNames.ToArray

    End Function

    Private Function getPEARLCompounds(
                        compoundNames As String(),
                        PEARLsumFile As String()) As compound()

        Dim rows As String()

        Dim results20Years As New List(Of Double)

        Dim compounds As New List(Of compound)
        Dim compound As compound

        For counter As Integer = 0 To compoundNames.Count - 1

            compound = New compound

            With compound

                .code = compoundNames(counter)

                Try

                    rows =
                        Filter(
                            Source:=PEARLsumFile,
                            Match:="target_" & compoundNames(counter),
                            Include:=True,
                            Compare:=CompareMethod.Text)

                    results20Years.Clear()

                    For Each member As String In rows
                        results20Years.Add(Double.Parse(member.Split.Last))
                    Next

                    ._PECs.Add(New PECs(data:=results20Years.ToArray))
                    ._PECs(._PECs.Count - 1).gwModel = eGWModels.PEARL
                    .endPoints.PEARL = ._PECs(._PECs.Count - 1).stdPECgwPercentile

                    rows =
                        Filter(
                            Source:=PEARLsumFile,
                            Match:=searchPEARLCompoundPercentiles & compoundNames(counter))

                Catch ex As Exception
                    'ToDo
                End Try

            End With

            compounds.Add(compound)

        Next

        Return compounds.ToArray

    End Function

#End Region

#Region "    parse psm/plm files"

    Public Const searchPELMOresult As String = "in the percolate at 1 m soil depth"
    Public Const searchParentPELMO As String = "ACTIVE SUBSTANCE"

    Private psmFile As String()
    Private plmFile As String()
    Private PELMOcompoundNames As String()
    Private PELMOPositions As PECs.ePelmoPosition() = {}

    Public Function parsePELMOfiles(psmFilePath As String, plmFilePath As String) As ai

        Dim AI As New ai
        Dim psmFile As String()
        Dim plmFile As String()

        readPELMOfiles(psmFilePath:=psmFilePath, plmFilePath:=plmFilePath)

        getPELMOVersion()

        getPELMOScenario()

        getPELMOCompoundNames()

        getPELMO_AI()

        Return AI

    End Function

    Private Sub readPELMOfiles(psmFilePath As String, plmFilePath As String)

        Try
            psmFile = File.ReadAllLines(path:=psmFilePath)
            plmFile = File.ReadAllLines(path:=plmFilePath)
        Catch ex As Exception

        End Try

    End Sub

    Public Sub getPELMOVersion()

        Dim temp As String
        Dim testPELMOVersion As ePELMOVersion = ePELMOVersion.not_dev

        For PELMOVersion As ePELMOVersion = ePELMOVersion.PELMO553 To ePELMOVersion.PELMO664

            '*** FOCUSPELMO  5. 5. 3 *** (PELMO 4.01  )
            temp = enumConverter(Of ePELMOVersion).getEnumDescription(EnumConstant:=PELMOVersion)
            temp = Replace(Expression:=temp, Find:=".", Replacement:=". ", Compare:=CompareMethod.Text)

            If plmFile.First.Contains(temp) Then
                testPELMOVersion = PELMOVersion
            End If

        Next

        If testPELMOVersion = ePELMOVersion.not_dev Then
            Throw New ArgumentException(
                message:="Can't get PELMO version")
        End If

        Select Case espGW._PELMOVersion

            Case ePELMOVersion.not_dev
                espGW._PELMOVersion = testPELMOVersion

            Case espGW._PELMOVersion <> testPELMOVersion
                Throw New ArgumentException(
                    message:=
                    "Different PEARL version" & vbCrLf &
                    "Old :" & espGW._PELMOVersion.ToString & vbCrLf &
                    "New :" & testPELMOVersion.ToString)

        End Select

    End Sub

    Public Sub getPELMOScenario()

        Dim targetRow As String
        Dim scenario As eScenariosGW = eScenariosGW.not_def

        targetRow = plmFile(1)
        targetRow =
                Replace(
                Expression:=targetRow,
                Find:="â",
                Replacement:="a",
                Compare:=CompareMethod.Text)

        For scenarioCounter As eScenariosGW = eScenariosGW.Chateaudun To eScenariosGW.Thiva

            If targetRow.ToLower.Contains(scenarioCounter.ToString.ToLower.Substring(0, 4)) Then
                scenario = scenarioCounter
                Exit For

            End If

        Next

        If Me.scenario <> eScenariosGW.not_def Then

            If Me.scenario <> scenario Then
                Throw New Exception(message:="Different scenarios for different models?")
            End If

        Else

            Me.scenario = scenario

        End If


    End Sub

    Public Const searchPELMOCompoundNames As String = "<END COMMENT>"
    Public Const searchPELMOStartYearResults As String = "  1  "
    Public Const searchPELMOEndYearResults As String = "--------------------"

    Private Sub getPELMOCompoundNames()

        Dim index As Integer = 0
        Dim names As New List(Of String)
        Dim pos As New List(Of PECs.ePelmoPosition)
        Dim temp As String()
        Dim comment As String

        Do

            index =
                    Array.FindIndex(
                    startIndex:=index,
                    array:=psmFile,
                    match:=Function(x) x = searchPELMOCompoundNames)

            If index = -1 Then Exit Do

            index -= 1

            temp =
                    psmFile(index).Split(
                    separator:={" "c},
                    options:=StringSplitOptions.RemoveEmptyEntries)

            If psmFile(index).StartsWith("METABOLITE") Then

                names.Add(temp.Last)
                pos.Add(
                        [Enum].Parse(
                            enumType:=GetType(PECs.ePelmoPosition),
                            value:=Trim(temp(1)), ignoreCase:=True))
            Else
                names.Add(Trim(psmFile(index).Split("<").Last.Split(">").First))
                comment = Trim(temp.First)
                pos.Add(PECs.ePelmoPosition.a0)
            End If

            index += 3
        Loop

        PELMOcompoundNames = names.ToArray
        PELMOPositions = pos.ToArray

    End Sub


    Private Sub getPELMO_AI()

        Dim newPLM As New List(Of String)
        Dim rowCounter As Integer = 0
        Dim compoundCounter As Integer = 0
        Dim compoundNamePLM As String
        Dim resultList As New List(Of Double)

        Dim compounds As New List(Of compound)
        Dim details As New List(Of PECs)

        Dim AI As New ai


        With AI

#Region "    parent"

            'read until parent result header ... in the percolate at 1 m soil depth
            Do

                newPLM.Add(plmFile(rowCounter))
                rowCounter += 1

            Loop Until plmFile(rowCounter).Contains(searchPELMOresult)

            'get name and correct row if necessary
            If Not plmFile(rowCounter).Contains(searchParentPELMO) Then
                plmFile(rowCounter) = vbTab &
                        "Results for ACTIVE SUBSTANCE (" &
                        PELMOcompoundNames.First & ") " & searchPELMOresult
            Else

                compoundNamePLM =
                        Trim(plmFile(rowCounter).Split("(").Last.Split(")").First)

                If compoundNamePLM <> PELMOcompoundNames.First Then
                    Throw New _
                            ArgumentException(
                                message:="Parent name doesn't fit  plm <-> psm file!")

                End If

            End If


            'read until 1st year of parent result
            Do

                newPLM.Add(plmFile(rowCounter))
                rowCounter += 1

            Loop Until plmFile(rowCounter).Contains(searchPELMOStartYearResults)

            'rowCounter += 1

            'get 20 year parent result
            Do
                resultList.Add(Double.Parse(s:=plmFile(rowCounter).Split(vbTab).Last))

                newPLM.Add(plmFile(rowCounter))
                rowCounter += 1

            Loop Until plmFile(rowCounter).Contains(searchPELMOEndYearResults)

            details.Add(New PECs)

            With details(details.Count - 1)

                .data = resultList.ToArray
                .gwModel = eGWModels.PELMO
                .pelmoPosition = PELMOPositions.First

            End With


            compounds.Add(New compound)

            With compounds(compounds.Count - 1)
                .code = PELMOcompoundNames.First
                .PECs = details.ToArray
            End With

            AI.code = PELMOcompoundNames.First
            AI.compounds = compounds.ToArray


#End Region

        End With

    End Sub



#End Region

    Public Const CATMetaData As String = "Meta Data"
#Region "    Meta Data Name, Scenario and Versions"

    <Category(CATMetaData)>
    <Browsable(False)>
    <XmlIgnore> <ScriptIgnore>
    Public Shadows Property name As String
        Get
            If Me.scenario = eScenariosGW.not_def Then
                Return enumConverter(Of Type).not_defined
            Else

                Return Me.scenario.ToString
            End If
        End Get
        Set

        End Set
    End Property

    ''' <summary>
    ''' FOCUSgw scenario like CHAT or HAMB
    ''' </summary>
    ''' <returns></returns>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATMetaData)>
    <DisplayName(
        "Scenario")>
    <Description(
        "FOCUSgw scenario like " & vbCrLf &
        "Hamburg or Porto")>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    <DefaultValue(CInt(eScenariosGW.not_def))>
    Public Property scenario As eScenariosGW
        Get
            Return _scenario
        End Get
        Set
            _scenario = Value
        End Set
    End Property


#End Region


    Public Const CATAI As String = "Active Ingredients"

    ''' <summary>
    ''' Short (5 chars) code of the compound/AI
    ''' no numbers at the beginning, no special characters
    ''' </summary>
    ''' <returns></returns>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATAI)>
    <DisplayName(
        "AI")>
    <Description(
    "Active Ingredient" & vbCrLf &
    "like TSF, FLU, IMD etc. ")>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    <DefaultValue(CType(Nothing, Object))>
    Public Property ai As ai
        Get
            Return _ai
        End Get
        Set
            _ai = Value
        End Set
    End Property

End Class


''' <summary>
''' Complete results for one Active Ingredient
''' </summary>
<TypeConverter(GetType(propGridConverter))>
<DefaultProperty("code")>
<Serializable>
Public Class ai

    <XmlIgnore> <ScriptIgnore>
    Public _compounds As New List(Of compound)
    Private _code As String = String.Empty

    Public Sub New()

    End Sub

    <Browsable(False)>
    <XmlIgnore> <ScriptIgnore>
    Public Shadows Property name As String
        Get

            Dim out As New StringBuilder

            If Not IsNothing(compounds) AndAlso
                    compounds.Count > 0 Then

                For counter As Integer = 0 To compounds.Count - 1
                    out.Append(compounds(counter).code & " ")
                    If counter < compounds.Count - 1 Then out.Append(vbCrLf)
                Next

            Else
                Return enumConverter(Of Type).not_defined
            End If

            Return out.ToString

        End Get
        Set

        End Set
    End Property

    ''' <summary>
    ''' Short (5 chars) code of the compound/AI
    ''' no numbers at the beginning, no special characters
    ''' </summary>
    ''' <returns></returns>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category("")>
    <DisplayName(
        "Code")>
    <Description(
        "Short (5 chars) code of the compound/AI" & vbCrLf &
        "no numbers at the beginning, no special characters!!!")>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    <DefaultValue(CType(Nothing, Object))>
    Public Property code As String
        Get
            Return _code
        End Get
        Set
            _code =
                    parseSubstanceCode(
                            code:=Value,
                            maxLength:=5)
        End Set
    End Property

    ''' <summary>
    ''' compounds
    ''' Parent and all metabolites of this Active Ingredient
    ''' code = Parent code (compounds[0])
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category("")>
    <DisplayName(
        "Compounds")>
    <Description(
        "Parent and metabolites of this Active Ingredient" & vbCrLf &
        "code = Parent code (compounds[0])")>
    <RefreshProperties(RefreshProperties.All)>
    <DefaultValue(CType(Nothing, Object))>
    Public Property compounds As compound()
        Get
            Return _compounds.ToArray
        End Get
        Set

            _compounds.Clear()
            _compounds.AddRange(Value)

            If Not IsNothing(_compounds) AndAlso
                                _compounds.Count > 0 Then
                compounds(0).code = _code
            End If

        End Set
    End Property

End Class

''' <summary>
''' compound
''' Parent or metabolite of an Active Ingredient
''' </summary>
<TypeConverter(GetType(propGridConverter))>
<DefaultProperty("code")>
<Serializable>
Public Class compound

    Public Sub New()

    End Sub

    <Browsable(False)>
    Public Shadows Property name As String
        Get
            Return code.PadRight(6)
        End Get
        Set

        End Set
    End Property

    Private _code As String = String.Empty
    Private _endPoints As New endPoints

    <XmlIgnore> <ScriptIgnore>
    Public _PECs As New List(Of PECs)

    ''' <summary>
    ''' Short (5 chars) code of the compound/AI
    ''' no numbers at the beginning, no special characters
    ''' </summary>
    ''' <returns></returns>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category("")>
    <DisplayName(
        "Code")>
    <Description(
        "Short (5 chars) code of the compound/AI" & vbCrLf &
        "no numbers at the beginning, no special characters!!!")>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    <DefaultValue(CType(Nothing, Object))>
    Public Property code As String
        Get
            Return _code
        End Get
        Set

            _code =
              parseSubstanceCode(
                        code:=Value,
                        maxLength:=5)

        End Set
    End Property

    ''' <summary>
    ''' Endpoints for all three FOCUSgw models
    ''' mostly 80th percentile in µg/L
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category("")>
    <DisplayName(
        "PECgw Endpoints")>
    <Description(
        "Endpoints for all three FOCUSgw models" & vbCrLf &
        "80th percentile in µg/L")>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    Public Property endPoints As endPoints
        Get
            Return _endPoints
        End Get
        Set
            _endPoints = Value
        End Set
    End Property

    ''' <summary>
    ''' FOCUS GW result data for 20 years
    ''' for all models
    ''' incl. statistic
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category("")>
    <DisplayName(
        "PECgw")>
    <Description(
        "FOCUSgw results incl. percentile, data for 20 years" & vbCrLf &
        "statistic, DFOP and pH dependency")>
    <RefreshProperties(RefreshProperties.All)>
    Public Property PECs As PECs()
        Get
            Return _PECs.ToArray
        End Get
        Set
            _PECs.Clear()
            _PECs.AddRange(Value)
        End Set
    End Property

End Class

''' <summary>
''' endPoint
''' Endpoints for all three FOCUSgw models
''' mostly 80th percentile in µg/L
''' </summary>
<TypeConverter(GetType(propGridConverter))>
<DefaultProperty("PEARL")>
<Serializable>
Public Class endPoints

    Public Sub New()

    End Sub

    <Browsable(False)>
    <XmlIgnore> <ScriptIgnore>
    Public Shadows Property name As String
        Get

            Dim temp As New StringBuilder

            temp.Clear()
            temp.AppendLine("PEARL : " &
                                dblConv.conv2String(value:=PEARL, unit:=" µg/L  "))
            temp.AppendLine("PELMO : " &
                                dblConv.conv2String(value:=PELMO, unit:=" µg/L  "))
            temp.AppendLine("MACRO : " &
                                dblConv.conv2String(value:=MACRO, unit:=" µg/L"))

            Return temp.ToString

        End Get
        Set(value As String)

        End Set
    End Property

    Public Const CAT As String = "Endpoints in µg/L"

    Private _PEARL As Double = Double.NaN
    Private _PELMO As Double = Double.NaN
    Private _MACRO As Double = Double.NaN

    ''' <summary>
    ''' Max result out of PEARL, PELMO and MACRO
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CAT)>
    <DisplayName(
        "Max Result")>
    <Description(
        "Max result out of PEARL, PELMO and MACRO")>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("minValue = '0.0001'")>
    <DefaultValue(Double.NaN)>
    Public ReadOnly Property max As Double
        Get

            Dim temp As Double() = {PEARL, PELMO, MACRO}

            Return temp.Max

        End Get
    End Property

    ''' <summary>
    ''' PEARL
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CAT)>
    <DisplayName(
        "PEARL")>
    <Description("")>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("minValue = '0.0001'")>
    <DefaultValue(Double.NaN)>
    Public Property PEARL As Double
        Get
            Return _PEARL
        End Get
        Set
            _PEARL = Value
        End Set
    End Property

    ''' <summary>
    ''' PELMO
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CAT)>
    <DisplayName(
        "PELMO")>
    <Description("")>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("minValue = '0.0001'")>
    <DefaultValue(Double.NaN)>
    Public Property PELMO As Double
        Get
            Return _PELMO
        End Get
        Set
            _PELMO = Value
        End Set
    End Property

    ''' <summary>
    ''' MACRO
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CAT)>
    <DisplayName(
        "MACRO")>
    <Description("")>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("minValue = '0.0001'")>
    <DefaultValue(Double.NaN)>
    Public Property MACRO As Double
        Get
            Return _MACRO
        End Get
        Set
            _MACRO = Value
        End Set
    End Property

End Class

''' <summary>
''' statisticPEC
''' FOCUS GW result data for 20 years
''' incl. statistic, gw model and PELMO position
''' </summary>
<DefaultProperty("gwModel")>
<Serializable>
Public Class PECs

    Inherits statistic

    Public Sub New()

    End Sub

    Public Sub New(data As Double())
        Me.data = data
    End Sub

    Public Const CATSummary As String = "00  Summary"

    ''' <summary>
    ''' Model := endPoint in µg/L min 0.00001
    ''' </summary>
    ''' <returns></returns>
    <Category(CATSummary)>
    <Browsable(False)>
    <XmlIgnore> <ScriptIgnore>
    Public Shadows Property name As String
        Get

            If gwModel = eGWModels.not_def Then

                Return " - "

            Else

                Return gwModel.ToString() & " := " &
                     dblConv.conv2String(Me.stdPECgwPercentile, minValue:=0.0001, unit:=" µg/L ") &
              IIf(
                    Expression:=Double.IsNaN(Me.relativeVariance),
                    TruePart:="",
                    FalsePart:=Me.relativeVariance.ToString("0.00") & "% rel. variance")

            End If

        End Get
        Set(value As String)

        End Set
    End Property

    ''' <summary>
    ''' FOCUS GW Model
    ''' PEARL, PELMO or MACRO
    ''' </summary>
    ''' <returns></returns>
    <Category(CATSummary)>
    <DisplayName(
    "FOCUS GW Model")>
    <Description(
    "PEARL, PELMO or MACRO")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(CInt(eGWModels.not_def))>
    <RefreshProperties(RefreshProperties.All)>
    Public Property gwModel As eGWModels = eGWModels.not_def

    <TypeConverter(GetType(enumConverter(Of ePelmoPosition)))>
    Public Enum ePelmoPosition
        a0
        a1
        a2
        a3
        a4
        b1
        b2
        b3
        b4
        c1
        c2
        c3
        c4
        d1
        d2
        d3
        d4
        <Description(enumConverter(Of Type).not_defined)>
        not_def = -1

    End Enum

    <Category(CATSummary)>
    <DisplayName(
    "PELMO Position")>
    <Description(
    "A0 = Parent" & vbCrLf &
    "A1, A2, A3, A4, B1 ... D3, D4")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <DefaultValue(CInt(ePelmoPosition.not_def))>
    Public Property pelmoPosition As ePelmoPosition = ePelmoPosition.not_def


    <TypeConverter(GetType(enumConverter(Of ek12)))>
    Public Enum ek12

        k1
        k2

        <Description(enumConverter(Of Type).not_defined)>
        not_def = -1

    End Enum

    <Category(CATSummary)>
    <DisplayName(
    "DFOP")>
    <Description(
    "DFOP with rate constant" & vbCrLf &
    "k1 or k2")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <DefaultValue(CInt(ek12.not_def))>
    Public Property k12 As ek12 = ek12.not_def


    <TypeConverter(GetType(enumConverter(Of eAcidBase)))>
    Public Enum eAcidBase

        acid
        base

        <Description(enumConverter(Of Type).not_defined)>
        not_def = -1

    End Enum

    <Category(CATSummary)>
    <DisplayName(
    "pH")>
    <Description(
    "pH dependent values" & vbCrLf &
    "for acid or base situation")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <DefaultValue(CInt(eAcidBase.not_def))>
    Public Property acidBase As eAcidBase = eAcidBase.not_def


    ''' <summary>
    ''' Percentile of PEC values
    ''' Arithmetic mean of 16th and 17th value
    ''' </summary>
    ''' <returns></returns>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATWhisker)>
    <DisplayName(
    "PECgw Perc.")>
    <Description(
    "Percentile  of PEC values" & vbCrLf &
    "Arithmetic mean of 16th and 17th value")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public ReadOnly Property stdPECgwPercentile
        Get

            Dim percList As Double() =
                {
                    2.5,
                    7.5,
                    12.5,
                    17.5,
                    22.5,
                    27.5,
                    32.5,
                    37.5,
                    42.5,
                    47.5,
                    52.5,
                    57.5,
                    62.5,
                    67.5,
                    72.5,
                    77.5,
                    82.5,
                    87.5,
                    92.5,
                    97.5
                }

            If n = 20 Then

                perc = (percList(lowerPECgwItemPos - 1) + percList(upperPECgwItemPos - 1)) / 2

                Return (sortedData(lowerPECgwItemPos - 1) + sortedData(upperPECgwItemPos - 1)) / 2

            Else
                perc = Double.NaN
                Return Double.NaN
            End If
        End Get
    End Property


    ''' <summary>
    ''' Lower sorted order number for
    ''' arithmetic mean, std = 15 (80th perc.)
    ''' </summary>
    ''' <returns></returns>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATWhisker)>
    <DisplayName(
    "   lower ")>
    <Description(
    "Lower sorted order number for" & vbCrLf &
    "arithmetic mean, std = 16 (counting from 1, 80th perc.)")>
    <RefreshProperties(RefreshProperties.All)>
    <DefaultValue(16)>
    Public Property lowerPECgwItemPos As Integer = 16

    ''' <summary>
    ''' Upper sorted order number for
    ''' arithmetic mean, std = 16 (80th perc.)
    ''' </summary>
    ''' <returns></returns>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATWhisker)>
    <DisplayName(
    "   upper ")>
    <Description(
    "Upper sorted order number for" & vbCrLf &
    "arithmetic mean, std = 17 (counting from 1, 80th perc.)")>
    <RefreshProperties(RefreshProperties.All)>
    <DefaultValue(17)>
    Public Property upperPECgwItemPos As Integer = 17

    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATWhisker)>
    <DisplayName(
    "   perc.")>
    <Description(
    "Percentile of PEC values" & vbCrLf &
    "2.5% - 97.5%")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property perc As Double = Double.NaN



End Class

