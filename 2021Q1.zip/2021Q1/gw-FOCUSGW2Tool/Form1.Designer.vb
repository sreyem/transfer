﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnPEARL333 = New System.Windows.Forms.Button()
        Me.btnPELMO32 = New System.Windows.Forms.Button()
        Me.btnGetApp = New System.Windows.Forms.Button()
        Me.txtMasterPath = New System.Windows.Forms.TextBox()
        Me.lblMasterPath = New System.Windows.Forms.Label()
        Me.lbxApp = New System.Windows.Forms.ListBox()
        Me.lblPEARLPath = New System.Windows.Forms.Label()
        Me.txtPELMOPath = New System.Windows.Forms.TextBox()
        Me.lblPELMOPath = New System.Windows.Forms.Label()
        Me.txtPEARLTemplate = New System.Windows.Forms.TextBox()
        Me.txtPELMOTemplate = New System.Windows.Forms.TextBox()
        Me.lblPEARLTemplate = New System.Windows.Forms.Label()
        Me.lblPELMOTemplate = New System.Windows.Forms.Label()
        Me.btnStartPELMO = New System.Windows.Forms.Button()
        Me.btnEvaluatePELMO = New System.Windows.Forms.Button()
        Me.btnEvaluatePEARL = New System.Windows.Forms.Button()
        Me.btnSubstInfoPEARL = New System.Windows.Forms.Button()
        Me.btnSubstInfoPELMO = New System.Windows.Forms.Button()
        Me.btnSave2Config = New System.Windows.Forms.Button()
        Me.btnLoadFromConfig = New System.Windows.Forms.Button()
        Me.lsbLog = New System.Windows.Forms.ListBox()
        Me.ContextMenuStriplsblog = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.SaveLog = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBoxFOCUSExecPaths = New System.Windows.Forms.GroupBox()
        Me.cmbPEARLPath = New System.Windows.Forms.ComboBox()
        Me.GroupBoxCMPData = New System.Windows.Forms.GroupBox()
        Me.lblPelmoWarning = New System.Windows.Forms.Label()
        Me.lblMNumberPELMO = New System.Windows.Forms.Label()
        Me.lblMNumberPEARL = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripProgressBar = New System.Windows.Forms.ToolStripProgressBar()
        Me.ToolStripStatusLabel = New System.Windows.Forms.ToolStripStatusLabel()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.chkKeepPelmoData = New System.Windows.Forms.CheckBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.PELMO = New System.Windows.Forms.GroupBox()
        Me.rbPELMO664 = New System.Windows.Forms.RadioButton()
        Me.rbPELMO553 = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rbPEARL555 = New System.Windows.Forms.RadioButton()
        Me.rbPEARL444 = New System.Windows.Forms.RadioButton()
        Me.ContextMenuStriplsblog.SuspendLayout()
        Me.GroupBoxFOCUSExecPaths.SuspendLayout()
        Me.GroupBoxCMPData.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.PELMO.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnPEARL333
        '
        Me.btnPEARL333.Location = New System.Drawing.Point(1, 94)
        Me.btnPEARL333.Name = "btnPEARL333"
        Me.btnPEARL333.Size = New System.Drawing.Size(106, 34)
        Me.btnPEARL333.TabIndex = 4
        Me.btnPEARL333.Text = "PEARL"
        Me.btnPEARL333.UseVisualStyleBackColor = True
        '
        'btnPELMO32
        '
        Me.btnPELMO32.Location = New System.Drawing.Point(0, 94)
        Me.btnPELMO32.Name = "btnPELMO32"
        Me.btnPELMO32.Size = New System.Drawing.Size(106, 34)
        Me.btnPELMO32.TabIndex = 4
        Me.btnPELMO32.Text = "PELMO"
        Me.btnPELMO32.UseVisualStyleBackColor = True
        '
        'btnGetApp
        '
        Me.btnGetApp.Location = New System.Drawing.Point(137, 363)
        Me.btnGetApp.Name = "btnGetApp"
        Me.btnGetApp.Size = New System.Drawing.Size(106, 34)
        Me.btnGetApp.TabIndex = 4
        Me.btnGetApp.Text = "get *.app files"
        Me.btnGetApp.UseVisualStyleBackColor = True
        '
        'txtMasterPath
        '
        Me.txtMasterPath.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMasterPath.Location = New System.Drawing.Point(136, 56)
        Me.txtMasterPath.Name = "txtMasterPath"
        Me.txtMasterPath.Size = New System.Drawing.Size(547, 20)
        Me.txtMasterPath.TabIndex = 6
        Me.txtMasterPath.Text = "C:\Temp\FOCUSgwNEW\appPELMO664PEARL555"
        '
        'lblMasterPath
        '
        Me.lblMasterPath.AutoSize = True
        Me.lblMasterPath.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMasterPath.Location = New System.Drawing.Point(23, 59)
        Me.lblMasterPath.Name = "lblMasterPath"
        Me.lblMasterPath.Size = New System.Drawing.Size(75, 13)
        Me.lblMasterPath.TabIndex = 7
        Me.lblMasterPath.Text = "Master Path"
        '
        'lbxApp
        '
        Me.lbxApp.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbxApp.FormattingEnabled = True
        Me.lbxApp.Location = New System.Drawing.Point(266, 323)
        Me.lbxApp.Name = "lbxApp"
        Me.lbxApp.Size = New System.Drawing.Size(443, 121)
        Me.lbxApp.TabIndex = 8
        '
        'lblPEARLPath
        '
        Me.lblPEARLPath.AutoSize = True
        Me.lblPEARLPath.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPEARLPath.Location = New System.Drawing.Point(14, 21)
        Me.lblPEARLPath.Name = "lblPEARLPath"
        Me.lblPEARLPath.Size = New System.Drawing.Size(67, 13)
        Me.lblPEARLPath.TabIndex = 7
        Me.lblPEARLPath.Text = "PEARL Path"
        '
        'txtPELMOPath
        '
        Me.txtPELMOPath.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPELMOPath.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPELMOPath.Location = New System.Drawing.Point(121, 45)
        Me.txtPELMOPath.Name = "txtPELMOPath"
        Me.txtPELMOPath.Size = New System.Drawing.Size(547, 20)
        Me.txtPELMOPath.TabIndex = 6
        Me.txtPELMOPath.Text = "C:\Emod\PelmoDummy"
        '
        'lblPELMOPath
        '
        Me.lblPELMOPath.AutoSize = True
        Me.lblPELMOPath.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPELMOPath.Location = New System.Drawing.Point(14, 47)
        Me.lblPELMOPath.Name = "lblPELMOPath"
        Me.lblPELMOPath.Size = New System.Drawing.Size(69, 13)
        Me.lblPELMOPath.TabIndex = 7
        Me.lblPELMOPath.Text = "PELMO Path"
        '
        'txtPEARLTemplate
        '
        Me.txtPEARLTemplate.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPEARLTemplate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPEARLTemplate.Location = New System.Drawing.Point(194, 22)
        Me.txtPEARLTemplate.Name = "txtPEARLTemplate"
        Me.txtPEARLTemplate.Size = New System.Drawing.Size(473, 20)
        Me.txtPEARLTemplate.TabIndex = 6
        Me.txtPEARLTemplate.Text = "C:\Temp\FOCUSgwNEW\CompoundTemplates\GW\PTZ\PEARL555"
        Me.ToolTip1.SetToolTip(Me.txtPEARLTemplate, "incl ...\PEARL444")
        '
        'txtPELMOTemplate
        '
        Me.txtPELMOTemplate.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPELMOTemplate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPELMOTemplate.Location = New System.Drawing.Point(194, 66)
        Me.txtPELMOTemplate.Name = "txtPELMOTemplate"
        Me.txtPELMOTemplate.Size = New System.Drawing.Size(473, 20)
        Me.txtPELMOTemplate.TabIndex = 6
        '
        'lblPEARLTemplate
        '
        Me.lblPEARLTemplate.AutoSize = True
        Me.lblPEARLTemplate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPEARLTemplate.Location = New System.Drawing.Point(12, 25)
        Me.lblPEARLTemplate.Name = "lblPEARLTemplate"
        Me.lblPEARLTemplate.Size = New System.Drawing.Size(176, 13)
        Me.lblPEARLTemplate.TabIndex = 7
        Me.lblPEARLTemplate.Text = "PEARL cmp Path incl. ..\PEARLxxx"
        '
        'lblPELMOTemplate
        '
        Me.lblPELMOTemplate.AutoSize = True
        Me.lblPELMOTemplate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPELMOTemplate.Location = New System.Drawing.Point(12, 66)
        Me.lblPELMOTemplate.Name = "lblPELMOTemplate"
        Me.lblPELMOTemplate.Size = New System.Drawing.Size(179, 13)
        Me.lblPELMOTemplate.TabIndex = 7
        Me.lblPELMOTemplate.Text = "PELMO psm Path incl. ..\PELMOxxx"
        '
        'btnStartPELMO
        '
        Me.btnStartPELMO.Location = New System.Drawing.Point(0, 134)
        Me.btnStartPELMO.Name = "btnStartPELMO"
        Me.btnStartPELMO.Size = New System.Drawing.Size(106, 34)
        Me.btnStartPELMO.TabIndex = 4
        Me.btnStartPELMO.Text = "Start PELMO"
        Me.btnStartPELMO.UseVisualStyleBackColor = True
        '
        'btnEvaluatePELMO
        '
        Me.btnEvaluatePELMO.Location = New System.Drawing.Point(0, 174)
        Me.btnEvaluatePELMO.Name = "btnEvaluatePELMO"
        Me.btnEvaluatePELMO.Size = New System.Drawing.Size(106, 34)
        Me.btnEvaluatePELMO.TabIndex = 4
        Me.btnEvaluatePELMO.Text = "Evaluate PELMO"
        Me.btnEvaluatePELMO.UseVisualStyleBackColor = True
        '
        'btnEvaluatePEARL
        '
        Me.btnEvaluatePEARL.Location = New System.Drawing.Point(1, 174)
        Me.btnEvaluatePEARL.Name = "btnEvaluatePEARL"
        Me.btnEvaluatePEARL.Size = New System.Drawing.Size(106, 34)
        Me.btnEvaluatePEARL.TabIndex = 4
        Me.btnEvaluatePEARL.Text = "Evaluate PEARL"
        Me.btnEvaluatePEARL.UseVisualStyleBackColor = True
        '
        'btnSubstInfoPEARL
        '
        Me.btnSubstInfoPEARL.Location = New System.Drawing.Point(1, 214)
        Me.btnSubstInfoPEARL.Name = "btnSubstInfoPEARL"
        Me.btnSubstInfoPEARL.Size = New System.Drawing.Size(106, 34)
        Me.btnSubstInfoPEARL.TabIndex = 4
        Me.btnSubstInfoPEARL.Text = "Subst Info PEARL"
        Me.btnSubstInfoPEARL.UseVisualStyleBackColor = True
        '
        'btnSubstInfoPELMO
        '
        Me.btnSubstInfoPELMO.Location = New System.Drawing.Point(0, 214)
        Me.btnSubstInfoPELMO.Name = "btnSubstInfoPELMO"
        Me.btnSubstInfoPELMO.Size = New System.Drawing.Size(106, 34)
        Me.btnSubstInfoPELMO.TabIndex = 4
        Me.btnSubstInfoPELMO.Text = "Subst Info PELMO"
        Me.btnSubstInfoPELMO.UseVisualStyleBackColor = True
        '
        'btnSave2Config
        '
        Me.btnSave2Config.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSave2Config.Location = New System.Drawing.Point(316, 12)
        Me.btnSave2Config.Name = "btnSave2Config"
        Me.btnSave2Config.Size = New System.Drawing.Size(135, 30)
        Me.btnSave2Config.TabIndex = 9
        Me.btnSave2Config.Text = "Save to Config"
        Me.btnSave2Config.UseVisualStyleBackColor = True
        '
        'btnLoadFromConfig
        '
        Me.btnLoadFromConfig.Location = New System.Drawing.Point(137, 12)
        Me.btnLoadFromConfig.Name = "btnLoadFromConfig"
        Me.btnLoadFromConfig.Size = New System.Drawing.Size(135, 30)
        Me.btnLoadFromConfig.TabIndex = 9
        Me.btnLoadFromConfig.Text = "Load from Config"
        Me.btnLoadFromConfig.UseVisualStyleBackColor = True
        '
        'lsbLog
        '
        Me.lsbLog.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lsbLog.ContextMenuStrip = Me.ContextMenuStriplsblog
        Me.lsbLog.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lsbLog.FormattingEnabled = True
        Me.lsbLog.ItemHeight = 18
        Me.lsbLog.Location = New System.Drawing.Point(266, 456)
        Me.lsbLog.Name = "lsbLog"
        Me.lsbLog.Size = New System.Drawing.Size(444, 238)
        Me.lsbLog.TabIndex = 10
        '
        'ContextMenuStriplsblog
        '
        Me.ContextMenuStriplsblog.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SaveLog})
        Me.ContextMenuStriplsblog.Name = "ContextMenuStriplsblog"
        Me.ContextMenuStriplsblog.Size = New System.Drawing.Size(119, 26)
        '
        'SaveLog
        '
        Me.SaveLog.Name = "SaveLog"
        Me.SaveLog.Size = New System.Drawing.Size(118, 22)
        Me.SaveLog.Text = "SaveLog"
        '
        'GroupBoxFOCUSExecPaths
        '
        Me.GroupBoxFOCUSExecPaths.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBoxFOCUSExecPaths.Controls.Add(Me.cmbPEARLPath)
        Me.GroupBoxFOCUSExecPaths.Controls.Add(Me.txtPELMOPath)
        Me.GroupBoxFOCUSExecPaths.Controls.Add(Me.lblPEARLPath)
        Me.GroupBoxFOCUSExecPaths.Controls.Add(Me.lblPELMOPath)
        Me.GroupBoxFOCUSExecPaths.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxFOCUSExecPaths.Location = New System.Drawing.Point(15, 99)
        Me.GroupBoxFOCUSExecPaths.Name = "GroupBoxFOCUSExecPaths"
        Me.GroupBoxFOCUSExecPaths.Size = New System.Drawing.Size(695, 76)
        Me.GroupBoxFOCUSExecPaths.TabIndex = 11
        Me.GroupBoxFOCUSExecPaths.TabStop = False
        Me.GroupBoxFOCUSExecPaths.Text = "FOCUS  PEARL/PELMO Environment (Wheater data, Soil data , Executables etc.)"
        '
        'cmbPEARLPath
        '
        Me.cmbPEARLPath.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbPEARLPath.FormattingEnabled = True
        Me.cmbPEARLPath.Items.AddRange(New Object() {"Z:\_PROUTT\_software\FOCUSPEARL555", "Z:\_PROUTT\_software\FOCUSPEARL444"})
        Me.cmbPEARLPath.Location = New System.Drawing.Point(122, 18)
        Me.cmbPEARLPath.Name = "cmbPEARLPath"
        Me.cmbPEARLPath.Size = New System.Drawing.Size(548, 21)
        Me.cmbPEARLPath.TabIndex = 8
        Me.cmbPEARLPath.Text = "Z:\_PROUTT\_software\FOCUSPEARL555"
        '
        'GroupBoxCMPData
        '
        Me.GroupBoxCMPData.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBoxCMPData.Controls.Add(Me.lblPelmoWarning)
        Me.GroupBoxCMPData.Controls.Add(Me.lblMNumberPELMO)
        Me.GroupBoxCMPData.Controls.Add(Me.lblMNumberPEARL)
        Me.GroupBoxCMPData.Controls.Add(Me.lblPEARLTemplate)
        Me.GroupBoxCMPData.Controls.Add(Me.txtPEARLTemplate)
        Me.GroupBoxCMPData.Controls.Add(Me.txtPELMOTemplate)
        Me.GroupBoxCMPData.Controls.Add(Me.lblPELMOTemplate)
        Me.GroupBoxCMPData.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxCMPData.Location = New System.Drawing.Point(15, 191)
        Me.GroupBoxCMPData.Name = "GroupBoxCMPData"
        Me.GroupBoxCMPData.Size = New System.Drawing.Size(695, 115)
        Me.GroupBoxCMPData.TabIndex = 12
        Me.GroupBoxCMPData.TabStop = False
        Me.GroupBoxCMPData.Text = "PEARL/PELMO Compound Data (*.prl, *.cmp, Complete.psm)"
        '
        'lblPelmoWarning
        '
        Me.lblPelmoWarning.AutoSize = True
        Me.lblPelmoWarning.ForeColor = System.Drawing.Color.Red
        Me.lblPelmoWarning.Location = New System.Drawing.Point(399, 89)
        Me.lblPelmoWarning.Name = "lblPelmoWarning"
        Me.lblPelmoWarning.Size = New System.Drawing.Size(0, 13)
        Me.lblPelmoWarning.TabIndex = 10
        '
        'lblMNumberPELMO
        '
        Me.lblMNumberPELMO.AutoSize = True
        Me.lblMNumberPELMO.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMNumberPELMO.ForeColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblMNumberPELMO.Location = New System.Drawing.Point(119, 89)
        Me.lblMNumberPELMO.Name = "lblMNumberPELMO"
        Me.lblMNumberPELMO.Size = New System.Drawing.Size(0, 13)
        Me.lblMNumberPELMO.TabIndex = 9
        '
        'lblMNumberPEARL
        '
        Me.lblMNumberPEARL.AutoSize = True
        Me.lblMNumberPEARL.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMNumberPEARL.ForeColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblMNumberPEARL.Location = New System.Drawing.Point(119, 45)
        Me.lblMNumberPEARL.Name = "lblMNumberPEARL"
        Me.lblMNumberPEARL.Size = New System.Drawing.Size(0, 13)
        Me.lblMNumberPEARL.TabIndex = 8
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripProgressBar, Me.ToolStripStatusLabel})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 723)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(729, 22)
        Me.StatusStrip1.TabIndex = 13
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripProgressBar
        '
        Me.ToolStripProgressBar.Name = "ToolStripProgressBar"
        Me.ToolStripProgressBar.Size = New System.Drawing.Size(100, 16)
        Me.ToolStripProgressBar.Visible = False
        '
        'ToolStripStatusLabel
        '
        Me.ToolStripStatusLabel.Name = "ToolStripStatusLabel"
        Me.ToolStripStatusLabel.Size = New System.Drawing.Size(0, 17)
        Me.ToolStripStatusLabel.Visible = False
        '
        'btnReset
        '
        Me.btnReset.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnReset.Location = New System.Drawing.Point(574, 12)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(135, 30)
        Me.btnReset.TabIndex = 14
        Me.btnReset.Text = "Reset Tool"
        Me.btnReset.UseVisualStyleBackColor = True
        Me.btnReset.Visible = False
        '
        'chkKeepPelmoData
        '
        Me.chkKeepPelmoData.AutoSize = True
        Me.chkKeepPelmoData.Location = New System.Drawing.Point(6, 323)
        Me.chkKeepPelmoData.Name = "chkKeepPelmoData"
        Me.chkKeepPelmoData.Size = New System.Drawing.Size(128, 43)
        Me.chkKeepPelmoData.TabIndex = 15
        Me.chkKeepPelmoData.Text = "Keep all PELMO data" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "after calculation" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "(not recommended)"
        Me.chkKeepPelmoData.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(1, 134)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(106, 34)
        Me.Button1.TabIndex = 16
        Me.Button1.Text = "just Condor script"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'PELMO
        '
        Me.PELMO.Controls.Add(Me.rbPELMO664)
        Me.PELMO.Controls.Add(Me.rbPELMO553)
        Me.PELMO.Controls.Add(Me.btnPELMO32)
        Me.PELMO.Controls.Add(Me.btnStartPELMO)
        Me.PELMO.Controls.Add(Me.btnEvaluatePELMO)
        Me.PELMO.Controls.Add(Me.btnSubstInfoPELMO)
        Me.PELMO.Location = New System.Drawing.Point(137, 445)
        Me.PELMO.Name = "PELMO"
        Me.PELMO.Size = New System.Drawing.Size(106, 257)
        Me.PELMO.TabIndex = 17
        Me.PELMO.TabStop = False
        Me.PELMO.Text = "PELMO"
        '
        'rbPELMO664
        '
        Me.rbPELMO664.AutoSize = True
        Me.rbPELMO664.Location = New System.Drawing.Point(6, 51)
        Me.rbPELMO664.Name = "rbPELMO664"
        Me.rbPELMO664.Size = New System.Drawing.Size(83, 17)
        Me.rbPELMO664.TabIndex = 18
        Me.rbPELMO664.Text = "PELMO 664"
        Me.rbPELMO664.UseVisualStyleBackColor = True
        '
        'rbPELMO553
        '
        Me.rbPELMO553.AutoSize = True
        Me.rbPELMO553.Checked = True
        Me.rbPELMO553.Location = New System.Drawing.Point(6, 28)
        Me.rbPELMO553.Name = "rbPELMO553"
        Me.rbPELMO553.Size = New System.Drawing.Size(83, 17)
        Me.rbPELMO553.TabIndex = 11
        Me.rbPELMO553.TabStop = True
        Me.rbPELMO553.Text = "PELMO 553"
        Me.rbPELMO553.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbPEARL555)
        Me.GroupBox1.Controls.Add(Me.rbPEARL444)
        Me.GroupBox1.Controls.Add(Me.btnPEARL333)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.btnEvaluatePEARL)
        Me.GroupBox1.Controls.Add(Me.btnSubstInfoPEARL)
        Me.GroupBox1.Location = New System.Drawing.Point(15, 445)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(107, 257)
        Me.GroupBox1.TabIndex = 18
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "PEARL"
        '
        'rbPEARL555
        '
        Me.rbPEARL555.AutoSize = True
        Me.rbPEARL555.Location = New System.Drawing.Point(11, 51)
        Me.rbPEARL555.Name = "rbPEARL555"
        Me.rbPEARL555.Size = New System.Drawing.Size(81, 17)
        Me.rbPEARL555.TabIndex = 19
        Me.rbPEARL555.Text = "PEARL 555"
        Me.rbPEARL555.UseVisualStyleBackColor = True
        '
        'rbPEARL444
        '
        Me.rbPEARL444.AutoSize = True
        Me.rbPEARL444.Checked = True
        Me.rbPEARL444.Location = New System.Drawing.Point(11, 28)
        Me.rbPEARL444.Name = "rbPEARL444"
        Me.rbPEARL444.Size = New System.Drawing.Size(81, 17)
        Me.rbPEARL444.TabIndex = 19
        Me.rbPEARL444.TabStop = True
        Me.rbPEARL444.Text = "PEARL 444"
        Me.rbPEARL444.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(729, 745)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PELMO)
        Me.Controls.Add(Me.chkKeepPelmoData)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.GroupBoxCMPData)
        Me.Controls.Add(Me.GroupBoxFOCUSExecPaths)
        Me.Controls.Add(Me.btnLoadFromConfig)
        Me.Controls.Add(Me.lsbLog)
        Me.Controls.Add(Me.lblMasterPath)
        Me.Controls.Add(Me.lbxApp)
        Me.Controls.Add(Me.txtMasterPath)
        Me.Controls.Add(Me.btnSave2Config)
        Me.Controls.Add(Me.btnGetApp)
        Me.MaximizeBox = False
        Me.MinimumSize = New System.Drawing.Size(740, 740)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ContextMenuStriplsblog.ResumeLayout(False)
        Me.GroupBoxFOCUSExecPaths.ResumeLayout(False)
        Me.GroupBoxFOCUSExecPaths.PerformLayout()
        Me.GroupBoxCMPData.ResumeLayout(False)
        Me.GroupBoxCMPData.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.PELMO.ResumeLayout(False)
        Me.PELMO.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnPEARL333 As System.Windows.Forms.Button
    Friend WithEvents btnPELMO32 As System.Windows.Forms.Button
    Friend WithEvents btnGetApp As System.Windows.Forms.Button
    Friend WithEvents txtMasterPath As System.Windows.Forms.TextBox
    Friend WithEvents lblMasterPath As System.Windows.Forms.Label
    Friend WithEvents lbxApp As System.Windows.Forms.ListBox
    Friend WithEvents lblPEARLPath As System.Windows.Forms.Label
    Friend WithEvents txtPELMOPath As System.Windows.Forms.TextBox
    Friend WithEvents lblPELMOPath As System.Windows.Forms.Label
    Friend WithEvents txtPEARLTemplate As System.Windows.Forms.TextBox
    Friend WithEvents txtPELMOTemplate As System.Windows.Forms.TextBox
    Friend WithEvents lblPEARLTemplate As System.Windows.Forms.Label
    Friend WithEvents lblPELMOTemplate As System.Windows.Forms.Label
    Friend WithEvents btnStartPELMO As System.Windows.Forms.Button
    Friend WithEvents btnEvaluatePELMO As System.Windows.Forms.Button
    Friend WithEvents btnEvaluatePEARL As System.Windows.Forms.Button
    Friend WithEvents btnSubstInfoPEARL As System.Windows.Forms.Button
    Friend WithEvents btnSubstInfoPELMO As System.Windows.Forms.Button
    Friend WithEvents btnSave2Config As System.Windows.Forms.Button
    Friend WithEvents btnLoadFromConfig As System.Windows.Forms.Button
    Friend WithEvents lsbLog As System.Windows.Forms.ListBox
    Friend WithEvents ContextMenuStriplsblog As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents SaveLog As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBoxFOCUSExecPaths As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBoxCMPData As System.Windows.Forms.GroupBox
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripProgressBar As System.Windows.Forms.ToolStripProgressBar
    Friend WithEvents ToolStripStatusLabel As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents lblMNumberPELMO As System.Windows.Forms.Label
    Friend WithEvents lblMNumberPEARL As System.Windows.Forms.Label
    Friend WithEvents cmbPEARLPath As System.Windows.Forms.ComboBox
    Friend WithEvents lblPelmoWarning As System.Windows.Forms.Label
    Friend WithEvents chkKeepPelmoData As System.Windows.Forms.CheckBox
    Friend WithEvents Button1 As Button
    Friend WithEvents PELMO As GroupBox
    Friend WithEvents rbPELMO664 As RadioButton
    Friend WithEvents rbPELMO553 As RadioButton
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents rbPEARL555 As RadioButton
    Friend WithEvents rbPEARL444 As RadioButton
End Class
