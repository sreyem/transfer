﻿


Imports PECmanDrift.inputs
Imports PECmanDrift.calculations

Imports System.ComponentModel
Imports System.Xml.Serialization
Imports System.Web.Script.Serialization
Imports System.IO.Compression
Imports System.IO
Imports System.Drawing.Design

<TypeConverter(GetType(propGridConverter))>
<Serializable>
<DefaultProperty("inputs")>
Public Class PECmanDrift

    Public Sub New()

    End Sub

    Public Property inputs As New inputs

    Private _outputs As New PATex.PATex

    Public Property outputs As PATex.PATex
        Get
            _outputs.inputs = Me.inputs
            Return _outputs
        End Get
        Set(value As PATex.PATex)

            _outputs = value

        End Set
    End Property

End Class

<TypeConverter(GetType(propGridConverter))>
<Serializable>
<DefaultProperty("FOCUSDriftCrop")>
Public Class inputs

    Public Sub New()
        getDrainageWaterDepthDB()
    End Sub

#Region "    management"


    ''' <summary>
    ''' if true, descriptions will be in the enum, else shown in separate properties
    ''' </summary>
    Private Const seeAll As Boolean = True

    Private Const offset As String = "    "

    ''' <summary>
    ''' rough water depths for the runOff scenarios, appln, date independent!
    ''' </summary>
    Public Shared runOffStreamDepths As Double() = {0.41, 0.3, 0.29, 0.41}



    '<DebuggerBrowsable(DebuggerBrowsableState.Never)>
    'Private _applnDate As Date = New Date

    '''' <summary>
    '''' Application Date
    '''' </summary>
    '<Category(CATApplication)>
    '<DisplayName(
    '"Date")>
    '<Description(
    '"Application date" & vbCrLf &
    '"")>
    '<RefreshProperties(RefreshProperties.All)>
    '<DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    '<Browsable(True)>
    '<[ReadOnly](False)>
    '<TypeConverter(GetType(dateConv))>
    '<AttributeProvider(" format = 'dd. MMM yy'| julian ='add' ")>
    'Public Property applnDate As Date
    '    Get
    '        Return _applnDate
    '    End Get
    '    Set

    '        If Value > FOCUSSeasonEndDate OrElse Value < FOCUSSeasonStartDate Then
    '            Exit Property
    '        End If

    '        _applnDate = Value
    '        setWaterDepth(inputs:=Me)

    '    End Set
    'End Property


    <XmlIgnore> <ScriptIgnore>
    <Browsable(False)>
    Public Property drainageWaterDepthDB As String() = Nothing


    <XmlIgnore> <ScriptIgnore>
    <Browsable(False)>
    Public Property targetIndex As Integer = -1


    <XmlIgnore> <ScriptIgnore>
    <Browsable(False)>
    Public Property test As String() = {}


    <XmlIgnore> <ScriptIgnore>
    <Browsable(False)>
    Public Property searchstring As String = ""




#End Region

    Public Const CATFOCUSSettings As String = "01  FOCUS Settings"

#Region "    Crop, scenario, water body"

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _FOCUSswDriftCrop As eFOCUSswDriftCrop = eFOCUSswDriftCrop.not_defined

    ''' <summary>
    ''' Target crop out of the
    ''' available FOCUS crops
    ''' </summary>
    <Category(CATFOCUSSettings)>
    <DisplayName(
    "Crop")>
    <Description(
    "FOCUS crop for drift" & vbCrLf &
    "triggers Ganzelmeier crop group")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(CInt(eFOCUSswDriftCrop.not_defined))>
    Public Property FOCUSswDriftCrop As eFOCUSswDriftCrop
        Get

            enumConverter(Of eFOCUSswDriftCrop).no2Show =
                IIf(Expression:=seeAll, TruePart:=-1, 1)

            Return _FOCUSswDriftCrop

        End Get
        Set

            _FOCUSswDriftCrop = Value

            If _FOCUSswDriftCrop = eFOCUSswDriftCrop.not_defined Then Exit Property

            'set Ganzelmeier crop group
            Ganzelmeier = convertFOCUSCrop2Ganzelmeier(_FOCUSswDriftCrop)

            definedScenarios =
                enumConverter(Of eFOCUSswDriftCrop).getEnumDescription(
                    EnumConstant:=_FOCUSswDriftCrop).Split(vbLf).Last

            If Not definedScenarios.Contains(_FOCUSswScenario.ToString) Then
                _FOCUSswScenario = eFOCUSswScenario.not_defined
            Else
                resetCsv(inputs:=Me)
            End If

            updateDistances(
                noOfApplns:=_noOfApplns,
                FOCUSswDriftCrop:=_FOCUSswDriftCrop,
                FOCUSswWaterBody:=_FOCUSswWaterBody)

            precipitationFile = getPrecipitationFileName(
                FOCUSswDriftCrop:=_FOCUSswDriftCrop,
                FOCUSswScenario:=_FOCUSswScenario).Split(",").Last

        End Set
    End Property

    ''' <summary>
    ''' Defined FOCUSsw scenarios
    ''' based on selected FOCUS crop
    ''' </summary>
    <Category(CATFOCUSSettings)>
    <DisplayName(
    offset & "def. Scenarios")>
    <Description(
    "Defined FOCUSsw scenarios" & vbCrLf &
    "based on selected FOCUS crop")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(Not seeAll)>
    <[ReadOnly](True)>
    <XmlIgnore> <ScriptIgnore>
    <DefaultValue("")>
    Public Property definedScenarios As String = ""

    ''' <summary>
    ''' Ganzelmeier crop group
    ''' based on selected FOCUS crop
    ''' </summary>
    <Category(CATFOCUSSettings)>
    <DisplayName(
    offset & "Ganzelmeier")>
    <Description(
    "Ganzelmeier crop group" & vbCrLf &
    "based on selected FOCUS crop")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    <XmlIgnore> <ScriptIgnore>
    <DefaultValue(CInt(eGanzelmeier.not_defined))>
    Public Property Ganzelmeier As eGanzelmeier = eGanzelmeier.not_defined


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _FOCUSswScenario As eFOCUSswScenario = eFOCUSswScenario.not_defined

    ''' <summary>
    ''' FOCUSSsw Scenario
    ''' if defined for this crop
    ''' </summary>
    <Category(CATFOCUSSettings)>
    <DisplayName(
    "Scenario")>
    <Description(
    "FOCUSsw scenario D1-D6, R1-R4" & vbCrLf &
    "if defined for this crop!")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(CInt(eFOCUSswScenario.not_defined))>
    Public Property FOCUSswScenario As eFOCUSswScenario
        Get

            If _FOCUSswDriftCrop <> eFOCUSswDriftCrop.not_defined Then

                enumConverter(Of eFOCUSswScenario).onlyShow =
                definedScenarios.Split("|")

                enumConverter(Of eFOCUSswScenario).no2Show =
                IIf(Expression:=seeAll, TruePart:=-1, 0)

            End If

            Return _FOCUSswScenario

        End Get
        Set

            If Value = eFOCUSswScenario.not_defined Then
                _FOCUSswWaterBody = eFOCUSswWaterBody.not_defined
                Exit Property
            End If

            If Not definedScenarios.Split("|").Contains(Value.ToString) Then
                Exit Property
            End If

            _FOCUSswScenario = Value

            'update  avail. water body
            definedWaterBody =
                enumConverter(Of eFOCUSswScenario).getEnumDescription(
            EnumConstant:=_FOCUSswScenario).Split(vbLf).Last

            'set water body in order of worst case for PECsw calculation
            If definedWaterBody.Contains(eFOCUSswWaterBody.ditch.ToString) Then
                FOCUSswWaterBody = eFOCUSswWaterBody.ditch
            ElseIf definedWaterBody.Contains(eFOCUSswWaterBody.stream.ToString) Then
                FOCUSswWaterBody = eFOCUSswWaterBody.stream
            Else
                FOCUSswWaterBody = eFOCUSswWaterBody.pond
            End If

            plainScenarioName =
                enumConverter(Of eFOCUSswScenario).getEnumDescription(
            EnumConstant:=_FOCUSswScenario).Split(vbLf)(1)

            'set ca. water depths for the R1-R4 scenarios
            If _FOCUSswScenario.ToString.StartsWith("R") Then

                waterDepth =
                runOffStreamDepths(CInt(_FOCUSswScenario.ToString.Substring(1, 1) - 1))

            End If

            updateDistances(
                noOfApplns:=_noOfApplns,
                FOCUSswDriftCrop:=_FOCUSswDriftCrop,
                FOCUSswWaterBody:=_FOCUSswWaterBody)

            precipitationFile = getPrecipitationFileName(
                FOCUSswDriftCrop:=_FOCUSswDriftCrop,
                FOCUSswScenario:=_FOCUSswScenario).Split(",").Last

            resetCsv(inputs:=Me)

        End Set
    End Property

    <Category(CATFOCUSSettings)>
    <DisplayName(
    offset & "Name")>
    <Description(
    "Location name of the scenario" & vbCrLf &
    "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(Not seeAll)>
    <[ReadOnly](True)>
    <XmlIgnore> <ScriptIgnore>
    <DefaultValue("")>
    Public Property plainScenarioName As String = ""

    ''' <summary>
    ''' Precipitation '*_P.BIN' file
    ''' </summary>
    ''' <returns></returns>
    <Category(CATFOCUSSettings)>
    <DisplayName(
    offset & "*_P.BIN file")>
    <Description(
    "*_P.BIN file" & vbCrLf &
    "precipitation file name for scenario corp combinations")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    <XmlIgnore> <ScriptIgnore>
    <DefaultValue("")>
    Public Property precipitationFile As String = ""



    <Category(CATFOCUSSettings)>
    <DisplayName(
    "Season Start")>
    <Description(
    "" & vbCrLf &
    "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    <XmlIgnore> <ScriptIgnore>
    Public Property FOCUSSeasonStartDate As Date = Nothing


    <Category(CATFOCUSSettings)>
    <DisplayName(
    "       End")>
    <Description(
    "" & vbCrLf &
    "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    <XmlIgnore> <ScriptIgnore>
    Public Property FOCUSSeasonEndDate As Date = Nothing


    ''' <summary>
    ''' Defined FOCUSsw WaterBody
    ''' based on selected FOCUS crop
    ''' </summary>
    <Category(CATFOCUSSettings)>
    <DisplayName(
    offset & "def. Water Body")>
    <Description(
    "Defined FOCUSsw Water Body" & vbCrLf &
    "based on selected FOCUS scenario")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(Not seeAll)>
    <[ReadOnly](True)>
    <XmlIgnore> <ScriptIgnore>
    <DefaultValue("")>
    Public Property definedWaterBody As String = ""

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _FOCUSswWaterBody As eFOCUSswWaterBody = eFOCUSswWaterBody.not_defined

    ''' <summary>
    ''' FOCUS water body
    ''' Ditch, pond or stream
    ''' </summary>
    <Category(CATFOCUSSettings)>
    <DisplayName(
    "Water Body")>
    <Description(
    "Ditch, pond or stream" & vbCrLf &
    "if defined for this scenario!")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(CInt(eFOCUSswWaterBody.not_defined))>
    Public Property FOCUSswWaterBody As eFOCUSswWaterBody
        Get
            If _FOCUSswScenario <> eFOCUSswScenario.not_defined Then

                enumConverter(Of eFOCUSswWaterBody).onlyShow =
                                definedWaterBody.Split("|")

                enumConverter(Of eFOCUSswWaterBody).no2Show =
                    IIf(Expression:=seeAll, TruePart:=-1, 1)

            End If


            Return _FOCUSswWaterBody

        End Get
        Set

            If Not definedWaterBody.Split("|").Contains(Value.ToString) Then
                Exit Property
            End If

            _FOCUSswWaterBody = Value

            wbDimensions =
                enumConverter(Of Type).getEnumDescription(
                EnumConstant:=_FOCUSswWaterBody).Split(vbLf).Last

            If _FOCUSswWaterBody = eFOCUSswWaterBody.not_defined Then Exit Property

            updateDistances(
                noOfApplns:=_noOfApplns,
                FOCUSswDriftCrop:=_FOCUSswDriftCrop,
                FOCUSswWaterBody:=_FOCUSswWaterBody)

            resetCsv(inputs:=Me)

        End Set
    End Property

    ''' <summary>
    ''' Defined FOCUSsw WaterBody
    ''' based on selected FOCUS crop
    ''' </summary>
    <Category(CATFOCUSSettings)>
    <DisplayName(
    offset & "Dimensions")>
    <Description(
    "Water body dimensions and upstream catchment factor" & vbCrLf &
    "length x width x depth; volume; upstream factor")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(Not seeAll)>
    <[ReadOnly](True)>
    <XmlIgnore> <ScriptIgnore>
    <DefaultValue("")>
    Public Property wbDimensions As String = ""

    ''' <summary>
    ''' Water depth
    ''' Ditch, pond or stream
    ''' </summary>
    <Category(CATFOCUSSettings)>
    <DisplayName(
    "Water Depth")>
    <Description(
    "Water depth in m " & vbCrLf &
    "at appln. date")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(Double.NaN)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(" format = 'G5'| unit =' m' ")>
    Public Property waterDepth As Double = Double.NaN

#End Region

    Public Const CATDistances As String = "02  Distances"

#Region "    Distances from crop"

    Public Sub updateDistances(
                            noOfApplns As eNoOfApplns,
                            FOCUSswDriftCrop As eFOCUSswDriftCrop,
                            FOCUSswWaterBody As eFOCUSswWaterBody)

        If FOCUSswDriftCrop <> eFOCUSswDriftCrop.not_defined AndAlso
           FOCUSswWaterBody <> eFOCUSswWaterBody.not_defined AndAlso
           noOfApplns <> eNoOfApplns.not_defined Then


            distanceCrop2Bank = getFOCUSStdDistance(
                        FOCUSswDriftCrop:=FOCUSswDriftCrop,
                        FOCUSswWaterBody:=FOCUSswWaterBody,
                        FOCUSstdDistancesMember:=eFOCUSStdDistancesMember.edgeField2topBank)

            distanceBank2Water = getFOCUSStdDistance(
                        FOCUSswDriftCrop:=FOCUSswDriftCrop,
                        FOCUSswWaterBody:=FOCUSswWaterBody,
                        FOCUSstdDistancesMember:=eFOCUSStdDistancesMember.topBank2edgeWaterbody)


            closest2EdgeOfField = distanceCrop2Bank + distanceBank2Water

            farthest2EdgeOfWB = distanceCrop2Bank +
                       distanceBank2Water +
                       WaterBodyDB(_FOCUSswWaterBody, eWBMember.Witdth)

        Else

            distanceCrop2Bank = Double.NaN
            distanceBank2Water = Double.NaN
            closest2EdgeOfField = Double.NaN

        End If

        If noOfApplns <> eNoOfApplns.not_defined AndAlso
           FOCUSswDriftCrop <> eFOCUSswDriftCrop.not_defined Then
            hingePoint =
                hingePointDB(
                    convertFOCUSCrop2Ganzelmeier(FOCUSswDriftCrop),
                    noOfApplns)
        Else
            hingePoint = Double.NaN
        End If

        If noOfApplns <> eNoOfApplns.not_defined AndAlso
           FOCUSswDriftCrop <> eFOCUSswDriftCrop.not_defined AndAlso
           FOCUSswWaterBody <> eFOCUSswWaterBody.not_defined Then

            nearestDriftPercent = calcDriftPercent(
                    noOfApplns:=noOfApplns,
                FOCUSswDriftCrop:=FOCUSswDriftCrop,
                        FOCUSswWaterBody:=FOCUSswWaterBody,
                        driftDistance:=eDriftDistance.closest)

            farthestDriftPercent = calcDriftPercent(
                    noOfApplns:=noOfApplns,
                FOCUSswDriftCrop:=FOCUSswDriftCrop,
                        FOCUSswWaterBody:=FOCUSswWaterBody,
                        driftDistance:=eDriftDistance.farthest)

            areicMeanDriftPercent = calcDriftPercent(
                    noOfApplns:=noOfApplns,
                FOCUSswDriftCrop:=FOCUSswDriftCrop,
                        FOCUSswWaterBody:=FOCUSswWaterBody,
                        driftDistance:=eDriftDistance.average)

        Else
            nearestDriftPercent = Double.NaN
        End If

    End Sub


    ''' <summary>
    ''' Distance  Crop to Bank in m 
    ''' </summary>
    <Category(CATDistances)>
    <DisplayName(
    "Crop <-> Bank")>
    <Description(
    "Distance Crop <-> Bank" & vbCrLf &
    "in m")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= 'G5'|unit=' m'")>
    <XmlIgnore> <ScriptIgnore>
    Public Property distanceCrop2Bank As Double = Double.NaN


    ''' <summary>
    ''' Distance  Bank to Water in m
    ''' </summary>
    <Category(CATDistances)>
    <DisplayName(
    "Bank <-> Water")>
    <Description(
    "Distance Bank <-> Water" & vbCrLf &
    "in m")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
    "format= 'G5'|unit=' m'")>
    <XmlIgnore> <ScriptIgnore>
    Public Property distanceBank2Water As Double = Double.NaN


    ''' <summary>
    ''' Hinge Point
    ''' Distance limit for each regression in m
    ''' to switch from A + B to C + D
    ''' </summary>
    <Category(CATDistances)>
    <DisplayName(
    "Hinge Point")>
    <Description(
    "Distance limit for each regression in m" & vbCrLf &
    "to switch from A/B to C/D")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
    "format= 'G5'|unit=' m'")>
    <XmlIgnore> <ScriptIgnore>
    Public Property hingePoint As Double = Double.NaN


    ''' <summary>
    ''' Closest to the edge of the field in m
    ''' </summary>
    <Category(CATDistances)>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
    "edge nearest  field")>
    <Description(
    "Closest to the edge of the field in m" & vbCrLf &
    "FOCUS std. Buffer length: Crop2Bank + Bank2Water")>
    <Browsable(True)>
    <[ReadOnly](True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
    "format= 'G5'|unit=' m'")>
    <XmlIgnore> <ScriptIgnore>
    Public Property closest2EdgeOfField As Double = Double.NaN


    ''' <summary>
    ''' Drift at edge nearest field in %
    ''' </summary>
    ''' <returns></returns>
    <Category(CATDistances)>
    <DisplayName(
    offset & " Drift %")>
    <Description(
    "Drift at edge nearest field" & vbCrLf &
    "in %")>
    <Browsable(True)>
    <[ReadOnly](True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
    "format= 'G5'|unit=' %'")>
    <XmlIgnore> <ScriptIgnore>
    Public Property nearestDriftPercent As Double = Double.NaN


    ''' <summary>
    ''' Farthest to the edge of the field in m
    ''' BufferWidth + WaterBodyWidth
    ''' </summary>
    <Category(CATDistances)>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
    "farthest from field")>
    <Description(
    "Farthest to the edge of the field in m" & vbCrLf &
    "Closest2Edge + water body width")>
    <Browsable(True)>
    <[ReadOnly](True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
    "format= 'G5'|unit=' m'")>
    <XmlIgnore> <ScriptIgnore>
    Public Property farthest2EdgeOfWB As Double = Double.NaN


    ''' <summary>
    ''' Drift farthest to the 
    ''' edge of the field in %
    ''' </summary>
    ''' <returns></returns>
    <Category(CATDistances)>
    <DisplayName(
    offset & " Drift %")>
    <Description(
    "Drift farthest to the edge of the field" & vbCrLf &
    "in %")>
    <Browsable(True)>
    <[ReadOnly](True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
    "format= 'G5'|unit=' %'")>
    <XmlIgnore> <ScriptIgnore>
    Public Property farthestDriftPercent As Double = Double.NaN



    ''' <summary>
    ''' Areic mean drift in %
    ''' </summary>
    ''' <returns></returns>
    <Category(CATDistances)>
    <DisplayName(
    "Mean Drift %")>
    <Description(
    "Areic mean drift" & vbCrLf &
    "in %")>
    <Browsable(True)>
    <[ReadOnly](True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider(
    "format= 'G5'|unit=' %'")>
    <XmlIgnore> <ScriptIgnore>
    Public Property areicMeanDriftPercent As Double = Double.NaN


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _bufferWidth As eBufferWidth = eBufferWidth.FOCUSStep03

    ''' <summary>
    ''' Buffer width in m
    ''' Step03 = std. FOCUS buffer width
    ''' </summary>
    ''' <returns></returns>
    <Category(CATDistances)>
    <DisplayName(
    "Buffer")>
    <Description(
    "Buffer width in m" & vbCrLf &
    "Step03 = std. FOCUS buffer width")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public Property bufferWidth As eBufferWidth
        Get
            Return _bufferWidth
        End Get
        Set(value As eBufferWidth)
            _bufferWidth = value
        End Set
    End Property


#End Region

    Public Const CATApplication As String = "03  Application"

#Region "    Application"

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _noOfApplns As eNoOfApplns = eNoOfApplns.not_defined

    ''' <summary>
    ''' Number of applications
    ''' 1 - 8
    ''' </summary>
    <Category(CATApplication)>
    <DisplayName(
    "Appln. Number")>
    <Description(
    "Number of applications" & vbCrLf &
    "1 - 8 (or more)")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(CInt(eNoOfApplns.not_defined))>
    Public Property noOfApplns As eNoOfApplns
        Get
            Return _noOfApplns
        End Get
        Set

            _noOfApplns = Value

            updateDistances(
                noOfApplns:=_noOfApplns,
                FOCUSswDriftCrop:=_FOCUSswDriftCrop,
                FOCUSswWaterBody:=FOCUSswWaterBody)

            applnRate = _applnRate
            checkWindow()
            updateDetails()

            RaiseEvent getPATresults()

        End Set
    End Property

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _applnRate As Double = Double.NaN

    ''' <summary>
    ''' Application rate
    ''' in kg/ha
    ''' </summary>
    <Category(CATApplication)>
    <DisplayName(
    offset & "Rate")>
    <Description(
    "Application rate" & vbCrLf &
    "in kg/ha")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= 'G5'|unit=' kg/ha'")>
    Public Property applnRate As Double
        Get
            Return _applnRate
        End Get
        Set
            _applnRate = Value
            updateDetails()
        End Set
    End Property

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _applnInterval As eApplnInterval = eApplnInterval.not_defined


    ''' <summary>
    ''' Interval between applications
    ''' in days, one appln = not def.
    ''' </summary>
    ''' <returns></returns>
    <Category(CATApplication)>
    <DisplayName(
    offset & "Interval")>
    <Description(
    "Interval between applications" & vbCrLf &
    "in days, one appln = not def.")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(CInt(eApplnInterval.not_defined))>
    Public Property applnInterval As eApplnInterval
        Get
            Return _applnInterval
        End Get
        Set(value As eApplnInterval)

            If _noOfApplns = eNoOfApplns.not_defined OrElse
               _noOfApplns = eNoOfApplns.one Then
                _applnInterval = eApplnInterval.not_defined
                Exit Property
            End If

            _applnInterval = value
            checkWindow()
            updateDetails()

            RaiseEvent getPATresults()

        End Set
    End Property

    <Category(CATApplication)>
    <DisplayName(
    offset & "Details")>
    <Description(
    "" & vbCrLf &
    "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public Property applns As New applns


#End Region

    Public Const CATPAT As String = "04  PAT"

#Region "    PAT"

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _SWASHversion As eSWASHVersion = eSWASHVersion._553

    <Category(CATPAT)>
    <DisplayName(
    "SWASH Version")>
    <Description(
    "PAT for one FOCUS year (5.5.3) or" & vbCrLf &
    "New PAT for 20 year assesment (6.6.4)")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public Property SWASHversion As eSWASHVersion
        Get
            Return _SWASHversion
        End Get
        Set(value As eSWASHVersion)

            _SWASHversion = value
            RaiseEvent getPATresults()

        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _PATStart As New Date(year:=1901, month:=1, day:=1)

    <Category(CATPAT)>
    <DisplayName(
    "PAT Start")>
    <Description(
    "" & vbCrLf &
    "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <TypeConverter(GetType(dateConv))>
    <AttributeProvider("format = 'dd. MMM yy'| julian ='add'")>
    Public Property PATStart As Date
        Get
            Return _PATStart
        End Get
        Set(value As Date)

            _PATStart = value
            checkWindow()
            updateDetails()
            RaiseEvent getPATresults()

        End Set
    End Property

    Public Function checkWindow() As Boolean

        Dim minInterval As Integer

        If _noOfApplns = eNoOfApplns.not_defined OrElse
           (_noOfApplns <> eNoOfApplns.one AndAlso _applnInterval = eApplnInterval.not_defined) OrElse
           _PATStart = New Date Then

            PATwindow = "min 30 days, def. start date, # of appls and interval"
            Return False

        End If

        minInterval = 30 + (_noOfApplns * _applnInterval)

        If _PATEnd < _PATStart.AddDays(minInterval) Then
            _PATEnd = _PATStart.AddDays(minInterval)
        End If

        PATwindow =
                (_PATEnd - _PATStart).Days.ToString & " days       " & vbCrLf &
                minInterval & " days = min" & vbCrLf &
                "min = 30 + ((NoOfApplns - 1) * Interval)" & vbCrLf &
                "min = 30 + ((" &
                CInt(_noOfApplns).ToString.PadLeft("NoOfApplns -1 ".Length) & ") * " &
                (_noOfApplns + 1).ToString.PadLeft("".Length) & ") days"

        Return True

    End Function

    Private Sub updateDetails()

        If _noOfApplns = eNoOfApplns.not_defined OrElse
           (_noOfApplns <> eNoOfApplns.one AndAlso _applnInterval = eApplnInterval.not_defined) OrElse
           _PATStart = New Date OrElse
           Double.IsNaN(applnRate) Then

            Exit Sub

        End If

        Me.applns =
            New applns(
            noOfApplns:=_noOfApplns,
            applnInterval:=_applnInterval,
            applnRate:=_applnRate,
            applnDate:=_PATStart)

    End Sub

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _PATEnd As New Date

    <Category(CATPAT)>
    <DisplayName(
    offset & "End")>
    <Description(
    "" & vbCrLf &
    "")>
    <RefreshProperties(RefreshProperties.All)>
    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
    <Browsable(True)>
    <[ReadOnly](False)>
    <TypeConverter(GetType(dateConv))>
    <AttributeProvider("format = 'dd. MMM yy'| julian ='add'")>
    Public Property PATEnd As Date
        Get
            Return _PATEnd
        End Get
        Set(value As Date)

            _PATEnd = value
            If Not checkWindow() Then
                _PATEnd = New Date
            End If

            RaiseEvent getPATresults()

        End Set
    End Property


    <RefreshProperties(RefreshProperties.All)>
    <Description("PAT Start - End in days")>
    <DisplayName(
    offset & "Window")>
    <Category(CATPAT)>
    <[ReadOnly](True)>
    <XmlIgnore> <ScriptIgnore>
    Public Property PATwindow As String

#End Region

#Region "    Events"

    Public Event getPATresults()

#End Region

#Region "    enums"

    ''' <summary>
    ''' FOCUSsw DRIFT crops as enumeration
    ''' </summary>
    <TypeConverter(GetType(enumConverter(Of eFOCUSswDriftCrop)))>
    Public Enum eFOCUSswDriftCrop

        <Description(
            "CS " & vbCrLf &
            "Cereals, spring " & vbCrLf &
            "D1|D3|D4|D5|R4")>
        CS_Cereals_spring = 0

        <Description(
            "CW " & vbCrLf &
            "Cereals, winter " & vbCrLf &
            "D1|D2|D3|D4|D5|D6|R1|R3|R4")>
        CW_Cereals_winter

        '-------------------------------------------------------------

        <Description(
            "CI " & vbCrLf &
            "Citrus " & vbCrLf &
            "D6|R4")>
        CI_Citrus

        <Description(
            "CO " & vbCrLf &
            "Cotton " & vbCrLf &
            "D6")>
        CO_Cotton

        '-------------------------------------------------------------

        <Description(
            "FB " & vbCrLf &
            "Field beans 1st/2nd " & vbCrLf &
            "D2|D3|D4|D6|R1|R2|R3|R4")>
        FB_Field_beans

        <Description(
            "GA " & vbCrLf &
            "Grass/alfalfa " & vbCrLf &
            "D1|D2|D3|D4|D5|R2|R3")>
        GA_Grass_alfalfa

        '-------------------------------------------------------------

        <Description(
            "HP " & vbCrLf &
            "Hops " & vbCrLf &
            "R1")>
        HP_Hops

        '-------------------------------------------------------------

        <Description(
            "LG " & vbCrLf &
            "Legumes " & vbCrLf &
            "D3|D4|D5|D6|R1|R2|R3|R4")>
        LG_Legumes

        <Description(
            "MZ " & vbCrLf &
            "Maize " & vbCrLf &
            "D3|D4|D5|D6|R1|R2|R3|R4")>
        MZ_Maize

        '-------------------------------------------------------------

        <Description(
            "OS " & vbCrLf &
            "Oil seed rape, spring " & vbCrLf &
            "D1|D3|D4|D5|R1")>
        OS_Oil_seed_rape_spring

        <Description(
            "OW " & vbCrLf &
            "Oil seed rape, winter " & vbCrLf &
            "D2|D3|D4|D5|R1|R3")>
        OW_Oil_seed_rape_winter

        '-------------------------------------------------------------

        <Description(
            "OL " & vbCrLf &
            "Olives " & vbCrLf &
            "D6|R4")>
        OL_Olives


        <Description(
            "PF " & vbCrLf &
            "Pome/stone fruits, early " & vbCrLf &
            "D3|D4|D5|R1|R2|R3|R4")>
        PFE_Pome_stone_fruit_early_applns

        <Description(
            "PF " & vbCrLf &
            "Pome/stone fruits, late " & vbCrLf &
            "D3|D4|D5|R1|R2|R3|R4")>
        PFL_Pome_stone_fruit_late_applns

        '-------------------------------------------------------------

        <Description(
            "PS " & vbCrLf &
            "Potatoes, 1st/2nd " & vbCrLf &
            "D3|D4|D6|R1|R2|R3")>
        PS_Potatoes

        <Description(
            "SY " & vbCrLf &
            "Soybeans " & vbCrLf &
            "R3|R4")>
        SY_Soybeans

        <Description(
            "SB " & vbCrLf &
            "Sugar beets " & vbCrLf &
            "D3|D4|R1|R3")>
        SB_Sugar_beets

        <Description(
            "SU " & vbCrLf &
            "Sunflowers " & vbCrLf &
            "D5|R1|R3|R4")>
        SU_Sunflowers

        '-------------------------------------------------------------

        <Description(
            "TB " & vbCrLf &
            "Tobacco " & vbCrLf &
            "R3")>
        TB_Tobacco

        '-------------------------------------------------------------

        <Description(
            "VB " & vbCrLf &
            "Vegetables, bulb, 1st/2nd " & vbCrLf &
            "D3|D4|D6|R1|R2|R3|R4")>
        VB_Vegetables_bulb

        <Description(
            "VF " & vbCrLf &
            "Vegetables, fruiting " & vbCrLf &
            "D6|R2|R3|R4")>
        VF_Vegetables_fruiting

        <Description(
            "VL " & vbCrLf &
            "Vegetables, leafy, 1st/2nd " & vbCrLf &
            "D3|D4|D6|R1|R2|R3|R4")>
        VL_Vegetables_leafy

        <Description(
            "VR " & vbCrLf &
            "Vegetables, root, 1st/2nd " & vbCrLf &
            "D3|D6|R1|R2|R3|R4")>
        VR_Vegetables_root

        '-------------------------------------------------------------

        <Description(
            "VI " & vbCrLf &
            "Vines, early " & vbCrLf &
            "D6|R1|R2|R3|R4")>
        VIE_Vines_early_applns

        <Description(
            "VI " & vbCrLf &
            "Vines, late " & vbCrLf &
            "D6|R1|R2|R3|R4")>
        VIL_Vines_late_applns

        '-------------------------------------------------------------

        <Description(
            "AA " & vbCrLf &
            "Aerial appln.")>
        AA_Aerial


        <Description(
            "HL " & vbCrLf &
            " Appln, hand " & vbCrLf &
            "(crop < 50 cm)")>
        HL_HandAppLow

        <Description(
            "HH " & vbCrLf &
            " Appln, hand " & vbCrLf &
            "(crop > 50 cm)")>
        HH_HandAppHigh


        <Description(
            "ND " & vbCrLf &
            " No drift " & vbCrLf &
            "(incorp or seed trtmt)")>
        ND_NoDrift


        <Description(enumConverter(Of Type).not_defined)>
        not_defined = -1

    End Enum


    ''' <summary>
    ''' Ganzelmeier crop groups
    ''' </summary>
    <TypeConverter(GetType(enumConverter(Of eGanzelmeier)))>
    Public Enum eGanzelmeier

        <Description(
            "Arable crops " & vbCrLf &
            "1.9274 %")>
        ArableCrops = 0

        <Description(
            "Fruit crops, early " & vbCrLf &
            "23.599 %")>
        FruitCrops_Early

        <Description(
            "Fruit crops, late " & vbCrLf &
            "11.134 %")>
        FruitCrops_Late

        <Description(
            "Hops " & vbCrLf &
            "14.554 %")>
        Hops

        <Description(
            "Vines, early " & vbCrLf &
            "1.7184 %")>
        Vines_Early

        <Description(
            "Vines, late " & vbCrLf &
            "5.173 %")>
        Vines_Late

        <Description(
            "Aerial appln " & vbCrLf &
            "25.476 %")>
        AerialAppln

        <Description("no drift " & vbCrLf &
            "0 % ;-)")>
        noDrift

        <Description(enumConverter(Of Type).not_defined)>
        not_defined = -1

    End Enum


    ''' <summary>
    ''' all FOCUSsw scenarios D1-6 and R1-4
    ''' </summary>
    <TypeConverter(GetType(enumConverter(Of eFOCUSswScenario)))>
    Public Enum eFOCUSswScenario

        <Description(
            "D1 " & vbCrLf &
            "Lanna " & vbCrLf &
            "ditch|stream")>
        D1 = 0

        <Description(
            "D2 " & vbCrLf &
            "Brimstone " & vbCrLf &
            "ditch|stream")>
        D2

        <Description(
            "D3 " & vbCrLf &
            "Vredepeel " & vbCrLf &
            "ditch")>
        D3

        <Description(
            "D4 " & vbCrLf &
            "Skousbo " & vbCrLf &
            "pond|stream")>
        D4

        <Description(
            "D5 " & vbCrLf &
            "La Jailliere " & vbCrLf &
            "pond|stream")>
        D5

        <Description(
            "D6 " & vbCrLf &
            "Thiva " & vbCrLf &
            "ditch")>
        D6

        <Description(
            "R1 " & vbCrLf &
            "Weiherbach " & vbCrLf &
            "pond|stream")>
        R1

        <Description(
            "R2 " & vbCrLf &
            "Porto " & vbCrLf &
            "stream")>
        R2

        <Description(
            "R3 " & vbCrLf &
            "Bologna " & vbCrLf &
            "stream")>
        R3

        <Description(
            "R4 " & vbCrLf &
            "Roujan " & vbCrLf &
            "stream")>
        R4

        <Description(enumConverter(Of Type).not_defined)>
        not_defined = -1

    End Enum


    ''' <summary>
    ''' FOCUSsw water body
    ''' ditch, stream or pond
    ''' </summary>
    <TypeConverter(GetType(enumConverter(Of eFOCUSswWaterBody)))>
    Public Enum eFOCUSswWaterBody

        <Description(
            "DI " & vbCrLf &
            "ditch " & vbCrLf &
            "100m " & Multipy & " 1m " & Multipy & " 0.3m; 30,000L; 1.0")>
        ditch = 0

        <Description(
            "ST " & vbCrLf &
            "stream " & vbCrLf &
            "100m " & Multipy & " 1m " & Multipy & " 0.3m; 30,000L; 1.2")>
        stream

        <Description(
            "PO " & vbCrLf &
            "pond " & vbCrLf &
            "30m radius " & Multipy & " 1.0m; ~94,000L; 1.0")>
        pond

        <Description(enumConverter(Of Type).not_defined)>
        not_defined = -1

    End Enum


    ''' <summary>
    ''' Number of applns.
    ''' 1 - 8 (or more)
    ''' </summary>
    <TypeConverter(GetType(enumConverter(Of eNoOfApplns)))>
    Public Enum eNoOfApplns

        <Description("one")>
        one = 0

        <Description("two")>
        two

        <Description("three")>
        three

        <Description("four")>
        four

        <Description("fife")>
        fife

        <Description("six")>
        six

        <Description("seven")>
        seven

        <Description("eight or more")>
        eight


        <Description(enumConverter(Of Type).not_defined)>
        not_defined = -1

    End Enum

    ''' <summary>
    ''' appln Interval
    ''' </summary>
    <TypeConverter(GetType(enumConverter(Of eApplnInterval)))>
    Public Enum eApplnInterval

        <Description(enumConverter(Of Type).not_defined)>
        not_defined = -1

        <Description(" 1")> _01 = 1
        <Description(" 2")> _02 = 2
        <Description(" 3")> _03 = 3
        <Description(" 4")> _04 = 4

        <Description(" 5")>
        _05 = 5
        <Description(" 7")>
        _07 = 7
        <Description("10")>
        _10 = 10
        <Description("12")>
        _12 = 12
        <Description("14")>
        _14 = 14
        <Description("21")>
        _21 = 21
        <Description("28")>
        _28 = 28


        '<Description(" 6")> _06 = 6

        '<Description(" 8")> _08 = 8
        '<Description(" 9")> _09 = 9

        '<Description("11")> _11 = 11

        '<Description("13")> _13 = 13

        <Description("15")> _15 = 15
        '<Description("16")> _16 = 16
        '<Description("17")> _17 = 17
        '<Description("18")> _18 = 18
        '<Description("19")> _19 = 19
        '<Description("20")> _20 = 20

        '<Description("22")> _22 = 22
        '<Description("23")> _23 = 23
        '<Description("24")> _24 = 24
        '<Description("25")> _25 = 25
        '<Description("26")> _26 = 26
        '<Description("27")> _27 = 27

        '<Description("29")> _29 = 29
        <Description("30")> _30 = 30
        '<Description("31")> _31 = 31
        '<Description("32")> _32 = 32
        '<Description("33")> _33 = 33
        '<Description("34")> _34 = 34
        '<Description("35")> _35 = 35
        '<Description("36")> _36 = 36
        '<Description("37")> _37 = 37
        '<Description("38")> _38 = 38
        '<Description("39")> _39 = 39
        '<Description("40")> _40 = 40
        '<Description("41")> _41 = 41
        <Description("42")> _42 = 42
        '<Description("43")> _43 = 43
        '<Description("44")> _44 = 44
        '<Description("45")> _45 = 45
        '<Description("46")> _46 = 46
        '<Description("47")> _47 = 47
        '<Description("48")> _48 = 48
        '<Description("49")> _49 = 49
        <Description("50")> _50 = 50
        <Description("60")> _60 = 60

    End Enum


    ''' <summary>
    ''' Buffer width as enum for simple input, -1 = Step03 std ;-)
    ''' </summary>
    <TypeConverter(GetType(enumConverter(Of eBufferWidth)))>
    Public Enum eBufferWidth

        <Description("Step03")>
        FOCUSStep03 = 0

        <Description(" 1")>
        _01 = 1

        <Description(" 2")>
        _02 = 2

        <Description(" 3")>
        _03 = 3

        <Description(" 4")>
        _04 = 4

        <Description(" 5")>
        _05 = 5

        <Description("10")>
        _10 = 10

        <Description("15")>
        _15 = 15

        <Description("20")>
        _20 = 20

        <Description("30")>
        _30 = 30

        <Description("40")>
        _40 = 40

        <Description("50")>
        _50 = 50

        <Description(enumConverter(Of Type).not_defined)>
        not_defined = -1

    End Enum


    ''' <summary>
    ''' PAT version
    ''' one FOCUS year or 20 year assessment
    ''' </summary>
    <TypeConverter(GetType(enumConverter(Of eSWASHVersion)))>
    Public Enum eSWASHVersion
        <Description("5.5.3, one target year")>
        _553
        <Description("6.6.4, 20 years")>
        _664
    End Enum

#End Region

#Region "    db"

    ''' <summary>
    ''' Water bodies defined for the different scenarios
    ''' </summary>
    Public Shared scenariosXWaterBodies As String() =
   {
    "D1+ Lanna        +ditch|stream",
    "D2+ Brimstone    +ditch|stream",
    "D3+ Vredepeel    +ditch",
    "D4+ Skousbo      +pond|stream",
    "D5+ La Jailliere +pond|stream",
    "D6+ Thiva        +ditch",
    "R1+ Weiherbach   +pond|stream",
    "R2+ Porto        +stream",
    "R3+ Bologna      +stream",
    "R4+ Roujan       +stream"
    }

    ''' <summary>
    ''' start dates for the drainage scenarios FOCUS season
    ''' normaly the last 18 months of the calc. period
    ''' </summary>
    Public Shared startDrainageSeasonDates As New List(Of Date) From
    {
        New Date(year:=1982, month:=1, day:=1),
        New Date(year:=1986, month:=1, day:=1),
        New Date(year:=1992, month:=1, day:=1),
        New Date(year:=1985, month:=1, day:=1),
        New Date(year:=1978, month:=1, day:=1),
        New Date(year:=1986, month:=1, day:=1)
    }

    ''' <summary>
    ''' precipitation file names for scenario corp combinations
    ''' </summary>
    Public Shared scenarioXCropX_PFile As String() =
    {
    "D1,CS,lanna_p.BIN",
    "D1,CW,lanna_p.BIN",
    "D1,GA,lanna_p.BIN",
    "D1,OS,lanna_p.BIN",
    "D2,CW,brims_p.BIN",
    "D2,FB,brims_p.BIN",
    "D2,GA,brims_p.BIN",
    "D2,OW,brims_p.BIN",
    "D3,CS,vr_isc_p.BIN",
    "D3,CW,vr_iwc_p.BIN",
    "D3,FB,vr_ifb_p.BIN",
    "D3,GA,vr_igr_p.BIN",
    "D3,LG,vr_ile_p.BIN",
    "D3,MZ,vr_ima_p.BIN",
    "D3,OS,vrede_p.BIN",
    "D3,OW,vrede_p.BIN",
    "D3,PF,vr_ipf_p.BIN",
    "D3,PS,vr_ipo_p.BIN",
    "D3,SB,vr_isb_p.BIN",
    "D3,VB,vr_ibv_p.BIN",
    "D3,VL,vr_ilv_p.BIN",
    "D3,VR,vr_irv_p.BIN",
    "D4,CS,skous_p.BIN",
    "D4,CW,skous_p.BIN",
    "D4,FB,skous_p.BIN",
    "D4,GA,skous_p.BIN",
    "D4,LG,sk_ile_p.BIN",
    "D4,MZ,skous_p.BIN",
    "D4,OS,skous_p.BIN",
    "D4,OW,skous_p.BIN",
    "D4,PF,skous_p.BIN",
    "D4,PS,sk_ipo_p.BIN",
    "D4,SB,sk_isb_p.BIN",
    "D4,VB,sk_ibv_p.BIN",
    "D4,VL,sk_ilv_p.BIN",
    "D5,CS,jaill_p.BIN",
    "D5,CW,jaill_p.BIN",
    "D5,GA,jaill_p.BIN",
    "D5,LG,jaill_p.BIN",
    "D5,MZ,jaill_p.BIN",
    "D5,OS,jaill_p.BIN",
    "D5,OW,jaill_p.BIN",
    "D5,PF,jaill_p.BIN",
    "D5,SU,jaill_p.BIN",
    "D6,CI,th_ici_p.BIN",
    "D6,CO,th_ico_p.BIN",
    "D6,CW,thebe_p.BIN",
    "D6,FB,th_ifb_p.BIN",
    "D6,LG,th_ile_p.BIN",
    "D6,MZ,th_ima_p.BIN",
    "D6,OL,thebe_p.BIN",
    "D6,PS,th_ipo_p.BIN",
    "D6,VB,th_ibv_p.BIN",
    "D6,VF,th_ifv_p.BIN",
    "D6,VI,thebe_p.BIN",
    "D6,VL,th_ilv_p.BIN",
    "D6,VR,th_irv_p.BIN"
    }

#End Region

#Region "    functions"

    Public Sub getDrainageWaterDepthDB()

        Dim fileName As String

        fileName =
            Path.Combine(
                path1:=Environment.CurrentDirectory,
                path2:="DrainageHYD553.zip")

        Using archive As ZipArchive =
               ZipFile.Open(
               archiveFileName:=fileName,
               mode:=ZipArchiveMode.Read)

            Dim entry As ZipArchiveEntry =
            archive.GetEntry(
                entryName:=Path.GetFileName(Path.ChangeExtension(
                path:=fileName,
                extension:=".csv")))

            Dim s As String = ""
            Using sr As StreamReader = New StreamReader(entry.Open())
                s = sr.ReadToEnd()
                drainageWaterDepthDB = s.Split(vbCrLf)
            End Using

        End Using

    End Sub


    ''' <summary>
    ''' convert FOCUSsw DRIFT crop to Ganzelmeier crop group
    ''' </summary>
    Public Shared convertFOCUSCrop2Ganzelmeier As eGanzelmeier() =
    {
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.FruitCrops_Late,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.Hops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.FruitCrops_Late,
       eGanzelmeier.FruitCrops_Early,
       eGanzelmeier.FruitCrops_Late,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.Vines_Early,
       eGanzelmeier.Vines_Late,
       eGanzelmeier.AerialAppln,
       eGanzelmeier.ArableCrops,
       eGanzelmeier.Vines_Late,
       eGanzelmeier.noDrift,
       eGanzelmeier.not_defined
    }

    ''' <summary>
    ''' returns avail. scenarios for this crop as array of string
    ''' </summary>
    Public Shared getSwScenarios4FOCUSDriftCrop As String() =
    {
        "CS+Cereals, Spring+D1|D3|D4|D5|R4",
        "CW+Cereals, Winter+D1|D2|D3|D4|D5|D6|R1|R3|R4",
        "CI+Citrus+D6|R4",
        "CO+Cotton+D6",
        "FB+Field beans+D2|D3|D4|D6|R1|R2|R3|R4",
        "GA+Grass/alfalfa+D1|D2|D3|D4|D5|R2|R3",
        "HP+Hops+R1",
        "LG+Legumes+D3|D4|D5|D6|R1|R2|R3|R4",
        "MZ+Maize+D3|D4|D5|D6|R1|R2|R3|R4",
        "OS+Oil seed rape, spring+D1|D3|D4|D5|R1",
        "OW+Oil seed rape, winter+D2|D3|D4|D5|R1|R3",
        "OL+Olives+D6|R4",
        "PFE+Pome/stone fruits+D3|D4|D5|R1|R2|R3|R4",
        "PFL+Pome/stone fruits+D3|D4|D5|R1|R2|R3|R4",
        "PS+Potatoes+D3|D4|D6|R1|R2|R3",
        "SY+Soybeans+R3|R4",
        "SB+Sugar beets+D3|D4|R1|R3",
        "SU+Sunflowers+D5|R1|R3|R4",
        "TB+Tobacco+R3",
        "VB+Vegetables, bulb+D3|D4|D6|R1|R2|R3|R4",
        "VF+Vegetables, fruiting+D6|R2|R3|R4",
        "VL+Vegetables, leafy+D3|D4|D6|R1|R2|R3|R4",
        "VR+Vegetables, root+D3|D6|R1|R2|R3|R4",
        "VIE+Vines+D6|R1|R2|R3|R4",
        "VIL+Vines+D6|R1|R2|R3|R4"
    }

    Public Function getPrecipitationFileName(
                            FOCUSswDriftCrop As eFOCUSswDriftCrop,
                            FOCUSswScenario As eFOCUSswScenario) As String


        If FOCUSswScenario = eFOCUSswScenario.not_defined OrElse
           FOCUSswDriftCrop = eFOCUSswDriftCrop.not_defined Then
            Return ""
        End If

        Dim temp As String()

        temp =
            Filter(
            Source:=scenarioXCropX_PFile,
            Match:=FOCUSswScenario.ToString & "," & FOCUSswDriftCrop.ToString.Split("_").First)

        If IsNothing(temp) OrElse temp.Count = 0 Then
            Return ""
        Else
            Return temp.First
        End If

    End Function

    Public Shared Function isScenarioIsDefined(
                                FOCUSDriftCrop As eFOCUSswDriftCrop,
                                FOCUSswScenario As eFOCUSswScenario) As Boolean

        Dim availScenarios As String()

        If FOCUSDriftCrop = eFOCUSswDriftCrop.not_defined OrElse
          FOCUSswScenario = eFOCUSswScenario.not_defined Then Return False

        Try
            availScenarios =
                       getSwScenarios4FOCUSDriftCrop(FOCUSDriftCrop).Split("+").Last.Split("|")

            If availScenarios.Contains(FOCUSswScenario.ToString) Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Return False
        End Try

    End Function

    Public Shared Function isWaterBodyDefined(FOCUSswScenario As eFOCUSswScenario, FOCUSswWaterBody As eFOCUSswWaterBody) As Boolean

        Dim enumDescription As String()

        If FOCUSswScenario = eFOCUSswDriftCrop.not_defined OrElse
           FOCUSswWaterBody = eFOCUSswWaterBody.not_defined Then Return False

        Try
            enumDescription =
                enumConverter(Of eFOCUSswScenario).getEnumDescription(
                EnumConstant:=FOCUSswScenario).Split(
                    separator:={vbCrLf},
                    options:=StringSplitOptions.RemoveEmptyEntries).Last.Split(",")


            If enumDescription.Contains(
                FOCUSswWaterBody.ToString) Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            Return False
        End Try


    End Function


#End Region

End Class

<TypeConverter(GetType(propGridConverter))>
<Serializable>
Public Class applns

    Public Sub New()

    End Sub

    Public Sub New(
                  noOfApplns As eNoOfApplns,
                  applnInterval As eApplnInterval,
                  applnRate As Double,
         Optional applnDate As Date = Nothing)

        Dim temp As New List(Of appln)

        If IsNothing(applnDate) Then
            applnDate = New Date(1901, 1, 1)
        End If

        If noOfApplns = eNoOfApplns.one Then applnInterval = 1

        For counter As Integer = 0 To noOfApplns

            temp.Add(New appln)

            With temp(temp.Count - 1)

                .applnNo = counter

                If counter = 0 Then
                    .DAL = counter
                Else
                    .DAL = applnInterval
                End If

                .applnDate = applnDate.AddDays(counter * applnInterval)

                .applnRate = applnRate

            End With

        Next

        _applns = temp.ToArray

    End Sub

    Private _applns As appln() = {}

    <RefreshProperties(RefreshProperties.All)>
    Public Property applns As appln()
        Get
            Return _applns
        End Get
        Set(value As appln())

            For counter As Integer = 0 To value.Count - 1

                With value(counter)

                    .applnNo = counter

                    If counter = 0 Then
                        .DAL = 0
                    Else
                        .DAL = (.applnDate - value(counter - 1).applnDate).TotalDays
                    End If

                End With

            Next

        End Set
    End Property

End Class

<TypeConverter(GetType(propGridConverter))>
<Serializable>
<DefaultProperty("applnRate")>
Public Class appln

    Public Sub New()

    End Sub

    Public ReadOnly Property name As String
        Get
            If IsNothing(applnDate) OrElse Double.IsNaN(applnRate) Then
                Return enumConverter(Of Type).not_defined
            End If

            Return _
                dateConv.convDate2String(
                value:=applnDate,
                format:="dd. MMM yy",
                julian:=dateConv.eJulian.add) & " " &
                dblConv.conv2String(value:=applnRate, format:="G5", unit:=" kg/ha") & " " &
                Me.interception & "% interc."

        End Get
    End Property


    <Browsable(False)>
    Public Property applnNo As Integer

    <[ReadOnly](True)>
    Public Property DAL As Integer = 0

    Public Property applnDate As Date = Nothing

    Public Property applnRate As Double = Double.NaN

    Public Property interception As Integer


    <Editor(GetType(multiLineDoubleArrayEditor), GetType(UITypeEditor))>
    Public Property rainAroundappln As Double() = {}

    Public ReadOnly Property rainAroundPassed As Boolean
        Get

            For Each member As Double In rainAroundappln
                If member > 2 Then
                    Return False
                End If
            Next

            Return True

        End Get
    End Property

    <Editor(GetType(multiLineDoubleArrayEditor), GetType(UITypeEditor))>
    Public Property rainNextdays As Double() = {}

End Class

Public Class calculations

    Public Shared Function calcDriftPercent(inputs As inputs) As Double

        With inputs

            Try
                Return calcDriftPercent(
                                noOfApplns:= .noOfApplns,
                                FOCUSswDriftCrop:= .FOCUSswDriftCrop,
                                FOCUSswWaterBody:= .FOCUSswWaterBody,
                                bufferWidth:= .bufferWidth)
            Catch ex As Exception
                Throw New ArithmeticException(
                    message:="Error calculation drift percent",
                    innerException:=ex)
            End Try

        End With

    End Function



    ''' <summary>
    ''' calculation of FOCUS drift values
    ''' </summary>
    ''' <param name="noOfApplns">
    ''' # of applications, 1 - 8, as enum
    ''' </param>
    ''' <param name="FOCUSswDriftCrop">
    ''' FOCUS crop as enum
    ''' </param>
    ''' <param name="FOCUSswWaterBody">
    ''' Ditch, pond or stream, as enum
    ''' </param>
    ''' <param name="bufferWidth">
    ''' Buffer width in m, -1 = FOCUS std. width
    ''' </param>
    ''' <param name="driftDistance">
    ''' Nearest, farthest or average distance 
    ''' std. = average
    ''' </param>
    ''' <returns>
    ''' FOCUS drift in percent as double
    ''' </returns>
    ''' <remarks></remarks>
    Public Shared Function calcDriftPercent(
                                    noOfApplns As eNoOfApplns,
                                    FOCUSswDriftCrop As eFOCUSswDriftCrop,
                                    FOCUSswWaterBody As eFOCUSswWaterBody,
                           Optional bufferWidth As Integer = eBufferWidth.FOCUSStep03,
                           Optional driftDistance As eDriftDistance = eDriftDistance.average) As Double

        'check inputs
        If noOfApplns = eNoOfApplns.not_defined OrElse
           FOCUSswDriftCrop = eFOCUSswDriftCrop.not_defined OrElse
           FOCUSswWaterBody = eFOCUSswWaterBody.not_defined Then
            Return Double.NaN
        End If


        'drift for output
        Dim drift As Double = Double.NaN

        'Application
        Dim Ganzelmeier As eGanzelmeier

        'regression parameters
        Dim A As Double
        Dim B As Double

        Dim C As Double
        Dim D As Double

        'set buffer width to FOCUS std.
        Dim hingePoint As Double
        Dim edgeField2topBank As Double
        Dim topBank2edgeWaterbody As Double
        Dim closest2EdgeOfField As Double
        Dim farthest2EdgeOfField As Double

        'drift for Step03 std. buffer distance?
        Dim step03stdBuffer As Boolean

        'check if buffer = Step03 std.
        Try

            If [Enum].Parse(
            enumType:=GetType(eBufferWidth),
            value:=bufferWidth) = eBufferWidth.FOCUSStep03 Then
                step03stdBuffer = True
            Else
                step03stdBuffer = False
            End If

        Catch ex As Exception
            step03stdBuffer = False
        End Try

        'get Ganzelmeier crop group
        Ganzelmeier = convertFOCUSCrop2Ganzelmeier(FOCUSswDriftCrop)

        'distances
        'edge of the field to top of the bank
        If step03stdBuffer Then

            edgeField2topBank =
                getFOCUSStdDistance(
                            FOCUSswDriftCrop:=FOCUSswDriftCrop,
                            FOCUSswWaterBody:=FOCUSswWaterBody,
                            FOCUSstdDistancesMember:=eFOCUSStdDistancesMember.edgeField2topBank)
        Else
            edgeField2topBank = 0
        End If

        'top of the bank to edge of water body
        'FOCUS Step03 std. 'buffer' distance
        If step03stdBuffer Then
            topBank2edgeWaterbody =
                getFOCUSStdDistance(
                            FOCUSswDriftCrop:=FOCUSswDriftCrop,
                            FOCUSswWaterBody:=FOCUSswWaterBody,
                            FOCUSstdDistancesMember:=eFOCUSStdDistancesMember.topBank2edgeWaterbody)

        Else
            topBank2edgeWaterbody = 0
        End If


        'distance limit for each regression in m, hinge point
        hingePoint = hingePointDB(Ganzelmeier, noOfApplns)


        'distance from crop at edge nearest to field
        If step03stdBuffer Then
            closest2EdgeOfField = edgeField2topBank + topBank2edgeWaterbody
        Else
            closest2EdgeOfField = bufferWidth
        End If

        'distance from crop at edge farthest from field
        If step03stdBuffer Then
            farthest2EdgeOfField =
                edgeField2topBank + topBank2edgeWaterbody + WaterBodyDB(FOCUSswWaterBody, eWBMember.Witdth)
        Else
            farthest2EdgeOfField =
                bufferWidth + WaterBodyDB(FOCUSswWaterBody, eWBMember.Witdth)
        End If

        'get regression parameter
        A = regressionA(Ganzelmeier,
                        noOfApplns)

        B = regressionB(Ganzelmeier,
                        noOfApplns)

        C = regressionC(Ganzelmeier,
                        noOfApplns)

        D = regressionD(Ganzelmeier,
                        noOfApplns)

        Select Case driftDistance

            Case eDriftDistance.farthest

                Try

                    If farthest2EdgeOfField < hingePoint Then
                        drift = A * (farthest2EdgeOfField ^ B)
                    Else
                        drift = C * (farthest2EdgeOfField ^ D)
                    End If

                Catch ex As Exception
                    Throw New _
                        ArithmeticException(
                        message:="Error during drift calc.",
                        innerException:=ex)
                End Try

            Case eDriftDistance.closest

                Try

                    If closest2EdgeOfField < hingePoint Then
                        drift = A * (closest2EdgeOfField ^ B)
                    Else
                        drift = C * (closest2EdgeOfField ^ D)
                    End If

                Catch ex As Exception
                    Throw New _
                        ArithmeticException(
                        message:="Error during drift calc.",
                        innerException:=ex)
                End Try

            Case eDriftDistance.average

                Try

                    If farthest2EdgeOfField < hingePoint Then
                        drift = (A / (B + 1) * (farthest2EdgeOfField ^ (B + 1) - closest2EdgeOfField ^ (B + 1))) /
                                          (farthest2EdgeOfField - closest2EdgeOfField)
                    ElseIf closest2EdgeOfField > hingePoint Then
                        drift = C / (D + 1) * (farthest2EdgeOfField ^ (D + 1) - closest2EdgeOfField ^ (D + 1)) /
                                          (farthest2EdgeOfField - closest2EdgeOfField)
                    Else
                        drift = (A / (B + 1) * (hingePoint ^ (B + 1) - closest2EdgeOfField ^ (B + 1)) + C / (D + 1) * (farthest2EdgeOfField ^ (D + 1) - hingePoint ^ (D + 1))) * 1 /
                                          (farthest2EdgeOfField - closest2EdgeOfField)
                    End If

                Catch ex As Exception
                    Throw New _
                        ArithmeticException(
                        message:="Error during drift calc.",
                        innerException:=ex)
                End Try

        End Select

        ' if stream then apply upstream catchment factor 1.2
        drift *= WaterBodyDB(FOCUSswWaterBody, eWBMember.Factor)

        Return drift

    End Function


    ''' <summary>
    ''' Calculation of mass loading for TOXSWA in mg/m^2 of water surface; ApplnRate * Drift
    ''' </summary>
    ''' <param name="applnRate">
    ''' Application rate in kg/ha
    ''' </param>
    ''' <param name="drift">
    ''' FOCUS drift in percent, 0 - 100%
    ''' </param>
    ''' <returns>
    ''' Mass loading in mg/m^2 of water surface as double
    ''' </returns>
    ''' <remarks></remarks>
    Public Shared Function calcMassLoading(applnRate As Double,
                                           drift As Double) As Double

        Try
            Return applnRate * drift
        Catch ex As Exception
            Throw New _
                        ArithmeticException(
                        message:="Error during MassLoading calc.",
                        innerException:=ex)
        End Try

    End Function



    ''' <summary>
    ''' Calculation of drift PECsw in µg/L
    '''  
    '''             applnRate [kg/ha]
    ''' PECsw =  --------------------- 
    '''          waterDepth * driftPercent
    ''' 
    ''' </summary>
    ''' <param name="applnRate">
    ''' Application rate in kg/ha
    ''' </param>
    ''' <param name="driftPercent">
    ''' FOCUS drift in percent, 0 - 100%
    ''' </param>
    ''' <param name="waterDepth">
    ''' Depth of water body in m, std. 0.3m for ditch and stream, 1m for pond
    ''' </param>
    ''' <returns>
    ''' PECsw in µg/L as double
    ''' </returns>
    ''' <remarks></remarks>
    Public Shared Function calcPECsw(applnRate As Double,
                                     driftPercent As Double,
                            Optional waterDepth As Double = 0.3) As Double

        Try
            Return applnRate / waterDepth * driftPercent
        Catch ex As Exception
            Throw New _
                        ArithmeticException(
                        message:="Error during PECsw calc.",
                        innerException:=ex)
        End Try

    End Function


    Public Shared Sub resetCsv(ByRef inputs As inputs)

        With inputs

            If .FOCUSswScenario = eFOCUSswScenario.not_defined OrElse
               .FOCUSswWaterBody = eFOCUSswWaterBody.not_defined OrElse
               .drainageWaterDepthDB Is Nothing Then
                Exit Sub
            End If

            Dim searchString As String
            Const csvDateOffset As Integer = 5

            If .FOCUSswScenario.ToString.StartsWith("D") Then

                searchString = .FOCUSswScenario.ToString & "_" &
                               .FOCUSswWaterBody.ToString.Substring(0, 2).ToUpper & "_" & Trim(
                                enumConverter(Of eFOCUSswDriftCrop).getEnumDescription(.FOCUSswDriftCrop).Split(vbCrLf).First)

                .searchstring = searchString
                .test = .drainageWaterDepthDB.First.Split(",")

                .targetIndex =
                Array.FindIndex(
                array:= .drainageWaterDepthDB.First.Split(","),
                match:=Function(x) _
                            x.Contains(searchString))

                If .targetIndex <> -1 Then

                    .FOCUSSeasonStartDate = New Date(year:= .drainageWaterDepthDB(1).Split(",")(.targetIndex), month:=1, day:=1)
                    .FOCUSSeasonEndDate = .FOCUSSeasonStartDate.AddDays(.drainageWaterDepthDB.Count - csvDateOffset)
                    '.applnDate = .FOCUSSeasonStartDate

                    setWaterDepth(inputs:=inputs)

                End If

            End If

        End With

    End Sub

    Public Shared Sub setWaterDepth(ByRef inputs As inputs)

        With inputs

            If .targetIndex = -1 Then Exit Sub

            Dim rowNumber As Integer = -1

            'rowNumber = (.applnDate - .FOCUSSeasonStartDate).TotalDays + 2

            '.waterDepth = .csv(rowNumber).Split(",")(.targetIndex)

        End With

    End Sub

#Region "enums"

    ''' <summary>
    ''' Distances
    ''' nearest, farthest, average
    ''' </summary>
    <TypeConverter(GetType(enumConverter(Of eDriftDistance)))>
    Public Enum eDriftDistance
        <Description("Drift at edge nearest field")>
        closest
        <Description("Drift farthest to the edge of the field")>
        farthest
        <Description("Areic mean drift")>
        average
    End Enum

#End Region

#Region "Std. FOCUS Step03 buffer distance in m"

    Public Shared Function getFOCUSStdDistance(
                            FOCUSswDriftCrop As eFOCUSswDriftCrop,
                            FOCUSswWaterBody As eFOCUSswWaterBody,
                            FOCUSstdDistancesMember As eFOCUSStdDistancesMember) As Double

        Dim FOCUSstdDistancesEntry As String = ""
        Dim CropString As String = String.Empty

        If FOCUSswDriftCrop = eFOCUSswDriftCrop.not_defined OrElse
           FOCUSswWaterBody = eFOCUSswWaterBody.not_defined Then
            Return Double.NaN
        End If

        Try

            CropString =
            enumConverter(Of eFOCUSswDriftCrop).getEnumDescription(
                    EnumConstant:=FOCUSswDriftCrop)

            FOCUSstdDistancesEntry =
                Array.Find(
                array:=
                    Filter(
                        Source:=FOCUSStdDistances,
                        Match:=FOCUSswWaterBody.ToString,
                        Include:=True,
                        Compare:=CompareMethod.Text),
                match:=Function(x) x.StartsWith(CropString.Substring(0, 2)))


            FOCUSstdDistancesEntry =
                FOCUSstdDistancesEntry.Split({"|"c})(FOCUSstdDistancesMember)

            Return CDbl(FOCUSstdDistancesEntry)

        Catch ex As Exception
            Return Double.NaN
        End Try

    End Function


    Public Enum eFOCUSStdDistancesMember

        cropShort
        cropString
        waterbody
        edgeField2topBank
        topBank2edgeWaterbody

    End Enum


    Public Shared FOCUSStdDistances As String() =
    {
        "CS|cereals, spring|ditch|0.5|0.5",
        "CS|cereals, spring|stream|0.5|1",
        "CS|cereals, spring|pond|0.5|3",
        "CW|cereals, winter|ditch|0.5|0.5",
        "CW|cereals, winter|stream|0.5|1",
        "CW|cereals, winter|pond|0.5|3",
        "GA|grass/alfalfa|ditch|0.5|0.5",
        "GA|grass/alfalfa|stream|0.5|1",
        "GA|grass/alfalfa|pond|0.5|3",
        "OS|oil seed rape, spring|ditch|0.5|0.5",
        "OS|oil seed rape, spring|stream|0.5|1",
        "OS|oil seed rape, spring|pond|0.5|3",
        "OW|oil seed rape, winter|ditch|0.5|0.5",
        "OW|oil seed rape, winter|stream|0.5|1",
        "OW|oil seed rape, winter|pond|0.5|3",
        "VB|vegetables, bulb|ditch|0.5|0.5",
        "VB|vegetables, bulb|stream|0.5|1",
        "VB|vegetables, bulb|pond|0.5|3",
        "VF|vegetables, fruiting|ditch|0.5|0.5",
        "VF|vegetables, fruiting|stream|0.5|1",
        "VF|vegetables, fruiting|pond|0.5|3",
        "VL|vegetables, leafy|ditch|0.5|0.5",
        "VL|vegetables, leafy|stream|0.5|1",
        "VL|vegetables, leafy|pond|0.5|3",
        "VR|vegetables, root|ditch|0.5|0.5",
        "VR|vegetables, root|stream|0.5|1",
        "VR|vegetables, root|pond|0.5|3",
        "K5|appln, hand (crop < 50 cm)|ditch|0.5|0.5",
        "K5|appln, hand (crop < 50 cm)|stream|0.5|1",
        "K5|appln, hand (crop < 50 cm)|pond|0.5|3",
        "PS|potatoes|ditch|0.8|0.5",
        "PS|potatoes|stream|0.8|1",
        "PS|potatoes|pond|0.8|3",
        "SY|soybeans|ditch|0.8|0.5",
        "SY|soybeans|stream|0.8|1",
        "SY|soybeans|pond|0.8|3",
        "SB|sugar beets|ditch|0.8|0.5",
        "SB|sugar beets|stream|0.8|1",
        "SB|sugar beets|pond|0.8|3",
        "SU|sunflowers|ditch|0.8|0.5",
        "SU|sunflowers|stream|0.8|1",
        "SU|sunflowers|pond|0.8|3",
        "CO|cotton|ditch|0.8|0.5",
        "CO|cotton|stream|0.8|1",
        "CO|cotton|pond|0.8|3",
        "FB|field beans|ditch|0.8|0.5",
        "FB|field beans|stream|0.8|1",
        "FB|field beans|pond|0.8|3",
        "LG|legumes|ditch|0.8|0.5",
        "LG|legumes|stream|0.8|1",
        "LG|legumes|pond|0.8|3",
        "MZ|maize|ditch|0.8|0.5",
        "MZ|maize|stream|0.8|1",
        "MZ|maize|pond|0.8|3",
        "TB|tobacco|ditch|1|0.5",
        "TB|tobacco|stream|1|1",
        "TB|tobacco|pond|1|3",
        "CI|citrus|ditch|3|0.5",
        "CI|citrus|stream|3|1",
        "CI|citrus|pond|3|3",
        "HP|hops|ditch|3|0.5",
        "HP|hops|stream|3|1",
        "HP|hops|pond|3|3",
        "OL|olives|ditch|3|0.5",
        "OL|olives|stream|3|1",
        "OL|olives|pond|3|3",
        "PF|pome/stone fruits|ditch|3|0.5",
        "PF|pome/stone fruits|stream|3|1",
        "PF|pome/stone fruits|pond|3|3",
        "VI|vines|ditch|3|0.5",
        "VI|vines|stream|3|1",
        "VI|vines|pond|3|3",
        "G5|appln, hand (crop > 50 cm)|ditch|3|0.5",
        "G5|appln, hand (crop > 50 cm)|stream|3|1",
        "G5|appln, hand (crop > 50 cm)|pond|3|3",
        "AA|appln, aerial|ditch|5|0.5",
        "AA|appln, aerial|stream|5|1",
        "AA|appln, aerial|pond|5|3"
    }

#End Region


#Region "Regression parameters and hinge point"

    Public Shared Property regressionA As Double(,) =
    {
        {2.7593, 2.4376, 2.0244, 1.8619, 1.7942, 1.6314, 1.5784, 1.5119},
        {66.702, 62.272, 58.796, 58.947, 58.111, 58.829, 59.912, 59.395},
        {60.396, 42.002, 40.12, 36.273, 34.591, 31.64, 31.561, 29.136},
        {58.247, 66.243, 60.397, 58.559, 59.548, 60.136, 59.774, 53.2},
        {15.793, 15.461, 16.887, 16.484, 15.648, 15.119, 14.675, 14.948},
        {44.769, 40.262, 39.314, 37.401, 37.767, 36.908, 35.498, 35.094},
        {50.47, 50.47, 50.47, 50.47, 50.47, 50.47, 50.47, 50.47}
    }

    Public Shared Property regressionB As Double(,) =
    {
        {-0.9778, -1.01, -0.9956, -0.9861, -0.9943, -0.9861, -0.9811, -0.9832},
        {-0.752, -0.8116, -0.8171, -0.8331, -0.8391, -0.8644, -0.8838, -0.8941},
        {-1.2249, -1.1306, -1.1769, -1.1616, -1.1533, -1.1239, -1.1318, -1.1048},
        {-1.0042, -1.2001, -1.2132, -1.2171, -1.2481, -1.2699, -1.2813, -1.2469},
        {-1.608, -1.6599, -1.7223, -1.7172, -1.7072, -1.6999, -1.6936, -1.7177},
        {-1.5643, -1.5771, -1.5842, -1.5746, -1.5829, -1.5905, -1.5844, -1.5819},
        {-0.3819, -0.3819, -0.3819, -0.3819, -0.3819, -0.3819, -0.3819, -0.3819}
    }

    'only used for fruit/early, fruit/late and hops
    Public Shared Property regressionC As Double(,) =
    {
        {2.7593, 2.4376, 2.0244, 1.8619, 1.7942, 1.6314, 1.5784, 1.5119},
        {3867.9, 7961.7, 9598.8, 8609.8, 7684.6, 7065.6, 7292.9, 7750.9},
        {210.7, 298.76, 247.78, 201.98, 197.08, 228.69, 281.84, 256.33},
        {8654.9, 5555.3, 4060.9, 3670.4, 2860.6, 2954, 3191.6, 3010.1},
        {15.793, 15.461, 16.887, 16.484, 15.648, 15.119, 14.675, 14.948},
        {44.769, 40.262, 39.314, 37.401, 37.767, 36.908, 35.498, 35.094},
        {281.06, 281.06, 281.06, 281.06, 281.06, 281.06, 281.06, 281.06}
    }

    'only used for fruit/early, fruit/late and hops
    Public Shared Property regressionD As Double(,) =
    {
        {-0.9778, -1.01, -0.9956, -0.9861, -0.9943, -0.9861, -0.9811, -0.9832},
        {-2.4183, -2.6854, -2.7706, -2.7592, -2.7366, -2.7323, -2.7463, -2.7752},
        {-1.7599, -1.9464, -1.9299, -1.8769, -1.8799, -1.9519, -2.0087, -1.9902},
        {-2.8354, -2.8231, -2.7625, -2.7619, -2.7036, -2.7269, -2.7665, -2.7549},
        {-1.608, -1.6599, -1.7223, -1.7172, -1.7072, -1.6999, -1.6936, -1.7177},
        {-1.5643, -1.5771, -1.5842, -1.5746, -1.5829, -1.5905, -1.5844, -1.5819},
        {-0.9989, -0.9989, -0.9989, -0.9989, -0.9989, -0.9989, -0.9989, -0.9989}
    }

    'distance limit for each regression (m), also called hinge point.
    Public Shared Property hingePointDB As Double(,) =
    {
        {1, 1, 1, 1, 1, 1, 1, 1},
        {11.4, 13.3, 13.6, 13.3, 13.1, 13, 13.2, 13.3},
        {10.3, 11.1, 11.2, 11, 11, 10.9, 12.1, 11.7},
        {15.3, 15.3, 15.1, 14.6, 14.3, 14.5, 14.6, 14.6},
        {1, 1, 1, 1, 1, 1, 1, 1},
        {1, 1, 1, 1, 1, 1, 1, 1},
        {16.2, 16.2, 16.2, 16.2, 16.2, 16.2, 16.2, 16.2}
    }

#End Region

#Region "Water body data"

    Public Enum eWBMember

        Witdth
        Length
        Depth
        DistanceBankWater
        Factor

    End Enum

    Public Shared WaterBodyDB As Double(,) =
    {
        {1, 100, 0.3, 0.5, 1},
        {1, 100, 0.3, 1, 1.2},
        {30, 30, 1, 3, 1}
    }

#End Region

    Public Shared RunOffStreamDepths As Double() = {0.41, 0.3, 0.29, 0.41}

End Class

