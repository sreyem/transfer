﻿
Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Design
Imports System.Globalization
Imports System.Reflection
Imports System.Threading
Imports System.Windows.Forms
Imports System.Windows.Forms.Design
Imports System.IO
Imports Microsoft.Win32
Imports System.Management
Imports System.Xml.Serialization
Imports System.Web.Script.Serialization
Imports System.Runtime.Serialization
Imports System.Runtime.Serialization.Json
Imports System.Text
Imports System.IO.Compression

#Region "toolBox"

#Region "propGrid"

''' <summary>
''' TypeConverter(GetType(propGridConverter))
''' Make a class brows-able in the property grid
''' Name property should be defined!
''' </summary>
Public Class propGridConverter

    'usage : <TypeConverter(GetType(propGridConverter))>

    Inherits ExpandableObjectConverter

    'test

#Region "    Engine"

    <DebuggerStepThrough>
    Public Overloads Overrides Function CanConvertTo(
                                                ByVal context As ITypeDescriptorContext,
                                                ByVal destinationType As Type) As Boolean
        Try

            If (destinationType Is GetType(propGridConverter)) Then
                Return True
            End If

        Catch ex As Exception

        End Try

        Return MyBase.CanConvertTo(
                                context,
                                destinationType)

    End Function

    <DebuggerStepThrough>
    Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

        If (destinationType Is GetType(System.String)) Then

            Try

                Return CallByName(
                                value,
                                "Name",
                                CallType.Get)

            Catch ex As Exception
                Return " ... "
            End Try

        End If

        Return MyBase.ConvertTo(
                            context,
                            culture,
                            value,
                            destinationType)

    End Function

#End Region

End Class

''' <summary>
''' Show enum descriptions
''' TypeConverter(GetType(EnumConverter(of enumType))
''' </summary>
''' <typeparam name="T">
''' enum type
''' </typeparam>
Public Class enumConverter(Of T)

    'usage :  <TypeConverter(GetType(EnumConverter(of <Type>))>

    Inherits EnumConverter

    Public Const not_defined As String = " - "


    '' <summary>
    '' Initializing instance
    '' </summary>       
    '' <remarks></remarks>
    Public Sub New()
        MyBase.New(GetType(T))
    End Sub

    ''' <summary>
    ''' don't show enum members with this description
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property dontShow As String() = {}

    ''' <summary>
    ''' only show enum members with this description
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property onlyShow As String() = {}


    Public Shared no2Show As Integer = -1

#Region "    Engine"

    Public Overrides Function CanConvertTo(context As ITypeDescriptorContext, destType As Type) As Boolean
        Return destType = GetType(String)
    End Function

    Public Overrides Function ConvertTo(
                                    context As ITypeDescriptorContext,
                                    culture As CultureInfo,
                                    value As Object,
                                    destType As Type) As Object

        Dim fi As FieldInfo = GetType(T).GetField([Enum].GetName(GetType(T), value))
        Dim dna As DescriptionAttribute = DirectCast(
            Attribute.GetCustomAttribute(fi, GetType(DescriptionAttribute)), DescriptionAttribute)

        If dna IsNot Nothing Then

            If no2Show > -1 And dna.Description.Split(vbLf).Count > no2Show Then
                Return dna.Description.Split(vbLf)(no2Show).Split(vbCr).First
            Else
                Return dna.Description
            End If

        Else
            Return value.ToString()
        End If

    End Function

    Public Overrides Function CanConvertFrom(
                                            context As ITypeDescriptorContext,
                                            srcType As Type) As Boolean
        Return srcType = GetType(String)
    End Function

    Public Overrides Function ConvertFrom(
                                    context As ITypeDescriptorContext,
                                    culture As CultureInfo,
                                    value As Object) As Object

        Dim found As Boolean = False

        For Each member As String In dontShow

            If CStr(value).Contains(member) Then
                value = not_defined
            End If

        Next


        If onlyShow.Count <> 0 Then

            For Each member As String In onlyShow
                If CStr(value).Contains(member) Then
                    found = True
                    Exit For
                End If
            Next

            If Not found Then
                value = not_defined
            End If

        End If


        For Each fi As FieldInfo In GetType(T).GetFields()

            Dim dna As DescriptionAttribute =
                DirectCast(
                        Attribute.GetCustomAttribute(
                                element:=fi,
                                attributeType:=GetType(DescriptionAttribute)),
                        DescriptionAttribute)

            If (dna IsNot Nothing) AndAlso
                    (dna.Description).Contains(DirectCast(value, String)) Then
                '(DirectCast(value, String).Contains(dna.Description)) Then
                Return [Enum].Parse(GetType(T), fi.Name)
            End If

        Next

        Return [Enum].Parse(GetType(T), DirectCast(value, String))

    End Function

#End Region

    ''' <summary>
    ''' returns the enum description
    ''' </summary>
    ''' <param name="EnumConstant"></param>
    ''' <returns></returns>
    <DebuggerStepThrough>
    Public Shared Function getEnumDescription(ByVal EnumConstant As [Enum]) As String

        Dim fi As FieldInfo =
            EnumConstant.GetType().GetField(EnumConstant.ToString())

        Dim attr() As DescriptionAttribute =
                      DirectCast(fi.GetCustomAttributes(GetType(DescriptionAttribute),
                      False), DescriptionAttribute())

        If attr.Length > 0 Then
            Return attr(0).Description
        Else
            Return EnumConstant.ToString()
        End If

    End Function

End Class


''' <summary>
''' double to string converter
''' AttributeProvider(
''' format , minValue , unit , country , minSign , digits , negDef  
''' </summary>
Public Class dblConv

    Inherits DoubleConverter

    'usage : 
    '<TypeConverter(GetType(dblConvPara))>
    '<AttributeProvider("format= 'G5'|unit=' kg/ha'")>

#Region "    get/set parameters"

    Public Shared Function getDblParameter(context As ITypeDescriptorContext) As String()

        Dim Attributes As AttributeCollection
        Dim Provider As AttributeProviderAttribute

        Dim formatArray As String() = {}

        Try

            With context

                Attributes = .PropertyDescriptor.Attributes

                For Each attribute In Attributes

                    If attribute.ToString =
                        "System.ComponentModel.AttributeProviderAttribute" Then

                        Provider = attribute
                        formatArray = Provider.TypeName.Split("|")

                    End If

                Next

            End With
        Catch ex As Exception

        End Try

        For counter As Integer = 0 To formatArray.Count - 1
            formatArray(counter) = Trim(formatArray(counter))
        Next

        Return formatArray

    End Function

    Public Shared Sub setDblParameters(formatArray As String())

        Dim parameterValue As String()

        setStd()

        For Each member As String In formatArray

            parameterValue = member.Split("=")
            parameterValue(0) = Trim(parameterValue(0))
            parameterValue(1) = parameterValue(1).Split("'")(1)

            Select Case parameterValue.First

                Case "format"
                    dblformat = parameterValue.Last

                Case "country"

                    Try
                        country =
                            [Enum].Parse(
                            enumType:=GetType(eCountry),
                            value:=parameterValue.Last)
                    Catch ex As Exception
                        country = stdCountry
                    End Try

                Case "minSign"
                    minSign = parameterValue.Last

                Case "minValue"
                    minValue = parameterValue.Last

                Case "digits"
                    digits = parameterValue.Last

                Case "negDef"
                    negDef = parameterValue.Last

                Case "unit"
                    unit = parameterValue.Last

            End Select

        Next

    End Sub

    Public Shared Sub setStd()

        country = stdCountry
        dblformat = stdDblformat
        emptyString = stdEmptyString
        minSign = stdMinSign
        minValue = stdMinValue
        digits = stdDigits
        unit = ""
        negDef = stdnegDef

    End Sub

#End Region

#Region "    engine"

    <DebuggerStepThrough>
    Public Overrides Function ConvertTo(
                            context As ITypeDescriptorContext,
                            culture As CultureInfo,
                            value As Object,
                            destType As Type) As Object


        setDblParameters(formatArray:=getDblParameter(context:=context))

        Try

            Return _
              conv2String(
                    value:=value,
                    format:=dblformat,
                    country:=country,
                    minSign:=minSign,
                    minValue:=minValue,
                    unit:=unit,
                    digits:=digits,
                    negativeDefined:=negDef)

        Catch ex As Exception
            Return value
        End Try

    End Function

    <DebuggerStepThrough>
    Public Overrides Function ConvertFrom(
                            context As ITypeDescriptorContext,
                            culture As CultureInfo,
                            value As Object) As Object

        Dim valueString As String

        Try

            valueString = CType(value, String)

            If valueString.Contains(minSign) Then
                Return minValue
            ElseIf Double.IsNaN(Double.Parse(valueString)) Then
                Return Double.NaN
            Else
                Return Double.Parse(valueString)
            End If

        Catch ex As Exception
            Return Double.NaN
        End Try

    End Function

#End Region

#Region "    functions"

    Public Shared Function conv2String(
                                 value As Double,
                        Optional format As String = stdDblformat,
                        Optional country As eCountry = stdCountry,
                        Optional minValue As Double = stdMinValue,
                        Optional minSign As String = stdMinSign,
                        Optional digits As Integer = stdDigits,
                        Optional unit As String = stdUnit,
                        Optional negativeDefined As Boolean = stdnegDef) As String

        Dim countryString As String

        countryString =
                    Replace(
                    Expression:=country.ToString,
                    Find:="_", Replacement:="-",
                    Compare:=CompareMethod.Text)

        If value < 0 And Not negativeDefined Then
            Return stdEmptyString
        End If

        If Not Double.IsNaN(minValue) AndAlso value < minValue Then
            Return minSign & minValue.ToString & unit
        End If

        If Double.IsNaN(Double.Parse(value)) Then
            Return stdEmptyString
        End If

        Try

            If digits > -1 Then

                value =
                    Math.Round(
                        value,
                        digits:=digits)

            End If

            Return value.ToString(
                              format:=format,
                            provider:=CultureInfo.CreateSpecificCulture(countryString)) & unit

        Catch ex As Exception

            Console.WriteLine("error converting double to string")
            Return ex.Message

        End Try

    End Function

#End Region

#Region "    definitions"

    Public Enum eCountry
        de_DE
        en_US
        fr_FR
    End Enum

#Region "    shared"

    Public Shared country As eCountry = stdCountry
    Public Shared dblformat As String = stdDblformat
    Public Shared emptyString As String = stdEmptyString
    Public Shared minSign As String = stdMinSign
    Public Shared minValue As Double = stdMinValue
    Public Shared digits As Integer = stdDigits
    Public Shared unit As String = ""
    Public Shared negDef As Boolean = stdnegDef

#End Region

#Region "    constants"

    Public Const stdCountry As eCountry = eCountry.en_US
    Public Const stdEmptyString As String = " - "

    Public Const stdDblformat As String = "G4"
    Public Const stdMinSign As String = "<"
    Public Const stdMinValue As Double = Nothing
    Public Const stdDigits As Integer = -1
    Public Const stdUnit As String = ""
    Public Const stdnegDef As Boolean = False

#End Region

#End Region

End Class

''' <summary>
''' date to string converter
''' AttributeProvider(
''' format, julian = add/only/none, country
''' </summary>
Public Class dateConv

    Inherits DateTimeConverter

    '<TypeConverter(GetType(dateConv)>

#Region "    get/set parameters"

    Public Shared Sub setStd()

        country = stdCountry
        dateFormat = stdDateFormat
        emptyString = stdEmptyString

    End Sub

    Public Shared Function getDateParameter(context As ITypeDescriptorContext) As String()

        Dim Attributes As AttributeCollection
        Dim Provider As AttributeProviderAttribute

        Dim formatArray As String() = {}

        Try

            With context

                Attributes = .PropertyDescriptor.Attributes

                For Each attribute In Attributes

                    If attribute.ToString =
                        "System.ComponentModel.AttributeProviderAttribute" Then

                        Provider = attribute
                        formatArray = Provider.TypeName.Split("|")

                    End If

                Next

            End With

        Catch ex As Exception

        End Try

        Return formatArray

    End Function

    Public Shared Sub setDateParameters(formatArray As String())

        Dim parameterValue As String()

        setStd()

        For Each member As String In formatArray

            parameterValue = member.Split("=")
            parameterValue(0) = Trim(parameterValue(0))
            parameterValue(1) = parameterValue(1).Split("'")(1)

            Select Case parameterValue.First

                Case "format"
                    dateFormat = parameterValue.Last

                Case "country"

                    Try
                        country =
                            [Enum].Parse(
                            enumType:=GetType(eCountry),
                            value:=parameterValue.Last)
                    Catch ex As Exception
                        country = stdCountry
                    End Try

                Case "julian"

                    Try

                        julian =
                            [Enum].Parse(
                            enumType:=GetType(eJulian),
                            value:=parameterValue.Last)

                    Catch ex As Exception
                        julian = stdJulian
                    End Try

            End Select

        Next

    End Sub

#End Region

#Region "    engine"


    <DebuggerStepThrough>
    Public Overrides Function ConvertTo(
                            context As ITypeDescriptorContext,
                            culture As CultureInfo,
                            value As Object,
                            destType As Type) As Object

        setDateParameters(
            formatArray:=getDateParameter(
                            context:=context))

        Try
            If CType(value, Date) = Date.MinValue OrElse
               CType(value, Date) = New Date Then

                Return emptyString

            Else

                Return _
                convDate2String(
                        value:=value,
                        format:=dateFormat,
                        julian:=julian,
                        emptyString:=emptyString,
                        country:=country)

            End If
        Catch ex As Exception
            Return emptyString
        End Try



    End Function

    <DebuggerStepThrough>
    Public Overrides Function ConvertFrom(
                            context As ITypeDescriptorContext,
                            culture As CultureInfo,
                            value As Object) As Object

        Try

            If CType(value, Date) = New Date Then
                Return New Date
            Else
                Return Date.Parse(CType(value, String))
            End If

        Catch ex As Exception
            Return New Date
        End Try

    End Function

#End Region

#Region "    functions"

    ''' <summary>
    ''' converts a date to a string
    ''' </summary>
    ''' <param name="value"></param>
    ''' <param name="format"></param>
    ''' <param name="julian"></param>
    ''' <param name="emptyString"></param>
    ''' <param name="country"></param>
    ''' <returns></returns>
    Public Shared Function convDate2String(
                                       value As Date,
                              Optional format As String = stdDateFormat,
                              Optional julian As eJulian = stdJulian,
                              Optional emptyString As String = stdEmptyString,
                              Optional country As eCountry = stdCountry) As String

        Dim countryString As String
        Dim out As String = ""

        countryString =
                    Replace(
                    Expression:=country.ToString,
                    Find:="_", Replacement:="-",
                    Compare:=CompareMethod.Text)
        Try

            If value = New Date OrElse IsNothing(value) Then
                Return emptyString
            End If

            out = value.ToString(
                                format:=format,
                                provider:=CultureInfo.CreateSpecificCulture(countryString))

            Select Case julian

                Case eJulian.none

                Case eJulian.add
                    out &= " (" & value.DayOfYear.ToString.PadLeft(3) & ")"

                Case eJulian.only
                    out = value.DayOfYear.ToString()

            End Select

            Return out

        Catch ex As Exception
            Return emptyString
        End Try


    End Function

#End Region

#Region "    definitions"

    Public Enum eCountry
        de_DE
        en_US
        fr_FR
    End Enum

    Public Enum eJulian
        add
        only
        none
    End Enum

#Region "    shared"

    Public Shared country As eCountry = stdCountry
    Public Shared emptyString As String = stdEmptyString

    Public Shared julian As eCountry = stdJulian
    Public Shared dateFormat As String = stdDateFormat

#End Region

#Region "    constants"

    Public Const stdCountry As eCountry = eCountry.en_US
    Public Const stdEmptyString As String = " - "

    Public Const stdDateFormat As String = "dd. MMM"
    Public Const stdJulian As eJulian = eJulian.add

#End Region

#End Region


End Class


''' <summary>
''' Multi line editor for string properties
''' change FontName and FontSize
''' used by adding
''' [Editor(GetType(MultiLineTextArrayEditor), GetType(UITypeEditor))]
''' </summary>
''' <remarks></remarks>
Public Class multiLineDoubleArrayEditor

    Inherits UITypeEditor

    ' usage :  add 
    '<Editor(GetType(MultiLineTextArrayEditor), GetType(UITypeEditor))>
    ' to property

    Public Shared FontName As String = "Courier New"
    Public Shared FontSize As Integer = 10
    Public Shared Width As Integer = 250
    Public Shared Height As Integer = 150
    Public Shared AcceptsReturn As Boolean = True


    Private editorService As IWindowsFormsEditorService

    Public Overrides Function GetEditStyle(
                            context As ITypeDescriptorContext) As UITypeEditorEditStyle
        Return UITypeEditorEditStyle.Modal
    End Function

    Public Overrides Function EditValue(
                            context As ITypeDescriptorContext,
                           provider As IServiceProvider,
                              value As Object) As Object

        editorService = DirectCast(
            provider.GetService(GetType(IWindowsFormsEditorService)),
            IWindowsFormsEditorService)

        Dim txtBox As New TextBox()
        Dim temp As New List(Of String)
        Dim out As New List(Of Double)

        With txtBox

            .Multiline = True

            .Font = New Font(
                familyName:=FontName,
                    emSize:=FontSize)

            .ScrollBars = ScrollBars.Both
            .BorderStyle = BorderStyle.None

            .Width = Width
            .Height = Height

            .AcceptsReturn = AcceptsReturn

            For Each member As Double In value

                Try
                    temp.Add(member.ToString)
                Catch ex As Exception
                    temp.Add("parsing error")
                End Try
            Next

            txtBox.Text = Join(SourceArray:=temp.ToArray, Delimiter:=vbCrLf)

        End With

        editorService.DropDownControl(txtBox)

        temp.Clear()
        temp.AddRange(txtBox.Text.Split(CChar(vbCrLf)))

        For Each member As String In temp

            Try
                out.Add(Double.Parse(Trim(member)))
            Catch ex As Exception
                out.Add(Double.NaN)
            End Try

        Next

        Return out.ToArray

    End Function

End Class


''' <summary>
''' adds a drop down field
''' </summary>
Public Class dropDownList

    Inherits StringConverter

    ' usage :  add 
    ' <TypeConverter(GetType(dropDownList))>
    ' to property
    Public Overloads Shared Property dropDownEntries As String() = {"add", "own", "entries"}

#Region "Overloads Overrides"

    Public Overloads Overrides Function GetStandardValuesSupported(ByVal context As ITypeDescriptorContext) As Boolean
        Return True
    End Function

    Public Overloads Overrides Function GetStandardValues(ByVal context As ITypeDescriptorContext) As StandardValuesCollection
        Return New StandardValuesCollection(DropDownEntries)
    End Function

    Public Overloads Overrides Function GetStandardValuesExclusive(ByVal context As ITypeDescriptorContext) As Boolean
        Return False
    End Function

#End Region

End Class


''' <summary>
''' on click enabler
''' [Editor(GetType(buttonEmulator), GetType(UITypeEditor))]
''' </summary>
Public Class buttonEmulator

    Inherits UITypeEditor

    'use : <Editor(GetType(buttonEmulator), GetType(UITypeEditor))>
    Public Shared Clicked As String = "Clicked"

#Region "Overloads Overrides"

    Public Overrides Function GetEditStyle(context As ITypeDescriptorContext) As UITypeEditorEditStyle
        Return UITypeEditorEditStyle.Modal
    End Function

    Public Overrides Function EditValue(context As ITypeDescriptorContext,
                                        provider As IServiceProvider,
                                        value As Object) As Object

        value = Clicked

        Return MyBase.EditValue(context,
                                    provider,
                                    value)

    End Function

#End Region

End Class



#End Region

#Region "myLog"

<DebuggerStepThrough()>
Public Module log

#Region "Settings"

    ''' <summary>
    ''' Contend of the log
    ''' </summary>
    ''' <remarks></remarks>
    Public LogList As New List(Of String)

    ''' <summary>
    ''' Log Filename
    ''' </summary>
    ''' <remarks></remarks>
    Public FileName As String = ""

    Public Enum eLogLevel
        std = -1
        init = 0
        one
        two
        three
        up
        down
    End Enum

    ''' <summary>
    ''' Intent level
    ''' </summary>
    ''' <remarks></remarks>
    Public stdIntentLevel As eLogLevel = eLogLevel.init

    ''' <summary>
    ''' No of spaces per intent level
    ''' </summary>
    ''' <remarks></remarks>
    Public IntentSpacePerLevel As Integer = 3


    Public FirstIntentChar As Char = "|"c

    ''' <summary>
    ''' std. time stamp at the start of the log line
    ''' </summary>
    ''' <remarks></remarks>
    Public Const StdTimeStampPattern As String = "hh:mm"

    Public Enum eLog2Console
        Yes
        No
        Only
    End Enum

    Public FilenameOK As Boolean = False

#End Region

#Region "Log and friends"

    ''' <summary>
    ''' log simple one line msg
    ''' </summary>
    ''' <param name="LogTxt">
    ''' Log msg as one line
    ''' </param>
    ''' <param name="IntentLevel">
    ''' Intent level as enum
    ''' std, init, on, two, three, up, down
    ''' </param>
    ''' <param name="Log2Console">
    ''' Log also to console, std. = on
    ''' </param>
    ''' <param name="Log2File">
    ''' Write log instantaneously to file, std. = on
    ''' </param>
    ''' <param name="Log2Msgbox">
    ''' Log also to MsgBox, std. = false
    ''' </param>
    ''' <param name="MsgBoxBtn">
    ''' If Log2MsgBox = true => Button
    ''' </param>
    ''' <param name="MsgTitle">
    ''' If Log2MsgBox = true => MsgTitle
    ''' ></param>
    ''' <param name="Add2PreviousRow">
    ''' If true log will be append to prev. row, std. = false
    ''' </param>
    ''' <param name="TimeStampPattern">
    ''' Std. = "hh:mm"
    ''' </param>
    ''' <param name="Exception2Throw">
    ''' Throw this exception
    ''' </param>
    ''' <param name="ShowInNotepad">
    ''' Show complete Log in Notepad, std. = false
    ''' </param>
    ''' <returns>
    ''' MsgBoxResult, like Yes, No or Cancel
    ''' </returns>
    Function mylog(
                LogTxt As String,
                Optional IntentLevel As eLogLevel = eLogLevel.std,
                Optional Log2Console As eLog2Console = eLog2Console.Yes,
                Optional Log2File As Boolean = True,
                Optional Log2MsgBox As Boolean = False,
                Optional MsgBoxBtn As MsgBoxStyle = MsgBoxStyle.Exclamation,
                Optional MsgTitle As String = "",
                Optional Add2PreviousRow As Boolean = False,
                Optional TimeStampPattern As String = "std",
                Optional Exception2Throw As Exception = Nothing,
                Optional ShowInNotepad As Boolean = False) As MsgBoxResult

        Dim TempList As New List(Of String)
        Dim TimeStamp As String
        Dim Intent As String = " "


        If Not IsNothing(Exception2Throw) Then

            If LogTxt <> String.Empty Then LogTxt &= vbCrLf

            LogTxt &= Join(parseExceptionMsg(
                                    Exception:=Exception2Throw,
                         UserErrorDescription:=LogTxt),
                                    Delimiter:=vbCrLf)

        End If

        Select Case IntentLevel

            Case eLogLevel.std
                IntentLevel = stdIntentLevel

            Case eLogLevel.init
                stdIntentLevel = IntentLevel

            Case eLogLevel.up

                If stdIntentLevel = eLogLevel.init Then IntentLevel = eLogLevel.one
                If stdIntentLevel = eLogLevel.one Then IntentLevel = eLogLevel.two
                If stdIntentLevel = eLogLevel.two Then IntentLevel = eLogLevel.three
                stdIntentLevel = IntentLevel

            Case eLogLevel.down

                If stdIntentLevel = eLogLevel.init Then IntentLevel = eLogLevel.std
                If stdIntentLevel = eLogLevel.one Then IntentLevel = eLogLevel.std
                If stdIntentLevel = eLogLevel.two Then IntentLevel = eLogLevel.one
                If stdIntentLevel = eLogLevel.three Then IntentLevel = eLogLevel.two
                stdIntentLevel = IntentLevel

        End Select

        Select Case IntentLevel

            Case eLogLevel.init
                Intent = " "

            Case eLogLevel.one
                Intent = " " & FirstIntentChar.ToString.PadRight(IntentSpacePerLevel)

            Case eLogLevel.two
                Intent = " " & FirstIntentChar.ToString.PadRight(IntentSpacePerLevel) &
                               FirstIntentChar.ToString.PadRight(IntentSpacePerLevel)

            Case eLogLevel.three
                Intent = " " & FirstIntentChar.ToString.PadRight(IntentSpacePerLevel) &
                               FirstIntentChar.ToString.PadRight(IntentSpacePerLevel) &
                               FirstIntentChar.ToString.PadRight(IntentSpacePerLevel)

        End Select


        Dim Lastlines As New List(Of String)

        Dim Txt2Log As String = ""

        'format time stamp + log level
        If TimeStampPattern = "std" Then
            TimeStampPattern = StdTimeStampPattern
        End If

        If TimeStampPattern = "" Then
            TimeStamp = " "
        Else
            TimeStamp = Now.ToString(StdTimeStampPattern) & " "
        End If

        'multi row log text without repeating time stamp
        If LogTxt.Contains(vbCrLf) OrElse
           LogTxt.Contains(vbLf) Then

            TempList.Clear()
            TempList.AddRange(LogTxt.Split(CChar(vbCrLf)))

            '1st row with time stamp
            'add to prev. row ?
            If Add2PreviousRow Then

                Txt2Log = Replace(
                            Expression:="".PadLeft(TimeStamp.Length) & Intent & TempList.First,
                                  Find:=vbCrLf,
                           Replacement:="")

            Else

                Txt2Log = Replace(
                            Expression:=TimeStamp & Intent & TempList.First,
                                  Find:=vbCrLf,
                           Replacement:="")

                Txt2Log = Replace(
                            Expression:=Txt2Log,
                                  Find:=vbLf,
                           Replacement:="")

            End If



            If Log2Console = eLog2Console.Only Then
                Console.WriteLine(Txt2Log)
            Else
                Console.WriteLine(Txt2Log)
                LogList.Add(Txt2Log)
            End If

            'all others without
            For counter As Integer = 1 To TempList.Count - 1

                Txt2Log = Replace(
                    Expression:=TempList(counter),
                          Find:=vbLf,
                   Replacement:="")


                If TimeStampPattern <> "" Then

                    Txt2Log = "".PadLeft(TimeStamp.Length) & Intent &
                    Txt2Log

                End If

                'log 2 console
                Select Case Log2Console

                    Case eLog2Console.Yes

                        Console.WriteLine(Txt2Log)
                        LogList.Add(Txt2Log)

                    Case eLog2Console.Only

                        Console.WriteLine(Txt2Log)

                    Case eLog2Console.No
                        LogList.Add(Txt2Log)

                End Select

            Next

        Else

            'single row log text
            If Add2PreviousRow Then
                LogList(LogList.Count - 1) = LogList.Last & LogTxt
            Else
                If TimeStampPattern = "" Then
                    LogList.Add(Intent & LogTxt)
                Else
                    LogList.Add(TimeStamp & Intent & LogTxt)
                End If
            End If

            'log 2 console
            Select Case Log2Console

                Case eLog2Console.Yes, eLog2Console.Only
                    Try
                        If Add2PreviousRow Then Console.CursorTop = Console.CursorTop - 1
                    Catch ex As Exception

                    End Try

                    Console.WriteLine(LogList(LogList.Count - 1))
                    'LogList.Add(LogTxt)

                Case eLog2Console.No

            End Select

        End If

        Try

            If Log2File Then

                If Not FilenameOK Then

                    resetLog()
                    FilenameOK = True

                End If

                File.WriteAllLines(path:=FileName,
                           contents:=LogList.ToArray)

            End If

            Try
                If ShowInNotepad Then showLogInNotepad()
            Catch ex As Exception

                Throw New Exception(message:="Can't show log file in editor" & vbCrLf & FileName,
                                innerException:=ex)

            End Try

        Catch ex As Exception

            Throw New Exception(message:="Can't write to log file" & vbCrLf & FileName,
                                innerException:=ex)

        End Try

        If Not IsNothing(Exception2Throw) Then
            Throw New Exception(
                       message:=LogTxt,
                innerException:=Exception2Throw)
        End If

        If Log2MsgBox Then

            Return MsgBox(Prompt:=LogTxt,
                         Buttons:=MsgBoxBtn,
                           Title:=MsgTitle)

        End If

        Return MsgBoxResult.Ok

    End Function

    ''' <summary>
    ''' Log array of strings
    ''' </summary>
    ''' <param name="LogTxtArray">
    ''' Array of strings to log
    ''' </param>
    ''' <param name="IntentLevel">
    ''' Intent level as enum
    ''' std,init,on,two,three,up,down
    ''' </param>
    ''' <param name="Log2Console">
    ''' Log also to console, std. = on
    ''' </param>
    ''' <param name="Log2File">
    ''' Write log instantaneously to file, std. = on
    ''' </param>
    ''' <param name="Log2Msgbox">
    ''' Log also to MsgBox, std. = false
    ''' </param>
    ''' <param name="MsgBoxBtn">
    ''' If Log2MsgBox = true => Button
    ''' </param>
    ''' <param name="MsgTitle">
    ''' If Log2MsgBox = true => MsgTitle
    ''' ></param>
    ''' <param name="Add2PreviousRow">
    ''' If true log will be append to prev. row, std. = false
    ''' </param>
    ''' <param name="TimeStampPattern">
    ''' Std. = "hh:mm"
    ''' </param>
    ''' <param name="Exception2Throw">
    ''' Throw this exception
    ''' </param>
    ''' <param name="ShowInNotepad">
    ''' Show complete Log in Notepad, std. = false
    ''' </param>
    ''' <returns></returns>
    Public Function mylog(
                        LogTxtArray As String(),
                        Optional IntentLevel As eLogLevel = eLogLevel.std,
                        Optional Log2Console As eLog2Console = eLog2Console.Yes,
                        Optional Log2File As Boolean = True,
                        Optional Log2MsgBox As Boolean = False,
                        Optional MsgBoxBtn As MsgBoxStyle = MsgBoxStyle.Exclamation,
                        Optional MsgTitle As String = "",
                        Optional Add2PreviousRow As Boolean = False,
                        Optional TimeStampPattern As String = "std",
                        Optional Exception2Throw As Exception = Nothing,
                        Optional ShowInNotepad As Boolean = False) As MsgBoxResult

        Return mylog(
                    LogTxt:=Join(LogTxtArray, vbCrLf),
                    IntentLevel:=IntentLevel,
                    Log2Console:=Log2Console,
                    Log2File:=Log2File,
                    Log2MsgBox:=Log2MsgBox,
                    MsgBoxBtn:=MsgBoxBtn,
                    MsgTitle:=MsgTitle,
                    TimeStampPattern:=TimeStampPattern,
                    Exception2Throw:=Exception2Throw,
                    ShowInNotepad:=ShowInNotepad)

    End Function

    ''' <summary>
    ''' Log multiple lines
    ''' </summary>
    ''' <param name="LogTxtList">
    ''' List of string of lines to log
    ''' </param>
    ''' <param name="IntentLevel">
    ''' Intent level as enum
    ''' std,init,on,two,three,up,down
    ''' </param>
    ''' <param name="Log2Console">
    ''' Log also to console, std. = on
    ''' </param>
    ''' <param name="Log2File">
    ''' Write log instantaneously to file, std. = on
    ''' </param>
    ''' <param name="Log2Msgbox">
    ''' Log also to MsgBox, std. = false
    ''' </param>
    ''' <param name="MsgBoxBtn">
    ''' If Log2MsgBox = true => Button
    ''' </param>
    ''' <param name="MsgTitle">
    ''' If Log2MsgBox = true => MsgTitle
    ''' ></param>
    ''' <param name="TimeStampPattern">
    ''' Std. = "hh:mm"
    ''' </param>
    ''' <param name="Exception2Throw">
    ''' Throw this exception
    ''' </param>
    ''' <param name="ShowInNotepad">
    ''' Show complete Log in Notepad, std. = false
    ''' </param>
    ''' <returns></returns>
    Public Function mylog(
                        LogTxtList As List(Of String),
                        Optional IntentLevel As eLogLevel = eLogLevel.std,
                        Optional Log2Console As eLog2Console = eLog2Console.Yes,
                        Optional Log2File As Boolean = True,
                        Optional Log2MsgBox As Boolean = False,
                        Optional MsgBoxBtn As MsgBoxStyle = MsgBoxStyle.Exclamation,
                        Optional MsgTitle As String = "",
                        Optional TimeStampPattern As String = "std",
                        Optional Exception2Throw As Exception = Nothing,
                        Optional ShowInNotepad As Boolean = False) As MsgBoxResult

        Return mylog(
                LogTxt:=Join(LogTxtList.ToArray, vbCrLf),
                IntentLevel:=IntentLevel,
                Log2Console:=Log2Console,
                Log2File:=Log2File,
                Log2MsgBox:=Log2MsgBox,
                MsgBoxBtn:=MsgBoxBtn,
                MsgTitle:=MsgTitle,
                TimeStampPattern:=TimeStampPattern,
                Exception2Throw:=Exception2Throw,
                ShowInNotepad:=ShowInNotepad)

    End Function

#End Region

#Region "Helper: getStartInfo, showLogInNotepad, resteLog"

    ''' <summary>
    ''' Basic app. infos
    ''' </summary>
    Public Function getStartInfo(Optional LeadingString As String = "") As String()

        Dim InfoList As New List(Of String)

        With InfoList

            Try
                With My.Application.Info
                    InfoList.Add(LeadingString & .ProductName & " v" & .Version.ToString)
                    InfoList.Add(LeadingString & .Title)
                    InfoList.Add(LeadingString & .Copyright)
                End With
            Catch ex As Exception
                InfoList.Add("No info about title and version !!")
            End Try


            .Add(LeadingString & "Started on " & Now.ToString("dddd, dd.MMM.yy"))
            .Add(LeadingString & "        at " & Now.ToString("hh:mm:ss"))
            .Add(LeadingString & "        by " & Environment.UserName)
            .Add(LeadingString & "on machine " & Environment.MachineName &
                                          " (" & Environment.ProcessorCount & " CPUs with " & GetCpuSpeed() & " GHz)")
            .Add(LeadingString & "        OS " & My.Computer.Info.OSFullName & " / " &
                                                 My.Computer.Info.OSPlatform & " / " &
                                                 My.Computer.Info.OSVersion)
            .Add(LeadingString & ".net       " & Get45PlusFromRegistry())
            .Add(LeadingString & "core       " & misc.getAssemblyVersion)
            .Add(LeadingString & "           ")
            .Add(LeadingString & "Culture    " & My.Application.Culture.ToString)
            .Add(LeadingString & "           " & "Numbers = " & Math.Round(Math.PI, 2).ToString)
            .Add(LeadingString & "           " & "Dates   = " & New Date(year:=1984, month:=10, day:=15).ToLongDateString)
            .Add(LeadingString & "           " & "CSV     = " & My.Application.Culture.NumberFormat.NumberGroupSeparator.ToString)

            Try
                .Add(LeadingString & "Exec.  Dir " & My.Application.Info.DirectoryPath.ToString)
                .Add(LeadingString & "Work   Dir " & Environment.CurrentDirectory)
                .Add(LeadingString & "Net avail. " & My.Computer.Network.IsAvailable.ToString &
                                                    " (" & Environment.UserDomainName & ")")
                .Add(LeadingString & "Log path   " & log.FileName)
            Catch ex As Exception
                .Add("No info about execution directory And/Or network !!")
            End Try

            .Add("----------------------------------------------------------------------")
            .Add("")

        End With

        Return InfoList.ToArray

    End Function


    ''' <summary>
    ''' Show log in editor
    ''' </summary>
    Public Sub showLogInNotepad()

        If FileName = "" Then Exit Sub

        Try
            Process.Start(FileName)
        Catch ex As Exception
            MsgBox(Prompt:="Can't show log file '" & FileName & "'" & vbCrLf & ex.Message,
                  Buttons:=MsgBoxStyle.Critical,
                    Title:="IO Error")
        End Try

    End Sub


    Public Function GetCpuSpeed() As Double
        Dim managementObject = New ManagementObject("Win32_Processor.DeviceID='CPU0'")
        Dim speed As UInteger = CUInt(managementObject("CurrentClockSpeed"))
        managementObject.Dispose()
        Return Math.Round(speed / 1000, digits:=2)
    End Function

    Private Function Get45PlusFromRegistry() As String

        Const subkey As String = "SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full\"

        Using ndpKey As RegistryKey =
            RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry32).OpenSubKey(subkey)

            If ndpKey IsNot Nothing AndAlso ndpKey.GetValue("Release") IsNot Nothing Then
                Return $".NET Framework Version: {CheckFor45PlusVersion(ndpKey.GetValue("Release"))}"
            Else
                Return ".NET Framework Version 4.5 or later is not detected."
            End If

        End Using
    End Function

    ' Checking the version using >= enables forward compatibility.
    Private Function CheckFor45PlusVersion(releaseKey As Integer) As String
        If releaseKey >= 528040 Then
            Return "4.8 or later"
        ElseIf releaseKey >= 461808 Then
            Return "4.7.2"
        ElseIf releaseKey >= 461308 Then
            Return "4.7.1"
        ElseIf releaseKey >= 460798 Then
            Return "4.7"
        ElseIf releaseKey >= 394802 Then
            Return "4.6.2"
        ElseIf releaseKey >= 394254 Then
            Return "4.6.1"
        ElseIf releaseKey >= 393295 Then
            Return "4.6"
        ElseIf releaseKey >= 379893 Then
            Return "4.5.2"
        ElseIf releaseKey >= 378675 Then
            Return "4.5.1"
        ElseIf releaseKey >= 378389 Then
            Return "4.5"
        End If
        ' This code should never execute. A non-null release key should mean
        ' that 4.5 or later is installed.
        Return "No 4.5 or later version detected"
    End Function


    Public Sub resetLog(Optional LogFileName As String = "",
                        Optional Logo As String() = Nothing,
                        Optional Clear As Boolean = True,
                        Optional ShowLogInNotepad As Boolean = False)

        Dim LogMsg As New List(Of String)

        If LogFileName = "" Then
            LogFileName = Path.Combine(My.Application.Info.DirectoryPath,
                                       My.Application.Info.ProductName & ".log")
        Else
            If Not Directory.Exists(Path.GetDirectoryName(LogFileName)) Then

                Throw New IOException(
                    message:="Directory does NOT exist : Can't write to" & vbCrLf &
                             "LogFileName = " & LogFileName)

                Exit Sub

            End If
        End If

        FileName = LogFileName
        FilenameOK = True

        If Clear Then LogList.Clear()

        If Not IsNothing(Logo) Then
            LogMsg.AddRange(Logo)
        End If

        LogMsg.AddRange(getStartInfo())

        mylog(LogTxtArray:=LogMsg.ToArray)

        If ShowLogInNotepad Then log.showLogInNotepad()

    End Sub

#End Region

    Public Function parseExceptionMsg(Exception As Exception,
                             Optional UserErrorDescription As String = "",
                             Optional LeadingString As String = "") As String()

        Const TargetAllignSpace As Integer = 8

        Dim Delimiter As String
        Dim ModuleDelimiter As String
        Dim RowDelimiter As String

        Dim StackTraceArray As String()
        Dim ErrorLineArray As String()
        Dim Output As New List(Of String)

        Dim ModuleRow As String = ""


        If UserErrorDescription <> "" Then Output.Add(UserErrorDescription)

        Output.Add(Exception.Message)

        'check if German or English error MSG
        If Exception.StackTrace.Contains("at ") Then

            'English
            Delimiter = "at "
            ModuleDelimiter = " in "
            RowDelimiter = ":line"

        ElseIf Exception.StackTrace.Contains("bei ") Then

            'German
            Delimiter = "bei "
            ModuleDelimiter = " in "
            RowDelimiter = ":Zeile"

        Else

            With Output

                .Add("Unknown language. can't parse error msg!")
                .Add("ErrorMsg".PadRight(TargetAllignSpace) & ": " & Exception.Message.ToString)
                .Add("StackTrace")
                .Add(Exception.StackTrace.ToString)

            End With

            Return Output.ToArray

        End If

        Try

            StackTraceArray = Split(Exception.StackTrace,
                                    Delimiter)
            StackTraceArray = Filter(StackTraceArray,
                                     ModuleDelimiter)

            'parse each msg
            For Each ErrorLine As String In StackTraceArray

                With Output

                    'Module name
                    ErrorLineArray = Split(ErrorLine,
                                           ModuleDelimiter)

                    ModuleRow = "Module".PadRight(TargetAllignSpace) & ": " &
                         Trim(ErrorLineArray.First)

                    If Output.Contains(ModuleRow) Then
                        Continue For
                    Else
                        .Add(ModuleRow)
                        ModuleRow = ""
                    End If


                    ErrorLineArray = Split(ErrorLineArray.Last,
                                           RowDelimiter)

                    'Where is the problem
                    .Add("in file".PadRight(TargetAllignSpace) & ": " &
                         Trim(ErrorLineArray.First))

                    .Add("at row".PadRight(TargetAllignSpace) & ": " &
                         Trim(Replace(ErrorLineArray.Last,
                                      ".", "")))

                End With

            Next

        Catch FatalException As Exception

            With Output

                .Add("Can't parse error msg!")
                .Add("ErrorMsg".PadRight(TargetAllignSpace) & ": " &
                                Exception.Message.ToString)
                .Add("StackTrace")
                .Add(Exception.StackTrace.ToString)
                .Add(FatalException.StackTrace.ToString)

            End With

        End Try

        For Counter As Integer = 0 To Output.Count - 1
            Output(Counter) = LeadingString & Output(Counter)
        Next


        If IsNothing(Exception.InnerException) Then
            Return Output.ToArray
        Else
            Output.Add(" ")
            Output.Add(" ")
            Output.Add("inner exception: ")
            Output.Add(" ")
            Output.AddRange(parseExceptionMsg(Exception:=Exception.InnerException))
        End If

        Return Output.ToArray

    End Function


End Module

#End Region

Module zipFileHandling

    Public Enum archiveAction
        Merge
        Replace
        [Error]
        Ignore
    End Enum

    Public Enum overwrite
        Always
        IfNewer
        Never
    End Enum

    Public Function addToArchive(
                ByVal archiveFullName As String,
                ByVal files As String(),
                ByVal Optional action As archiveAction = archiveAction.Replace,
                ByVal Optional fileOverwrite As overwrite = overwrite.IfNewer,
                ByVal Optional compression As CompressionLevel = CompressionLevel.Optimal,
                      Optional deleteOrig As Boolean = False) As Boolean

        Dim mode As ZipArchiveMode = ZipArchiveMode.Create
        Dim archiveExists As Boolean = File.Exists(archiveFullName)

        Select Case action
            Case archiveAction.Merge

                If archiveExists Then
                    mode = ZipArchiveMode.Update
                End If

            Case archiveAction.Replace

                If archiveExists Then
                    File.Delete(archiveFullName)
                End If

            Case archiveAction.[Error]

                If archiveExists Then
                    Throw New IOException(String.Format("The zip file {0} already exists.", archiveFullName))
                End If

            Case archiveAction.Ignore

                If archiveExists Then
                    Return True
                End If

            Case Else

        End Select

        Try

            Using archive As ZipArchive = ZipFile.Open(archiveFullName, mode)

                If mode = ZipArchiveMode.Create Then

                    For Each file As String In files

                        If System.IO.File.Exists(file) Then

                            archive.CreateEntryFromFile(
                                file, Path.GetFileName(file), compression)

                            If deleteOrig Then

                                Try

                                    mylog(LogTxt:="Try to delete " &
                                          Path.GetFileName(file).PadRight(10))

                                    System.IO.File.Delete(file)

                                    If System.IO.File.Exists(file) Then
                                        mylog(LogTxt:=" ... ERROR",
                                              Add2PreviousRow:=True)
                                    Else
                                        mylog(LogTxt:=" ... OK",
                                              Add2PreviousRow:=True)
                                    End If

                                Catch ex As Exception

                                    mylog(LogTxt:="Can't delete " & Path.GetFileName(file))
                                    mylog(LogTxt:=parseExceptionMsg(ex).First)

                                End Try

                            End If

                        Else
                            mylog(LogTxt:=file & " does NOT exist ???")
                        End If

                    Next

                Else

                    For Each file As String In files

                        Dim fileInZip = (From f In archive.Entries
                                         Where f.Name = Path.GetFileName(file)
                                         Select f).FirstOrDefault()

                        Select Case fileOverwrite
                            Case overwrite.Always

                                If fileInZip IsNot Nothing Then
                                    fileInZip.Delete()
                                End If

                                archive.CreateEntryFromFile(
                                                    sourceFileName:=file,
                                                    entryName:=Path.GetFileName(file),
                                                    compressionLevel:=compression)

                            Case overwrite.IfNewer

                                If fileInZip IsNot Nothing Then

                                    If fileInZip.LastWriteTime < System.IO.File.GetLastWriteTime(file) Then
                                        fileInZip.Delete()
                                        archive.CreateEntryFromFile(
                                                    sourceFileName:=file,
                                                    entryName:=Path.GetFileName(file),
                                                    compressionLevel:=compression)
                                    End If
                                Else
                                    archive.CreateEntryFromFile(
                                                    sourceFileName:=file,
                                                    entryName:=Path.GetFileName(file),
                                                    compressionLevel:=compression)
                                End If

                            Case overwrite.Never

                            Case Else

                        End Select

                        If deleteOrig Then
                            Try

                                mylog(LogTxt:="Delete " & Path.GetFileName(file).PadLeft(15))
                                System.IO.File.Delete(file)
                                mylog(LogTxt:=" ... OK", Add2PreviousRow:=True)

                            Catch ex As Exception

                                mylog(LogTxt:="Can't delete " & Path.GetFileName(file))
                                mylog(LogTxt:=parseExceptionMsg(ex).First)

                            End Try
                        End If

                    Next

                End If

                Return True

            End Using

        Catch ex As Exception

            mylog("Error during zip process")
            mylog(LogTxt:=parseExceptionMsg(ex).First)

            Return False

        End Try

    End Function


    Public Sub unzip2Path(zipFileName As String, TargetPath As String)

        ZipFile.ExtractToDirectory(
            sourceArchiveFileName:=zipFileName,
            destinationDirectoryName:=TargetPath)

    End Sub

    Public Sub zipPath(Path2Zip As String, zipFilePath As String)

        ZipFile.CreateFromDirectory(
            sourceDirectoryName:=Path2Zip,
            destinationArchiveFileName:=zipFilePath)

    End Sub

End Module

#Region "misc"

Public Module misc

    Public Const Multipy As Char = "×"c

    Public Sub setCulture(Optional CultureString As String = "en-US")
        Thread.CurrentThread.CurrentCulture =
            CultureInfo.CreateSpecificCulture(CultureString)
    End Sub

    Public Function getAssemblyVersion() As String
        Return GetType(misc).Assembly.GetName().Version.ToString
    End Function

    <DebuggerStepThrough>
    Public Function Integer2Roman(Number As Integer) As String

        Dim result As New System.Text.StringBuilder()

        Dim digitsValues As Integer() =
                {1, 4, 5, 9, 10, 40, 50, 90, 100, 400, 500, 900, 1000}
        Dim romanDigits As String() =
                {"I", "IV", "V", "IX", "X", "XL", "L", "XC", "C", "CD", "D", "CM", "M"}

        If Number = 0 Then Number = 1

        While Number > 0
            For i As Integer = digitsValues.Count() - 1 To 0 Step -1
                If Number \ digitsValues(i) >= 1 Then
                    Number -= digitsValues(i)
                    result.Append(romanDigits(i))
                    Exit For
                End If
            Next
        End While

        Return result.ToString()

    End Function

#Region "std. enums"

    <TypeConverter(GetType(enumConverter(Of eOnOff)))>
    Public Enum eOnOff

        <Description("On")>
        [On]

        <Description("Off")>
        [Off]

    End Enum

    <TypeConverter(GetType(enumConverter(Of eYesNo)))>
    Public Enum eYesNo

        <Description("Yes")>
        Yes

        <Description("No")>
        No

    End Enum

End Module

#End Region



#End Region

#Region "statistic"

''' <summary>
''' Descriptive statistic
''' </summary>
<TypeConverter(GetType(propGridConverter))>
<DefaultProperty("dataImporter")>
<Serializable>
Public Class statistic

#Region "    Constructors"

    ''' <summary>
    ''' Default constructor
    ''' </summary>
    Public Sub New()

    End Sub

    ''' <summary>
    ''' Complete constructor
    ''' </summary>
    ''' <param name="Data">
    ''' Array of double to analyze
    ''' </param>
    ''' <param name="Percentile">
    ''' Percentile, from 1 to 100
    ''' </param>
    ''' <param name="Base">
    ''' std deviation and variance
    ''' from sample or totality
    ''' </param>
    ''' <remarks></remarks>
    Public Sub New(
                  Data As Double(),
                  Optional Percentile As Integer = 80,
                  Optional Base As eSampleTotality = eSampleTotality.Sample,
                  Optional gaussNorm As Boolean = True)


        Me.data = Data
        Me.Percent = Percentile
        Me.Base = Base
        Me.norm = gaussNorm

        Analyze()

    End Sub

#End Region

#Region "    Calculations"

    ''' <summary>
    ''' Run the analysis to obtain descriptive information of the data
    ''' </summary>
    Public Function Analyze() As statistic

        Dim ZeroOrNeg As Boolean = False
        Dim SkewHelper As Double = 0
        Dim KurtHelper As Double = 0

        If data.Count = 0 Then Return New statistic

        Me.sortedData = New Double(data.Length - 1) {}
        Me.gauss = New Double(data.Length - 1) {}
        Me.order = New Integer(data.Length - 1) {}

#Region "        sort data, get order"

        For counter As Integer = 0 To order.Count - 1
            Me.order(counter) = counter + 1
            Me.sortedData(counter) = Me.data(counter)
        Next

        Dim temp As Double
        Dim tempOrder As Int16

        For outerCounter As Integer = 0 To order.Count - 1

            For innerCounter As Integer = 0 To order.Count - 1

                If sortedData(innerCounter) > sortedData(outerCounter) Then
                    temp = sortedData(innerCounter)
                    sortedData(innerCounter) = sortedData(outerCounter)
                    sortedData(outerCounter) = temp
                    tempOrder = order(innerCounter)
                    order(innerCounter) = order(outerCounter)
                    order(outerCounter) = tempOrder

                End If

            Next

        Next

        'Data.CopyTo(sortedData, 0)
        'Array.Sort(sortedData)

#End Region

        Me.n = data.Count
        Me.Min = sortedData.First
        Me.Max = sortedData.Last
        Me.Range = data.Max - data.Min

        'sum, .. of products, ... of reciprocals
        For i As Integer = 0 To data.Length - 1

            If i = 0 Then

                'init
                Me.Sum = data(i)
                Me.SumOfProducts = data(i)
                Me.SumOfReciprocalProducts = 1.0 / data(i)
                'Me.Arithmetic = data(i)

            Else

                Me.Sum += data(i)
                Me.SumOfProducts *= data(i)
                Me.SumOfReciprocalProducts += 1.0 / data(i)

            End If

            'data  <= 0  no geometric and harmonic mean
            If data(i) <= 0 Then ZeroOrNeg = True

        Next

        Me.Arithmetic = Me.Sum / n

        'data  <= 0  no geometric and harmonic mean
        If ZeroOrNeg Then
            Me.Geometric = Double.NaN
            Me.Harmonic = Double.NaN
        Else

            'https://support.office.com/en-us/article/geomean-function-045ff75c-0bb8-4748-831d-16c395804586?redirectSourcePath=%252fde-de%252farticle%252fGEOMITTEL-Funktion-d97b6117-3280-475d-ac88-7c7858adf58e
            Me.Geometric = Math.Pow(Me.SumOfProducts, 1.0 / n)

            'https://support.office.com/en-us/article/harmean-function-5efd9184-fab5-42f9-b1d3-57883a1d3bc6?redirectSourcePath=%252fde-de%252farticle%252fHARMITTEL-Funktion-b2d540ce-445f-4d31-a09d-021ca38fb416
            Me.Harmonic = 1.0 / (Me.SumOfReciprocalProducts / n)

        End If

        'sum of errors and error square, helper for kurtosis
        For i As Integer = 0 To data.Length - 1

            If i = 0 Then

                Me.SumOfError = Math.Abs(data(i) - Me.Arithmetic)
                Me.SumOfErrorSquare = (Math.Abs(data(i) - Me.Arithmetic)) ^ 2

                KurtHelper = (Math.Abs(data(i) - Me.Arithmetic)) ^ 4

            Else

                Me.SumOfError += Math.Abs(data(i) - Me.Arithmetic)
                Me.SumOfErrorSquare += (Math.Abs(data(i) - Me.Arithmetic)) ^ 2

                KurtHelper += (Math.Abs(data(i) - Me.Arithmetic)) ^ 4

            End If

        Next

        'https://support.office.com/de-de/article/VAR-S-Funktion-913633DE-136B-449D-813E-65A00B2B990B
        Me.Variance = Me.SumOfErrorSquare / (n - IIf(Me.Base = eSampleTotality.Sample, 1, 0))

        'https://support.office.com/en-us/article/STDEV-S-function-7D69CF97-0C1F-4ACF-BE27-F3E83904CC23
        Me.StdDeviation = Math.Sqrt(Me.Variance)

        'http://jumbo.uni-muenster.de/index.php?id=185
#Region "        Gauss norm. distribution"

        For i As Integer = 0 To gauss.Length - 1

            Try
                gauss(i) =
              Double.Parse(getGauss(
                value:=data(i),
                stdDeviation:=Me.StdDeviation,
                arithmeticMean:=Me.Arithmetic))

            Catch ex As Exception

            End Try

        Next

        If norm Then

            Dim maxgauss As Double = gauss.Max

            For i As Integer = 0 To gauss.Length - 1
                gauss(i) = Double.Parse((gauss(i) * 100 / maxgauss))
            Next

        End If

#End Region

        'https://welt-der-bwl.de/Variationskoeffizient
        Me.relativeVariance = Me.StdDeviation / Me.Arithmetic * 100


        ' the cum part of SKEW formula
        For i As Integer = 0 To data.Length - 1
            SkewHelper += Math.Pow((data(i) - Me.Arithmetic) / (Math.Sqrt(Me.SumOfErrorSquare / (n - 1))), 3)
        Next

        'https://support.office.com/en-us/article/skew-function-bdf49d86-b1ef-4804-a046-28eaea69c9fa
        Me.Skewness = n / (n - 1) / (n - 2) * SkewHelper

        'https://support.office.com/de-de/article/kurt-funktion-bc3a265c-5da4-4dcb-b7fd-c237789095ab
        Me.Kurtosis = ((n + 1) * n * (n - 1)) /
                        ((n - 2) * (n - 3)) * (KurtHelper /
                                           Me.SumOfErrorSquare ^ 2) - 3 * Math.Pow(n - 1, 2) /
                                  ((n - 2) * (n - 3))

        Me.FirstQuartile = calcPercentile(sortedData, 25)
        Me.ThirdQuartile = calcPercentile(sortedData, 75)
        Me.IQR = Me.ThirdQuartile - Me.FirstQuartile
        Me.Median = calcPercentile(sortedData, 50)
        Me.Percentile = calcPercentile(sortedData, Me.Percent)

        Return Me

    End Function

#Region "     Percentile"

    ''' <summary>
    ''' Percentile
    ''' </summary>
    ''' <param name="percent">Percentile, between 0 to 100</param>
    ''' <returns>Percentile</returns>
    Public Function calcPercentile(percent As Double) As Double
        Return Me.calcPercentile(sortedData, percent)
    End Function


    ''' <summary>
    ''' Calculate percentile of a sorted data set
    ''' </summary>
    ''' <param name="sortedData"></param>
    ''' <param name="p">Percentile as percent, 1 - 100</param>
    ''' <returns></returns>
    Public Function calcPercentile(sortedData As Double(), p As Double) As Double

        If IsNothing(sortedData) Then Return 0

        Try

            ' algorithm derived from Aczel pg 15 bottom
            If p >= 100.0 Then
                Return sortedData(sortedData.Length - 1)
            End If

            Dim position As Double = CDbl(sortedData.Length + 1) * p / 100.0
            Dim leftNumber As Double = 0.0, rightNumber As Double = 0.0

            Dim n As Double = p / 100.0 * (sortedData.Length - 1) + 1.0

            If position >= 1 Then
                leftNumber = sortedData(CInt(System.Math.Floor(n)) - 1)
                rightNumber = sortedData(CInt(System.Math.Floor(n)))
            Else
                leftNumber = sortedData(0)
                ' first data
                ' first data
                rightNumber = sortedData(1)
            End If

            If leftNumber = rightNumber Then
                Return leftNumber
            Else
                Dim part As Double = n - System.Math.Floor(n)
                Return leftNumber + part * (rightNumber - leftNumber)
            End If

        Catch ex As Exception
            Return Double.NaN
        End Try

    End Function

    'Private Shared Function InlineAssignHelper(Of T)(ByRef target As T, value As T) As T
    '    target = value
    '    Return value
    'End Function

#End Region

    'http://jumbo.uni-muenster.de/index.php?id=185
    Public Function getGauss(
                        value As Double,
                        stdDeviation As Double,
                        arithmeticMean As Double) As Double

        Dim temp01 As Double
        Dim temp02 As Double

        Try

            temp01 = 1 /
                        (stdDeviation * Math.Sqrt(2 * Math.PI))

            temp02 = Math.Exp(-0.5 * Math.Pow(
                                          x:=(value - arithmeticMean) / stdDeviation,
                                          y:=2))

        Catch ex As Exception
            Return Double.NaN
        End Try


        Return temp01 * temp02

    End Function

#End Region

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Public Const CATBasic As String = "01 Basic"
#Region "    Basic"


    ''' <summary>
    ''' name to display and for .tostring
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
    "Name")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATBasic)>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    Public Overridable Property name As String

#Region "    Data"

    ''' <summary>
    ''' add a single value to the dataset
    ''' </summary>
    ''' <param name="value">data point as double</param>
    Public Sub addValue(value As Double)

        Dim temp As New List(Of Double)

        If IsNothing(Me.data) OrElse
           IsNothing(value) Then
            Exit Sub
        End If

        temp.AddRange(Me.data)
        temp.Add(value)

        Me.data = temp.ToArray

    End Sub

    ''' <summary>
    ''' add multiple values to the dataset
    ''' </summary>
    ''' <param name="values">data points as array of double</param>
    Public Sub addValue(values As Double())

        Dim temp As New List(Of Double)

        If IsNothing(Me.data) OrElse
           IsNothing(values) Then
            Exit Sub
        End If

        temp.AddRange(Me.data)
        temp.AddRange(values)

        Me.data = temp.ToArray

    End Sub

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _dataImporter As String() = {}

    ''' <summary>
    ''' orig.data is used to calculate percentiles
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
    "Data  importer")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATBasic)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property dataImporter As String()
        Get
            Return _dataImporter
        End Get
        Set

            Dim tempDbl As New List(Of Double)
            Dim tempString As New List(Of String)

            For Each member As String In Value

                Try
                    tempDbl.Add(Double.Parse(Trim(member)))
                    tempString.Add(tempDbl.Last.ToString)
                Catch ex As Exception

                End Try

            Next

            _data = tempDbl.ToArray
            Analyze()

            _dataImporter = Value

        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _data As Double()

    ''' <summary>
    ''' orig.data is used to calculate percentiles
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
    "Data, as double")>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATBasic)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property data As Double()
        Get
            Return _data
        End Get
        Set(value As Double())

            Dim temp As New List(Of String)

            For Each member As Double In value
                temp.Add(member.ToString)
            Next

            _dataImporter = temp.ToArray
            _data = value

            Analyze()

        End Set
    End Property


    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _sortedData As Double()

    ''' <summary>
    ''' sortedData is used to calculate percentiles
    ''' </summary>
    ''' <returns></returns>
    <XmlIgnore> <ScriptIgnore>
    <DisplayName(
    " '' , sorted")>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATBasic)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property sortedData As Double()
        Get
            Return _sortedData
        End Get
        Set
            _sortedData = Value
        End Set
    End Property

    ''' <summary>
    ''' sortedData is used to calculate percentiles
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
    " '' , order")>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATBasic)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property order As Integer()

#End Region

    ''' <summary>
    ''' Count
    ''' </summary>
    <Description(
    "Number of elements")>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATBasic)>
    <XmlIgnore> <ScriptIgnore>
    Public Property n As Integer

    ''' <summary>
    ''' Sum
    ''' </summary>
    <Description(
    "Sum of elements")>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATBasic)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property Sum As Double = Double.NaN


    ''' <summary>
    ''' The range of the values
    ''' </summary>
    <Description(
    "Range of the values")>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATBasic)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property Range As Double = Double.NaN

#End Region

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Public Const CATMeans As String = "02 Mean"
#Region "    Mean"

    ''' <summary>
    ''' Arithmetic mean
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATMeans)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    <Description(
    "(a1 + a2  +...+ an)/n")>
    Public Property Arithmetic As Double = Double.NaN

    ''' <summary>
    ''' Geometric mean
    ''' </summary>
    ''' 
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATMeans)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    <Description(
    "(a1 * a2 *...* an)^1/n" & vbCrLf &
    "not def. if any value is 0 or neg.")>
    Public Property Geometric As Double = Double.NaN

    ''' <summary>
    ''' Harmonic mean
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATMeans)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    <Description(
    "n(1/a1 + 1/a2 +...+ 1/an)" & vbCrLf &
    "not def. if any value is 0 or neg.")>
    Public Property Harmonic As Double = Double.NaN

    ''' <summary>
    ''' Median, or second quartile, or at 50 percentile
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATMeans)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    <Description("= second quartile or 50th percentile")>
    Public Property Median As Double = Double.NaN

#End Region

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Public Const CATWhisker As String = "03 Whisker"
#Region "    Whisker"

    ''' <summary>
    ''' Minimum value
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATWhisker)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property Min As Double = Double.NaN

    ''' <summary>
    ''' First quartile, at 25 percentile
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATWhisker)>
    <DisplayName(
    "1st Quartile")>
    <Description(
    "First quartile = 25th percentile")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property FirstQuartile As Double = Double.NaN

    ''' <summary>
    ''' Interquartile range
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATWhisker)>
    <DisplayName(
    "IQR")>
    <Description(
    "Inter Quartile Range")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property IQR As Double = Double.NaN

    ''' <summary>
    ''' Third quartile, at 75 percentile
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATWhisker)>
    <DisplayName(
    "3rd Quartile")>
    <Description(
    "Third Quartile")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property ThirdQuartile As Double = Double.NaN

    ''' <summary>
    ''' Maximum value
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATWhisker)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property Max As Double = Double.NaN

    <DebuggerBrowsable(False)>
    Private m_Percent As Double = 80

    ''' <summary>
    ''' Percentile
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATWhisker)>
    <DisplayName(
    "Percentile")>
    <Description(
    "Percentile in percent 0 - 100%")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    <DefaultValue(80)>
    Public Property Percent As Double
        Get
            Return m_Percent
        End Get
        Set(value As Double)

            m_Percent = value
            Percentile = calcPercentile(percent:=Me.Percent)

        End Set
    End Property

    ''' <summary>
    ''' Percentile
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATWhisker)>
    <DisplayName(
    "Value")>
    <Description(
    "Percentile value")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property Percentile As Double = Double.NaN

    ''' <summary>
    ''' Percentile of PEC values
    ''' Arithmetic mean of 16th and 17th value
    ''' </summary>
    ''' <returns></returns>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATWhisker)>
    <DisplayName(
    "PECgw Perc.")>
    <Description(
    "Percentile  of PEC values" & vbCrLf &
    "Arithmetic mean of 16th and 17th value")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public ReadOnly Property stdPECgwPercentile
        Get

            If n = 20 Then

                Return (sortedData(15) + sortedData(16)) / 2

            Else
                Return Double.NaN
            End If
        End Get
    End Property

#End Region

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Public Const CATStatistic As String = "04 Statistic"
#Region "    Statistic"

    Public Enum eSampleTotality
        Sample
        Totality
    End Enum

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private m_Base As eSampleTotality = eSampleTotality.Sample

    ''' <summary>
    ''' Sample or Totality
    ''' for std. deviation and variance
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATStatistic)>
    <DisplayName("Sample or Totality")>
    <RefreshProperties(RefreshProperties.All)>
    <DefaultValue(CInt(eSampleTotality.Sample))>
    <XmlIgnore> <ScriptIgnore>
    Public Property Base As eSampleTotality
        Get
            Return m_Base
        End Get
        Set(value As eSampleTotality)
            m_Base = value
            Analyze()
        End Set
    End Property

    ''' <summary>
    ''' Sample variance
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatistic)>
    <DisplayName(
    "Variance")>
    <Description(
    "Sum of error^2 / (n - 1{Sample}, 0{Total})" & vbCrLf &
    "EXCEL : VARIANZA sample; VARIANZENA totality" & vbCrLf &
    "1/n * (a1^2 + a2^2 + ... + an^2) - mean^2")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property Variance As Double = Double.NaN

    ''' <summary>
    ''' Sample variance
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatistic)>
    <DisplayName(
    "Relative Variance in %")>
    <Description(
    "std deviation / mean" & vbCrLf &
    "EXCEL : VARIANZA sample; VARIANZENA totality")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property relativeVariance As Double = Double.NaN

    ''' <summary>
    ''' Sample standard deviation
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatistic)>
    <DisplayName(
    "Std. Deviation")>
    <Description(
    "sqrt(Variance)" & vbCrLf &
    "EXCEL : STABWA sample; STABWNA totality")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property StdDeviation As Double = Double.NaN

    ''' <summary>
    ''' orig.data is used to calculate percentiles
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
    "Gaussian distribution")>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatistic)>
    <RefreshProperties(RefreshProperties.All)>
    <XmlIgnore> <ScriptIgnore>
    Public Property gauss As Double()

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Private _norm As Boolean = False

    ''' <summary>
    ''' orig.data is used to calculate percentiles
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
    " '     ' norm. to 100?")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATStatistic)>
    <RefreshProperties(RefreshProperties.All)>
    <DefaultValue(False)>
    <XmlIgnore> <ScriptIgnore>
    Public Property norm As Boolean
        Get
            Return _norm
        End Get
        Set(value As Boolean)
            _norm = value
            Analyze()
        End Set
    End Property

    ''' <summary>
    ''' Skewness of the data distribution
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatistic)>
    <DisplayName(
    "Skewness")>
    <Description(
    "Measure of the asymmetry" & vbCrLf &
    "negative/positive: left/right tail; EXCEL schief")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property Skewness As Double = Double.NaN

    ''' <summary>
    ''' Kurtosis of the data distribution
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatistic)>
    <DisplayName(
    "Kurtosis")>
    <Description(
    "measure of the 'tailedness' of the probability distribution" & vbCrLf &
    "positive/negative: sharp/wide distirbution")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property Kurtosis As Double = Double.NaN

#End Region

    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
    Public Const CATStatHelper As String = "05 Helper"
#Region "    05 Helper"

    ''' <summary>
    ''' Sum of Error
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatHelper)>
    <DisplayName(
    "Sum of error")>
    <Description(
    "(|a1| - aver.) + (|a2| - aver.) + ... + (|a3| - aver.)")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property SumOfError As Double = Double.NaN

    ''' <summary>
    ''' The sum of the squares of errors
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatHelper)>
    <DisplayName(
    "Sum of error^2")>
    <Description(
    "(|a1| - aver.)^2 + (|a2| - aver.)^2 + ... + (|a3| - aver.)^2")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property SumOfErrorSquare As Double = Double.NaN


    ''' <summary>
    ''' Sum of Products
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatHelper)>
    <DisplayName(
    "Sum of products")>
    <Description(
    "a1 * a2 * ... * an")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property SumOfProducts As Double = Double.NaN

    ''' <summary>
    ''' Sum of reciprocal Products
    ''' </summary>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category(CATStatHelper)>
    <DisplayName(
    "Sum of reciprocal products")>
    <Description(
    "1/a1 + 1/a2 + ... + 1/an")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <XmlIgnore> <ScriptIgnore>
    Public Property SumOfReciprocalProducts As Double = Double.NaN

#End Region

End Class

#End Region

#Region "De-Serialization"

''' <summary>
''' Serialize a class to XML/SOAP/JSON or 
''' De serialize a class from XML/SOAP/JSON
''' </summary>
<DebuggerStepThrough>
Public Module DeSerialize

#Region "XML"

    ''' <summary>
    ''' Save to file
    ''' Serializes a class to an xml file
    ''' </summary>
    ''' <param name="Class2Save">
    ''' The class to serialize
    ''' </param>
    ''' <param name="ClassType">
    ''' = gettype(Class2Save)
    ''' </param>
    ''' <param name="XMLFileName">
    ''' Target filename for the xml
    ''' </param>
    ''' <param name="ShowInNotepad">
    ''' if true notepad will display the file
    ''' </param> 
    ''' <returns> true or false
    ''' </returns>
    ''' <remarks></remarks>
    Public Function Class2XML(ByVal Class2Save As Object,
                              ByVal ClassType As Type,
                              ByVal XMLFileName As String,
                              Optional ShowInNotepad As Boolean = False) As Boolean

        If Not Directory.Exists(Path.GetDirectoryName(XMLFileName)) Then

            Try
                My.Computer.FileSystem.CreateDirectory(
                    Path.GetDirectoryName(XMLFileName))
            Catch ex As Exception
                mylog(LogTxtArray:={"IO ERROR",
                                    "Not a valid xml Path",
                                    XMLFileName,
                                    Join(parseExceptionMsg(ex), vbCrLf)})
                Return False
            End Try

        End If

        Try

            Dim mySerializer As XmlSerializer =
                            New XmlSerializer(ClassType)

            Dim myWriter As IO.StreamWriter =
                        New IO.StreamWriter(XMLFileName)

            mySerializer.Serialize(myWriter, Class2Save)

            myWriter.Close()
            myWriter = Nothing

            mylog(
                 LogTxtArray:={"OK : XML Serializing ",
                 Class2Save.ToString,
                 "to : " & XMLFileName})

        Catch ex As Exception

            mylog(Log2MsgBox:=True, MsgBoxBtn:=MsgBoxStyle.Critical, MsgTitle:="ERROR : XML Serializing",
                 LogTxtArray:={"ERROR : XML Serializing ",
                              Class2Save.ToString,
                              "to : " & XMLFileName,
                              Join(
                                  SourceArray:=parseExceptionMsg(ex),
                                  Delimiter:=vbCrLf)},
                ShowInNotepad:=ShowInNotepad)
            Return False

        End Try

        Return True

    End Function

    ''' <summary>
    ''' Load xml to class
    ''' De-serializes an xml file to a class 
    ''' </summary>
    ''' <param name="ClassType">
    ''' = gettype(Class2Fill)
    ''' </param>
    ''' <param name="XMLFileName">
    ''' Target filename for the xml
    ''' </param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function XML2Class(ByVal ClassType As Type,
                              ByVal XMLFileName As String) As Object

        Dim TargetClass As New Object


        Dim xmlFile As String() = {}


        If Not File.Exists(XMLFileName) Then

            mylog(
                LogTxtArray:={"IO ERROR",
                              "Not a valid XML Path",
                               XMLFileName})
            Return Nothing

        End If

        Try

            xmlFile = File.ReadAllLines(XMLFileName)

        Catch ex As Exception

            mylog(
                LogTxtArray:={"IO ERROR",
                              "Can't read xml file",
                               XMLFileName})
            Return Nothing
        End Try


        ' Call the Deserialize method and cast to the object type.
        Try

            Dim mySerializer As XmlSerializer =
                                   New XmlSerializer(ClassType)

            ' To read the file, create a FileStream.
            Dim myFileStream As IO.FileStream =
                            New IO.FileStream(XMLFileName, IO.FileMode.Open)


            Dim type As Type = TargetClass.GetType()
            Dim typeName As String = type.FullName


            TargetClass = mySerializer.Deserialize(myFileStream)
            myFileStream.Close()

            Try
                'check for xmltype
                typeName = TargetClass.xmlname
            Catch ex As Exception

                'else compare 2nd row start with class name
                typeName = ClassType.Name.ToString

            End Try

            If Not xmlFile(1).StartsWith("<" & typeName) Then

                mylog(
                LogTxtArray:={"File does NOT fit to class!",
                              "XML   type : " & xmlFile(1),
                              "Class type : " & typeName & " | " & ClassType.ToString})

                Return Nothing

            End If

        Catch ex As Exception

            mylog(
                LogTxtArray:={"Error de-serializing class",
                              "from file " & XMLFileName,
                              "XML   type : " & xmlFile(1),
                              "Class type : " & ClassType.ToString,
                              parseExceptionMsg(ex).First})

            Return Nothing

        End Try

        mylog(
                LogTxtArray:={"OK : XML De-serialize",
                XMLFileName,
                "to : " & ClassType.ToString})



        'Try
        '    CallByName(
        '        TargetClass,
        '        "_MD5Hash",
        '        CallType.Set,
        '        MD5HashGenerator.GenerateKey(sourceObject:=TargetClass))

        'Catch ex As Exception

        'End Try

        Return TargetClass

    End Function

#End Region

#Region "SOAP"

    ''' <summary>
    ''' Serializes a class to a binary file
    ''' </summary>
    ''' <param name="Class2Save">
    ''' The class to serialize
    ''' </param>
    ''' <param name="BINFileName">
    ''' Target filename for the binary file
    ''' </param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function Class2SOAP(Class2Save As Object,
                               BINFileName As String) As Boolean

        Dim formatter As IFormatter
        Dim fileStream As FileStream = Nothing
        Dim strObject As String = ""

        If Not Directory.Exists(Path.GetDirectoryName(BINFileName)) Then

            Try
                My.Computer.FileSystem.CreateDirectory(Path.GetDirectoryName(BINFileName))
            Catch ex As Exception
                mylog(LogTxtArray:={"IO ERROR",
                                    "Not a valid bin Path",
                                    BINFileName,
                                    Join(parseExceptionMsg(ex), vbCrLf)})
            End Try

        End If


        Try


            fileStream = New FileStream(
                        path:=BINFileName,
                        mode:=FileMode.Create,
                      access:=FileAccess.Write)

            formatter = New Formatters.Binary.BinaryFormatter
            formatter.Serialize(
                    serializationStream:=fileStream,
                                  graph:=Class2Save)

            mylog(
                 LogTxtArray:={"OK : SOAP Serializing ",
                 Class2Save.ToString,
                 "to : " & BINFileName})

        Catch ex As Exception

            mylog(LogTxtArray:={"ERROR SOAP Serializing",
                                "SOAP File " & BINFileName,
                                "Class " & Class2Save.ToString,
                                 Join(parseExceptionMsg(ex), vbCrLf)})

            Return False

        Finally

            If fileStream IsNot Nothing Then
                fileStream.Close()
            End If

        End Try

        Return True

    End Function


    ''' <summary>
    ''' De-serializes an binary file to a class
    ''' </summary>
    ''' <param name="BINFileName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function SOAP2Class(BINFileName As String) As Object

        Dim formatter As IFormatter
        Dim fileStream As FileStream = Nothing
        Dim objectFromSoap As Object = Nothing


        If Not File.Exists(BINFileName) Then

            mylog(
                LogTxtArray:={"IO ERROR",
                              "Not a valid bin Path",
                               BINFileName})
            Return Nothing

        End If

        Try

            fileStream = New FileStream(
                     path:=BINFileName,
                     mode:=FileMode.Open,
                   access:=FileAccess.Read)

            formatter = New Formatters.Binary.BinaryFormatter
            objectFromSoap = formatter.Deserialize(serializationStream:=fileStream)

            mylog(
                LogTxtArray:={"OK : SOAP De-Serializing ",
                              "from : " & BINFileName})

        Catch ex As Exception

            mylog(LogTxtArray:={"ERROR SOAP De-Serializing",
                                "SOAP File " & BINFileName,
                                 Join(parseExceptionMsg(ex), vbCrLf)})

            Return Nothing

        Finally

            If fileStream IsNot Nothing Then
                fileStream.Close()
            End If

        End Try

        Return objectFromSoap

    End Function


#End Region

#Region "JSON"

    Public Function formatJSON(ByVal inputText As String) As String

        Dim escaped As Boolean = False
        Dim inquotes As Boolean = False
        Dim column As Integer = 0
        Dim indentation As Integer = 0
        Dim indentations As Stack(Of Integer) = New Stack(Of Integer)()
        Dim TABBING As Integer = 2
        Dim sb As StringBuilder = New StringBuilder()

        For Each x As Char In inputText

            sb.Append(x)
            column += 1

            If escaped Then
                escaped = False
            Else

                If x = "\"c Then
                    escaped = True
                ElseIf x = """"c Then
                    inquotes = Not inquotes
                ElseIf Not inquotes Then

                    If x = ","c Then
                        sb.Append(vbCrLf)
                        column = 0

                        For i As Integer = 0 To indentation - 1
                            sb.Append(" ")
                            column += 1
                        Next
                    ElseIf x = "["c OrElse x = "{"c Then
                        indentations.Push(indentation)
                        indentation = column
                    ElseIf x = "]"c OrElse x = "}"c Then
                        indentation = indentations.Pop()
                    ElseIf x = ":"c Then

                        While (column Mod TABBING) <> 0
                            sb.Append(" "c)
                            column += 1
                        End While
                    End If
                End If
            End If
        Next

        Return sb.ToString()

    End Function

    Public Function saveClass2JSON(
                                  Class2Save As Object,
                                  filePath As String,
                                  Optional formatted As Boolean = True,
                              Optional ShowInNotepad As Boolean = False) As Boolean

        Dim serializer As New JavaScriptSerializer

        Dim serializedResult = serializer.Serialize(Class2Save)

        If formatted Then
            serializedResult = New JsonFormatter(json:=serializedResult).Format

        End If

        Try

            File.WriteAllText(
                path:=filePath,
                contents:=serializedResult)

            If ShowInNotepad Then
                Process.Start(filePath)
            End If

            Return True

        Catch ex As Exception

        End Try

        Return False

    End Function

    Public Function loadFromJSON(jsonFileName As String, classType As Type) As Object

        Dim jss = New JavaScriptSerializer()
        Dim jsonString As String = String.Empty
        Dim out As Object

        'get json string
        Try
            jsonString =
                File.ReadAllText(
                    path:=jsonFileName)
        Catch ex As Exception

            mylog(LogTxtArray:={"IO ERROR reading JSON file",
                                 jsonFileName,
                                 Join(parseExceptionMsg(ex), vbCrLf)})

            Return Nothing

        End Try

        'de-serialization JSON string
        Try

            Return jss.Deserialize(
                           input:=jsonString,
                           targetType:=classType)



        Catch ex As Exception

            mylog(LogTxtArray:={"ERROR de-serialization JSON",
                                jsonFileName,
                                Join(parseExceptionMsg(ex), vbCrLf)})

            Return Nothing

        End Try


    End Function

#Region "file stream"

    Public Function Class2JSON(ByVal Class2Save As Object,
                               ByVal ClassType As Type,
                               ByVal JSONFileName As String,
                            Optional format As Boolean = True) As Boolean



        If Not Directory.Exists(Path.GetDirectoryName(JSONFileName)) Then


            Try
                My.Computer.FileSystem.CreateDirectory(
                    Path.GetDirectoryName(JSONFileName))
            Catch ex As Exception
                mylog(LogTxtArray:={"IO ERROR",
                                    "Not a valid JSON Path",
                                    JSONFileName,
                                    Join(parseExceptionMsg(ex), vbCrLf)})
                Return False
            End Try

        End If

        Try

            Dim fs As FileStream =
                New FileStream(
                path:=JSONFileName,
                mode:=FileMode.Create,
                access:=FileAccess.Write)

            Dim jf As New DataContractJsonSerializer(type:=ClassType)

            jf.WriteObject(fs, Class2Save)
            fs.Close()

        Catch ex As Exception

            mylog(Log2MsgBox:=True, MsgBoxBtn:=MsgBoxStyle.Critical, MsgTitle:="ERROR : JSON Serializing",
                LogTxtArray:={"ERROR : JSON Serializing ",
                             Class2Save.ToString,
                             "to : " & JSONFileName,
                             Join(
                                 SourceArray:=parseExceptionMsg(ex),
                                 Delimiter:=vbCrLf)},
               ShowInNotepad:=True)

            Return False

        End Try

        Return True

    End Function

    Public Function JSON2Class(ByVal ClassType As Type,
                               ByVal JSONFileName As String) As Object



        'Dim jss As New JavaScriptSerializer()
        'Dim jsonText As String = File.ReadAllText(path:=JSONFileName)

        Dim TargetClass As New Object

        If Not File.Exists(JSONFileName) Then

            mylog(
                LogTxtArray:={"IO ERROR",
                              "Not a valid JSON Path",
                               JSONFileName})
            Return Nothing

        End If

        Try

            Dim fs As FileStream =
               New FileStream(
               path:=JSONFileName,
               mode:=FileMode.Open)

            Dim jf As New DataContractJsonSerializer(type:=ClassType)

            TargetClass = jf.ReadObject(fs)
            fs.Close()

            Return TargetClass

        Catch ex As Exception

            mylog(Log2MsgBox:=True, MsgBoxBtn:=MsgBoxStyle.Critical, MsgTitle:="ERROR : JSON De-Serializing",
               LogTxtArray:={"ERROR : JSON De-Serializing ",
                             "Class type : " & ClassType.ToString,
                             "from file  :  " & JSONFileName,
                            Join(
                                SourceArray:=parseExceptionMsg(ex),
                                Delimiter:=vbCrLf)},
              ShowInNotepad:=True)

            Return False

        End Try

    End Function

#End Region


#Region "formating"

    Public Class JsonFormatter

        Private ReadOnly _walker As StringWalker
        Private ReadOnly _writer As IndentWriter = New IndentWriter()
        Private ReadOnly _currentLine As StringBuilder = New StringBuilder()
        Private _quoted As Boolean

        Public Sub New(ByVal json As String)
            _walker = New StringWalker(json)
            ResetLine()
        End Sub

        Public Sub ResetLine()
            _currentLine.Length = 0
        End Sub

        Public Function Format() As String
            While MoveNextChar()

                If Me._quoted = False AndAlso Me.IsOpenBracket() Then
                    Me.WriteCurrentLine()
                    Me.AddCharToLine()
                    Me.WriteCurrentLine()
                    _writer.Indent()
                ElseIf Me._quoted = False AndAlso Me.IsCloseBracket() Then
                    Me.WriteCurrentLine()
                    _writer.UnIndent()
                    Me.AddCharToLine()
                ElseIf Me._quoted = False AndAlso Me.IsColon() Then
                    Me.AddCharToLine()
                    Me.WriteCurrentLine()
                Else
                    AddCharToLine()
                End If
            End While

            Me.WriteCurrentLine()
            Return _writer.ToString()
        End Function

        Private Function MoveNextChar() As Boolean
            Dim success As Boolean = _walker.MoveNext()

            If Me.IsApostrophe() Then
                Me._quoted = Not _quoted
            End If

            Return success
        End Function

        Public Function IsApostrophe() As Boolean
            Return Me._walker.CurrentChar = """"c AndAlso Me._walker.IsEscaped = False
        End Function

        Public Function IsOpenBracket() As Boolean
            Return Me._walker.CurrentChar = "{"c OrElse Me._walker.CurrentChar = "["c
        End Function

        Public Function IsCloseBracket() As Boolean
            Return Me._walker.CurrentChar = "}"c OrElse Me._walker.CurrentChar = "]"c
        End Function

        Public Function IsColon() As Boolean
            Return Me._walker.CurrentChar = ","c
        End Function

        Private Sub AddCharToLine()
            Me._currentLine.Append(_walker.CurrentChar)
        End Sub

        Private Sub WriteCurrentLine()
            Dim line As String = Me._currentLine.ToString().Trim()

            If line.Length > 0 Then
                _writer.WriteLine(line)
            End If

            Me.ResetLine()
        End Sub
    End Class

    Public Class StringWalker
        Private ReadOnly _s As String
        Public Property Index As Integer
        Public Property IsEscaped As Boolean
        Public Property CurrentChar As Char

        Public Sub New(ByVal s As String)
            _s = s
            Me.Index = -1
        End Sub

        Public Function MoveNext() As Boolean
            If Me.Index = _s.Length - 1 Then Return False

            If IsEscaped = False Then
                IsEscaped = CurrentChar = "\"c
            Else
                IsEscaped = False
            End If

            Me.Index += 1
            CurrentChar = _s(Index)
            Return True
        End Function
    End Class

    Public Class IndentWriter
        Private ReadOnly _result As StringBuilder = New StringBuilder()
        Private _indentLevel As Integer

        Public Sub Indent()
            _indentLevel += 1
        End Sub

        Public Sub UnIndent()
            If _indentLevel > 0 Then _indentLevel -= 1
        End Sub

        Public Sub WriteLine(ByVal line As String)
            _result.AppendLine(CreateIndent() & line)
        End Sub

        Private Function CreateIndent() As String
            Dim indent As StringBuilder = New StringBuilder()

            For i As Integer = 0 To _indentLevel - 1
                indent.Append("    ")
            Next

            Return indent.ToString()
        End Function

        Public Overrides Function ToString() As String
            Return _result.ToString()
        End Function
    End Class

#End Region


#End Region

End Module

Public Module DeSerializeGUI

    Public Enum eFileType
        xml
        soap
        json
        definedByExtension
    End Enum

    Public Function Load(ClassType As Type,
                       Optional FileName As String = Nothing,
                       Optional Silent As Boolean = True,
                       Optional Filter As String = "XML files (*.xml)|*.xml|" &
                                                   "Binary files (*.soap)|*.soap|" &
                                                   "JSON files (*.json)|*.json|",
                       Optional Filetype As eFileType = eFileType.definedByExtension) As Object


        Dim myOpenFileDialog As New OpenFileDialog
        Dim out As New Object
        Dim xmlFile As String() = {}
        Dim extension As String = String.Empty

        With myOpenFileDialog

            .Filter = Filter &
                      "All files (*.*)|*.*"

            .FilterIndex = 0

            .AddExtension = True
            .AutoUpgradeEnabled = True

            .CheckFileExists = False
            .CheckPathExists = True

            'get filename
            If IsNothing(FileName) Then

                If .ShowDialog <> DialogResult.OK Then

                    showMsg(
                        logTXT:="Load process aborted by user",
                        filename:="",
                        silent:=True,
                        isError:=False)

                    Return Nothing

                End If

            Else
                .FileName = FileName
            End If

            'get file type
            If Filetype = eFileType.definedByExtension Then

                Try

                    extension = Path.GetExtension(.FileName).ToLower

                    Filetype = [Enum].Parse(
                        enumType:=GetType(eFileType),
                           value:=Replace(
                                   Expression:=extension,
                                         Find:=".",
                                  Replacement:="",
                                      Compare:=CompareMethod.Text))

                Catch ex As Exception
                    showMsg(
                            logTXT:="Unknown file type : " & Path.GetExtension(.FileName).ToLower,
                          filename:= .FileName,
                            silent:=Silent,
                           isError:=True)

                    Return Nothing
                End Try

            End If

            If Filetype = eFileType.xml Then

                Try

                    out = XML2Class(
                                ClassType:=ClassType,
                              XMLFileName:= .FileName)

                    If IsNothing(out) Then

                        showMsg(
                          logTXT:=Join(SourceArray:={"Error de-serializing class ",
                                                      ClassType.Name.ToString,
                                                     "from file " & .FileName},
                                         Delimiter:=vbCrLf),
                        filename:= .FileName,
                          silent:=Silent,
                         isError:=True)

                        Return Nothing

                    Else

                        showMsg(
                            logTXT:="OK : Load " & .FileName & " to class " & out.ToString,
                            isError:=False,
                        filename:= .FileName,
                            silent:=Silent)

                        Return out

                    End If




                Catch ex As Exception

                    showMsg(
                          logTXT:=Join(SourceArray:={"Error de-serializing class ",
                                                      ClassType.Name.ToString,
                                                     "from file " & .FileName,
                                                      Join(parseExceptionMsg(ex), vbCrLf)},
                                         Delimiter:=vbCrLf),
                        filename:= .FileName,
                          silent:=Silent,
                         isError:=True)

                    Return Nothing

                End Try

            ElseIf Filetype = eFileType.soap Then

                Try

                    out = SOAP2Class(BINFileName:= .FileName)

                    If IsNothing(out) Then

                        showMsg(
                          logTXT:=Join(SourceArray:={"Error de-serializing class ",
                                                      ClassType.Name.ToString,
                                                     "from file " & .FileName},
                                         Delimiter:=vbCrLf),
                        filename:= .FileName,
                          silent:=Silent,
                         isError:=True)

                        Return Nothing

                    Else

                        showMsg(
                            logTXT:="OK : Load " & .FileName & " to class " & ClassType.Name.ToString,
                            isError:=False,
                        filename:= .FileName,
                            silent:=Silent)

                        Return out

                    End If



                Catch ex As Exception

                    showMsg(
                          logTXT:=Join(SourceArray:={"Error de-serializing class ",
                                                      ClassType.Name.ToString,
                                                     "from file " & .FileName,
                                                      Join(parseExceptionMsg(ex), vbCrLf)},
                                         Delimiter:=vbCrLf),
                        filename:= .FileName,
                          silent:=Silent,
                         isError:=True)

                    Return Nothing

                End Try

            ElseIf Filetype = eFileType.json Then

                Try

                    out =
                        loadFromJSON(
                            jsonFileName:= .FileName,
                            classType:=ClassType)

                    If IsNothing(out) Then
                        showMsg(
                            logTXT:=Join(SourceArray:={"Error de-serializing class ",
                                                        ClassType.Name.ToString,
                                                    "from file " & .FileName},
                                        Delimiter:=vbCrLf),
                        filename:= .FileName,
                            silent:=Silent,
                        isError:=True)

                        Return Nothing
                    Else

                        showMsg(
                            logTXT:="OK : Load " & .FileName & " to class " & out.ToString,
                            isError:=False,
                        filename:= .FileName,
                            silent:=Silent)

                        Return out

                    End If



                Catch ex As Exception

                    showMsg(
                          logTXT:=Join(SourceArray:={"Error de-serializing class ",
                                                      ClassType.Name.ToString,
                                                     "from file " & .FileName,
                                                      Join(parseExceptionMsg(ex), vbCrLf)},
                                         Delimiter:=vbCrLf),
                        filename:= .FileName,
                          silent:=Silent,
                         isError:=True)

                    Return Nothing

                End Try

            Else

                MsgBox("mist")

            End If

        End With

        Return out

    End Function

    Public Function Save(
                        Class2Save As Object,
                        Optional ClassType As Type = Nothing,
                        Optional Silent As Boolean = True,
                        Optional FileName As String = Nothing,
                        Optional Filter As String = "XML files (*.xml)|*.xml|" &
                                                    "Binary files (*.soap)|*.soap|" &
                                                    "JSON files (*.json)|*.json|",
                        Optional Filetype As eFileType = eFileType.definedByExtension) As Boolean


        Dim mySaveFileDialog As New SaveFileDialog

        With mySaveFileDialog

#Region "            SaveFileDialog settings"

            .Filter = Filter &
                      "All files (*.*)|*.*"

            .FilterIndex = 0

            .AddExtension = True
            .AutoUpgradeEnabled = True

            .CheckFileExists = False
            .CheckPathExists = True

            .CreatePrompt = False
            .OverwritePrompt = True

#End Region

            'get filename
            If IsNothing(FileName) Then
                If .ShowDialog <> DialogResult.OK Then Return False
            Else
                .FileName = FileName
            End If

            'check extension
            If Path.GetExtension(.FileName).ToLower = ".xml" Then

                Filetype = eFileType.xml

            ElseIf Path.GetExtension(.FileName).ToLower = ".soap" Then

                Filetype = eFileType.soap

            ElseIf Path.GetExtension(.FileName).ToLower = ".json" Then

                Filetype = eFileType.json

            Else

                showMsg(
                      logTXT:="Unknown file type : " & Path.GetExtension(.FileName).ToLower,
                     isError:=True,
                    filename:= .FileName,
                      silent:=Silent)

                Return False

            End If


            Select Case Filetype

                Case eFileType.xml

                    Try

                        Class2XML(
                            Class2Save:=Class2Save,
                             ClassType:=ClassType,
                           XMLFileName:= .FileName)

                        showMsg(
                          logTXT:="OK : Save class to file " & .FileName,
                         isError:=False,
                        filename:= .FileName,
                          silent:=Silent)

                        Return True

                    Catch ex As Exception

                        showMsg(
                          logTXT:=Join(
                            SourceArray:=parseExceptionMsg(
                                                   Exception:=ex,
                                        UserErrorDescription:=
                                            "Error serializing (saving) class " &
                                            ClassType.Name.ToString &
                                            "to file " & .FileName)),
                         isError:=False,
                        filename:= .FileName,
                          silent:=False)

                        Return False

                    End Try

                Case eFileType.soap

                    Try

                        Class2SOAP(
                            Class2Save:=Class2Save,
                           BINFileName:= .FileName)

                        showMsg(
                          logTXT:="OK : Save class to file " & .FileName,
                         isError:=False,
                        filename:= .FileName,
                          silent:=Silent)

                        Return True

                    Catch ex As Exception

                        showMsg(
                          logTXT:=Join(
                            SourceArray:=parseExceptionMsg(
                                                   Exception:=ex,
                                        UserErrorDescription:=
                                            "Error serializing (saving) class " &
                                            ClassType.Name.ToString &
                                            "to file " & .FileName)),
                         isError:=False,
                        filename:= .FileName,
                          silent:=False)

                        Return False

                    End Try

                Case eFileType.json

                    Try

                        Try

                            Dim jss As New JavaScriptSerializer

                            Dim result As String
                            result =
                                saveClass2JSON(
                                    Class2Save:=Class2Save,
                                    filePath:= .FileName)

                            'File.WriteAllText(
                            '    path:= .FileName,
                            '    contents:=result)

                            showMsg(
                         logTXT:="OK : Save class to JSON file " & .FileName,
                        isError:=False,
                       filename:= .FileName,
                         silent:=Silent)

                            Return True

                        Catch ex As Exception

                            showMsg(
                          logTXT:=Join(
                            SourceArray:=parseExceptionMsg(
                                                   Exception:=ex,
                                        UserErrorDescription:=
                                            "Error serializing (saving) class in JSON " &
                                            "to file " & .FileName)),
                         isError:=False,
                        filename:= .FileName,
                          silent:=False)

                            Return False

                        End Try


                        'Class2JSON(
                        '    Class2Save:=Class2Save,
                        '     ClassType:=ClassType,
                        '  JSONFileName:= .FileName)

                        'showMsg(
                        '  logTXT:="OK : Save class to file " & .FileName,
                        ' isError:=False,
                        'filename:= .FileName,
                        '  silent:=Silent)

                        'Return True

                    Catch ex As Exception

                        showMsg(
                          logTXT:=Join(
                            SourceArray:=parseExceptionMsg(
                                                   Exception:=ex,
                                        UserErrorDescription:=
                                            "Error serializing (saving) class " &
                                            ClassType.Name.ToString &
                                            "to file " & .FileName)),
                         isError:=False,
                        filename:= .FileName,
                          silent:=False)

                        Return False

                    End Try

            End Select

        End With

        Return False

    End Function

    Private Sub showMsg(logTXT As String, filename As String, silent As Boolean, isError As Boolean)

        If isError Then

            If silent Then
                Console.WriteLine(logTXT)
            Else

                If mylog(
                    LogTxt:=logTXT &
                            " OK, open in editor?",
                Log2MsgBox:=True,
                 MsgBoxBtn:=MsgBoxStyle.YesNo,
                  MsgTitle:="(De)-serialization error") = MsgBoxResult.Yes Then

                    Try
                        Process.Start(filename)
                    Catch ex As Exception
                        mylog(
                            LogTxtArray:=parseExceptionMsg(
                                                Exception:=ex,
                                     UserErrorDescription:="Can't start " & filename),
                             Log2MsgBox:=True,
                              MsgBoxBtn:=MsgBoxStyle.Exclamation)
                    End Try

                End If

            End If

        Else

            If silent Then
                Console.WriteLine(logTXT)
            Else

                mylog(
                    LogTxt:=logTXT,
                Log2MsgBox:=True,
                 MsgBoxBtn:=MsgBoxStyle.Exclamation,
                  MsgTitle:="OK (De)-serialize")

            End If

        End If

    End Sub


End Module


#End Region

#End Region



