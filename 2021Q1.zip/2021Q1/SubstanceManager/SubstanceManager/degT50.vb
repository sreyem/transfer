﻿
Imports System.ComponentModel
Imports System.Drawing.Design
Imports System.Xml.Serialization
Imports System.Web.Script.Serialization
Imports System.Text

Imports essentials
Imports DBs.FOCUSGWdb


Namespace degT50New

    ''' <summary>
    ''' DT50 incl. temp. and moist. corr.
    ''' Inherits degT50Base
    ''' </summary>
    <Serializable>
    <TypeConverter(GetType(propGridConverter))>
    Public Class degT50TempMoistCorr

        Inherits degT50Base

#Region "    Constructor"

        Public Sub New()

        End Sub

        <Browsable(False)>
        <XmlIgnore> <ScriptIgnore>
        Public Property collapseStd As String() =
        {
        catTempMoistCorr,
        catDetailsMoistCorr,
        catDetailsTempCorr,
        catConstantsDegT50
        }

#End Region

        Public ReadOnly Property getMe() As degT50TempMoistCorr
            Get
                Return Me
            End Get
        End Property

#Region "    Output"

        Public Enum eItem
            degrate = 0
            degtemp
            q10
            mabs
            mrel
            mexp
            rel
            neq
            ff
        End Enum

        Public Function createPELMOdegRow(
                                     ff As Double,
                                     Optional PELMOpos As ePelmoPosition = ePelmoPosition.not_def,
                                     Optional scenario As eScenariosGW = eScenariosGW.not_def,
                                     Optional empty As Boolean = False) As String()

            Dim row As New StringBuilder
            Dim target As degT50TempMoistCorr
            Dim temp As String = ""
            Dim out As New List(Of String)



            Dim header As String() =
            {
        "<degrate    ",
        "temp  ",
        "q10   ",
        "m-abs  ",
        "m-rel  ",
        "m-exp  ",
        "rel  ",
        "neq  ",
        "formation factor"
        }


            For Each member As String In header
                row.Append(member)
            Next

            If empty Then

                out.Add(row.ToString)
                row.Clear()

                row.Append("  0.00E+00".PadRight(header(eItem.degrate).Length))

                row.Append("20".PadRight(header(eItem.degtemp).Length))
                row.Append("2.58".PadRight(header(eItem.q10).Length))
                row.Append("0".PadRight(header(eItem.mabs).Length))
                row.Append("100".PadRight(header(eItem.mrel).Length))
                row.Append("0.70".PadRight(header(eItem.mexp).Length))
                row.Append("0".PadRight(header(eItem.rel).Length))
                row.Append("1".PadRight(header(eItem.neq).Length))

                If PELMOpos <> ePelmoPosition.not_def Then
                    row.Append("<Met " & PELMOpos.ToString & ">")
                End If

                out.Add(row.ToString)
                Return out.ToArray

            End If

            out.Add(row.ToString)
            row.Clear()

            'If Me.scenarioSpecificDT50 = eOnOff.On AndAlso scenario <> eScenariosGW.not_def Then

            '    For Each member In Me.scenarioSpecificData

            '        If member.scenario = scenario Then

            '            With member

            '                row.Append(
            '                (" " & (Math.Log(2) / .degT50 * ff).ToString(0.0000000)).PadRight(header(eItem.degrate).Length))

            '            End With

            '        End If

            '    Next

            'Else

            '    temp = " " & (Math.Round(Math.Log(2) / degT50 * ff, decimals:=7)).ToString("0.0000000")

            '    row.Append(temp.PadRight(header(eItem.degrate).Length))

            'End If

            row.Append(_temRefTra.ToString("0.0").PadRight(header(eItem.degtemp).Length))
            row.Append(_q10.ToString("0.00").PadRight(header(eItem.q10).Length))
            row.Append("0".PadRight(header(eItem.mabs).Length))
            row.Append(_relMoist.ToString(0.0).PadRight(header(eItem.mrel).Length))
            row.Append(_EXPB.ToString("0.00").PadRight(header(eItem.mexp).Length))
            row.Append("0".PadRight(header(eItem.rel).Length))
            row.Append("1".PadRight(header(eItem.neq).Length))

            If PELMOpos <> ePelmoPosition.not_def Then
                row.Append("<Met " & PELMOpos.ToString & ">")
            End If

            out.Add(row.ToString)

            Return out.ToArray

        End Function

        Public Shadows Function createPEARLDegT50(
                Optional iop As String = "",
                Optional scenario As eScenariosGW = eScenariosGW.not_def) As List(Of String())


            Dim out As New List(Of String())
            Dim base As New List(Of String)
            Dim std As New List(Of String)

            Dim row As String = ""
            Dim description As New StringBuilder

            out.Add({}) : out.Add({})

            If Double.IsNaN(Me.degT50) Then Return out

            'temp & moist corr.
            If _tempCorr = eOnOffUserdef.On AndAlso
               _moistCorr = eOnOffUserdef.On Then

                description.Append("T|M = on")

            ElseIf _tempCorr = eOnOffUserdef.Off AndAlso
                   _moistCorr = eOnOffUserdef.Off Then

                description.Append("T|M = off")

            Else

                description.Append(
                "T=" & extras.getEnumDescription(_tempCorr) &
               "|M=" & extras.getEnumDescription(_moistCorr))

            End If

            description.Append(" at " & _temRefTra & "°C")

            'If Me.depthDependentFOCUSuserdef = eDepthDependentFOCUSuserdef.userDef Then

            '    description.Append(" FacZTra = user def!")

            'ElseIf Me.scenarioSpecificDT50 = eOnOff.On AndAlso scenario <> eScenariosGW.not_def Then

            '    For Each member In Me.scenarioSpecificData

            '        If member.scenario = scenario Then

            '            description.Append(", " & scenario.ToString & " " &
            '              member.kPerc.ToString &
            '               ", DT90 = " &
            '              member.degT90.ToString("G4") & " days")

            '        End If

            '    Next

            'Else

            '    description.Append(" ," &
            '        kPerc.ToString &
            '        ", DT90 = " &
            '        degT90.ToString("G4") & " days")

            'End If

            row = ""
            'If Me.scenarioSpecificDT50 = eOnOff.On AndAlso scenario <> eScenariosGW.not_def Then

            '    For Each member In Me.scenarioSpecificData

            '        If member.scenario = scenario Then

            '            row = createPrlRow(
            '            Value:=member.degT50,
            '            iop:=iop,
            '            parameterName:="DT50Ref_",
            '            unit:="(d)",
            '            description:=description.ToString,
            '            range:=" ")

            '        End If

            '    Next

            'Else

            '    row = createPrlRow(
            '    Value:=Me.degT50,
            '    iop:=iop,
            '    parameterName:="DT50Ref_",
            '    unit:="(d)",
            '    description:=description.ToString,
            '    range:=" ")

            'End If

            If row = "" Then
                row = createPrlRow(
                Value:=Me.degT50,
                iop:=iop,
                parameterName:="DT50Ref_",
                unit:="(d)",
                description:=description.ToString,
                range:=" ")
            End If

            base.Add(row)

            If _tempCorr = eOnOffUserdef.On OrElse
           _tempCorr = eOnOffUserdef.Off Then

                If _temRefTra = stdTemRef Then

                    row =
            createPrlRow(
                Value:=_temRefTra,
                iop:=iop,
                parameterName:="TemRefTra_",
                unit:="(C)",
                description:="DT50 measurement temp., std. = " & stdTemRef & "°C",
                range:="[5|30]")

                    std.Add(row)

                Else

                    row =
            createPrlRow(
                Value:=_temRefTra,
                iop:=iop,
                parameterName:="TemRefTra_",
                unit:="(C)",
                description:="Non std. measurement temp!, std. = " & stdTemRef & "°C",
                range:="[5|30]")

                    base.Add(row)

                End If



                description.Clear()

                If _tempCorr = eOnOffUserdef.On Then
                    description.Append("Molar activ. energy, std. for on")
                Else
                    description.Append("Molar activ. energy, std. for off")
                End If

                row = createPrlRow(
                    Value:=Me.molEntTra,
                    iop:=iop,
                    parameterName:="MolEntTra_",
                    unit:="(kJ.mol-1)",
                    description:=description.ToString,
                    range:="[0|200]")

                std.Add(row)

            Else

                If _temRefTra = stdTemRef Then

                    row =
            createPrlRow(
                Value:=_temRefTra,
                iop:=iop,
                parameterName:="TemRefTra_",
                unit:="(C)",
                description:="DT50 measurement temp., std. = " & stdTemRef & "°C",
                range:="[5|30]")

                    std.Add(row)

                Else

                    row =
            createPrlRow(
                Value:=_temRefTra,
                iop:=iop,
                parameterName:="TemRefTra_",
                unit:="(C)",
                description:="Non std. measurement temp!, std. = " & stdTemRef & "°C",
                range:="[5|30]")

                    base.Add(row)

                End If


                row = createPrlRow(
                    Value:=Me.molEntTra,
                    iop:=iop,
                    parameterName:="MolEntTra_",
                    unit:="(kJ.mol-1)",
                    description:="Molar activ. energy, user def. value",
                    range:="[0|200]")

                base.Add(row)

            End If

            '**********************************

            If _moistCorr = eOnOffUserdef.On OrElse
           _moistCorr = eOnOffUserdef.Off Then

                description.Clear()

                If _moistCorr = eOnOffUserdef.On Then
                    description.Append("Walker exp., std. value for on")
                Else
                    description.Append("Walker exp., std. value for off")
                End If

                row = createPrlRow(
                    Value:=Me.expLiqTra,
                    iop:=iop,
                    parameterName:="ExpLiqTra_",
                    unit:="(-)",
                    description:=description.ToString,
                    range:="[0|5]")

                std.Add(row)

            Else

                description.Append("Walker exp., user def. value")
                row = createPrlRow(
                    Value:=Me.expLiqTra,
                    iop:=iop,
                    parameterName:="ExpLiqTra_",
                    unit:="(-)",
                    description:=description.ToString,
                    range:="[0|5]")

                base.Add(row)

            End If

            If Me.cntLiqTraRef = stdcntLiqTraRef Then

                row =
            createPrlRow(
                    Value:=Me.cntLiqTraRef,
                    iop:=iop,
                    parameterName:="CntLiqTraRef_",
                    unit:="(kg.kg-1)",
                    description:="std. setting",
                    range:="[0|1]")

                std.Add(row)

            Else

                row =
            createPrlRow(
                    Value:=Me.optDT50.ToString,
                    iop:=iop,
                    parameterName:="CntLiqTraRef_",
                    unit:="(kg.kg-1)",
                    description:="non std. setting !!!",
                    range:="[0|1]")

                base.Add(row)

            End If


            If Me.optCntLiqTraRef = eOptCntLiqTraRef.OptimumConditions Then

                row =
                createPrlRow(
                        Value:=Me.optCntLiqTraRef.ToString,
                        iop:=iop,
                        parameterName:="OptCntLiqTraRef_",
                        unit:=" ",
                        description:="std. setting",
                        range:=" ")

                std.Add(row)

            Else

                row =
                createPrlRow(
                        Value:=Me.optCntLiqTraRef.ToString,
                        iop:=iop,
                        parameterName:="OptCntLiqTraRef_",
                        unit:=" ",
                        description:="non std. setting !!!",
                        range:=" ")

                base.Add(row)

            End If


            If Me.optDT50 = eOptDT50.EqlDom_Input Then

                row =
            createPrlRow(
                    Value:=Me.optDT50.ToString,
                    iop:=iop,
                    parameterName:="OptDT50_",
                    unit:=" ",
                    description:="std. setting",
                    range:=" ")

                std.Add(row)

            Else

                row =
            createPrlRow(
                    Value:=Me.optDT50.ToString,
                    iop:=iop,
                    parameterName:="OptDT50_",
                    unit:=" ",
                    description:="non std. setting !!!",
                    range:=" ")

                base.Add(row)

            End If

            out.Clear()
            out.Add(base.ToArray)
            out.Add(std.ToArray)

            Return out

        End Function

#End Region

        Public Const catTempMoistCorr As String = "02  Temp. And Moist."

#Region "    Temp/Moist corr"

        Private _tempCorr As eOnOffUserdef = eOnOffUserdef.On

        ''' <summary>
        ''' Temperature correction on or off
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <DisplayName(
    "Corr. Temp.")>
        <Description(
    "Temperature correction" & vbCrLf &
    "On, off Or user defined")>
        <Category(catTempMoistCorr)>
        <DefaultValue(CInt(eOnOffUserdef.On))>
        Public Property tempCorr As eOnOffUserdef
            Get
                Return _tempCorr
            End Get
            Set(value As eOnOffUserdef)
                _tempCorr = value

                If _tempCorr = eOnOffUserdef.On Then

                    _molEntTra = molEntTra_on   'PEARL
                    _q10 = q10_on               'PELMO
                    _TRESP = TRESP_on           'MACRO

                ElseIf _tempCorr = eOnOffUserdef.Off Then

                    _molEntTra = molEntTra_off
                    _q10 = q10_off
                    _TRESP = TRESP_off

                End If

            End Set
        End Property


        Public Const stdTemRef As Double = 20

        Private _temRefTra As Double = stdTemRef

        ''' <summary>
        ''' Temperature at which half-life is measured
        ''' in °C [5|30 ; TemRef, std. = 20°C]
        ''' </summary>
        <DisplayName(
    "      at")>
        <Description(
    "Temperature at which half-life Is measured" & vbCrLf &
    "In °C [5|30 ; TemRef, std. = 20°C]")>
        <[ReadOnly](False)>
        <Editor(GetType(nudValueEditorInteger), GetType(UITypeEditor))>
        <RefreshProperties(RefreshProperties.All)>
        <Browsable(True)>
        <TypeConverter(GetType(dblConv))>
        <AttributeProvider("format= '0.0'|unit=' °C'")>
        <Category(catTempMoistCorr)>
        <DefaultValue(stdTemRef)>
        Public Property temRefTra As Double
            Get
                Return _temRefTra
            End Get
            Set

                Try

                    If Value < 5 OrElse
                   Value > 30 Then

                        MsgBox(
                        Prompt:=Value & "°C : " &
                        "Meas. temp for half-life in soil [5|30]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                    Else
                        _temRefTra = Value
                    End If
                Catch ex As Exception

                    MsgBox(
                    Prompt:=Value & vbCrLf & "Error : " &
                    Join(parseExceptionMsg(ex), vbCrLf),
                    Buttons:=MsgBoxStyle.Critical,
                    Title:="Unknown Error")

                End Try

            End Set
        End Property


        Private _moistCorr As eOnOffUserdef = eOnOffUserdef.On


        ''' <summary>
        ''' Moisture correction on or off
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <DisplayName(
    "      Moist.")>
        <Description(
    "Moisture correction" & vbCrLf &
    "On, off or user defined")>
        <Category(catTempMoistCorr)>
        <DefaultValue(CInt(eOnOffUserdef.On))>
        Public Property moistCorr As eOnOffUserdef
            Get
                Return _moistCorr
            End Get
            Set(value As eOnOffUserdef)
                _moistCorr = value

                If _moistCorr = eOnOffUserdef.On Then

                    _expLiqTra = expLiqTra_on       'PEARL & PELMO
                    _relMoist = relMoist_on         'PELMO
                    _EXPB = EXPB_on                 'MACRO

                ElseIf _moistCorr = eOnOffUserdef.Off Then

                    _expLiqTra = expLiqTra_off
                    _relMoist = relMoist_off
                    _EXPB = EXPB_off

                End If

            End Set
        End Property


#End Region

        Public Const catDetailsMoistCorr As String = "02a Moist."

#Region "    Details Moist. Correction"

        Public Const expLiqTra_on As Double = 0.7
        Public Const expLiqTra_off As Double = 0


        Private _expLiqTra As Double = expLiqTra_on

        ''' <summary>
        ''' Walker exponent
        ''' (-) [0 - 5, ExpLiqTra PEARL & PELMO]
        ''' </summary>
        ''' <returns></returns>
        <Category(catDetailsMoistCorr)>
        <DisplayName(
    "Walker exponent")>
        <Description(
    "(-) [0 - 5, ExpLiqTra PEARL & FEUEXP PELMO]")>
        <Browsable(True)>
        <[ReadOnly](False)>
        <RefreshProperties(RefreshProperties.All)>
        <TypeConverter(GetType(dblConv))>
        <AttributeProvider("format= '0.00'|unit=' (-)'")>
        <DefaultValue(Double.NaN)>
        Public Property expLiqTra As Double
            Get
                Return _expLiqTra
            End Get
            Set
                _expLiqTra = Value
            End Set
        End Property



        Public Const relMoist_on As Double = 100
        Public Const relMoist_off As Double = 0

        Private _relMoist As Double = relMoist_on

        ''' <summary>
        ''' Walker exponent
        ''' (-) [0 - 5, relMoist PEARL & PELMO]
        ''' </summary>
        ''' <returns></returns>
        <Category(catDetailsMoistCorr)>
        <DisplayName(
    "Rel. Moisture")>
        <Description(
    "Relative moisture during study in %Field Capacity" & vbCrLf &
    "[0-100, 0 = off, 100 = on; 'moist-rel' PELMO")>
        <Browsable(True)>
        <[ReadOnly](False)>
        <RefreshProperties(RefreshProperties.All)>
        <TypeConverter(GetType(dblConv))>
        <AttributeProvider("format= '0'|unit=' %FC'")>
        <DefaultValue(relMoist_on)>
        Public Property relMoist As Double
            Get
                Return _relMoist
            End Get
            Set
                _relMoist = Value
            End Set
        End Property



        Public Const EXPB_on As Double = 0.49
        Public Const EXPB_off As Double = 0

        Private _EXPB As Double = EXPB_on

        <Category(catDetailsMoistCorr)>
        <DisplayName(
    "MACRO Temp EXPB")>
        <Description(
    "(-) [EXPB, on = 0.49, off = 0]")>
        <Browsable(True)>
        <[ReadOnly](False)>
        <RefreshProperties(RefreshProperties.All)>
        <TypeConverter(GetType(dblConv))>
        <AttributeProvider("format= '0.00'|unit=' (-)'")>
        <DefaultValue(Double.NaN)>
        Public Property EXPB As Double
            Get
                Return _EXPB
            End Get
            Set
                _EXPB = Value
            End Set
        End Property

#End Region

        Public Const catDetailsTempCorr As String = "02b Temp."

#Region "    Details Temp. Correction"

        Public Const molEntTra_on As Double = 65.4
        Public Const molEntTra_off As Double = 1


        Private _molEntTra As Double = molEntTra_on

        ''' <summary>
        ''' Activation Energy
        ''' (-) [0 - 200 kJ/mol, MolEntTra PEARL
        ''' </summary>
        ''' <returns></returns>
        <Category(catDetailsTempCorr)>
        <DisplayName(
    "Activation Energy")>
        <Description(
    "(-) [0 - 200 kJ/mol] " & vbCrLf &
    "std. = 65.4kJ/mol (on) or 0 (off), MolEntTra PEARL")>
        <Browsable(True)>
        <[ReadOnly](False)>
        <RefreshProperties(RefreshProperties.All)>
        <TypeConverter(GetType(dblConv))>
        <AttributeProvider("format= '0.0'|unit=' kJ/mol'")>
        <DefaultValue(Double.NaN)>
        Public Property molEntTra As Double
            Get
                Return _molEntTra
            End Get
            Set
                _molEntTra = Value
            End Set
        End Property


        Public Const q10_on As Double = 2.58
        Public Const q10_off As Double = 1

        Private _q10 As Double = q10_on

        ''' <summary>
        ''' Activation Energy
        ''' (-) [0 - 200 kJ/mol, q10 PEARL
        ''' </summary>
        ''' <returns></returns>
        <Category(catDetailsTempCorr)>
        <DisplayName(
    "Q10")>
        <Description(
    "factor for degradation rate increase when temperature" & vbCrLf &
    "increases by 10°C, std. 2.58 (on) or 0 (off), q10 PELMO")>
        <Browsable(True)>
        <[ReadOnly](False)>
        <RefreshProperties(RefreshProperties.All)>
        <TypeConverter(GetType(dblConv))>
        <AttributeProvider("format= '0.00'|unit=' (-)'")>
        <DefaultValue(Double.NaN)>
        Public Property q10 As Double
            Get
                Return _q10
            End Get
            Set
                _q10 = Value
            End Set
        End Property

        Public Const TRESP_on As Double = 0.0948
        Public Const TRESP_off As Double = 0

        Private _TRESP As Double = TRESP_on

        <Category(catDetailsTempCorr)>
        <DisplayName(
    "MACRO Moist TRESP")>
        <Description(
    "(-) [TRESP, on = 0.0948]")>
        <Browsable(True)>
        <[ReadOnly](False)>
        <RefreshProperties(RefreshProperties.All)>
        <TypeConverter(GetType(dblConv))>
        <AttributeProvider("format= '0.0000'|unit=' (-)'")>
        <DefaultValue(Double.NaN)>
        Public Property TRESP As Double
            Get
                Return _TRESP
            End Get
            Set
                _TRESP = Value
            End Set
        End Property


#End Region

        Public Const catConstantsDegT50 As String = "03  Constants"

#Region "    Constants"

        Public Const stdcntLiqTraRef As Double = 1

        <Category(catConstantsDegT50)>
        <DisplayName(
    "DT50 Liquid Content")>
        <Description(
    "Liq. content at which DT50 is measured" & vbCrLf &
    "in kg/kg [0|1], std. 1kg/kg")>
        Public Property cntLiqTraRef As Double = stdcntLiqTraRef


        Public Enum eOptCntLiqTraRef
            OptimumConditions
            NonOptimumConditions
        End Enum

        <Category(catConstantsDegT50)>
        <DisplayName("(Non) Optimum Conditions")>
        <Description("std. = OptimumConditions")>
        Public Property optCntLiqTraRef As eOptCntLiqTraRef = eOptCntLiqTraRef.OptimumConditions

        ''' <summary>
        ''' Option for DT50: Input or Calculate in
        ''' equilibrium domain(EqlDom) Or In liquid phase
        ''' only (LiqPhs)
        ''' </summary>
        Public Enum eOptDT50

            EqlDom_Input
            LiqPhs_Input

            EqlDom_Calculate
            LiqPhs_Calculate

        End Enum

        <Category(catConstantsDegT50)>
        <DisplayName("Inp/Calc Equ. Domain or Liquid phase")>
        <Description("std. = OptimumConditions")>
        Public Property optDT50 As eOptDT50 = eOptDT50.EqlDom_Input

#End Region

    End Class

    ''' <summary>
    ''' degT50 base class
    ''' degT50/90 and rate constant
    ''' </summary>
    <Serializable>
    <TypeConverter(GetType(propGridConverter))>
    Public Class degT50Base

#Region "    Constructor"

        Public Sub New()

        End Sub

        ''' <summary>
        ''' degT50
        ''' </summary>
        ''' <param name="degT50">
        ''' Single first order degradation half-life in days
        ''' </param>
        Public Sub New(degT50 As Double)
            Me.degT50 = degT50
        End Sub

#End Region

#Region "    Meta"

        <Browsable(False)>
        Public Overridable ReadOnly Property name As String
            Get

                If Not Double.IsNaN(degT50) Then
                    Return _
                        ("DT50 : " & degT50.ToString & " days").PadRight(40) & vbCrLf &
                        ("rate : " & Math.Round(_k * 100, decimals:=2).ToString & " % / day").PadRight(40) & vbCrLf &
                         "DT90 : " & dblConv.conv2String(value:=degT90, unit:=" days")
                Else
                    Return propGridConverter.noName
                End If

            End Get
        End Property

        Public Overridable Function createPEARLdegT50(Optional iop As String = "") As String

            Return createPrlRow(
                Value:=Me.degT50,
                iop:=iop,
                parameterName:="DT50Ref_",
                unit:="(d)",
                description:=
                Math.Round(_k * 100, decimals:=2).ToString & " % / day, degT90 = " & dblConv.conv2String(value:=degT90, unit:=" days"),
                range:="[1|1e6]")

        End Function

        <Browsable(False)>
        Public ReadOnly Property inputComplete As String
            Get

                If Double.IsNaN(Me.degT50) Then Return " degt50 ?"

                Return misc.inputComplete

            End Get
        End Property

#End Region

        Public Const catDT50 As String = "01  degT50"

#Region "    degT50"

        Private _degT50 As Double = Double.NaN

        ''' <summary>
        ''' Single first order degradation
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <Description(
        "Single first order degradation half-life" & vbCrLf &
        "Mt=M0*e^(-k*t)")>
        <DisplayName(
        "degT50")>
        <Category(catDT50)>
        <DefaultValue(Double.NaN)>
        <TypeConverter(GetType(dblConv))>
        <AttributeProvider("unit=' days'")>
        Public Overridable Property degT50 As Double
            Get
                Return _degT50
            End Get
            Set
                _degT50 = Value
                _k = Math.Log(2) / _degT50
            End Set
        End Property

        ''' <summary>
        ''' degT90
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <Category(catDT50)>
        <DisplayName(
        "   degT90")>
        <TypeConverter(GetType(dblConv))>
        <AttributeProvider("unit=' days'")>
        Public ReadOnly Property degT90 As Double
            Get

                If Not Double.IsNaN(_degT50) AndAlso _degT50 > 0 Then

                    Return Math.Log(10) /
                 (Math.Log(2) / _degT50)

                Else
                    Return Double.NaN
                End If

            End Get
        End Property


        Private _k As Double = Double.NaN

        ''' <summary>
        ''' Rate constant
        ''' </summary>
        ''' <returns></returns>
        <RefreshProperties(RefreshProperties.All)>
        <Category(catDT50)>
        <DisplayName(
        "Rate Constant")>
        <Description("")>
        <TypeConverter(GetType(dblConv))>
        <AttributeProvider("format='G8' | unit=' per day'")>
        Public Property k As Double
            Get
                Return _k
            End Get
            Set
                _k = Value
            End Set
        End Property

#End Region

    End Class

    ''' <summary>
    ''' Depth dependent degradation
    ''' FacZTra
    ''' </summary>
    <Serializable>
    <TypeConverter(GetType(propGridConverter))>
    Public Class facZTra

        Public Sub New()
            resetFacZTra()
        End Sub

        Public Const catFacZTra As String = "Depth dep. Degradation "

        <DisplayName("Reset to FOCUS std.")>
        <Category(catFacZTra)>
        <Editor(GetType(buttonEmulator), GetType(UITypeEditor))>
        <XmlIgnore> <ScriptIgnore>
        <RefreshProperties(RefreshProperties.All)>
        Public Property reset As String
            Get
                Return ""
            End Get
            Set(value As String)

                If value.Contains(buttonEmulator.Clicked) Then
                    resetFacZTra()
                End If

            End Set
        End Property

        <DisplayName("FacZTra")>
        <Description("Depth dependent degradation factors")>
        <Category(catFacZTra)>
        <RefreshProperties(RefreshProperties.All)>
        Public Property facZTra As facZ() = {}

#Region "    Methods"

        ''' <summary>
        ''' Reset FacZTra with FOCUS std. values
        ''' for 4.4.4 and 5.5.5
        ''' </summary>
        Public Sub resetFacZTra()

            Dim facZTraList As New List(Of facZ)

            For scenario As eScenariosGW = eScenariosGW.Chateaudun To eScenariosGW.Thiva

                facZTraList.Add(New facZ)

                With facZTraList(facZTraList.Count - 1)

                    .scenario = scenario

                    .PEARL444 = DBs.FOCUSGWdb.getFacZTra(
                        scenario:=scenario,
                        version:=ePEARLVersion.PEARL444)

                    .PEARL555 = DBs.FOCUSGWdb.getFacZTra(
                        scenario:=scenario,
                        version:=ePEARLVersion.PEARL555)

                End With

            Next

            facZTra = facZTraList.ToArray

        End Sub

        ''' <summary>
        ''' Get FacZTra for 
        ''' specific scenario
        ''' </summary>
        ''' <param name="scenario">
        ''' Chat - Thiva
        ''' </param>
        ''' <returns></returns>
        Public Function getFacZTra(scenario As eScenariosGW) As facZ

            For Each member As facZ In facZTra
                If member.scenario = scenario Then
                    Return member
                End If
            Next

            Return Nothing

        End Function

        ''' <summary>
        ''' Get FacZTra for 
        ''' specific scenario and
        ''' PEARL version
        ''' </summary>
        ''' <param name="scenario">
        ''' Chat - Thiva
        ''' </param>
        ''' <param name="version">
        ''' 4.4.4 or 5.5.5
        ''' </param>
        ''' <returns></returns>
        Public Function getFacZTra(scenario As eScenariosGW, version As ePEARLVersion) As Double()

            Dim facZ As New facZ

            facZ = getFacZTra(scenario:=scenario)

            If Not IsNothing(facZ) Then

                If version = ePEARLVersion.PEARL444 Then
                    Return facZ.PEARL444
                Else
                    Return facZ.PEARL555
                End If

            End If

            Return Nothing

        End Function

#End Region

    End Class

End Namespace

Namespace sorptionNew

    <Serializable>
    <TypeConverter(GetType(propGridConverter))>
    <DefaultProperty("kom")>
    Public Class equilibriumSorption

        Public Sub New()

        End Sub

        Public Const factor As Double = 1.724
        Public Const digits As Integer = 2
        Public Const komMaxFactor As Integer = 100

        Public Const catBaseParameters As String = "01 Base Parameters"

        <Browsable(False)>
        Public Overridable ReadOnly Property name As String
            Get

                If Not Double.IsNaN(_kom) Then
                    Return _
                        ("Kom : " & _kom.ToString & " L/kg").PadRight(40) & vbCrLf &
                        ("Koc : " & _koc.ToString & " L/kg").PadRight(40) & vbCrLf &
                         "1/n : " & _expFre.ToString
                Else
                    Return propGridConverter.noName
                End If

            End Get
        End Property


#Region "    Base Parameters"

        Private _kom As Double = Double.NaN

        ''' <summary>
        ''' Kom
        ''' Coefficient equilibrium sorption on org. !matter!
        ''' in L/kg, [0|1e9], KomEql\Sed\SusSol
        ''' </summary>
        <DisplayName(
            "Kom")>
        <Description(
        "Coef. eql. sorption on org. !matter! in L/kg" & vbCrLf &
        "[0|1e9], KomEql\Sed\SusSol, click '..' to calc from Koc")>
        <DefaultValue(Double.NaN)>
        <RefreshProperties(RefreshProperties.All)>
        <Category(catBaseParameters)>
        <TypeConverter(GetType(dblConv))>
        <AttributeProvider("format='G8'| unit=' L/kg'")>
        <Browsable(True)>
        <Editor(GetType(buttonDblInt), GetType(UITypeEditor))>
        Public Property kom As Double
            Get
                Return _kom
            End Get
            Set

                Try

                    If Value = buttonDblInt.Clicked Then

                        If Not Double.IsNaN(_koc) Then

                            _kom =
                            Math.Round(_koc / factor, digits:=digits)

                        End If

                    ElseIf Value < 0 OrElse
                           Value > 1000000000 Then

                        MsgBox(
                        Prompt:=Value.ToString("0.00") & " : Kom [0|1e9]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                    Else

                        _kom = Value

                    End If

                Catch ex As Exception

                    mylog(
                    LogTxt:=Value & vbCrLf & "Error : " &
                    Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")


                End Try

            End Set
        End Property

        ''' <summary>
        ''' Coef. eql. sorption on org. matter in dry soil
        ''' </summary>
        ''' <returns></returns>
        <Category(catBaseParameters)>
        <Description(
        "Coef. eql. sorption on org. matter in dry soil")>
        <Browsable(False)>
        Public ReadOnly Property komEqlMax As Double
            Get
                Return _kom * komMaxFactor
            End Get
        End Property

        Private _koc As Double = Double.NaN

        ''' <summary>
        ''' Koc
        ''' Coefficient equilibrium sorption on org. !content!
        ''' in L/kg, [0|1e9], KOC\ZKD (MACRO)
        ''' </summary>
        ''' <returns></returns>
        <DisplayName("Koc")>
        <Description(
        "Coef. eql. sorption on org. !content!" & vbCrLf &
        "in L/kg, [0|1e9], KOC\ZKD (MACRO), click '..' to calc from Kom")>
        <DefaultValue(Double.NaN)>
        <RefreshProperties(RefreshProperties.All)>
        <Category(catBaseParameters)>
        <Editor(GetType(buttonDblInt), GetType(UITypeEditor))>
        <TypeConverter(GetType(dblConv))>
        <AttributeProvider("format='G8'| unit=' L/kg'")>
        <Browsable(True)>
        Public Property koc As Double
            Get
                Return _koc
            End Get
            Set

                Try

                    If Value = buttonDblInt.Clicked Then

                        If Not Double.IsNaN(_koc) Then

                            _koc =
                            Math.Round(_kom * factor, digits:=digits)
                        End If

                    ElseIf Value < 0 OrElse
                       Value > 1000000000 Then

                        MsgBox(
                        Prompt:=Value.ToString("0.00") & " : Koc [0|1e9]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                    Else
                        _koc = Value
                    End If

                Catch ex As Exception

                    mylog(
                    LogTxt:=Value & vbCrLf & "Error : " &
                    Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")

                End Try

            End Set
        End Property


        Private _expFre As Double = Double.NaN

        ''' <summary>
        ''' Summary
        ''' Freundlich Exp. 1/n
        ''' no unit 0.1 - 1.3
        ''' ExpFre
        ''' </summary>
        <DisplayName("1/n")>
        <Description("Freundlich Exp. no unit 0.1 - 1.3 ; ExpFre\Sed\SusSol ")>
        <TypeConverter(GetType(dblConv))>
        <RefreshProperties(RefreshProperties.All)>
        <Category(catBaseParameters)>
        <Browsable(True)>
        <DefaultValue(Double.NaN)>
        Public Property expFre As Double
            Get
                Return _expFre
            End Get
            Set(value As Double)

                Try

                    If value < 0.1 OrElse
                   value > 1.3 Then

                        MsgBox(
                        Prompt:=value.ToString("0.0000") &
                        " : Freundlich Exp. 1/n [0.1|1.3]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                    Else
                        _expFre = value
                    End If

                Catch ex As Exception

                    mylog(
                    LogTxt:=value & vbCrLf & "Error : " &
                    Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")

                End Try


            End Set
        End Property

#End Region

        Public Const catConstants As String = "02  Constants"

#Region "    Constants"

        Private Const stdConLiqRef As Double = 1

        <Category(catConstants)>
        <DisplayName("Ref. conc. in liq. phase")>
        <Description("in mg/L [0.1|-, std. = 1; ConLiqRef]")>
        <DefaultValue(stdConLiqRef)>
        Public Property conLiqRef As Double = stdConLiqRef


        Public Const stdTemRef As Double = 20

        Private _temRefSor As Double = stdTemRef

        ''' <summary>
        ''' Temperature at which sorption is measured
        ''' in °C [5|30 ; TemRef, std. = 20°C]
        ''' </summary>
        <DisplayName(
    "      at")>
        <Description(
    "Temperature at which sorption Is measured" & vbCrLf &
    "In °C [5|30 ; TemRefSor, std. = 20°C]")>
        <[ReadOnly](False)>
        <Editor(GetType(nudValueEditorInteger), GetType(UITypeEditor))>
        <RefreshProperties(RefreshProperties.All)>
        <Browsable(True)>
        <TypeConverter(GetType(dblConv))>
        <AttributeProvider("format= '0.0'|unit=' °C'")>
        <Category(catConstants)>
        <DefaultValue(stdTemRef)>
        Public Property temRefSor As Double
            Get
                Return _temRefSor
            End Get
            Set

                Try

                    If Value < 5 OrElse
                   Value > 30 Then

                        MsgBox(
                        Prompt:=Value & "°C : " &
                        "Meas. temp for sorption [5|30]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                    Else
                        _temRefSor = Value
                    End If
                Catch ex As Exception

                    MsgBox(
                    Prompt:=Value & vbCrLf & "Error : " &
                    Join(parseExceptionMsg(ex), vbCrLf),
                    Buttons:=MsgBoxStyle.Critical,
                    Title:="Unknown Error")

                End Try

            End Set
        End Property

        Private Const stdMolEntSor As Double = 0
        Private _molEntSor As Double = stdMolEntSor

        ''' <summary>
        ''' Activation Energy
        ''' (-) [0 - 200 kJ/mol, MolEntSor PEARL
        ''' </summary>
        ''' <returns></returns>
        <Category(catConstants)>
        <DisplayName(
    "Activation Energy")>
        <Description(
    "(-) [0 - 200 kJ/mol] " & vbCrLf &
    "std. = 0 kJ/mol , MolEntSor PEARL")>
        <Browsable(True)>
        <[ReadOnly](False)>
        <RefreshProperties(RefreshProperties.All)>
        <TypeConverter(GetType(dblConv))>
        <AttributeProvider("format= '0.0'|unit=' kJ/mol'")>
        <DefaultValue(stdMolEntSor)>
        Public Property molEntSor As Double
            Get
                Return _molEntSor
            End Get
            Set

                If Value < 0 OrElse
                  Value > 200 Then

                    MsgBox(
                    Prompt:=Value & " kj/mol : " &
                    "Activation Energy for sorption [0|200]",
                    Buttons:=MsgBoxStyle.Exclamation,
                    Title:="User input outside limits")

                Else

                    If Value <> stdMolEntSor Then

                        If MsgBox(
                            Prompt:="Std. value for MolEntSor is " & stdMolEntSor & vbCrLf &
                            " Realy change this to " & Value & " ?",
                            Buttons:=MsgBoxStyle.YesNo,
                            Title:="User input strange") = MsgBoxResult.Yes Then

                            _temRefSor = Value

                        End If

                    Else
                        _temRefSor = Value
                    End If

                End If

            End Set
        End Property


        <TypeConverter(GetType(enumConverter(Of eOptCofFre)))>
        Public Enum eOptCofFre
            <Description("pH-dependent")>
            pHdependent
            <Description("pH-independent")>
            pHindependent
            <Description("CofFre")>
            CofFre
        End Enum

        <Category(catConstants)>
        Public Property optCofFre As eOptCofFre = eOptCofFre.pHindependent

#End Region


    End Class



    ''' <summary>
    ''' Depth dependent sorption FacZSor
    ''' </summary>
    <Serializable>
    <TypeConverter(GetType(propGridConverter))>
    Public Class facZSor

        Public Sub New()
            resetFacZSor()
        End Sub

        Public Const catFacZSor As String = "Depth dep. Sorption "

        <DisplayName("Reset to FOCUS std.")>
        <Category(catFacZSor)>
        <Editor(GetType(buttonEmulator), GetType(UITypeEditor))>
        <XmlIgnore> <ScriptIgnore>
        <RefreshProperties(RefreshProperties.All)>
        Public Property reset As String
            Get
                Return ""
            End Get
            Set(value As String)

                If value.Contains(buttonEmulator.Clicked) Then
                    resetFacZSor()
                End If

            End Set
        End Property

        <DisplayName("FacZSor")>
        <Description("Depth dependent sorption factors")>
        <Category(catFacZSor)>
        <RefreshProperties(RefreshProperties.All)>
        Public Property facZSor As facZ() = {}

#Region "    Methods"

        Public Sub resetFacZSor()

            Dim facZTraList As New List(Of facZ)

            For scenario As eScenariosGW = eScenariosGW.Chateaudun To eScenariosGW.Thiva

                facZTraList.Add(New facZ)

                With facZTraList(facZTraList.Count - 1)

                    .scenario = scenario

                    .PEARL444 = DBs.FOCUSGWdb.getFacZSor(
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL444)

                    .PEARL555 = DBs.FOCUSGWdb.getFacZSor(
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL555)

                End With

            Next

            facZSor = facZTraList.ToArray

        End Sub

        Public Function getFacZSor(scenario As eScenariosGW) As facZ

            For Each member As facZ In facZSor
                If member.scenario = scenario Then
                    Return member
                End If
            Next

            Return Nothing

        End Function

        Public Function getFacZSor(scenario As eScenariosGW, version As ePEARLVersion) As Double()

            Dim facZ As New facZ

            facZ = getFacZSor(scenario:=scenario)

            If Not IsNothing(facZ) Then
                If version = ePEARLVersion.PEARL444 Then
                    Return facZ.PEARL444
                Else
                    Return facZ.PEARL555
                End If
            End If

            Return Nothing

        End Function

#End Region

    End Class


    ''' <summary>
    ''' Depth dependent degT50/Sorption base class
    ''' </summary>
    <Serializable>
    <TypeConverter(GetType(propGridConverter))>
    <DefaultProperty("scenario")>
    Public Class facZ

        Private _PEARL444 As Double() = {}
        Private _PEARL555 As Double() = {}

        Public Sub New()

        End Sub

        <Browsable(False)>
        Public ReadOnly Property name As String
            Get
                Return scenario.ToString
            End Get
        End Property

        Public Property scenario As eScenariosGW = eScenariosGW.not_def

        <Editor(GetType(multiLineDoubleArrayEditor), GetType(UITypeEditor))>
        <DisplayName("PEARL 4.4.4")>
        Public Property PEARL444 As Double()
            Get
                Return _PEARL444
            End Get
            Set

                If Value.Count <> DBs.FOCUSGWdb.getFacZSor(
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL444).Count Then
                    MsgBox(Prompt:="# of horizons do not match, must be " & DBs.FOCUSGWdb.getFacZSor(
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL444).Count)
                Else
                    _PEARL444 = Value
                End If

            End Set
        End Property

        <Editor(GetType(multiLineDoubleArrayEditor), GetType(UITypeEditor))>
        <DisplayName("PEARL 5.5.5")>
        Public Property PEARL555 As Double()
            Get
                Return _PEARL555
            End Get
            Set

                If Value.Count <> DBs.FOCUSGWdb.getFacZSor(
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL555).Count Then
                    MsgBox(Prompt:="# of horizons do not match, must be " & DBs.FOCUSGWdb.getFacZSor(
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL555).Count)
                Else
                    _PEARL555 = Value
                End If

            End Set
        End Property

    End Class


End Namespace




'    <Serializable>
'    <TypeConverter(GetType(propGridConverter))>
'    Public Class degT50TempMoistCorrScen

'        Inherits degT50TempMoistCorr

'        Public Sub New()

'        End Sub

'        Private _scenarioSpecific As eYesNo = eYesNo.No

'        Public Const catScenarioSpecific As String = "00  Scenario Specific"

'        <Browsable(True)>
'        <DefaultValue(CType(Nothing, Object))>
'        <DisplayName("Scenario Specific ?")>
'        <Category(catScenarioSpecific)>
'        Public Property scenarioSpecific As eYesNo
'            Get
'                Return _scenarioSpecific
'            End Get
'            Set
'                _scenarioSpecific = Value
'                If _scenarioSpecific = eYesNo.Yes Then

'                    Dim temp As New List(Of degT50TempMoistCorrScenBase)

'                    For scenario As eScenariosGW = eScenariosGW.Chateaudun To eScenariosGW.Thiva
'                        temp.Add(New degT50TempMoistCorrScenBase(
'                                 scenario:=scenario, base:=MyBase.getMe))
'                    Next

'                    degT50TempMoistCorrScen = temp.ToArray

'                Else
'                    degT50TempMoistCorrScen = Nothing
'                End If
'            End Set
'        End Property

'        <Browsable(True)>
'        <DefaultValue(CType(Nothing, Object))>
'        <Category(catScenarioSpecific)>
'        <DisplayName("Data")>
'        Public Property degT50TempMoistCorrScen As degT50TempMoistCorrScenBase() = Nothing

'    End Class

'    ''' <summary>
'    ''' Base class for scenario specific data
'    ''' Inherits degT50TempMoistCorr
'    ''' </summary>
'    <Serializable>
'    <TypeConverter(GetType(propGridConverter))>
'    Public Class degT50TempMoistCorrScenBase

'        Inherits degT50TempMoistCorr

'#Region "        Constructor"

'        Public Sub New()

'        End Sub

'        Public Sub New(scenario As eScenariosGW)
'            Me.scenario = scenario
'        End Sub

'#End Region

'        <Browsable(False)>
'        Public Overrides ReadOnly Property name As String
'            Get
'                Return _
'                    extras.getEnumDescription(scenario).PadRight(15) & vbCrLf &
'                    MyBase.name
'            End Get
'        End Property

'        <Category(degT50TempMoistCorrScen.catScenarioSpecific)>
'        <DisplayName("FOCUSgw Scenario")>
'        <Description("Chateaudun - Thiva, 9 scenarios")>
'        Public Property scenario As eScenariosGW = eScenariosGW.not_def

'    End Class
