﻿

Imports System.ComponentModel
Imports System.Drawing.Design
Imports System.Text
Imports System.Web.Script.Serialization
Imports System.Xml.Serialization
Imports essentials
Imports essentials.mailMerge
Imports DBs.FOCUSGWdb

<TypeConverter(GetType(propGridConverter))>
<Serializable>
Public Class common

    Private _metaData As New metaData
    Private _physChem As New physChem

    Public Sub New()

    End Sub

    <Editor(GetType(buttonForm), GetType(UITypeEditor))>
    Public Property metaData As metaData
        Get
            Return _metaData
        End Get
        Set
            _metaData = Value
        End Set
    End Property

    <Editor(GetType(buttonForm), GetType(UITypeEditor))>
    Public Property physChem As physChem
        Get
            Return _physChem
        End Get
        Set
            _physChem = Value
        End Set
    End Property

End Class

''' <summary>
''' Names and Codes
''' </summary>
<TypeConverter(GetType(propGridConverter))>
<Serializable>
Public Class metaData

    Public Sub New()

    End Sub

    <Browsable(False)>
    Public ReadOnly Property name As String
        Get

            If iop = "" Then Return propGridConverter.noName
            If nameUC = "" Then
                Return iop
            Else
                Return iop & " " & nameUC
            End If

        End Get
    End Property

    Private _iop As String = ""
    Private _nameInModel As String = ""


    Public Const catNames As String = "01  Names and Codes"

#Region "    01  Names and Codes"

    <RefreshProperties(RefreshProperties.All)>
    <Category(catNames)>
    Public Property iop As String
        Get
            Return _iop
        End Get
        Set
            _iop = parseSubstanceCode(code:=Value)
        End Set
    End Property

    <Category(catNames)>
    Public Property nameInModel As String
        Get
            Return _nameInModel
        End Get
        Set
            _nameInModel = Value
        End Set
    End Property

    <Category(catNames)>
    Public Property nameUC As String = ""

    <Category(catNames)>
    Public Property nameLC As String = ""

    <Category(catNames)>
    Public Property companyCode As String = ""

#End Region

    Public Const catDART As String = "02  DART"

#Region "    02  DART"

    <Category(catDART)>
    Public Property molID As String

    <Category(catDART)>
    Public Property subID As String

#End Region

End Class

''' <summary>
''' Phys-Chem
''' Mol mass and structure, VP and solubility
''' </summary>
<TypeConverter(GetType(propGridConverter))>
<Serializable>
Public Class physChem

    Public Sub New()

    End Sub

    <Browsable(False)>
    <XmlIgnore> <ScriptIgnore>
    Public Property collapseStd As String() =
    {"04a Vaporization", "04b Dissolution", "04c Diffusion"}

    <Browsable(False)>
    Public ReadOnly Property name As String
        Get

            Dim out As New StringBuilder
            Dim inputIncomplete As Boolean = False

            If Double.IsNaN(_molMass) Then
                Return propGridConverter.noName
            Else
                out.Append(
                    "Mol mass   : " &
                    dblConv.conv2String(
                    value:=_molMass,
                    unit:=" g/mol") &
                    " - " & vbCrLf)
            End If

            If Not Double.IsNaN(_preVapRef) Then
                out.Append(
                    extras.getEnumDescription(enumConstant:=EVAClassification) &
                    " - " & vbCrLf)
            Else
                out.Append("preVapRef ?" &
                           " - " & vbCrLf)
                inputIncomplete = True
            End If

            If Not Double.IsNaN(_sblWatRef) Then
                out.Append(
                    "Solubility : " &
                    dblConv.conv2String(
                    value:=_sblWatRef,
                    unit:=" mg/L") &
                    " - " & vbCrLf)
            Else
                out.Append("sblWatRef ?")
                inputIncomplete = True
            End If



            Return out.ToString

        End Get
    End Property


    Public Function createPEARLPhysChem(Optional iop As String = "") As List(Of String())

        Dim out As New List(Of String())

        Dim top As New List(Of String)
        Dim std As New List(Of String)
        Dim both As New List(Of String)

        Dim description As String
        Dim row As String

        row =
            createPrlRow(
                Value:=_molMass,
                iop:=iop,
                parameterName:="MolMas_",
                unit:="(g.mol-1)",
                description:="Molar mass of parent substance",
                range:="[10.0|10000]")

        top.Add(row) : both.Add(row)

#Region "    VP"

        If Me.temRefVap <> stdTemRef Then

            description = "Vapor pressure of substance"
            row =
                       createPrlRow(
                           Value:=_preVapRef,
                           iop:=iop,
                           parameterName:="PreVapRef_",
                           unit:="(Pa)",
                           description:=description,
                           range:="[0|2e5]")

            top.Add(row) : both.Add(row)

            description = "Std. value (20°C) for VP temp. changed !!!"

            row = createPrlRow(
               Value:=_temRefVap,
               iop:=iop,
               parameterName:="TemRefVap_",
               unit:="(C)",
               description:=description,
               range:="[0|40]")

            top.Add(row) : both.Add(row)

        Else

            description = "Vapor pressure of substance   at " & Me.temRefVap & "°C"

            row =
                      createPrlRow(
                          Value:=_preVapRef,
                          iop:=iop,
                          parameterName:="PreVapRef_",
                          unit:="(Pa)",
                          description:=description,
                          range:="[0|2e5]")

            top.Add(row) : both.Add(row)

            description = "Vapor pressure measurement temperature"

            row = createPrlRow(
               Value:=_temRefVap,
               iop:=iop,
               parameterName:="TemRefVap_",
               unit:="(C)",
               description:=description,
               range:="[0|40]")

            std.Add(row) : both.Add(row)

        End If

#End Region

#Region "    Solubility"

        If Me.temRefSlb <> stdTemRef Then

            description = "Water solubility of substance"

            row = createPrlRow(
                Value:=slbWatRef,
                iop:=iop,
                parameterName:="SlbWatRef_",
                unit:="(mg.L-1)",
                description:=description,
                range:="[0.001|1e6]")

            top.Add(row) : both.Add(row)

            description = "Std. value (20°C) for solub. temp. changed !!!"

            row =
            createPrlRow(
                Value:=_temRefSlb,
                iop:=iop,
                parameterName:="TemRefSlb_",
                unit:="(C)",
                description:=description,
                range:="[0|40]")

            top.Add(row) : both.Add(row)

        Else

            description = "Water solubility of substance at " & Me.temRefSlb & "°C"

            row = createPrlRow(
               Value:=slbWatRef,
               iop:=iop,
               parameterName:="SlbWatRef_",
               unit:="(mg.L-1)",
               description:=description,
               range:="[0.001|1e6]")

            top.Add(row) : both.Add(row)

            description = "Water solubility measurement temperature"

            row =
                createPrlRow(
                    Value:=_temRefSlb,
                    iop:=iop,
                    parameterName:="TemRefSlb_",
                    unit:="(C)",
                    description:=description,
                    range:="[0|40]")

            std.Add(row) : both.Add(row)

        End If

#End Region

#Region "    Constants"

        row = createPrlRow(
                Value:=_molEntVap,
                iop:=iop,
                parameterName:="MolEntVap_",
                unit:="(kJ.mol-1)",
                description:="Molar enthalpy of vaporization",
                range:="[-200|200]")

        If Me.molEntVap <> stdMolEntVap Then

            top.AddRange(
            {
            "*",
            "* Std. value (" & stdMolEntVap & " kJ/mol) for molar enthalpy of vaporization changed !!!",
            row,
            "*"
            })

            both.AddRange(
            {
            "*",
            "* Std. value (" & stdMolEntVap & " kJ/mol) for molar enthalpy of vaporization changed !!!",
            row,
            "*"
            })

        Else
            std.Add(row) : both.Add(row)
        End If

        row = createPrlRow(
                Value:=_molEntSlb,
                iop:=iop,
                parameterName:="MolEntSlb_",
                unit:="(kJ.mol-1)",
                description:="Molar enthalpy of dissolution",
                range:="[-200|200]")

        If Me.molEntVap <> stdMolEntVap Then

            top.AddRange(
            {
            "*",
            "* Std. value (" & stdMolEntVap & " kJ/mol) for molar enthalpy of dissolution changed !!!",
            row,
            "*"
            })

            both.AddRange(
            {
            "*",
            "* Std. value (" & stdMolEntVap & " kJ/mol) for molar enthalpy of dissolution changed !!!",
            row,
            "*"
            })

        Else
            std.Add(row) : both.Add(row)
        End If

        row = createPrlRow(
                Value:=_cofDifWatRef,
                iop:=iop,
                parameterName:="CofDifWatRef_",
                unit:="(m2.d-1)",
                description:="Reference diff. coeff. in water",
                range:="[10e-5|3e-4]")

        If Me.molEntVap <> stdMolEntVap Then

            top.AddRange(
            {
            "*",
            "* Std. value (" & stdMolEntVap & " m²/d) for reference diffusion. coefficient. in water changed !!!",
            row,
            "*"
            })

            both.AddRange(
            {
            "*",
            "* Std. value (" & stdMolEntVap & " m²/d) for reference diffusion. coefficient. in water changed !!!",
            row,
            "*"
            })

        Else
            std.Add(row) : both.Add(row)
        End If

        row = createPrlRow(
                Value:=_cofDifAirRef,
                iop:=iop,
                parameterName:="CofDifAirRef_",
                unit:="(m2.d-1)",
                description:="Reference diff. coeff. in air",
                range:="0.1|3")

        If Me.molEntVap <> stdMolEntVap Then

            top.AddRange(
            {
            "*",
            "* Std. value (4.3 m²/d) for reference diffusion. coefficient. in air changed !!!",
            row,
            "*"
            })

            both.AddRange(
            {
            "*",
            "* Std. value (4.3 m²/d) for reference diffusion. coefficient. in air changed !!!",
            row,
            "*"
            })

        Else
            std.Add(row) : both.Add(row)
        End If

        If Me.temRefDif <> stdTemRef Then

            description = "Std. value (20°C) for Diff. coeff meas. temp. changed !!!"

            row = createPrlRow(
               Value:=_temRefDif,
               iop:=iop,
               parameterName:="TemRefDif_",
               unit:="(C)",
               description:=description,
               range:="[0|40]")

            top.Add(row) : both.Add(row)

        Else


            description = "Diff. coeff measurement temperature"

            row = createPrlRow(
               Value:=_temRefDif,
               iop:=iop,
               parameterName:="TemRefDif_",
               unit:="(C)",
               description:=description,
               range:="[0|40]")

            std.Add(row) : both.Add(row)

        End If

#End Region

        out.Add(top.ToArray)
        out.Add(std.ToArray)
        out.Add(both.ToArray)

        Return out

    End Function

    Public Function createPELMOVolatilization() As String()

        Dim row As New StringBuilder
        Dim out As New List(Of String)

        out.Add("<VOLATILIZATION>")
        out.Add("<henry       solub.     molmass   vap.press  diff air    depth volat.  Hv       Temperature>)")

        row.Append(("  " & henrykPELMO.ToString(format:="0.00E00")).PadRight(totalWidth:="<henry       ".Length))
        row.Append(_sblWatRef.ToString.PadRight(totalWidth:="solub.     ".Length))
        row.Append(_molMass.ToString.PadRight(totalWidth:="molmass   ".Length))
        row.Append(_preVapRef.ToString(format:="0.00E00").PadRight(totalWidth:="vap.press  ".Length))
        row.Append(Math.Round(diffCoeffAirPELMO, 4).ToString(format:="0.0000").PadRight(totalWidth:="diff air    ".Length))
        row.Append(depthVolat.ToString.PadRight(totalWidth:="depth volat.  ".Length))
        row.Append(HV.ToString.PadRight(totalWidth:="Hv       ".Length))

        out.Add(row.ToString & (_temRefVap - 1).ToString)
        out.Add(row.ToString & (_temRefVap + 1).ToString)

        out.Add("<END VOLATILIZATION>")

        Return out.ToArray

    End Function

    Public Const CATMolarMassStructure As String = "01  Molar mass and Structure"

#Region "    01  Molar mass and Structure"

    ''' <summary>
    ''' Chemical structure
    ''' as bitmap in png format
    ''' </summary>
    <DisplayName(
        "Structure")>
    <Description(
    "Chemical structure" & vbCrLf &
    "as bitmap in png format")>
    <Browsable(True)>
    <RefreshProperties(RefreshProperties.All)>
    <Category(CATMolarMassStructure)>
    Public Property chemStructure As New chemStructureProperty


    Private _molMass As Double = Double.NaN

    ''' <summary>
    ''' Molar mass in g/mol
    ''' [10.0 - 10000 ; MolMas]
    ''' </summary>
    <Category(CATMolarMassStructure)>
    <DisplayName(
    "Molar Mass")>
    <Description(
    "in g/mol [10.0 - 10000, MolMas]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.00'|unit=' g/mol'")>
    <DefaultValue(Double.NaN)>
    Public Property molMass As Double
        Get
            Return _molMass
        End Get
        Set

            Try

                If Value < 10 OrElse
                   Value > 10000 Then

                    MsgBox(
                        Prompt:=Value.ToString("0.00") &
                        " g/mol : " & "Molar mass exceeds limits [10|10000]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else
                    _molMass = Value
                End If

            Catch ex As Exception

                mylog(
                    LogTxt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property

    Private _smilesCode As String = String.Empty

    ''' <summary>
    ''' Smiles Code
    ''' Simplified Molecular Input
    ''' Line Entry Specification, click for editor 
    ''' </summary>
    <Category(CATMolarMassStructure)>
    <DisplayName(
    "Smiles Code")>
    <Description(
    "Simplified Molecular Input " & vbCrLf &
    "Line Entry Specification, click '...' for editor")>
    <Browsable(True)>
    <RefreshProperties(RefreshProperties.All)>
    <Editor(GetType(buttonEmulator), GetType(UITypeEditor))>
    <DefaultValue("")>
    Public Property smilesCode As String
        Get
            Return _smilesCode
        End Get
        Set(value As String)

            If value.Contains(buttonEmulator.Clicked) Then
                Process.Start("https://pubchem.ncbi.nlm.nih.gov/edit2/index.html")
            Else
                _smilesCode = value
            End If

        End Set
    End Property

#End Region

    Public Const CATVPSolubility As String = "02  VP and Solubility"

#Region "    02  VP and Solubility"

    Public Const stdTemRef As Double = 20

#Region "    Vapor pressure incl. ref temp."

    Private _preVapRef As Double = Double.NaN

    ''' <summary>
    ''' Saturated vapor pressure
    ''' in Pa [0|2.0E+05 ; PreVapRef]
    ''' </summary>
    <DisplayName("Vapor Pressure")>
    <Description("Saturated Vapor pressure" & vbCrLf &
                 "in Pa [0|2.0E+05 ; PreVapRef]")>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <Category(CATVPSolubility)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.00E-00'|unit=' Pa'")>
    <DefaultValue(Double.NaN)>
    Public Property preVapRef As Double
        Get
            Return _preVapRef
        End Get
        Set(value As Double)

            Try

                If value < 0 OrElse
                   value > 200000.0 Then

                    MsgBox(
                        Prompt:=value.ToString("0.00E00") &
                        " Pa : " & "Vapor Pressure exceeds limits [0|2e5]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else
                    _preVapRef = value
                End If

                'EVA classification
                EVAClassification = convertVaporPressure2EVAClassification(_preVapRef)

            Catch ex As Exception

                mylog(
                    LogTxt:=value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property


#Region "    EVA VP Classification"

    ''' <summary>
    ''' converts vapor pressure in PA
    ''' into the respective EVA classification
    ''' </summary>
    ''' <param name="vaporPressure">
    ''' vapor pressure in PA
    ''' </param>
    ''' <returns>
    ''' "non_volatile","semi_low",
    ''' "semi_medium","volatile"
    ''' </returns>
    Public Shared Function convertVaporPressure2EVAClassification(
                                    vaporPressure As Double) As eEVAClassificationVP
        If Double.IsNaN(vaporPressure) Then
            Return eEVAClassificationVP.not_dev
        ElseIf vaporPressure = 0 Then
            Return eEVAClassificationVP.non_volatile
        ElseIf vaporPressure < 0.00001 Then
            Return eEVAClassificationVP.non_volatile
        ElseIf vaporPressure >= 0.00001 AndAlso vaporPressure < 0.0001 Then
            Return eEVAClassificationVP.semi_low
        ElseIf vaporPressure >= 0.0001 AndAlso vaporPressure < 0.005 Then
            Return eEVAClassificationVP.semi_medium
        Else
            Return eEVAClassificationVP.volatile
        End If

    End Function


    ''' <summary>
    ''' EVA classification of volatility
    ''' </summary>
    <DisplayName(
        "EVA Classification")>
    <Description(
    DontUseInMailMerge & "<1E-5 non      ; 1E-5 <= VP < 1e-4 low " & vbCrLf &
    ">5E-3 volatile ; 1E-4 <= VP < 5e-3 semi")>
    <[ReadOnly](True)>
    <DefaultValue(CInt(eEVAClassificationVP.non_volatile))>
    <Category(CATVPSolubility)>
    <XmlIgnore>
    <Browsable(True)>
    Public Property EVAClassification As eEVAClassificationVP = eEVAClassificationVP.not_dev

    <TypeConverter(GetType(enumConverter(Of eEVAClassificationVP)))>
    Public Enum eEVAClassificationVP

        <Description("non volatile (VP < 1.0E-05 Pa)")>
        non_volatile

        <Description("low volatile (1.0E-05 Pa <= VP > 1.0E-04 Pa)")>
        semi_low

        <Description("semi volatile (1.0E-04 Pa <= VP > 5.0E-03 Pa)")>
        semi_medium

        <Description("volatile (VP >= 5.0E-03 Pa)")>
        volatile

        <Description(enumConverter(Of Type).not_defined)>
        not_dev = -1

    End Enum

#End Region


    Private _temRefVap As Double = stdTemRef

    ''' <summary>
    ''' Ref. temp. for vapor pressure
    ''' in °C [0|40 ; TemRefVap]
    ''' </summary>
    <DisplayName(
        "  at ref. temp.")>
    <Description(
    "Ref. temp. for vapor pressure" & vbCrLf &
    "in °C [0|40 ; TemRefVap, std. = 20°C]")>
    <[ReadOnly](False)>
    <Editor(GetType(nudValueEditorInteger), GetType(UITypeEditor))>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.0'|unit=' °C'")>
    <Category(CATVPSolubility)>
    <DefaultValue(stdTemRef)>
    Public Property temRefVap As Double
        Get
            Return _temRefVap
        End Get
        Set

            Try

                If Value < 0 OrElse
                   Value > 40 Then

                    MsgBox(
                        Prompt:=Value & "°C : " &
                        "Ref temp for vapor pressure exceeds limits [0|40]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else
                    _temRefVap = Value
                End If
            Catch ex As Exception

                MsgBox(
                    Prompt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                    Buttons:=MsgBoxStyle.Critical,
                    Title:="Unknown Error")

            End Try

        End Set
    End Property


#End Region

#Region "    Solubility incl. ref temp"


    Private _sblWatRef As Double = Double.NaN

    ''' <summary>
    ''' Water solubility
    ''' in mg/L [0.001|1e6]; SlbWatRef]
    ''' </summary>
    <DisplayName(
        "Solubility")>
    <Description(
    "Water solubility" & vbCrLf &
    "in mg/L [0.001|1e6 ; SlbWatRef]")>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <Category(CATVPSolubility)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= 'G4'|unit=' mg/L'")>
    <DefaultValue(Double.NaN)>
    Public Property slbWatRef As Double
        Get
            Return _sblWatRef
        End Get
        Set(value As Double)

            Try

                If value < 0.001 OrElse
                   value > 1000000 Then

                    MsgBox(
                        Prompt:=value.ToString("0.00") &
                        " mg/L : " & "Solubility exceeds limits [0.001|1e6]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else
                    _sblWatRef = value
                End If

            Catch ex As Exception

                mylog(
                    LogTxt:=value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property


    Private _temRefSlb As Double = stdTemRef

    ''' <summary>
    ''' Ref. temp. for solubility
    ''' in °C [0|40 ; TemRefSol]
    ''' </summary>
    <DisplayName(
        "  at ref. temp.")>
    <Description(
    "Ref. temp. for water solubility" & vbCrLf &
    "in °C [0|40 ; TemRefSlb, std. = 20°C]")>
    <[ReadOnly](False)>
    <Editor(GetType(nudValueEditorInteger), GetType(UITypeEditor))>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= 'G4'|unit=' °C'")>
    <Category(CATVPSolubility)>
    <DefaultValue(stdTemRef)>
    Public Property temRefSlb As Double
        Get
            Return _temRefSlb
        End Get
        Set

            Try

                If Value < 0 OrElse
                   Value > 40 Then

                    MsgBox(
                        Prompt:=Value & "°C : " &
                        "Ref temp for solubility exceeds limits [0|40]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else
                    _temRefSlb = Value
                End If
            Catch ex As Exception

                MsgBox(
                    Prompt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                    Buttons:=MsgBoxStyle.Critical,
                    Title:="Unknown Error")

            End Try

        End Set
    End Property

#End Region

#End Region

    Public Const CATMisc As String = "03  Misc"

#Region "    03  Misc"

    <AttributeProvider("format= 'G4'|unit=''")>
    <Category(CATMisc)>
    <TypeConverter(GetType(dblConv))>
    <DefaultValue(Double.NaN)>
    Public Property logP As Double = Double.NaN

    <AttributeProvider("format= 'G4'|unit=''")>
    <Category(CATMisc)>
    <TypeConverter(GetType(dblConv))>
    <DefaultValue(Double.NaN)>
    Public Property pKa As Double = Double.NaN

#End Region

#Region "    04  Constants"

#Region "    Vaporization"

    Public Const CATVaporization As String = "04a Vaporization"

    ''' <summary>
    ''' Std. molar enthalpy of vaporization = 95 kJ/mol
    ''' </summary>
    ''' <remarks></remarks>
    Public Const stdMolEntVap As Double = 95

    Private _molEntVap As Double = StdMolEntVap

    ''' <summary>
    ''' MolEntVap
    ''' Molar enthalpy of vaporization in kJ/mol
    ''' [-200|200; MolEntVap; std. = 95 kJ/mol]
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName("MolEntVap")>
    <Description("Molar enthalpy of vaporization in kJ/mol" & vbCrLf &
                 "[-200|200; MolEntVap; std. = 95 kJ/mol]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATVaporization)>
    <DefaultValue(StdMolEntVap)>
    Public Property molEntVap As Double
        Get

            Return _molEntVap

        End Get
        Set

            Try

                If Value < -200 OrElse
                   Value > 200 Then

                    MsgBox(
                        Prompt:=Value.ToString("0.00") & " mg/L : " & "Molar enthalpy of vaporization [-200|200]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else

                    If Value <> CDbl(StdMolEntVap) Then

                        If _
                            MsgBox(
                                Prompt:=Value & " kJ/mol : Really? std. value is " & StdMolEntVap &
                                                " kJ/mol and you shouldn't touch it!!",
                                Buttons:=MsgBoxStyle.YesNo,
                                Title:="Don't Change BASIC values!!") <> MsgBoxResult.No Then

                            _molEntVap = Value

                        End If

                    Else
                        _molEntVap = Value
                    End If

                End If

            Catch ex As Exception

                mylog(
                    LogTxt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property


    ''' <summary>
    ''' ENPY
    ''' Enthalpy of vaporization in kcal/mol
    ''' PRZM value; std. = 22.7 kcal/mol, 1kcal = 4.184J
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName("PRZM : ENPY")>
    <Description("Enthalpy of vaporization" & vbCrLf &
                 "PRZM value; std. = 22.7 kcal/mol = 95 kJ/mol, 1kcal = 4.184 J")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATVaporization)>
    <DefaultValue(22.7)>
    Public ReadOnly Property ENPY As Double
        Get

            Try
                Return dblConv.conv2String(value:=(_molEntVap / 4.184), format:="G3")
            Catch ex As Exception

                mylog(
                    LogTxt:="MolEntVap : " & _molEntVap & "kJ/mol" & vbCrLf &
                            "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")

                Return Double.NaN

            End Try

        End Get
    End Property

#End Region

#Region "    Dissolution"

    Public Const CATDissolution As String = "04b Dissolution"


    ''' <summary>
    ''' Std. molar enthalpy of dissolution = 27 kJ/mol
    ''' </summary>
    ''' <remarks></remarks>
    Public Const StdMolEntSlb As Double = 27

    Private _molEntSlb As Double = StdMolEntSlb

    ''' <summary>
    ''' Molar enthalpy of dissolution in kJ/mol
    ''' -200|200; MolEntSlb; std. = 27 kJ/mol
    ''' MolEntSlb
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName("MolEntSlb")>
    <Description("Molar enthalpy of dissolution in kJ/mol" & vbCrLf &
                 "[-200|200; MolEntSlb; std. = 27 kJ/mol]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATDissolution)>
    <DefaultValue(StdMolEntSlb)>
    Public Property molEntSlb As Double
        Get
            Return _molEntSlb
        End Get
        Set

            Try

                If Value < -200 OrElse
                   Value > 200 Then

                    MsgBox(
                        Prompt:=Value.ToString("0.00") & " mg/L : " & "Molar enthalpy of dissolution [-200|200]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else

                    If Value <> CDbl(StdMolEntSlb) Then

                        If _
                         MsgBox(
                             Prompt:=Value & " kJ/mol : Really? std. value is " & StdMolEntSlb &
                                             " kJ/mol and you shouldn't touch it!!",
                             Buttons:=MsgBoxStyle.YesNo,
                             Title:="Don't Change BASIC values!!") <> MsgBoxResult.No Then

                            _molEntSlb = Value

                        End If

                    Else
                        _molEntSlb = Value
                    End If
                End If

            Catch ex As Exception

                mylog(
                    LogTxt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property


#End Region

#Region "    Diffusion"

    Public Const CATDiffusion As String = "04c Diffusion"

    ''' <summary>
    ''' Std. diffusion coefficient in water = 4.3E-5 m²/day
    ''' </summary>
    ''' <remarks></remarks>
    Public Const StdCofDifWatRef As Double = 0.000043

    Private _cofDifWatRef As Double = StdCofDifWatRef

    ''' <summary>
    ''' Reference diffusion coefficient in water in m²/day
    ''' [0|0.002; CofDifWatRef; std. = 4.3E-5 m²/day]
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName("CofDifWatRef")>
    <Description("Reference diffusion coefficient in water in m²/day" & vbCrLf &
                 "[0|0.002; CofDifWatRef; std. = 0.000043 (4.3E-05) m²/day]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATDiffusion)>
    <DefaultValue(StdCofDifWatRef)>
    Public Property cofDifWatRef As Double
        Get
            Return _cofDifWatRef
        End Get
        Set(value As Double)

            Try


                If value < 0 OrElse
                   value > 0.002 Then

                    MsgBox(
                        Prompt:=value.ToString("0.00") & "m²/day : " & "Diffusion coefficient in water [0|0.002]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")
                Else

                    If value <> CDbl(StdCofDifWatRef) Then

                        If _
                            MsgBox(
                                Prompt:=value & " m²/day : Really? std. value is " & CDbl(StdCofDifWatRef) &
                                                " m²/day and you shouldn't touch it!!",
                                Buttons:=MsgBoxStyle.YesNo,
                                Title:="Don't Change BASIC values!!") <> MsgBoxResult.No Then

                            _cofDifWatRef = value
                        End If

                    Else
                        _cofDifWatRef = value
                    End If

                End If

            Catch ex As Exception

                mylog(
                    LogTxt:=value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property

    ''' <summary>
    ''' Std. diffusion coefficient in air = 0.43 m²/day
    ''' </summary>
    ''' <remarks></remarks>
    Public Const StdCofDifAirRef As Double = 0.43

    Private _cofDifAirRef As Double = StdCofDifAirRef

    ''' <summary>
    ''' Reference diffusion coefficient in water in m²/day
    ''' [0|0.002; CofDifWatRef; std. = 4.3E-5 m²/day]
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName("CofDifAirRef")>
    <Description("Reference diffusion coefficient in air in [m²/day]" & vbCrLf &
                 "PEARL 0.1|3; CofDifAirRef; std. = 0.43 m²/day]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATDiffusion)>
    <DefaultValue(StdCofDifAirRef)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.00'|unit=' m²/day'")>
    Public Property cofDifAirRef As Double
        Get
            Return _cofDifAirRef
        End Get
        Set(value As Double)

            Try

                If value < 0.1 OrElse
                   value > 3 Then

                    MsgBox(
                        Prompt:=value.ToString("0.00") & "m^2/day : " & "Diffusion coefficient in air [0.1|3]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else

                    If _
                MsgBox(
                    Prompt:=value & " m^2/day : Really? std. value is 0.43 m^2/day and you shouldn't touch it!!",
                    Buttons:=MsgBoxStyle.YesNo,
                    Title:="Don't Change BASIC values!!") <> MsgBoxResult.No Then


                        _cofDifAirRef = value

                    End If

                End If

            Catch ex As Exception

                mylog(
                    LogTxt:=value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property


    Private _temRefDif As Double = stdTemRef

    ''' <summary>
    ''' Ref. temp. for Diff. coeff
    ''' in °C [0|40 ; TemRefDif]
    ''' </summary>
    <DisplayName(
        "  at ref. temp.")>
    <Description(
    "Ref. temp. for Diff. coeff" & vbCrLf &
    "in °C [0|40 ; TemRefDif, std. = 20°C]")>
    <[ReadOnly](False)>
    <Editor(GetType(nudValueEditorInteger), GetType(UITypeEditor))>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.0'|unit=' °C'")>
    <Category(CATDiffusion)>
    <DefaultValue(stdTemRef)>
    Public Property temRefDif As Double
        Get
            Return _temRefDif
        End Get
        Set

            Try

                If Value < 0 OrElse
                   Value > 40 Then

                    MsgBox(
                        Prompt:=Value & "°C : " &
                        "Ref temp for Diff. coeff measur. exceeds limits [0|40]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else
                    _temRefDif = Value
                End If
            Catch ex As Exception

                MsgBox(
                    Prompt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                    Buttons:=MsgBoxStyle.Critical,
                    Title:="Unknown Error")

            End Try

        End Set
    End Property


#Region "    Derived PRZM values"

    ''' <summary>
    ''' Henry's law constant in J/mol
    ''' (VP * MolMass / Solubility)/ (R * Tref)
    ''' </summary>
    ''' <returns></returns>
    <Category(CATDiffusion)>
    <DisplayName(
    "PRZM Henry")>
    <Description(
    "Henry's law constant (dimensionsless)" & vbCrLf &
    "(VP * MolMass / Solubility)/ (R * Tref)")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '.00E-00'")>
    <XmlIgnore>
    Public ReadOnly Property henrykPRZM As Double
        Get

            Try

                If _
                    Not Double.IsNaN(_preVapRef) AndAlso
                    Not Double.IsNaN(_sblWatRef) AndAlso
                    Not Double.IsNaN(_molMass) Then

                    Return ((_preVapRef * _molMass / _sblWatRef) /
                                   (8.3143 * (_temRefVap + 273.15)))
                Else
                    Return Double.NaN
                End If

            Catch ex As Exception
                Return Double.NaN
            End Try

        End Get
    End Property

    ''' <summary>
    ''' DAIR
    ''' Diffusion coefficient in the air in cm^2/day
    ''' PRZM value; std. = 4300.00 cm^2/day
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName("PRZM  : DAIR Base CofDifAirRef")>
    <Description("Diffusion coefficient in the air in cm²/day" & vbCrLf &
                 "PRZM value; std. = 4300.00 [cm²/day]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATDiffusion)>
    <DefaultValue(4300.0)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= 'G5'|unit=' cm²/day'")>
    Public ReadOnly Property DAIR As Double
        Get

            Try
                Return _cofDifAirRef * 100 * 100
            Catch ex As Exception

                mylog(
                   LogTxt:="CofDifAirRef : " & _cofDifAirRef & " m²/day" & vbCrLf &
                           "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                   Log2MsgBox:=True,
                   MsgBoxBtn:=MsgBoxStyle.Critical,
                   MsgTitle:="Unknown Error")

                Return Double.NaN
            End Try

        End Get
    End Property


    ''' <summary>
    ''' Diffusion coefficient in water in m²/s
    ''' MACRO value; std. = 4.976852E-10 m²/s
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName("MACRO : DIFF Base CofDifWatRef")>
    <Description("Diffusion coefficient in water in m²/s" & vbCrLf &
                 "MACRO value; std. = 4.976852E-10 [m²/s]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATDiffusion)>
    <DefaultValue(0.0000000004976852)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.0000E00'|unit=' m²/s'")>
    Public ReadOnly Property DIFF As Double
        Get

            If Not Double.IsNaN(_cofDifWatRef) Then
                Return _cofDifWatRef / (60 * 60 * 24)
            Else
                Return Double.NaN
            End If

        End Get
    End Property

#End Region



#End Region

#Region "    PELMO"

    ''' <summary>
    ''' Henry's law constant in J/mol
    ''' (VP * MolMass / Solubility)/ (R * Tref)
    ''' </summary>
    ''' <returns></returns>
    <Category(CATDiffusion)>
    <DisplayName(
    "PELMO Henry")>
    <Description(
    "Henry's law constant in J/mol" & vbCrLf &
    "HENRYK (PRZM) * R * T <=> VP * MolMass / Solubility")>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.00E-00'|unit=' J/mol'")>
    <XmlIgnore>
    Public ReadOnly Property henrykPELMO As Double
        Get

            Try

                If _
                    Not Double.IsNaN(henrykPRZM) Then

                    Return henrykPRZM * (8.3143 * (_temRefVap + 273.15))
                Else
                    Return Double.NaN
                End If

            Catch ex As Exception
                Return Double.NaN
            End Try

        End Get
    End Property

    ''' <summary>
    ''' Diffusion coefficient in water in cm²/s
    ''' PELMO value; std. = 0.0498 cm²/s
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName("PELMO : 'diff air' Base CofDifWatRef")>
    <Description("Diffusion coefficient in water in cm²/s" & vbCrLf &
                 "PELMO value; std. = 0.0498 [cm²/s]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <Category(CATDiffusion)>
    <DefaultValue(0.0498)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.0000'|unit=' cm²/s'")>
    Public ReadOnly Property diffCoeffAirPELMO As Double
        Get

            If Not Double.IsNaN(DIFF) Then
                Return DIFF * 1000 * 1000 * 100
            Else
                Return Double.NaN
            End If

        End Get
    End Property


    Public Const StdDepthVolat As Double = 0.1

    <Category(CATDiffusion)>
    <DefaultValue(StdDepthVolat)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.00'|unit=' cm'")>
    Public Property depthVolat As Double = StdDepthVolat


    Public Const StdHV As Double = 98400

    <Category(CATDiffusion)>
    <DefaultValue(StdHV)>
    Public Property HV As Double = StdHV


#End Region

#End Region

#Region "    05  Outputs, Experts only"

    Public Const browseOut As Boolean = False

    Public Const catPRLTXWOutput As String = "05a PRL / TXW Out"
    Public Const catPRZMOutput As String = "05b PRZM Out"
    Public Const catPELMOOutput As String = "05c PELMO Out"

#Region "    PRZM RECORD26"

    ''' <summary>
    ''' Description for PRZM RECORD26 parameters
    ''' Diffusion coefficient
    ''' Henry's law constant and enthalpy of vaporization
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName("RECORD26 Description")>
    <Description("Description for RECORD26 parameters")>
    <Browsable(browseOut)>
    <[ReadOnly](True)>
    <Category(CATPRZMOutput)>
    <XmlIgnore>
    Public Property PRZM_RECORD26_Description As String()


    ''' <summary>
    ''' RECORD26 PRZM
    ''' Diffusion coefficient
    ''' Henry's law constant and enthalpy of vaporization
    ''' </summary>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName("RECORD26 PRZM")>
    <Description("Diffusion coefficient" & vbCrLf &
                 "Henry's law constant and enthalpy of vaporization")>
    <Browsable(browseOut)>
    <[ReadOnly](True)>
    <Category(CATPRZMOutput)>
    <XmlIgnore>
    Public Property PRZM_RECORD26 As String()


#Region "    Methods"

    Public Enum eNoOfSubst
        ParOnly
        ParMet01
        ParMet01Met02
    End Enum

    Public Shared Function getPRZM_RECORD26_PhyChem_Description(
                                    Optional NoOfSubst As eNoOfSubst = eNoOfSubst.ParOnly) As String()

        Dim out As New List(Of String)
        Dim header As String = String.Empty

        out.AddRange(
       {"*** --- RECORD 26 PhysChem ---",
        "*** 01 DAIR    Diffusion coefficient for the pesticide(s) in the air",
        "***            std. = 4300 cm°2 day-1",
        "*** 02 HENRYK  Henry's law constant of the pesticide(s)",
        "***            in J/mol",
        "*** 03 ENPY    Enthalpy of vaporization of the pesticide(s)",
        "***            std. = 22.7 kcal/mole",
        "*** "})

        header = "*** PAR01   PAR02   PAR03"

        If NoOfSubst = eNoOfSubst.ParMet01 Then
            header &= " |  MET01   MET02   MET03"
        ElseIf NoOfSubst = eNoOfSubst.ParMet01Met02 Then
            header &= " |  M0101   M0102   M0103 |  M0201   M0202   M0203"
        End If

        out.Add(header)

        Return out.ToArray

    End Function

    Public Function getPRZM_RECORD26_PhysChem(PhysChemList As List(Of physChem)) As String()

        Dim out As New List(Of String)
        Dim row As New StringBuilder

        For counter = 0 To PhysChemList.Count - 1

            With PhysChemList(counter)

                row.Append(.DAIR.ToString("0.00").PadLeft("*** PAR01".Count))
                row.Append(.henrykPRZM.ToString(".00E-00").PadLeft("   PAR02".Count))
                row.Append(.ENPY.ToString("0.00").PadLeft("   PAR03".Count))

            End With

        Next

        out.Add(row.ToString)

        Return out.ToArray

    End Function

#End Region

#End Region

#Region "    TOXSWA and PEARL"

    '    Public Const seeOut As Boolean = True

    '    <RefreshProperties(RefreshProperties.All)>
    '    <DisplayName("TXW/PRL PhyChem Overview")>
    '    <Description("PhysChem section for this substance" & vbCrLf &
    '                 "for TOXSWA 5.5.3 or PEARL 5.5.5")>
    '    <Browsable(browseOut)>
    '    <[ReadOnly](True)>
    '    <Category(CATPRLTXWOutput)>
    '    <XmlIgnore>
    '    Public Property txwPrlPhysChemOvw As String()

    '    <RefreshProperties(RefreshProperties.All)>
    '    <DisplayName("TXW/PRL PhyChem Values")>
    '    <Description("PhysChem section for this substance" & vbCrLf &
    '                 "for TOXSWA 5.5.3 or PEARL 5.5.5")>
    '    <Browsable(browseOut)>
    '    <[ReadOnly](True)>
    '    <Category(CATPRLTXWOutput)>
    '    <XmlIgnore>
    '    Public Property txwPrlPhysChemValues As String()

    '    <RefreshProperties(RefreshProperties.All)>
    '    <DisplayName("TXW/PRL PhyChem Std. Values")>
    '    <Description("PhysChem section for this substance" & vbCrLf &
    '                 "for TOXSWA 5.5.3 or PEARL 5.5.5")>
    '    <Browsable(browseOut)>
    '    <[ReadOnly](True)>
    '    <Category(CATPRLTXWOutput)>
    '    <XmlIgnore>
    '    Public Property txwPrlPhysChemStdValues As String()

    '    Public Function fillTxwPrlPhysChem(
    '                           Optional ValueEndPos As Integer = pathWay.valueEndPos,
    '                           Optional NameEndPos As Integer = pathWay.nameEndPos,
    '                           Optional UnitEndPos As Integer = pathWay.unitEndPos,
    '                           Optional MinMaxPos As Integer = pathWay.minMaxPos,
    '                           Optional sumCode As String = "|IOP|",
    '                           Optional inclHeader As Boolean = False) As List(Of String())

    '        Dim out As New List(Of String)
    '        Dim outFunction As New List(Of String())
    '        Dim row As String = String.Empty
    '        Dim codeOffset As Integer = 0


    '        If sumCode.Length <= 5 Then
    '            codeOffset = 0
    '        Else
    '            codeOffset = sumCode.Length - 5
    '        End If

    '#Region "     Overview"

    '        If inclHeader Then out.Add("*** PhysChem ***")
    '        out.Add("* Molar Mass       = " & _molMass & " g/mol")
    '        out.Add("* Vapor Pressure   = " & _preVapRef & " Pa at " & _temRefVap & "°C")
    '        out.Add("*                  = " & extras.getEnumDescription(EVAClassification))
    '        out.Add("* Water Solubility = " & _sblWatRef & " mg/L at " & _temRefSlb & "°C")

    '        out.Add("* ")

    '        Me.txwPrlPhysChemOvw = out.ToArray
    '        outFunction.Add(out.ToArray)
    '        out.Clear()

    '#End Region

    '#Region "     Values"

    '        If inclHeader Then out.Add("***  PhysChem : MolMass, VP, Solubility ***")

    '        row = Me.molMass.ToString.PadRight(ValueEndPos)
    '        row = (row & "MolMas_" & sumCode).PadRight(NameEndPos + codeOffset)
    '        row = (row & "(g.mol-1)").PadRight(UnitEndPos)
    '        row = (row & "! Molar mass of parent substance").PadRight(MinMaxPos)
    '        row &= "[10.0 - 10000]"

    '        out.Add(row)

    '        row = Me.preVapRef.ToString.PadRight(ValueEndPos)
    '        row = (row & "PreVapRef_" & sumCode).PadRight(NameEndPos + codeOffset)
    '        row = (row & "(Pa)").PadRight(UnitEndPos)

    '        If Me.temRefVap <> stdTemRef Then
    '            row = (row & "! Vapour pressure of substance").PadRight(MinMaxPos)
    '        Else
    '            row = (row & "! Vapour pressure of substance at " & Me.temRefVap & "°C").PadRight(MinMaxPos)
    '        End If

    '        row &= "[0|2e5]"

    '        out.Add(row)

    '        If Me.temRefVap <> stdTemRef Then

    '            row = Me.temRefVap.ToString.PadRight(ValueEndPos)
    '            row = (row & "TemRefVap_" & sumCode).PadRight(NameEndPos + codeOffset)
    '            row = (row & "(C)").PadRight(UnitEndPos)
    '            row = (row & "! Ref. temp. for vapour pressure").PadRight(MinMaxPos)
    '            row &= "[0|40]"

    '            out.Add(row)

    '        End If


    '        row = Me.slbWatRef.ToString.PadRight(ValueEndPos)
    '        row = (row & "SlbWatRef_" & sumCode).PadRight(NameEndPos + codeOffset)
    '        row = (row & "(mg.L-1)").PadRight(UnitEndPos)

    '        If Me.temRefSlb <> stdTemRef Then
    '            row = (row & "! Water solubility of substance").PadRight(MinMaxPos)
    '        Else
    '            row = (row & "! Water solubility of substance at " & Me.temRefSlb & "°C").PadRight(MinMaxPos)
    '        End If

    '        row &= "[0.001|1e6]"

    '        out.Add(row)

    '        If Me.temRefSlb <> stdTemRef Then

    '            row = Me.temRefSlb.ToString.PadRight(ValueEndPos)
    '            row = (row & "TemRefSlb_" & sumCode).PadRight(NameEndPos + codeOffset)
    '            row = (row & "(C)").PadRight(UnitEndPos)
    '            row = (row & "! Ref. temp. for solubility").PadRight(MinMaxPos)
    '            row &= "[0|40]"

    '            out.Add(row)

    '        End If

    '        If Me.molEntVap <> StdMolEntVap Then

    '            out.Add("* Std. Value (95 kJ/mol) Changed !!!")

    '            row = Me.molEntVap.ToString.PadRight(ValueEndPos)
    '            row = (row & "MolEntVap_" & sumCode).PadRight(NameEndPos + codeOffset)
    '            row = (row & "(kJ.mol-1)").PadRight(UnitEndPos)
    '            row = (row & "! Molar enthalpy of vaporization").PadRight(MinMaxPos)
    '            row &= "[-200|200]"

    '            out.Add(row)

    '        End If

    '        If Me.molEntSlb <> StdMolEntSlb Then

    '            out.Add("* Std. Value (27 kJ/mol) Changed !!!")

    '            row = Me.molEntSlb.ToString.PadRight(ValueEndPos)
    '            row = (row & "MolEntSlb_" & sumCode).PadRight(NameEndPos + codeOffset)
    '            row = (row & "(kJ.mol-1)").PadRight(UnitEndPos)
    '            row = (row & "! Molar enthalpy of dissolution").PadRight(MinMaxPos)
    '            row &= "[-200|200]"

    '            out.Add(row)

    '        End If

    '        out.Add("* ")
    '        Me.txwPrlPhysChemValues = out.ToArray
    '        outFunction.Add(out.ToArray)
    '        out.Clear()

    '#End Region

    '#Region "     Std. Values"


    '        out.Add("*** " & sumCode.PadRight(5) &
    '                " PhysChem std. values : Molar enthalpy of vaporization/dissolution ***")

    '        If Me.temRefVap = stdTemRef Then

    '            row = Me.temRefVap.ToString.PadRight(ValueEndPos)
    '            row = (row & "TemRefVap_" & sumCode).PadRight(NameEndPos + codeOffset)
    '            row = (row & "(C)").PadRight(UnitEndPos)
    '            row = (row & "! Ref. temp. for vapour pressure").PadRight(MinMaxPos)
    '            row &= "[0|40]"

    '            out.Add(row)

    '        End If

    '        If Me.temRefSlb = stdTemRef Then

    '            row = Me.temRefSlb.ToString.PadRight(ValueEndPos)
    '            row = (row & "TemRefSlb_" & sumCode).PadRight(NameEndPos + codeOffset)
    '            row = (row & "(C)").PadRight(UnitEndPos)
    '            row = (row & "! Ref. temp. for solubility").PadRight(MinMaxPos)
    '            row &= "[0|40]"

    '            out.Add(row)

    '        End If

    '        If Me.molEntVap = StdMolEntVap Then

    '            row = Me.molEntVap.ToString.PadRight(ValueEndPos)
    '            row = (row & "MolEntVap_" & sumCode).PadRight(NameEndPos + codeOffset)
    '            row = (row & "(kJ.mol-1)").PadRight(UnitEndPos)
    '            row = (row & "! Molar enthalpy of vaporization").PadRight(MinMaxPos)
    '            row &= "[-200|200]"

    '            out.Add(row)

    '        End If

    '        If Me.molEntSlb = StdMolEntSlb Then

    '            row = Me.molEntSlb.ToString.PadRight(ValueEndPos)
    '            row = (row & "MolEntSlb_" & sumCode).PadRight(NameEndPos + codeOffset)
    '            row = (row & "(kJ.mol-1)").PadRight(UnitEndPos)
    '            row = (row & "! Molar enthalpy of dissolution").PadRight(MinMaxPos)
    '            row &= "[-200|200]"

    '            out.Add(row)

    '        End If

    '        out.Add("* ")
    '        Me.txwPrlPhysChemStdValues = out.ToArray
    '        outFunction.Add(out.ToArray)
    '        out.Clear()

    '#End Region

    '        Return outFunction

    '    End Function

#End Region

#Region "    PELMO Volatilization"

    <Browsable(browseOut)>
    <[ReadOnly](True)>
    <Category(catPELMOOutput)>
    <XmlIgnore>
    Public Property PELMOVolatilization As String()




#End Region

#End Region



End Class
