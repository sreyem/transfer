﻿
Imports System.ComponentModel
Imports System.Drawing.Design
Imports System.Xml.Serialization
Imports System.Web.Script.Serialization

Imports essentials
Imports DBs.FOCUSGWdb
Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary
Imports System.Runtime.Serialization

<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class compound

    Inherits compoundBase

    Public Const catScenarioSpecific As String = "00  Scenario Specific"

    Private _scenarioSpecific As eYesNo = eYesNo.No

    <Browsable(True)>
    <DisplayName("Scenario Specific ?")>
    <Category(catScenarioSpecific)>
    Public Property scenarioSpecific As eYesNo
        Get
            Return _scenarioSpecific
        End Get
        Set
            _scenarioSpecific = Value
            If _scenarioSpecific = eYesNo.Yes Then

                Dim temp As New List(Of compoundSceBase)
                Dim obj As Object

                For scenario As eScenariosGW = eScenariosGW.Chateaudun To eScenariosGW.Thiva
                    temp.Add(New compoundSceBase(scenario:=scenario))
                Next

                compoundSceBase = temp.ToArray

            Else
                compoundSceBase = Nothing
            End If
        End Set
    End Property

    <Browsable(True)>
    <DefaultValue(CType(Nothing, Object))>
    <Category(catScenarioSpecific)>
    <DisplayName("Data")>
    Public Property compoundSceBase As compoundSceBase() = Nothing

    <Category(catDetails)>
    Public Property FacZTra As New degT50New.facZTra

End Class

''' <summary>
''' Compound base + scenario
''' </summary>
<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class compoundSceBase

    Inherits compoundBase

    Public Sub New()

    End Sub

    Public Sub New(scenario As eScenariosGW)
        Me.scenario = scenario
    End Sub

    <Browsable(False)>
    Public Overrides ReadOnly Property name As String
        Get
            Return extras.getEnumDescription(scenario).PadRight(17) & MyBase.name
        End Get
    End Property

    <Category("00")>
    <DisplayName("FOCUSgw Scenario")>
    Public Property scenario As eScenariosGW = eScenariosGW.not_def

End Class


''' <summary>
''' Main compound class
''' </summary>
<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class compoundBase

#Region "    Constructor"

    Public Sub New()
    End Sub

    <Browsable(False)>
    <XmlIgnore> <ScriptIgnore>
    Public Property collapseStd As String() =
        {catVanillaDFOP, catDetails}

#End Region

#Region "    output PEARL"


    Public Function createPELMOdegRow(
                                     ff As Double,
                                     Optional PELMOpos As ePelmoPosition = ePelmoPosition.not_def,
                                     Optional scenario As eScenariosGW = eScenariosGW.not_def,
                                     Optional empty As Boolean = False) As String()


        Select Case Me.degType

            Case eDegType.SFO

                With Me.degt50Sorption.SFO

                    Return .degT50.createPELMOdegRow(ff:=ff, PELMOpos:=PELMOpos, scenario:=scenario, empty:=empty)

                End With

        End Select

    End Function

    Public Function createPEARLCompound(
                Optional scenario As eScenariosGW = eScenariosGW.not_def) As List(Of String())

        Dim out As New List(Of String())
        Dim para01 As New List(Of String())
        Dim para02 As New List(Of String())

        Dim top As New List(Of String)
        Dim std As New List(Of String)
        Dim both As New List(Of String)

        Dim description As String
        Dim row As String
        Dim temp As New List(Of String)

        Dim iop As String

        iop = Me.common.metaData.iop

        description = iop.PadRight(7)

        With Me.degt50Sorption

            Select Case .DegType

                Case eDegType.SFO

                    With .SFO

                        If scenario <> eScenariosGW.not_def AndAlso
                                        (.degT50.scenarioSpecificDT50 = eOnOff.On OrElse
                                        .sorption.scenarioSpecificSorption = eOnOff.On) Then

                            With .degT50

                                If Not IsNothing(.scenarioSpecificData) AndAlso
                                                .scenarioSpecificData.Count > 0 Then

                                    For Each member In .scenarioSpecificData

                                        If member.scenario = scenario Then

                                            description = " | " & scenario.ToString

                                        End If

                                    Next

                                End If
                            End With

                            With .sorption
                                If Not description.Contains("|") AndAlso
                                                         Not IsNothing(.scenarioSpecificData) AndAlso
                                                         .scenarioSpecificData.Count > 0 Then

                                    For Each member In .scenarioSpecificData

                                        If member.scenario = scenario Then

                                            description = " | " & scenario.ToString

                                        End If

                                    Next

                                End If
                            End With
                        Else

                            description = ""

                        End If

                        top.Add("*** Start " & iop.PadRight(7) & " Base Parameters " & description & " ***")
                        std.Add("*** Start " & iop.PadRight(7) & " Std. Parameters " & description & " ***")
                        both.Add("*** Start " & iop.PadRight(7) & " " & description & " ***")

                        out = .degT50.createPEARLDegT50(iop:=iop, scenario:=scenario)

                        top.AddRange(out(0))
                        std.Add("*".PadRight(10) & "degT50")
                        std.AddRange(out(1))
                        both.AddRange(out(2))

                        out.Clear()

                        out = .sorption.createPEARLSorption(iop:=iop, scenario:=scenario)
                        top.AddRange(out(0))
                        std.Add("*".PadRight(10) & "Sorption")
                        std.AddRange(out(1))
                        both.AddRange(out(2))

                    End With

                    temp.Add("*".PadRight(10) & "Non-equ. sorption; switched off")
                    temp.Add(
                            createPrlRow(
                            Value:=0.ToString,
                            iop:=iop,
                            parameterName:="CofDesRat_",
                            unit:="(d-1)",
                            description:="Desorption rate coefficient",
                            range:="[0|0.5]"))

                    temp.Add(
                            createPrlRow(
                            Value:=0.ToString,
                            iop:=iop,
                            parameterName:="FacSorNeqEql_",
                            unit:="(-)",
                            description:="CofFreNeq/CofFreEql",
                            range:="[0|-]"))

                    std.AddRange(temp)
                    both.AddRange(temp)

                Case eDegType.DFOP

#Region "   k1"

                    With .DFOP

                        If scenario <> eScenariosGW.not_def AndAlso
                                       (.k1.scenarioSpecificDT50 = eOnOff.On OrElse
                                       .sorption.scenarioSpecificSorption = eOnOff.On) Then

                            With .k1

                                If Not IsNothing(.scenarioSpecificData) AndAlso
                                                .scenarioSpecificData.Count > 0 Then

                                    For Each member In .scenarioSpecificData

                                        If member.scenario = scenario Then

                                            description = " | " & scenario.ToString

                                        End If

                                    Next

                                End If

                            End With

                            With .sorption

                                If Not description.Contains("|") AndAlso
                                                         Not IsNothing(.scenarioSpecificData) AndAlso
                                                         .scenarioSpecificData.Count > 0 Then

                                    For Each member In .scenarioSpecificData

                                        If member.scenario = scenario Then

                                            description = " | " & scenario.ToString

                                        End If

                                    Next

                                End If

                            End With

                        Else

                            description = ""

                        End If

                        top.Add("*** Start " & iop.PadRight(7) & " DFOP k1 Base Parameters " & description & " ***")
                        std.Add("*** Start " & iop.PadRight(7) & " DFOP k1 Std. Parameters " & description & " ***")
                        both.Add("*** Start " & iop.PadRight(7) & " DFOP k1 " & description & " ***")

                        out = .k1.createPEARLDegT50(iop:=iop, scenario:=scenario)
                        top.AddRange(out(0))
                        std.Add("*".PadRight(10) & "degT50")
                        std.AddRange(out(1))
                        both.AddRange(out(2))

                        out.Clear()

                        out = .sorption.createPEARLSorption(iop:=iop, scenario:=scenario)
                        top.AddRange(out(0))
                        std.Add("*".PadRight(10) & "Sorption")
                        std.AddRange(out(1))
                        both.AddRange(out(2))

                    End With

                    temp.Add("*".PadRight(10) & "Non-equ. sorption; switched off")
                    temp.Add(
                            createPrlRow(
                            Value:=0.ToString,
                            iop:=iop,
                            parameterName:="CofDesRat_",
                            unit:="(d-1)",
                            description:="Desorption rate coefficient",
                            range:="[0|0.5]"))

                    temp.Add(
                            createPrlRow(
                            Value:=0.ToString,
                            iop:=iop,
                            parameterName:="FacSorNeqEql_",
                            unit:="(-)",
                            description:="CofFreNeq/CofFreEql",
                            range:="[0|-]"))

                    std.AddRange(temp)
                    both.AddRange(temp)

                    para01.Add(top.ToArray)
                    para01.Add(std.ToArray)
                    para01.Add(both.ToArray)

                    top.Clear()
                    std.Clear()
                    both.Clear()

#End Region

#Region "   k2"

                    With .DFOP

                        If scenario <> eScenariosGW.not_def AndAlso
                                       (.k2.scenarioSpecificDT50 = eOnOff.On OrElse
                                       .sorption.scenarioSpecificSorption = eOnOff.On) Then

                            With .k2

                                If Not IsNothing(.scenarioSpecificData) AndAlso
                                                .scenarioSpecificData.Count > 0 Then

                                    For Each member In .scenarioSpecificData

                                        If member.scenario = scenario Then

                                            description = " | " & scenario.ToString

                                        End If

                                    Next

                                End If

                            End With

                            With .sorption

                                If Not description.Contains("|") AndAlso
                                                         Not IsNothing(.scenarioSpecificData) AndAlso
                                                         .scenarioSpecificData.Count > 0 Then

                                    For Each member In .scenarioSpecificData

                                        If member.scenario = scenario Then

                                            description = " | " & scenario.ToString

                                        End If

                                    Next

                                End If

                            End With

                        Else

                            description = ""

                        End If

                        top.Add("*** Start " & iop.PadRight(7) & " Base Parameters " & description & " ***")
                        std.Add("*** Start " & iop.PadRight(7) & " Std. Parameters " & description & " ***")
                        both.Add("*** Start " & iop.PadRight(7) & " " & description & " ***")

                        out = .k2.createPEARLDegT50(iop:=iop, scenario:=scenario)
                        top.AddRange(out(0))
                        std.Add("*".PadRight(10) & "degT50")
                        std.AddRange(out(1))
                        both.AddRange(out(2))

                        out.Clear()

                        out = .sorption.createPEARLSorption(iop:=iop, scenario:=scenario)
                        top.AddRange(out(0))
                        std.Add("*".PadRight(10) & "Sorption")
                        std.AddRange(out(1))
                        both.AddRange(out(2))

                    End With

                    temp.Add("*".PadRight(10) & "Non-equ. sorption; switched off")
                    temp.Add(
                            createPrlRow(
                            Value:=0.ToString,
                            iop:=iop,
                            parameterName:="CofDesRat_",
                            unit:="(d-1)",
                            description:="Desorption rate coefficient",
                            range:="[0|0.5]"))

                    temp.Add(
                            createPrlRow(
                            Value:=0.ToString,
                            iop:=iop,
                            parameterName:="FacSorNeqEql_",
                            unit:="(-)",
                            description:="CofFreNeq/CofFreEql",
                            range:="[0|-]"))

                    std.AddRange(temp)
                    both.AddRange(temp)

                    para01.Add(top.ToArray)
                    para01.Add(std.ToArray)
                    para01.Add(both.ToArray)

                    top.Clear()
                    std.Clear()
                    both.Clear()

#End Region

            End Select

        End With

        out.Clear()
        out = Me.common.physChem.createPEARLPhysChem(iop:=iop)
        top.AddRange(out(0))
        std.Add("*".PadRight(10) & "Phys-Chem")
        std.AddRange(out(1))
        both.AddRange(out(2))

        out.Clear()

        out = Me.cropProcesses.createPEARLCropProcesses(iop:=iop)
        top.AddRange(out(0))
        std.Add("*".PadRight(10) & "Crop-Processes")
        std.AddRange(out(1))
        both.AddRange(out(2))

        out.Clear()

        top.Add("*** End   " & iop.PadRight(7) & " Base Parameters " & description & " ***")
        std.Add("*** End   " & iop.PadRight(7) & " Std. Parameters " & description & " ***")
        both.Add("*** End   " & iop.PadRight(7) & " " & description & " ***")

        out.Add(top.ToArray)
        out.Add(std.ToArray)
        out.Add(both.ToArray)

        Return out

    End Function

#End Region

    Public Const catVanilla As String = "01  Vanilla"

#Region "    Vanilla"

    ''' <summary>
    ''' Input complete?
    ''' </summary>
    ''' <returns></returns>
    <Category(catVanilla)>
    <DisplayName("Input Complete?")>
    Public ReadOnly Property inputComplete As String
        Get

            If iop = String.Empty Then Return "IOP code?"
            If Double.IsNaN(molMass) Then Return "Molar mass?"
            If Double.IsNaN(preVapRef) Then Return "Vapor pressure?"
            If Double.IsNaN(slbWatRef) Then Return "Water solubility?"

            If degType = eDegType.SFO Then

                If Double.IsNaN(degT50) Then Return "SFO degT50?"

            ElseIf degType = eDegType.DFOP Then

                If Double.IsNaN(g) Then Return "DFOP g?"
                If Double.IsNaN(k1) Then Return "DFOP k1?"
                If Double.IsNaN(k2) Then Return "DFOP k2?"

            End If

            If Double.IsNaN(kom) Then Return "Kom?"
            If Double.IsNaN(expFre) Then Return "Freundlich Exponent?"

            If Double.IsNaN(facUpt) Then Return "Plant uptake factor?"
            If Double.IsNaN(Me.degT50) Then Return " degt50 ?"

            Return misc.inputComplete

        End Get
    End Property

    ''' <summary>
    ''' Deg. + Sorption Type
    ''' SFO, TDS, DFOP or pH
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName("Deg. + Sorption Type")>
    <Description("SFO, TDS, DFOP Or pH")>
    <Browsable(True)>
    <Category(catVanilla)>
    Public Property degType As eDegType
        Get
            Return degt50Sorption.DegType
        End Get
        Set(value As eDegType)

            degt50Sorption.DegType = value

            Select Case value

                Case eDegType.SFO

                    degt50Sorption.SFO = New SFO

                    degt50Sorption.DFOP = Nothing
                    degt50Sorption.TDS = Nothing
                    degt50Sorption.pH = Nothing

                        'setBrowsableCategory(category:=catVanillaSFO, browsable:=True)
                        'setBrowsableCategory(category:=catVanillaDFOP, browsable:=False)

                Case eDegType.DFOP

                    'setBrowsableCategory(category:=catVanillaSFO, browsable:=False)
                    'setBrowsableCategory(category:=catVanillaDFOP, browsable:=True)

                    degt50Sorption.DFOP = New DFOP

                    degt50Sorption.SFO = Nothing
                    degt50Sorption.TDS = Nothing
                    degt50Sorption.pH = Nothing

                Case eDegType.TDS

                    degt50Sorption.TDS = New TDS
                    degt50Sorption.TDS.KINETIC = 1

                    degt50Sorption.SFO = Nothing
                    degt50Sorption.DFOP = Nothing
                    degt50Sorption.pH = Nothing

                Case eDegType.pH

                    degt50Sorption.pH = New pH

                    degt50Sorption.DFOP = Nothing
                    degt50Sorption.TDS = Nothing
                    degt50Sorption.SFO = Nothing

            End Select

        End Set
    End Property

    ''' <summary>
    ''' Show item in own window
    ''' </summary>
    ''' <returns></returns>
    <Category(catVanilla)>
    <Editor(GetType(buttonEmulator), GetType(UITypeEditor))>
    <DisplayName(" ... show ")>
    <Description("Show item In own window")>
    <XmlIgnore> <ScriptIgnore>
    <Browsable(True)>
    <DefaultValue("")>
    Public Property show As String
        Get
            Return ""
        End Get
        Set(value As String)

            If value.Contains(buttonEmulator.Clicked) Then

                Dim frm As New frmPGrid(class2Show:=Me, classType:=Me.GetType)

                With frm

                    .Width = 900
                    .Height = 550

                End With

                frm.ShowDialog()

                Me.CopyPropertiesByName(src:=frm.class2Show)

            End If

        End Set
    End Property

    Public Const catVanillaMeta As String = "01a Meta"

#Region "    Meta"

    ''' <summary>
    ''' Include this compound in the reporting tables?
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
                "Report Compound?")>
    <Description(
            "Include this compound In reporting tables?" & vbCrLf &
            "")>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <Category(catVanillaMeta)>
    <DefaultValue(CInt(eYesNo.Yes))>
    <XmlIgnore>
    Public Property reportCompoundVanilla As eYesNo
        Get
            Return _reportCompound
        End Get
        Set
            _reportCompound = Value
        End Set
    End Property

    ''' <summary>
    ''' IOP code (used in model), max length 5 char
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catVanillaMeta)>
    <DisplayName(
            "IOP Code")>
    <Description(
            "IOP code (used In model), max length 5 chars")>
    <XmlIgnore>
    Public Property iop As String
        Get
            Return Me.common.metaData.iop
        End Get
        Set

            Me.common.metaData.iop = Value
            Me.common.metaData.nameInModel = Value
            'If Not IsNothing(frm) Then frm.Text = Me.iop

        End Set
    End Property

#End Region

    Public Const catVanillaPhyChem As String = "01b Phys-Chem"

#Region "    Phys-Chem"

    ''' <summary>
    ''' Molar mass in g/mol
    ''' [10.0 - 10000 ; MolMas]
    ''' </summary>
    <Category(catVanillaPhyChem)>
    <DisplayName(
            "Molar Mass")>
    <Description(
            "In g/mol [10.0 - 10000, MolMas]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.00'|unit=' g/mol'")>
    <DefaultValue(Double.NaN)>
    <XmlIgnore>
    Public Property molMass As Double
        Get
            Return Me.common.physChem.molMass
        End Get
        Set
            Me.common.physChem.molMass = Value
        End Set
    End Property

    ''' <summary>
    ''' Saturated vapor pressure
    ''' in Pa [0|2.0E+05 ; PreVapRef]
    ''' </summary>
    <DisplayName("Vapor Pressure")>
    <Description("Saturated Vapor pressure" & vbCrLf &
                         "in Pa [0|2.0E+05 ; PreVapRef]")>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <Category(catVanillaPhyChem)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.00E-00'|unit=' Pa'")>
    <DefaultValue(Double.NaN)>
    <XmlIgnore>
    Public Property preVapRef As Double
        Get
            Return Me.common.physChem.preVapRef
        End Get
        Set(value As Double)
            Me.common.physChem.preVapRef = value
        End Set
    End Property

    ''' <summary>
    ''' Water solubility
    ''' in mg/L [0.001|1e6]; SlbWatRef]
    ''' </summary>
    <DisplayName(
                "Solubility")>
    <Description(
            "Water solubility" & vbCrLf &
            "in mg/L [0.001|1e6 ; SlbWatRef]")>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <Category(catVanillaPhyChem)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= 'G4'|unit=' mg/L'")>
    <DefaultValue(Double.NaN)>
    <XmlIgnore>
    Public Property slbWatRef As Double
        Get
            Return Me.common.physChem.slbWatRef
        End Get
        Set(value As Double)
            Me.common.physChem.slbWatRef = value
        End Set
    End Property

#End Region

    Public Const catVanillaSFO As String = "01c SFO"

#Region "    SFO"

    ''' <summary>
    ''' Single first order degradation
    ''' Temperature and moisture corrected at 20°C
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Description(
            "Single first order degradation" & vbCrLf &
            "Temperature and moisture corrected at 20°C")>
    <DisplayName(
            "degT50")>
    <Category(catVanillaSFO)>
    <DefaultValue(Double.NaN)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("unit=' days'")>
    <XmlIgnore>
    Public Overridable Property degT50 As Double
        Get

            If Not IsNothing(Me.degt50Sorption.SFO) Then
                Return Me.degt50Sorption.SFO.degT50.degT50
            Else
                Return Double.NaN
            End If

        End Get
        Set

            If Not IsNothing(Me.degt50Sorption.SFO) Then
                Me.degt50Sorption.SFO.degT50.degT50 = Value
            End If

        End Set
    End Property

    ''' <summary>
    ''' Temperature correction on or off
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
            "  temperature and ..")>
    <Description(
            "Temperature correction" & vbCrLf &
            "On, off Or user defined")>
    <Category(catVanillaSFO)>
    <DefaultValue(CInt(eOnOffUserdef.On))>
    <XmlIgnore> <ScriptIgnore>
    Public Property tempCorr As eOnOffUserdef
        Get

            If Not IsNothing(Me.degt50Sorption.SFO) Then
                Return Me.degt50Sorption.SFO.degT50.tempCorr
            Else
                Return eOnOffUserdef.On
            End If

        End Get
        Set(value As eOnOffUserdef)

            If Not IsNothing(Me.degt50Sorption.SFO) Then
                Me.degt50Sorption.SFO.degT50.tempCorr = value
            End If

        End Set
    End Property

    ''' <summary>
    ''' Moisture correction on or off
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
            "  moisture correction")>
    <Description(
            "Moisture correction" & vbCrLf &
            "On, off or user defined")>
    <Category(catVanillaSFO)>
    <DefaultValue(CInt(eOnOffUserdef.On))>
    <XmlIgnore> <ScriptIgnore>
    Public Property moistCorr As eOnOffUserdef
        Get

            If Not IsNothing(Me.degt50Sorption.SFO) Then
                Return Me.degt50Sorption.SFO.degT50.moistCorr
            Else
                Return eOnOffUserdef.On
            End If

        End Get
        Set(value As eOnOffUserdef)


            If Not IsNothing(Me.degt50Sorption.SFO) Then
                Me.degt50Sorption.SFO.degT50.moistCorr = value
            End If

        End Set
    End Property

#End Region

    Public Const catVanillaSorption As String = "01d Sorption"

#Region "    Sorption"

    ''' <summary>
    ''' Kom
    ''' Coef. eql. sorption on org. !matter!
    ''' in L/kg, [0|1e9], KomEql\Sed\SusSol
    ''' </summary>
    <DisplayName("Kom")>
    <Description("Coef. eql. sorption on org. !matter!" & vbCrLf &
                         "in L/kg, [0|1e9], KomEql\Sed\SusSol, Koc is calc.")>
    <DefaultValue(Double.NaN)>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catVanillaSorption)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format='G8'| unit=' L/kg'")>
    <Browsable(True)>
    <XmlIgnore> <ScriptIgnore>
    Public Property kom As Double
        Get

            If Not IsNothing(Me.degt50Sorption.SFO) Then
                Return Me.degt50Sorption.SFO.sorption.kom
            ElseIf Not IsNothing(Me.degt50Sorption.DFOP) Then
                Return Me.degt50Sorption.DFOP.sorption.kom
            Else
                Return Double.NaN
            End If

        End Get
        Set

            If Not IsNothing(Me.degt50Sorption.SFO) Then
                Me.degt50Sorption.SFO.sorption.kom = Value
                Me.degt50Sorption.SFO.sorption.koc =
                        Math.Round(Value * sorption.factor, digits:=sorption.digits)
            ElseIf Not IsNothing(Me.degt50Sorption.DFOP) Then
                Me.degt50Sorption.DFOP.sorption.kom = Value
                Me.degt50Sorption.DFOP.sorption.koc =
                       Math.Round(Value * sorption.factor, digits:=sorption.digits)
            End If

        End Set
    End Property

    ''' <summary>
    ''' Koc
    ''' Coef. eql. sorption on org. !content!
    ''' in L/kg, [0|1e9], KOC\ZKD (MACRO)
    ''' </summary>
    ''' <returns></returns>
    <DisplayName("Koc")>
    <Description("Coef. eql. sorption on org. !content!" & vbCrLf &
                         "in L/kg, [0|1e9], KOC\ZKD (MACRO)")>
    <DefaultValue(Double.NaN)>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catVanillaSorption)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format='G8'| unit=' L/kg'")>
    <Browsable(True)>
    <XmlIgnore> <ScriptIgnore>
    Public Property koc As Double
        Get

            If Not IsNothing(Me.degt50Sorption.SFO) Then
                Return Me.degt50Sorption.SFO.sorption.koc
            ElseIf Not IsNothing(Me.degt50Sorption.DFOP) Then
                Return Me.degt50Sorption.DFOP.sorption.koc
            Else
                Return Double.NaN
            End If

        End Get
        Set

            If Not IsNothing(Me.degt50Sorption.SFO) Then
                Me.degt50Sorption.SFO.sorption.koc = Value
            ElseIf Not IsNothing(Me.degt50Sorption.DFOP) Then
                Me.degt50Sorption.DFOP.sorption.koc = Value
            End If

        End Set
    End Property

    ''' <summary>
    ''' Freundlich Exp. 1/n
    ''' no unit 0.1 - 1.3
    ''' ExpFre
    ''' </summary>
    <DisplayName("1/n")>
    <Description("Freundlich Exp. no unit 0.1 - 1.3 ; ExpFre\Sed\SusSol ")>
    <TypeConverter(GetType(dblConv))>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catVanillaSorption)>
    <Browsable(True)>
    <AttributeProvider("format = '0.0000' | unit=' (-)'")>
    <DefaultValue(Double.NaN)>
    <XmlIgnore>
    Public Property expFre As Double
        Get

            If Not IsNothing(Me.degt50Sorption.SFO) Then
                Return Me.degt50Sorption.SFO.sorption.expFre
            ElseIf Not IsNothing(Me.degt50Sorption.DFOP) Then
                Return Me.degt50Sorption.DFOP.sorption.expFre
            Else
                Return Double.NaN
            End If

        End Get
        Set(value As Double)

            If Not IsNothing(Me.degt50Sorption.SFO) Then
                Me.degt50Sorption.SFO.sorption.expFre = value
            ElseIf Not IsNothing(Me.degt50Sorption.DFOP) Then
                Me.degt50Sorption.DFOP.sorption.expFre = value
            End If

        End Set
    End Property

#End Region

    Public Const catVanillaCrop As String = "01e Crop Processes"

#Region "    Crop Processes"

    ''' <summary>
    ''' Plant uptake factor
    ''' in Pa [0|10 ; FacUpt]
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
                "Plant Uptake Factor")>
    <Description(
            "Plant uptake factor" & vbCrLf &
            "(-) [0|10 ; FacUpt]")>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= 'G4'|unit=' (-)'")>
    <DefaultValue(Double.NaN)>
    <Category(catVanillaCrop)>
    <XmlIgnore>
    Public Property facUpt As Double
        Get
            Return Me.cropProcesses.facUpt
        End Get
        Set
            Me.cropProcesses.facUpt = Value
        End Set
    End Property

#End Region

    Public Const catVanillaDFOP As String = "01f DFOP"

#Region "    DFOP"

    ''' <summary>
    ''' DFOP g [0|1]
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Description()>
    <DisplayName()>
    <Category(catVanillaDFOP)>
    <DefaultValue(1)>
    <TypeConverter(GetType(dblConv))>
    <Browsable(True)>
    Public Property g As Double
        Get

            If Not IsNothing(Me.degt50Sorption.DFOP) Then
                Return Me.degt50Sorption.DFOP.k1.g
            Else
                Return Double.NaN
            End If

        End Get
        Set
            If Not IsNothing(Me.degt50Sorption.DFOP) Then
                Me.degt50Sorption.DFOP.k1.g = Value
            End If
        End Set
    End Property

    ''' <summary>
    ''' k1
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Description()>
    <DisplayName()>
    <Category(catVanillaDFOP)>
    <DefaultValue(Double.NaN)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format='G8' | unit=' per day'")>
    <Browsable(True)>
    Public Property k1 As Double
        Get

            If Not IsNothing(Me.degt50Sorption.DFOP) Then
                Return Me.degt50Sorption.DFOP.k1.k
            Else
                Return Nothing
            End If

        End Get
        Set
            If Not IsNothing(Me.degt50Sorption.DFOP) AndAlso
                   Not Double.IsNaN(Value) Then
                Me.degt50Sorption.DFOP.k1.k = Value
                Me.degt50Sorption.DFOP.k1.degT50 = Math.Log(2) / Value
            End If
        End Set
    End Property

    ''' <summary>
    ''' k2
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Description()>
    <DisplayName()>
    <Category(catVanillaDFOP)>
    <DefaultValue(Double.NaN)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format='G8' | unit=' per day'")>
    <Browsable(True)>
    Public Property k2 As Double
        Get

            If Not IsNothing(Me.degt50Sorption.DFOP) Then
                Return Me.degt50Sorption.DFOP.k2.k
            Else
                Return Nothing
            End If

        End Get
        Set
            If Not IsNothing(Me.degt50Sorption.DFOP) AndAlso
                   Not Double.IsNaN(Value) Then
                Me.degt50Sorption.DFOP.k2.k = Value
                Me.degt50Sorption.DFOP.k2.degT50 = Math.Log(2) / Value
            End If
        End Set
    End Property

#End Region

#End Region

    Public Const catDetails As String = "04  Detailed settings"

#Region "    Detailed settings"

#Region "    _"

    Private _common As New common
    Private _degt50Sorption As New degt50Sorption
    Private _cropProcesses As New cropProcesses

    Private _reportCompound As eYesNo = eYesNo.Yes

#End Region

    ''' <summary>
    ''' Name shown in array
    ''' </summary>
    ''' <returns></returns>
    <Browsable(False)>
    <RefreshProperties(RefreshProperties.All)>
    Public Overridable ReadOnly Property name As String
        Get
            Return Me.iop
        End Get
    End Property

    ''' <summary>
    ''' Include this compound in the reporting tables?
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
                "Report Compound?")>
    <Description(
            "Include this compound in the reporting tables?" & vbCrLf &
            "")>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <Category(catDetails)>
    <DefaultValue(CInt(eYesNo.Yes))>
    Public Property reportCompound As eYesNo
        Get
            Return _reportCompound
        End Get
        Set
            _reportCompound = Value
        End Set
    End Property

    ''' <summary>
    ''' Meta data like IOP, names and Mol/SubIDs
    ''' and base Phys-Chem data
    ''' </summary>
    <DisplayName(
                "Common")>
    <Description(
            "Meta data like IOP, names and Mol/SubIDs" & vbCrLf &
            "and base Phys-Chem data: mol mass, VP, solubility")>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <Category(catDetails)>
    <Editor(GetType(buttonForm), GetType(UITypeEditor))>
    Public Property common As common
        Get
            Return _common
        End Get
        Set
            _common = Value
        End Set
    End Property

    ''' <summary>
    ''' Different degradation options
    ''' incl. equil. and non equil. sorption
    ''' </summary>
    <DisplayName(
                "degT50 + Sorption")>
    <Description(
            "Different degradation options" & vbCrLf &
            "incl. equil. and non equil. sorption")>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catDetails)>
    <Browsable(True)>
    <Editor(GetType(buttonForm), GetType(UITypeEditor))>
    Public Property degt50Sorption As degt50Sorption
        Get
            Return _degt50Sorption
        End Get
        Set
            _degt50Sorption = Value
        End Set
    End Property

    ''' <summary>
    ''' Crop Processes
    ''' degT50 on crop surface
    ''' wash-off and plant uptake
    ''' </summary>
    <DisplayName(
                "Crop Processes")>
    <Description(
            "degT50 on crop surface" & vbCrLf &
            "wash-off and plant uptake")>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <Category(catDetails)>
    <Editor(GetType(buttonForm), GetType(UITypeEditor))>
    Public Property cropProcesses As cropProcesses
        Get
            Return _cropProcesses
        End Get
        Set
            _cropProcesses = Value
        End Set
    End Property

#End Region

End Class

