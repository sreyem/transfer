﻿
Imports System.ComponentModel
Imports System.Drawing.Design
Imports System.Text
Imports essentials

Imports DBs.FOCUSGWdb
Imports System.Xml.Serialization
Imports System.Web.Script.Serialization

Imports SubstanceManager.degt50Sorption

#Region "    degt50"

<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class degt50Sorption

    Public Sub New()

    End Sub

    <Browsable(False)>
    Public ReadOnly Property name As String
        Get

            Select Case _degType

                Case eDegType.SFO

                    If Double.IsNaN(SFO.degT50.degT50) Then
                        Return propGridConverter.noName
                    End If

                    Return SFO.degT50.name

            End Select

        End Get
    End Property

    Public Enum eTopValueBoth
        top
        value
        both
    End Enum


    Public Function createPEARLDegt50Sorption(
                            Optional iop As String = "",
                            Optional scenario As eScenariosGW = eScenariosGW.not_def) As List(Of String())

        Dim out As New List(Of String())

        Dim deg As New List(Of String())
        Dim sorp As New List(Of String())

        Dim top As New List(Of String)
        Dim std As New List(Of String)
        Dim both As New List(Of String)
        Dim row As New List(Of String)

        Select Case _degType

            Case eDegType.SFO

                With Me.SFO

                    deg.AddRange(.degT50.createPEARLDegT50(iop:=iop, scenario:=scenario))
                    sorp.AddRange(.sorption.createPEARLSorption(iop:=iop, scenario:=scenario))

                    top.AddRange(deg(0))
                    top.AddRange(sorp(0))

                    row.Add("* Non-equilibrium sorption switched off")
                    row.Add(
                        createPrlRow(
                        Value:=0.ToString,
                        iop:=iop,
                        parameterName:="CofDesRat_",
                        unit:="(d-1)",
                        description:="Desorption rate coefficient",
                        range:="[0|0.5]"))

                    row.Add(
                        createPrlRow(
                        Value:=0.ToString,
                        iop:=iop,
                        parameterName:="FacSorNeqEql_",
                        unit:="(-)",
                        description:="CofFreNeq/CofFreEql",
                        range:="[0|-]"))

                    std.AddRange(deg(1))
                    std.AddRange(sorp(1))
                    std.AddRange(row)

                    both.AddRange(deg(2))
                    both.AddRange(sorp(2))

                    both.AddRange(row)

                End With

        End Select

        out.Add(top.ToArray)
        out.Add(std.ToArray)
        out.Add(both.ToArray)

        Return out

    End Function

    Public Enum eTraSor
        Tra
        Sor
    End Enum

    Public Function getFacZ(traSor As eTraSor, scenario As eScenariosGW, version As ePEARLVersion) As List(Of Double())

        Dim out As New List(Of Double())

        Select Case Me.DegType

            Case eDegType.SFO

                With Me.SFO

                    If traSor = eTraSor.Tra Then

                        If .degT50.depthDependentFOCUSuserdef = eDepthDependentFOCUSuserdef.userDef Then

                            out.Add(
                                .degT50.depthDependentDegradation.getFacZTra(
                                    scenario:=scenario,
                                    version:=version))
                        Else

                            out.Add(
                                DBs.FOCUSGWdb.getFacZTra(
                                    scenario:=scenario,
                                    version:=version))

                        End If

                    Else

                        If .sorption.depthDependentFOCUSuserdef = eDepthDependentFOCUSuserdef.userDef Then

                            out.Add(
                            .sorption.depthDependentSorption.getFacZSor(
                                scenario:=scenario,
                                version:=version))

                        Else

                            out.Add(
                                DBs.FOCUSGWdb.getFacZSor(
                                    scenario:=scenario,
                                    version:=version))

                        End If

                    End If
                End With

            Case eDegType.DFOP

                With DFOP

                    If traSor = eTraSor.Tra Then
                        out.Add(
                            .k1.depthDependentDegradation.getFacZTra(
                                scenario:=scenario,
                                version:=version))
                        out.Add(
                            .k2.depthDependentDegradation.getFacZTra(
                                scenario:=scenario,
                                version:=version))
                    Else
                        out.Add(
                            .sorption.depthDependentSorption.getFacZSor(
                                scenario:=scenario,
                                version:=version))
                    End If

                End With

            Case eDegType.pH

                With pH

                    If traSor = eTraSor.Tra Then
                        out.Add(
                            .acid.degT50.depthDependentDegradation.getFacZTra(
                                scenario:=scenario,
                                version:=version))

                        out.Add(
                            .alkaline.degT50.depthDependentDegradation.getFacZTra(
                                scenario:=scenario,
                                version:=version))
                    Else
                        out.Add(
                            .acid.sorption.depthDependentSorption.getFacZSor(
                                scenario:=scenario,
                                version:=version))

                        out.Add(
                            .alkaline.sorption.depthDependentSorption.getFacZSor(
                                scenario:=scenario,
                                version:=version))
                    End If

                End With

            Case eDegType.TDS
                'If TDS.SFO.depthDepDegFOCUSuserdef = eDepthDepFOCUSuserdef.userDef Then
                '    Return True
                'End If

        End Select

        Return out

    End Function


    Private _degType As eDegType = eDegType.SFO

    <RefreshProperties(RefreshProperties.All)>
    <DisplayName("Deg. & Sorption Type")>
    <Description("SFO, TDS, DFOP Or pH")>
    <Category()>
    Public Property DegType As eDegType
        Get
            Return _degType
        End Get
        Set(value As eDegType)

            _degType = value

            Select Case _degType

                Case eDegType.SFO

                    Me.SFO = New SFO

                    Me.DFOP = Nothing
                    Me.TDS = Nothing
                    Me.pH = Nothing

                Case eDegType.DFOP

                    Me.DFOP = New DFOP

                    Me.SFO = Nothing
                    Me.TDS = Nothing
                    Me.pH = Nothing

                Case eDegType.TDS

                    Me.TDS = New TDS
                    Me.TDS.KINETIC = 1

                    Me.SFO = Nothing
                    Me.DFOP = Nothing
                    Me.pH = Nothing

                Case eDegType.pH

                    Me.pH = New pH

                    Me.DFOP = Nothing
                    Me.TDS = Nothing
                    Me.SFO = Nothing

            End Select

        End Set
    End Property


    <RefreshProperties(RefreshProperties.All)>
    <Description("Single First Order")>
    <DisplayName("SFO")>
    <Category()>
    <DefaultValue(CType(Nothing, Object))>
    Public Property SFO As New SFO

    <RefreshProperties(RefreshProperties.All)>
    <Description("Time Dependent Sorption")>
    <DisplayName("TDS")>
    <Category()>
    <DefaultValue(CType(Nothing, Object))>
    Public Property TDS As TDS = Nothing

    <RefreshProperties(RefreshProperties.All)>
    <Description("Double SFO In Parallel")>
    <DisplayName("DFOP")>
    <Category()>
    <DefaultValue(CType(Nothing, Object))>
    Public Property DFOP As DFOP = Nothing

    <RefreshProperties(RefreshProperties.All)>
    <Description("pH dependent sorption And/Or degradation")>
    <DisplayName("pH")>
    <Category()>
    <DefaultValue(CType(Nothing, Object))>
    Public Property pH As pH = Nothing

End Class

#End Region

#Region "    SFO"

''' <summary>
''' Single first order degradation in soil
''' together with equilibrium Sorption
''' </summary>
<Serializable>
<TypeConverter(GetType(propGridConverter))>
<Description(
"Single first order degradation In soil" & vbCrLf &
"together With equilibrium Sorption")>
<DisplayName("DT50 soil, SFO")>
<RefreshProperties(RefreshProperties.All)>
Public Class SFO

    Public Sub New()

    End Sub

    <RefreshProperties(RefreshProperties.All)>
    <Description("Single first order degradation In soil")>
    <DisplayName("DT50 soil")>
    <Category()>
    <DefaultValue(CType(Nothing, Object))>
    Public Property degT50 As New degT50TempMoistCorr

    <RefreshProperties(RefreshProperties.All)>
    <Description("Sorption parameters Like KOC Or Freundlich exponent")>
    <DisplayName("Equilibrium Sorption")>
    <Category()>
    <DefaultValue(CType(Nothing, Object))>
    Public Property sorption As New sorption

End Class

''' <summary>
''' DT50 incl. temp. and moist. corr.
''' </summary>
<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class degT50TempMoistCorr

    Inherits degT50DepthDependent

    Public Sub New()

    End Sub

    <Browsable(False)>
    <XmlIgnore> <ScriptIgnore>
    Public Property collapseStd As String() =
    {catTempMoistCorr, catDetailsMoistCorr, catDetailsTempCorr, catConstantsDegT50, catDepthDependentDegratation}


#Region "    Output"

    Public Enum eItem
        degrate = 0
        degtemp
        q10
        mabs
        mrel
        mexp
        rel
        neq
        ff
    End Enum

    Public Function createPELMOdegRow(
                                     ff As Double,
                                     Optional PELMOpos As ePelmoPosition = ePelmoPosition.not_def,
                                     Optional scenario As eScenariosGW = eScenariosGW.not_def,
                                     Optional empty As Boolean = False) As String()

        Dim row As New StringBuilder
        Dim target As degT50TempMoistCorr
        Dim temp As String = ""
        Dim out As New List(Of String)



        Dim header As String() =
            {
        "<degrate    ",
        "temp  ",
        "q10   ",
        "m-abs  ",
        "m-rel  ",
        "m-exp  ",
        "rel  ",
        "neq  ",
        "formation factor"
        }


        For Each member As String In header
            row.Append(member)
        Next

        If empty Then

            out.Add(row.ToString)
            row.Clear()

            row.Append("  0.00E+00".PadRight(header(eItem.degrate).Length))

            row.Append("20".PadRight(header(eItem.degtemp).Length))
            row.Append("2.58".PadRight(header(eItem.q10).Length))
            row.Append("0".PadRight(header(eItem.mabs).Length))
            row.Append("100".PadRight(header(eItem.mrel).Length))
            row.Append("0.70".PadRight(header(eItem.mexp).Length))
            row.Append("0".PadRight(header(eItem.rel).Length))
            row.Append("1".PadRight(header(eItem.neq).Length))

            If PELMOpos <> ePelmoPosition.not_def Then
                row.Append("<Met " & PELMOpos.ToString & ">")
            End If

            out.Add(row.ToString)
            Return out.ToArray

        End If

        out.Add(row.ToString)
        row.Clear()

        If Me.scenarioSpecificDT50 = eOnOff.On AndAlso scenario <> eScenariosGW.not_def Then

            For Each member In Me.scenarioSpecificData

                If member.scenario = scenario Then

                    With member

                        row.Append(
                            (" " & (Math.Log(2) / .degT50 * ff).ToString(0.0000000)).PadRight(header(eItem.degrate).Length))

                    End With

                End If

            Next

        Else

            temp = " " & (Math.Round(Math.Log(2) / degT50 * ff, decimals:=7)).ToString("0.0000000")

            row.Append(temp.PadRight(header(eItem.degrate).Length))

        End If

        row.Append(_temRefTra.ToString("0.0").PadRight(header(eItem.degtemp).Length))
        row.Append(_q10.ToString("0.00").PadRight(header(eItem.q10).Length))
        row.Append("0".PadRight(header(eItem.mabs).Length))
        row.Append(_relMoist.ToString(0.0).PadRight(header(eItem.mrel).Length))
        row.Append(_EXPB.ToString("0.00").PadRight(header(eItem.mexp).Length))
        row.Append("0".PadRight(header(eItem.rel).Length))
        row.Append("1".PadRight(header(eItem.neq).Length))

        If PELMOpos <> ePelmoPosition.not_def Then
            row.Append("<Met " & PELMOpos.ToString & ">")
        End If

        out.Add(row.ToString)

        Return out.ToArray

    End Function


    Public Shadows Function createPEARLDegT50(
                Optional iop As String = "",
                Optional scenario As eScenariosGW = eScenariosGW.not_def) As List(Of String())

        Dim out As New List(Of String())
        Dim top As New List(Of String)
        Dim std As New List(Of String)
        Dim both As New List(Of String)
        Dim row As String = ""

        Dim description As New StringBuilder

        out.Add({}) : out.Add({}) : out.Add({})

        If Double.IsNaN(Me.degT50) Then Return out

        'temp & moist corr.
        If _tempCorr = eOnOffUserdef.On AndAlso
           _moistCorr = eOnOffUserdef.On Then

            description.Append("T|M = on")

        ElseIf _tempCorr = eOnOffUserdef.Off AndAlso
               _moistCorr = eOnOffUserdef.Off Then

            description.Append("T|M = off")

        Else

            description.Append(
                "T=" & extras.getEnumDescription(_tempCorr) &
               "|M=" & extras.getEnumDescription(_moistCorr))

        End If

        description.Append(" at " & _temRefTra & "°C")

        If Me.depthDependentFOCUSuserdef = eDepthDependentFOCUSuserdef.userDef Then

            description.Append(" FacZTra = user def!")

        ElseIf Me.scenarioSpecificDT50 = eOnOff.On AndAlso scenario <> eScenariosGW.not_def Then

            For Each member In Me.scenarioSpecificData

                If member.scenario = scenario Then

                    description.Append(", " & scenario.ToString & " " &
                          member.kPerc.ToString &
                           ", DT90 = " &
                          member.degT90.ToString("G4") & " days")

                End If

            Next

        Else

            description.Append(" ," &
                    kPerc.ToString &
                    ", DT90 = " &
                    degT90.ToString("G4") & " days")

        End If

        row = ""
        If Me.scenarioSpecificDT50 = eOnOff.On AndAlso scenario <> eScenariosGW.not_def Then

            For Each member In Me.scenarioSpecificData

                If member.scenario = scenario Then

                    row = createPrlRow(
                        Value:=member.degT50,
                        iop:=iop,
                        parameterName:="DT50Ref_",
                        unit:="(d)",
                        description:=description.ToString,
                        range:=" ")

                End If

            Next

        Else

            row = createPrlRow(
                Value:=Me.degT50,
                iop:=iop,
                parameterName:="DT50Ref_",
                unit:="(d)",
                description:=description.ToString,
                range:=" ")

        End If

        If row = "" Then
            row = createPrlRow(
                Value:=Me.degT50,
                iop:=iop,
                parameterName:="DT50Ref_",
                unit:="(d)",
                description:=description.ToString,
                range:=" ")
        End If

        top.Add(row)
        both.Add(row)

        If _tempCorr = eOnOffUserdef.On OrElse
           _tempCorr = eOnOffUserdef.Off Then

            If _temRefTra = stdTemRef Then

                row =
            createPrlRow(
                Value:=_temRefTra,
                iop:=iop,
                parameterName:="TemRefTra_",
                unit:="(C)",
                description:="DT50 measurement temp., std. = " & stdTemRef & "°C",
                range:="[5|30]")

                std.Add(row)

            Else

                row =
            createPrlRow(
                Value:=_temRefTra,
                iop:=iop,
                parameterName:="TemRefTra_",
                unit:="(C)",
                description:="Non std. measurement temp!, std. = " & stdTemRef & "°C",
                range:="[5|30]")

                top.Add(row)

            End If

            both.Add(row)

            description.Clear()

            If _tempCorr = eOnOffUserdef.On Then
                description.Append("Molar activ. energy, std. for on")
            Else
                description.Append("Molar activ. energy, std. for off")
            End If

            row = createPrlRow(
                    Value:=Me.molEntTra,
                    iop:=iop,
                    parameterName:="MolEntTra_",
                    unit:="(kJ.mol-1)",
                    description:=description.ToString,
                    range:="[0|200]")

            std.Add(row)
            both.Add(row)

        Else

            If _temRefTra = stdTemRef Then

                row =
            createPrlRow(
                Value:=_temRefTra,
                iop:=iop,
                parameterName:="TemRefTra_",
                unit:="(C)",
                description:="DT50 measurement temp., std. = " & stdTemRef & "°C",
                range:="[5|30]")

                std.Add(row)

            Else

                row =
            createPrlRow(
                Value:=_temRefTra,
                iop:=iop,
                parameterName:="TemRefTra_",
                unit:="(C)",
                description:="Non std. measurement temp!, std. = " & stdTemRef & "°C",
                range:="[5|30]")

                top.Add(row)

            End If

            both.Add(row)

            row = createPrlRow(
                    Value:=Me.molEntTra,
                    iop:=iop,
                    parameterName:="MolEntTra_",
                    unit:="(kJ.mol-1)",
                    description:="Molar activ. energy, user def. value",
                    range:="[0|200]")

            top.Add(row)
            both.Add(row)

        End If

        '**********************************

        If _moistCorr = eOnOffUserdef.On OrElse
           _moistCorr = eOnOffUserdef.Off Then

            description.Clear()

            If _moistCorr = eOnOffUserdef.On Then
                description.Append("Walker exp., std. value for on")
            Else
                description.Append("Walker exp., std. value for off")
            End If

            row = createPrlRow(
                    Value:=Me.expLiqTra,
                    iop:=iop,
                    parameterName:="ExpLiqTra_",
                    unit:="(-)",
                    description:=description.ToString,
                    range:="[0|5]")

            std.Add(row)

        Else

            description.Append("Walker exp., user def. value")
            row = createPrlRow(
                    Value:=Me.expLiqTra,
                    iop:=iop,
                    parameterName:="ExpLiqTra_",
                    unit:="(-)",
                    description:=description.ToString,
                    range:="[0|5]")

            top.Add(row)

        End If

        If Me.cntLiqTraRef = stdcntLiqTraRef Then

            row =
            createPrlRow(
                    Value:=Me.cntLiqTraRef,
                    iop:=iop,
                    parameterName:="CntLiqTraRef_",
                    unit:="(kg.kg-1)",
                    description:="std. setting",
                    range:="[0|1]")

            std.Add(row)

        Else

            row =
            createPrlRow(
                    Value:=Me.optDT50.ToString,
                    iop:=iop,
                    parameterName:="CntLiqTraRef_",
                    unit:="(kg.kg-1)",
                    description:="non std. setting !!!",
                    range:="[0|1]")

            top.Add(row)

        End If

        both.Add(row)

        If Me.optCntLiqTraRef = eOptCntLiqTraRef.OptimumConditions Then

            row =
                createPrlRow(
                        Value:=Me.optCntLiqTraRef.ToString,
                        iop:=iop,
                        parameterName:="OptCntLiqTraRef_",
                        unit:=" ",
                        description:="std. setting",
                        range:=" ")

            std.Add(row)

        Else

            row =
                createPrlRow(
                        Value:=Me.optCntLiqTraRef.ToString,
                        iop:=iop,
                        parameterName:="OptCntLiqTraRef_",
                        unit:=" ",
                        description:="non std. setting !!!",
                        range:=" ")

            top.Add(row)

        End If

        both.Add(row)

        If Me.optDT50 = eOptDT50.EqlDom_Input Then

            row =
            createPrlRow(
                    Value:=Me.optDT50.ToString,
                    iop:=iop,
                    parameterName:="OptDT50_",
                    unit:=" ",
                    description:="std. setting",
                    range:=" ")

            std.Add(row)

        Else

            row =
            createPrlRow(
                    Value:=Me.optDT50.ToString,
                    iop:=iop,
                    parameterName:="OptDT50_",
                    unit:=" ",
                    description:="non std. setting !!!",
                    range:=" ")

            top.Add(row)

        End If

        both.Add(row)

        out.Clear()
        out.Add(top.ToArray)
        out.Add(std.ToArray)
        out.Add(both.ToArray)

        Return out

    End Function

#End Region

    Public Const catTempMoistCorr As String = "03  Temp. And Moist."

#Region "    Temp/Moist corr"

    Private _tempCorr As eOnOffUserdef = eOnOffUserdef.On

    ''' <summary>
    ''' Temperature correction on or off
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
    "Corr. Temp.")>
    <Description(
    "Temperature correction" & vbCrLf &
    "On, off Or user defined")>
    <Category(catTempMoistCorr)>
    <DefaultValue(CInt(eOnOffUserdef.On))>
    Public Property tempCorr As eOnOffUserdef
        Get
            Return _tempCorr
        End Get
        Set(value As eOnOffUserdef)
            _tempCorr = value

            If _tempCorr = eOnOffUserdef.On Then

                _molEntTra = molEntTra_on   'PEARL
                _q10 = q10_on               'PELMO
                _TRESP = TRESP_on           'MACRO

            ElseIf _tempCorr = eOnOffUserdef.Off Then

                _molEntTra = molEntTra_off
                _q10 = q10_off
                _TRESP = TRESP_off

            End If

        End Set
    End Property


    Public Const stdTemRef As Double = 20

    Private _temRefTra As Double = stdTemRef

    ''' <summary>
    ''' Temperature at which half-life is measured
    ''' in °C [5|30 ; TemRef, std. = 20°C]
    ''' </summary>
    <DisplayName(
    "      at")>
    <Description(
    "Temperature at which half-life Is measured" & vbCrLf &
    "In °C [5|30 ; TemRef, std. = 20°C]")>
    <[ReadOnly](False)>
    <Editor(GetType(nudValueEditorInteger), GetType(UITypeEditor))>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.0'|unit=' °C'")>
    <Category(catTempMoistCorr)>
    <DefaultValue(stdTemRef)>
    Public Property temRefTra As Double
        Get
            Return _temRefTra
        End Get
        Set

            Try

                If Value < 5 OrElse
                   Value > 30 Then

                    MsgBox(
                        Prompt:=Value & "°C : " &
                        "Meas. temp for half-life in soil [5|30]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else
                    _temRefTra = Value
                End If
            Catch ex As Exception

                MsgBox(
                    Prompt:=Value & vbCrLf & "Error : " &
                    Join(parseExceptionMsg(ex), vbCrLf),
                    Buttons:=MsgBoxStyle.Critical,
                    Title:="Unknown Error")

            End Try

        End Set
    End Property


    Private _moistCorr As eOnOffUserdef = eOnOffUserdef.On


    ''' <summary>
    ''' Moisture correction on or off
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(
    "      Moist.")>
    <Description(
    "Moisture correction" & vbCrLf &
    "On, off or user defined")>
    <Category(catTempMoistCorr)>
    <DefaultValue(CInt(eOnOffUserdef.On))>
    Public Property moistCorr As eOnOffUserdef
        Get
            Return _moistCorr
        End Get
        Set(value As eOnOffUserdef)
            _moistCorr = value

            If _moistCorr = eOnOffUserdef.On Then

                _expLiqTra = expLiqTra_on       'PEARL & PELMO
                _relMoist = relMoist_on         'PELMO
                _EXPB = EXPB_on                 'MACRO

            ElseIf _moistCorr = eOnOffUserdef.Off Then

                _expLiqTra = expLiqTra_off
                _relMoist = relMoist_off
                _EXPB = EXPB_off

            End If

        End Set
    End Property


#End Region

    Public Const catDetailsMoistCorr As String = "04a Moist."

#Region "    Details Moist. Correction"

    Public Const expLiqTra_on As Double = 0.7
    Public Const expLiqTra_off As Double = 0


    Private _expLiqTra As Double = expLiqTra_on

    ''' <summary>
    ''' Walker exponent
    ''' (-) [0 - 5, ExpLiqTra PEARL & PELMO]
    ''' </summary>
    ''' <returns></returns>
    <Category(catDetailsMoistCorr)>
    <DisplayName(
    "Walker exponent")>
    <Description(
    "(-) [0 - 5, ExpLiqTra PEARL & FEUEXP PELMO]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.00'|unit=' (-)'")>
    <DefaultValue(Double.NaN)>
    Public Property expLiqTra As Double
        Get
            Return _expLiqTra
        End Get
        Set
            _expLiqTra = Value
        End Set
    End Property



    Public Const relMoist_on As Double = 100
    Public Const relMoist_off As Double = 0

    Private _relMoist As Double = relMoist_on

    ''' <summary>
    ''' Walker exponent
    ''' (-) [0 - 5, relMoist PEARL & PELMO]
    ''' </summary>
    ''' <returns></returns>
    <Category(catDetailsMoistCorr)>
    <DisplayName(
    "Rel. Moisture")>
    <Description(
    "Relative moisture during study in %Field Capacity" & vbCrLf &
    "[0-100, 0 = off, 100 = on; 'moist-rel' PELMO")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0'|unit=' %FC'")>
    <DefaultValue(relMoist_on)>
    Public Property relMoist As Double
        Get
            Return _relMoist
        End Get
        Set
            _relMoist = Value
        End Set
    End Property



    Public Const EXPB_on As Double = 0.49
    Public Const EXPB_off As Double = 0

    Private _EXPB As Double = EXPB_on

    <Category(catDetailsMoistCorr)>
    <DisplayName(
    "MACRO Temp EXPB")>
    <Description(
    "(-) [EXPB, on = 0.49, off = 0]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.00'|unit=' (-)'")>
    <DefaultValue(Double.NaN)>
    Public Property EXPB As Double
        Get
            Return _EXPB
        End Get
        Set
            _EXPB = Value
        End Set
    End Property

#End Region

    Public Const catDetailsTempCorr As String = "04b Temp."

#Region "    Details Temp. Correction"

    Public Const molEntTra_on As Double = 65.4
    Public Const molEntTra_off As Double = 1


    Private _molEntTra As Double = molEntTra_on

    ''' <summary>
    ''' Activation Energy
    ''' (-) [0 - 200 kJ/mol, MolEntTra PEARL
    ''' </summary>
    ''' <returns></returns>
    <Category(catDetailsTempCorr)>
    <DisplayName(
    "Activation Energy")>
    <Description(
    "(-) [0 - 200 kJ/mol] " & vbCrLf &
    "std. = 65.4kJ/mol (on) or 0 (off), MolEntTra PEARL")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.0'|unit=' kJ/mol'")>
    <DefaultValue(Double.NaN)>
    Public Property molEntTra As Double
        Get
            Return _molEntTra
        End Get
        Set
            _molEntTra = Value
        End Set
    End Property


    Public Const q10_on As Double = 2.58
    Public Const q10_off As Double = 1

    Private _q10 As Double = q10_on

    ''' <summary>
    ''' Activation Energy
    ''' (-) [0 - 200 kJ/mol, q10 PEARL
    ''' </summary>
    ''' <returns></returns>
    <Category(catDetailsTempCorr)>
    <DisplayName(
    "Q10")>
    <Description(
    "factor for degradation rate increase when temperature" & vbCrLf &
    "increases by 10°C, std. 2.58 (on) or 0 (off), q10 PELMO")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.00'|unit=' (-)'")>
    <DefaultValue(Double.NaN)>
    Public Property q10 As Double
        Get
            Return _q10
        End Get
        Set
            _q10 = Value
        End Set
    End Property

    Public Const TRESP_on As Double = 0.0948
    Public Const TRESP_off As Double = 0

    Private _TRESP As Double = TRESP_on

    <Category(catDetailsTempCorr)>
    <DisplayName(
    "MACRO Moist TRESP")>
    <Description(
    "(-) [TRESP, on = 0.0948]")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.0000'|unit=' (-)'")>
    <DefaultValue(Double.NaN)>
    Public Property TRESP As Double
        Get
            Return _TRESP
        End Get
        Set
            _TRESP = Value
        End Set
    End Property


#End Region

    Public Const catConstantsDegT50 As String = "05  Constants"

#Region "    Constants"

    Public Const stdcntLiqTraRef As Double = 1

    <Category(catConstantsDegT50)>
    <DisplayName(
    "DT50 Liquid Content")>
    <Description(
    "Liq. content at which DT50 is measured" & vbCrLf &
    "in kg/kg [0|1], std. 1kg/kg")>
    Public Property cntLiqTraRef As Double = stdcntLiqTraRef


    Public Enum eOptCntLiqTraRef
        OptimumConditions
        NonOptimumConditions
    End Enum

    <Category(catConstantsDegT50)>
    <DisplayName("(Non) Optimum Conditions")>
    <Description("std. = OptimumConditions")>
    Public Property optCntLiqTraRef As eOptCntLiqTraRef = eOptCntLiqTraRef.OptimumConditions

    ''' <summary>
    ''' Option for DT50: Input or Calculate in
    ''' equilibrium domain(EqlDom) Or In liquid phase
    ''' only (LiqPhs)
    ''' </summary>
    Public Enum eOptDT50

        EqlDom_Input
        LiqPhs_Input

        EqlDom_Calculate
        LiqPhs_Calculate

    End Enum

    <Category(catConstantsDegT50)>
    <DisplayName("Inp/Calc Equ. Domain or Liquid phase")>
    <Description("std. = OptimumConditions")>
    Public Property optDT50 As eOptDT50 = eOptDT50.EqlDom_Input

#End Region

End Class

''' <summary>
''' DT50 incl. depth dependent degradation
''' </summary>
<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class degT50DepthDependent

    Inherits degT50

    Public Sub New()

    End Sub

    <Browsable(False)>
    Public Overrides ReadOnly Property name As String
        Get

            If Not Double.IsNaN(degT50) Then

                Return MyBase.name &
                    IIf(
                    Expression:=depthDependentFOCUSuserdef = eDepthDependentFOCUSuserdef.FOCUS,
                    TruePart:="",
                    FalsePart:=" ".PadLeft(40) & vbCrLf & "user def. depth dep. degT50!!")

            Else
                Return propGridConverter.noName
            End If

        End Get
    End Property

    Public Const catDepthDependentDegratation As String = "02  Depth dep. degradation"

#Region "    Depth dependent degradation"

    Private _depthDependentFOCUSuserdef As eDepthDependentFOCUSuserdef = eDepthDependentFOCUSuserdef.FOCUS

    ''' <summary>
    ''' Depth dependent degt50?
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catDepthDependentDegratation)>
    <DisplayName("Depth dep. degt50")>
    <DefaultValue(CInt(eDepthDependentFOCUSuserdef.FOCUS))>
    Public Property depthDependentFOCUSuserdef As eDepthDependentFOCUSuserdef
        Get
            Return _depthDependentFOCUSuserdef
        End Get
        Set

            _depthDependentFOCUSuserdef = Value

            If _depthDependentFOCUSuserdef = eDepthDependentFOCUSuserdef.FOCUS Then
                depthDependentDegradation = Nothing
            Else
                depthDependentDegradation = New depthDependentDegradation
            End If

        End Set
    End Property

    <DisplayName("Scenario Settings")>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catDepthDependentDegratation)>
    <DefaultValue(CType(Nothing, Object))>
    Public Property depthDependentDegradation As depthDependentDegradation = Nothing

#End Region

End Class

''' <summary>
''' DT50 incl. DT90 and rate per days in %
''' </summary>
<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class degT50

#Region "    Constructor"

    Public Sub New()

    End Sub

    Public Sub New(degT50 As Double)
        Me.degT50 = degT50
    End Sub

#End Region

#Region "    Meta"

    <Browsable(False)>
    Public Overridable ReadOnly Property name As String
        Get

            If Not Double.IsNaN(degT50) Then
                Return _
                    ("DT50 : " & degT50.ToString & " days").PadRight(40) & vbCrLf &
                    ("rate : " & kPerc & " % / day").PadRight(40) & vbCrLf &
                     "DT90 : " & dblConv.conv2String(value:=degT90, unit:=" days")
            Else
                Return propGridConverter.noName
            End If

        End Get
    End Property

    Public Overridable Function createPEARLdegT50(Optional iop As String = "") As String

        Return createPrlRow(
            Value:=Me.degT50,
            iop:=iop,
            parameterName:="DT50Ref_",
            unit:="(d)",
            description:=kPerc & " % / day, degT90 = " & dblConv.conv2String(value:=degT90, unit:=" days"),
            range:="[1|1e6]")

    End Function

    <Browsable(False)>
    Public ReadOnly Property inputComplete As String
        Get

            If Double.IsNaN(Me.degT50) Then Return " degt50 ?"

            Return misc.inputComplete

        End Get
    End Property

#End Region

    Public Const catDT50 As String = "01  degT50"

#Region "    degT50"

    Private _degT50 As Double = Double.NaN

    ''' <summary>
    ''' Single first order degradation
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Description(
    "Single first order degradation" & vbCrLf &
    "click '...' to fill k")>
    <DisplayName(
    "degT50")>
    <Category(catDT50)>
    <DefaultValue(Double.NaN)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("unit=' days'")>
    <Editor(GetType(buttonDblInt), GetType(UITypeEditor))>
    Public Overridable Property degT50 As Double
        Get
            Return _degT50
        End Get
        Set

            If Value = buttonDblInt.Clicked Then
                If Not Double.IsNaN(_degT50) Then
                    _k = Math.Log(2) / _degT50
                End If
            Else
                _degT50 = Value
            End If

        End Set
    End Property

    ''' <summary>
    ''' degT90
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catDT50)>
    <DisplayName(
    "   degT90")>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("unit=' days'")>
    Public ReadOnly Property degT90 As Double
        Get

            If Not Double.IsNaN(_degT50) AndAlso _degT50 > 0 Then

                Return Math.Log(10) /
             (Math.Log(2) / _degT50)

            Else
                Return Double.NaN
            End If

        End Get
    End Property

    ''' <summary>
    ''' Rate per day in percent
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catDT50)>
    <DisplayName(
    "   rate per day")>
    Public ReadOnly Property kPerc As String
        Get

            If Not Double.IsNaN(_degT50) AndAlso _degT50 > 0 Then

                Return _
             (Math.Log(2) / _degT50 * 100).ToString("0.00") & " % per day"

            Else
                Return dblConv.stdEmptyString
            End If

        End Get
    End Property

    Private _k As Double = Double.NaN

    ''' <summary>
    ''' DFOP k
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catDT50)>
    <DisplayName(
    "   k (for DFOP)")>
    <Description(" click '...' to fill degT50")>
    <TypeConverter(GetType(dblConv))>
    <Editor(GetType(buttonDblInt), GetType(UITypeEditor))>
    <AttributeProvider("format='G8' | unit=' per day'")>
    Public Property k As Double
        Get
            Return _k
        End Get
        Set

            If Value = buttonDblInt.Clicked Then
                If Not Double.IsNaN(_k) Then
                    _degT50 = Math.Log(2) / _k
                End If
            Else
                _k = Value
            End If

        End Set
    End Property

#End Region

    Public Const catScenarioSpecific As String = "01a Scenario specific"

#Region "    Scenario specific"

    Private _scenarioSpecificDT50 As eOnOff = eOnOff.Off
    Private _scenarioSpecificData As degT50ScenarioSpecific() = Nothing

    ''' <summary>
    ''' Scenario Specific degT50 ?
    ''' </summary>
    ''' <returns></returns>
    <Category(catScenarioSpecific)>
    <DisplayName("Scenario Specific degT50 ?")>
    Public Overridable Property scenarioSpecificDT50 As eOnOff
        Get
            Return _scenarioSpecificDT50
        End Get
        Set
            _scenarioSpecificDT50 = Value
        End Set
    End Property

    ''' <summary>
    ''' degT50 Data
    ''' </summary>
    ''' <returns></returns>
    <Category(catScenarioSpecific)>
    <DefaultValue(CType(Nothing, Object))>
    <DisplayName("degT50 Data")>
    Public Overridable Property scenarioSpecificData As degT50ScenarioSpecific()
        Get
            Return _scenarioSpecificData
        End Get
        Set

            If _scenarioSpecificDT50 = eOnOff.Off Then
                _scenarioSpecificData = Nothing
            Else
                _scenarioSpecificData = Value
            End If

        End Set
    End Property

#End Region

End Class

''' <summary>
''' Scenario specific degT50
''' </summary>
<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class degT50ScenarioSpecific

    Public Sub New()

    End Sub

    <Browsable(False)>
    Public ReadOnly Property name As String
        Get
            Return extras.getEnumDescription(Me.scenario)
        End Get
    End Property

    Public Const catDT50 As String = "01  degT50"

    <Category(catDT50)>
    Public Property scenario As eScenariosGW = eScenariosGW.not_def

    Private _degT50 As Double = Double.NaN

    ''' <summary>
    ''' Single first order degradation
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Description(
    "Single first order degradation" & vbCrLf &
    "click '...' to fill k")>
    <DisplayName(
    "degT50")>
    <Category(catDT50)>
    <DefaultValue(Double.NaN)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("unit=' days'")>
    <Editor(GetType(buttonDblInt), GetType(UITypeEditor))>
    Public Overridable Property degT50 As Double
        Get
            Return _degT50
        End Get
        Set

            If Value = buttonDblInt.Clicked Then
                If Not Double.IsNaN(_degT50) Then
                    _k = Math.Log(2) / _degT50
                End If
            Else
                _degT50 = Value
            End If

        End Set
    End Property

    ''' <summary>
    ''' degT90
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catDT50)>
    <DisplayName(
    "   degT90")>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("unit=' days'")>
    Public ReadOnly Property degT90 As Double
        Get

            If Not Double.IsNaN(_degT50) AndAlso _degT50 > 0 Then

                Return Math.Log(10) /
             (Math.Log(2) / _degT50)

            Else
                Return Double.NaN
            End If

        End Get
    End Property

    ''' <summary>
    ''' Rate per day in percent
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catDT50)>
    <DisplayName(
    "   rate per day")>
    Public ReadOnly Property kPerc As String
        Get

            If Not Double.IsNaN(_degT50) AndAlso _degT50 > 0 Then

                Return _
             (Math.Log(2) / _degT50 * 100).ToString("0.00") & " % per day"

            Else
                Return dblConv.stdEmptyString
            End If

        End Get
    End Property

    Private _k As Double = Double.NaN

    ''' <summary>
    ''' DFOP k
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catDT50)>
    <DisplayName(
    "   k (for DFOP)")>
    <Description(" click '...' to fill degT50")>
    <TypeConverter(GetType(dblConv))>
    <Editor(GetType(buttonDblInt), GetType(UITypeEditor))>
    <AttributeProvider("format='G8' | unit=' per day'")>
    Public Property k As Double
        Get
            Return _k
        End Get
        Set

            If Value = buttonDblInt.Clicked Then
                If Not Double.IsNaN(_k) Then
                    _degT50 = Math.Log(2) / _k
                End If
            Else
                _k = Value
            End If

        End Set
    End Property


    <Browsable(False)>
    <DefaultValue(CType(Nothing, Object))>
    Public Property scenarioSpecificDT50 As eOnOff = Nothing

    <Browsable(False)>
    <DefaultValue(CType(Nothing, Object))>
    Public Property scenarioSpecificData As degT50ScenarioSpecific() = Nothing

End Class


''' <summary>
''' depth dependent degradation
''' </summary>
<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class depthDependentDegradation

    Public Sub New()
        resetFacZTra()
    End Sub

    Public Const catDepthDependentDegradation As String = "02  Depth dep. Degradation "

    <Editor(GetType(buttonEmulator), GetType(UITypeEditor))>
    Public Property reset As String
        Get
            Return ""
        End Get
        Set(value As String)

            If value.Contains(buttonEmulator.Clicked) Then
                resetFacZTra()
            End If

        End Set
    End Property

    Public Sub resetFacZTra()

        Dim facZTraList As New List(Of facZ)

        For scenario As eScenariosGW = eScenariosGW.Chateaudun To eScenariosGW.Thiva

            facZTraList.Add(New facZ)

            With facZTraList(facZTraList.Count - 1)

                .scenario = scenario

                .PEARL444 = DBs.FOCUSGWdb.getFacZTra(
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL444)

                .PEARL555 = DBs.FOCUSGWdb.getFacZTra(
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL555)

            End With

        Next

        facZTra = facZTraList.ToArray

    End Sub

    Public Function getFacZTra(scenario As eScenariosGW) As facZ

        For Each member As facZ In facZTra
            If member.scenario = scenario Then
                Return member
            End If
        Next

        Return Nothing

    End Function

    Public Function getFacZTra(scenario As eScenariosGW, version As ePEARLVersion) As Double()

        Dim facZ As New facZ

        facZ = getFacZTra(scenario:=scenario)

        If Not IsNothing(facZ) Then

            If version = ePEARLVersion.PEARL444 Then
                Return facZ.PEARL444
            Else
                Return facZ.PEARL555
            End If

        End If

        Return Nothing

    End Function

    Public Property facZTra As facZ() = {}

End Class

#End Region

#Region "    DFOP"

''' <summary>
''' Degradation
''' </summary>
<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class DFOP

    Public Sub New()

    End Sub

    <RefreshProperties(RefreshProperties.All)>
    <Description()>
    <DisplayName()>
    <Category()>
    Public Property k1 As New baseDFOP

    <RefreshProperties(RefreshProperties.All)>
    <Description()>
    <DisplayName()>
    <Category()>
    Public Property k2 As New degT50TempMoistCorr

    <RefreshProperties(RefreshProperties.All)>
    <Description()>
    <DisplayName()>
    <Category()>
    <DefaultValue(CType(Nothing, Object))>
    Public Property sorption As New sorption

End Class

Public Class baseDFOP

    Inherits degT50TempMoistCorr

    Private _g As Double = Double.NaN
    Private _applnFactor As Double = 2

    Public Sub New()

    End Sub

#Region "    DFOP"

    ''' <summary>
    ''' DFOP g [0|1]
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Description()>
    <DisplayName()>
    <Category()>
    <DefaultValue(Double.NaN)>
    <TypeConverter(GetType(dblConv))>
    Public Property g As Double
        Get
            Return _g
        End Get
        Set
            Try

                If Value < 0 OrElse
                   Value > 1 Then

                    MsgBox(
                        Prompt:=Value.ToString("0.0000") &
                        " (-) : " & "DFOP g exceeds limits [0|1]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else
                    _g = Value
                End If

            Catch ex As Exception

                mylog(
                    LogTxt:=Value & vbCrLf & "Error : " & Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")

            End Try
        End Set
    End Property

    ''' <summary>
    ''' Appln. Factor for DFOP, std. 2
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Description()>
    <DisplayName()>
    <Category()>
    <DefaultValue(2)>
    <TypeConverter(GetType(dblConv))>
    Public Property applnFactor As Double
        Get
            Return _applnFactor
        End Get
        Set
            _applnFactor = Value
        End Set
    End Property

#End Region

End Class

#End Region

#Region "    TDS"

<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class TDS

    Public Sub New()

    End Sub

    <RefreshProperties(RefreshProperties.All)>
    <Description()>
    <DisplayName("SFO degT50 soil")>
    <Category()>
    <DefaultValue(CType(Nothing, Object))>
    Public Property SFO As New degT50TempMoistCorr


    <RefreshProperties(RefreshProperties.All)>
    <Description()>
    <DisplayName("Kom/Koc and 1/n")>
    <Category()>
    <DefaultValue(CType(Nothing, Object))>
    Public Property Sorption As New sorption

    Public Const CATTDSSpecial As String = "TDS Special"

    Public Const stdcofDesRat As Double = 0

    Private _cofDesRat As Double = stdcofDesRat




    ''' <summary>
    ''' Single first order degradation
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Description(
    "Desorption rate coefficient" & vbCrLf &
    "[0|0.5 per day; CofDesRat off = 0 ]")>
    <DisplayName(
    "Desorption rate coef.")>
    <Category(CATTDSSpecial)>
    <DefaultValue(stdcofDesRat)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("unit=' (-)'")>
    <Editor(GetType(buttonDblInt), GetType(UITypeEditor))>
    Public Overridable Property cofDesRat As Double
        Get
            Return _cofDesRat
        End Get
        Set
            _cofDesRat = Value
        End Set
    End Property

    Public Const stdFacSorNeqEql As Double = 0

    Private _facSorNeqEql As Double = stdFacSorNeqEql

    ''' <summary>
    ''' Single first order degradation
    ''' </summary>
    ''' <returns></returns>
    <RefreshProperties(RefreshProperties.All)>
    <Description(
    "CofFreNeq/CofFreEql, off = 0")>
    <DisplayName(
    "Ratio Neq/Eql")>
    <Category(CATTDSSpecial)>
    <DefaultValue(stdFacSorNeqEql)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("unit=' (-)'")>
    <Editor(GetType(buttonDblInt), GetType(UITypeEditor))>
    Public Overridable Property facSorNeqEql As Double
        Get
            Return _facSorNeqEql
        End Get
        Set
            _facSorNeqEql = Value
        End Set
    End Property


    <RefreshProperties(RefreshProperties.All)>
    <Description()>
    <DisplayName()>
    <DefaultValue(0)>
    <[ReadOnly](True)>
    <Category(CATTDSSpecial)>
    Public Property KINETIC As Integer = 0

    <RefreshProperties(RefreshProperties.All)>
    <Description(
            "0 (std) = DEGxxx = ln(2)/DT50eq" & vbCrLf &
            "no degradation in the non-equilibrium, 1 = same for eq/non eq ")>
    <DisplayName()>
    <DefaultValue(0)>
    <Category(CATTDSSpecial)>
    Public Property DEGKIN As Integer = 0


    Private m_fNE As Double = Double.NaN

    <RefreshProperties(RefreshProperties.All)>
    <Description()>
    <DisplayName()>
    <DefaultValue(Double.NaN)>
    <Category(CATTDSSpecial)>
    <TypeConverter(GetType(dblConv))>
    Public Property fNE As Double
        Get
            Return m_fNE
        End Get
        Set(value As Double)
            m_fNE = value
            kdes = m_kdes
        End Set
    End Property


    Private m_kdes As Double = Double.NaN

    <RefreshProperties(RefreshProperties.All)>
    <Description()>
    <DisplayName()>
    <DefaultValue(Double.NaN)>
    <Category(CATTDSSpecial)>
    <TypeConverter(GetType(dblConv))>
    Public Property kdes As Double
        Get
            Return m_kdes
        End Get
        Set(value As Double)

            m_kdes = value

            If Not IsNothing(kdes) AndAlso Not IsNothing(fNE) AndAlso
                       kdes <> 0 AndAlso fNE <> 0 Then

                KfFinal = fNE + 1
                SORPRATE = Math.Round(kdes * fNE / KfFinal, digits:=7)
                FRACEQ = Math.Round(1 - (1 / KfFinal), digits:=5)

            End If

        End Set
    End Property


    <RefreshProperties(RefreshProperties.All)>
    <Description("SORPRATE = alpha = kdes * fNE / (fNE + 1)")>
    <DisplayName()>
    <DefaultValue(Double.NaN)>
    <Category(CATTDSSpecial)>
    <TypeConverter(GetType(dblConv))>
    Public Property SORPRATE As Double = Double.NaN

    <RefreshProperties(RefreshProperties.All)>
    <Description(
            "f = 1/(fNE + 1)" & vbCrLf &
            "FRACEQ = 1 - f")>
    <DisplayName()>
    <DefaultValue(Double.NaN)>
    <Category(CATTDSSpecial)>
    <TypeConverter(GetType(dblConv))>
    Public Property FRACEQ As Double = Double.NaN

    <RefreshProperties(RefreshProperties.All)>
    <Description("fNE + 1")>
    <DisplayName()>
    <DefaultValue(Double.NaN)>
    <Category(CATTDSSpecial)>
    <TypeConverter(GetType(dblConv))>
    Public Property KfFinal As Double = Double.NaN


End Class

#End Region

#Region "    pH"

<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class pH

    Public Sub New()

    End Sub

    <RefreshProperties(RefreshProperties.All)>
    <Description()>
    <DisplayName("Acid")>
    <Category()>
    <DefaultValue(CType(Nothing, Object))>
    Public Property acid As New SFO

    <RefreshProperties(RefreshProperties.All)>
    <Description()>
    <DisplayName("Alkaline")>
    <Category()>
    <DefaultValue(CType(Nothing, Object))>
    Public Property alkaline As New SFO

End Class

#End Region

#Region "    Sorption"

''' <summary>
''' Kom/Koc and 1/n
''' </summary>
<TypeConverter(GetType(propGridConverter))>
<Serializable>
Public Class sorption

    Inherits sorptionDepthDependent

    Public Sub New()

    End Sub

    Public Const factor As Double = 1.724
    Public Const digits As Integer = 2

    Public Const catSorptionBasic As String = "01  Sorption Basics"

    <Browsable(False)>
    Public ReadOnly Property name As String
        Get

            If Not Double.IsNaN(_kom) AndAlso
               Not Double.IsNaN(_koc) AndAlso
               Not Double.IsNaN(_expFre) Then

                Return ("Kom  : " & dblConv.conv2String(value:=_kom, unit:=" L/kg")).PadRight(40) & vbCrLf &
                       ("Koc  : " & dblConv.conv2String(value:=_koc, unit:=" L/kg")).PadRight(40) & vbCrLf &
                        "1/n  : " & _expFre.ToString & " (-)"

            Else

                Return propGridConverter.noName

            End If

        End Get
    End Property

#Region "    Output"

    Public Function createPEARLSorption(
                        Optional iop As String = "",
                        Optional scenario As eScenariosGW = eScenariosGW.not_def) As List(Of String())

        Dim out As New List(Of String())
        Dim top As New List(Of String)
        Dim std As New List(Of String)
        Dim both As New List(Of String)
        Dim row As String

        Dim description As New StringBuilder

        If Me.depthDependentFOCUSuserdef = eDepthDependentFOCUSuserdef.userDef Then

            description.Append("FacZSor = user def!, Koc = " & _koc & " L/kg")

        ElseIf Me.scenarioSpecificSorption = eOnOff.On AndAlso scenario <> eScenariosGW.not_def Then

            For Each member In Me.scenarioSpecificData

                If member.scenario = scenario Then

                    description.Append(
                        "Koc = " &
                        member.koc &
                        " L/kg" & ", " &
                        scenario.ToString)

                End If

            Next

        Else
            description.Append("Koc = " & _koc & "L/kg")
        End If

        If description.ToString = "" Then description.Append("Koc = " & _koc & "L/kg")

        row = ""
        If Me.scenarioSpecificSorption = eOnOff.On AndAlso scenario <> eScenariosGW.not_def Then

            For Each member In Me.scenarioSpecificData

                If member.scenario = scenario Then

                    row = createPrlRow(
                            Value:=member.kom,
                            iop:=iop,
                            parameterName:="KomEql_",
                            unit:="(L.kg-1)",
                            description:=description.ToString,
                            range:="[0|1e9]")

                End If

            Next

        End If

        If row = "" Then

            row = createPrlRow(
                        Value:=_kom,
                        iop:=iop,
                        parameterName:="KomEql_",
                        unit:="(L.kg-1)",
                        description:=description.ToString,
                        range:="[0|1e9]")
        End If


        top.Add(row)
        both.Add(row)


        row = ""
        If Me.scenarioSpecificSorption = eOnOff.On AndAlso scenario <> eScenariosGW.not_def Then

            For Each member In Me.scenarioSpecificData

                If member.scenario = scenario Then

                    row = createPrlRow(
                            Value:=member.expFre,
                            iop:=iop,
                            parameterName:="ExpFre_",
                            unit:="(-)",
                            description:="Freundlich sorption exponent, " & member.scenario.ToString,
                            range:="[0.1|1.3]")

                End If

            Next

        End If
        If row = "" Then

            row = createPrlRow(
                   Value:=expFre,
                   iop:=iop,
                   parameterName:="ExpFre_",
                   unit:="(-)",
                   description:="Freundlich sorption exponent",
                   range:="[0.1|1.3]")

        End If


        top.Add(row)
        both.Add(row)


        row = ""
        If Me.scenarioSpecificSorption = eOnOff.On AndAlso scenario <> eScenariosGW.not_def Then

            For Each member In Me.scenarioSpecificData

                If member.scenario = scenario Then

                    row = createPrlRow(
                            Value:=member.komEqlMax,
                            iop:=iop,
                            parameterName:="KomEqlMax_",
                            unit:="(L.kg-1)",
                            description:="sorp. on org. matter in dry soil, " & member.scenario.ToString,
                            range:="[0|1e9]")

                End If

            Next

        End If

        If row = "" Then

            row = createPrlRow(
            Value:=komEqlMax,
            iop:=iop,
            parameterName:="KomEqlMax_",
            unit:="(L.kg-1)",
            description:="sorption on org. matter in dry soil, 100 * Kom",
            range:="[0|1e9]")

        End If

        std.Add(row)
        both.Add(row)

        row = createPrlRow(
            Value:=Me.molEntSor,
            iop:=iop,
            parameterName:="MolEntSor_",
            unit:="(kJ.mol-1)",
            description:="",
            range:="[0|200]")

        std.Add(row)
        both.Add(row)

        row = createPrlRow(
            Value:=_temRefSor,
            iop:=iop,
            parameterName:="TemRefSor_",
            unit:="(C)",
            description:="",
            range:="[5|30]")

        std.Add(row)
        both.Add(row)

        row = createPrlRow(
            Value:=Me.conLiqRef,
            iop:=iop,
            parameterName:="ConLiqRef_",
            unit:="(mg.L-1)",
            description:="Reference conc. In liquid phase",
            range:="[0.1|-]")

        std.Add(row)
        both.Add(row)

        row = createPrlRow(
            Value:=extras.getEnumDescription(Me.optCofFre),
            iop:=iop,
            parameterName:="OptCofFre_",
            unit:="",
            description:="std. setting",
            range:="")

        std.Add(row)
        both.Add(row)

        out.Clear()
        out.Add(top.ToArray)
        out.Add(std.ToArray)
        out.Add(both.ToArray)

        Return out

    End Function

#End Region

    Public Const catBaseParameters As String = "01  Base Parameters"

#Region "    Base Parameters"

    Private _kom As Double = Double.NaN

    ''' <summary>
    ''' Kom
    ''' Coef. eql. sorption on org. !matter!
    ''' in L/kg, [0|1e9], KomEql\Sed\SusSol
    ''' </summary>
    <DisplayName("Kom")>
    <Description("Coef. eql. sorption on org. !matter!" & vbCrLf &
                 "in L/kg, [0|1e9], KomEql\Sed\SusSol, click '..' to calc Koc")>
    <DefaultValue(Double.NaN)>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catSorptionBasic)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format='G8'| unit=' L/kg'")>
    <Browsable(True)>
    <Editor(GetType(buttonDblInt), GetType(UITypeEditor))>
    Public Property kom As Double
        Get
            Return _kom
        End Get
        Set

            Try

                If Value = buttonDblInt.Clicked Then

                    If Not Double.IsNaN(_kom) Then

                        _koc =
                            Math.Round(_kom * factor, digits:=digits)
                    End If

                ElseIf Value < 0 OrElse
                   Value > 1000000000 Then

                    MsgBox(
                        Prompt:=Value.ToString("0.00") & " : Kom [0|1e9]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else

                    _kom = Value
                    komEqlMax = _kom * 100

                End If

            Catch ex As Exception

                mylog(
                    LogTxt:=Value & vbCrLf & "Error : " &
                    Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")


            End Try

        End Set
    End Property


    Private _koc As Double = Double.NaN

    ''' <summary>
    ''' Koc
    ''' Coef. eql. sorption on org. !content!
    ''' in L/kg, [0|1e9], KOC\ZKD (MACRO)
    ''' </summary>
    ''' <returns></returns>
    <DisplayName("Koc")>
    <Description("Coef. eql. sorption on org. !content!" & vbCrLf &
                 "in L/kg, [0|1e9], KOC\ZKD (MACRO), click '..' to calc Kom")>
    <DefaultValue(Double.NaN)>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catSorptionBasic)>
    <Editor(GetType(buttonDblInt), GetType(UITypeEditor))>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format='G8'| unit=' L/kg'")>
    <Browsable(True)>
    Public Property koc As Double
        Get
            Return _koc
        End Get
        Set

            Try

                If Value = buttonDblInt.Clicked Then

                    If Not Double.IsNaN(_koc) Then

                        _kom =
                            Math.Round(_koc /
                                factor, digits:=digits)
                    End If

                ElseIf Value < 0 OrElse
                   Value > 1000000000 Then

                    MsgBox(
                        Prompt:=Value.ToString("0.00") & " : Koc [0|1e9]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else
                    _koc = Value
                End If

            Catch ex As Exception

                mylog(
                    LogTxt:=Value & vbCrLf & "Error : " &
                    Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property


    Private _expFre As Double = Double.NaN

    ''' <summary>
    ''' Summary
    ''' Freundlich Exp. 1/n
    ''' no unit 0.1 - 1.3
    ''' ExpFre
    ''' </summary>
    <DisplayName("1/n")>
    <Description("Freundlich Exp. no unit 0.1 - 1.3 ; ExpFre\Sed\SusSol ")>
    <TypeConverter(GetType(dblConv))>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catSorptionBasic)>
    <Browsable(True)>
    <DefaultValue(Double.NaN)>
    Public Property expFre As Double
        Get
            Return _expFre
        End Get
        Set(value As Double)

            Try

                If value < 0.1 OrElse
                   value > 1.3 Then

                    MsgBox(
                        Prompt:=value.ToString("0.0000") &
                        " : Freundlich Exp. 1/n [0.1|1.3]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else
                    _expFre = value
                End If

            Catch ex As Exception

                mylog(
                    LogTxt:=value & vbCrLf & "Error : " &
                    Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")

            End Try


        End Set
    End Property

#End Region


    Public Const catScenarioSpecific As String = "01a Scenario specific"

#Region "    Scenario specific"

    Private _scenarioSpecificSorption As eOnOff = eOnOff.Off
    Private _scenarioSpecificData As sorptionScenarioSpecific() = Nothing

    ''' <summary>
    ''' Scenario Specific Sorption ?
    ''' </summary>
    ''' <returns></returns>
    <Category(catScenarioSpecific)>
    <DisplayName("Scenario Specific Sorption ?")>
    Public Overridable Property scenarioSpecificSorption As eOnOff
        Get
            Return _scenarioSpecificSorption
        End Get
        Set
            _scenarioSpecificSorption = Value
        End Set
    End Property

    ''' <summary>
    ''' Sorption Scenario Data
    ''' </summary>
    ''' <returns></returns>
    <Category(catScenarioSpecific)>
    <DefaultValue(CType(Nothing, Object))>
    <DisplayName("Sorption Scenario Data")>
    Public Overridable Property scenarioSpecificData As sorptionScenarioSpecific()
        Get
            Return _scenarioSpecificData
        End Get
        Set

            If _scenarioSpecificSorption = eOnOff.Off Then
                _scenarioSpecificData = Nothing
            Else
                _scenarioSpecificData = Value
            End If

        End Set
    End Property

#End Region

    Public Const catConstants As String = "03  Constants"

#Region "    Constants"

    <Category(catConstants)>
    Public Property conLiqRef As Double = 1

    <Category(catConstants)>
    Public Property komEqlMax As Double = Double.NaN

    Public Const stdTemRef As Double = 20

    Private _temRefSor As Double = stdTemRef

    ''' <summary>
    ''' Temperature at which sorption is measured
    ''' in °C [5|30 ; TemRef, std. = 20°C]
    ''' </summary>
    <DisplayName(
    "      at")>
    <Description(
    "Temperature at which sorption Is measured" & vbCrLf &
    "In °C [5|30 ; TemRef, std. = 20°C]")>
    <[ReadOnly](False)>
    <Editor(GetType(nudValueEditorInteger), GetType(UITypeEditor))>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.0'|unit=' °C'")>
    <Category(catConstants)>
    <DefaultValue(stdTemRef)>
    Public Property temRefSor As Double
        Get
            Return _temRefSor
        End Get
        Set

            Try

                If Value < 5 OrElse
                   Value > 30 Then

                    MsgBox(
                        Prompt:=Value & "°C : " &
                        "Meas. temp for sorption [5|30]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else
                    _temRefSor = Value
                End If
            Catch ex As Exception

                MsgBox(
                    Prompt:=Value & vbCrLf & "Error : " &
                    Join(parseExceptionMsg(ex), vbCrLf),
                    Buttons:=MsgBoxStyle.Critical,
                    Title:="Unknown Error")

            End Try

        End Set
    End Property

    Private _molEntSor As Double = 0

    ''' <summary>
    ''' Activation Energy
    ''' (-) [0 - 200 kJ/mol, MolEntSor PEARL
    ''' </summary>
    ''' <returns></returns>
    <Category(catConstants)>
    <DisplayName(
    "Activation Energy")>
    <Description(
    "(-) [0 - 200 kJ/mol] " & vbCrLf &
    "std. = 0 kJ/mol , MolEntSor PEARL")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= '0.0'|unit=' kJ/mol'")>
    <DefaultValue(Double.NaN)>
    Public Property molEntSor As Double
        Get
            Return _molEntSor
        End Get
        Set
            _molEntSor = Value
        End Set
    End Property


    <TypeConverter(GetType(enumConverter(Of eOptCofFre)))>
    Public Enum eOptCofFre
        <Description("pH-dependent")>
        pHdependent
        <Description("pH-independent")>
        pHindependent
        <Description("CofFre")>
        CofFre
    End Enum

    <Category(catConstants)>
    Public Property optCofFre As eOptCofFre = eOptCofFre.pHindependent

#End Region

End Class

#End Region


Public Class sorptionScenarioSpecific

    Public Sub New()

    End Sub

    Public Const factor As Double = 1.724
    Public Const digits As Integer = 2

    Public Const catBaseParameters As String = " Base Parameters"

    <Browsable(False)>
    Public ReadOnly Property name As String
        Get
            Return extras.getEnumDescription(Me.scenario)
        End Get
    End Property


    <Category(catBaseParameters)>
    Public Property scenario As eScenariosGW = eScenariosGW.not_def

#Region "    Base Parameters"

    Private _kom As Double = Double.NaN

    ''' <summary>
    ''' Kom
    ''' Coef. eql. sorption on org. !matter!
    ''' in L/kg, [0|1e9], KomEql\Sed\SusSol
    ''' </summary>
    <DisplayName("Kom")>
    <Description("Coef. eql. sorption on org. !matter!" & vbCrLf &
                 "in L/kg, [0|1e9], KomEql\Sed\SusSol, click '..' to calc from Koc")>
    <DefaultValue(Double.NaN)>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catBaseParameters)>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format='G8'| unit=' L/kg'")>
    <Browsable(True)>
    <Editor(GetType(buttonDblInt), GetType(UITypeEditor))>
    Public Property kom As Double
        Get
            Return _kom
        End Get
        Set

            Try

                If Value = buttonDblInt.Clicked Then

                    If Not Double.IsNaN(_koc) Then

                        _kom =
                            Math.Round(_koc / factor, digits:=digits)
                    End If

                ElseIf Value < 0 OrElse
                       Value > 1000000000 Then

                    MsgBox(
                        Prompt:=Value.ToString("0.00") & " : Kom [0|1e9]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else

                    _kom = Value

                End If

            Catch ex As Exception

                mylog(
                    LogTxt:=Value & vbCrLf & "Error : " &
                    Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")


            End Try

        End Set
    End Property

    <Category(catBaseParameters)>
    <Browsable(False)>
    Public ReadOnly Property komEqlMax As Double
        Get
            Return _kom * 100
        End Get
    End Property

    Private _koc As Double = Double.NaN

    ''' <summary>
    ''' Koc
    ''' Coef. eql. sorption on org. !content!
    ''' in L/kg, [0|1e9], KOC\ZKD (MACRO)
    ''' </summary>
    ''' <returns></returns>
    <DisplayName("Koc")>
    <Description("Coef. eql. sorption on org. !content!" & vbCrLf &
                 "in L/kg, [0|1e9], KOC\ZKD (MACRO), click '..' to calc from Kom")>
    <DefaultValue(Double.NaN)>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catBaseParameters)>
    <Editor(GetType(buttonDblInt), GetType(UITypeEditor))>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format='G8'| unit=' L/kg'")>
    <Browsable(True)>
    Public Property koc As Double
        Get
            Return _koc
        End Get
        Set

            Try

                If Value = buttonDblInt.Clicked Then

                    If Not Double.IsNaN(_koc) Then

                        _koc =
                            Math.Round(_kom * factor, digits:=digits)
                    End If

                ElseIf Value < 0 OrElse
                       Value > 1000000000 Then

                    MsgBox(
                        Prompt:=Value.ToString("0.00") & " : Koc [0|1e9]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else
                    _koc = Value
                End If

            Catch ex As Exception

                mylog(
                    LogTxt:=Value & vbCrLf & "Error : " &
                    Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")

            End Try

        End Set
    End Property


    Private _expFre As Double = Double.NaN

    ''' <summary>
    ''' Summary
    ''' Freundlich Exp. 1/n
    ''' no unit 0.1 - 1.3
    ''' ExpFre
    ''' </summary>
    <DisplayName("1/n")>
    <Description("Freundlich Exp. no unit 0.1 - 1.3 ; ExpFre\Sed\SusSol ")>
    <TypeConverter(GetType(dblConv))>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catBaseParameters)>
    <Browsable(True)>
    <DefaultValue(Double.NaN)>
    Public Property expFre As Double
        Get
            Return _expFre
        End Get
        Set(value As Double)

            Try

                If value < 0.1 OrElse
                   value > 1.3 Then

                    MsgBox(
                        Prompt:=value.ToString("0.0000") &
                        " : Freundlich Exp. 1/n [0.1|1.3]",
                        Buttons:=MsgBoxStyle.Exclamation,
                        Title:="User input outside limits")

                Else
                    _expFre = value
                End If

            Catch ex As Exception

                mylog(
                    LogTxt:=value & vbCrLf & "Error : " &
                    Join(parseExceptionMsg(ex), vbCrLf),
                    Log2MsgBox:=True,
                    MsgBoxBtn:=MsgBoxStyle.Critical,
                    MsgTitle:="Unknown Error")

            End Try


        End Set
    End Property

#End Region


End Class


''' <summary>
''' depth dependent sorption
''' </summary>
<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class sorptionDepthDependent

    Public Sub New()

    End Sub

    Public Const catDepthDeg As String = "02  Depth Dep. Sorption"

#Region "    Depth Dep. Sorption"

    Private _depthDependentFOCUSuserdef As eDepthDependentFOCUSuserdef = eDepthDependentFOCUSuserdef.FOCUS

    <RefreshProperties(RefreshProperties.All)>
    <Category(catDepthDeg)>
    <DisplayName("Depth dep. Sorption")>
    Public Property depthDependentFOCUSuserdef As eDepthDependentFOCUSuserdef
        Get
            Return _depthDependentFOCUSuserdef
        End Get
        Set

            _depthDependentFOCUSuserdef = Value

            If _depthDependentFOCUSuserdef = eDepthDependentFOCUSuserdef.FOCUS Then
                depthDependentSorption = Nothing
            Else
                depthDependentSorption = New depthDependentSorption
            End If

        End Set
    End Property

    <DisplayName("Scenario Settings")>
    <RefreshProperties(RefreshProperties.All)>
    <Category(catDepthDeg)>
    Public Property depthDependentSorption As depthDependentSorption = Nothing

#End Region

End Class

''' <summary>
''' depth dependent sorption
''' </summary>
<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class depthDependentSorption

    Public Sub New()
        resetFacZSor()
    End Sub

    Public Const catDepthdepSorption As String = "02  Depth dep. Sorption "

    <Editor(GetType(buttonEmulator), GetType(UITypeEditor))>
    Public Property reset As String
        Get
            Return ""
        End Get
        Set(value As String)

            If value.Contains(buttonEmulator.Clicked) Then
                resetFacZSor()
            End If

        End Set
    End Property

    Public Sub resetFacZSor()

        Dim facZTraList As New List(Of facZ)

        For scenario As eScenariosGW = eScenariosGW.Chateaudun To eScenariosGW.Thiva

            facZTraList.Add(New facZ)

            With facZTraList(facZTraList.Count - 1)

                .scenario = scenario

                .PEARL444 = DBs.FOCUSGWdb.getFacZSor(
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL444)

                .PEARL555 = DBs.FOCUSGWdb.getFacZSor(
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL555)

            End With

        Next

        facZSor = facZTraList.ToArray

    End Sub

    Public Function getFacZSor(scenario As eScenariosGW) As facZ

        For Each member As facZ In facZSor
            If member.scenario = scenario Then
                Return member
            End If
        Next

        Return Nothing

    End Function

    Public Function getFacZSor(scenario As eScenariosGW, version As ePEARLVersion) As Double()

        Dim facZ As New facZ

        facZ = getFacZSor(scenario:=scenario)

        If Not IsNothing(facZ) Then
            If version = ePEARLVersion.PEARL444 Then
                Return facZ.PEARL444
            Else
                Return facZ.PEARL555
            End If
        End If

        Return Nothing

    End Function

    Public Property facZSor As facZ() = {}

End Class

''' <summary>
''' Depth dependent degT50/Sorption base class
''' </summary>
<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class facZ

    Private _PEARL444 As Double() = {}
    Private _PEARL555 As Double() = {}

    Public Sub New()

    End Sub

    <Browsable(False)>
    Public ReadOnly Property name As String
        Get
            Return scenario.ToString
        End Get
    End Property

    Public Property scenario As eScenariosGW = eScenariosGW.not_def

    <Editor(GetType(multiLineDoubleArrayEditor), GetType(UITypeEditor))>
    <DisplayName("PEARL 4.4.4")>
    Public Property PEARL444 As Double()
        Get
            Return _PEARL444
        End Get
        Set

            If Value.Count <> DBs.FOCUSGWdb.getFacZSor(
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL444).Count Then
                MsgBox(Prompt:="# of horizons do not match, must be " & DBs.FOCUSGWdb.getFacZSor(
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL444).Count)
            Else
                _PEARL444 = Value
            End If

        End Set
    End Property

    <Editor(GetType(multiLineDoubleArrayEditor), GetType(UITypeEditor))>
    <DisplayName("PEARL 5.5.5")>
    Public Property PEARL555 As Double()
        Get
            Return _PEARL555
        End Get
        Set

            If Value.Count <> DBs.FOCUSGWdb.getFacZSor(
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL555).Count Then
                MsgBox(Prompt:="# of horizons do not match, must be " & DBs.FOCUSGWdb.getFacZSor(
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL555).Count)
            Else
                _PEARL555 = Value
            End If

        End Set
    End Property

End Class


