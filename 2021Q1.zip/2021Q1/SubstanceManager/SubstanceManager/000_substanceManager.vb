﻿
Imports System.ComponentModel
Imports System.Drawing.Design
Imports essentials
Imports DBs.FOCUSGWdb
Imports System.Xml.Serialization
Imports System.Web.Script.Serialization


#Region "    Management"


<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class eModSubstanceManager

    Public Sub New()

    End Sub

    Public Const catEmodSubstMan As String = "01  eMod Substance Manager"

    Private _substances As New List(Of substance)

    ''' <summary>
    ''' eMod Substances
    ''' </summary>
    ''' <returns></returns>
    <Category(catEmodSubstMan)>
    <DisplayName("Substances")>
    <RefreshProperties(RefreshProperties.All)>
    Public Property substances As substance()
        Get
            Return _substances.ToArray
        End Get
        Set
            _substances.Clear()
            _substances.AddRange(Value)

            _substances.Last.dataPackages.Last.tiers.Last.pathWays.Last.compounds.Last.show = buttonEmulator.Clicked

        End Set
    End Property


    ''' <summary>
    ''' Add substance
    ''' </summary>
    ''' <returns></returns>
    <Category(catEmodSubstMan)>
    <Editor(GetType(buttonEmulator), GetType(UITypeEditor))>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(" ... add")>
    Public Property add As String
        Get
            Return ""
        End Get
        Set(value As String)

            If value.Contains(buttonEmulator.Clicked) Then
                _substances.Add(New substance)
                _substances.Last.add = buttonEmulator.Clicked
            End If

        End Set
    End Property



End Class

<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class substance

    Public Sub New()

    End Sub

    Public ReadOnly Property name As String
        Get
            Return parentIOP
        End Get
    End Property

    Public Property parentIOP As String

    Public Property parentNameUC As String

    <TypeConverter(GetType(enumConverter(Of eIndication)))>
    Public Enum eIndication

        insecticide
        herbicide
        fungicide

        others

        <Description(enumConverter(Of Type).not_defined)>
        not_def = -1

    End Enum


    <Editor(GetType(MultiLineTextEditor), GetType(UITypeEditor))>
    Public Property comments As String = ""

    Private _dataPackages As New List(Of dataPackage)

    <RefreshProperties(RefreshProperties.All)>
    Public Property dataPackages As dataPackage()
        Get
            Return _dataPackages.ToArray
        End Get
        Set
            _dataPackages.Clear()
            _dataPackages.AddRange(Value)
        End Set
    End Property

    <Editor(GetType(buttonEmulator), GetType(UITypeEditor))>
    Public Property add As String
        Get
            Return ""
        End Get
        Set(value As String)

            If value.Contains(buttonEmulator.Clicked) Then
                _dataPackages.Add(New dataPackage)
                _dataPackages.Last.add = buttonEmulator.Clicked
            End If

        End Set
    End Property

End Class



<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class dataPackage


    Public Sub New()

    End Sub

    Private _tiers As New List(Of tier)

    Public Property tiers As tier()
        Get
            Return _tiers.ToArray
        End Get
        Set
            _tiers.Clear()
            _tiers.AddRange(Value)
        End Set
    End Property

    <Editor(GetType(buttonEmulator), GetType(UITypeEditor))>
    Public Property add As String
        Get
            Return ""
        End Get
        Set(value As String)

            If value.Contains(buttonEmulator.Clicked) Then
                _tiers.Add(New tier)
                _tiers.Last.add = buttonEmulator.Clicked
            End If

        End Set
    End Property

End Class


<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class tier

    Public Sub New()

    End Sub

    Private _pathWays As New List(Of pathWay)

    Public Property pathWays As pathWay()
        Get
            Return _pathWays.ToArray
        End Get
        Set
            _pathWays.Clear()
            _pathWays.AddRange(Value)
        End Set
    End Property

    <Editor(GetType(buttonEmulator), GetType(UITypeEditor))>
    Public Property add As String
        Get
            Return ""
        End Get
        Set(value As String)

            If value.Contains(buttonEmulator.Clicked) Then
                _pathWays.Add(New pathWay)
                _pathWays.Last.show = buttonEmulator.Clicked
            End If

        End Set
    End Property

End Class


#End Region
