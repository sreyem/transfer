﻿
Imports System.ComponentModel
Imports System.Drawing.Design
Imports essentials
Imports DBs.FOCUSGWdb
Imports System.Xml.Serialization
Imports System.Web.Script.Serialization
Imports System.Text

<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class pathWay

    Public Sub New()

    End Sub

#Region "    Formating const."

    Public Const valueEndPos As Integer = 15
    Public Const nameEndPos As Integer = 35
    Public Const unitEndPos As Integer = 45
    Public Const minMaxPos As Integer = 90

#End Region

    Public Const catBasic As String = "01  Basic Inputs"

#Region "    Basic Inputs"

    Private _compounds As New List(Of compound)

    <Category(catBasic)>
    <DisplayName("Compounds")>
    Public Property compounds As compound()
        Get
            Return _compounds.ToArray
        End Get
        Set
            _compounds.Clear()
            _compounds.AddRange(Value)
        End Set
    End Property

    <Category(catBasic)>
    <Editor(GetType(buttonEmulator), GetType(UITypeEditor))>
    <RefreshProperties(RefreshProperties.All)>
    <DisplayName(" ... add")>
    <XmlIgnore> <ScriptIgnore>
    Public Property add As String
        Get
            Return ""
        End Get
        Set(value As String)

            If value.Contains(buttonEmulator.Clicked) Then

                Dim frm As New frmPGrid(
                    class2Show:=New compound,
                    classType:=(New compound).GetType)

                With frm

                    .Width = 900
                    .Height = 750

                End With

                frm.ShowDialog()

                _compounds.Add(frm.class2Show)

            End If

        End Set
    End Property


    Public Const catFF As String = "01a FF"

#Region "    ff"

    Private _scenarioSpecificFF As Boolean = False

    <Category(catFF)>
    <DisplayName("Scenario Specific?")>
    Public Property scenarioSpecificFF As Boolean
        Get
            Return _scenarioSpecificFF
        End Get
        Set

            _scenarioSpecificFF = Value

            If _scenarioSpecificFF Then
                ffScenarioSpecific.compounds = Me.compounds
                scenarioSpecificFFData = {}
            Else
                scenarioSpecificFFData = Nothing
            End If

        End Set
    End Property

    <DisplayName("Formation fractions")>
    <Description("Formation fractions from 0-1")>
    <Category(catFF)>
    Public Property fraPrtDau As formation()
        Get

            Dim out As New List(Of String)

            For Each compound As compound In compounds
                out.Add(compound.common.metaData.iop)
            Next

            formation.compNames = out.ToArray

            Return _FraPrtDau

        End Get
        Set
            _FraPrtDau = Value
        End Set
    End Property




    Private _FraPrtDau As formation() = {}



    <Category(catFF)>
    Public Property scenarioSpecificFFData As ffScenarioSpecific() = Nothing


#End Region

#End Region

    Public Function degradationPELMO() As List(Of String())


        Dim parent As New compound
        Dim ff As New List(Of formation)
        Dim mets As New List(Of compound)
        Dim possMets As New List(Of String)
        Dim actualMet As New compound
        Dim metExits As Boolean = False
        Dim out As New List(Of String)
        Dim co2Fraction As Double = Double.NaN
        Dim lastRow As String = ""

        For position As ePelmoPosition = ePelmoPosition.A0 To ePelmoPosition.D2

            Try

                possMets.AddRange(
                Array.Find(
                    array:=degPosPELMO,
                    match:=Function(x) x.StartsWith(position.ToString)).Split(","))

                possMets.RemoveAt(0)

            Catch ex As Exception

            End Try

            'Dim query01 = From compound As compound In compounds
            '              Where compound.positionPELMO = position
            '              Select compound

            'parent = query01.First




            Dim query02 = From formation As formation In fraPrtDau
                          Where formation.parPosPELMO = position
                          Select formation

            co2Fraction = 0
            For Each member In query02
                ff.Add(member)
                co2Fraction += member.fraction
            Next

            For Each member As String In possMets

                metExits = False


                For Each forf As formation In ff

                    If forf.metPosPELMO.ToString = member Then

                        Dim query01 = From compound As compound In compounds
                                      Where compound.common.metaData.iop = forf.parent
                                      Select compound

                        parent = query01.First


                        If out.Count = 0 Then
                            out.AddRange(
                                parent.createPELMOdegRow(
                                ff:=forf.fraction,
                                PELMOpos:=forf.metPosPELMO))
                        Else
                            out.Add(
                                parent.createPELMOdegRow(
                                ff:=forf.fraction,
                                PELMOpos:=forf.metPosPELMO).Last)
                        End If

                        lastRow = parent.createPELMOdegRow(
                                ff:=1 - co2Fraction,
                                PELMOpos:=ePelmoPosition.not_def).Last & "<BR/CO2>"

                        metExits = True

                    End If

                Next

                If Not metExits Then

                    parent = New compound
                    If out.Count = 0 Then

                        out.AddRange(
                         parent.createPELMOdegRow(
                         ff:=1,
                         PELMOpos:=[Enum].Parse(enumType:=GetType(ePelmoPosition), value:=member), empty:=True))

                    Else
                        out.Add(
                            parent.createPELMOdegRow(
                            ff:=1,
                            PELMOpos:=[Enum].Parse(enumType:=GetType(ePelmoPosition), value:=member), empty:=True).Last)
                    End If

                End If


            Next

            out.Add(lastRow)

        Next

        ' Return out.ToArray

    End Function

    Public Function getParent() As compound

    End Function


    <Editor(GetType(buttonEmulator), GetType(UITypeEditor))>
    Public Property test As String
        Get
            Return ""
        End Get
        Set(value As String)

            If value.Contains(buttonEmulator.Clicked) Then
                degradationPELMO()

                createPEARLSubstChapters()
            End If

        End Set
    End Property

    Public Sub createPEARLSubstChapters()

        Dim para1st As New List(Of parameterFiles)

        Dim temp As New List(Of String())
        Dim scen As New List(Of String)
        Dim top As New List(Of String)
        Dim header As New List(Of String)
        Dim std As New List(Of String)

        With header

            .Add("*-------------------------------------------------------------------------------")
            .Add("*  Compound section, key parameters")
            .Add("*-------------------------------------------------------------------------------")
            .Add("")

            .AddRange(createTableCompounds)
            .Add("")

        End With

        For scenario As eScenariosGW = eScenariosGW.Chateaudun To eScenariosGW.Thiva

            top.Clear()
            top.AddRange(header)

            top.Add("* Formation Fractions")
            top.AddRange(createFraPrtDau(scenario:=scenario))
            top.Add("")

            std.Clear()

            For compoundCounter As Integer = 0 To Me.compounds.Count - 1

                temp.Clear()
                temp.AddRange(Me.compounds(compoundCounter).createPEARLCompound(scenario:=scenario))

                top.AddRange(temp(0))
                top.Add("")
                std.AddRange(temp(1))
                std.Add("")

            Next

            para1st.Add(New parameterFiles)

            With para1st(para1st.Count - 1)

                .scenario = scenario

                scen.Clear()
                scen.AddRange(top)

                scen.Add("* Depth dependent degT50")
                scen.AddRange(
                    createFacZ(
                    traSor:=degt50Sorption.eTraSor.Tra,
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL444).First)

                scen.Add("")

                scen.Add("* Depth dependent Sorption")
                scen.AddRange(
                    createFacZ(
                    traSor:=degt50Sorption.eTraSor.Sor,
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL444).First)

                scen.Add("*-------------------------------------------------------------------------------")
                scen.Add("*  Compound section, standards & constants")
                scen.Add("*-------------------------------------------------------------------------------")
                scen.Add("")

                scen.AddRange(std)

                scen.Add(
                createPrlRow(
                Value:="0.01",
                iop:="",
                parameterName:="ThiAirBouLay",
                unit:="(m)",
                description:="Boundary air layer thickness",
                range:="[1e-6|1]"))

                .PEARL444 = scen.ToArray

                scen.Clear()
                scen.AddRange(top)

                scen.Add("* Depth dependent values")
                scen.AddRange(
                    createFacZ(
                    traSor:=degt50Sorption.eTraSor.Tra,
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL555).First)

                scen.Add("*")

                scen.AddRange(
                    createFacZ(
                    traSor:=degt50Sorption.eTraSor.Sor,
                    scenario:=scenario,
                    version:=ePEARLVersion.PEARL555).First)

                scen.Add("* ")
                scen.Add("* Standard parameters")
                scen.Add("* ")

                scen.AddRange(std)

                scen.Add(
                createPrlRow(
                Value:="0.01",
                iop:="",
                parameterName:="ThiAirBouLay",
                unit:="(m)",
                description:="Boundary air layer thickness",
                range:="[1e-6|1]"))

                .PEARL555 = scen.ToArray

            End With

        Next

        paramter_SFO_TDS_k1_Acid = para1st.ToArray

    End Sub


    Public Function createFacZ(traSor As degt50Sorption.eTraSor, scenario As eScenariosGW, version As ePEARLVersion) As List(Of String())

        Dim out As New List(Of String())
        Dim temp As New List(Of String)

        Dim row1st As New List(Of StringBuilder)
        Dim row2nd As New List(Of StringBuilder)

        Dim facZ As New List(Of Double())
        Dim twoParametersets As Boolean = False
        Dim space As Integer = 8
        Dim noOfHorizons As Integer

        noOfHorizons = DBs.FOCUSGWdb.getFacZTra(scenario:=scenario, version:=version).Count

        row1st.Add(New StringBuilder(value:="table horizon "))

        If traSor = degt50Sorption.eTraSor.Tra Then
            row1st.First.Append("FacZTra (-)")
        Else
            row1st.First.Append("FacZSor (-)")
        End If

        row1st.Add(New StringBuilder(value:="horizon".PadRight(space)))

        For compoundCounter As Integer = 0 To Me.compounds.Count - 1

            With Me.compounds(compoundCounter)

                If .degType = eDegType.DFOP OrElse
                   .degType = eDegType.pH Then

                    twoParametersets = True

                End If

            End With

        Next

        For horizonCounter As Integer = 1 To noOfHorizons
            row1st.Add(New StringBuilder(value:=horizonCounter.ToString.PadRight(space)))
        Next

        For Each member In row1st
            row2nd.Add(New StringBuilder(value:=member.ToString))
        Next

        For compoundCounter As Integer = 0 To Me.compounds.Count - 1

            With Me.compounds(compoundCounter)

                If traSor = degt50Sorption.eTraSor.Tra Then

                    facZ =
                        .degt50Sorption.getFacZ(
                            traSor:=degt50Sorption.eTraSor.Tra,
                            scenario:=scenario,
                            version:=version)

                Else

                    facZ =
                        .degt50Sorption.getFacZ(
                            traSor:=degt50Sorption.eTraSor.Sor,
                            scenario:=scenario,
                            version:=version)

                End If

                row1st(1).Append(.common.metaData.iop.PadRight(space))
                row2nd(1).Append(.common.metaData.iop.PadRight(space))

            End With

            For facZCounter As Integer = 0 To facZ(0).Count - 1
                row1st(facZCounter + 2).Append(facZ(0)(facZCounter).ToString.PadRight(space))
            Next

            If facZ.Count = 2 Then

                For facZCounter As Integer = 0 To facZ(1).Count - 1
                    row2nd(facZCounter + 2).Append(facZ(1)(facZCounter).ToString.PadRight(space))
                Next

            End If


        Next

        row1st.Add(New StringBuilder(value:="end_table"))
        row2nd.Add(New StringBuilder(value:="end_table"))

        temp.Clear()
        For Each member In row1st
            temp.Add(member.ToString)
        Next

        out.Add(temp.ToArray)

        If twoParametersets Then

            temp.Clear()

            For Each member In row2nd
                temp.Add(member.ToString)
            Next

            out.Add(temp.ToArray)

        End If

        Return out

    End Function

    Public Function createTableCompounds() As String()

        Dim out As New List(Of String)

        If Not IsNothing(compounds) AndAlso compounds.Count > 0 Then

            out.Add(compounds.First.common.metaData.iop.ToUpper.PadRight(10) & "SubstanceName")

            out.Add("table compounds")

            For Each compound As compound In compounds
                out.Add(compound.common.metaData.iop.ToUpper)
            Next

            out.Add("end_table")

        End If

        Return out.ToArray

    End Function

    Public Function createFraPrtDau(Optional scenario As eScenariosGW = eScenariosGW.not_def) As String()

        Dim out As New List(Of String)

        out.Add("table FraPrtDau (mol.mol-1)")

        If Me.scenarioSpecificFF Then

            For Each member In Me.scenarioSpecificFFData

                If member.scenario = scenario Then

                    For Each formation As formation In member.fraPrtDau
                        out.Add(formation.tostring)
                    Next

                End If

            Next

        End If

        If out.Count = 1 Then
            For Each formation As formation In fraPrtDau
                out.Add(formation.tostring)
            Next
        End If

        out.Add("end_table")

        Return out.ToArray

    End Function


    ''' <summary>
    ''' Show item in own window
    ''' </summary>
    ''' <returns></returns>
    <Category(catBasic)>
    <Editor(GetType(buttonEmulator), GetType(UITypeEditor))>
    <DisplayName("Show ...")>
    <Description("Show item in own window")>
    <XmlIgnore> <ScriptIgnore>
    <Browsable(True)>
    <DefaultValue("")>
    Public Property show As String
        Get
            Return ""
        End Get
        Set(value As String)

            If value.Contains(buttonEmulator.Clicked) Then

                Dim frm As New frmPGrid(class2Show:=Me, classType:=Me.GetType)

                With frm

                    .Width = 900
                    .Height = 550

                End With

                frm.ShowDialog()

                Me.CopyPropertiesByName(src:=frm.class2Show)

            End If

        End Set
    End Property


    Public Const catFinalParameterSets As String = "02  Final Parameter Sets"

#Region "    Final Parameter Sets"

    <Category(catFinalParameterSets)>
    <DisplayName("Parameters 1st Set")>
    <Description("Parameter set for SFO, TDS, DFOP k1, Acid")>
    Public Property paramter_SFO_TDS_k1_Acid As parameterFiles() = {}

    <Category(catFinalParameterSets)>
    <DisplayName("Parameters 2nd Set")>
    <Description("Parameter set for DFOP k2, Alkaline")>
    Public Property paramter_Alkaline_k2 As parameterFiles() = {}

#End Region

End Class

<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class parameterFiles

    Private _PEARL444 As String() = {}

    Public Sub New()

    End Sub

    <Browsable(False)>
    Public ReadOnly Property name As String
        Get
            Return extras.getEnumDescription(scenario)
        End Get
    End Property


    <Category("Base")>
    Public Property scenario As eScenariosGW = eScenariosGW.not_def

    <Category("PEARL")>
    <DisplayName("PEARL v. 4.4.4")>
    <Editor(GetType(buttonEmulatorGeneric), GetType(UITypeEditor))>
    Public Property PEARL444 As String()
        Get

            If buttonEmulatorGeneric.Clicked Then

                buttonEmulatorGeneric.Clicked = False

                My.Computer.Clipboard.SetText(
                        text:=Join(
                            SourceArray:=_PEARL444,
                            Delimiter:=vbCrLf))

                MsgBox("Copy PEARL v. 4.4.4 Compound section to Clipboard")

            End If

                Return _PEARL444
        End Get
        Set

            _PEARL444 = Value

        End Set
    End Property

    <Category("PEARL")>
    <DisplayName("PEARL v. 5.5.5")>
    Public Property PEARL555 As String() = {}

    <Category("PELMO")>
    <DisplayName("PELMO v. 5.3.3")>
    Public Property PELMO553 As String() = {}

    <Category("PELMO")>
    <DisplayName("PELMO v. 6.6.4")>
    Public Property PELMO664 As String() = {}

    <Category("MACRO")>
    <DisplayName("MACRO v. 5.5.4")>
    Public Property MACRO544 As String() = {}

End Class

<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class ffScenarioSpecific

    Public Sub New()

    End Sub

    <Browsable(False)>
    Public ReadOnly Property name As String
        Get
            Return scenario.ToString
        End Get
    End Property

    <Category()>
    Public Property scenario As eScenariosGW = eScenariosGW.not_def

    Public Shared Property compounds As compound() = {}

    Private _FraPrtDau As formation() = {}

    <DisplayName("FF")>
    <Description("Formation fractions from 0-1")>
    <Category()>
    Public Property fraPrtDau As formation()
        Get

            Dim out As New List(Of String)

            For Each compound As compound In compounds
                out.Add(compound.common.metaData.iop)
            Next

            formation.compNames = out.ToArray

            Return _FraPrtDau

        End Get
        Set
            _FraPrtDau = Value
        End Set
    End Property


End Class


<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class formation

    Public Shared compNames As String()

    Private _parent As String
    Private _metabolite As String

    Public Sub New()

    End Sub

    <Browsable(False)>
    Public ReadOnly Property name As String
        Get
            If parent <> "" AndAlso
               metabolite <> "" AndAlso
               fraction <= 1 AndAlso
               fraction >= 0 Then

                Return fraction.ToString.PadRight(8) &
                        parent.PadRight(7) & " -> " &
                        metabolite.PadRight(7) & vbCrLf &
                        " ".PadRight(8) & parPosPELMO.ToString.PadRight(7) &
                        " -> " & metPosPELMO.ToString.PadRight(7)
            Else
                Return ""
            End If
        End Get
    End Property

    Public Overrides Function tostring() As String
        Return name
    End Function

    <TypeConverter(GetType(dropDownList))>
    <DisplayName("01  Parent")>
    Public Property parent As String
        Get

            If Not IsNothing(compNames) AndAlso compNames.Count > 0 Then
                dropDownList.dropDownEntries = compNames.ToArray
            End If

            Return _parent
        End Get
        Set
            _parent = Value
        End Set
    End Property


    ''' <summary>
    ''' PELMO Path Position
    ''' A0 = Parent, a1, b1, c1, d1
    '''              a2, b2, c2, d2
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
                "PARENT PELMO Path Position")>
    <Description(
            "A0 = Parent, a1, b1, c1, d1" & vbCrLf &
            "             a2, b2, c2, d2")>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <Category()>
    <DefaultValue(CInt(ePelmoPosition.not_def))>
    Public Property parPosPELMO As ePelmoPosition



    <TypeConverter(GetType(dropDownList))>
    <DisplayName("02  Metabolite")>
    Public Property metabolite As String
        Get

            If Not IsNothing(compNames) AndAlso compNames.Count > 1 Then
                dropDownList.dropDownEntries =
                            Filter(
                            Source:=compNames.ToArray,
                            Match:=_parent,
                            Include:=False,
                            Compare:=CompareMethod.Text)
            End If

            Return _metabolite

        End Get
        Set
            _metabolite = Value
        End Set
    End Property

    ''' <summary>
    ''' PELMO Path Position
    ''' A0 = Parent, a1, b1, c1, d1
    '''              a2, b2, c2, d2
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
                "METABOLITE PELMO Path Position")>
    <Description(
            "A0 = Parent, a1, b1, c1, d1" & vbCrLf &
            "             a2, b2, c2, d2")>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <Category()>
    <DefaultValue(CInt(ePelmoPosition.not_def))>
    Public Property metPosPELMO As ePelmoPosition

    <DisplayName("03  Formation Fraction")>
    Public Property fraction As Double = 0

End Class
