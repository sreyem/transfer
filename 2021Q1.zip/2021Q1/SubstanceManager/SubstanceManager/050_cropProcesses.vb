﻿

Imports System.ComponentModel
Imports System.Drawing.Design
Imports System.Text
Imports System.Xml.Serialization
Imports essentials
Imports DBs.FOCUSGWdb
Imports System.Web.Script.Serialization

<Serializable>
<TypeConverter(GetType(propGridConverter))>
Public Class cropProcesses


    Public Sub New()

    End Sub

    <Browsable(False)>
    Public ReadOnly Property name As String
        Get

            Dim out As New StringBuilder

            If Not Double.IsNaN(degT50DspCrp.degT50) AndAlso
                degT50DspCrp.degT50 <> stdDegT50DspCrp Then

                out.Append(
                "degT50   : " &
                dblConv.conv2String(value:=degT50DspCrp.degT50, unit:=" days") & vbCrLf)

            Else
                Return propGridConverter.noName
            End If

            If Not Double.IsNaN(facUpt) Then
                out.Append(
                "PUF      : " &
                dblConv.conv2String(value:=facUpt, unit:=" (-)") & vbCrLf)
            End If

            If Not Double.IsNaN(facUpt) Then
                out.Append(
                "Wash-Off : " &
                dblConv.conv2String(value:=facWasCrp, unit:=" per meter") & vbCrLf)
            End If

            Return out.ToString

        End Get
    End Property

    Public Function createPELMOPlantUptake() As String()

        Dim out As New List(Of String)

        out.Add("<PLANT UPTAKE>")
        out.Add(" " & facUpt.ToString.PadRight(totalWidth:="0      ".Length) & "<plant uptake factor>")
        out.Add("<END PLANT UPTAKE>")

        Return out.ToArray

    End Function

    Public Function createPEARLCropProcesses(Optional iop As String = "") As List(Of String())

        Dim out As New List(Of String())

        Dim top As New List(Of String)
        Dim std As New List(Of String)
        Dim both As New List(Of String)

        Dim description As String
        Dim row As String

        row =
        createPrlRow(
            Value:="Lumped",
            iop:=iop,
            parameterName:="OptDspCrp_",
            unit:=" ",
            description:="Lumped, Specified or Calculated",
            range:=" ")

        std.Add(row) : both.Add(row)

        row =
        createPrlRow(
            Value:=facUpt,
            iop:=iop,
            parameterName:="FacUpt_",
            unit:="(-)",
            description:="Coefficient for uptake by plant (TSCF)",
            range:="[0|10]")

        std.Add(row) : both.Add(row)


        row =
            createPrlRow(
                Value:=degT50DspCrp.degT50,
                iop:=iop,
                parameterName:="DT50DspCrp_",
                unit:="(d)",
                description:="Half-life at crop surface",
                range:="[1|1e6]")

        If degT50DspCrp.degT50 <> stdDegT50DspCrp Then

            top.AddRange(
           {
           "*",
           "* Std. value (" & stdDegT50DspCrp & " days) for degT50 at crop surface changed !!!",
           row,
           "*"
           })

            both.AddRange(
            {
            "*",
            "* Std. value (" & stdDegT50DspCrp & " days) for degT50 at crop surface changed !!!",
            row,
            "*"
            })


        Else
            std.Add(row) : both.Add(row)
        End If

        row =
            createPrlRow(
                Value:=facWasCrp,
                iop:=iop,
                parameterName:="FacWasCrp_",
                unit:="(m-1)",
                description:="Wash-off factor TSCF",
                range:="[1e-6|0.1]")

        If facWasCrp <> stdFacWasCrp Then

            top.AddRange(
           {
           "*",
           "* Std. value (" & stdFacWasCrp & " per meter) for wash-off factor changed !!!",
           row,
           "*"
           })

            both.AddRange(
            {
            "*",
            "* Std. value (" & stdFacWasCrp & " per meter) for wash-off factor changed !!!",
            row,
            "*"
            })

        Else
            std.Add(row) : both.Add(row)
        End If


        'row =
        '   createPrlRow(
        '       Value:=_thiAirBouLay,
        '       iop:=iop,
        '       parameterName:="ThiAirBouLay_",
        '       unit:="(m)",
        '       description:="Boundary air layer thickness",
        '       range:="[1e-6|1]")

        'If _thiAirBouLay <> stdThiAirBouLay Then

        '    top.AddRange(
        '           {
        '           "*",
        '           "* Std. value (" & stdThiAirBouLay & " meter) for boundary air layer thickness changed !!!",
        '           row,
        '           "*"
        '           })

        '    both.AddRange(
        '            {
        '            "*",
        '            "* Std. value (" & stdThiAirBouLay & " meter) for boundary air layer thickness changed !!!",
        '            row,
        '            "*"
        '            })


        'Else
        '    std.Add(row) : both.Add(row)
        'End If

        out.Add(top.ToArray)
        out.Add(std.ToArray)
        out.Add(both.ToArray)

        Return out

    End Function


    Public Const stdDegT50DspCrp As Double = 1000000
    Public Const stdFacWasCrp As Double = 0.0001

    Private _degT50DspCrp As New degT50(degT50:=stdDegT50DspCrp)
    Private _facWasCrp As Double = stdFacWasCrp
    Private _facUpt As Double = Double.NaN

    ''' <summary>
    ''' Half-life at crop surface
    ''' in Pa [1|1E6 ; DT50DspCrp]
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
        "DT50 Crop Surface")>
    <Description(
    "Half-life at crop surface" & vbCrLf &
    "in Pa [1|1E6 ; DT50DspCrp]")>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <Category()>
    <DefaultValue(CType(Nothing, Object))>
    Public Property degT50DspCrp As degT50
        Get
            Return _degT50DspCrp
        End Get
        Set
            _degT50DspCrp = Value
        End Set
    End Property

    ''' <summary>
    ''' Plant uptake factor
    ''' in Pa [0|10 ; FacUpt]
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
        "Plant Uptake Factor")>
    <Description(
    "Plant uptake factor" & vbCrLf &
    "in Pa [0|10 ; FacUpt]")>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <Category()>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= 'G4'|unit=' (-)'")>
    <DefaultValue(Double.NaN)>
    Public Property facUpt As Double
        Get
            Return _facUpt
        End Get
        Set
            _facUpt = Value
        End Set
    End Property


    ''' <summary>
    ''' Wash-off factor
    ''' in per meter [1E-6|0.1 ; FacWasCrp]
    ''' </summary>
    ''' <returns></returns>
    <DisplayName(
        "Wash Off")>
    <Description(
    "Wash-off factor" & vbCrLf &
    "in per meter [1E-6|0.1 ; FacWasCrp]")>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    <Category()>
    <TypeConverter(GetType(dblConv))>
    <AttributeProvider("format= 'G4'|unit=' per meter'")>
    <DefaultValue(stdFacWasCrp)>
    Public Property facWasCrp As Double
        Get
            Return _facWasCrp
        End Get
        Set
            _facWasCrp = Value
        End Set
    End Property



    <RefreshProperties(RefreshProperties.All)>
    <DisplayName("PSM Crop Processes Values")>
    <Description("Crop Processes section for this substance" & vbCrLf &
                 "for  PELMO 5.5.3/6.6.4")>
    <Browsable(True)>
    <[ReadOnly](True)>
    <Category()>
    <XmlIgnore>
    Public ReadOnly Property psmCropProcesses As String()
        Get
            Return createPELMOPlantUptake()
        End Get
    End Property

End Class
