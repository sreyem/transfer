﻿
Imports System.ComponentModel
Imports System.Drawing.Design
Imports System.IO
Imports System.Runtime.Serialization
Imports System.Text
Imports System.Web.Script.Serialization
Imports System.Xml.Serialization

Imports essentials
Imports SubstanceManager



Public Class frmMain

    Public Sub New()
        InitializeComponent()



        'test =
        '    essentials.DeSerialize.XML2Class(
        '    ClassType:=test.GetType,
        '    XMLFileName:="C:\developer\DevID0002\2021Q1\SubstanceManager\pelmo.xml")

        'test.createPEARLSubstChapters()


        'test.show = buttonEmulator.Clicked

        'End

        class2Show = test

        Me.propGridMain.SelectedObject = class2Show

    End Sub

    Public Property class2Show As Object

    'Public Property test As New eModSubstanceManager
    'Public Property test As New compound
    'Public Property test As New degt50Sorption
    'Public Property test As New pathWay
    'Public Property test As New degt50Sorption
    'Public Property test As New degT50New.degT50TempMoistCorrScen
    'Public Property test As New sorptionNew.equilibriumSorption

    Public Property test As New compound

#Region "Form-Stuff"

    Private Sub gridItemChangedMain(
            sender As Object,
            e As SelectedGridItemChangedEventArgs) Handles propGridMain.SelectedGridItemChanged

        If Not IsNothing(e.OldSelection) AndAlso
           Not IsNothing(e.NewSelection.Value) AndAlso
           e.NewSelection.Value.GetType.ToString <> (New Date).GetType.ToString Then

            Try

                With propGridDetails

                    .Font = New Font(
                                    familyName:="Courier New",
                                    emSize:=10)

                    .PropertySort = PropertySort.Categorized
                    .SelectedObject = e.NewSelection.Value

                    .Refresh()

                End With

            Catch ex As Exception
                Console.Write(ex.Message)
            End Try

        End If

    End Sub

    Private Sub propertyValue_Changed(s As Object, e As PropertyValueChangedEventArgs) Handles _
                                propGridMain.PropertyValueChanged,
                                propGridDetails.PropertyValueChanged

        Dim oldValue As String

        '1st change
        If IsNothing(e.OldValue) Then
            oldValue = ""
        Else
            oldValue = e.OldValue.ToString
        End If

        Dim NewValue As String
        Dim ChangedItemLabel As String = e.ChangedItem.Label.ToString
        Dim Status As String

        If Not IsNothing(e.ChangedItem.Value) Then

            NewValue = e.ChangedItem.Value.ToString

            oldValue = Replace(
                            Expression:=oldValue,
                                  Find:=Environment.NewLine,
                           Replacement:=" ")

            If oldValue <> NewValue Then

                Status =
                    "Value for '" &
                        ChangedItemLabel & "' changed: " &
                        IIf(
                            oldValue = "",
                            "",
                            " from " & oldValue).ToString &
                            " to " & NewValue

                Status = Replace(
                                Expression:=Status,
                                      Find:=vbCrLf,
                               Replacement:="")

                Me.lblStatus.Text = Status

            End If

        End If

        'refresh()

    End Sub

    Private Sub tsmiExit_Click(sender As Object, e As EventArgs) Handles tsmiExit.Click

        Me.Close()

    End Sub


#Region "load and save"

    Private Sub save_click(sender As Object, e As EventArgs) Handles tsmiSave.Click

        Try
            Me.lblStatus.Text = serialize()
        Catch ex As Exception
            Me.lblStatus.Text = ex.Message
        End Try

    End Sub

    Public Function serialize() As String

        Dim mySaveFileDialog As New SaveFileDialog

        With mySaveFileDialog

#Region "            SaveFileDialog settings"

            .Filter =
                "XML files (*.xml)|*.xml|" &
                "Binary files (*.soap)|*.soap|" &
                "JSON files (*.json)|*.json|" &
                "All files (*.*)|*.*"

            .FilterIndex = 0

            .AddExtension = True
            .AutoUpgradeEnabled = True

            .CheckFileExists = False
            .CheckPathExists = True

            .CreatePrompt = False
            .OverwritePrompt = True

#End Region

            'get filename
            If .ShowDialog <> DialogResult.OK Then
                Return " Save canceled by user"
            End If

            Select Case Path.GetExtension(.FileName).ToLower

                Case ".xml"

                    Dim myWriter As IO.StreamWriter = Nothing

                    Try

                        Dim mySerializer As XmlSerializer =
                            New XmlSerializer(class2Show.GetType)

                        myWriter = New IO.StreamWriter(.FileName)

                        mySerializer.Serialize(
                            textWriter:=myWriter,
                            o:=class2Show)

                    Catch ex As Exception

                        Return "Error serializing (saving) class " &
                            ex.Message

                    Finally
                        myWriter.Close()
                        myWriter = Nothing
                    End Try

                Case ".soap"

                    Dim formatter As IFormatter = Nothing
                    Dim fileStream As FileStream = Nothing

                    Try

                        fileStream =
                            New FileStream(
                        path:= .FileName,
                        mode:=FileMode.Create,
                      access:=FileAccess.Write)

                        formatter =
                            New Formatters.Binary.BinaryFormatter

                        formatter.Serialize(
                                serializationStream:=fileStream,
                                              graph:=class2Show)

                    Catch ex As Exception
                        Return "Error serializing to SOAP " & ex.Message
                    Finally

                        If fileStream IsNot Nothing Then
                            fileStream.Close()
                        End If

                    End Try

                Case ".json"

                    Try

                        Dim serializer As New JavaScriptSerializer

                        Dim serializedResult =
                            serializer.Serialize(class2Show)

                        serializedResult =
                            New jsonFormatter(json:=serializedResult).Format

                        File.WriteAllText(
                            path:= .FileName,
                            contents:=serializedResult)

                        Return True

                    Catch ex As Exception
                        Return "Error serializing to JSON " & ex.Message
                    End Try

            End Select

            Return "OK : Serializing class to file " & .FileName

        End With

        Return False

    End Function


    Private Sub load_click(sender As Object, e As EventArgs) Handles tsmiLoad.Click

        Try
            Me.lblStatus.Text = deSerialize()
        Catch ex As Exception
            Me.lblStatus.Text = ex.Message
        End Try

    End Sub

    Public Function deSerialize() As String

        Dim myOpenFileDialog As New OpenFileDialog
        Dim xmlFile As String() = {}
        Dim myFileStream As IO.FileStream = Nothing
        Dim jsonString As String = String.Empty
        Dim jss = New JavaScriptSerializer()

        With myOpenFileDialog

#Region "            OpenFileDialog settings"

            .Filter =
                "XML files (*.xml)|*.xml|" &
                "Binary files (*.soap)|*.soap|" &
                "JSON files (*.json)|*.json|" &
                "All files (*.*)|*.*"

            .FilterIndex = 0

            .AddExtension = True
            .AutoUpgradeEnabled = True

            .CheckFileExists = False
            .CheckPathExists = True

#End Region

            'get filename
            If .ShowDialog <> DialogResult.OK Then
                Return "Canceled by user"
            End If

            Select Case Path.GetExtension(.FileName).ToLower

                Case ".xml"

                    'read xml file, text and stream
                    Try
                        xmlFile = File.ReadAllLines(.FileName)

                        ' To read the file, create a FileStream.
                        myFileStream =
                            New IO.FileStream(
                                    path:= .FileName,
                                    mode:=IO.FileMode.Open)

                    Catch ex As Exception

                        If Not IsNothing(myFileStream) Then
                            myFileStream.Close()
                        End If

                        Return "IO error : " & ex.Message

                    End Try

                    'de-serialize json string to class2Show
                    Try

                        Dim mySerializer As XmlSerializer =
                            New XmlSerializer(class2Show.GetType)

                        class2Show =
                            mySerializer.Deserialize(myFileStream)

                    Catch ex As Exception
                        Return "Error de-serializing json string to " &
                               class2Show.GetType.FullName
                    Finally
                        myFileStream.Close()
                    End Try

                    'check type and show in property grid
                    Try

                        If Not xmlFile(1).StartsWith(
                            "<" & class2Show.GetType.FullName.Split(".").Last) Then

                            Return "File and class don't match < " &
                                class2Show.GetType.FullName.Split(".").Last

                        Else

                            With Me.propGridMain

                                .SelectedObject = Nothing
                                .SelectedObject = class2Show
                                .Refresh()

                            End With

                            Return "OK : Load file " & .FileName

                        End If

                    Catch ex As Exception

                        Return ex.Message

                    End Try


                Case ".soap"

                    Dim formatter As IFormatter = Nothing
                    Dim fileStream As FileStream = Nothing

                    'getting file stream
                    Try
                        fileStream = New FileStream(
                                             path:= .FileName,
                                             mode:=FileMode.Open,
                                           access:=FileAccess.Read)
                    Catch ex As Exception

                        If fileStream IsNot Nothing Then
                            fileStream.Close()
                        End If

                        Return "IO Error De-Serializing : " &
                            ex.Message

                    End Try

                    'de-serialization SOAP binary and 
                    'show in property grid
                    Try

                        formatter =
                            New Formatters.Binary.BinaryFormatter

                        class2Show =
                            formatter.Deserialize(
                            serializationStream:=fileStream)


                        With Me.propGridMain

                            .SelectedObject = Nothing
                            .SelectedObject = class2Show
                            .Refresh()

                        End With

                        Return "OK : SOAP De-Serializing from " &
                            .FileName

                    Catch ex As Exception
                        Return "ERROR SOAP De-Serializing : " &
                            ex.Message

                    Finally

                        If fileStream IsNot Nothing Then
                            fileStream.Close()
                        End If
                    End Try

                Case ".json"

                    'get json string
                    Try
                        jsonString =
                            File.ReadAllText(
                                path:= .FileName)
                    Catch ex As Exception
                        Return "IO ERROR reading JSON file : " & ex.Message
                    End Try

                    'de-serialization JSON string and 
                    'show in property grid
                    Try

                        class2Show = jss.Deserialize(
                                       input:=jsonString,
                                       targetType:=class2Show.GetType)


                        With Me.propGridMain

                            .SelectedObject = Nothing
                            .SelectedObject = class2Show
                            .Refresh()

                        End With


                    Catch ex As Exception
                        Return "ERROR de-serialization JSON " & ex.Message
                    End Try

                Case Else

                    Return "Unknown file type "

            End Select

        End With

        Return "?"

    End Function

#Region "    json formating"

    Public Class jsonFormatter

        Private ReadOnly _walker As StringWalker
        Private ReadOnly _writer As IndentWriter = New IndentWriter()
        Private ReadOnly _currentLine As StringBuilder = New StringBuilder()
        Private _quoted As Boolean

        Public Sub New(ByVal json As String)
            _walker = New StringWalker(json)
            ResetLine()
        End Sub

        Public Sub ResetLine()
            _currentLine.Length = 0
        End Sub

        Public Function Format() As String
            While MoveNextChar()

                If Not Me._quoted AndAlso Me.isOpenBracket() Then
                    Me.writeCurrentLine()
                    Me.addCharToLine()
                    Me.writeCurrentLine()
                    _writer.Indent()
                ElseIf Not Me._quoted AndAlso Me.isCloseBracket() Then
                    Me.writeCurrentLine()
                    _writer.UnIndent()
                    Me.addCharToLine()
                ElseIf Not Me._quoted AndAlso Me.isColon() Then
                    Me.addCharToLine()
                    Me.writeCurrentLine()
                Else
                    addCharToLine()
                End If
            End While

            Me.writeCurrentLine()
            Return _writer.ToString()
        End Function

        Private Function MoveNextChar() As Boolean
            Dim success As Boolean = _walker.MoveNext()

            If Me.isApostrophe() Then
                Me._quoted = Not _quoted
            End If

            Return success
        End Function

        Public Function isApostrophe() As Boolean
            Return Me._walker.currentChar = """"c AndAlso Me._walker.isEscaped = False
        End Function

        Public Function isOpenBracket() As Boolean
            Return Me._walker.currentChar = "{"c OrElse Me._walker.currentChar = "["c
        End Function

        Public Function isCloseBracket() As Boolean
            Return Me._walker.currentChar = "}"c OrElse Me._walker.currentChar = "]"c
        End Function

        Public Function isColon() As Boolean
            Return Me._walker.currentChar = ","c
        End Function

        Private Sub addCharToLine()
            Me._currentLine.Append(_walker.currentChar)
        End Sub

        Private Sub writeCurrentLine()
            Dim line As String = Me._currentLine.ToString().Trim()

            If line.Length > 0 Then
                _writer.WriteLine(line)
            End If

            Me.ResetLine()
        End Sub
    End Class

    Public Class StringWalker

        Private ReadOnly _s As String
        Public Property index As Integer
        Public Property isEscaped As Boolean
        Public Property currentChar As Char

        Public Sub New(ByVal s As String)
            _s = s
            Me.index = -1
        End Sub

        Public Function MoveNext() As Boolean

            If Me.index = _s.Length - 1 Then Return False

            If Not isEscaped Then
                isEscaped = currentChar = "\"c
            Else
                isEscaped = False
            End If

            Me.index += 1
            currentChar = _s(index)
            Return True

        End Function
    End Class

    Public Class IndentWriter

        Private ReadOnly _result As StringBuilder = New StringBuilder()
        Private _indentLevel As Integer

        Public Sub Indent()
            _indentLevel += 1
        End Sub

        Public Sub UnIndent()
            If _indentLevel > 0 Then _indentLevel -= 1
        End Sub

        Public Sub WriteLine(ByVal line As String)
            _result.AppendLine(CreateIndent() & line)
        End Sub

        Private Function CreateIndent() As String
            Dim indent As StringBuilder = New StringBuilder()

            For i As Integer = 0 To _indentLevel - 1
                indent.Append("    ")
            Next

            Return indent.ToString()
        End Function

        Public Overrides Function ToString() As String
            Return _result.ToString()
        End Function
    End Class


#End Region

#End Region

#Region "collapse and expand"

    Public Shared refreshOngoing As Boolean = False

    Private Sub tsmiCollapseStd_Click(sender As Object, e As EventArgs) Handles tsmiCollapseStd.Click

        Dim root As GridItem

        If Not refreshOngoing Then

            If Not IsNothing(propGridMain.SelectedGridItem) AndAlso
                Not IsNothing(propGridMain.SelectedGridItem.Parent) AndAlso
                Not IsNothing(propGridMain.SelectedGridItem.Parent.Parent) Then

                root = propGridMain.SelectedGridItem.Parent.Parent

                Try

                    For Each CollapesCategorie As String In class2Show.collapseStd

                        For counter As Integer = 0 To root.GridItems.Count - 1

                            If root.GridItems(counter).Label =
                            CollapesCategorie Then

                                root.GridItems(counter).Expanded = False

                            End If

                        Next

                    Next
                Catch ex As Exception
                    ' lblStatus.Text = "No Public Property 'collapseStd' defined"
                End Try

            End If

            If Not IsNothing(propGridDetails.SelectedGridItem) AndAlso
                Not IsNothing(propGridDetails.SelectedGridItem.Parent) AndAlso
                Not IsNothing(propGridDetails.SelectedGridItem.Parent.Parent) Then

                root = propGridDetails.SelectedGridItem.Parent.Parent

                If Not IsNothing(root) Then

                    Try

                        For Each CollapesCategorie As String In propGridDetails.SelectedObject.collapseStd

                            For counter As Integer = 0 To root.GridItems.Count - 1

                                If root.GridItems(counter).Label =
                                CollapesCategorie Then

                                    root.GridItems(counter).Expanded = False

                                End If

                            Next

                        Next
                    Catch ex As Exception
                        'lblStatus.Text = "No Public Property 'collapseStd' defined"
                    End Try

                End If
            End If


        End If

    End Sub

    Private Sub tsmiCollapseAll_Click(sender As Object, e As EventArgs) Handles tsmiCollapseAll.Click
        Me.propGridMain.CollapseAllGridItems()
        Me.propGridDetails.CollapseAllGridItems()
    End Sub

    Private Sub tsmiExpandAll_Click(sender As Object, e As EventArgs) Handles tsmiExpandAll.Click
        Me.propGridMain.ExpandAllGridItems()
        Me.propGridDetails.ExpandAllGridItems()
    End Sub

    Private Sub tsmiRefresh_Click(sender As Object, e As EventArgs) Handles tsmiRefresh.Click
        refresh()
    End Sub

    Public Sub refresh()

        With Me.propGridMain

            refreshOngoing = True

            .Refresh()
            .RefreshTabs(tabScope:=PropertyTabScope.Component)

            refreshOngoing = False

        End With

    End Sub

    Private Sub tsmiViewOut_Click(sender As Object, e As EventArgs) Handles tsmiViewOut.Click

        Me.Width = 1500
        Me.Height = 900

        Me.SplitContainer.SplitterDistance = 300

        ' extras.moveVerticalSplitter(grid:=Me.propGridDetails, Fraction:=90)


    End Sub


#End Region

#End Region

End Class



