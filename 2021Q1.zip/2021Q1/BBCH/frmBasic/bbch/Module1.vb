﻿
Imports System.IO
Imports System.ComponentModel
Imports DBs.FOCUSGWdb
Imports essentials

Module Module1

    Sub main()

        Dim BBCHout As String()
        Dim out As String()
        Dim compartment As eGwSw = eGwSw.not_def

        Dim crop As eCropsGW = eCropsGW.notDef
        Dim searchCrop As String
        Dim bbch As Integer = -1
        Dim outList As New List(Of String)
        Dim temp As String()

        compartment = eGwSw.gw
        bbch = 45
        crop = eCropsGW.LINSEED

        BBCHout = File.ReadAllLines("C:\developer\DevID0002\2021Q1\BBCH\BBCHtotal 20191031.out")

        out =
            Filter(
            Source:=BBCHout,
            Match:=enumConverter(Of eGwSw).getEnumDescription(compartment),
            Include:=True,
            Compare:=CompareMethod.Text)

        out =
            Filter(
            Source:=out,
            Match:=bbchCropNames(crop),
            Include:=True,
            Compare:=CompareMethod.Text)

        For Each member As String In out

            temp = member.Split(vbTab)

            If member.Split(vbTab)(eBBCHMember.RequestedBBCH) = bbch Then
                outList.Add(member)
            End If

        Next


    End Sub


    Public Enum eBBCHMember
        Compartment
        Location
        Crop
        RequestedBBCH
        AllocatedBBCH
        NominalAppln
        RecommendedAppln
    End Enum

    <TypeConverter(GetType(essentials.enumConverter(Of eGwSw)))>
    Public Enum eGwSw
        ''' <summary>
        ''' Groundwater
        ''' </summary>
        <Description("Groundwater")>
        gw

        ''' <summary>
        ''' Surface water
        ''' </summary>
        <Description("Surface water")>
        sw

        <Description(essentials.enumConverter(Of Type).not_defined)>
        not_def = -1
    End Enum

    Public bbchCropNames As String() =
    {
        "pome fruit",
        "beans 1",
        "beans 2",
        "soft fruits",
        "cabbage 12",
        "carrots 12",
        "citrus",
        "cotton",
        "grass",
        "linseed",
        "maize",
        "oil seed rape, summer",
        "oil seed rape, winter",
        "onions",
        "peas",
        "potatoes",
        "soybean",
        "cereals winter",
        "strawberries",
        "sugar beet",
        "sun flower",
        "tobacco",
        "tomatoes",
        "vines",
        "cereals winter"
    }

End Module
