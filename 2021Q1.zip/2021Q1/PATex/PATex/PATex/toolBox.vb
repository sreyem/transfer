﻿
Imports System.ComponentModel
Imports System.Globalization
Imports System.Reflection


#Region "toolBox"

#Region "propGrid"

''' <summary>
''' TypeConverter(GetType(propGridConverter))
''' Make a class brows-able in the property grid
''' Name property should be defined!
''' </summary>
Public Class propGridConverter

    'usage : <TypeConverter(GetType(propGridConverter))>

    Inherits ExpandableObjectConverter

    'test

#Region "    Engine"

    <DebuggerStepThrough>
    Public Overloads Overrides Function CanConvertTo(
                                                ByVal context As ITypeDescriptorContext,
                                                ByVal destinationType As Type) As Boolean
        Try

            If (destinationType Is GetType(propGridConverter)) Then
                Return True
            End If

        Catch ex As Exception

        End Try

        Return MyBase.CanConvertTo(
                                context,
                                destinationType)

    End Function

    <DebuggerStepThrough>
    Public Overloads Overrides Function ConvertTo(
                             ByVal context As ITypeDescriptorContext,
                             ByVal culture As Globalization.CultureInfo,
                             ByVal value As Object,
                             ByVal destinationType As System.Type) As Object

        If (destinationType Is GetType(System.String)) Then

            Try

                Return CallByName(
                                value,
                                "Name",
                                CallType.Get)

            Catch ex As Exception
                Return " ... "
            End Try

        End If

        Return MyBase.ConvertTo(
                            context,
                            culture,
                            value,
                            destinationType)

    End Function

#End Region

End Class

''' <summary>
''' Show enum descriptions
''' TypeConverter(GetType(EnumConverter(of enumType))
''' </summary>
''' <typeparam name="T">
''' enum type
''' </typeparam>
Public Class enumConverter(Of T)

    'usage :  <TypeConverter(GetType(EnumConverter(of <Type>))>

    Inherits EnumConverter

    Public Const not_defined As String = " - "


    '' <summary>
    '' Initializing instance
    '' </summary>       
    '' <remarks></remarks>
    Public Sub New()
        MyBase.New(GetType(T))
    End Sub

    ''' <summary>
    ''' don't show enum members with this description
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property dontShow As String() = {}

    ''' <summary>
    ''' only show enum members with this description
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property onlyShow As String() = {}


    Public Shared no2Show As Integer = -1

#Region "    Engine"

    Public Overrides Function CanConvertTo(context As ITypeDescriptorContext, destType As Type) As Boolean
        Return destType = GetType(String)
    End Function

    Public Overrides Function ConvertTo(
                                    context As ITypeDescriptorContext,
                                    culture As CultureInfo,
                                    value As Object,
                                    destType As Type) As Object

        Dim fi As FieldInfo = GetType(T).GetField([Enum].GetName(GetType(T), value))
        Dim dna As DescriptionAttribute = DirectCast(
            Attribute.GetCustomAttribute(fi, GetType(DescriptionAttribute)), DescriptionAttribute)

        If dna IsNot Nothing Then

            If no2Show > -1 And dna.Description.Split(vbLf).Count > no2Show Then
                Return dna.Description.Split(vbLf)(no2Show).Split(vbCr).First
            Else
                Return dna.Description
            End If

        Else
            Return value.ToString()
        End If

    End Function

    Public Overrides Function CanConvertFrom(
                                            context As ITypeDescriptorContext,
                                            srcType As Type) As Boolean
        Return srcType = GetType(String)
    End Function

    Public Overrides Function ConvertFrom(
                                    context As ITypeDescriptorContext,
                                    culture As CultureInfo,
                                    value As Object) As Object

        Dim found As Boolean = False

        For Each member As String In dontShow

            If CStr(value).Contains(member) Then
                value = not_defined
            End If

        Next


        If onlyShow.Count <> 0 Then

            For Each member As String In onlyShow
                If CStr(value).Contains(member) Then
                    found = True
                    Exit For
                End If
            Next

            If Not found Then
                value = not_defined
            End If

        End If


        For Each fi As FieldInfo In GetType(T).GetFields()

            Dim dna As DescriptionAttribute =
                DirectCast(
                        Attribute.GetCustomAttribute(
                                element:=fi,
                                attributeType:=GetType(DescriptionAttribute)),
                        DescriptionAttribute)

            If (dna IsNot Nothing) AndAlso
                    (dna.Description).Contains(DirectCast(value, String)) Then
                '(DirectCast(value, String).Contains(dna.Description)) Then
                Return [Enum].Parse(GetType(T), fi.Name)
            End If

        Next

        Return [Enum].Parse(GetType(T), DirectCast(value, String))

    End Function

#End Region

    ''' <summary>
    ''' returns the enum description
    ''' </summary>
    ''' <param name="EnumConstant"></param>
    ''' <returns></returns>
    <DebuggerStepThrough>
    Public Shared Function getEnumDescription(ByVal EnumConstant As [Enum]) As String

        Dim fi As FieldInfo =
            EnumConstant.GetType().GetField(EnumConstant.ToString())

        Dim attr() As DescriptionAttribute =
                      DirectCast(fi.GetCustomAttributes(GetType(DescriptionAttribute),
                      False), DescriptionAttribute())

        If attr.Length > 0 Then
            Return attr(0).Description
        Else
            Return EnumConstant.ToString()
        End If

    End Function

End Class


''' <summary>
''' double to string converter
''' AttributeProvider(
''' format , minValue , unit , country , minSign , digits , negDef  
''' </summary>
Public Class dblConv

    Inherits DoubleConverter

    'usage : 
    '<TypeConverter(GetType(dblConvPara))>
    '<AttributeProvider("format= 'G5'|unit=' kg/ha'")>

#Region "    get/set parameters"

    Public Shared Function getDblParameter(context As ITypeDescriptorContext) As String()

        Dim Attributes As AttributeCollection
        Dim Provider As AttributeProviderAttribute

        Dim formatArray As String() = {}

        Try

            With context

                Attributes = .PropertyDescriptor.Attributes

                For Each attribute In Attributes

                    If attribute.ToString =
                        "System.ComponentModel.AttributeProviderAttribute" Then

                        Provider = attribute
                        formatArray = Provider.TypeName.Split("|")

                    End If

                Next

            End With
        Catch ex As Exception

        End Try

        For counter As Integer = 0 To formatArray.Count - 1
            formatArray(counter) = Trim(formatArray(counter))
        Next

        Return formatArray

    End Function

    Public Shared Sub setDblParameters(formatArray As String())

        Dim parameterValue As String()

        setStd()

        For Each member As String In formatArray

            parameterValue = member.Split("=")
            parameterValue(0) = Trim(parameterValue(0))
            parameterValue(1) = parameterValue(1).Split("'")(1)

            Select Case parameterValue.First

                Case "format"
                    dblformat = parameterValue.Last

                Case "country"

                    Try
                        country =
                            [Enum].Parse(
                            enumType:=GetType(eCountry),
                            value:=parameterValue.Last)
                    Catch ex As Exception
                        country = stdCountry
                    End Try

                Case "minSign"
                    minSign = parameterValue.Last

                Case "minValue"
                    minValue = parameterValue.Last

                Case "digits"
                    digits = parameterValue.Last

                Case "negDef"
                    negDef = parameterValue.Last

                Case "unit"
                    unit = parameterValue.Last

            End Select

        Next

    End Sub

    Public Shared Sub setStd()

        country = stdCountry
        dblformat = stdDblformat
        emptyString = stdEmptyString
        minSign = stdMinSign
        minValue = stdMinValue
        digits = stdDigits
        unit = ""
        negDef = stdnegDef

    End Sub

#End Region

#Region "    engine"

    <DebuggerStepThrough>
    Public Overrides Function ConvertTo(
                            context As ITypeDescriptorContext,
                            culture As CultureInfo,
                            value As Object,
                            destType As Type) As Object


        setDblParameters(formatArray:=getDblParameter(context:=context))

        Try

            Return _
              conv2String(
                    value:=value,
                    format:=dblformat,
                    country:=country,
                    minSign:=minSign,
                    minValue:=minValue,
                    unit:=unit,
                    digits:=digits,
                    negativeDefined:=negDef)

        Catch ex As Exception
            Return value
        End Try

    End Function

    <DebuggerStepThrough>
    Public Overrides Function ConvertFrom(
                            context As ITypeDescriptorContext,
                            culture As CultureInfo,
                            value As Object) As Object

        Dim valueString As String

        Try

            valueString = CType(value, String)

            If valueString.Contains(minSign) Then
                Return minValue
            ElseIf Double.IsNaN(Double.Parse(valueString)) Then
                Return Double.NaN
            Else
                Return Double.Parse(valueString)
            End If

        Catch ex As Exception
            Return Double.NaN
        End Try

    End Function

#End Region

#Region "    functions"

    Public Shared Function conv2String(
                                 value As Double,
                        Optional format As String = stdDblformat,
                        Optional country As eCountry = stdCountry,
                        Optional minValue As Double = stdMinValue,
                        Optional minSign As String = stdMinSign,
                        Optional digits As Integer = stdDigits,
                        Optional unit As String = stdUnit,
                        Optional negativeDefined As Boolean = stdnegDef) As String

        Dim countryString As String

        countryString =
                    Replace(
                    Expression:=country.ToString,
                    Find:="_", Replacement:="-",
                    Compare:=CompareMethod.Text)

        If value < 0 And Not negativeDefined Then
            Return stdEmptyString
        End If

        If Not Double.IsNaN(minValue) AndAlso value < minValue Then
            Return minSign & minValue.ToString & unit
        End If

        If Double.IsNaN(Double.Parse(value)) Then
            Return stdEmptyString
        End If

        Try

            If digits > -1 Then

                value =
                    Math.Round(
                        value,
                        digits:=digits)

            End If

            Return value.ToString(
                              format:=format,
                            provider:=CultureInfo.CreateSpecificCulture(countryString)) & unit

        Catch ex As Exception

            Console.WriteLine("error converting double to string")
            Return ex.Message

        End Try

    End Function

#End Region

#Region "    definitions"

    Public Enum eCountry
        de_DE
        en_US
        fr_FR
    End Enum

#Region "    shared"

    Public Shared country As eCountry = stdCountry
    Public Shared dblformat As String = stdDblformat
    Public Shared emptyString As String = stdEmptyString
    Public Shared minSign As String = stdMinSign
    Public Shared minValue As Double = stdMinValue
    Public Shared digits As Integer = stdDigits
    Public Shared unit As String = ""
    Public Shared negDef As Boolean = stdnegDef

#End Region

#Region "    constants"

    Public Const stdCountry As eCountry = eCountry.en_US
    Public Const stdEmptyString As String = " - "

    Public Const stdDblformat As String = "G4"
    Public Const stdMinSign As String = "<"
    Public Const stdMinValue As Double = Nothing
    Public Const stdDigits As Integer = -1
    Public Const stdUnit As String = ""
    Public Const stdnegDef As Boolean = False

#End Region

#End Region

End Class

''' <summary>
''' date to string converter
''' AttributeProvider(
''' format, julian = add/only/none, country
''' </summary>
Public Class dateConv

    Inherits DateTimeConverter


#Region "    get/set parameters"

    Public Shared Sub setStd()

        country = stdCountry
        dateFormat = stdDateFormat
        emptyString = stdEmptyString

    End Sub

    Public Shared Function getDateParameter(context As ITypeDescriptorContext) As String()

        Dim Attributes As AttributeCollection
        Dim Provider As AttributeProviderAttribute

        Dim formatArray As String() = {}

        Try

            With context

                Attributes = .PropertyDescriptor.Attributes

                For Each attribute In Attributes

                    If attribute.ToString =
                        "System.ComponentModel.AttributeProviderAttribute" Then

                        Provider = attribute
                        formatArray = Provider.TypeName.Split("|")

                    End If

                Next

            End With

        Catch ex As Exception

        End Try

        Return formatArray

    End Function

    Public Shared Sub setDateParameters(formatArray As String())

        Dim parameterValue As String()

        setStd()

        For Each member As String In formatArray

            parameterValue = member.Split("=")
            parameterValue(0) = Trim(parameterValue(0))
            parameterValue(1) = parameterValue(1).Split("'")(1)

            Select Case parameterValue.First

                Case "format"
                    dateFormat = parameterValue.Last

                Case "country"

                    Try
                        country =
                            [Enum].Parse(
                            enumType:=GetType(eCountry),
                            value:=parameterValue.Last)
                    Catch ex As Exception
                        country = stdCountry
                    End Try

                Case "julian"

                    Try

                        julian =
                            [Enum].Parse(
                            enumType:=GetType(eJulian),
                            value:=parameterValue.Last)

                    Catch ex As Exception
                        julian = stdJulian
                    End Try

            End Select

        Next

    End Sub

#End Region

#Region "    engine"


    <DebuggerStepThrough>
    Public Overrides Function ConvertTo(
                            context As ITypeDescriptorContext,
                            culture As CultureInfo,
                            value As Object,
                            destType As Type) As Object

        setDateParameters(
            formatArray:=getDateParameter(
                            context:=context))

        Try
            If CType(value, Date) = Date.MinValue OrElse
               CType(value, Date) = New Date Then

                Return emptyString

            Else

                Return _
                convDate2String(
                        value:=value,
                        format:=dateFormat,
                        julian:=julian,
                        emptyString:=emptyString,
                        country:=country)

            End If
        Catch ex As Exception
            Return emptyString
        End Try



    End Function

    <DebuggerStepThrough>
    Public Overrides Function ConvertFrom(
                            context As ITypeDescriptorContext,
                            culture As CultureInfo,
                            value As Object) As Object

        Try

            If CType(value, Date) = New Date Then
                Return New Date
            Else
                Return Date.Parse(CType(value, String))
            End If

        Catch ex As Exception
            Return New Date
        End Try

    End Function

#End Region

#Region "    functions"

    ''' <summary>
    ''' converts a date to a string
    ''' </summary>
    ''' <param name="value"></param>
    ''' <param name="format"></param>
    ''' <param name="julian"></param>
    ''' <param name="emptyString"></param>
    ''' <param name="country"></param>
    ''' <returns></returns>
    Public Shared Function convDate2String(
                                       value As Date,
                              Optional format As String = stdDateFormat,
                              Optional julian As eJulian = stdJulian,
                              Optional emptyString As String = stdEmptyString,
                              Optional country As eCountry = stdCountry) As String

        Dim countryString As String
        Dim out As String = ""

        countryString =
                    Replace(
                    Expression:=country.ToString,
                    Find:="_", Replacement:="-",
                    Compare:=CompareMethod.Text)
        Try

            If value = New Date OrElse IsNothing(value) Then
                Return emptyString
            End If

            out = value.ToString(
                                format:=format,
                                provider:=CultureInfo.CreateSpecificCulture(countryString))

            Select Case julian

                Case eJulian.none

                Case eJulian.add
                    out &= " (" & value.DayOfYear.ToString & ")"

                Case eJulian.only
                    out = value.DayOfYear.ToString()

            End Select

            Return out

        Catch ex As Exception
            Return emptyString
        End Try


    End Function

#End Region

#Region "    definitions"

    Public Enum eCountry
        de_DE
        en_US
        fr_FR
    End Enum

    Public Enum eJulian
        add
        only
        none
    End Enum

#Region "    shared"

    Public Shared country As eCountry = stdCountry
    Public Shared emptyString As String = stdEmptyString

    Public Shared julian As eCountry = stdJulian
    Public Shared dateFormat As String = stdDateFormat

#End Region

#Region "    constants"

    Public Const stdCountry As eCountry = eCountry.en_US
    Public Const stdEmptyString As String = " - "

    Public Const stdDateFormat As String = "dd. MMM"
    Public Const stdJulian As eJulian = eJulian.add

#End Region

#End Region


End Class

#End Region


#End Region


