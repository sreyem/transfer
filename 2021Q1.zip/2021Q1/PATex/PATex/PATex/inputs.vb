﻿

Imports System.ComponentModel
Imports System.Xml.Serialization
Imports System.Web.Script.Serialization
Imports System.IO.Compression
Imports System.IO
Imports PECmanDrift
Imports PECmanDrift.inputs

<TypeConverter(GetType(propGridConverter))>
<Serializable>
Public Class PATex


    Public Sub New()

        Me.precipitationCSV =
           File.ReadAllLines(
           path:="C:\developer\DevID0002\2021Q1\PATex\PATex\PATex\bin\Debug\prec.csv")

        'Dim pattest As New PATCalc.CPATCalculation

    End Sub

    <Browsable(False)>
    Public Property PATrun As New PATrun



    Public Property doit As Boolean
        Get
            Return True
        End Get
        Set(value As Boolean)
            If value Then Exit Property
            inputs_getPATresults()
        End Set
    End Property


    Public Property app As appln() = {}

    <RefreshProperties(RefreshProperties.All)>
    Public WithEvents inputs As New inputs

    Private Sub inputs_getPATresults() 'Handles inputs.getPATresults

        With inputs

            If .noOfApplns = eNoOfApplns.not_defined OrElse
              (.noOfApplns <> eNoOfApplns.one And .applnInterval = eApplnInterval.not_defined) OrElse
               .PATEnd = New Date Then

                Exit Sub

            End If


            Dim irrday As Integer(,) = {}

            irrday = getMACRO554PatApplnDays(
                fname:=Path.Combine(
                    path1:="C:\VS2020\MACROResources\ExeParFile554",
                    path2:= .precipitationFile),
                num_apps:= .noOfApplns + 1,
                interval:= .applnInterval, .PATStart.DayOfYear, .PATEnd.DayOfYear)

            Dim out As New List(Of String)
            Dim temp As String = ""

            Dim app As New List(Of appln)

            For yearCounter As Integer = 1 To irrday.GetUpperBound(0)

                For applnCounter As Integer = 0 To irrday.GetUpperBound(1)

                    If applnCounter = 0 Then
                        temp = (irrday(yearCounter, applnCounter)) & " "
                    Else
                        temp &= New Date(year:=irrday(yearCounter, 0), 1, 1).AddDays(irrday(yearCounter, applnCounter) - 1).ToShortDateString & " "
                        temp &= (irrday(yearCounter, applnCounter)) & " "

                        app.Add(New appln)

                        With app(app.Count - 1)

                            .applnDate =
                                New Date(
                                year:=irrday(yearCounter, 0), 1, 1).AddDays(irrday(yearCounter, applnCounter) - 1)

                        End With



                    End If

                Next

                out.Add(temp)
                temp = ""

            Next

            Me.app = app.ToArray

            .applns.applns = app.ToArray

            Me.temp = out.ToArray

        End With


        Dim PATrepairMasterPath As String = "C:\developer\DevID0002\2021Q1\PATex\PATex\pat"

        'Dim transferfile As New System.IO.FileInfo(
        '                    fileName:=Path.Combine(
        '                            path1:=PATrepairMasterPath,
        '                            path2:="inputpat.txt"))

        'Dim PATexe As New PATExe.CPATExe(
        '    transferFile:=transferfile,
        '    rulesFile:=New System.IO.FileInfo(
        '                    fileName:=Path.Combine(
        '                        path1:=PATrepairMasterPath,
        '                        path2:="rules.txt")))

        'With PATexe

        '    .RunPAT()
        '    .LogPATRuns(filename:=Path.Combine(
        '                        path1:=PATrepairMasterPath,
        '                        path2:="pat.txt"))


        'End With

        With inputs

            PATrun.ID = 1
            PATrun.NoOfApplns = .noOfApplns + 1

            If .noOfApplns = eNoOfApplns.one Then
                PATrun.AppInterval(0) = 1
            Else

                For counter As Integer = 0 To .noOfApplns - 1
                    PATrun.AppInterval(counter) = .applnInterval
                Next

            End If

            PATrun.PATStartDate = New Date(year:= .FOCUSSeasonStartDate.Year, month:= .PATStart.Month, day:= .PATStart.Day)
            PATrun.PATEndDate = PATrun.PATStartDate.AddDays((.PATEnd - .PATStart).TotalDays)
            PATrun.Scenario = .FOCUSswScenario.ToString
            PATrun.Season = "1st"

        End With

        With PATrun

            .ClimateFile = New FileInfo("test.txt")
            .Rainfall = Me.RAIN
            .RainfallDates.Add(Me.startDate)

            For counter As Integer = 1 To .Rainfall.Count - 1

                .RainfallDates.Add(.RainfallDates(counter - 1).AddDays(1))

            Next



        End With

        Dim PATCalc As New PATCalc.CPATCalculation(PATRun:=PATrun,
                                                   PATRule:=New PATCommon.CPATRule)


        PATCalc.SetAppDays()

        Dim log As New List(Of String)


        log.Add(PATrun.SettingsToLog)
        log.Add(PATCalc.Log)

        File.WriteAllLines(
            path:=Path.Combine(Environment.CurrentDirectory, "PATrepair.log"),
            contents:=log.ToArray)

        File.WriteAllLines(
           path:=Path.Combine(Environment.CurrentDirectory, "PAT553.log"),
           contents:=temp)


        File.WriteAllLines(
           path:=Path.Combine(Environment.CurrentDirectory, "PATdetail.log"),
           contents:=Me.temp)

    End Sub



    <RefreshProperties(RefreshProperties.All)>
    Public Property temp As String() = {}

    Public Property log As String()

    Public Property RAIN As Single()

    Public Property startDate As Date

    ''' <summary>
    ''' Find the appln days according to (old) PAT
    ''' </summary>
    ''' <param name="fname">
    ''' name of the weather file, *.bin
    ''' </param>
    ''' <param name="num_apps">
    ''' # of applns, 1 - 8
    ''' </param>
    ''' <param name="interval">
    ''' interval between applns
    ''' </param>
    ''' <param name="fd">
    ''' first possible appln. day as julian day 1 - 365
    ''' </param>
    ''' <param name="ld">
    ''' last possible appln. day as julian day 1 - 365
    ''' </param>
    ''' <remarks></remarks>
    Public Function getMACRO554PatApplnDays(
                                       fname As String,
                                       num_apps As Integer,
                                       interval As Integer,
                                       fd As Integer, ld As Integer,
                                       Optional MaxOutput As Boolean = False
                                       ) As Integer(,)

#Region "Definitions"

        Dim yea As Integer
        Dim je As Integer
        Dim jd As Integer
        Dim jc As Integer
        Dim jb As Integer
        Dim jalpha As Integer
        Dim ja As Integer
        Dim ho As Integer
        Dim mi As Integer
        Dim m As Integer
        Dim l As Integer
        Dim total_rain As Single
        Dim condition As Integer
        Dim current_day As Integer
        Dim ki As Integer
        Dim da As Integer
        Dim mon As Integer
        Dim k As Integer
        Dim j As Integer


        Dim rec_l As Integer
        Dim rec_ant As Integer
        Dim var_ant As Integer
        Dim start As Long
        Dim jul As Integer
        Dim rra As Single
        Dim addto As Short

        Dim Years As New List(Of Integer)

        'Dim RAIN As Single()
        ReDim RAIN(10000)

        Dim acc_days As Integer()
        ReDim acc_days(100)

        Dim days_around_app As Integer = 2
        Dim max_rain As Single = 2
        Dim min_rain As Single = 10
        Dim days_after_app As Integer = 10
        Dim irrday As Integer(,) = {}
        ReDim irrday(200, 200)


        Dim first_day As Integer
        Dim last_day As Integer
        Dim MaxYears As Integer

        Dim TempDateOut As String = ""
        Dim DateTemp As New Date
        Dim TempJulOut As String = ""
        Dim TempRainOut As String = ""
        Dim RainArroundAppln As Boolean = False

        Dim PATlog As New List(Of String)

#End Region

        If num_apps = 1 Then interval = 1

        PATlog.Clear()

        If precipitationCSV.Count > 0 Then

            Dim searchArray As String()
            Dim index As Integer = -1


            j = 1
            k = 1

            searchArray = precipitationCSV.First.Split(",")
            For counter As Integer = 0 To searchArray.Count - 1
                searchArray(counter) = searchArray(counter).ToLower
            Next

            index =
                Array.FindIndex(
                array:=searchArray,
                match:=Function(x) _
                           x = Path.GetFileNameWithoutExtension(fname).ToLower)

            If index = -1 Then
                Me.log = PATlog.ToArray
                Return irrday
            End If

            startDate = New Date(
                year:=precipitationCSV(1).Split(",")(index),
                month:=1,
                day:=1)

            For rowCounter As Integer = 2 To precipitationCSV.Count - 1
                RAIN(rowCounter - 1) = precipitationCSV(rowCounter).Split(",")(index)

                j += 1

                With startDate.AddDays(rowCounter - 2)
                    If .Month = 12 AndAlso .Day = 31 Then

                        Years.Add(.Year)
                        acc_days(k) = j - 1
                        k += 1

                    End If
                End With

            Next

            ReDim Preserve RAIN(precipitationCSV.Count - 1 - 2)

        Else

            Try

                PATlog.Add("Open " & fname)
                FileOpen(1, fname, OpenMode.Binary)

                FileGet(1, rec_ant, 1)
                FileGet(1, rec_l)

                var_ant = CInt(rec_l / 4 - 1)
                start = rec_l + 1

                j = 1
                k = 1

                PATlog(PATlog.Count - 1) = PATlog(PATlog.Count - 1) & " ... OK"

            Catch ex As Exception

            End Try

            'read *.bin file to array
            Do

                Try

                    Seek(1, start)

                    FileGet(1, jul) '=julian date
                    mi = jul Mod (60 * 24)
                    ho = CInt(mi / 60)
                    mi = mi - ho * 60
                    jul = CInt((jul - mi - ho * 60) / 60 / 24 + 1721424)
                    ja = jul

                    If jul >= 2299161 Then
                        jalpha = CInt(Int(((jul - 1867216) - 0.25) / 36524.25))
                        ja = CInt(jul + 1 + jalpha - Int(jalpha * 0.25))
                    End If

                    jb = ja + 1524
                    jc = CInt(Int(6680.0# + ((jb - 2439870) - 122.1) / 365.25))
                    jd = CInt(365 * jc + Int(0.25 * jc))
                    je = CInt(Int((jb - jd) / 30.6001))
                    da = CInt(jb - jd - Int(30.6001 * je))
                    mon = je - 1
                    If mon > 12 Then mon = mon - 12
                    yea = jc - 4715


                    If mon > 2 Then yea = yea - 1
                    If yea <= 0 Then yea = yea - 1

                    FileGet(1, rra)
                    RAIN(j) = rra
                    start = start + rec_l


                    If j = 1 Then
                        startDate =
                        New Date(
                            year:=yea,
                            month:=mon,
                            day:=da)
                    End If

                    j = j + 1

                    'If k = 8 And mon = 4 And da = 30 Then
                    '    GoTo 5
                    'End If

                    If da = 31 And mon = 12 Then
                        Years.Add(yea)
                        acc_days(k) = j - 1
                        k = k + 1
                    End If

                Catch ex As Exception
                    FileClose(1)
                    Exit Do
                End Try

            Loop

        End If

        MaxYears = Years.Count
        PATlog.Add(MaxYears & " years of weather data")

        ReDim irrday(MaxYears, num_apps)
        For YearCounter As Integer = 1 To Years.Count
            irrday(YearCounter, 0) = Years(YearCounter - 1)
        Next

        PATlog(PATlog.Count - 1) = PATlog(PATlog.Count - 1) &
            ", " & Years.First & " - " & Years.Last

        For ki = 1 To MaxYears

            days_after_app = 10
            min_rain = 10
            max_rain = 2
            days_around_app = 2

            If ki > 1 Then
                first_day = fd + acc_days(ki - 1)
            Else
                first_day = fd
                If first_day < 3 Then
                    first_day = 3
                    addto = 2
                Else
                    first_day = fd
                    addto = 0
                End If

            End If

            If ki > 1 Then
                last_day = ld + acc_days(ki - 1)
            Else
                last_day = ld + addto
            End If

            If last_day < first_day Then
                last_day = last_day + 365
            End If

#Region " Log"


            PATlog.Add("")
            PATlog.Add("Year " & ki & " , " & Years(ki - 1).ToString)
            PATlog.Add("days_after_app  " & days_after_app)
            PATlog.Add("min_rain        " & min_rain)
            PATlog.Add("max_rain        " & max_rain)
            PATlog.Add("days_around_app " & days_around_app)
            PATlog.Add("first_day       " & first_day & " (" & fd & ", " &
                                                New Date(year:=Years.First,
                                                         month:=1,
                                            day:=1).AddDays(first_day - 1).ToString("dd-MMM-yy ") & ")")

            PATlog.Add("last_day        " & last_day & " (" & ld & ", " &
                                                New Date(year:=Years.First,
                                                         month:=1,
                                            day:=1).AddDays(last_day - 1).ToString("dd-MMM-yy ") & ")")

#End Region

            For j = 1 To num_apps
2:
                If j = 1 Then
                    current_day = first_day
                Else
                    If ki = 1 Then
                        current_day = irrday(ki, j - 1) + interval
                    Else
                        current_day = irrday(ki, j - 1) + interval + acc_days(ki - 1)
                    End If

                End If

                condition = 1
                PATlog.Add("")

                Do While current_day <= last_day - ((num_apps - j) * interval)

                    PATlog(PATlog.Count - 1) =
                        PATlog(PATlog.Count - 1) & "Test day " & current_day & " , " & New Date(year:=Years.First,
                                            month:=1,
                                            day:=1).AddDays(current_day - 1).ToString("dd-MMM-yy ")

                    total_rain = 0

                    TempDateOut = ""
                    TempJulOut = ""
                    TempRainOut = ""

                    For l = 1 To days_after_app

                        total_rain = total_rain + RAIN(current_day + l)

                        TempDateOut &= New Date(year:=Years.First,
                                            month:=1,
                                            day:=1).AddDays(current_day + l - 1).ToString("dd-MMM-yy ")
                        TempJulOut &= (current_day + l).ToString.PadRight("dd-MMM-yy ".Length)
                        TempRainOut &= RAIN(current_day + l).ToString("G2").PadRight("dd-MMM-yy ".Length)

                    Next l

                    PATlog.Add(TempDateOut)
                    PATlog.Add(TempJulOut)
                    PATlog.Add(TempRainOut)

                    If total_rain < min_rain Then
                        condition = 0
                        PATlog.Add(total_rain.ToString("G2") & "mm < " & min_rain & "mm, rule failed")
                    Else
                        PATlog.Add(total_rain.ToString("G2") & "mm > " & min_rain & "mm, rule passed")
                    End If

                    TempDateOut = ""
                    TempJulOut = ""
                    TempRainOut = ""

                    PATlog.Add("Rain " & days_around_app & " days around appln")

                    RainArroundAppln = True
                    For m = -days_around_app To days_around_app

                        TempDateOut &= New Date(year:=Years.First,
                                            month:=1,
                                            day:=1).AddDays(current_day + m - 1).ToString("dd-MMM-yy ")
                        TempJulOut &= (current_day + m).ToString.PadRight("dd-MMM-yy ".Length)
                        TempRainOut &= RAIN(current_day + m).ToString.PadRight("dd-MMM-yy ".Length)


                        If RAIN(current_day + m) > max_rain Then

                            condition = 0
                            RainArroundAppln = False

                        End If

                    Next m

                    PATlog.Add(TempDateOut)
                    PATlog.Add(TempJulOut)
                    PATlog.Add(TempRainOut)

                    If RainArroundAppln Then
                        PATlog(PATlog.Count - 1) = PATlog(PATlog.Count - 1) & " passed"
                    Else
                        PATlog(PATlog.Count - 1) = PATlog(PATlog.Count - 1) & " failed"
                    End If

                    If condition = 1 Then

                        If ki = 1 Then
                            irrday(ki, j) = current_day
                        Else

                            irrday(ki, j) = current_day - acc_days(ki - 1)


                            If irrday(ki, j) > acc_days(ki) - acc_days(ki - 1) AndAlso acc_days(ki) <> 0 Then
                                irrday(ki, j) = irrday(ki, j) - acc_days(ki) + acc_days(ki - 1)
                            End If

                        End If

                        PATlog.Add(" *** Possible solution found for appln no " & j.ToString("00") & " year " & ki.ToString("00"))
                        PATlog.Add(" *** " & New Date(year:=Years.First,
                                            month:=1,
                                            day:=1).AddDays(current_day - 1).ToString("dd-MMM-yy ") & ", day no " &
                        (current_day).ToString & "(" & New Date(year:=Years.First,
                                            month:=1,
                                            day:=1).AddDays(current_day - 1).DayOfYear.ToString & ") , day no " &
                        (current_day).ToString & ", rain " &
                        RAIN(current_day).ToString & " mm")

                        PATlog.Add(TempDateOut)
                        PATlog.Add(TempJulOut)
                        PATlog.Add(TempRainOut)

                        If j = num_apps And ki = MaxYears Then
                            Me.log = PATlog.ToArray
                            Return irrday
                        Else
                            If j <> num_apps Then PATlog.Add("Next appln")
                            current_day = current_day + interval
                            days_after_app = 10
                            min_rain = 10
                            max_rain = 2
                            days_around_app = 2
                            GoTo 1
                        End If

                    Else
                        PATlog.Add("Try next day")
                        current_day = current_day + 1
                        condition = 1
                    End If

                Loop

                If min_rain = 0 And days_around_app = 0 Then
                    max_rain = max_rain + 1
                End If

                days_around_app = days_around_app - 1

                If days_around_app = -1 Then
                    days_around_app = 0
                    days_after_app = days_after_app + 5
                    If current_day + days_after_app > last_day + 10 Then
                        days_after_app = days_after_app - 5
                        min_rain = 0
                    End If
                End If

                GoTo 2
1:
            Next j

        Next ki

        Me.log = PATlog.ToArray

        Return irrday

    End Function


    Public Property precipitationCSV As String() = {}

End Class




<TypeConverter(GetType(propGridConverter))>
<Serializable>
Public Class PATrun

    Inherits PATCommon.CPATRun

End Class

'<TypeConverter(GetType(propGridConverter))>
'<Serializable>
'<DefaultProperty("FOCUSDriftCrop")>
'Public Class inputs2

'    Public Sub New()

'    End Sub

'    ''' <summary>
'    ''' if true, descriptions will be in the enum, else shown in separate properties
'    ''' </summary>
'    Private Const seeAll As Boolean = True

'    Private Const offset As String = "    "


'    Public Const CATFOCUSSettings As String = "01  Crop  & Scenario"

'#Region "Crop, scenario, precipitation file"

'    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
'    Private _FOCUSswDriftCrop As eFOCUSswDriftCrop = eFOCUSswDriftCrop.not_defined

'    ''' <summary>
'    ''' Target crop out of the
'    ''' available FOCUS crops
'    ''' </summary>
'    <Category(CATFOCUSSettings)>
'    <DisplayName(
'    "Crop")>
'    <Description(
'    "FOCUS crop for drift" & vbCrLf &
'    "triggers Ganzelmeier crop group")>
'    <RefreshProperties(RefreshProperties.All)>
'    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
'    <Browsable(True)>
'    <[ReadOnly](False)>
'    <DefaultValue(CInt(eFOCUSswDriftCrop.not_defined))>
'    Public Property FOCUSswDriftCrop As eFOCUSswDriftCrop
'        Get

'            enumConverter(Of eFOCUSswDriftCrop).no2Show =
'                IIf(Expression:=seeAll, TruePart:=-1, 1)

'            Return _FOCUSswDriftCrop

'        End Get
'        Set

'            _FOCUSswDriftCrop = Value

'            If _FOCUSswDriftCrop = eFOCUSswDriftCrop.not_defined Then Exit Property

'            'set Ganzelmeier crop group
'            Ganzelmeier = convertFOCUSCrop2Ganzelmeier(_FOCUSswDriftCrop)

'            definedScenarios =
'                enumConverter(Of eFOCUSswDriftCrop).getEnumDescription(
'                    EnumConstant:=_FOCUSswDriftCrop).Split(vbLf).Last

'            If Not definedScenarios.Contains(_FOCUSswScenario.ToString) Then
'                _FOCUSswScenario = eFOCUSswScenario.not_defined
'            End If

'            precipitationFile = getPrecipitationFileName(
'                FOCUSswDriftCrop:=_FOCUSswDriftCrop,
'                FOCUSswScenario:=_FOCUSswScenario).Split(",").Last

'        End Set
'    End Property

'    ''' <summary>
'    ''' Defined FOCUSsw scenarios
'    ''' based on selected FOCUS crop
'    ''' </summary>
'    <Category(CATFOCUSSettings)>
'    <DisplayName(
'    offset & "def. Scenarios")>
'    <Description(
'    "Defined FOCUSsw scenarios" & vbCrLf &
'    "based on selected FOCUS crop")>
'    <RefreshProperties(RefreshProperties.All)>
'    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
'    <Browsable(Not seeAll)>
'    <[ReadOnly](True)>
'    <XmlIgnore> <ScriptIgnore>
'    <DefaultValue("")>
'    Public Property definedScenarios As String = ""

'    ''' <summary>
'    ''' Ganzelmeier crop group
'    ''' based on selected FOCUS crop
'    ''' </summary>
'    <Category(CATFOCUSSettings)>
'    <DisplayName(
'    offset & "Ganzelmeier")>
'    <Description(
'    "Ganzelmeier crop group" & vbCrLf &
'    "based on selected FOCUS crop")>
'    <RefreshProperties(RefreshProperties.All)>
'    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
'    <Browsable(True)>
'    <[ReadOnly](True)>
'    <XmlIgnore> <ScriptIgnore>
'    <DefaultValue(CInt(eGanzelmeier.not_defined))>
'    Public Property Ganzelmeier As eGanzelmeier = eGanzelmeier.not_defined


'    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
'    Private _FOCUSswScenario As eFOCUSswScenario = eFOCUSswScenario.not_defined

'    ''' <summary>
'    ''' FOCUSSsw Scenario
'    ''' if defined for this crop
'    ''' </summary>
'    <Category(CATFOCUSSettings)>
'    <DisplayName(
'    "Scenario")>
'    <Description(
'    "FOCUSsw scenario D1-D6, R1-R4" & vbCrLf &
'    "if defined for this crop!")>
'    <RefreshProperties(RefreshProperties.All)>
'    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
'    <Browsable(True)>
'    <[ReadOnly](False)>
'    <DefaultValue(CInt(eFOCUSswScenario.not_defined))>
'    Public Property FOCUSswScenario As eFOCUSswScenario
'        Get

'            If _FOCUSswDriftCrop <> eFOCUSswDriftCrop.not_defined Then

'                enumConverter(Of eFOCUSswScenario).onlyShow =
'                definedScenarios.Split("|")

'                enumConverter(Of eFOCUSswScenario).no2Show =
'                IIf(Expression:=seeAll, TruePart:=-1, 0)

'            End If

'            Return _FOCUSswScenario

'        End Get
'        Set

'            If Not definedScenarios.Split("|").Contains(Value.ToString) Then
'                Exit Property
'            End If

'            _FOCUSswScenario = Value

'            plainScenarioName =
'                enumConverter(Of eFOCUSswScenario).getEnumDescription(
'            EnumConstant:=_FOCUSswScenario).Split(vbLf)(1)

'            precipitationFile = getPrecipitationFileName(
'                FOCUSswDriftCrop:=_FOCUSswDriftCrop,
'                FOCUSswScenario:=_FOCUSswScenario).Split(",").Last

'        End Set
'    End Property

'    <Category(CATFOCUSSettings)>
'    <DisplayName(
'    offset & "Name")>
'    <Description(
'    "Location name of the scenario" & vbCrLf &
'    "")>
'    <RefreshProperties(RefreshProperties.All)>
'    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
'    <Browsable(Not seeAll)>
'    <[ReadOnly](True)>
'    <XmlIgnore> <ScriptIgnore>
'    <DefaultValue("")>
'    Public Property plainScenarioName As String = ""

'    <Category(CATFOCUSSettings)>
'    <DisplayName(
'    offset & "Precipitation")>
'    <Description(
'    "*_P.BIN file" & vbCrLf &
'    "")>
'    <RefreshProperties(RefreshProperties.All)>
'    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
'    <Browsable(True)>
'    <[ReadOnly](True)>
'    <XmlIgnore> <ScriptIgnore>
'    <DefaultValue("")>
'    Public Property precipitationFile As String = ""

'#End Region

'    Public Const CATPAT As String = "02  PAT"

'#Region "PAT"

'    <DebuggerBrowsable(DebuggerBrowsableState.Never)>
'    Private _noOfApplns As eNoOfApplns = eNoOfApplns.not_defined

'    ''' <summary>
'    ''' Number of applications
'    ''' 1 - 8
'    ''' </summary>
'    <Category(CATPAT)>
'    <DisplayName(
'    "Appln. Number")>
'    <Description(
'    "Number of applications" & vbCrLf &
'    "1 - 8 (or more)")>
'    <RefreshProperties(RefreshProperties.All)>
'    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
'    <Browsable(True)>
'    <[ReadOnly](False)>
'    <DefaultValue(CInt(eNoOfApplns.not_defined))>
'    Public Property noOfApplns As eNoOfApplns
'        Get
'            Return _noOfApplns
'        End Get
'        Set
'            _noOfApplns = Value
'        End Set
'    End Property


'    Private _applnInterval As Integer = 0


'    <Category(CATPAT)>
'    Public Property applnInterval As Integer
'        Get
'            Return _applnInterval
'        End Get
'        Set(value As Integer)

'            If _noOfApplns = eNoOfApplns.one OrElse
'                    _noOfApplns = eNoOfApplns.not_defined Then
'                Exit Property
'            End If



'        End Set
'    End Property


'    <Category(CATPAT)>
'    <DisplayName(
'    "PAT Start")>
'    <Description(
'    "PAT start date" & vbCrLf &
'    "")>
'    <RefreshProperties(RefreshProperties.All)>
'    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
'    <Browsable(True)>
'    <[ReadOnly](False)>
'    <TypeConverter(GetType(dateConv))>
'    <AttributeProvider(" format = 'dd. MMM'| julian ='add' ")>
'    Public Property startDate As New Date

'    <Category(CATPAT)>
'    <DisplayName(
'    "    Windows")>
'    <Description(
'    "" & vbCrLf &
'    "")>
'    <RefreshProperties(RefreshProperties.All)>
'    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
'    <Browsable(True)>
'    <[ReadOnly](False)>
'    Public Property interval As Integer


'    Private _endDate As New Date

'    <Category(CATPAT)>
'    <DisplayName(
'    "    End")>
'    <Description(
'    "PAT end date" & vbCrLf &
'    "")>
'    <RefreshProperties(RefreshProperties.All)>
'    <DebuggerBrowsable(DebuggerBrowsableState.Collapsed)>
'    <Browsable(True)>
'    <[ReadOnly](False)>
'    <TypeConverter(GetType(dateConv))>
'    <AttributeProvider(" format = 'dd. MMM'| julian ='add' ")>
'    Public Property endDate As Date
'        Get
'            Return _endDate
'        End Get
'        Set(value As Date)
'            _endDate = value
'        End Set
'    End Property


'    <RefreshProperties(RefreshProperties.All)>
'    <Description()>
'    <DisplayName("")>
'    <Category(CATPAT)>
'    Public ReadOnly Property Window As String
'        Get

'            If noOfApplns <> eNoOfApplns.not_defined Then
'                Return (endDate - startDate).Days.ToString & " days       " & vbCrLf &
'                        "min = 30 + ((NoOfApplns - 1) * Interval)" & vbCrLf &
'                        "min = 30 + ((" &
'                        CInt(noOfApplns).ToString.PadLeft("NoOfApplns -1 ".Length) & ") * " &
'                        CInt(interval).ToString.PadLeft("".Length) & ") days" & vbCrLf &
'                        "min = " & 30 + (noOfApplns * interval) & " days"
'            Else
'                Return "min 30 days, def. # of appls and interval"
'            End If

'        End Get
'    End Property


'    Public Property irrg As String() = {}

'#End Region



'#Region "enums"


'    ''' <summary>
'    ''' FOCUSsw DRIFT crops as enumeration
'    ''' </summary>
'    <TypeConverter(GetType(enumConverter(Of eFOCUSswDriftCrop)))>
'    Public Enum eFOCUSswDriftCrop

'        <Description(
'            "CS " & vbCrLf &
'            "Cereals, spring " & vbCrLf &
'            "D1|D3|D4|D5|R4")>
'        CS_Cereals_spring = 0

'        <Description(
'            "CW " & vbCrLf &
'            "Cereals, winter " & vbCrLf &
'            "D1|D2|D3|D4|D5|D6|R1|R3|R4")>
'        CW_Cereals_winter

'        '-------------------------------------------------------------

'        <Description(
'            "CI " & vbCrLf &
'            "Citrus " & vbCrLf &
'            "D6|R4")>
'        CI_Citrus

'        <Description(
'            "CO " & vbCrLf &
'            "Cotton " & vbCrLf &
'            "D6")>
'        CO_Cotton

'        '-------------------------------------------------------------

'        <Description(
'            "FB " & vbCrLf &
'            "Field beans 1st/2nd " & vbCrLf &
'            "D2|D3|D4|D6|R1|R2|R3|R4")>
'        FB_Field_beans

'        <Description(
'            "GA " & vbCrLf &
'            "Grass/alfalfa " & vbCrLf &
'            "D1|D2|D3|D4|D5|R2|R3")>
'        GA_Grass_alfalfa

'        '-------------------------------------------------------------

'        <Description(
'            "HP " & vbCrLf &
'            "Hops " & vbCrLf &
'            "R1")>
'        HP_Hops

'        '-------------------------------------------------------------

'        <Description(
'            "LG " & vbCrLf &
'            "Legumes " & vbCrLf &
'            "D3|D4|D5|D6|R1|R2|R3|R4")>
'        LG_Legumes

'        <Description(
'            "MZ " & vbCrLf &
'            "Maize " & vbCrLf &
'            "D3|D4|D5|D6|R1|R2|R3|R4")>
'        MZ_Maize

'        '-------------------------------------------------------------

'        <Description(
'            "OS " & vbCrLf &
'            "Oil seed rape, spring " & vbCrLf &
'            "D1|D3|D4|D5|R1")>
'        OS_Oil_seed_rape_spring

'        <Description(
'            "OW " & vbCrLf &
'            "Oil seed rape, winter " & vbCrLf &
'            "D2|D3|D4|D5|R1|R3")>
'        OW_Oil_seed_rape_winter

'        '-------------------------------------------------------------

'        <Description(
'            "OL " & vbCrLf &
'            "Olives " & vbCrLf &
'            "D6|R4")>
'        OL_Olives


'        <Description(
'            "PF " & vbCrLf &
'            "Pome/stone fruits, early " & vbCrLf &
'            "D3|D4|D5|R1|R2|R3|R4")>
'        PFE_Pome_stone_fruit_early_applns

'        <Description(
'            "PF " & vbCrLf &
'            "Pome/stone fruits, late " & vbCrLf &
'            "D3|D4|D5|R1|R2|R3|R4")>
'        PFL_Pome_stone_fruit_late_applns

'        '-------------------------------------------------------------

'        <Description(
'            "PS " & vbCrLf &
'            "Potatoes, 1st/2nd " & vbCrLf &
'            "D3|D4|D6|R1|R2|R3")>
'        PS_Potatoes

'        <Description(
'            "SY " & vbCrLf &
'            "Soybeans " & vbCrLf &
'            "R3|R4")>
'        SY_Soybeans

'        <Description(
'            "SB " & vbCrLf &
'            "Sugar beets " & vbCrLf &
'            "D3|D4|R1|R3")>
'        SB_Sugar_beets

'        <Description(
'            "SU " & vbCrLf &
'            "Sunflowers " & vbCrLf &
'            "D5|R1|R3|R4")>
'        SU_Sunflowers

'        '-------------------------------------------------------------

'        <Description(
'            "TB " & vbCrLf &
'            "Tobacco " & vbCrLf &
'            "R3")>
'        TB_Tobacco

'        '-------------------------------------------------------------

'        <Description(
'            "VB " & vbCrLf &
'            "Vegetables, bulb, 1st/2nd " & vbCrLf &
'            "D3|D4|D6|R1|R2|R3|R4")>
'        VB_Vegetables_bulb

'        <Description(
'            "VF " & vbCrLf &
'            "Vegetables, fruiting " & vbCrLf &
'            "D6|R2|R3|R4")>
'        VF_Vegetables_fruiting

'        <Description(
'            "VL " & vbCrLf &
'            "Vegetables, leafy, 1st/2nd " & vbCrLf &
'            "D3|D4|D6|R1|R2|R3|R4")>
'        VL_Vegetables_leafy

'        <Description(
'            "VR " & vbCrLf &
'            "Vegetables, root, 1st/2nd " & vbCrLf &
'            "D3|D6|R1|R2|R3|R4")>
'        VR_Vegetables_root

'        '-------------------------------------------------------------

'        <Description(
'            "VI " & vbCrLf &
'            "Vines, early " & vbCrLf &
'            "D6|R1|R2|R3|R4")>
'        VIE_Vines_early_applns

'        <Description(
'            "VI " & vbCrLf &
'            "Vines, late " & vbCrLf &
'            "D6|R1|R2|R3|R4")>
'        VIL_Vines_late_applns

'        '-------------------------------------------------------------

'        <Description(
'            "AA " & vbCrLf &
'            "Aerial appln.")>
'        AA_Aerial


'        <Description(
'            "HL " & vbCrLf &
'            " Appln, hand " & vbCrLf &
'            "(crop < 50 cm)")>
'        HL_HandAppLow

'        <Description(
'            "HH " & vbCrLf &
'            " Appln, hand " & vbCrLf &
'            "(crop > 50 cm)")>
'        HH_HandAppHigh


'        <Description(
'            "ND " & vbCrLf &
'            " No drift " & vbCrLf &
'            "(incorp or seed trtmt)")>
'        ND_NoDrift


'        <Description(enumConverter(Of Type).not_defined)>
'        not_defined = -1

'    End Enum


'    ''' <summary>
'    ''' Ganzelmeier crop groups
'    ''' </summary>
'    <TypeConverter(GetType(enumConverter(Of eGanzelmeier)))>
'    Public Enum eGanzelmeier

'        <Description(
'            "Arable crops " & vbCrLf &
'            "1.9274 %")>
'        ArableCrops = 0

'        <Description(
'            "Fruit crops, early " & vbCrLf &
'            "23.599 %")>
'        FruitCrops_Early

'        <Description(
'            "Fruit crops, late " & vbCrLf &
'            "11.134 %")>
'        FruitCrops_Late

'        <Description(
'            "Hops " & vbCrLf &
'            "14.554 %")>
'        Hops

'        <Description(
'            "Vines, early " & vbCrLf &
'            "1.7184 %")>
'        Vines_Early

'        <Description(
'            "Vines, late " & vbCrLf &
'            "5.173 %")>
'        Vines_Late

'        <Description(
'            "Aerial appln " & vbCrLf &
'            "25.476 %")>
'        AerialAppln

'        <Description("no drift " & vbCrLf &
'            "0 % ;-)")>
'        noDrift

'        <Description(" - ")>
'        not_defined

'    End Enum


'    ''' <summary>
'    ''' all FOCUSsw scenarios D1-6 and R1-4
'    ''' </summary>
'    <TypeConverter(GetType(enumConverter(Of eFOCUSswScenario)))>
'    Public Enum eFOCUSswScenario

'        <Description(
'            "D1 " & vbCrLf &
'            "Lanna " & vbCrLf &
'            "ditch|stream")>
'        D1 = 0

'        <Description(
'            "D2 " & vbCrLf &
'            "Brimstone " & vbCrLf &
'            "ditch|stream")>
'        D2

'        <Description(
'            "D3 " & vbCrLf &
'            "Vredepeel " & vbCrLf &
'            "ditch")>
'        D3

'        <Description(
'            "D4 " & vbCrLf &
'            "Skousbo " & vbCrLf &
'            "pond|stream")>
'        D4

'        <Description(
'            "D5 " & vbCrLf &
'            "La Jailliere " & vbCrLf &
'            "pond|stream")>
'        D5

'        <Description(
'            "D6 " & vbCrLf &
'            "Thiva " & vbCrLf &
'            "ditch")>
'        D6

'        <Description(
'            "R1 " & vbCrLf &
'            "Weiherbach " & vbCrLf &
'            "pond|stream")>
'        R1

'        <Description(
'            "R2 " & vbCrLf &
'            "Porto " & vbCrLf &
'            "stream")>
'        R2

'        <Description(
'            "R3 " & vbCrLf &
'            "Bologna " & vbCrLf &
'            "stream")>
'        R3

'        <Description(
'            "R4 " & vbCrLf &
'            "Roujan " & vbCrLf &
'            "stream")>
'        R4

'        <Description(enumConverter(Of Type).not_defined)>
'        not_defined = -1

'    End Enum


'    ''' <summary>
'    ''' FOCUSsw water body
'    ''' ditch, stream or pond
'    ''' </summary>
'    <TypeConverter(GetType(enumConverter(Of eFOCUSswWaterBody)))>
'    Public Enum eFOCUSswWaterBody

'        <Description(
'            "DI " & vbCrLf &
'            "ditch " & vbCrLf &
'            "100m x 1m x 0.3m; 30,000L; 1.0")>
'        ditch = 0

'        <Description(
'            "ST " & vbCrLf &
'            "stream " & vbCrLf &
'            "100m x 1m x 0.3m; 30,000L; 1.2")>
'        stream

'        <Description(
'            "PO " & vbCrLf &
'            "pond " & vbCrLf &
'            "30m radius x 1.0m; ~94,000L; 1.0")>
'        pond

'        <Description(enumConverter(Of Type).not_defined)>
'        not_defined = -1

'    End Enum


'    ''' <summary>
'    ''' Number of applns.
'    ''' 1 - 8 (or more)
'    ''' </summary>
'    <TypeConverter(GetType(enumConverter(Of eNoOfApplns)))>
'    Public Enum eNoOfApplns

'        <Description("one")>
'        one = 0

'        <Description("two")>
'        two

'        <Description("three")>
'        three

'        <Description("four")>
'        four

'        <Description("fife")>
'        fife

'        <Description("six")>
'        six

'        <Description("seven")>
'        seven

'        <Description("eight or more")>
'        eight


'        <Description(enumConverter(Of Type).not_defined)>
'        not_defined = -1

'    End Enum

'    ''' <summary>
'    ''' Water bodies defined for the different scenarios
'    ''' </summary>
'    Public Shared scenariosXWaterBodies As String() =
'   {
'    "D1+ Lanna        +ditch|stream",
'    "D2+ Brimstone    +ditch|stream",
'    "D3+ Vredepeel    +ditch",
'    "D4+ Skousbo      +pond|stream",
'    "D5+ La Jailliere +pond|stream",
'    "D6+ Thiva        +ditch",
'    "R1+ Weiherbach   +pond|stream",
'    "R2+ Porto        +stream",
'    "R3+ Bologna      +stream",
'    "R4+ Roujan       +stream"
'    }

'    Public Shared scenarioXCropX_PFile As String() =
'    {
'    "D1,CS,lanna_p.BIN",
'    "D1,CW,lanna_p.BIN",
'    "D1,GA,lanna_p.BIN",
'    "D1,OS,lanna_p.BIN",
'    "D2,CW,brims_p.BIN",
'    "D2,FB,brims_p.BIN",
'    "D2,GA,brims_p.BIN",
'    "D2,OW,brims_p.BIN",
'    "D3,CS,vr_isc_p.BIN",
'    "D3,CW,vr_iwc_p.BIN",
'    "D3,FB,vr_ifb_p.BIN",
'    "D3,GA,vr_igr_p.BIN",
'    "D3,LG,vr_ile_p.BIN",
'    "D3,MZ,vr_ima_p.BIN",
'    "D3,OS,vrede_p.BIN",
'    "D3,OW,vrede_p.BIN",
'    "D3,PF,vr_ipf_p.BIN",
'    "D3,PS,vr_ipo_p.BIN",
'    "D3,SB,vr_isb_p.BIN",
'    "D3,VB,vr_ibv_p.BIN",
'    "D3,VL,vr_ilv_p.BIN",
'    "D3,VR,vr_irv_p.BIN",
'    "D4,CS,skous_p.BIN",
'    "D4,CW,skous_p.BIN",
'    "D4,FB,skous_p.BIN",
'    "D4,GA,skous_p.BIN",
'    "D4,LG,sk_ile_p.BIN",
'    "D4,MZ,skous_p.BIN",
'    "D4,OS,skous_p.BIN",
'    "D4,OW,skous_p.BIN",
'    "D4,PF,skous_p.BIN",
'    "D4,PS,sk_ipo_p.BIN",
'    "D4,SB,sk_isb_p.BIN",
'    "D4,VB,sk_ibv_p.BIN",
'    "D4,VL,sk_ilv_p.BIN",
'    "D5,CS,jaill_p.BIN",
'    "D5,CW,jaill_p.BIN",
'    "D5,GA,jaill_p.BIN",
'    "D5,LG,jaill_p.BIN",
'    "D5,MZ,jaill_p.BIN",
'    "D5,OS,jaill_p.BIN",
'    "D5,OW,jaill_p.BIN",
'    "D5,PF,jaill_p.BIN",
'    "D5,SU,jaill_p.BIN",
'    "D6,CI,th_ici_p.BIN",
'    "D6,CO,th_ico_p.BIN",
'    "D6,CW,thebe_p.BIN",
'    "D6,FB,th_ifb_p.BIN",
'    "D6,LG,th_ile_p.BIN",
'    "D6,MZ,th_ima_p.BIN",
'    "D6,OL,thebe_p.BIN",
'    "D6,PS,th_ipo_p.BIN",
'    "D6,VB,th_ibv_p.BIN",
'    "D6,VF,th_ifv_p.BIN",
'    "D6,VI,thebe_p.BIN",
'    "D6,VL,th_ilv_p.BIN",
'    "D6,VR,th_irv_p.BIN"
'    }


'    ''' <summary>
'    ''' Buffer width as enum for simple input, -1 = Step03 std ;-)
'    ''' </summary>
'    <TypeConverter(GetType(enumConverter(Of eBufferWidth)))>
'    Public Enum eBufferWidth

'        <Description("Step03")>
'        FOCUSStep03 = 0

'        <Description(" 1")>
'        _01 = 1

'        <Description(" 2")>
'        _02 = 2

'        <Description(" 3")>
'        _03 = 3

'        <Description(" 4")>
'        _04 = 4

'        <Description(" 5")>
'        _05 = 5

'        <Description("10")>
'        _10 = 10

'        <Description("15")>
'        _15 = 15

'        <Description("20")>
'        _20 = 20

'        <Description("30")>
'        _30 = 30

'        <Description("40")>
'        _40 = 40

'        <Description("50")>
'        _50 = 50


'    End Enum


'#End Region

'    Public Property test As Boolean
'        Get
'            Return True
'        End Get
'        Set(value As Boolean)
'            If value Then Exit Property

'            Dim irrday2 As Integer(,) = {}
'            Dim temp As New List(Of String)
'            Dim irrday As Integer(,) = {}
'            irrday = getMACROPatApplnDays(
'                fname:=Path.Combine(
'                    path1:="C:\VS2020\MACROResources\ExeParFile554",
'                    path2:=Me.precipitationFile),
'                num_apps:=Me.noOfApplns + 1,
'                interval:=Me.interval, startDate.DayOfYear, endDate.DayOfYear)

'            For counter As Integer = 1 To irrday.GetUpperBound(0)
'                For counter02 As Integer = 0 To irrday.GetUpperBound(1)
'                    temp.Add(irrday(counter, counter02))
'                Next
'            Next
'            irrg = temp.ToArray

'            'File.WriteAllLines(
'            '    Path.Combine(
'            '    Environment.CurrentDirectory,
'            '    "PATlog.txt"),
'            '    PATlog.ToArray)

'            'precipitationCSV = {}

'            'irrday2 = getMACROPatApplnDays(
'            '    fname:="C:\VS2020\MACROResources\ExeParFile554\sk_ile_p.BIN",
'            '    num_apps:=2,
'            '    interval:=7, 133, 170)

'            'File.WriteAllLines(
'            '    Path.Combine(
'            '    Environment.CurrentDirectory,
'            '    "PATlog2.txt"),
'            '    PATlog.ToArray)

'        End Set
'    End Property

'    Public Property report As String
'        Get
'            Return ""
'        End Get
'        Set(value As String)

'            Dim reporttxt As New List(Of String)
'            Dim temp As String() = {}

'            Try
'                reporttxt.AddRange(File.ReadAllLines(value))
'                reporttxt.RemoveRange(index:=0, count:=32)

'                temp = Filter(
'                    reporttxt.ToArray,
'                    Match:="      *         ",
'                    Include:=False,
'                    Compare:=CompareMethod.Text)

'                reporttxt.Clear()

'                For Each member As String In temp

'                    If member.Length > 15 Then
'                        reporttxt.Add(member)
'                    End If

'                Next
'                temp = {}

'            Catch ex As Exception

'            End Try


'        End Set
'    End Property
'    Public Class PATout

'        Public Sub New()

'        End Sub

'        Public Property applnDate




'    End Class

'    Public precipitationCSV As String() = {}

'    Public Shared PATlog As New List(Of String)

'    ''' <summary>
'    ''' Find the appln days according to (old) PAT
'    ''' </summary>
'    ''' <param name="fname">
'    ''' name of the weather file, *.bin
'    ''' </param>
'    ''' <param name="num_apps">
'    ''' # of applns, 1 - 8
'    ''' </param>
'    ''' <param name="interval">
'    ''' interval between applns
'    ''' </param>
'    ''' <param name="fd">
'    ''' first possible appln. day as julian day 1 - 365
'    ''' </param>
'    ''' <param name="ld">
'    ''' last possible appln. day as julian day 1 - 365
'    ''' </param>
'    ''' <remarks></remarks>
'    Public Function getMACROPatApplnDays(
'                                       fname As String,
'                                       num_apps As Integer,
'                                       interval As Integer,
'                                       fd As Integer, ld As Integer,
'                                       Optional MaxOutput As Boolean = False
'                                       ) As Integer(,)

'#Region "Definitions"

'        Dim yea As Integer
'        Dim je As Integer
'        Dim jd As Integer
'        Dim jc As Integer
'        Dim jb As Integer
'        Dim jalpha As Integer
'        Dim ja As Integer
'        Dim ho As Integer
'        Dim mi As Integer
'        Dim m As Integer
'        Dim l As Integer
'        Dim total_rain As Single
'        Dim condition As Integer
'        Dim current_day As Integer
'        Dim ki As Integer
'        Dim da As Integer
'        Dim mon As Integer
'        Dim k As Integer
'        Dim j As Integer


'        Dim rec_l As Integer
'        Dim rec_ant As Integer
'        Dim var_ant As Integer
'        Dim start As Long
'        Dim jul As Integer
'        Dim rra As Single
'        Dim addto As Short

'        Dim Years As New List(Of Integer)

'        Dim RAIN As Single()
'        ReDim RAIN(10000)

'        Dim acc_days As Integer()
'        ReDim acc_days(100)

'        Dim days_around_app As Integer = 2
'        Dim max_rain As Single = 2
'        Dim min_rain As Single = 10
'        Dim days_after_app As Integer = 10
'        Dim irrday As Integer(,) = {}
'        ReDim irrday(200, 200)


'        Dim first_day As Integer
'        Dim last_day As Integer
'        Dim MaxYears As Integer

'        Dim TempDateOut As String = ""
'        Dim DateTemp As New Date
'        Dim TempJulOut As String = ""
'        Dim TempRainOut As String = ""
'        Dim RainArroundAppln As Boolean = False

'#End Region

'        PATlog.Clear()

'        If precipitationCSV.Count > 0 Then

'            Dim searchArray As String()
'            Dim index As Integer = -1
'            Dim startDate As Date

'            j = 1
'            k = 1

'            searchArray = precipitationCSV.First.Split(",")
'            For counter As Integer = 0 To searchArray.Count - 1
'                searchArray(counter) = searchArray(counter).ToLower
'            Next

'            index = Array.FindIndex(array:=searchArray, match:=Function(x) x = Path.GetFileNameWithoutExtension(fname).ToLower)

'            If index = -1 Then Exit Function

'            startDate = New Date(
'                year:=precipitationCSV(1).Split(",")(index),
'                month:=1,
'                day:=1)

'            For rowCounter As Integer = 2 To precipitationCSV.Count - 1
'                RAIN(rowCounter - 1) = precipitationCSV(rowCounter).Split(",")(index)

'                j += 1

'                With startDate.AddDays(rowCounter - 2)
'                    If .Month = 12 AndAlso .Day = 31 Then

'                        Years.Add(.Year)
'                        acc_days(k) = j - 1
'                        k += 1

'                    End If
'                End With

'            Next

'        Else

'            Try

'                PATlog.Add("Open " & fname)
'                FileOpen(1, fname, OpenMode.Binary)

'                FileGet(1, rec_ant, 1)
'                FileGet(1, rec_l)

'                var_ant = CInt(rec_l / 4 - 1)
'                start = rec_l + 1

'                j = 1
'                k = 1

'                PATlog(PATlog.Count - 1) = PATlog(PATlog.Count - 1) & " ... OK"

'            Catch ex As Exception

'            End Try

'            'read *.bin file to array
'            Do

'                Try

'                    Seek(1, start)

'                    FileGet(1, jul) '=julian date
'                    mi = jul Mod (60 * 24)
'                    ho = CInt(mi / 60)
'                    mi = mi - ho * 60
'                    jul = CInt((jul - mi - ho * 60) / 60 / 24 + 1721424)
'                    ja = jul

'                    If jul >= 2299161 Then
'                        jalpha = CInt(Int(((jul - 1867216) - 0.25) / 36524.25))
'                        ja = CInt(jul + 1 + jalpha - Int(jalpha * 0.25))
'                    End If

'                    jb = ja + 1524
'                    jc = CInt(Int(6680.0# + ((jb - 2439870) - 122.1) / 365.25))
'                    jd = CInt(365 * jc + Int(0.25 * jc))
'                    je = CInt(Int((jb - jd) / 30.6001))
'                    da = CInt(jb - jd - Int(30.6001 * je))
'                    mon = je - 1
'                    If mon > 12 Then mon = mon - 12
'                    yea = jc - 4715


'                    If mon > 2 Then yea = yea - 1
'                    If yea <= 0 Then yea = yea - 1

'                    FileGet(1, rra)
'                    RAIN(j) = rra
'                    start = start + rec_l
'                    j = j + 1

'                    'If k = 8 And mon = 4 And da = 30 Then
'                    '    GoTo 5
'                    'End If

'                    If da = 31 And mon = 12 Then
'                        Years.Add(yea)
'                        acc_days(k) = j - 1
'                        k = k + 1
'                    End If

'                Catch ex As Exception
'                    FileClose(1)
'                    Exit Do
'                End Try

'            Loop

'        End If

'        MaxYears = Years.Count
'        PATlog.Add(MaxYears & " years of weather data")

'        ReDim irrday(MaxYears, num_apps)
'        For YearCounter As Integer = 1 To Years.Count
'            irrday(YearCounter, 0) = Years(YearCounter - 1)
'        Next

'        PATlog(PATlog.Count - 1) = PATlog(PATlog.Count - 1) &
'            ", " & Years.First & " - " & Years.Last

'        For ki = 1 To MaxYears

'            days_after_app = 10
'            min_rain = 10
'            max_rain = 2
'            days_around_app = 2

'            If ki > 1 Then
'                first_day = fd + acc_days(ki - 1)
'            Else
'                first_day = fd
'                If first_day < 3 Then
'                    first_day = 3
'                    addto = 2
'                Else
'                    first_day = fd
'                    addto = 0
'                End If

'            End If

'            If ki > 1 Then
'                last_day = ld + acc_days(ki - 1)
'            Else
'                last_day = ld + addto
'            End If

'            If last_day < first_day Then
'                last_day = last_day + 365
'            End If

'#Region " Log"


'            PATlog.Add("")
'            PATlog.Add("Year " & ki & " , " & Years(ki - 1).ToString)
'            PATlog.Add("days_after_app  " & days_after_app)
'            PATlog.Add("min_rain        " & min_rain)
'            PATlog.Add("max_rain        " & max_rain)
'            PATlog.Add("days_around_app " & days_around_app)
'            PATlog.Add("first_day       " & first_day & " (" & fd & ", " &
'                                                New Date(year:=Years.First,
'                                                         month:=1,
'                                            day:=1).AddDays(first_day - 1).ToString("dd-MMM-yy ") & ")")

'            PATlog.Add("last_day        " & last_day & " (" & ld & ", " &
'                                                New Date(year:=Years.First,
'                                                         month:=1,
'                                            day:=1).AddDays(last_day - 1).ToString("dd-MMM-yy ") & ")")

'#End Region

'            For j = 1 To num_apps
'2:
'                If j = 1 Then
'                    current_day = first_day
'                Else
'                    If ki = 1 Then
'                        current_day = irrday(ki, j - 1) + interval
'                    Else
'                        current_day = irrday(ki, j - 1) + interval + acc_days(ki - 1)
'                    End If

'                End If

'                condition = 1
'                PATlog.Add("")

'                Do While current_day <= last_day - ((num_apps - j) * interval)

'                    PATlog(PATlog.Count - 1) =
'                        PATlog(PATlog.Count - 1) & "Test day " & current_day & " , " & New Date(year:=Years.First,
'                                            month:=1,
'                                            day:=1).AddDays(current_day - 1).ToString("dd-MMM-yy ")

'                    total_rain = 0

'                    TempDateOut = ""
'                    TempJulOut = ""
'                    TempRainOut = ""

'                    For l = 1 To days_after_app

'                        total_rain = total_rain + RAIN(current_day + l)

'                        TempDateOut &= New Date(year:=Years.First,
'                                            month:=1,
'                                            day:=1).AddDays(current_day + l - 1).ToString("dd-MMM-yy ")
'                        TempJulOut &= (current_day + l).ToString.PadRight("dd-MMM-yy ".Length)
'                        TempRainOut &= RAIN(current_day + l).ToString("G2").PadRight("dd-MMM-yy ".Length)

'                    Next l

'                    PATlog.Add(TempDateOut)
'                    PATlog.Add(TempJulOut)
'                    PATlog.Add(TempRainOut)

'                    If total_rain < min_rain Then
'                        condition = 0
'                        PATlog.Add(total_rain.ToString("G2") & "mm < " & min_rain & "mm, rule failed")
'                    Else
'                        PATlog.Add(total_rain.ToString("G2") & "mm > " & min_rain & "mm, rule passed")
'                    End If

'                    TempDateOut = ""
'                    TempJulOut = ""
'                    TempRainOut = ""

'                    PATlog.Add("Rain " & days_around_app & " days around appln")

'                    RainArroundAppln = True
'                    For m = -days_around_app To days_around_app

'                        TempDateOut &= New Date(year:=Years.First,
'                                            month:=1,
'                                            day:=1).AddDays(current_day + m - 1).ToString("dd-MMM-yy ")
'                        TempJulOut &= (current_day + m).ToString.PadRight("dd-MMM-yy ".Length)
'                        TempRainOut &= RAIN(current_day + m).ToString.PadRight("dd-MMM-yy ".Length)


'                        If RAIN(current_day + m) > max_rain Then

'                            condition = 0
'                            RainArroundAppln = False

'                        End If

'                    Next m

'                    PATlog.Add(TempDateOut)
'                    PATlog.Add(TempJulOut)
'                    PATlog.Add(TempRainOut)

'                    If RainArroundAppln Then
'                        PATlog(PATlog.Count - 1) = PATlog(PATlog.Count - 1) & " passed"
'                    Else
'                        PATlog(PATlog.Count - 1) = PATlog(PATlog.Count - 1) & " failed"
'                    End If

'                    If condition = 1 Then

'                        If ki = 1 Then
'                            irrday(ki, j) = current_day
'                        Else

'                            irrday(ki, j) = current_day - acc_days(ki - 1)


'                            If irrday(ki, j) > acc_days(ki) - acc_days(ki - 1) AndAlso acc_days(ki) <> 0 Then
'                                irrday(ki, j) = irrday(ki, j) - acc_days(ki) + acc_days(ki - 1)
'                            End If

'                        End If

'                        PATlog.Add(" *** Possible solution found for appln no " & j.ToString("00") & " year " & ki.ToString("00"))
'                        PATlog.Add(" *** " & New Date(year:=Years.First,
'                                            month:=1,
'                                            day:=1).AddDays(current_day - 1).ToString("dd-MMM-yy ") & ", day no " &
'                        (current_day).ToString & "(" & New Date(year:=Years.First,
'                                            month:=1,
'                                            day:=1).AddDays(current_day - 1).DayOfYear.ToString & ") , day no " &
'                        (current_day).ToString & ", rain " &
'                        RAIN(current_day).ToString & " mm")

'                        PATlog.Add(TempDateOut)
'                        PATlog.Add(TempJulOut)
'                        PATlog.Add(TempRainOut)

'                        If j = num_apps And ki = MaxYears Then
'                            Return irrday
'                        Else
'                            If j <> num_apps Then PATlog.Add("Next appln")
'                            current_day = current_day + interval
'                            days_after_app = 10
'                            min_rain = 10
'                            max_rain = 2
'                            days_around_app = 2
'                            GoTo 1
'                        End If

'                    Else
'                        PATlog.Add("Try next day")
'                        current_day = current_day + 1
'                        condition = 1
'                    End If

'                Loop

'                If min_rain = 0 And days_around_app = 0 Then
'                    max_rain = max_rain + 1
'                End If

'                days_around_app = days_around_app - 1

'                If days_around_app = -1 Then
'                    days_around_app = 0
'                    days_after_app = days_after_app + 5
'                    If current_day + days_after_app > last_day + 10 Then
'                        days_after_app = days_after_app - 5
'                        min_rain = 0
'                    End If
'                End If

'                GoTo 2
'1:
'            Next j

'        Next ki

'        Return irrday

'    End Function




'#Region "functions"

'    ''' <summary>
'    ''' convert FOCUSsw DRIFT crop to Ganzelmeier crop group
'    ''' </summary>
'    Public Shared convertFOCUSCrop2Ganzelmeier As eGanzelmeier() =
'    {
'       eGanzelmeier.ArableCrops,
'       eGanzelmeier.ArableCrops,
'       eGanzelmeier.FruitCrops_Late,
'       eGanzelmeier.ArableCrops,
'       eGanzelmeier.ArableCrops,
'       eGanzelmeier.ArableCrops,
'       eGanzelmeier.Hops,
'       eGanzelmeier.ArableCrops,
'       eGanzelmeier.ArableCrops,
'       eGanzelmeier.ArableCrops,
'       eGanzelmeier.ArableCrops,
'       eGanzelmeier.FruitCrops_Late,
'       eGanzelmeier.FruitCrops_Early,
'       eGanzelmeier.FruitCrops_Late,
'       eGanzelmeier.ArableCrops,
'       eGanzelmeier.ArableCrops,
'       eGanzelmeier.ArableCrops,
'       eGanzelmeier.ArableCrops,
'       eGanzelmeier.ArableCrops,
'       eGanzelmeier.ArableCrops,
'       eGanzelmeier.ArableCrops,
'       eGanzelmeier.ArableCrops,
'       eGanzelmeier.ArableCrops,
'       eGanzelmeier.Vines_Early,
'       eGanzelmeier.Vines_Late,
'       eGanzelmeier.AerialAppln,
'       eGanzelmeier.ArableCrops,
'       eGanzelmeier.Vines_Late,
'       eGanzelmeier.noDrift,
'       eGanzelmeier.not_defined
'    }

'    ''' <summary>
'    ''' returns avail. scenarios for this crop as array of string
'    ''' </summary>
'    Public Shared getSwScenarios4FOCUSDriftCrop As String() =
'    {
'        "CS+Cereals, Spring+D1|D3|D4|D5|R4",
'        "CW+Cereals, Winter+D1|D2|D3|D4|D5|D6|R1|R3|R4",
'        "CI+Citrus+D6|R4",
'        "CO+Cotton+D6",
'        "FB+Field beans+D2|D3|D4|D6|R1|R2|R3|R4",
'        "GA+Grass/alfalfa+D1|D2|D3|D4|D5|R2|R3",
'        "HP+Hops+R1",
'        "LG+Legumes+D3|D4|D5|D6|R1|R2|R3|R4",
'        "MZ+Maize+D3|D4|D5|D6|R1|R2|R3|R4",
'        "OS+Oil seed rape, spring+D1|D3|D4|D5|R1",
'        "OW+Oil seed rape, winter+D2|D3|D4|D5|R1|R3",
'        "OL+Olives+D6|R4",
'        "PFE+Pome/stone fruits+D3|D4|D5|R1|R2|R3|R4",
'        "PFL+Pome/stone fruits+D3|D4|D5|R1|R2|R3|R4",
'        "PS+Potatoes+D3|D4|D6|R1|R2|R3",
'        "SY+Soybeans+R3|R4",
'        "SB+Sugar beets+D3|D4|R1|R3",
'        "SU+Sunflowers+D5|R1|R3|R4",
'        "TB+Tobacco+R3",
'        "VB+Vegetables, bulb+D3|D4|D6|R1|R2|R3|R4",
'        "VF+Vegetables, fruiting+D6|R2|R3|R4",
'        "VL+Vegetables, leafy+D3|D4|D6|R1|R2|R3|R4",
'        "VR+Vegetables, root+D3|D6|R1|R2|R3|R4",
'        "VIE+Vines+D6|R1|R2|R3|R4",
'        "VIL+Vines+D6|R1|R2|R3|R4"
'    }

'    Public Function getPrecipitationFileName(
'                            FOCUSswDriftCrop As eFOCUSswDriftCrop,
'                            FOCUSswScenario As eFOCUSswScenario) As String


'        If FOCUSswScenario = eFOCUSswScenario.not_defined OrElse
'           FOCUSswDriftCrop = eFOCUSswDriftCrop.not_defined Then
'            Return ""
'        End If

'        Dim temp As String()

'        temp =
'            Filter(
'            Source:=scenarioXCropX_PFile,
'            Match:=FOCUSswScenario.ToString & "," & FOCUSswDriftCrop.ToString.Split("_").First)

'        If IsNothing(temp) OrElse temp.Count = 0 Then
'            Return ""
'        Else
'            Return temp.First
'        End If

'    End Function

'    Public Shared Function isScenarioIsDefined(
'                                FOCUSDriftCrop As eFOCUSswDriftCrop,
'                                FOCUSswScenario As eFOCUSswScenario) As Boolean

'        Dim availScenarios As String()

'        If FOCUSDriftCrop = eFOCUSswDriftCrop.not_defined OrElse
'          FOCUSswScenario = eFOCUSswScenario.not_defined Then Return False

'        Try
'            availScenarios =
'                       getSwScenarios4FOCUSDriftCrop(FOCUSDriftCrop).Split("+").Last.Split("|")

'            If availScenarios.Contains(FOCUSswScenario.ToString) Then
'                Return True
'            Else
'                Return False
'            End If
'        Catch ex As Exception
'            Return False
'        End Try

'    End Function

'    Public Shared Function isWaterBodyDefined(FOCUSswScenario As eFOCUSswScenario, FOCUSswWaterBody As eFOCUSswWaterBody) As Boolean

'        Dim enumDescription As String()

'        If FOCUSswScenario = eFOCUSswDriftCrop.not_defined OrElse
'           FOCUSswWaterBody = eFOCUSswWaterBody.not_defined Then Return False

'        Try
'            enumDescription =
'                enumConverter(Of eFOCUSswScenario).getEnumDescription(
'                EnumConstant:=FOCUSswScenario).Split(
'                    separator:={vbCrLf},
'                    options:=StringSplitOptions.RemoveEmptyEntries).Last.Split(",")


'            If enumDescription.Contains(
'                FOCUSswWaterBody.ToString) Then
'                Return True
'            Else
'                Return False
'            End If

'        Catch ex As Exception
'            Return False
'        End Try


'    End Function


'#End Region

'End Class

