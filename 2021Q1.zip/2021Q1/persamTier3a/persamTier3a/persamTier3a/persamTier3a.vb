﻿

Imports System.ComponentModel
Imports System.Drawing.Design
Imports System.IO
Imports System.Web.Script.Serialization
Imports System.Xml.Serialization
Imports persamTier3a.FOCUSGWdb

Module persamTier3a_cli


    Sub Main()

        With persamTier3a

            .ptfPath = "C:\Temp\EFSA_PECsoil_implementation\Tier3a\PEARL\pmt\Persam\EA-20-042_test\south\FPF\660_apple 1_1_0-FPF_total soil_zEco(default)_South.ptf"

        End With


    End Sub

    Public Property persamTier3a As New persamTier3a

End Module


#Region "    tier3a"

<TypeConverter(GetType(enumConverter(Of eRegZone)))>
Public Enum eRegZone

    North
    Centre
    South

    <Description(enumConverter(Of Type).not_defined)>
    not_dev = -1

End Enum

<TypeConverter(GetType(enumConverter(Of eTypeOfEP)))>
Public Enum eTypeOfEP

    TotSol
    PoreWat

    <Description(enumConverter(Of Type).not_defined)>
    not_dev = -1

End Enum

<TypeConverter(GetType(enumConverter(Of eSoilTypeID)))>
Public Enum eSoilTypeID

    Coarse
    Medium
    MediumFine
    Fine
    VeryFine
    Organic

    <Description(enumConverter(Of Type).not_defined)>
    not_dev = -1

End Enum

<TypeConverter(GetType(enumConverter(Of eSubstanceAss)))>
Public Enum eSubstanceAss

    P

    M1A
    M1B
    M1C
    M1D

    M2A
    M2B
    M2C
    M2D

    <Description(enumConverter(Of Type).not_defined)>
    not_dev = -1

End Enum


Public Class persamTier3a
    Private _ptfPath As String = ""

    Public Sub New()

    End Sub

    Public Property ptfPath As String
        Get
            Return _ptfPath
        End Get
        Set

            _ptfPath = Value
            readPTFFile(ptfPath:=_ptfPath)

        End Set
    End Property

    <RefreshProperties(RefreshProperties.All)>
    Public Property controlSection As String() =
    {
        "*-------------------------------------------------------------------------------",
        "* Section 1: Control section",
        "*-------------------------------------------------------------------------------",
        " ",
        "FOCUSPEARL        CallingProgram",
        "5.5.5             CallingProgramVersion",
        "Groundwater       ExposureType",
        "FOCUSPEARL A      AssessmentSubstance",
        "6                 InitYears (y)",
        "0                 NumRep (-)",
        "01-Jan-1901       TimStart",
        "31-Dec-1926       TimEnd",
        "0.001             ThetaTol (m3.m-3)",
        "Month             OptDelTimPrn",
        "30                DelTimPrn  (d)",
        "OnLine            OptHyd",
        "1E-5              DelTimSwaMin (d)",
        "0.2               DelTimSwaMax (d)",
        "Yes               PrintCumulatives",
        "1.0               GWLTol (m)",
        "30                MaxItSwa",
        "No                OptHysteresis",
        "0.2               PreHeaWetDryMin (cm)",
        "All               OptSys",
        "Yes               OptScreen",
        "No                OptPaddy",
        "No                OptMacropore",
        "None              OptAux",
        " "
    }

    Private _persamSubstances As persamSubstance() = {}
    Private _persamApplns As persamAppln() = {}

    Public Sub readPTFFile(ptfPath As String)

        Dim header As New List(Of String)
        header.AddRange(getStartInfo(LeadingString:="* "))

        Try
            ptfFile = File.ReadAllLines(ptfPath)
        Catch ex As Exception
            Throw New IOException(
                    message:="Error reading ptf file" & vbCrLf & ptfPath,
                    innerException:=ex)
        End Try

        Me.regZone =
        [Enum].Parse(
        enumType:=GetType(eRegZone),
        value:=getValue(
                search:="RegZone",
                stringArray:=ptfFile))

        Me.typeOfEP =
        [Enum].Parse(
        enumType:=GetType(eTypeOfEP),
        value:=getValue(
                search:="TypeOfEP",
                stringArray:=ptfFile))

        Me.location = getValue(
                search:="Location",
                stringArray:=ptfFile)

        Me.fRef = CDbl(getValue(
                search:="fRef",
                stringArray:=ptfFile))

        Me.PERSAMCropNr = CInt(getValue(
                search:="PERSAMCropNr",
                stringArray:=ptfFile))

        Me.soilTypeID =
        [Enum].Parse(
        enumType:=GetType(eSoilTypeID),
        value:=getValue(
                search:="SoilTypeID",
                stringArray:=ptfFile))

        Me.cntOmSca = CDbl(getValue(
                search:="CntOmSca",
                stringArray:=ptfFile))

        Me.pHInp = CDbl(getValue(
               search:="pHInp",
               stringArray:=ptfFile))

        Me.prc = CDbl(getValue(
              search:="Prc",
              stringArray:=ptfFile))

        Me.temp = CDbl(getValue(
              search:="Temp",
              stringArray:=ptfFile))

        getSubstances(ptfFile:=ptfFile)

        With Me.substanceAss

            Me.warmUpYears =
                calcWarmUpYears(
                DT50Ref:= .DT50Ref,
                KomEql:= .KomEql)

        End With

        Me.ZEADTop = CDbl(getValue(
                search:="ZEADTop",
                stringArray:=ptfFile))

        Me.ZEADBot = CDbl(getValue(
                search:="ZEADBot",
                stringArray:=ptfFile))

        header.Add("* This file used transfer file " & ptfPath)
        header.AddRange(Me.controlSection)

        Me.controlSection = header.ToArray

    End Sub

    <XmlIgnore> <ScriptIgnore>
    <[ReadOnly](True)>
    Public Property ptfFile As String() = {}

    Public Sub getSubstances(ptfFile As String())

        Dim noOfsubst As Integer
        Dim temp As String() = {}
        Dim parameter As String() = {}
        Dim substanceAss As String

        temp =
            Filter(
                Source:=ptfFile,
                Match:=" Name_",
                Include:=True,
                Compare:=CompareMethod.Text)

        temp =
            Filter(
                Source:=temp,
                Match:=noValue,
                Include:=False,
                Compare:=CompareMethod.Text)

        noOfsubst = temp.Count - 1

        substanceAss =
        [Enum].Parse(
        enumType:=GetType(eSubstanceAss),
        value:=getValue(
                search:="SubstanceAss",
                stringArray:=ptfFile))

        Me.persamSubstances = {}
        ReDim Me.persamSubstances(noOfsubst)

        parameter = getValues(search:=" Name_", stringArray:=ptfFile)
        For counter As Integer = 0 To Me.persamSubstances.Count - 1
            Me.persamSubstances(counter) =
                New persamSubstance With {
                            .name = parameter(counter)
                                         }

            With Me.persamSubstances(counter)

                substanceAss = Filter(
                    Source:=ptfFile,
                    Match:= .name & " Name_").First.Split("_").Last.Split.First

                .substanceAss =
                    [Enum].Parse(
                    enumType:=GetType(eSubstanceAss),
                    value:=substanceAss)

            End With

        Next

        parameter = getValues(search:=" MolMas_", stringArray:=ptfFile)
        For counter As Integer = 0 To Me.persamSubstances.Count - 1

            With Me.persamSubstances(counter)

                .molMass = parameter(counter)

                If .substanceAss.ToString = substanceAss Then
                    Me.substanceAss.molMass = parameter(counter)
                End If

            End With

        Next

        parameter = getValues(search:=" DT50Ref_", stringArray:=ptfFile)
        For counter As Integer = 0 To Me.persamSubstances.Count - 1

            With Me.persamSubstances(counter)

                .DT50Ref = parameter(counter)

                If .substanceAss.ToString = substanceAss Then
                    Me.substanceAss.DT50Ref = parameter(counter)
                End If

            End With

        Next

        parameter = getValues(search:=" MolEntTra_", stringArray:=ptfFile)
        For counter As Integer = 0 To Me.persamSubstances.Count - 1

            With Me.persamSubstances(counter)

                .molEntTra = parameter(counter)

                If .substanceAss.ToString = substanceAss Then
                    Me.substanceAss.molEntTra = parameter(counter)
                End If

            End With

        Next

        parameter = getValues(search:=" KomEql_", stringArray:=ptfFile)
        For counter As Integer = 0 To Me.persamSubstances.Count - 1

            With Me.persamSubstances(counter)

                .KomEql = parameter(counter)

                If .substanceAss.ToString = substanceAss Then
                    Me.substanceAss.KomEql = parameter(counter)
                End If

            End With

        Next

    End Sub

    Public Function getValues(
                    search As String,
                    stringArray As String(),
                    Optional separator As String = " ",
                    Optional position As Integer = 0,
                    Optional exclude As String = Nothing) As String()

        Dim temp As String() = {}

        temp =
            Array.FindAll(
                array:=stringArray,
                match:=Function(x) x.Contains(search))

        If Not IsNothing(exclude) Then

            temp =
                Filter(
                    Source:=temp,
                    Match:=noValue,
                    Include:=False,
                    Compare:=CompareMethod.Text)

        End If

        For counter As Integer = 0 To temp.Count - 1
            temp(counter) =
                Trim(temp(counter).Split.First)
        Next

        Return temp

    End Function

    Public Function getValue(
                    search As String,
                    stringArray As String(),
                    Optional separator As String = " ",
                    Optional position As Integer = 0) As String

        Dim index As Integer = -1

        Try
            index = Array.FindIndex(array:=stringArray, match:=Function(x) x.Contains(search))

            If index = -1 Then
                Throw New ArgumentException(
                message:="Can't find " & search)
            End If

            Return _
                Trim(str:=stringArray(index).Split(
                     separator:=separator,
                     options:=StringSplitOptions.RemoveEmptyEntries)(position))

        Catch ex As Exception
            Throw New ArgumentException(
                message:="Can't get " & search,
                innerException:=ex)
        End Try

    End Function

    Public Sub setValue(search As String, value As String, stringArray As String())

        Dim index As Integer = -1
        Dim pos As Integer = -1

        Try

            index =
                Array.FindIndex(
                    array:=stringArray,
                    match:=Function(x) x.Contains(search))

            If index = -1 Then
                Throw New ArgumentException(
                message:="Can't find " & search)
            End If

            pos = stringArray(index).IndexOf(search)

            stringArray(index) = value.PadRight(pos) & search

        Catch ex As Exception
            Throw New ArgumentException(
                message:="Can't get " & search,
                innerException:=ex)
        End Try

    End Sub

    Public Const noValue As String = "-99"

    <RefreshProperties(RefreshProperties.All)>
    <Editor(GetType(buttonInteger), GetType(UITypeEditor))>
    Public Property warmUpYears As Integer
        Get
            Return _warmUpYears
        End Get
        Set

            If Value = buttonInteger.Clicked Then
                With substanceAss
                    _warmUpYears = calcWarmUpYears(
                        DT50Ref:= .DT50Ref, KomEql:= .KomEql)
                End With
            Else
                _warmUpYears = Value
            End If

            setValue(
                search:=searchWarmUp,
                value:=_warmUpYears,
                stringArray:=Me.controlSection)

        End Set
    End Property

    Const searchWarmUp As String = "InitYears (y)"
    Public Function calcWarmUpYears(DT50Ref As Double, KomEql As Double) As Integer

        Dim DT50Class As Integer
        Dim KomClass As Integer

        Select Case DT50Ref

            Case >= 1000
                DT50Class = 4

            Case >= 500
                DT50Class = 3

            Case >= 200
                DT50Class = 2

            Case >= 100
                DT50Class = 1

            Case Else
                DT50Class = 0

        End Select

        Select Case KomEql

            Case >= 500
                KomClass = 10

            Case >= 100
                KomClass = 5

            Case Else
                KomClass = 0

        End Select

        Try

            Return _
                CInt(warmUpDB(KomClass + DT50Class).Split(",").Last)

        Catch ex As Exception

            Throw New ArgumentException(
            message:=
            "Can't calc. warm up for" & vbCrLf &
            "  DT50Ref : " & DT50Ref & " days" & vbCrLf &
            "  KomEql  : " & KomEql & " L/kg", innerException:=ex)

        End Try

    End Function

    Public ReadOnly Property warmUpDB As String() =
    {
        "0,0,6",
        "100,0,12",
        "200,0,12",
        "500,0,18",
        "1000,0,24",
        "0,100,6",
        "100,100,12",
        "200,100,24",
        "500,100,30",
        "1000,100,30",
        "0,500,6",
        "100,500,12",
        "200,500,30",
        "500,500,30",
        "1000,500,54"
     }

    Public Property regZone As eRegZone = eRegZone.not_dev

    Public Property typeOfEP As eTypeOfEP = eTypeOfEP.not_dev

    Public Property location As String = ""

    Public Property fRef As Double = Double.NaN

    Public Property PERSAMCropNr As Integer
        Get
            Return _PERSAMCropNr
        End Get
        Set

            _PERSAMCropNr = Value
            fillFOCUS_crop_weatherData()

        End Set
    End Property

    Public Sub fillFOCUS_crop_weatherData()

        Dim temp As String() = {}

        If regZone <> eRegZone.not_dev AndAlso
            PERSAMCropNr >= 1 AndAlso PERSAMCropNr <= 33 Then

            temp =
                Array.FindAll(
                    array:=FOCUS_crop_weather,
                    match:=Function(x) x.StartsWith(Me.PERSAMCropNr & ","))

            temp =
               Array.FindAll(
                   array:=temp,
                   match:=Function(x) x.Contains(Me.regZone.ToString))


        End If


    End Sub


    Public Enum eFOCUS_crop_weatherMember

        PERSAMCropNr
        PERSAMCropName
        RegZone
        domFOCUS
        crop
        weather
        crop_calendar
        crop_file
        tillage_type
        crop_type
        irrigation_type

    End Enum

    ''' <summary>
    ''' PERSAMCropNr,PERSAMCropName,RegZone,domFOCUS,crop,weather,crop_calendar,crop_file,tillage_type,crop_type,irrigation_type
    ''' </summary>
    ''' <returns></returns>
    Public Property FOCUS_crop_weather As String() =
        {
"1,apples,North,HA,HA,hamb-ps-m,HAMB-GRASS,GRASS-HAMBURG,3,permanent,No",
"2,applesInRow,North,HA,HA,hamb-ps-m,HAMB-APPLES,APPLES-HAMBURG,3,permanent,No",
"3,beans,North,HA,HA,hamb-ps-m,HAMB-FLDBEANS,FLDBEANS-HAMBURG,1,annual,No",
"4,bushBerries,North,HA,HA,hamb-ps-m,HAMB-GRASS,GRASS-HAMBURG,3,permanent,No",
"5,bushBerriesInRow,North,HA,HA,hamb-ps-m,HAMB-BUSHBERR,BUSHBERR-HAMBURG,3,permanent,No",
"6,cabbage,North,HA,HA,hamb-ps-m,HAMB-CABBAGE,CABBAGE-HAMBURG,1,annual,No",
"7,carrots,North,HA,HA,hamb-ps-m,HAMB-CARROTS,CARROTS-HAMBURG,1,annual,No",
"8,citrus,North,-99,-99,-99,-99,-99,2,-99,-99",
"9,citrusInRow,North,-99,-99,-99,-99,-99,3,-99,-99",
"10,cotton,North,-99,-99,-99,-99,-99,1,-99,-99",
"11,fallow,North,HA,No,hamb-ps-m,No,-99,1,bare,No",
"12,grass,North,HA,HA,hamb-ps-m,HAMB-GRASS,GRASS-HAMBURG,3,permanent,No",
"13,hops,North,-99,-99,-99,-99,-99,2,-99,-99",
"14,hopsInRow,North,-99,-99,-99,-99,-99,3,-99,-99",
"15,linseed,North,HA,OK,hamb-ps-m,OKEH-LINSEED,LINSEED-OKEHAMPTON,1,annual,No",
"16,maize,North,HA,HA,hamb-ps-m,HAMB-MAIZE,MAIZE-HAMBURG,1,annual,No",
"17,oilseedRapeSummer,North,HA,OK,hamb-ps-m,OKEH-SOILSEED,SOILSEED-OKEHAMPTON,1,annual,No",
"18,oilseedRapeWinter,North,HA,HA,hamb-ps-m,HAMB-WOILSEED,WOILSEED-HAMBURG,1,annual,No",
"19,olives,North,-99,-99,-99,-99,-99,2,-99,-99",
"20,olivesInRow,North,-99,-99,-99,-99,-99,2,-99,-99",
"21,onions,North,HA,HA,hamb-ps-m,HAMB-ONIONS,ONIONS-HAMBURG,1,annual,No",
"22,peas,North,HA,HA,hamb-ps-m,HAMB-PEAS,PEAS-HAMBURG,1,annual,No",
"23,potatoes,North,HA,HA,hamb-ps-m,HAMB-SPOTATOES,SPOTATOES-HAMBURG,1,annual,No",
"24,soybean,North,HA,PI,hamb-ps-m,PIAC-SOYBEAN,SOYBEAN-PIACENZA,1,annual,No",
"25,springCereals,North,HA,HA,hamb-ps-m,HAMB-SCEREALS,SCEREALS-HAMBURG,1,annual,No",
"26,strawberries,North,HA,HA,hamb-ps-m,HAMB-STRAWBER,STRAWBER-HAMBURG,1,annual,No",
"27,sugarBeets,North,HA,HA,hamb-ps-m,HAMB-SUGARBEET,SUGARBEET-HAMBURG,1,annual,No",
"28,sunflowers,North,JO,PI,joki-ps-m,PIAC-SUNFLOWER,SUNFLOWER-PIACENZA,1,annual,No",
"29,tobacco,North,-99,-99,-99,-99,-99,1,-99,-99",
"30,tomatoes,North,HA,CH,hamb-ps-m,CHAT-TOMATOES,TOMATOES-CHATEAUDUN,1,annual,No",
"31,vines,North,-99,-99,-99,-99,-99,2,-99,-99",
"32,vinesInRow,North,-99,-99,-99,-99,-99,3,-99,-99",
"33,winterCereals,North,HA,HA,hamb-ps-m,HAMB-WCEREALS,WCEREALS-HAMBURG,1,annual,No",
"1,apples,Centre,CH,CH,chat-ps-m,CHAT-GRASS,GRASS-CHATEAUDUN,3,permanent,No",
"2,applesInRow,Centre,HA,HA,hamb-ps-m,HAMB-APPLES,APPLES-HAMBURG,3,permanent,No",
"3,beans,Centre,CH,HA,chat-ps-m,HAMB-FLDBEANS,FLDBEANS-HAMBURG,1,annual,Spr",
"4,bushBerries,Centre,CH,CH,chat-ps-m,CHAT-GRASS,GRASS-CHATEAUDUN,3,permanent,No",
"5,bushBerriesInRow,Centre,CH,CH,chat-ps-m,CHAT-BUSHBERR,BUSHBERR-CHATEAUDUN,3,permanent,Spr",
"6,cabbage,Centre,CH,CH,chat-ps-m,CHAT-CABBAGE,CABBAGE-CHATEAUDUN,1,annual,Spr",
"7,carrots,Centre,CH,CH,chat-ps-m,CHAT-CARROTS,CARROTS-CHATEAUDUN,1,annual,Spr",
"8,citrus,Centre,-99,-99,-99,-99,-99,2,-99,-99",
"9,citrusInRow,Centre,-99,-99,-99,-99,-99,3,-99,-99",
"10,cotton,Centre,HA,TH,hamb-ps-m,THIV-COTTON,COTTON-THIVA,1,annual,No",
"11,fallow,Centre,HA,No,hamb-ps-m,No,-99,1,bare,No",
"12,grass,Centre,HA,HA,hamb-ps-m,HAMB-GRASS,GRASS-HAMBURG,3,permanent,No",
"13,hops,Centre,HA,No,hamb-ps-m,No,-99,2,bare,No",
"14,hopsInRow,Centre,HA,HA,hamb-ps-m,HAMB-HOPS,HOPS-HAMBURG,3,permanent,No",
"15,linseed,Centre,HA,OK,hamb-ps-m,OKEH-LINSEED,LINSEED-OKEHAMPTON,1,annual,No",
"16,maize,Centre,CH,CH,chat-ps-m,CHAT-MAIZE,MAIZE-CHATEAUDUN,1,annual,Spr",
"17,oilseedRapeSummer,Centre,HA,OK,hamb-ps-m,OKEH-SOILSEED,SOILSEED-OKEHAMPTON,1,annual,No",
"18,oilseedRapeWinter,Centre,HA,HA,hamb-ps-m,HAMB-WOILSEED,WOILSEED-HAMBURG,1,annual,No",
"19,olives,Centre,-99,-99,-99,-99,-99,2,-99,-99",
"20,olivesInRow,Centre,-99,-99,-99,-99,-99,2,-99,-99",
"21,onions,Centre,HA,HA,hamb-ps-m,HAMB-ONIONS,ONIONS-HAMBURG,1,annual,No",
"22,peas,Centre,CH,CH,chat-ps-m,CHAT-PEAS,PEAS-CHATEAUDUN,1,annual,No",
"23,potatoes,Centre,HA,HA,hamb-ps-m,HAMB-SPOTATOES,SPOTATOES-HAMBURG,1,annual,No",
"24,soybean,Centre,CH,PI,chat-ps-m,PIAC-SOYBEAN,SOYBEAN-PIACENZA,1,annual,Spr",
"25,springCereals,Centre,CH,CH,chat-ps-m,CHAT-SCEREALS,SCEREALS-CHATEAUDUN,1,annual,No",
"26,strawberries,Centre,CH,HA,chat-ps-m,HAMB-STRAWBER,STRAWBER-HAMBURG,1,annual,Spr",
"27,sugarBeets,Centre,HA,HA,hamb-ps-m,HAMB-SUGARBEET,SUGARBEET-HAMBURG,1,annual,No",
"28,sunflowers,Centre,CH,PI,chat-ps-m,PIAC-SUNFLOWER,SUNFLOWER-PIACENZA,1,annual,Spr",
"29,tobacco,Centre,CH,PI,chat-ps-m,PIAC-TOBACCO,TOBACCO-PIACENZA,1,annual,Spr",
"30,tomatoes,Centre,CH,CH,chat-ps-m,CHAT-TOMATOES,TOMATOES-CHATEAUDUN,1,annual,Spr",
"31,vines,Centre,CH,No,chat-ps-m,No,-99,2,bare,No",
"32,vinesInRow,Centre,CH,CH,chat-ps-m,CHAT-VINES,VINES-CHATEAUDUN,3,permanent,Sur",
"33,winterCereals,Centre,CH,CH,chat-ps-m,CHAT-WCEREALS,WCEREALS-CHATEAUDUN,1,annual,No",
"1,apples,South,SE,SE,sevi-ps-m,SEVI-GRASS,GRASS-SEVILLA,3,permanent,No",
"2,applesInRow,South,SE,SE,sevi-ps-m,SEVI-APPLES,APPLES-SEVILLA,3,permanent,Sur",
"3,beans,South,HA,TH,hamb-ps-m,THIV-VEGBEANS,VEGBEANS-THIVA,1,annual,No",
"4,bushBerries,South,SE,SE,sevi-ps-m,SEVI-GRASS,GRASS-SEVILLA,3,permanent,No",
"5,bushBerriesInRow,South,SE,SE,sevi-ps-m,SEVI-BUSHBERR,BUSHBERR-SEVILLA,3,permanent,Spr",
"6,cabbage,South,SE,SE,sevi-ps-m,SEVI-CABBAGE,CABBAGE-SEVILLA,1,annual,Spr",
"7,carrots,South,SE,TH,sevi-ps-m,THIV-CARROTS,CARROTS-THIVA,1,annual,Spr",
"8,citrus,South,SE,No,sevi-ps-m,No,-99,2,bare,No",
"9,citrusInRow,South,SE,SE,sevi-ps-m,SEVI-CITRUS,CITRUS-SEVILLA,3,permanent,Sur",
"10,cotton,South,TH,TH,thiv-ps-m,THIV-COTTON,COTTON-THIVA,1,annual,Spr",
"11,fallow,South,SE,No,sevi-ps-m,No,-99,1,bare,No",
"12,grass,South,HA,HA,hamb-ps-m,HAMB-GRASS,GRASS-HAMBURG,3,permanent,No",
"13,hops,South,HA,No,hamb-ps-m,No,-99,2,bare,No",
"14,hopsInRow,South,HA,HA,hamb-ps-m,HAMB-HOPS,HOPS-HAMBURG,3,permanent,No",
"15,linseed,South,SE,OK,sevi-ps-m,OKEH-LINSEED,LINSEED-OKEHAMPTON,1,annual,Spr",
"16,maize,South,HA,HA,hamb-ps-m,HAMB-MAIZE,MAIZE-HAMBURG,1,annual,No",
"17,oilseedRapeSummer,South,HA,OK,hamb-ps-m,OKEH-SOILSEED,SOILSEED-OKEHAMPTON,1,annual,No",
"18,oilseedRapeWinter,South,HA,HA,hamb-ps-m,HAMB-WOILSEED,WOILSEED-HAMBURG,1,annual,No",
"19,olives,South,SE,-99,sevi-ps-m,-99,-99,2,-99,-99",
"20,olivesInRow,South,SE,SE,sevi-ps-m,SEVI-OLIVES,OLIVES-SEVILLA,2,permanent,Sur",
"21,onions,South,SE,TH,sevi-ps-m,THIV-ONIONS,ONIONS-THIVA,1,annual,Spr",
"22,peas,South,HA,HA,hamb-ps-m,HAMB-PEAS,PEAS-HAMBURG,1,annual,No",
"23,potatoes,South,HA,HA,hamb-ps-m,HAMB-SPOTATOES,SPOTATOES-HAMBURG,1,annual,No",
"24,soybean,South,TH,PI,thiv-ps-m,PIAC-SOYBEAN,SOYBEAN-PIACENZA,1,annual,Spr",
"25,springCereals,South,HA,HA,hamb-ps-m,HAMB-SCEREALS,SCEREALS-HAMBURG,1,annual,No",
"26,strawberries,South,SE,SE,sevi-ps-m,SEVI-STRAWBER,STRAWBER-SEVILLA,1,annual,Spr",
"27,sugarBeets,South,HA,HA,hamb-ps-m,HAMB-SUGARBEET,SUGARBEET-HAMBURG,1,annual,No",
"28,sunflowers,South,HA,PI,hamb-ps-m,PIAC-SUNFLOWER,SUNFLOWER-PIACENZA,1,annual,Spr",
"29,tobacco,South,SE,TH,sevi-ps-m,THIV-TOBACCO,TOBACCO-THIVA,1,annual,Spr",
"30,tomatoes,South,SE,SE,sevi-ps-m,SEVI-TOMATOES,TOMATOES-SEVILLA,1,annual,Spr",
"31,vines,South,SE,No,sevi-ps-m,No,-99,2,bare,No",
"32,vinesInRow,South,SE,SE,sevi-ps-m,SEVI-VINES,VINES-SEVILLA,3,permanent,Sur",
"33,winterCereals,South,HA,HA,hamb-ps-m,HAMB-WCEREALS,WCEREALS-HAMBURG,1,annual,No"
    }

    Public Property weaterFile As String

    Public Property cropType As String

    Public Property irrigType As String

    Public Property scenarioArrTemp As Double = Double.NaN

    Public Property molEntTra As Double = Double.NaN

    Public ReadOnly Property fT As Double



    Public Property soilTypeID As eSoilTypeID = eSoilTypeID.not_dev

    Public Property cntOmSca As Double = Double.NaN

    Public Property pHInp As Double = Double.NaN

    Public Property prc As Double = Double.NaN

    Public Property temp As Double = Double.NaN

    Public Property degPath As String() = {}

    Public Property optApp As eApplnMode = eApplnMode.not_dev

    Public Property zAppl As Double = Double.NaN

    <RefreshProperties(RefreshProperties.All)>
    Public Property substanceAss As New persamSubstance

    Private _warmUpYears As Integer = -1
    Private _PERSAMCropNr As Integer = -99

    Public Property persamSubstances As persamSubstance()
        Get
            Return _persamSubstances
        End Get
        Set
            _persamSubstances = Value
        End Set
    End Property

    Public Property persamApplns As persamAppln()
        Get
            Return _persamApplns
        End Get
        Set
            _persamApplns = Value
        End Set
    End Property

    Public Property ZEADTop As Double = Double.NaN

    Public Property ZEADBot As Double = Double.NaN

End Class

<TypeConverter(GetType(propGridConverter))>
Public Class persamAppln

    Public Sub New()

    End Sub

    Public Property dayOfAppln As Integer = 0

    Public Property applnRate As Double = Double.NaN

    Public Property interception As Double = Double.NaN


End Class

<TypeConverter(GetType(propGridConverter))>
Public Class persamSubstance

    Public Sub New()

    End Sub

    Public Property name As String

    Public Property substanceAss As eSubstanceAss = eSubstanceAss.not_dev

    Public Property molMass As Double = Double.NaN

    <RefreshProperties(RefreshProperties.All)>
    Public Property DT50Ref As Double


    Public Property molEntTra As Double = Double.NaN

    <RefreshProperties(RefreshProperties.All)>
    Public Property KomEql As Double


    Public Event recalcWarmup(DT50Ref As Double, KomEql As Double)

End Class

#End Region


