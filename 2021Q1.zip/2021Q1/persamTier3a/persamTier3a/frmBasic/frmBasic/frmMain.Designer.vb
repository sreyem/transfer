﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.MenuStrip = New System.Windows.Forms.MenuStrip()
        Me.tsmiFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiLoad = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiSave = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.tsmiExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiGrid = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiCollapseAll = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiCollapseStd = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiExpandAll = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip = New System.Windows.Forms.StatusStrip()
        Me.lblStatus = New System.Windows.Forms.ToolStripStatusLabel()
        Me.progressBar = New System.Windows.Forms.ToolStripProgressBar()
        Me.SplitContainer = New System.Windows.Forms.SplitContainer()
        Me.propGridMain = New System.Windows.Forms.PropertyGrid()
        Me.TabControl = New System.Windows.Forms.TabControl()
        Me.tabPropGridDetails = New System.Windows.Forms.TabPage()
        Me.propGridDetails = New System.Windows.Forms.PropertyGrid()
        Me.MenuStrip.SuspendLayout()
        Me.StatusStrip.SuspendLayout()
        CType(Me.SplitContainer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer.Panel1.SuspendLayout()
        Me.SplitContainer.Panel2.SuspendLayout()
        Me.SplitContainer.SuspendLayout()
        Me.TabControl.SuspendLayout()
        Me.tabPropGridDetails.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip
        '
        Me.MenuStrip.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmiFile, Me.tsmiGrid})
        Me.MenuStrip.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip.Name = "MenuStrip"
        Me.MenuStrip.Padding = New System.Windows.Forms.Padding(8, 2, 0, 2)
        Me.MenuStrip.Size = New System.Drawing.Size(760, 25)
        Me.MenuStrip.TabIndex = 0
        Me.MenuStrip.Text = "MenuStrip"
        '
        'tsmiFile
        '
        Me.tsmiFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmiLoad, Me.tsmiSave, Me.ToolStripSeparator1, Me.tsmiExit})
        Me.tsmiFile.Name = "tsmiFile"
        Me.tsmiFile.Size = New System.Drawing.Size(39, 21)
        Me.tsmiFile.Text = "&File"
        '
        'tsmiLoad
        '
        Me.tsmiLoad.Name = "tsmiLoad"
        Me.tsmiLoad.Size = New System.Drawing.Size(105, 22)
        Me.tsmiLoad.Text = "&Load"
        '
        'tsmiSave
        '
        Me.tsmiSave.Name = "tsmiSave"
        Me.tsmiSave.Size = New System.Drawing.Size(105, 22)
        Me.tsmiSave.Text = "&Save"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(102, 6)
        '
        'tsmiExit
        '
        Me.tsmiExit.Name = "tsmiExit"
        Me.tsmiExit.Size = New System.Drawing.Size(105, 22)
        Me.tsmiExit.Text = "&Exit"
        '
        'tsmiGrid
        '
        Me.tsmiGrid.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmiCollapseAll, Me.tsmiCollapseStd, Me.tsmiExpandAll})
        Me.tsmiGrid.Name = "tsmiGrid"
        Me.tsmiGrid.Size = New System.Drawing.Size(45, 21)
        Me.tsmiGrid.Text = "&Grid"
        '
        'tsmiCollapseAll
        '
        Me.tsmiCollapseAll.Name = "tsmiCollapseAll"
        Me.tsmiCollapseAll.Size = New System.Drawing.Size(143, 22)
        Me.tsmiCollapseAll.Text = "Collapse all"
        '
        'tsmiCollapseStd
        '
        Me.tsmiCollapseStd.Name = "tsmiCollapseStd"
        Me.tsmiCollapseStd.Size = New System.Drawing.Size(143, 22)
        Me.tsmiCollapseStd.Text = "    std."
        '
        'tsmiExpandAll
        '
        Me.tsmiExpandAll.Name = "tsmiExpandAll"
        Me.tsmiExpandAll.Size = New System.Drawing.Size(143, 22)
        Me.tsmiExpandAll.Text = "Expand all"
        '
        'StatusStrip
        '
        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lblStatus, Me.progressBar})
        Me.StatusStrip.Location = New System.Drawing.Point(0, 539)
        Me.StatusStrip.Name = "StatusStrip"
        Me.StatusStrip.Padding = New System.Windows.Forms.Padding(1, 0, 19, 0)
        Me.StatusStrip.Size = New System.Drawing.Size(760, 26)
        Me.StatusStrip.TabIndex = 1
        Me.StatusStrip.Text = "StatusStrip"
        '
        'lblStatus
        '
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(22, 21)
        Me.lblStatus.Text = " ... "
        '
        'progressBar
        '
        Me.progressBar.Name = "progressBar"
        Me.progressBar.Size = New System.Drawing.Size(133, 20)
        '
        'SplitContainer
        '
        Me.SplitContainer.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SplitContainer.Location = New System.Drawing.Point(0, 33)
        Me.SplitContainer.Margin = New System.Windows.Forms.Padding(4)
        Me.SplitContainer.Name = "SplitContainer"
        '
        'SplitContainer.Panel1
        '
        Me.SplitContainer.Panel1.Controls.Add(Me.propGridMain)
        '
        'SplitContainer.Panel2
        '
        Me.SplitContainer.Panel2.Controls.Add(Me.TabControl)
        Me.SplitContainer.Size = New System.Drawing.Size(760, 501)
        Me.SplitContainer.SplitterDistance = 330
        Me.SplitContainer.SplitterWidth = 5
        Me.SplitContainer.TabIndex = 2
        '
        'propGridMain
        '
        Me.propGridMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.propGridMain.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.propGridMain.Location = New System.Drawing.Point(0, 0)
        Me.propGridMain.Margin = New System.Windows.Forms.Padding(4)
        Me.propGridMain.Name = "propGridMain"
        Me.propGridMain.PropertySort = System.Windows.Forms.PropertySort.Categorized
        Me.propGridMain.Size = New System.Drawing.Size(330, 501)
        Me.propGridMain.TabIndex = 0
        Me.propGridMain.ToolbarVisible = False
        '
        'TabControl
        '
        Me.TabControl.Controls.Add(Me.tabPropGridDetails)
        Me.TabControl.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl.Location = New System.Drawing.Point(0, 0)
        Me.TabControl.Margin = New System.Windows.Forms.Padding(4)
        Me.TabControl.Name = "TabControl"
        Me.TabControl.SelectedIndex = 0
        Me.TabControl.Size = New System.Drawing.Size(425, 501)
        Me.TabControl.TabIndex = 0
        '
        'tabPropGridDetails
        '
        Me.tabPropGridDetails.Controls.Add(Me.propGridDetails)
        Me.tabPropGridDetails.Location = New System.Drawing.Point(4, 25)
        Me.tabPropGridDetails.Margin = New System.Windows.Forms.Padding(4)
        Me.tabPropGridDetails.Name = "tabPropGridDetails"
        Me.tabPropGridDetails.Padding = New System.Windows.Forms.Padding(4)
        Me.tabPropGridDetails.Size = New System.Drawing.Size(417, 472)
        Me.tabPropGridDetails.TabIndex = 0
        Me.tabPropGridDetails.Text = "Details"
        Me.tabPropGridDetails.UseVisualStyleBackColor = True
        '
        'propGridDetails
        '
        Me.propGridDetails.Dock = System.Windows.Forms.DockStyle.Fill
        Me.propGridDetails.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.propGridDetails.Location = New System.Drawing.Point(4, 4)
        Me.propGridDetails.Margin = New System.Windows.Forms.Padding(4)
        Me.propGridDetails.Name = "propGridDetails"
        Me.propGridDetails.PropertySort = System.Windows.Forms.PropertySort.Categorized
        Me.propGridDetails.Size = New System.Drawing.Size(409, 464)
        Me.propGridDetails.TabIndex = 1
        Me.propGridDetails.ToolbarVisible = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(760, 565)
        Me.Controls.Add(Me.SplitContainer)
        Me.Controls.Add(Me.StatusStrip)
        Me.Controls.Add(Me.MenuStrip)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MainMenuStrip = Me.MenuStrip
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.MenuStrip.ResumeLayout(False)
        Me.MenuStrip.PerformLayout()
        Me.StatusStrip.ResumeLayout(False)
        Me.StatusStrip.PerformLayout()
        Me.SplitContainer.Panel1.ResumeLayout(False)
        Me.SplitContainer.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer.ResumeLayout(False)
        Me.TabControl.ResumeLayout(False)
        Me.tabPropGridDetails.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip As MenuStrip
    Friend WithEvents StatusStrip As StatusStrip
    Friend WithEvents lblStatus As ToolStripStatusLabel
    Friend WithEvents progressBar As ToolStripProgressBar
    Friend WithEvents tsmiFile As ToolStripMenuItem
    Friend WithEvents tsmiLoad As ToolStripMenuItem
    Friend WithEvents tsmiSave As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents tsmiExit As ToolStripMenuItem
    Friend WithEvents tsmiGrid As ToolStripMenuItem
    Friend WithEvents SplitContainer As SplitContainer
    Friend WithEvents propGridMain As PropertyGrid
    Friend WithEvents TabControl As TabControl
    Friend WithEvents tabPropGridDetails As TabPage
    Friend WithEvents propGridDetails As PropertyGrid
    Friend WithEvents tsmiCollapseAll As ToolStripMenuItem
    Friend WithEvents tsmiCollapseStd As ToolStripMenuItem
    Friend WithEvents tsmiExpandAll As ToolStripMenuItem
End Class
