﻿
Imports System.IO

Module main


    Sub main()

        'test 3

        obin.obin()
        indump.indump()
        runModel.runModel()

        bin2dat.bin2dat()

    End Sub

End Module
