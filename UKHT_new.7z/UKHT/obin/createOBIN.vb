﻿
Imports System.IO


Module createOBIN

    Public Const obinPathName As String = "obin"

    Public Sub createOBIN()

        Try

            obinPath = Path.Combine(path1:=Environment.CurrentDirectory,
                                    path2:=obinPathName)

            If Not Directory.Exists(obinPath) Then
                Directory.CreateDirectory(path:=obinPath)
            End If

        Catch ex As Exception

            Throw New IOException(message:="Can't create 'obin' directory")

        End Try

    End Sub

End Module
