﻿
Imports System.IO

Module moveWeatherFiles

    Public Sub moveWeatherFiles()

        Dim weatherBins As String()
        Dim target As String

        weatherBins =
            Directory.GetFiles(path:=Environment.CurrentDirectory,
                               searchPattern:="*.bin",
                               searchOption:=SearchOption.TopDirectoryOnly)

        If weatherBins.Count <> 2 Then
            Throw New ArgumentException(message:="Wrong no of weather *.bin files")
        End If

        For Each weatherFile As String In weatherBins

            target = Path.Combine(path1:=obinPath,
                                  path2:=Path.GetFileName(path:=weatherFile))

            Try

                File.Move(sourceFileName:=weatherFile,
                                      destFileName:=target)

            Catch ex As Exception
                Throw New IOException(message:="Can't move weather file",
                                      innerException:=ex)
            End Try


        Next


    End Sub

End Module
