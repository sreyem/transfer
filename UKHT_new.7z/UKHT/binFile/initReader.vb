﻿
Imports System.IO

Module initReader

    Public Sub initReader()


        Dim hdrPos As Integer

        Try

            recordNo = binaryReader.ReadInt32()
            recordLength = binaryReader.ReadInt32()

            varNo = recordLength / 4

            If varNo <> 4 Then
                Throw New IOException(message:="Invalid no of columns " & varNo)
            End If

            hdrPos = (recordNo + 1) * recordLength

            inputStream.Seek(hdrPos, SeekOrigin.Begin)
            cols.Add(New column(0, "Date", "Date"))

        Catch ex As Exception

            Throw New IOException(message:="Can't init reader",
                                  innerException:=ex)

        End Try

    End Sub

End Module
