﻿
Imports System.IO

Module writeDAT

    Public Sub writeDAT()

        Try

            File.WriteAllLines(
                path:=Path.ChangeExtension(path:=binFilePath,
                                           extension:=".dat"),
                contents:=csvRows.ToArray)

        Catch ex As Exception

            Throw New IOException(message:=("Can't write *.dat file"),
                                  innerException:=ex)

        End Try

    End Sub

End Module
