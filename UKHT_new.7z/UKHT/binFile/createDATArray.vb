﻿

Module createDATArray

    Public Sub createDATArray()

        Const numberFormat As String = "0.00000E+00"
        Const dateFormat As String = "yyyyMMddHHmm"
        Const delimter As String = "  "

        csvRows.Add(
                dateFormat.ToUpper & delimter &
                cols(0).Label.Split.First.PadLeft(numberFormat.Length) & delimter &
                cols(1).Label.Split.First.PadLeft(numberFormat.Length) & delimter &
                cols(2).Label.Split.First.PadLeft(numberFormat.Length))

        For Each row As row In rows

            csvRows.Add(
                row.myDate.ToString(dateFormat) & delimter &
                row(0).ToString(numberFormat) & delimter &
                row(1).ToString(numberFormat) & delimter &
                row(2).ToString(numberFormat))

        Next

    End Sub

End Module
