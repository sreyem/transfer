﻿
Imports System.IO
Imports System.Text

Module createReader

    Public Sub createReader()

        Try

            binaryReader =
                    New BinaryReader(
                        input:=inputStream,
                        encoding:=Encoding.ASCII,
                        leaveOpen:=False)

        Catch ex As Exception

            Throw New IOException(message:="Can't create binary reader",
                                  innerException:=ex)

        End Try

    End Sub

End Module
