﻿<DebuggerStepThrough>
Public Class column

    Public ReadOnly Index As Integer
    Public ReadOnly Name As String
    Public ReadOnly Label As String

    Public Sub New(ByVal index As Integer, ByVal name As String, ByVal label As String)
        Me.Index = index
        Me.Name = name
        Me.Label = label
    End Sub
End Class

<DebuggerStepThrough>
Public Class row

    Public myDate As DateTime
    Public Values As Single()

    Default Public ReadOnly Property Item(ByVal i As Integer) As Single
        Get
            Return Values(i)
        End Get
    End Property
End Class