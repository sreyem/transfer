﻿
Imports System.IO

Module openStream

    Public Sub openStream()

        Try

            inputStream =
                      File.Open(
                          path:=binFilePath,
                          mode:=FileMode.Open,
                          access:=FileAccess.Read,
                          share:=FileShare.Read)

        Catch ex As Exception
            Throw New IOException(message:="Can't open stream to " & binFilePath,
                                  innerException:=ex)
        End Try

    End Sub

End Module
