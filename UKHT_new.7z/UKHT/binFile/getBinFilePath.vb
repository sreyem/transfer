﻿
Imports System.IO

Module getBinFilePath

    Public ukWeatherFiles As String() =
        {
            "dryev.bin",
            "dryr.bin",
            "medev.bin",
            "medr.bin",
            "wetev.bin",
            "wetr.bin"
        }

    Public Sub getBinFilePath()

        Dim args As String() = Environment.GetCommandLineArgs
        Dim fileInfo As FileInfo

        If args.Count = 2 Then

            binFilePath = Path.ChangeExtension(path:=args.Last,
                                               extension:=".bin")

        Else

            args = Directory.GetFiles(path:=Environment.CurrentDirectory,
                                      searchPattern:="*.bin",
                                      searchOption:=SearchOption.TopDirectoryOnly)

            For Each weatherFile As String In ukWeatherFiles

                args = Filter(Source:=args,
                              Match:=weatherFile,
                              Include:=False,
                              Compare:=CompareMethod.Text)

            Next

        End If

        fileInfo = New FileInfo(fileName:=args.Last)

        With fileInfo

            If .Exists AndAlso
               .Length > minBinFileSize AndAlso .Length < maxBinFileSize Then

                binFilePath = .FullName

            Else
                Throw New ArgumentException(
                               message:="Can't find valid binFilePath " & .FullName)
            End If

        End With

    End Sub

End Module
