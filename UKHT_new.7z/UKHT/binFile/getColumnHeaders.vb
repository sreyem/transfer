﻿
Imports System.IO
Imports System.Text.RegularExpressions

Module getColumnHeaders

    Public Sub getColumnHeaders()

        Dim entry As String
        Dim label As String
        Dim name As String
        Dim match As Match

        For i As Integer = 1 To varNo - 1

            entry = New String(binaryReader.ReadChars(60))
            label = entry.Substring(0, 52).Trim()
            name = label.Split({" "c}, StringSplitOptions.RemoveEmptyEntries).First()
            match = Regex.Match(label, "^(\S+(\s\S+)*\S*)")

            If match.Success Then
                name = match.Groups(1).Value.Trim()
            End If

            cols.Add(New column(i - 1, name, label))

        Next

    End Sub

End Module
