﻿
Imports System.IO
Imports VFSmodCMD.Common


Public Class frmDialog


    Public Sub New()

        ' Dieser Aufruf ist für den Designer erforderlich.
        InitializeComponent()

        ' Fügen Sie Initialisierungen nach dem InitializeComponent()-Aufruf hinzu.

        SelectSWASHProjectPath()

    End Sub

    Public Property Swan2VFSmodGUI As New VFSmodCMD.Swan2VFSmodGUI

    Public Property TOXSWAInfo As New VFSmodCMD.TOXSWAInfo

    Public Property CheckedByProgramm As Boolean = False

    Public Property Swash34Switch As Boolean = True

    Private Sub lblSelectSWASHProjectPath_Click(sender As System.Object,
                                                e As System.EventArgs)


        SelectSWASHProjectPath()

    End Sub

    Public Sub SelectSWASHProjectPath()


        Dim myFBD As New FolderBrowserDialog
        Dim PRZM As String() = {}
     
        resetScenario()

        CheckedByProgramm = True

        With myFBD

            .Description = "Select 'SWASHProject' path"

            .ShowNewFolderButton = True

            If Directory.Exists("C:\SwashProjects") Then
                .SelectedPath = "C:\SwashProjects"
            End If

            '''''''''''''''''''''''' Test
            .SelectedPath = "Z:\000 - special\VFSMOD\WDT\CMP01Late"

            If .ShowDialog = DialogResult.OK Then

                If Not Directory.Exists(Path.Combine(.SelectedPath, "PRZM")) Then

                    MsgBox("No valid SWASH project path selected",
                           MsgBoxStyle.Critical,
                           " Can't find '" & Path.Combine(.SelectedPath, "PRZM") & "'")

                    CheckedByProgramm = False

                Else

                    '******************* Season ***********************
                    Try

                        PRZM = Directory.GetFiles(.SelectedPath,
                                                  "przm.pzm",
                                                  SearchOption.AllDirectories)

                        If PRZM.Count = 0 Then
                            MsgBox("No valid SWASH project path selected",
                                    MsgBoxStyle.Critical,
                                    " Can't find  'przm.pzm' in '" &
                                    Path.Combine(.SelectedPath, "PRZM") & "'")

                            CheckedByProgramm = False
                            Exit Sub

                        ElseIf PRZM.Count = 1 Then

                            'only 2nd season
                            If PRZM(0).Contains("_2nd\") Then

                                With rbtn2nd
                                    .Checked = True
                                    .Enabled = True
                                    .ForeColor = Color.Black
                                End With

                                With rbtn1st
                                    .Checked = False
                                    .Enabled = False
                                    .ForeColor = Color.Gray
                                End With

                            Else

                                'just 1st season
                                With rbtn1st
                                    .Checked = True
                                    .Enabled = True
                                    .ForeColor = Color.Black
                                End With

                                With rbtn2nd
                                    .Checked = False
                                    .Enabled = False
                                    .ForeColor = Color.Gray
                                End With

                            End If

                        ElseIf PRZM.Count = 2 Then

                            'both seasons
                            With rbtn1st
                                .Checked = True
                                .Enabled = True
                                .ForeColor = Color.Black
                            End With

                            With rbtn2nd
                                .Checked = False
                                .Enabled = True
                                .ForeColor = Color.Black
                            End With

                        Else

                            MsgBox("Unexpected error, more than 2 'przm.pzm' files",
                                   MsgBoxStyle.Critical,
                                   "Selected path : " & Path.Combine(.SelectedPath, "PRZM"))

                            CheckedByProgramm = False
                            Exit Sub

                        End If


                        '******************* Par/Met *********************** 

                        If Directory.GetFiles(Path.GetDirectoryName(PRZM(0)), "*.P2T").Count = 0 Then
                            'no przm->toxswa results avail.
                            MsgBox("Can't find *.p2t files in selected path",
                                  MsgBoxStyle.Critical,
                                  "Selected SWASH project path : " & .SelectedPath)

                            CheckedByProgramm = False
                            Exit Sub

                        End If

                        With rbtnParent
                            .Checked = True
                            .Enabled = True
                            .ForeColor = Color.Black
                        End With

                        With rbtnMetabolite

                            .Checked = False

                            If Directory.GetFiles(Path.GetDirectoryName(PRZM(0)), "*-C2.P2T").Count <> 0 Then

                                'met avail.
                                .Enabled = True
                                .ForeColor = Color.Black

                            Else

                                'no met avail. => parent only
                                .Enabled = False
                                .ForeColor = Color.Gray

                            End If

                        End With

                        'set przm master path initial to 1st season
                        lblSWASHProjectPath.Text = .SelectedPath

                        btnOK.Enabled = True
                        btnOK.ForeColor = Color.Black

                    Catch ex As Exception

                        MsgBox("Unexpected error" & vbCrLf & ex.Message,
                                  MsgBoxStyle.Critical,
                                  "Selected path : " & Path.Combine(.SelectedPath, "PRZM"))
                        lblSWASHProjectPath.Text = ""
                        CheckedByProgramm = False

                    End Try

                End If

            Else

                'canceld by user

            End If

        End With

        CheckedByProgramm = False

        activateAvailScenarios()

    End Sub

    Public Sub resubmitScenario()

        If rbtnR1.Checked Then

            rbtnR1.Checked = False
            rbtnR1.Checked = True

        ElseIf rbtnR2.Checked Then

            rbtnR2.Checked = False
            rbtnR2.Checked = True

        ElseIf rbtnR3.Checked Then

            rbtnR3.Checked = False
            rbtnR3.Checked = True

        ElseIf rbtnR4.Checked Then

            rbtnR4.Checked = False
            rbtnR4.Checked = True

        End If

    End Sub

    Public Sub resetScenario()

        CheckedByProgramm = True

       
        With rbtnR1
            .Enabled = False
            .ForeColor = Color.Gray
            .Checked = False
        End With

        With rbtnR2
            .Enabled = False
            .ForeColor = Color.Gray
            .Checked = False
        End With

        With rbtnR3
            .Enabled = False
            .ForeColor = Color.Gray
            .Checked = False
        End With

        With rbtnR4
            .Enabled = False
            .ForeColor = Color.Gray
            .Checked = False
        End With

        CheckedByProgramm = False

    End Sub


    Public Sub activateAvailScenarios(Optional ByVal Scenario As String = "")

        Dim TestChecked As Boolean = False

        CheckedByProgramm = True


        If rbtnR1.Checked OrElse
           rbtnR2.Checked OrElse
           rbtnR3.Checked OrElse
           rbtnR4.Checked Then

            TestChecked = True

        End If


        For Counter As Integer = 4 To 1 Step -1

            If fillPaths("R" & Counter) Then

                With btnOK
                    .Enabled = True
                    .ForeColor = Color.Black
                End With

                Select Case Counter

                    Case 1
                        With rbtnR1
                            .Enabled = True
                            .ForeColor = Color.Black
                            If Not TestChecked Then .Checked = True
                        End With
                    Case 2
                        With rbtnR2
                            .Enabled = True
                            .ForeColor = Color.Black
                            If Not TestChecked Then .Checked = True
                        End With
                    Case 3
                        With rbtnR3
                            .Enabled = True
                            .ForeColor = Color.Black
                            If Not TestChecked Then .Checked = True
                        End With
                    Case 4
                        With rbtnR4
                            .Enabled = True
                            .ForeColor = Color.Black
                            If Not TestChecked Then .Checked = True
                        End With

                End Select

            Else

                With btnOK
                    .Enabled = False
                    .ForeColor = Color.Gray
                End With

                Select Case Counter

                    Case 1
                        With rbtnR1
                            .Enabled = False
                            .ForeColor = Color.Gray
                            .Checked = False
                        End With
                    Case 2
                        With rbtnR2
                            .Enabled = False
                            .ForeColor = Color.Gray
                            .Checked = False
                        End With
                    Case 3
                        With rbtnR3
                            .Enabled = False
                            .ForeColor = Color.Gray
                            .Checked = False
                        End With
                    Case 4
                        With rbtnR4
                            .Enabled = False
                            .ForeColor = Color.Gray
                            .Checked = False
                        End With

                End Select


            End If

        Next


        If rbtnR1.Checked OrElse
           rbtnR2.Checked OrElse
           rbtnR3.Checked OrElse
           rbtnR4.Checked Then


            With btnOK
                .Enabled = True
                .ForeColor = Color.Black
            End With

        End If


        If Scenario <> "" Then fillPaths(Scenario)

    End Sub

    Public Function fillPaths(Optional ByVal Scenario As String = "") As Boolean

        Dim PRZMFileArray As String() = {}
        Dim ScenarioNo As String = ""

        Dim ParMetString As String = ""
        Dim WaterBodyString = ""
        Dim SeasonString As String = ""

        Dim PRZM As String() = {}
        Dim TargetPath As String = ""

        Dim ScenarioString As String = ""

        CheckedByProgramm = True

        If Not Directory.Exists(lblSWASHProjectPath.Text) Then

            CheckedByProgramm = False
            Return False

        End If


        If rbtnParent.Checked Then
            ParMetString = "-C1.P2T"
        ElseIf rbtnMetabolite.Checked Then
            ParMetString = "-C2.P2T"
        Else
            CheckedByProgramm = False
            Return False
        End If

        Try

            PRZM = Directory.GetFiles(lblSWASHProjectPath.Text,
                                      "przm.pzm",
                                      SearchOption.AllDirectories)

            If PRZM.Count = 0 Then

                MsgBox("No valid SWASH project path selected",
                        MsgBoxStyle.Critical,
                        "Can't find  'przm.pzm' in '" &
                        Path.Combine(lblSWASHProjectPath.Text, "PRZM") & "'")

                CheckedByProgramm = False
                Return False

            End If

        Catch ex As Exception
            MsgBox("No valid SWASH project path selected",
                   MsgBoxStyle.Critical,
                   "Can't find  'przm.pzm' in '" &
                   Path.Combine(lblSWASHProjectPath.Text, "PRZM") & "'")

            CheckedByProgramm = False
            Return False

        End Try

        Try
            If rbtn1st.Checked Then
                TargetPath = Path.GetDirectoryName(PRZM.First)
            ElseIf rbtn2nd.Checked Then
                TargetPath = Path.GetDirectoryName(PRZM.Last)
            Else
                CheckedByProgramm = False
                Return False
            End If
        Catch ex As Exception
            Return False
        End Try

        If Scenario <> "" Then
            ScenarioString = Scenario
        Else
            Try
                If rbtnR1.Checked Then
                    ScenarioString = "R1"
                ElseIf rbtnR2.Checked Then
                    ScenarioString = "R2"
                ElseIf rbtnR3.Checked Then
                    ScenarioString = "R3"
                ElseIf rbtnR2.Checked Then
                    ScenarioString = "R4"
                Else
                    CheckedByProgramm = False
                    Return False
                End If
            Catch ex As Exception
                CheckedByProgramm = False
                Return False
            End Try

        End If

        With frmVFSmodGUI.TempSWAN2VFSmodGUI.Paths

            Try

                .ztsFilePath = Directory.GetFiles(TargetPath, ScenarioString & "*.zts").First
                If Not File.Exists(.ztsFilePath) Then
                    CheckedByProgramm = False
                    Return False
                End If
                lblZTS.Text = Replace(.ztsFilePath, lblSWASHProjectPath.Text, ".")

                .inpFilePath = Directory.GetFiles(TargetPath, ScenarioString & "*.inp").First
                If Not File.Exists(.inpFilePath) Then
                    CheckedByProgramm = False
                    Return False
                End If
                lblINP.Text = Replace(.inpFilePath, lblSWASHProjectPath.Text, ".")


                PRZMFileArray = File.ReadAllLines(Path.Combine(TargetPath, "przm.pzm"))
                ScenarioNo = Filter(PRZMFileArray, ScenarioString & "=").First
                ScenarioNo = Replace(ScenarioNo, ScenarioString & "=", "")

                .p2tFilePath = Path.Combine(TargetPath, ScenarioNo & ParMetString)
                If Not File.Exists(.p2tFilePath) Then
                    CheckedByProgramm = False
                    Return False
                End If
                lblP2T.Text = Replace(.p2tFilePath, lblSWASHProjectPath.Text, ".")


                If rbtnParent.Checked Then
                    ParMetString = "pa."
                ElseIf rbtnMetabolite.Checked Then
                    ParMetString = "m1."
                Else
                    CheckedByProgramm = False
                    Return False
                End If

                If rbtnStream.Checked = True Then
                    WaterBodyString = "s_"
                ElseIf rbtnPond.Checked Then
                    WaterBodyString = "p_"
                Else
                    CheckedByProgramm = False
                    Return False
                End If

                With frmVFSmodGUI.TempTOXSWAInfo

                    .origTXWFilePath = Path.Combine(lblSWASHProjectPath.Text, "TOXSWA")

                    If Swash34Switch Then
                        .origTXWFilePath &= "\" & CType(Integer.Parse(ScenarioNo), String) & ".txw"
                    Else
                        .origTXWFilePath &= "\" &
                           ScenarioNo & WaterBodyString & ParMetString & "txw"

                    End If


                    If Not File.Exists(.origTXWFilePath) Then
                        'ToDo Changed for swash 4
                        CheckedByProgramm = False
                        Return False
                    End If
                    lblTXW.Text = Replace(.origTXWFilePath, lblSWASHProjectPath.Text, ".")

                End With

                frmVFSmodGUI.TempSWAN2VFSmodGUI.GeneralInfo.FOCUSScenario =
                        CType([Enum].Parse(
                              GetType(VFSmodCMD.Common.eFOCUSScenarios),
                              ScenarioString.Substring(0, 2)), 
                              VFSmodCMD.Common.eFOCUSScenarios)

            Catch ex As Exception
                CheckedByProgramm = False
                Return False
            End Try

        End With

        CheckedByProgramm = False
        Return True

    End Function
   
    Private Sub rbtnParent_CheckedChanged(ByVal sender As System.Object,
                                          ByVal e As System.EventArgs) _
                                      Handles rbtnParent.CheckedChanged, rbtnMetabolite.CheckedChanged

        With frmVFSmodGUI.TempSWAN2VFSmodGUI.GeneralInfo
            If rbtnParent.Checked Then
                .ParMet = eParMet.Parent
            Else
                .ParMet = eParMet.Metabolite
            End If
        End With


        If CheckedByProgramm = True Then Exit Sub

        If rbtnR1.Checked Then

            activateAvailScenarios("R1")

        ElseIf rbtnR2.Checked Then

            activateAvailScenarios("R2")

        ElseIf rbtnR3.Checked Then

            activateAvailScenarios("R3")

        ElseIf rbtnR4.Checked Then

            activateAvailScenarios("R4")

        End If

        resubmitScenario()

    End Sub

    Private Sub rbtn1st_CheckedChanged(ByVal sender As System.Object,
                                       ByVal e As System.EventArgs) _
                                   Handles rbtn1st.CheckedChanged, rbtn2nd.CheckedChanged

        If CheckedByProgramm = True Then Exit Sub
        activateAvailScenarios()

        resubmitScenario()

    End Sub

    Private Sub rbtnR1_CheckedChanged(ByVal sender As System.Object,
                                      ByVal e As System.EventArgs) _
                                  Handles rbtnR1.CheckedChanged,
                                  rbtnR2.CheckedChanged,
                                  rbtnR3.CheckedChanged,
                                  rbtnR4.CheckedChanged

        If CheckedByProgramm = True Then Exit Sub

        If rbtnR1.Checked Then
            With rbtnPond
                .Enabled = True
                .ForeColor = Color.Black
            End With
        Else
            With rbtnPond
                .Enabled = False
                .ForeColor = Color.Gray
            End With
        End If


        If rbtnR1.Checked Then

            fillPaths("R1")
            frmVFSmodGUI.TempTOXSWAInfo.TOXSWAmetFilePath = Path.Combine(ExecPath, "Weiherbach.met")

        ElseIf rbtnR2.Checked Then

            fillPaths("R2")
            frmVFSmodGUI.TempTOXSWAInfo.TOXSWAmetFilePath = Path.Combine(ExecPath, "Porto.met")

        ElseIf rbtnR3.Checked Then

            fillPaths("R3")
            frmVFSmodGUI.TempTOXSWAInfo.TOXSWAmetFilePath = Path.Combine(ExecPath, "Bologna.met")

        ElseIf rbtnR4.Checked Then

            fillPaths("R4")
            frmVFSmodGUI.TempTOXSWAInfo.TOXSWAmetFilePath = Path.Combine(ExecPath, "Roujan.met")

        End If


    End Sub

    Private Sub rbtnStream_CheckedChanged(sender As System.Object,
                                          e As System.EventArgs) _
                                      Handles rbtnStream.CheckedChanged, rbtnPond.CheckedChanged

        If CheckedByProgramm = True Then Exit Sub


        With frmVFSmodGUI.TempSWAN2VFSmodGUI.GeneralInfo
            If rbtnStream.Checked Then
                .FOCUSWaterBody = eRWB.Stream
            Else
                .FOCUSWaterBody = eRWB.Pond
            End If
        End With

        If rbtnR1.Checked Then

            activateAvailScenarios("R1")

        ElseIf rbtnR2.Checked Then

            activateAvailScenarios("R2")

        ElseIf rbtnR3.Checked Then

            activateAvailScenarios("R3")

        ElseIf rbtnR4.Checked Then

            activateAvailScenarios("R4")

        End If

        resubmitScenario()

    End Sub


    Private Sub btnOK_Click(ByVal sender As System.Object,
                            ByVal e As System.EventArgs) Handles btnOK.Click

        Dim workdir As String = ""
        Dim origCWA As String = ""

        'set workdir
        With frmVFSmodGUI.TempSWAN2VFSmodGUI
            workdir = Path.Combine(lblSWASHProjectPath.Text, "VFSmod",
                                  .GeneralInfo.FOCUSScenario.ToString,
                                   Me.nudBufferStripLength.Value.ToString & "m")

            Try
                If Directory.Exists(workdir) Then

                    If Directory.GetFiles(workdir, "*").Count <> 0 Then
                        workdir &= Format(Now, "hhmmss")
                    End If

                Else
                    My.Computer.FileSystem.CreateDirectory(directory:=workdir)

                End If
            Catch ex As Exception
                MsgBox("Can't set Working directory to " & workdir & vbCrLf & "Please set dir manually!", MsgBoxStyle.Exclamation)
            End Try

            .Paths.VFSmodGUI2SwanPath = workdir
            .GeneralInfo.BufferStripLen = nudBufferStripLength.Value

        End With

        With frmVFSmodGUI.TempTOXSWAInfo

            .WorkingDirectory = workdir
            .NewP2TFilePath = ""
            .newTXWFilePath = ""

        End With

        Me.DialogResult = Windows.Forms.DialogResult.OK
        Me.Close()

    End Sub


    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click

        Me.DialogResult = Windows.Forms.DialogResult.Cancel
        Me.Close()

    End Sub

   
End Class