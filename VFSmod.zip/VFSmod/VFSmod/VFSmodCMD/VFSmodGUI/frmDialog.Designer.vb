﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDialog
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblSWASHProjectPath = New System.Windows.Forms.Label()
        Me.gbxParMet = New System.Windows.Forms.GroupBox()
        Me.rbtnMetabolite = New System.Windows.Forms.RadioButton()
        Me.rbtnParent = New System.Windows.Forms.RadioButton()
        Me.gbx1st2ndSeason = New System.Windows.Forms.GroupBox()
        Me.rbtn2nd = New System.Windows.Forms.RadioButton()
        Me.rbtn1st = New System.Windows.Forms.RadioButton()
        Me.gbxScenario = New System.Windows.Forms.GroupBox()
        Me.rbtnR4 = New System.Windows.Forms.RadioButton()
        Me.rbtnR3 = New System.Windows.Forms.RadioButton()
        Me.rbtnR2 = New System.Windows.Forms.RadioButton()
        Me.rbtnR1 = New System.Windows.Forms.RadioButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.nudBufferStripLength = New System.Windows.Forms.NumericUpDown()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.gbxWB = New System.Windows.Forms.GroupBox()
        Me.rbtnPond = New System.Windows.Forms.RadioButton()
        Me.rbtnStream = New System.Windows.Forms.RadioButton()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblINP = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblP2T = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblTXW = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblZTS = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.gbxParMet.SuspendLayout()
        Me.gbx1st2ndSeason.SuspendLayout()
        Me.gbxScenario.SuspendLayout()
        CType(Me.nudBufferStripLength, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbxWB.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblSWASHProjectPath
        '
        Me.lblSWASHProjectPath.AutoSize = True
        Me.lblSWASHProjectPath.Enabled = False
        Me.lblSWASHProjectPath.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSWASHProjectPath.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblSWASHProjectPath.Location = New System.Drawing.Point(114, 33)
        Me.lblSWASHProjectPath.Name = "lblSWASHProjectPath"
        Me.lblSWASHProjectPath.Size = New System.Drawing.Size(92, 13)
        Me.lblSWASHProjectPath.TabIndex = 0
        Me.lblSWASHProjectPath.Text = "C:\SwashProjects"
        '
        'gbxParMet
        '
        Me.gbxParMet.Controls.Add(Me.rbtnMetabolite)
        Me.gbxParMet.Controls.Add(Me.rbtnParent)
        Me.gbxParMet.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbxParMet.Location = New System.Drawing.Point(12, 12)
        Me.gbxParMet.Name = "gbxParMet"
        Me.gbxParMet.Size = New System.Drawing.Size(199, 45)
        Me.gbxParMet.TabIndex = 2
        Me.gbxParMet.TabStop = False
        Me.gbxParMet.Text = "Parent or Metabolite run"
        '
        'rbtnMetabolite
        '
        Me.rbtnMetabolite.AutoSize = True
        Me.rbtnMetabolite.Enabled = False
        Me.rbtnMetabolite.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtnMetabolite.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.rbtnMetabolite.Location = New System.Drawing.Point(101, 19)
        Me.rbtnMetabolite.Name = "rbtnMetabolite"
        Me.rbtnMetabolite.Size = New System.Drawing.Size(74, 17)
        Me.rbtnMetabolite.TabIndex = 1
        Me.rbtnMetabolite.TabStop = True
        Me.rbtnMetabolite.Text = "Metabolite"
        Me.rbtnMetabolite.UseVisualStyleBackColor = True
        '
        'rbtnParent
        '
        Me.rbtnParent.AutoSize = True
        Me.rbtnParent.Enabled = False
        Me.rbtnParent.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtnParent.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.rbtnParent.Location = New System.Drawing.Point(17, 19)
        Me.rbtnParent.Name = "rbtnParent"
        Me.rbtnParent.Size = New System.Drawing.Size(56, 17)
        Me.rbtnParent.TabIndex = 0
        Me.rbtnParent.TabStop = True
        Me.rbtnParent.Text = "Parent"
        Me.rbtnParent.UseVisualStyleBackColor = True
        '
        'gbx1st2ndSeason
        '
        Me.gbx1st2ndSeason.Controls.Add(Me.rbtn2nd)
        Me.gbx1st2ndSeason.Controls.Add(Me.rbtn1st)
        Me.gbx1st2ndSeason.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbx1st2ndSeason.Location = New System.Drawing.Point(12, 63)
        Me.gbx1st2ndSeason.Name = "gbx1st2ndSeason"
        Me.gbx1st2ndSeason.Size = New System.Drawing.Size(199, 45)
        Me.gbx1st2ndSeason.TabIndex = 3
        Me.gbx1st2ndSeason.TabStop = False
        Me.gbx1st2ndSeason.Text = "Crop Season"
        '
        'rbtn2nd
        '
        Me.rbtn2nd.AutoSize = True
        Me.rbtn2nd.Enabled = False
        Me.rbtn2nd.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtn2nd.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.rbtn2nd.Location = New System.Drawing.Point(101, 19)
        Me.rbtn2nd.Name = "rbtn2nd"
        Me.rbtn2nd.Size = New System.Drawing.Size(82, 17)
        Me.rbtn2nd.TabIndex = 1
        Me.rbtn2nd.TabStop = True
        Me.rbtn2nd.Text = "2nd Season"
        Me.rbtn2nd.UseVisualStyleBackColor = True
        '
        'rbtn1st
        '
        Me.rbtn1st.AutoSize = True
        Me.rbtn1st.Enabled = False
        Me.rbtn1st.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtn1st.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.rbtn1st.Location = New System.Drawing.Point(17, 19)
        Me.rbtn1st.Name = "rbtn1st"
        Me.rbtn1st.Size = New System.Drawing.Size(78, 17)
        Me.rbtn1st.TabIndex = 0
        Me.rbtn1st.TabStop = True
        Me.rbtn1st.Text = "1st Season"
        Me.rbtn1st.UseVisualStyleBackColor = True
        '
        'gbxScenario
        '
        Me.gbxScenario.Controls.Add(Me.rbtnR4)
        Me.gbxScenario.Controls.Add(Me.rbtnR3)
        Me.gbxScenario.Controls.Add(Me.rbtnR2)
        Me.gbxScenario.Controls.Add(Me.rbtnR1)
        Me.gbxScenario.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbxScenario.Location = New System.Drawing.Point(252, 12)
        Me.gbxScenario.Name = "gbxScenario"
        Me.gbxScenario.Size = New System.Drawing.Size(159, 150)
        Me.gbxScenario.TabIndex = 4
        Me.gbxScenario.TabStop = False
        Me.gbxScenario.Text = "Runoff Scenario"
        '
        'rbtnR4
        '
        Me.rbtnR4.AutoSize = True
        Me.rbtnR4.Enabled = False
        Me.rbtnR4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtnR4.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.rbtnR4.Location = New System.Drawing.Point(18, 121)
        Me.rbtnR4.Name = "rbtnR4"
        Me.rbtnR4.Size = New System.Drawing.Size(88, 17)
        Me.rbtnR4.TabIndex = 3
        Me.rbtnR4.TabStop = True
        Me.rbtnR4.Text = "R4   (Roujan)"
        Me.rbtnR4.UseVisualStyleBackColor = True
        '
        'rbtnR3
        '
        Me.rbtnR3.AutoSize = True
        Me.rbtnR3.Enabled = False
        Me.rbtnR3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtnR3.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.rbtnR3.Location = New System.Drawing.Point(18, 88)
        Me.rbtnR3.Name = "rbtnR3"
        Me.rbtnR3.Size = New System.Drawing.Size(93, 17)
        Me.rbtnR3.TabIndex = 2
        Me.rbtnR3.TabStop = True
        Me.rbtnR3.Text = "R3   (Bologna)"
        Me.rbtnR3.UseVisualStyleBackColor = True
        '
        'rbtnR2
        '
        Me.rbtnR2.AutoSize = True
        Me.rbtnR2.Enabled = False
        Me.rbtnR2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtnR2.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.rbtnR2.Location = New System.Drawing.Point(18, 51)
        Me.rbtnR2.Name = "rbtnR2"
        Me.rbtnR2.Size = New System.Drawing.Size(79, 17)
        Me.rbtnR2.TabIndex = 1
        Me.rbtnR2.TabStop = True
        Me.rbtnR2.Text = "R2   (Porto)"
        Me.rbtnR2.UseVisualStyleBackColor = True
        '
        'rbtnR1
        '
        Me.rbtnR1.AutoSize = True
        Me.rbtnR1.Enabled = False
        Me.rbtnR1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtnR1.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.rbtnR1.Location = New System.Drawing.Point(18, 19)
        Me.rbtnR1.Name = "rbtnR1"
        Me.rbtnR1.Size = New System.Drawing.Size(112, 17)
        Me.rbtnR1.TabIndex = 0
        Me.rbtnR1.TabStop = True
        Me.rbtnR1.Text = "R1   (Weiherbach)"
        Me.rbtnR1.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(15, 174)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(129, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Buffer strip length (m)"
        '
        'nudBufferStripLength
        '
        Me.nudBufferStripLength.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.nudBufferStripLength.Location = New System.Drawing.Point(150, 172)
        Me.nudBufferStripLength.Name = "nudBufferStripLength"
        Me.nudBufferStripLength.Size = New System.Drawing.Size(61, 20)
        Me.nudBufferStripLength.TabIndex = 6
        Me.nudBufferStripLength.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'btnOK
        '
        Me.btnOK.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.btnOK.Enabled = False
        Me.btnOK.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.btnOK.Location = New System.Drawing.Point(320, 413)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(91, 24)
        Me.btnOK.TabIndex = 8
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'gbxWB
        '
        Me.gbxWB.Controls.Add(Me.rbtnPond)
        Me.gbxWB.Controls.Add(Me.rbtnStream)
        Me.gbxWB.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbxWB.Location = New System.Drawing.Point(12, 115)
        Me.gbxWB.Name = "gbxWB"
        Me.gbxWB.Size = New System.Drawing.Size(199, 47)
        Me.gbxWB.TabIndex = 9
        Me.gbxWB.TabStop = False
        Me.gbxWB.Text = "Waterbody"
        '
        'rbtnPond
        '
        Me.rbtnPond.AutoSize = True
        Me.rbtnPond.Enabled = False
        Me.rbtnPond.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtnPond.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.rbtnPond.Location = New System.Drawing.Point(101, 18)
        Me.rbtnPond.Name = "rbtnPond"
        Me.rbtnPond.Size = New System.Drawing.Size(50, 17)
        Me.rbtnPond.TabIndex = 1
        Me.rbtnPond.Text = "Pond"
        Me.rbtnPond.UseVisualStyleBackColor = True
        '
        'rbtnStream
        '
        Me.rbtnStream.AutoSize = True
        Me.rbtnStream.Checked = True
        Me.rbtnStream.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtnStream.Location = New System.Drawing.Point(15, 19)
        Me.rbtnStream.Name = "rbtnStream"
        Me.rbtnStream.Size = New System.Drawing.Size(58, 17)
        Me.rbtnStream.TabIndex = 0
        Me.rbtnStream.TabStop = True
        Me.rbtnStream.Text = "Stream"
        Me.rbtnStream.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Enabled = False
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label2.Location = New System.Drawing.Point(12, 65)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 13)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "PRZM input"
        '
        'lblINP
        '
        Me.lblINP.AutoSize = True
        Me.lblINP.Enabled = False
        Me.lblINP.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblINP.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblINP.Location = New System.Drawing.Point(114, 65)
        Me.lblINP.Name = "lblINP"
        Me.lblINP.Size = New System.Drawing.Size(28, 13)
        Me.lblINP.TabIndex = 11
        Me.lblINP.Text = "*.inp"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.lblP2T)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.lblTXW)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.lblZTS)
        Me.GroupBox1.Controls.Add(Me.lblINP)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.lblSWASHProjectPath)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 220)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(399, 169)
        Me.GroupBox1.TabIndex = 14
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Path info"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Enabled = False
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label7.Location = New System.Drawing.Point(12, 33)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(83, 13)
        Me.Label7.TabIndex = 19
        Me.Label7.Text = "SWASH Project"
        '
        'lblP2T
        '
        Me.lblP2T.AutoSize = True
        Me.lblP2T.Enabled = False
        Me.lblP2T.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblP2T.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblP2T.Location = New System.Drawing.Point(115, 136)
        Me.lblP2T.Name = "lblP2T"
        Me.lblP2T.Size = New System.Drawing.Size(29, 13)
        Me.lblP2T.TabIndex = 18
        Me.lblP2T.Text = "*.p2t"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Enabled = False
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label6.Location = New System.Drawing.Point(12, 136)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(97, 13)
        Me.Label6.TabIndex = 17
        Me.Label6.Text = "PRZM ->TOXSWA"
        '
        'lblTXW
        '
        Me.lblTXW.AutoSize = True
        Me.lblTXW.Enabled = False
        Me.lblTXW.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTXW.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblTXW.Location = New System.Drawing.Point(115, 113)
        Me.lblTXW.Name = "lblTXW"
        Me.lblTXW.Size = New System.Drawing.Size(30, 13)
        Me.lblTXW.TabIndex = 16
        Me.lblTXW.Text = "*.txw"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Enabled = False
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label5.Location = New System.Drawing.Point(12, 113)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(80, 13)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "TOXSWA input"
        '
        'lblZTS
        '
        Me.lblZTS.AutoSize = True
        Me.lblZTS.Enabled = False
        Me.lblZTS.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZTS.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblZTS.Location = New System.Drawing.Point(115, 88)
        Me.lblZTS.Name = "lblZTS"
        Me.lblZTS.Size = New System.Drawing.Size(27, 13)
        Me.lblZTS.TabIndex = 14
        Me.lblZTS.Text = "*.zts"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Enabled = False
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label4.Location = New System.Drawing.Point(12, 88)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(71, 13)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "PRZM output"
        '
        'btnCancel
        '
        Me.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.Location = New System.Drawing.Point(209, 413)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(91, 24)
        Me.btnCancel.TabIndex = 15
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'frmDialog
        '
        Me.AcceptButton = Me.btnOK
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnCancel
        Me.ClientSize = New System.Drawing.Size(423, 449)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.gbxWB)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.nudBufferStripLength)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.gbxScenario)
        Me.Controls.Add(Me.gbx1st2ndSeason)
        Me.Controls.Add(Me.gbxParMet)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmDialog"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Easy selection dialog"
        Me.gbxParMet.ResumeLayout(False)
        Me.gbxParMet.PerformLayout()
        Me.gbx1st2ndSeason.ResumeLayout(False)
        Me.gbx1st2ndSeason.PerformLayout()
        Me.gbxScenario.ResumeLayout(False)
        Me.gbxScenario.PerformLayout()
        CType(Me.nudBufferStripLength, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbxWB.ResumeLayout(False)
        Me.gbxWB.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblSWASHProjectPath As System.Windows.Forms.Label
    Friend WithEvents gbxParMet As System.Windows.Forms.GroupBox
    Friend WithEvents rbtnMetabolite As System.Windows.Forms.RadioButton
    Friend WithEvents rbtnParent As System.Windows.Forms.RadioButton
    Friend WithEvents gbx1st2ndSeason As System.Windows.Forms.GroupBox
    Friend WithEvents rbtn2nd As System.Windows.Forms.RadioButton
    Friend WithEvents rbtn1st As System.Windows.Forms.RadioButton
    Friend WithEvents gbxScenario As System.Windows.Forms.GroupBox
    Friend WithEvents rbtnR4 As System.Windows.Forms.RadioButton
    Friend WithEvents rbtnR3 As System.Windows.Forms.RadioButton
    Friend WithEvents rbtnR2 As System.Windows.Forms.RadioButton
    Friend WithEvents rbtnR1 As System.Windows.Forms.RadioButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents nudBufferStripLength As System.Windows.Forms.NumericUpDown
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents gbxWB As System.Windows.Forms.GroupBox
    Friend WithEvents rbtnPond As System.Windows.Forms.RadioButton
    Friend WithEvents rbtnStream As System.Windows.Forms.RadioButton
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblINP As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents lblP2T As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lblTXW As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lblZTS As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnCancel As System.Windows.Forms.Button
End Class
