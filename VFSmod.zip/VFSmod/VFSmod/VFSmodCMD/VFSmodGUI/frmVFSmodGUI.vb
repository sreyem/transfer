﻿
Imports VFSmodGUI.PGridTools
Imports VFSmodGUI.ToolsXML
Imports VFSmodCMD

Imports System.IO
Imports VFSmodCMD.Common

Public Class frmVFSmodGUI

    Public Property VFSmod As New VFSmod
    Public Property PRZMEvent2Show As New P2TEvent
    Public Property VFSmodInputFileset As New VFSmodInputFilesSet

#Region "Constructor and Init"

    Public Sub New()

        ' Dieser Aufruf ist für den Designer erforderlich.
        InitializeComponent()

        ' Fügen Sie Initialisierungen nach dem InitializeComponent()-Aufruf hinzu.

        'If Now > New Date(year:=2020, month:=12, day:=31) Then
        '    MsgBox("Version outdated")
        '    End
        'End If


        init()
        fillPGrid()

    End Sub

    Public Sub init()

        initPGrid(Me.PGrid)

        Me.Text = "VFSmodGUI v." & My.Application.Info.Version.ToString

        VFSmodCMD.Common.rtblog = Me.rtbLog

    End Sub

    Public Sub fillPGrid()

        Me.PGrid.Item.Clear()

        With Me.PGrid

            .Item.Add("Open 'EasySelect' form",
                      "Click here for dialog", False,
                      "VFSmodGUI inputs",
                      "Dialog for getting user inputs", True)
            .Item(.Item.Count - 1).OnClick = AddressOf Me.getVFSmodGeneralInputs

        End With

        AddClass2PGrid(Class2Add:=Me.VFSmod.ScenarioUserInput.StdValues,
                           PGrid:=Me.PGrid,
                        Category:="Scenario User Input",
                            Name:="StdValues",
                     Description:="StdValues des")


        AddClass2PGrid(Class2Add:=Me.VFSmod.ScenarioUserInput.ScenarioProperties,
                          PGrid:=Me.PGrid,
                       Category:="Scenario User Input",
                           Name:="ScenarioProperties",
                    Description:="ScenarioProperties des")

        AddClass2PGrid(Class2Add:=Me.VFSmod.ScenarioUserInput.CompoundProperties,
                         PGrid:=Me.PGrid,
                      Category:="Scenario User Input",
                          Name:="CompoundProperties",
                   Description:="CompoundProperties des")


        AddClass2PGrid(Class2Add:=Me.VFSmod.TOXSWArun,
                        PGrid:=Me.PGrid,
                     Category:="VFSmodGUI inputs",
                         Name:="TOXSWA Settings",
                  Description:="TOXSWA Settings")

        Me.PGrid.Refresh()

    End Sub

#End Region

#Region "VFSmodGUI Inputs"

    Dim Scenarios As String() = New String() {"R1", "R2", "R3", "R4"}
    Dim Info As String() = {}

    Public Property TempSWAN2VFSmodGUI As New Swan2VFSmodGUI
    Public Property TempTOXSWAInfo As New TOXSWAInfo

    Public Function getVFSmodGeneralInputs(ByVal sender As Object,
                                           ByVal e As EventArgs) As Object


        Dim workdir As String = ""
        Dim ItemNo As Integer = 0

        TempSWAN2VFSmodGUI = New Swan2VFSmodGUI
        TempTOXSWAInfo = New TOXSWAInfo

        If frmDialog.ShowDialog(Me) <> Windows.Forms.DialogResult.OK Then
            Return Nothing
        End If

        frmDialog = Nothing
        

        VFSmod.ScenarioUserInput.StdValues.VL = TempSWAN2VFSmodGUI.GeneralInfo.BufferStripLen


        'fill Swan2VFSmodGUI
        With TempSWAN2VFSmodGUI
            VFSmod.Swan2VFSmodGUI.GeneralInfo = .GeneralInfo
            VFSmod.Swan2VFSmodGUI.Paths = .Paths
        End With

        'fill TOXSWArun
        With TempTOXSWAInfo
            VFSmod.TOXSWArun.origTXWFilePath = .origTXWFilePath
            VFSmod.TOXSWArun.TOXSWAmetFilePath = .TOXSWAmetFilePath
            VFSmod.TOXSWArun.WorkingDirectory = .WorkingDirectory

            VFSmod.TOXSWArun.NewP2TFilePath = .NewP2TFilePath
            VFSmod.TOXSWArun.newTXWFilePath = .newTXWFilePath

            VFSmod.fillTOXSWArun()

        End With


        'assign scenario
        VFSmod.ScenarioUserInput.ScenarioProperties.FOCUSScenario =
            VFSmod.Swan2VFSmodGUI.GeneralInfo.FOCUSScenario

        'get comp. props from inp file
        VFSmod.ScenarioUserInput.CompoundProperties.getCompoundProperties(
            INPFileName:=VFSmod.Swan2VFSmodGUI.Paths.inpFilePath,
                 ParMet:=VFSmod.Swan2VFSmodGUI.GeneralInfo.ParMet)



        If MsgBox("Show Event Details", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then

            Try

                Dim myEventFrm As New frmEventList(VFSmod)

                myEventFrm.Show()

            Catch ex As Exception

            End Try

        End If

        'delete old pgrid entries
        Try
            With PGrid

                .Item.RemoveAt(getPGridNoByName(Me.PGrid, "Paths"))
                .Item.RemoveAt(getPGridNoByName(Me.PGrid, "General Inputs"))
            End With
        Catch ex As Exception

        End Try

        'add classes to pgrid
        AddClass2PGrid(Class2Add:=Me.VFSmod.Swan2VFSmodGUI.Paths,
                        PGrid:=Me.PGrid,
                     Category:="VFSmodGUI inputs",
                         Name:="Paths",
                  Description:="Paths to PRZM and TOXSWA in/output files")

        AddClass2PGrid(Class2Add:=Me.VFSmod.Swan2VFSmodGUI.GeneralInfo,
                        PGrid:=Me.PGrid,
                     Category:="VFSmodGUI inputs",
                         Name:="General Inputs",
                  Description:="General Inputs")

        Me.PGrid.Refresh()

        Return "OK"

    End Function


#End Region

#Region "Swan2VFSmodGUI"

    Private Sub SaveSWAN2VFSmod(sender As System.Object, e As System.EventArgs) _
        Handles tsmiSaveXMLSWAN2VFSmod.Click

        Dim mySFD As New SaveFileDialog

        With mySFD

            .Reset()
            .Title = " Select 'SWAN->VFSmod' file ( std. 'Swan2VFSmodGUI.xml')"


            .CheckPathExists = True
            .ValidateNames = True
            .SupportMultiDottedExtensions = False
            .AddExtension = True

            .DefaultExt = "xml"
            .Filter = "'SWAN->VFSmod' file (Swan2VFSmodGUI.xml)|Swan2VFSmodGUI.xml|" &
                      "All xml files (*.xml)|*.xml|" &
                      "All files (*.*)|*.*"
            .FilterIndex = 0

            If .ShowDialog = DialogResult.OK Then
                Try

                    SaveClass2XML(Class2Save:=Me.VFSmod.Swan2VFSmodGUI,
                                  ClassType:=GetType(Swan2VFSmodGUI),
                                  XMLFileName:=.FileName)

                    Me.lblStatus.Text = "'SWAN->VFSmod' file saved to " & .FileName

                Catch ex As Exception

                    Me.lblStatus.Text = ex.Message

                End Try

            Else
                Me.lblStatus.Text = "'SWAN->VFSmod' file save canceled by user"
            End If

        End With

    End Sub

    Private Sub LoadSWANVFSmod(sender As System.Object, e As System.EventArgs) _
        Handles tsmiLoadXMLSWANVFSmod.Click

        Dim myOFD As New OpenFileDialog

        With myOFD

            .Reset()
            .Title = " Select 'SWAN->VFSmod' file ( std. 'Swan2VFSmodGUI.xml')"

            .CheckFileExists = True
            .ValidateNames = True
            .SupportMultiDottedExtensions = False
            .AddExtension = True

            .DefaultExt = "xml"
            .Filter = "'SWAN->VFSmod' file (Swan2VFSmodGUI.xml)|Swan2VFSmodGUI.xml|" &
                      "All xml files (*.xml)|*.xml|" &
                      "All files (*.*)|*.*"
            .FilterIndex = 0

            If .ShowDialog = DialogResult.OK Then
                Try

                    VFSmod = New VFSmod(.FileName)
                    VFSmod.Swan2VFSmodGUI.Swan2VFSmodGUIFileName = .FileName
                    lblStatus.Text = "De-Serialized 'Swan2VFSmodGUI.xml' from " & .FileName

                Catch ex As Exception

                    Me.lblStatus.Text = ex.Message

                End Try
            End If

        End With

        fillPGrid()

        updateEventsInPGrid(eNextPrev.NextROEvent)
        'fillPRZMFiles2Form()

        Me.PGrid.Refresh()
        Me.Refresh()

    End Sub

#End Region

#Region "Scenario User Input"

    Private Sub SaveScenarioUserInput(sender As System.Object, e As System.EventArgs) _
        Handles tsmiSaveScenarioUserInput.Click

        Dim mySFD As New SaveFileDialog

        With mySFD

            .Reset()
            .Title = " Select 'Scenario user input' file (std. 'RxScenarioUserInput.xml')"


            .CheckPathExists = True

            .DefaultExt = "xml"
            .Filter = "Scenario user input file (*.xml)|*.xml|" &
                      "All files (*.*)|*.*"
            .FilterIndex = 0

            If .ShowDialog = DialogResult.OK Then

                Try
                    SaveClass2XML(VFSmod.ScenarioUserInput, GetType(ScenarioUserInput), .FileName)

                    Me.lblStatus.Text = "'Scenario user input' file saved to " & .FileName

                Catch ex As Exception

                    lblStatus.Text = ex.Message

                End Try

            Else
                Me.lblStatus.Text = "'Scenario user input' file save canceled by user"

            End If

        End With

    End Sub

    Private Sub LoadScenarioUserInput(sender As System.Object, e As System.EventArgs) _
        Handles tsmiLoadScenarioUserInput.Click

        Dim myOFD As New OpenFileDialog

        With myOFD

            .Reset()
            .Title = " Select 'Scenario user input' file (std. 'RxScenarioUserInput.xml')"


            .CheckFileExists = True

            .DefaultExt = "xml"
            .Filter = "Scenario user input file (*.xml)|*.xml|" &
                      "All files (*.*)|*.*"
            .FilterIndex = 0

            If .ShowDialog = DialogResult.OK Then

                Try

                    VFSmod.ScenarioUserInput = CType(LoadXML2Class(GetType(ScenarioUserInput), .FileName), ScenarioUserInput)
                    Me.lblStatus.Text = "'Scenario user input' file saved to " & .FileName

                    fillPGrid()


                Catch ex As Exception

                    lblStatus.Text = ex.Message

                End Try

            Else
                Me.lblStatus.Text = "'Scenario user input' file save canceled by user"

            End If

        End With



    End Sub

#End Region

#Region "TOXSWArun"

    Private Sub SaveTOXSWArun(sender As System.Object, e As System.EventArgs) _
        Handles tsmiSaveTOXSWARunInfo.Click

        Dim mySFD As New SaveFileDialog

        With mySFD

            .Reset()
            .Title = " Select 'TOXSWA run info' file (std. 'TOXSWArun.xml')"


            .CheckPathExists = True

            .DefaultExt = "xml"
            .Filter = "TOXSWArun info file (*.xml)|*.xml|" &
                      "All files (*.*)|*.*"
            .FilterIndex = 0

            If .ShowDialog = DialogResult.OK Then

                Try
                    SaveClass2XML(VFSmod.TOXSWArun, GetType(TOXSWAInfo), .FileName)

                    Me.lblStatus.Text = "'TOXSWArun info' file saved to " & .FileName

                Catch ex As Exception

                    lblStatus.Text = ex.Message

                End Try

            Else
                Me.lblStatus.Text = "'TOXSWArun info' file save canceled by user"

            End If

        End With

    End Sub

    Private Sub LoadTOXSWArun(sender As System.Object, e As System.EventArgs) _
        Handles LoadTOXSWARunInfo.Click

        Dim myOFD As New OpenFileDialog

        With myOFD

            .Reset()
            .Title = " Select 'TOXSWArun info' file (std. 'TOXSWArun.xml')"


            .CheckFileExists = True

            .DefaultExt = "xml"
            .Filter = "TOXSWArun info file (*.xml)|*.xml|" &
                      "All files (*.*)|*.*"
            .FilterIndex = 0

            If .ShowDialog = DialogResult.OK Then

                Try

                    VFSmod.TOXSWArun = CType(LoadXML2Class(GetType(TOXSWAInfo), .FileName), TOXSWAInfo)
                    Me.lblStatus.Text = "'TOXSWArun info' file saved to " & .FileName

                    fillPGrid()


                Catch ex As Exception

                    lblStatus.Text = ex.Message

                End Try

            Else
                Me.lblStatus.Text = "'TOXSWArun info' file save canceled by user"

            End If

        End With



    End Sub

#End Region

#Region "Next Prev Event"

    Public ShownEvent As Integer = -1

    Public Enum eNextPrev

        NextROEvent
        PrevROEvent

    End Enum

    Private Sub updateEventsInPGrid(NextPrev As eNextPrev)


        Dim Event2Show As Integer = 0

        If NextPrev = eNextPrev.NextROEvent Then
            Event2Show = ShownEvent + 1
        Else
            Event2Show = ShownEvent - 1
        End If

        If Event2Show >= 0 AndAlso
           Event2Show < VFSmod.PRZMOutData.P2TEventList.Count Then

            With Me.PGrid

                Dim Counter As Integer = 0
                Dim Dummy As String = ""

                Do While Counter < .Item.Count
                    Dummy = .Item(Counter).Category

                    If .Item(Counter).Category.StartsWith("Runoff Event") Then
                        .Item.RemoveAt(Counter)
                    Else
                        Counter += 1
                    End If

                Loop

            End With


            Me.PRZMEvent2Show = VFSmod.PRZMOutData.P2TEventList(Event2Show)
            Me.VFSmodInputFileset = VFSmod.VFSmodInputFileSets(Event2Show)

            addEventsAndFiles2PGrid()

            Me.PGrid.Refresh()

            ShownEvent = Event2Show

        End If

    End Sub

    Public Sub addEventsAndFiles2PGrid()


        AddClass2PGrid(Class2Add:=Me.PRZMEvent2Show,
                               PGrid:=Me.PGrid,
                            Category:="Runoff Event",
                                Name:="PRZM output at " & Format(Me.PRZMEvent2Show.EventDate, "dd.MMM.yy"),
                         Description:="PRZM runoff outputs " & vbCrLf &
                                      "from *.pt2 and *.zts file")

        AddClass2PGrid(Class2Add:=Me.VFSmodInputFileset.IKW,
                                   PGrid:=Me.PGrid,
                                Category:="Runoff Event",
                                    Name:="IKW",
                             Description:="IKW Overland Flow Inputs")

        AddClass2PGrid(Class2Add:=Me.VFSmodInputFileset.ISO,
                                  PGrid:=Me.PGrid,
                               Category:="Runoff Event",
                                   Name:="ISO",
                            Description:="ISO Infiltration Soil Properties")

        AddClass2PGrid(Class2Add:=Me.VFSmodInputFileset.IGR,
                                  PGrid:=Me.PGrid,
                               Category:="Runoff Event",
                                   Name:="IGR",
                            Description:="IGR Buffer Vegetation Characteristics")

        AddClass2PGrid(Class2Add:=Me.VFSmodInputFileset.ISD,
                                PGrid:=Me.PGrid,
                             Category:="Runoff Event",
                                 Name:="ISD",
                          Description:="ISD Incomming Sediment Characteristics")

        AddClass2PGrid(Class2Add:=Me.VFSmodInputFileset.IRN,
                              PGrid:=Me.PGrid,
                           Category:="Runoff Event",
                               Name:="IRN",
                        Description:="IRN Storm Hyetograph")

        AddClass2PGrid(Class2Add:=Me.VFSmodInputFileset.IRO,
                              PGrid:=Me.PGrid,
                           Category:="Runoff Event",
                               Name:="IRO",
                        Description:="IRO Storm Runoff Hydrograph")


        AddClass2PGrid(Class2Add:=Me.VFSmodInputFileset.IWQ,
                              PGrid:=Me.PGrid,
                           Category:="Runoff Event",
                               Name:="IWQ",
                        Description:="IWQ Water quality/transport submodel")


    End Sub


    Private Sub tsmiPrevEvent_Click(sender As System.Object, e As System.EventArgs) Handles tsmiPrevEvent.Click
        updateEventsInPGrid(eNextPrev.PrevROEvent)
    End Sub

    Private Sub tsmiNextEvent_Click(sender As System.Object, e As System.EventArgs) Handles tsmiNextEvent.Click
        updateEventsInPGrid(eNextPrev.NextROEvent)
    End Sub

#End Region

#Region "GUI"

    Private Sub tsmiOpenEasySelectDialog_Click(sender As System.Object, e As System.EventArgs) Handles tsmiOpenEasySelectDialog.Click

        Me.getVFSmodGeneralInputs(Me, Nothing)

    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub PGrid_PropertyValueChanged(s As Object, e As System.Windows.Forms.PropertyValueChangedEventArgs) Handles PGrid.PropertyValueChanged

        Try
            Me.PGrid.Refresh()
        Catch ex As Exception

        End Try

    End Sub

    'timelimit
    Private Sub t()

        MsgBox("pre-SWAN test version, pls use SWAN", MsgBoxStyle.Exclamation)

    End Sub

#End Region

#Region "Load / Save complete model"

    Private Sub tsmiLoadCompleteModel_Click(sender As System.Object,
                                            e As System.EventArgs) Handles tsmiLoadCompleteModel.Click


        Dim myOFD As New OpenFileDialog

        With myOFD

            .Reset()
            .Title = "Select 'Complete model' xml file (std. VFSmodCMDSave.xml)"


            .CheckFileExists = True

            .DefaultExt = "xml"
            .Filter = "Complete model file (VFSmodCMDSave.xml)|VFSmodCMDSave.xml|" &
                      "XML file (*.xml)|*.xml|" &
                      "All files (*.*)|*.*"
            .FilterIndex = 0

            If .ShowDialog = DialogResult.OK Then

                Try

                    VFSmod = CType(LoadXML2Class(GetType(VFSmod), .FileName), VFSmodCMD.VFSmod)
                    Me.lblStatus.Text = "'Complete model' file load from to " & .FileName

                    VFSmod.initThetaIFocusTempWTD()

                    fillPGrid()

                    'add classes to pgrid
                    AddClass2PGrid(Class2Add:=Me.VFSmod.Swan2VFSmodGUI.Paths,
                                    PGrid:=Me.PGrid,
                                 Category:="VFSmodGUI inputs",
                                     Name:="Paths",
                              Description:="Paths to PRZM and TOXSWA in/output files")

                    AddClass2PGrid(Class2Add:=Me.VFSmod.Swan2VFSmodGUI.GeneralInfo,
                                    PGrid:=Me.PGrid,
                                 Category:="VFSmodGUI inputs",
                                     Name:="General Inputs",
                              Description:="General Inputs")

                Catch ex As Exception

                    lblStatus.Text = ex.Message

                End Try

            Else
                Me.lblStatus.Text = "'Complete model' file load canceled by user"

            End If

        End With


    End Sub

    Private Sub tsmiSaveCompleteModel_Click(sender As System.Object,
                                            e As System.EventArgs) Handles tsmiSaveCompleteModel.Click


        Dim mySFD As New SaveFileDialog

        With mySFD

            .Reset()
            .Title = "Select 'Complete model' xml file (std. VFSmodCMDSave.xml)"


            .CheckPathExists = True

            .DefaultExt = "xml"
            .Filter = "Complete model file (VFSmodCMDSave.xml)|VFSmodCMDSave.xml|" &
                      "XML file (*.xml)|*.xml|" &
                      "All files (*.*)|*.*"
            .FilterIndex = 0

            If .ShowDialog = DialogResult.OK Then

                Try
                    SaveClass2XML(VFSmod, GetType(VFSmod), .FileName)

                    Me.lblStatus.Text = "'Complete model' file saved to " & .FileName

                Catch ex As Exception

                    lblStatus.Text = ex.Message

                End Try

            Else
                Me.lblStatus.Text = "'Complete model' file save canceled by user"

            End If

        End With

    End Sub

#End Region


#Region "Run VFSmod (and TOXSWA) or create batch only"

    Private Sub Run_Click(sender As System.Object, e As System.EventArgs)

        Dim myProcess As New Process


        Dim ScenarioUserInputFileName As String = ""
        Dim TOXSWArunFileName As String = ""
        Dim Swan2VFSmodGUIFileName As String = ""
        Dim CWAFiles As String() = {}

        ScenarioUserInputFileName = VFSmod.Swan2VFSmodGUI.GeneralInfo.FOCUSScenario.ToString & "ScenarioUserInput.xml"
        ScenarioUserInputFileName = Path.Combine(VFSmod.Swan2VFSmodGUI.Paths.VFSmodGUI2SwanPath, ScenarioUserInputFileName)
        Swan2VFSmodGUIFileName = Path.Combine(VFSmod.Swan2VFSmodGUI.Paths.VFSmodGUI2SwanPath, "Swan2VFSmodGUI.xml")

        '**************************test************************************
        'GoTo testme
        '**************************test************************************
        TOXSWArunFileName = Path.Combine(VFSmod.Swan2VFSmodGUI.Paths.VFSmodGUI2SwanPath, "TOXSWArunInfo.xml")

        'write scenario file to exec path
        Try

            SaveClass2XML(Class2Save:=VFSmod.ScenarioUserInput,
                          ClassType:=GetType(ScenarioUserInput),
                          XMLFileName:=ScenarioUserInputFileName)

        Catch ex As Exception

            log(ex.Message & vbCrLf & EOP)

        End Try


        VFSmod.Swan2VFSmodGUI.Paths.ScenarioUserInputFilePath = ScenarioUserInputFileName

        'write swan2vfsmod file to exec path
        Try

            SaveClass2XML(Class2Save:=VFSmod.Swan2VFSmodGUI,
                          ClassType:=GetType(Swan2VFSmodGUI),
                          XMLFileName:=Swan2VFSmodGUIFileName)

        Catch ex As Exception

            log(ex.Message & vbCrLf & EOP)

        End Try

        'write toxswa run file
        Try

            SaveClass2XML(Class2Save:=VFSmod.TOXSWArun,
                          ClassType:=GetType(TOXSWAInfo),
                          XMLFileName:=TOXSWArunFileName)

        Catch ex As Exception

            log(ex.Message & vbCrLf & EOP)

        End Try


        With myProcess.StartInfo

            .FileName = Path.Combine(ExecPath, "VFSmodCMD.exe")

            If Not File.Exists(.FileName) Then
                log("Can't find 'VFSmodCMD.exe'" & vbCrLf &
                    .FileName & vbCrLf &
                    EOP)
            End If

            If VFSmodOnly Then
                .Arguments = Path.GetFileName(Swan2VFSmodGUIFileName)
                VFSmodOnly = True
            Else
                VFSmodOnly = False
                .Arguments = Path.GetFileName(Swan2VFSmodGUIFileName) & " " & Path.GetFileName(TOXSWArunFileName)
            End If

            .WindowStyle = ProcessWindowStyle.Normal
            .WorkingDirectory = VFSmod.Swan2VFSmodGUI.Paths.VFSmodGUI2SwanPath

            File.WriteAllLines(Path.Combine(.WorkingDirectory, "StartVFSmodCMD.bat"),
                                                           { .FileName & " " & .Arguments})
        End With

testme:

        If BatchOnly Then

            BatchOnly = False
            Exit Sub

        End If


        '**************************test************************************
        ' .Start()
        'Swan2VFSmodGUIFileName = "X:\RRP1900392\DGR00\Fs3\PMT00\R01TFS02\VFSmod\R3\5m\Swan2VFSmodGUI.xml"
        '    TOXSWArunFileName = "X:\RRP1900392\DGR00\Fs3\PMT00\R01TFS02\VFSmod\R3\5m\TOXSWArunInfo.xml"

        '**************************test************************************

        VFSmod = New VFSmod(
                Swan2VFSmodGUIFilePath:=Swan2VFSmodGUIFileName,
                TOXSWArunInfoFilePath:=TOXSWArunFileName)

        With VFSmod

            .runVFSmod()

            If Not VFSmodOnly Then

                'VFSmod.getTOXSWArunInfo(CMDArgs(1))
                Try
                    .fillTOXSWArun()
                Catch ex As Exception

                End Try


                'create new p2t file
                .PRZMOutData.rebuildP2T(
                            VFSmodResults:=VFSmod.VFSmodGUI2Swan.VFSmodResults,
                                       WB:=VFSmod.Swan2VFSmodGUI.GeneralInfo.FOCUSWaterBody)

                log("Write new p2t file")
                log(" P2T     : " & VFSmod.TOXSWArun.NewP2TFilePath)
                File.WriteAllLines(path:=VFSmod.TOXSWArun.NewP2TFilePath,
                                   contents:=VFSmod.PRZMOutData.MitigationP2T)

                .runTOXSWA()

            End If

        End With

        Me.Refresh()

        log("Finished")
        ' MsgBox("Finished ;-)")

    End Sub


    Private BatchOnly As Boolean = False

    Private Sub tsmiOnlyCreateBatchToolStrip_Click(sender As System.Object, e As System.EventArgs) Handles tsmiOnlyCreateBatchToolStrip.Click

        BatchOnly = True

        Run_Click(Me, Nothing)

    End Sub

    Private VFSmodOnly As Boolean = False

    Private Sub tsmiRunOnlyVFSmod_Click(sender As System.Object, e As System.EventArgs) Handles tsmiRunOnlyVFSmod.Click

        VFSmodOnly = True

        Run_Click(Me, Nothing)

        Try

            File.Copy(Path.Combine(ExecPath,
                                   "log.txt"),
                      Path.Combine(VFSmod.Swan2VFSmodGUI.Paths.VFSmodGUI2SwanPath,
                                   "log.txt"))

        Catch ex As Exception

        End Try

    End Sub

    Private Sub tsmiRunVFSmodAndTOXSWA_Click(sender As System.Object, e As System.EventArgs) Handles tsmiRunVFSmodAndTOXSWA.Click

        VFSmodOnly = False

        Run_Click(Me, Nothing)

        VFSmod.runTOXSWA()

        Try

            File.Copy(Path.Combine(ExecPath,
                                   "log.txt"),
                      Path.Combine(VFSmod.Swan2VFSmodGUI.Paths.VFSmodGUI2SwanPath,
                                   "log.txt"))

        Catch ex As Exception

        End Try

    End Sub

#End Region

    Private Sub tsmiShowDetails_Click(sender As System.Object,
                                       e As System.EventArgs) Handles tsmiShowDetails.Click

        Try

            Dim myEventFrm As New frmEventList(VFSmod)
            myEventFrm.Show()

        Catch ex As Exception

        End Try

    End Sub

    Private Sub JustRebuildP2tToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles JustRebuildP2tToolStripMenuItem.Click

        Dim Swan2VFSmodGUIFileName As String = String.Empty
        Dim TOXSWArunFileName As String = String.Empty

        Swan2VFSmodGUIFileName = Path.Combine(VFSmod.Swan2VFSmodGUI.Paths.VFSmodGUI2SwanPath, "Swan2VFSmodGUI.xml")
        TOXSWArunFileName = Path.Combine(VFSmod.Swan2VFSmodGUI.Paths.VFSmodGUI2SwanPath, "TOXSWArunFileName.xml")

        VFSmod = New VFSmod(
               Swan2VFSmodGUIFilePath:=Swan2VFSmodGUIFileName,
               TOXSWArunInfoFilePath:=TOXSWArunFileName)

        With VFSmod

        End With

    End Sub
End Class


