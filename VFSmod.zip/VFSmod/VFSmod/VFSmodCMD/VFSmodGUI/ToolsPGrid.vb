﻿
Imports System.ComponentModel
Imports System.Xml.Serialization
Imports PropertyGridEx

Public Class PGridTools

#Region "PGrid"

    Public Class PGridDesciption

        Public Sub New()

        End Sub

        Public Sub New(ByVal Category As String,
                       ByVal Name As String,
                       ByVal Description As String)

            Me.Category = Category
            Me.Name = Name
            Me.Description = Description

        End Sub

        <XmlIgnore()>
        <Browsable(False)>
        Public Property Category As String

        <XmlIgnore()>
        <Browsable(False)>
        Public Property Name As String

        <XmlIgnore()>
        <Browsable(False)>
        Public Property Description As String

    End Class

    Shared Sub initPGrid(ByVal PGrid As PropertyGridEx.PropertyGridEx,
                Optional ByVal Font As Font = Nothing,
                Optional ByVal ClearToolBar As Boolean = False)

        If IsNothing(Font) Then
            Font = New Font("Courier New", 10, FontStyle.Regular)
        End If


        Dim Test As String = ""

        With PGrid

            'description properties
            .Font = New Font(Font.FontFamily.Name, Font.Size, FontStyle.Regular)

            With .DocCommentTitle
                .Font = New Font(Font.FontFamily.Name, Font.Size, FontStyle.Bold)
                .AutoSize = True
            End With

            With .DocCommentDescription
                .Font = New Font(Font.FontFamily.Name,
                                 Font.Size - 2,
                                 FontStyle.Regular)
                .AutoSize = True
                .Location = New Point(3,
                                      5 + PGrid.DocCommentTitle.Font.Height)
            End With

            'activate special PGrid features
            .ShowCustomProperties = True

            .PropertySort = PropertySort.Categorized
            .AutoSizeProperties = True



            If ClearToolBar Then

                'remove event view
                For counter As Integer = 0 To PGrid.ToolStrip.Items.Count - 1

                    With .ToolStrip

                        Test = .Items(counter).Text.ToLower

                        If .Items(counter).Text.ToLower = "property pages" OrElse
                            .Items(counter).Text.ToLower = "eigenschaftenseiten" Then
                            .Items(counter).Visible = False

                        End If

                        If .Items(counter).Text.ToLower = "nach kategorien." OrElse
                           .Items(counter).Text.ToLower = "alphabetisch" Then
                            .Items(counter).Visible = False

                        End If


                    End With

                Next

            End If

            'clear PGrid and refresh view
            .Item.Clear()
            .Refresh()

        End With

    End Sub

    Public Enum eBowserStyle

        Normal = 0
        TypeName = 1
        Ellipsis = 2
        NoStyle = 3

    End Enum

    Shared Function AddClass2PGrid(ByVal Class2Add As Object, _
                                   ByVal PGrid As PropertyGridEx.PropertyGridEx, _
                                   ByVal Category As String, _
                                   ByVal Name As String, _
                                   ByVal Description As String, _
                          Optional ByVal IsBrowsable As Boolean = True, _
                          Optional ByVal IsReadonly As Boolean = False, _
                          Optional ByVal IsVisible As Boolean = True,
                          Optional ByVal BrowsableLabelStyle As eBowserStyle = eBowserStyle.Ellipsis) As Integer

        Try

            With PGrid

                .Item.Add(strName:=Name, _
                         objValue:=Class2Add, _
                   boolIsReadOnly:=IsReadonly, _
                      strCategory:=Category, _
                   strDescription:=Description, _
                      boolVisible:=IsVisible)

            End With

            With PGrid.Item(PGrid.Item.Count - 1)

                If BrowsableLabelStyle <> eBowserStyle.NoStyle Then
                    .IsBrowsable = IsBrowsable
                    .BrowsableLabelStyle = CType(BrowsableLabelStyle, BrowsableTypeConverter.LabelStyle)
                End If

            End With

            PGrid.Refresh()

            Return PGrid.Item.Count - 1

        Catch ex As Exception

            Debug.Assert(False)
            Return 0
        End Try

    End Function

    ''' <summary>
    ''' Add a class property to the grid
    ''' </summary>
    ''' <param name="BaseClass"></param>
    ''' <param name="Property2Add"></param>
    ''' <param name="PGrid"></param>
    ''' <param name="Category"></param>
    ''' <param name="Name"></param>
    ''' <param name="Description"></param>
    ''' <param name="IsBrowsable"></param>
    ''' <param name="IsReadonly"></param>
    ''' <param name="IsVisible"></param>
    ''' <param name="BrowsableLabelStyle"></param>
    ''' <param name="FileNameDialogFilter">
    ''' </param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Shared Function AddProperty2PGrid(ByVal BaseClass As Object, ByVal Property2Add As String, _
                                      ByVal PGrid As PropertyGridEx.PropertyGridEx, _
                                      ByVal Category As String, _
                                      ByVal Name As String, _
                                      ByVal Description As String, _
                             Optional ByVal IsBrowsable As Boolean = True, _
                             Optional ByVal IsReadonly As Boolean = False, _
                             Optional ByVal IsVisible As Boolean = True, _
                             Optional ByVal BrowsableLabelStyle As eBowserStyle = eBowserStyle.NoStyle,
                             Optional ByVal FileNameDialogFilter As String = "",
                             Optional ByVal DialogType As UIFilenameEditor.FileDialogType =
                                                          UIFilenameEditor.FileDialogType.LoadFileDialog,
                             Optional ByVal ClickFunktion As String = "",
                             Optional ByVal IsPercentage As Boolean = False,
                             Optional ByVal IsPasswd As Boolean = False) As Integer

        Try


            With PGrid

                .Item.Add(strName:=Name, _
                           objRef:=BaseClass,
                          strProp:=Property2Add,
                   boolIsReadOnly:=IsReadonly, _
                      strCategory:=Category, _
                   strDescription:=Description, _
                      boolVisible:=IsVisible)

            End With

            With PGrid.Item(PGrid.Item.Count - 1)

                If IsPercentage Then
                    .IsPercentage = True

                ElseIf IsPasswd Then
                    .IsPassword = True

                ElseIf FileNameDialogFilter <> "" Then

                    .UseFileNameEditor = True
                    .FileNameFilter = FileNameDialogFilter
                    .FileNameDialogType = UIFilenameEditor.FileDialogType.SaveFileDialog

                Else

                    If BrowsableLabelStyle <> eBowserStyle.NoStyle Then
                        .IsBrowsable = IsBrowsable
                        .BrowsableLabelStyle = CType(BrowsableLabelStyle, BrowsableTypeConverter.LabelStyle)
                    End If

                End If

            End With

            PGrid.Refresh()

            Return PGrid.Item.Count - 1


        Catch ex As Exception

            Debug.Assert(False)
            Return 0
        End Try


    End Function

    Shared Function getPGridItemByName(ByVal PGrid As PropertyGridEx.PropertyGridEx,
                                       ByVal ItemName As String) As PropertyGridEx.CustomProperty

        Dim TargetItem As New PropertyGridEx.CustomProperty

        For Counter As Integer = 0 To PGrid.Item.Count - 1

            With PGrid.Item(Counter)

                If .Name = ItemName Then

                    TargetItem = PGrid.Item(Counter)
                    Exit For

                End If

            End With

        Next

        Return TargetItem

    End Function

    Shared Function getPGridNoByName(ByVal PGrid As PropertyGridEx.PropertyGridEx,
                                       ByVal ItemName As String) As Integer

        Dim TargetItem As New PropertyGridEx.CustomProperty

        For Counter As Integer = 0 To PGrid.Item.Count - 1
            With PGrid.Item(Counter)

                If .Name = ItemName Then
                    Return Counter
                End If

            End With
        Next

        Return -1

    End Function


    Shared Function ChangeItemName(ByVal PGrid As PropertyGridEx.PropertyGridEx,
                                   ByVal OldName As String,
                                   ByVal NewName As String) As Object


        For Counter As Integer = 0 To PGrid.Item.Count - 1


            With PGrid.Item(Counter)


                If .Name = OldName Then
                    '.Value = {"rterte", "8888"}
                    .Name = NewName
                    Return PGrid.Item(Counter).Value
                    Exit For
                End If


            End With

        Next

        Return Nothing

    End Function


#End Region

End Class


