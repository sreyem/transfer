﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEventList
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmEventList))
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.PGrid = New PropertyGridEx.PropertyGridEx()
        Me.tsbNext = New System.Windows.Forms.ToolStripButton()
        Me.tsbPrev = New System.Windows.Forms.ToolStripButton()
        Me.tsbLoad = New System.Windows.Forms.ToolStripButton()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.lblPoint = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblPoint2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblAddInfo = New System.Windows.Forms.ToolStripStatusLabel()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.PGrid)
        Me.SplitContainer1.Size = New System.Drawing.Size(925, 606)
        Me.SplitContainer1.SplitterDistance = 884
        Me.SplitContainer1.TabIndex = 0
        '
        'PGrid
        '
        '
        '
        '
        Me.PGrid.DocCommentDescription.AutoEllipsis = True
        Me.PGrid.DocCommentDescription.Cursor = System.Windows.Forms.Cursors.Default
        Me.PGrid.DocCommentDescription.Location = New System.Drawing.Point(3, 18)
        Me.PGrid.DocCommentDescription.Name = ""
        Me.PGrid.DocCommentDescription.Size = New System.Drawing.Size(878, 37)
        Me.PGrid.DocCommentDescription.TabIndex = 1
        Me.PGrid.DocCommentImage = Nothing
        '
        '
        '
        Me.PGrid.DocCommentTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.PGrid.DocCommentTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.PGrid.DocCommentTitle.Location = New System.Drawing.Point(3, 3)
        Me.PGrid.DocCommentTitle.Name = ""
        Me.PGrid.DocCommentTitle.Size = New System.Drawing.Size(878, 15)
        Me.PGrid.DocCommentTitle.TabIndex = 0
        Me.PGrid.DocCommentTitle.UseMnemonic = False
        Me.PGrid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PGrid.Location = New System.Drawing.Point(0, 0)
        Me.PGrid.Name = "PGrid"
        Me.PGrid.Size = New System.Drawing.Size(884, 606)
        Me.PGrid.TabIndex = 0
        Me.PGrid.ToolbarVisible = False
        '
        '
        '
        Me.PGrid.ToolStrip.AccessibleName = "ToolBar"
        Me.PGrid.ToolStrip.AccessibleRole = System.Windows.Forms.AccessibleRole.ToolBar
        Me.PGrid.ToolStrip.AllowMerge = False
        Me.PGrid.ToolStrip.AutoSize = False
        Me.PGrid.ToolStrip.CanOverflow = False
        Me.PGrid.ToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.PGrid.ToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.PGrid.ToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsbNext, Me.tsbPrev, Me.tsbLoad})
        Me.PGrid.ToolStrip.Location = New System.Drawing.Point(0, 1)
        Me.PGrid.ToolStrip.Name = ""
        Me.PGrid.ToolStrip.Padding = New System.Windows.Forms.Padding(2, 0, 1, 0)
        Me.PGrid.ToolStrip.Size = New System.Drawing.Size(884, 25)
        Me.PGrid.ToolStrip.TabIndex = 1
        Me.PGrid.ToolStrip.TabStop = True
        Me.PGrid.ToolStrip.Text = "PropertyGridToolBar"
        Me.PGrid.ToolStrip.Visible = False
        '
        'tsbNext
        '
        Me.tsbNext.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.tsbNext.Image = CType(resources.GetObject("tsbNext.Image"), System.Drawing.Image)
        Me.tsbNext.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbNext.Name = "tsbNext"
        Me.tsbNext.Size = New System.Drawing.Size(35, 22)
        Me.tsbNext.Text = "Next"
        '
        'tsbPrev
        '
        Me.tsbPrev.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.tsbPrev.Image = CType(resources.GetObject("tsbPrev.Image"), System.Drawing.Image)
        Me.tsbPrev.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbPrev.Name = "tsbPrev"
        Me.tsbPrev.Size = New System.Drawing.Size(37, 22)
        Me.tsbPrev.Text = "Prev."
        '
        'tsbLoad
        '
        Me.tsbLoad.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.tsbLoad.Image = CType(resources.GetObject("tsbLoad.Image"), System.Drawing.Image)
        Me.tsbLoad.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbLoad.Name = "tsbLoad"
        Me.tsbLoad.Size = New System.Drawing.Size(77, 22)
        Me.tsbLoad.Text = "Load Results"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lblPoint, Me.lblPoint2, Me.lblAddInfo})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 609)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(925, 22)
        Me.StatusStrip1.TabIndex = 1
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'lblPoint
        '
        Me.lblPoint.Name = "lblPoint"
        Me.lblPoint.Size = New System.Drawing.Size(120, 17)
        Me.lblPoint.Text = "ToolStripStatusLabel1"
        '
        'lblPoint2
        '
        Me.lblPoint2.Name = "lblPoint2"
        Me.lblPoint2.Size = New System.Drawing.Size(120, 17)
        Me.lblPoint2.Text = "ToolStripStatusLabel1"
        '
        'lblAddInfo
        '
        Me.lblAddInfo.Name = "lblAddInfo"
        Me.lblAddInfo.Size = New System.Drawing.Size(63, 17)
        Me.lblAddInfo.Text = "lblAddInfo"
        '
        'frmEventList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(925, 631)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Name = "frmEventList"
        Me.Text = "frmEventList"
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout
        Me.ResumeLayout(false)
        Me.PerformLayout

End Sub
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents PGrid As PropertyGridEx.PropertyGridEx
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents lblPoint As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblPoint2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblAddInfo As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents tsbNext As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbPrev As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbLoad As System.Windows.Forms.ToolStripButton
End Class
