
Imports System.IO


Public Class ToolsXML


    <DebuggerStepThrough()>
    Shared Sub SaveClass2XML(ByVal Class2Save As Object, _
                             ByVal ClassType As Type, _
                             ByVal XMLFileName As String)

        If Not Directory.Exists(Path.GetDirectoryName(XMLFileName)) Then _
            Throw New DirectoryNotFoundException("No valid XML Path")

        Try

            Dim mySerializer As Xml.Serialization.XmlSerializer = _
                            New Xml.Serialization.XmlSerializer(ClassType)

            Dim myWriter As IO.StreamWriter = _
                        New IO.StreamWriter(XMLFileName)

            mySerializer.Serialize(myWriter, Class2Save)
            myWriter.Close()

        Catch ex As Exception
            Throw (ex)
        End Try

    End Sub

    <DebuggerStepThrough()>
    Shared Function LoadXML2Class(ByVal ClassType As Type, _
                                  ByVal XMLFileName As String) As Object

        Dim TargetClass As New Object

        Try

            Dim mySerializer As Xml.Serialization.XmlSerializer = _
                                    New Xml.Serialization.XmlSerializer(ClassType)

            ' To read the file, create a FileStream.
            Dim myFileStream As IO.FileStream = _
                            New IO.FileStream(XMLFileName, IO.FileMode.Open)

            ' Call the Deserialize method and cast to the object type.
            TargetClass = mySerializer.Deserialize(myFileStream)


            myFileStream.Close()

            Return TargetClass

        Catch ex As Exception
            Throw New ArgumentException(ex.Message)
        End Try

    End Function


End Class