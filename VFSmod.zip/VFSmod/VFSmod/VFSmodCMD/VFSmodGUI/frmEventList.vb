﻿
Imports VFSmodGUI.PGridTools
Imports VFSmodGUI.ToolsXML
Imports VFSmodCMD

Imports System.IO
Imports System.Windows.Forms.DataVisualization.Charting
Imports VFSmodCMD.Common

Public Class frmEventList

    Public myVFSmod As New VFSmod

    Private FileCounter As Integer = 0



    Public Sub New(myVFSmod As VFSmod)

        ' Dieser Aufruf ist für den Designer erforderlich.
        InitializeComponent()

        ' Fügen Sie Initialisierungen nach dem InitializeComponent()-Aufruf hinzu.


        Me.Text = "VFSmodGUI v." & My.Application.Info.Version.ToString
        initPGrid(Me.PGrid, New Font("Courier New", 10), False)
        'Chart.EnableZoomAndPanControls(AddressOf ChartCursorSelected, AddressOf ChartCursorMoved)


        getData(myVFSmod)
        addEvents2PGrid(myVFSmod)
        addVFSmodfiles(FileCounter, myVFSmod)

        Me.PGrid.Refresh()

    End Sub



    Public Sub getData(ByRef VFSmod As VFSmod)

        VFSmod.initThetaIFocusTempWTD()

        With VFSmod.Swan2VFSmodGUI

            If VFSmod.PRZMOutData.P2TEventList.Count = 0 Then
                VFSmod.PRZMOutData = New PRZMOutData(.Paths.p2tFilePath,
                                                       .Paths.ztsFilePath,
                                                       .GeneralInfo.FOCUSScenario)
            End If

            VFSmod.VFSmodInputFileSets = VFSmod.generateVFSmodInputFiles()

        End With

    End Sub


    Public Sub addEvents2PGrid(ByRef VFSmod As VFSmod)

        For Counter As Integer = 0 To VFSmod.PRZMOutData.P2TEventList.Count - 1

            With VFSmod.PRZMOutData.P2TEventList(Counter)

                AddClass2PGrid(VFSmod.PRZMOutData.P2TEventList(Counter),
                               Me.PGrid, "Events",
                               .EventDate.ToShortDateString & " " &
                               .Precipitation & "mm/h",
                               .EventDuration & "h")

            End With

        Next

    End Sub


    Public Sub addResults2PGrid()


        For Counter As Integer = 0 To myVFSmod.PRZMOutData.P2TEventList.Count - 1

            With myVFSmod.PRZMOutData.P2TEventList(Counter)

                AddClass2PGrid(myVFSmod.VFSmodGUI2Swan.VFSmodResults(Counter),
                               Me.PGrid, "Results",
                               .EventDate.ToShortDateString & " " & .Precipitation & "mm/h", .EventDuration & "h")

            End With

        Next

        Me.PGrid.Refresh()

    End Sub

    Public Sub addVFSmodfiles(Counter As Integer, VFSmod As VFSmod)

        With VFSmod.PRZMOutData.P2TEventList(Counter)

            Try
                Me.PGrid.Item.RemoveAt(VFSmodGUI.PGridTools.getPGridNoByName(Me.PGrid, "IKW Overland Flow Inputs"))
            Catch ex As Exception

            End Try

            AddClass2PGrid(VFSmod.VFSmodInputFileSets(Counter).IKW,
                                           Me.PGrid, "VFSmod files",
                                            "IKW Overland Flow Inputs", .EventDate.ToShortDateString & " " & .Precipitation & "mm/h")
            Try
                Me.PGrid.Item.RemoveAt(VFSmodGUI.PGridTools.getPGridNoByName(Me.PGrid, "ISO Infiltration Soil Properties"))
            Catch ex As Exception

            End Try

            AddClass2PGrid(VFSmod.VFSmodInputFileSets(Counter).ISO,
                                          Me.PGrid, "VFSmod files",
                                           "ISO Infiltration Soil Properties", .EventDate.ToShortDateString & " " & .Precipitation & "mm/h")

            Try
                Me.PGrid.Item.RemoveAt(VFSmodGUI.PGridTools.getPGridNoByName(Me.PGrid, "IGR Buffer Vegetation Characteristics"))
            Catch ex As Exception

            End Try

            AddClass2PGrid(VFSmod.VFSmodInputFileSets(Counter).IGR,
                                          Me.PGrid, "VFSmod files",
                                           "IGR Buffer Vegetation Characteristics", .EventDate.ToShortDateString & " " & .Precipitation & "mm/h")

            Try
                Me.PGrid.Item.RemoveAt(VFSmodGUI.PGridTools.getPGridNoByName(Me.PGrid, "ISD Incomming Sediment Characteristics"))
            Catch ex As Exception

            End Try

            AddClass2PGrid(VFSmod.VFSmodInputFileSets(Counter).ISD,
                                          Me.PGrid, "VFSmod files",
                                           "ISD Incomming Sediment Characteristics", .EventDate.ToShortDateString & " " & .Precipitation & "mm/h")

            Try
                Me.PGrid.Item.RemoveAt(VFSmodGUI.PGridTools.getPGridNoByName(Me.PGrid, "IRN Storm Hyetograph"))
            Catch ex As Exception

            End Try

            AddClass2PGrid(VFSmod.VFSmodInputFileSets(Counter).IRN,
                                          Me.PGrid, "VFSmod files",
                                           "IRN Storm Hyetograph", .EventDate.ToShortDateString & " " & .Precipitation & "mm/h")

            Try
                Me.PGrid.Item.RemoveAt(VFSmodGUI.PGridTools.getPGridNoByName(Me.PGrid, "IRO Storm Runoff Hydrograph"))
            Catch ex As Exception

            End Try

            AddClass2PGrid(VFSmod.VFSmodInputFileSets(Counter).IRO,
                                          Me.PGrid, "VFSmod files",
                                           "IRO Storm Runoff Hydrograph", .EventDate.ToShortDateString & " " & .Precipitation & "mm/h")

            Try
                Me.PGrid.Item.RemoveAt(VFSmodGUI.PGridTools.getPGridNoByName(Me.PGrid, "IWQ Water quality/transport submodel"))
            Catch ex As Exception

            End Try

            AddClass2PGrid(VFSmod.VFSmodInputFileSets(Counter).IWQ,
                                          Me.PGrid, "VFSmod files",
                                           "IWQ Water quality/transport submodel", .EventDate.ToShortDateString & " " & .Precipitation & "mm/h")

        End With

    End Sub


    Private Sub ChartCursorMoved(x As Double, y As Double)

        Dim movDate As New Date
        movDate = CDate(Date.FromOADate(x))

        'If Chart.Series.Count = 0 Then

        '    lblPoint.Text = ""
        '    lblAddInfo.Text = ""
        '    Exit Sub
        'End If


        lblPoint.Text = "Actual : " & Format(movDate, "dd.MMM hh\h") & " || " &
                                      Format(y, "0.00E+00 µg/L               ")

        lblAddInfo.Text = "Time diff. = " & Math.Abs((seldate - movDate).Days) & "days" & " || " &
                          "Conc. diff. = " & Format(Math.Abs(selConc - y), "0.00E+00") & "µg/L"

    End Sub

    Private seldate As New Date
    Private selConc As Double

    Private Sub ChartCursorSelected(x As Double, y As Double)

        seldate = CDate(Date.FromOADate(x))
        selConc = y

        'If Chart.Series.Count = 0 Then
        '    lblPoint2.Text = ""
        '    Exit Sub
        'End If


        lblPoint2.Text = " Selected : " & Format(seldate, "dd.MMM hh\h") & " || " &
                         Format(y, "0.00E+00 µg/L               ")

    End Sub


    Private Sub tsbNext_Click(sender As Object, e As System.EventArgs) Handles tsbNext.Click

        If FileCounter + 1 > Me.myVFSmod.PRZMOutData.P2TEventList.Count - 1 Then

            FileCounter = 0

        Else
            FileCounter += 1

        End If

        addVFSmodfiles(FileCounter, myVFSmod)

        Me.PGrid.Refresh()

    End Sub

    Private Sub tsbPrev_Click(sender As Object, e As System.EventArgs) Handles tsbPrev.Click

        If FileCounter - 1 < 0 Then

            FileCounter = Me.myVFSmod.PRZMOutData.P2TEventList.Count - 1

        Else
            FileCounter -= 1

        End If

        addVFSmodfiles(FileCounter, myVFSmod)

        Me.PGrid.Refresh()


    End Sub

    Private Sub tsbLoad_Click(sender As Object, e As System.EventArgs) Handles tsbLoad.Click

        Dim myOFD As New OpenFileDialog

        With myOFD

            .Reset()
            .Title = "Select 'VFSmod2SWAN' xml file (std. VFSmodGUI2Swan.xml)"


            .CheckFileExists = True

            .DefaultExt = "xml"
            .Filter = "VFSmod 2 SWAN file (VFSmodGUI2Swan.xml)|VFSmodGUI2Swan.xml|" &
                      "XML file (*.xml)|*.xml|" &
                      "All files (*.*)|*.*"
            .FilterIndex = 0

            If .ShowDialog = DialogResult.OK Then

                Try

                    myVFSmod.VFSmodGUI2Swan = CType(LoadXML2Class(GetType(VFSmodGUI2Swan), .FileName), VFSmodGUI2Swan)
                    addResults2PGrid()

                Catch ex As Exception

                End Try

            End If

        End With

    End Sub

    
End Class