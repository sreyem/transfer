﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmVFSmodGUI
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.SplitContainerMain = New System.Windows.Forms.SplitContainer()
        Me.PGrid = New PropertyGridEx.PropertyGridEx()
        Me.SplitContainerResults = New System.Windows.Forms.SplitContainer()
        Me.tabcTXTFiles = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.rtbP2T = New System.Windows.Forms.RichTextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.rtbLog = New System.Windows.Forms.RichTextBox()
        Me.tabcGraphs = New System.Windows.Forms.TabControl()
        Me.MenuStrip = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiOpenEasySelectDialog = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadFromXMLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiLoadXMLSWANVFSmod = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiLoadScenarioUserInput = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadTOXSWARunInfo = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiLoadCompleteModel = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToXMLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiSaveXMLSWAN2VFSmod = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiSaveScenarioUserInput = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiSaveTOXSWARunInfo = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiSaveCompleteModel = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiShowDetails = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiRun = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiOnlyCreateBatchToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiRunOnlyVFSmod = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiRunVFSmodAndTOXSWA = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiNextEvent = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiPrevEvent = New System.Windows.Forms.ToolStripMenuItem()
        Me.GraphToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadCWAToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToWmfToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip = New System.Windows.Forms.StatusStrip()
        Me.lblStatus = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblPoint = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblPoint2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblAddInfo = New System.Windows.Forms.ToolStripStatusLabel()
        Me.JustRebuildP2tToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.SplitContainerMain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainerMain.Panel1.SuspendLayout()
        Me.SplitContainerMain.Panel2.SuspendLayout()
        Me.SplitContainerMain.SuspendLayout()
        CType(Me.SplitContainerResults, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainerResults.Panel1.SuspendLayout()
        Me.SplitContainerResults.Panel2.SuspendLayout()
        Me.SplitContainerResults.SuspendLayout()
        Me.tabcTXTFiles.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.MenuStrip.SuspendLayout()
        Me.StatusStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainerMain
        '
        Me.SplitContainerMain.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SplitContainerMain.Location = New System.Drawing.Point(0, 27)
        Me.SplitContainerMain.Name = "SplitContainerMain"
        '
        'SplitContainerMain.Panel1
        '
        Me.SplitContainerMain.Panel1.Controls.Add(Me.PGrid)
        '
        'SplitContainerMain.Panel2
        '
        Me.SplitContainerMain.Panel2.Controls.Add(Me.SplitContainerResults)
        Me.SplitContainerMain.Size = New System.Drawing.Size(923, 586)
        Me.SplitContainerMain.SplitterDistance = 893
        Me.SplitContainerMain.TabIndex = 0
        '
        'PGrid
        '
        '
        '
        '
        Me.PGrid.DocCommentDescription.AutoEllipsis = True
        Me.PGrid.DocCommentDescription.Cursor = System.Windows.Forms.Cursors.Default
        Me.PGrid.DocCommentDescription.Location = New System.Drawing.Point(3, 18)
        Me.PGrid.DocCommentDescription.Name = ""
        Me.PGrid.DocCommentDescription.Size = New System.Drawing.Size(887, 37)
        Me.PGrid.DocCommentDescription.TabIndex = 1
        Me.PGrid.DocCommentImage = Nothing
        '
        '
        '
        Me.PGrid.DocCommentTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.PGrid.DocCommentTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.PGrid.DocCommentTitle.Location = New System.Drawing.Point(3, 3)
        Me.PGrid.DocCommentTitle.Name = ""
        Me.PGrid.DocCommentTitle.Size = New System.Drawing.Size(887, 15)
        Me.PGrid.DocCommentTitle.TabIndex = 0
        Me.PGrid.DocCommentTitle.UseMnemonic = False
        Me.PGrid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PGrid.Location = New System.Drawing.Point(0, 0)
        Me.PGrid.Name = "PGrid"
        Me.PGrid.Size = New System.Drawing.Size(893, 586)
        Me.PGrid.TabIndex = 0
        Me.PGrid.ToolbarVisible = False
        '
        '
        '
        Me.PGrid.ToolStrip.AccessibleName = "ToolBar"
        Me.PGrid.ToolStrip.AccessibleRole = System.Windows.Forms.AccessibleRole.ToolBar
        Me.PGrid.ToolStrip.AllowMerge = False
        Me.PGrid.ToolStrip.AutoSize = False
        Me.PGrid.ToolStrip.CanOverflow = False
        Me.PGrid.ToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.PGrid.ToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.PGrid.ToolStrip.Location = New System.Drawing.Point(0, 1)
        Me.PGrid.ToolStrip.Name = ""
        Me.PGrid.ToolStrip.Padding = New System.Windows.Forms.Padding(2, 0, 1, 0)
        Me.PGrid.ToolStrip.Size = New System.Drawing.Size(94, 25)
        Me.PGrid.ToolStrip.TabIndex = 1
        Me.PGrid.ToolStrip.TabStop = True
        Me.PGrid.ToolStrip.Text = "PropertyGridToolBar"
        Me.PGrid.ToolStrip.Visible = False
        '
        'SplitContainerResults
        '
        Me.SplitContainerResults.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainerResults.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainerResults.Name = "SplitContainerResults"
        Me.SplitContainerResults.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainerResults.Panel1
        '
        Me.SplitContainerResults.Panel1.Controls.Add(Me.tabcTXTFiles)
        Me.SplitContainerResults.Panel1Collapsed = True
        '
        'SplitContainerResults.Panel2
        '
        Me.SplitContainerResults.Panel2.Controls.Add(Me.tabcGraphs)
        Me.SplitContainerResults.Size = New System.Drawing.Size(26, 586)
        Me.SplitContainerResults.SplitterDistance = 272
        Me.SplitContainerResults.TabIndex = 0
        '
        'tabcTXTFiles
        '
        Me.tabcTXTFiles.Controls.Add(Me.TabPage1)
        Me.tabcTXTFiles.Controls.Add(Me.TabPage2)
        Me.tabcTXTFiles.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tabcTXTFiles.Location = New System.Drawing.Point(0, 0)
        Me.tabcTXTFiles.Name = "tabcTXTFiles"
        Me.tabcTXTFiles.SelectedIndex = 0
        Me.tabcTXTFiles.Size = New System.Drawing.Size(150, 272)
        Me.tabcTXTFiles.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.rtbP2T)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(142, 246)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "p2t"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'rtbP2T
        '
        Me.rtbP2T.Dock = System.Windows.Forms.DockStyle.Fill
        Me.rtbP2T.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbP2T.Location = New System.Drawing.Point(3, 3)
        Me.rtbP2T.Name = "rtbP2T"
        Me.rtbP2T.Size = New System.Drawing.Size(136, 240)
        Me.rtbP2T.TabIndex = 0
        Me.rtbP2T.Text = ""
        Me.rtbP2T.WordWrap = False
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.rtbLog)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(142, 246)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "log"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'rtbLog
        '
        Me.rtbLog.Dock = System.Windows.Forms.DockStyle.Fill
        Me.rtbLog.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbLog.Location = New System.Drawing.Point(3, 3)
        Me.rtbLog.Name = "rtbLog"
        Me.rtbLog.Size = New System.Drawing.Size(136, 240)
        Me.rtbLog.TabIndex = 0
        Me.rtbLog.Text = ""
        Me.rtbLog.WordWrap = False
        '
        'tabcGraphs
        '
        Me.tabcGraphs.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tabcGraphs.Location = New System.Drawing.Point(0, 0)
        Me.tabcGraphs.Name = "tabcGraphs"
        Me.tabcGraphs.SelectedIndex = 0
        Me.tabcGraphs.Size = New System.Drawing.Size(26, 586)
        Me.tabcGraphs.TabIndex = 0
        '
        'MenuStrip
        '
        Me.MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.tsmiRun, Me.tsmiNextEvent, Me.tsmiPrevEvent, Me.GraphToolStripMenuItem, Me.AboutToolStripMenuItem})
        Me.MenuStrip.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip.Name = "MenuStrip"
        Me.MenuStrip.Size = New System.Drawing.Size(923, 24)
        Me.MenuStrip.TabIndex = 1
        Me.MenuStrip.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmiOpenEasySelectDialog, Me.LoadFromXMLToolStripMenuItem, Me.SaveToXMLToolStripMenuItem, Me.tsmiShowDetails, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'tsmiOpenEasySelectDialog
        '
        Me.tsmiOpenEasySelectDialog.Name = "tsmiOpenEasySelectDialog"
        Me.tsmiOpenEasySelectDialog.Size = New System.Drawing.Size(207, 22)
        Me.tsmiOpenEasySelectDialog.Text = "Open 'Easy select ' dialog"
        '
        'LoadFromXMLToolStripMenuItem
        '
        Me.LoadFromXMLToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmiLoadXMLSWANVFSmod, Me.tsmiLoadScenarioUserInput, Me.LoadTOXSWARunInfo, Me.tsmiLoadCompleteModel})
        Me.LoadFromXMLToolStripMenuItem.Name = "LoadFromXMLToolStripMenuItem"
        Me.LoadFromXMLToolStripMenuItem.Size = New System.Drawing.Size(207, 22)
        Me.LoadFromXMLToolStripMenuItem.Text = "&Load from XML"
        '
        'tsmiLoadXMLSWANVFSmod
        '
        Me.tsmiLoadXMLSWANVFSmod.Name = "tsmiLoadXMLSWANVFSmod"
        Me.tsmiLoadXMLSWANVFSmod.Size = New System.Drawing.Size(175, 22)
        Me.tsmiLoadXMLSWANVFSmod.Text = "SWAN -> VFSmod"
        '
        'tsmiLoadScenarioUserInput
        '
        Me.tsmiLoadScenarioUserInput.Name = "tsmiLoadScenarioUserInput"
        Me.tsmiLoadScenarioUserInput.Size = New System.Drawing.Size(175, 22)
        Me.tsmiLoadScenarioUserInput.Text = "Scenario user input"
        '
        'LoadTOXSWARunInfo
        '
        Me.LoadTOXSWARunInfo.Name = "LoadTOXSWARunInfo"
        Me.LoadTOXSWARunInfo.Size = New System.Drawing.Size(175, 22)
        Me.LoadTOXSWARunInfo.Text = "TOXSWA run info"
        Me.LoadTOXSWARunInfo.Visible = False
        '
        'tsmiLoadCompleteModel
        '
        Me.tsmiLoadCompleteModel.Name = "tsmiLoadCompleteModel"
        Me.tsmiLoadCompleteModel.Size = New System.Drawing.Size(175, 22)
        Me.tsmiLoadCompleteModel.Text = "Complete model"
        '
        'SaveToXMLToolStripMenuItem
        '
        Me.SaveToXMLToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmiSaveXMLSWAN2VFSmod, Me.tsmiSaveScenarioUserInput, Me.tsmiSaveTOXSWARunInfo, Me.tsmiSaveCompleteModel})
        Me.SaveToXMLToolStripMenuItem.Name = "SaveToXMLToolStripMenuItem"
        Me.SaveToXMLToolStripMenuItem.Size = New System.Drawing.Size(207, 22)
        Me.SaveToXMLToolStripMenuItem.Text = "&Save to XML"
        '
        'tsmiSaveXMLSWAN2VFSmod
        '
        Me.tsmiSaveXMLSWAN2VFSmod.Name = "tsmiSaveXMLSWAN2VFSmod"
        Me.tsmiSaveXMLSWAN2VFSmod.Size = New System.Drawing.Size(175, 22)
        Me.tsmiSaveXMLSWAN2VFSmod.Text = "SWAN -> VFSmod"
        '
        'tsmiSaveScenarioUserInput
        '
        Me.tsmiSaveScenarioUserInput.Name = "tsmiSaveScenarioUserInput"
        Me.tsmiSaveScenarioUserInput.Size = New System.Drawing.Size(175, 22)
        Me.tsmiSaveScenarioUserInput.Text = "Scenario user input"
        '
        'tsmiSaveTOXSWARunInfo
        '
        Me.tsmiSaveTOXSWARunInfo.Name = "tsmiSaveTOXSWARunInfo"
        Me.tsmiSaveTOXSWARunInfo.Size = New System.Drawing.Size(175, 22)
        Me.tsmiSaveTOXSWARunInfo.Text = "TOXSWA run info"
        Me.tsmiSaveTOXSWARunInfo.Visible = False
        '
        'tsmiSaveCompleteModel
        '
        Me.tsmiSaveCompleteModel.Name = "tsmiSaveCompleteModel"
        Me.tsmiSaveCompleteModel.Size = New System.Drawing.Size(175, 22)
        Me.tsmiSaveCompleteModel.Text = "Complete model"
        '
        'tsmiShowDetails
        '
        Me.tsmiShowDetails.Name = "tsmiShowDetails"
        Me.tsmiShowDetails.Size = New System.Drawing.Size(207, 22)
        Me.tsmiShowDetails.Text = "Show Details"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(207, 22)
        Me.ExitToolStripMenuItem.Text = "&Exit"
        '
        'tsmiRun
        '
        Me.tsmiRun.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmiOnlyCreateBatchToolStrip, Me.tsmiRunOnlyVFSmod, Me.tsmiRunVFSmodAndTOXSWA, Me.JustRebuildP2tToolStripMenuItem})
        Me.tsmiRun.Name = "tsmiRun"
        Me.tsmiRun.Size = New System.Drawing.Size(40, 20)
        Me.tsmiRun.Text = "&Run"
        '
        'tsmiOnlyCreateBatchToolStrip
        '
        Me.tsmiOnlyCreateBatchToolStrip.Name = "tsmiOnlyCreateBatchToolStrip"
        Me.tsmiOnlyCreateBatchToolStrip.Size = New System.Drawing.Size(215, 22)
        Me.tsmiOnlyCreateBatchToolStrip.Text = "Only create batch"
        '
        'tsmiRunOnlyVFSmod
        '
        Me.tsmiRunOnlyVFSmod.Name = "tsmiRunOnlyVFSmod"
        Me.tsmiRunOnlyVFSmod.Size = New System.Drawing.Size(215, 22)
        Me.tsmiRunOnlyVFSmod.Text = "Run only VFSmod"
        '
        'tsmiRunVFSmodAndTOXSWA
        '
        Me.tsmiRunVFSmodAndTOXSWA.Name = "tsmiRunVFSmodAndTOXSWA"
        Me.tsmiRunVFSmodAndTOXSWA.Size = New System.Drawing.Size(215, 22)
        Me.tsmiRunVFSmodAndTOXSWA.Text = "Run VFSmod and TOXSWA"
        '
        'tsmiNextEvent
        '
        Me.tsmiNextEvent.Name = "tsmiNextEvent"
        Me.tsmiNextEvent.Size = New System.Drawing.Size(75, 20)
        Me.tsmiNextEvent.Text = "&Next Event"
        Me.tsmiNextEvent.Visible = False
        '
        'tsmiPrevEvent
        '
        Me.tsmiPrevEvent.Name = "tsmiPrevEvent"
        Me.tsmiPrevEvent.Size = New System.Drawing.Size(77, 20)
        Me.tsmiPrevEvent.Text = "&Prev. Event"
        Me.tsmiPrevEvent.Visible = False
        '
        'GraphToolStripMenuItem
        '
        Me.GraphToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LoadCWAToolStripMenuItem, Me.SaveToWmfToolStripMenuItem})
        Me.GraphToolStripMenuItem.Name = "GraphToolStripMenuItem"
        Me.GraphToolStripMenuItem.Size = New System.Drawing.Size(51, 20)
        Me.GraphToolStripMenuItem.Text = "&Graph"
        Me.GraphToolStripMenuItem.Visible = False
        '
        'LoadCWAToolStripMenuItem
        '
        Me.LoadCWAToolStripMenuItem.Name = "LoadCWAToolStripMenuItem"
        Me.LoadCWAToolStripMenuItem.Size = New System.Drawing.Size(139, 22)
        Me.LoadCWAToolStripMenuItem.Text = "&Load CWA"
        '
        'SaveToWmfToolStripMenuItem
        '
        Me.SaveToWmfToolStripMenuItem.Name = "SaveToWmfToolStripMenuItem"
        Me.SaveToWmfToolStripMenuItem.Size = New System.Drawing.Size(139, 22)
        Me.SaveToWmfToolStripMenuItem.Text = "Save to wmf"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(52, 20)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'StatusStrip
        '
        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lblStatus, Me.lblPoint, Me.lblPoint2, Me.lblAddInfo})
        Me.StatusStrip.Location = New System.Drawing.Point(0, 616)
        Me.StatusStrip.Name = "StatusStrip"
        Me.StatusStrip.Size = New System.Drawing.Size(923, 22)
        Me.StatusStrip.TabIndex = 2
        Me.StatusStrip.Text = "StatusStrip1"
        '
        'lblStatus
        '
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(39, 17)
        Me.lblStatus.Text = "Status"
        '
        'lblPoint
        '
        Me.lblPoint.Name = "lblPoint"
        Me.lblPoint.Size = New System.Drawing.Size(35, 17)
        Me.lblPoint.Text = "Point"
        '
        'lblPoint2
        '
        Me.lblPoint2.Name = "lblPoint2"
        Me.lblPoint2.Size = New System.Drawing.Size(41, 17)
        Me.lblPoint2.Text = "Point2"
        '
        'lblAddInfo
        '
        Me.lblAddInfo.Name = "lblAddInfo"
        Me.lblAddInfo.Size = New System.Drawing.Size(0, 17)
        '
        'JustRebuildP2tToolStripMenuItem
        '
        Me.JustRebuildP2tToolStripMenuItem.Name = "JustRebuildP2tToolStripMenuItem"
        Me.JustRebuildP2tToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
        Me.JustRebuildP2tToolStripMenuItem.Text = "Just rebuild p2t"
        '
        'frmVFSmodGUI
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(923, 638)
        Me.Controls.Add(Me.StatusStrip)
        Me.Controls.Add(Me.SplitContainerMain)
        Me.Controls.Add(Me.MenuStrip)
        Me.MainMenuStrip = Me.MenuStrip
        Me.Name = "frmVFSmodGUI"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.SplitContainerMain.Panel1.ResumeLayout(False)
        Me.SplitContainerMain.Panel2.ResumeLayout(False)
        CType(Me.SplitContainerMain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainerMain.ResumeLayout(False)
        Me.SplitContainerResults.Panel1.ResumeLayout(False)
        Me.SplitContainerResults.Panel2.ResumeLayout(False)
        CType(Me.SplitContainerResults, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainerResults.ResumeLayout(False)
        Me.tabcTXTFiles.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.MenuStrip.ResumeLayout(False)
        Me.MenuStrip.PerformLayout()
        Me.StatusStrip.ResumeLayout(False)
        Me.StatusStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents SplitContainerMain As System.Windows.Forms.SplitContainer
    Friend WithEvents PGrid As PropertyGridEx.PropertyGridEx
    Friend WithEvents MenuStrip As System.Windows.Forms.MenuStrip
    Friend WithEvents StatusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents lblStatus As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveToXMLToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmiSaveXMLSWAN2VFSmod As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SplitContainerResults As System.Windows.Forms.SplitContainer
    Friend WithEvents tabcTXTFiles As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents tabcGraphs As System.Windows.Forms.TabControl
    Friend WithEvents LoadFromXMLToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmiLoadXMLSWANVFSmod As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmiNextEvent As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmiPrevEvent As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents rtbP2T As System.Windows.Forms.RichTextBox
    Friend WithEvents tsmiSaveScenarioUserInput As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblPoint As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblPoint2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblAddInfo As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents rtbLog As System.Windows.Forms.RichTextBox
    Friend WithEvents tsmiRun As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmiLoadScenarioUserInput As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmiSaveTOXSWARunInfo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoadTOXSWARunInfo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmiOpenEasySelectDialog As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmiLoadCompleteModel As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GraphToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoadCWAToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmiSaveCompleteModel As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveToWmfToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmiOnlyCreateBatchToolStrip As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmiRunOnlyVFSmod As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmiRunVFSmodAndTOXSWA As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmiShowDetails As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents JustRebuildP2tToolStripMenuItem As ToolStripMenuItem
End Class
