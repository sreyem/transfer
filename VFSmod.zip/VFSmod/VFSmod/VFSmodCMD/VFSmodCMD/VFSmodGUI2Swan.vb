﻿Imports System.ComponentModel
Imports System.Xml.Serialization
Imports System.IO

Imports VFSmodCMD.Common

''' <summary>
''' VFSmod result list incl. log
''' </summary>
''' <remarks></remarks>
'<DebuggerStepThrough()>
<Serializable()>
Public Class VFSmodGUI2Swan

    Public Sub New()

    End Sub

    <DisplayName("VFSmod result list")>
    <Browsable(False)>
    Public Property VFSmodResults As New List(Of VFSmodResult)

    <DisplayName("Log from VFSmod GUI")>
    Public Property Log As String() = {}

    <XmlIgnore()>
    <Browsable(False)>
    Public Property ErrorStdValue As Double = 0

    Public Function getVFSmodOWQResult(OWQFileName As String,
                                       EventDate As Date) As VFSmodResult

        Dim Dummy As String = ""

        Dim OWQFileArray As String() = {}
        Dim Result As New VFSmodResult
        Dim TestDate As Date = Nothing
        Dim ShowOWQFile As Boolean = False
        Dim TempString As String = ""

        Try

            OWQFileArray = File.ReadAllLines(OWQFileName)

            With Result

                'date
                .EventDate = EventDate

                'Infiltration  dQ 
                Try

                    Dummy = Filter(OWQFileArray,
                                   "Infiltration",
                                   True,
                                   CompareMethod.Binary).First

                    .Infiltration = Math.Round(Double.Parse(Trim(Split(Dummy, "%").First)) / 100, 5)

                    If [Double].IsNaN(.RunoffInflowReduction) Then Throw New Exception(Dummy)


                Catch ex As Exception

                    Dummy = .EventDate.ToString & " : " & Dummy

                    If ErrorStdValue = -99 Then

                        Common.log("Can't read 'Infiltration' from" & vbCrLf &
                                                    OWQFileName & vbCrLf & Dummy & vbCrLf &
                                                    ex.Message & vbCrLf & EOP)
                    Else

                        Common.log("Can't read 'Infiltration' from" & vbCrLf &
                                                  OWQFileName & vbCrLf & Dummy & vbCrLf &
                                                  ex.Message)

                        .Infiltration = ErrorStdValue
                        Common.log("Infiltration  = " & .Infiltration)
                        ShowOWQFile = True

                    End If

                End Try

                'Pesticide reduction dP
                Try

                    Dummy = Filter(OWQFileArray,
                                   "Pesticide reduction",
                                   True,
                                   CompareMethod.Binary).First

                    .PesticideReduction = Math.Round(Double.Parse(Trim(Split(Dummy, "%").First)) / 100, 5)

                    If [Double].IsNaN(.PesticideReduction) Then Throw New Exception(Dummy)

                    'if PesticideReduction < 0 correct to 0
                    If .PesticideReduction < 0 Then
                        Common.log("PesticideReduction = 0 (" & .PesticideReduction & ")")
                        .PesticideReduction = 0
                        .RunError = True
                    End If

                Catch ex As Exception

                    Dummy = .EventDate.ToString & " : " & Dummy

                    If ErrorStdValue = -99 Then

                        Common.log("Can't read 'Pesticide reduction' from" & vbCrLf &
                                                    OWQFileName & vbCrLf & Dummy & vbCrLf &
                                                    ex.Message & vbCrLf & EOP)
                    Else

                        Common.log("Can't read 'Pesticide reduction' from" & vbCrLf &
                                                    OWQFileName & vbCrLf & Dummy & vbCrLf &
                                                    ex.Message)

                        .PesticideReduction = ErrorStdValue
                        Common.log("PesticideReduction  = " & .PesticideReduction)
                        ShowOWQFile = True

                    End If

                End Try

                'Infiltration  dQ (Runoff inflow reduction)
                Try

                    Dummy = Filter(OWQFileArray,
                                   "Runoff inflow reduction",
                                   True,
                                   CompareMethod.Binary).First

                    .RunoffInflowReduction = Math.Round(Double.Parse(Trim(Split(Dummy, "%").First)) / 100, 5)

                    If [Double].IsNaN(.RunoffInflowReduction) Then Throw New Exception(Dummy)

                    'if RunoffInflowReduction < 0 correct to 0
                    'If .RunoffInflowReduction < 0 Then
                    '    Common.log("RunoffInflowReduction = 0 (" & .RunoffInflowReduction & ")")
                    '    .RunoffInflowReduction = 0
                    '    .RunError = True
                    'End If

                Catch ex As Exception

                    Dummy = .EventDate.ToString & " : " & Dummy

                    If ErrorStdValue = -99 Then

                        Common.log("Can't read 'Runoff inflow reduction' from" & vbCrLf &
                                                    OWQFileName & vbCrLf & Dummy & vbCrLf &
                                                    ex.Message & vbCrLf & EOP)
                    Else

                        Common.log("Can't read 'Runoff inflow reduction' from" & vbCrLf &
                                                  OWQFileName & vbCrLf & Dummy & vbCrLf &
                                                  ex.Message)

                        .RunoffInflowReduction = ErrorStdValue
                        Common.log("RunoffInflowReduction  = " & .RunoffInflowReduction)
                        ShowOWQFile = True

                    End If

                End Try

                'Sediment reduction (dE)
                Try

                    Dummy = Filter(OWQFileArray,
                                   "Sediment reduction (dE)",
                                   True,
                                   CompareMethod.Binary).First

                    .SedimentReduction = Math.Round(Double.Parse(Trim(Split(Dummy, "%").First)) / 100, 5)

                    If [Double].IsNaN(.SedimentReduction) Then Throw New Exception(Dummy)

                    'if SedimentReduction < 0 correct to 0
                    If .SedimentReduction < 0 Then
                        Common.log("SedimentReduction = 0 (" & .SedimentReduction & ")")
                        .SedimentReduction = 0
                        .RunError = True
                    End If

                Catch ex As Exception

                    Dummy = .EventDate.ToString & " : " & Dummy

                    If ErrorStdValue = -99 Then

                        Common.log("Can't read 'Sediment reduction (dE)' from" & vbCrLf &
                                                OWQFileName & vbCrLf & Dummy & vbCrLf &
                                                ex.Message & vbCrLf & EOP)
                    Else

                        Common.log("Can't read 'Sediment reduction (dE)' from" & vbCrLf &
                                                OWQFileName & vbCrLf & Dummy & vbCrLf &
                                                ex.Message)

                        .SedimentReduction = ErrorStdValue
                        Common.log("SedimentReduction  = " & .SedimentReduction)
                        ShowOWQFile = True

                    End If

                End Try

                'Pesticide surface residue
                Try

                    'outdated
                    'Dummy = Filter(OWQFileArray,
                    '               "mg/m2= Pesticide surface residue at the start of next event",
                    '               True,
                    '               CompareMethod.Binary).First


                    Dummy = Filter(OWQFileArray,
                                   "mg/m2= Pesticide surface residue at next event (after degradation,",
                                   True,
                                   CompareMethod.Binary).First

                    TempString = Trim(Split(Dummy, "mg").First)

                    If Not TempString.Contains("E") Then

                        TempString = Replace(TempString, "-", "E-")
                        TempString = Replace(TempString, "+", "E+")

                    End If

                    .ResidualMass = Double.Parse(TempString)

                    If [Double].IsNaN(.ResidualMass) Then Throw New Exception(Dummy)

                    'if ResidualMass < 0 correct to 0
                    If .ResidualMass < 0 Then
                        Common.log("ResidualMass = 0 (" & .ResidualMass & ")")
                        .ResidualMass = 0
                        .RunError = True
                    End If

                Catch ex As Exception

                    If ErrorStdValue = -99 Then

                        Common.log("Can't read 'Pesticide surface residue' in mg/m2 from" & vbCrLf &
                                                OWQFileName & vbCrLf & Dummy & vbCrLf &
                                                ex.Message & vbCrLf & EOP)

                    Else

                        Common.log("Can't read 'Pesticide surface residue' in mg/m2 from" & vbCrLf &
                                                OWQFileName & vbCrLf & Dummy & vbCrLf &
                                                ex.Message)

                        .ResidualMass = ErrorStdValue
                        Common.log("ResidualMass  = " & .ResidualMass)
                        ShowOWQFile = True

                    End If

                End Try


                'Runoff inflow (m3)
                Try

                    Dummy = Filter(OWQFileArray,
                                   "m3 = Runoff inflow",
                                   True,
                                   CompareMethod.Binary).First

                    TempString = Trim(Split(Dummy, "m3").First)

                    If Not TempString.Contains("E") Then

                        TempString = Replace(TempString, "-", "E-")
                        TempString = Replace(TempString, "+", "E+")

                    End If

                    .RunoffInflow = Double.Parse(TempString)

                    If [Double].IsNaN(.RunoffInflow) Then Throw New Exception(Dummy)


                    'if RunoffInflow < 0 correct to 0
                    If .RunoffInflow < 0 Then
                        Common.log("RunoffInflow = 0 (" & .RunoffInflow & ")")
                        .RunoffInflow = 0
                        .RunError = True
                    End If

                Catch ex As Exception

                    Dummy = .EventDate.ToString & " : " & Dummy

                    Common.log("Can't read 'Runoff inflow (m3)' from" & vbCrLf &
                                                OWQFileName & vbCrLf & Dummy & vbCrLf &
                                                ex.Message)

                    .RunoffInflow = ErrorStdValue
                    Common.log("RunoffInflow  = " & .RunoffInflow)
                    ShowOWQFile = True

                End Try

                'Sediment inflow (kg)
                Try

                    Dummy = Filter(OWQFileArray, "Kg = Sediment inflow", True, CompareMethod.Binary).First

                    TempString = Trim(Split(Dummy, "Kg").First)

                    If Not TempString.Contains("E") Then

                        TempString = Replace(TempString, "-", "E-")
                        TempString = Replace(TempString, "+", "E+")

                    End If

                    .SedimentInflow = Double.Parse(TempString)

                    If [Double].IsNaN(.SedimentInflow) Then Throw New Exception(Dummy)


                    'if SedimentInflow < 0 correct to 0
                    If .SedimentInflow < 0 Then
                        Common.log("SedimentInflow = 0 (" & .SedimentInflow & ")")
                        .RunoffInflow = 0
                        .RunError = True
                    End If

                Catch ex As Exception

                    Dummy = .EventDate.ToString & " : " & Dummy

                    Common.log("Can't read 'Sediment inflow (kg)' from" & vbCrLf &
                                                OWQFileName & vbCrLf & Dummy & vbCrLf &
                                                ex.Message)

                    .SedimentInflow = ErrorStdValue
                    Common.log("SedimentInflow  = " & .SedimentInflow)
                    ShowOWQFile = True

                End Try

                'Phase distribution, Fph
                Try

                    Dummy = Filter(OWQFileArray, "Phase distribution, Fph", True, CompareMethod.Binary).First

                    .PhaseDistribution = Double.Parse(Trim(Split(Dummy, "=").First))
                    If [Double].IsNaN(.PhaseDistribution) Then Throw New Exception(Dummy)
                Catch ex As Exception

                    Dummy = .EventDate.ToString & " : " & Dummy

                    Common.log("Can't read 'Phase distribution, Fph' from" & vbCrLf &
                                                OWQFileName & vbCrLf & Dummy & vbCrLf &
                                                ex.Message)

                    .PhaseDistribution = ErrorStdValue
                    Common.log("PhaseDistribution  = " & .PhaseDistribution)
                    ShowOWQFile = True

                End Try

            End With

            If ShowOWQFile Then
                Common.log(Join(OWQFileArray, vbCrLf))
                ShowOWQFile = False
            End If


        Catch ex As Exception

            Common.log("Can't read VFSmod results from " & vbCrLf &
                                        OWQFileName & vbCrLf & Dummy & vbCrLf &
                                        ex.Message & vbCrLf & EOP)

        End Try

        Return Result

    End Function

End Class

''' <summary>
''' VFSmod result for a single event
''' </summary>
''' <remarks></remarks>
<DebuggerStepThrough()>
<Serializable()>
Public Class VFSmodResult

    Public Sub New()

    End Sub


    <DisplayName("Event Date")>
    Public Property EventDate As Date = Nothing

    <DisplayName("Infiltration (dQ) (frac)")>
    Public Property Infiltration As Double = -99

    <DisplayName("Sediment Reduction (dE) (frac)")>
    Public Property SedimentReduction As Double = -99

    <DisplayName("Runoff Inflow Reduction (frac)")>
    Public Property RunoffInflowReduction As Double = -99

    <DisplayName("Pesticide Reduction  (dP) (frac)")>
    Public Property PesticideReduction As Double = -99

    ''' <summary>
    ''' Needed for dgPin; mo in the equation
    ''' </summary>
    <DisplayName("Residual mass (mg/m)")>
    Public Property ResidualMass As Double = -99

    '<XmlIgnore()>
    <DisplayName("Runoff inflow (m3)")>
    Public Property RunoffInflow As Double = -99

    '<XmlIgnore()>
    <DisplayName("Sediment inflow (kg)")>
    Public Property SedimentInflow As Double = -99

    '<XmlIgnore()>
    <DisplayName("Phase distribution, Fph")>
    Public Property PhaseDistribution As Double = -99

    <Browsable(False)>
    <XmlIgnore()>
    Public Property RunError As Boolean = False

End Class




