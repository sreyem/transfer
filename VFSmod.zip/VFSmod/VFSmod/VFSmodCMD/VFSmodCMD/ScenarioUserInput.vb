﻿
Imports System.ComponentModel
Imports System.Xml.Serialization
Imports System.IO

Imports VFSmodCMD.Common

Public Class ScenarioUserInput

#Region "Constructor"

    Public Sub New()

    End Sub

    Public Sub New(ScenarioUserInputFileName As String)

        Me.ScenarioUserInputFileName = ScenarioUserInputFileName
        readScenarioUserInputFile()

    End Sub

    Public Property ScenarioUserInputFileName As String

    Public Sub readScenarioUserInputFile(Optional ScenarioUserInputFileName As String = "")

        Dim TempScenarioUserInput As New ScenarioUserInput

        If ScenarioUserInputFileName <> "" Then
            Me.ScenarioUserInputFileName = ScenarioUserInputFileName
        End If

        Try

            TempScenarioUserInput = CType(LoadXML2Class(ClassType:=GetType(ScenarioUserInput),
                                               XMLFileName:=ScenarioUserInputFileName), 
                                          ScenarioUserInput)

            With TempScenarioUserInput

                Me.CompoundProperties = .CompoundProperties
                Me.ScenarioProperties = .ScenarioProperties
                Me.StdValues = .StdValues

            End With



        Catch ex As Exception

            Throw New Exception("Can't de-serialize xml to 'ScenarioUserInput'" & vbCrLf &
                                 ScenarioUserInputFileName & vbCrLf &
                                 ex.Message & vbCrLf &
                                 EOP)
            End

        End Try

    End Sub

#End Region

#Region "Properties"

    Public Property StdValues As New StdProperties

    Public Property ScenarioProperties As New ScenarioProperties

    Public Property CompoundProperties As New CompoundProperties

#End Region

End Class

#Region "SubClasses"

Public Class CompoundProperties

#Region "Constructor"

    Public Sub New()

    End Sub

    Public Sub New(INPFileName As String,
          Optional ParMet As Common.eParMet = eParMet.Parent)

        getCompoundProperties(INPFileName, ParMet)

    End Sub

#End Region

#Region "Properties"

    ''' <summary>
    ''' PRZM parameter file, *.inp
    ''' </summary>
    ''' <value>PRZM parameter file, *.inp</value>
    ''' <returns>String()</returns>
    ''' <remarks></remarks>
    <Description("PRZM parameter file, *.inp")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DisplayName("PRZM inp file")>
    <XmlIgnore()>
    Public Property INP() As String() = {}

    ''' <summary>
    ''' Adsorption Kd (ml/g)
    ''' </summary>
    ''' <value>Adsorption Kd (ml/g)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Adsorption Kd (ml/g)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DisplayName("Kd (mL/g)")>
    <DefaultValue(0)>
    Public Property Kd() As Double

    Private m_RateConstant As Double = 0

    ''' <summary>
    ''' RateConstant (1/d)
    ''' </summary>
    ''' <value>RateConstant (1/d)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("RateConstant (1/d)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DisplayName("Rate constant (1/d)")>
    <DefaultValue(0)>
    Public Property RateConstant() As Double
        Get
            Return m_RateConstant
        End Get
        Set(vRateConstant As Double)

            Try
                If vRateConstant = 0 Then
                    m_DT50 = 0
                Else
                    m_DT50 = Math.Round(Math.Log(2) / vRateConstant, 3)
                End If

                m_RateConstant = vRateConstant

            Catch ex As Exception
                Throw New ArgumentException("Invalid rate constant (1/d) " & vbCrLf &
                                            "k = " & vRateConstant, vbCrLf &
                                            ex.Message)
            End Try

        End Set
    End Property

    Private m_DT50 As Double = 0

    ''' <summary>
    ''' DT50 (d) = ln(2)/k
    ''' </summary>
    ''' <value>DT50 (d) = ln(2)/k</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("DT50 (d) = ln(2)/k")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DisplayName("DT50 (d)")>
    <DefaultValue(0)>
    <XmlIgnore()>
    Public Property DT50 As Double
        Get
            Return m_DT50
        End Get
        Set(vDT50 As Double)

            Try

                If vDT50 = 0 Then
                    m_RateConstant = 0
                Else
                    m_RateConstant = Math.Round(Math.Log(2) / vDT50, 6)
                End If

                m_DT50 = vDT50

            Catch ex As Exception
                Throw New ArgumentException("Invalid DT50 (d) " & vbCrLf &
                                            "DT50 = " & vDT50, vbCrLf &
                                            ex.Message)
            End Try
        End Set
    End Property

#End Region

    Public Sub getCompoundProperties(INPFileName As String,
                            Optional ParMet As Common.eParMet = eParMet.Parent)

        Dim DummyString As String = ""
        Dim Adsorption As String = ""
        Dim Index As Integer = 0
        Dim DummyArray As String() = {}


        'read inp file to array
        Try
            Me.INP = File.ReadAllLines(INPFileName)
        Catch ex As Exception
            log("Error reading inp file '" &
                 INPFileName & vbCrLf & ex.Message & vbCrLf & EOP)
        End Try


        'get offset
        Index = getIndex("Soil Series:", INP)
        If Index = -1 Then

            log("Can't find 'Soil Series:' in file '" &
                 vbCrLf & INPFileName & vbCrLf & EOP)
        End If


        'adsorption
        Try

            DummyString = Me.INP(Index + ParPos(enumParPos.OrganicContent, enumPos.Row))
            DummyArray = DummyString.Split({" "c}, StringSplitOptions.RemoveEmptyEntries)

            Select Case ParMet

                Case eParMet.Parent

                    Adsorption = DummyString.Substring(40, 8)

                Case eParMet.Metabolite

                    Adsorption = DummyString.Substring(48, DummyString.Length - 48)

            End Select

            Kd = Double.Parse(Adsorption)


        Catch ex As Exception
            log("Can't read adsorption data" & vbCrLf &
                 INPFileName & vbCrLf &
                 DummyString & vbCrLf &
                 ex.Message & vbCrLf &
                 EOP)
        End Try


        'degradation
        Try

            DummyString = Me.INP(-1 + Index + ParPos(enumParPos.OrganicContent, enumPos.Row))
            DummyArray = DummyString.Split({" "c}, StringSplitOptions.RemoveEmptyEntries)

            Select Case ParMet

                Case eParMet.Parent
                    DummyString = DummyArray(0)

                Case eParMet.Metabolite

                    If DummyArray.Count = 6 Then
                        DummyString = DummyArray(1)
                    Else
                        log("No Metabolite degradation data available" & vbCrLf & EOP)
                    End If

            End Select

            RateConstant = Double.Parse(DummyString)

        Catch ex As Exception
            log("Can't read degradation data" & vbCrLf &
                 INPFileName & vbCrLf & ex.Message)
        End Try

    End Sub

End Class

Public Class ScenarioProperties

    Public Sub New()

    End Sub

    Private m_FOCUSScenario As eFOCUSScenarios = eFOCUSScenarios.UserDefined

    Public Property FOCUSScenario As eFOCUSScenarios
        Get
            Return m_FOCUSScenario
        End Get
        Set(vFOCUSScenario As eFOCUSScenarios)

            Try

                If vFOCUSScenario <> eFOCUSScenarios.UserDefined Then

                    SOA = CDbl(RecomStdParameter(eRecomStdParameter.SOA, vFOCUSScenario - 1))
                    KS = CDbl(RecomStdParameter(eRecomStdParameter.KS, vFOCUSScenario - 1))
                    SAV = CDbl(RecomStdParameter(eRecomStdParameter.SAV, vFOCUSScenario - 1))
                    ThetaS = CDbl(RecomStdParameter(eRecomStdParameter.ThetaS, vFOCUSScenario - 1))
                    PCTOC = CDbl(RecomStdParameter(eRecomStdParameter.PCTOC, vFOCUSScenario - 1))
                    PCTC = CDbl(RecomStdParameter(eRecomStdParameter.PCTC, vFOCUSScenario - 1))
                    RHO = CDbl(RecomStdParameter(eRecomStdParameter.RHO, vFOCUSScenario - 1))
                    FC = CDbl(RecomStdParameter(eRecomStdParameter.FC, vFOCUSScenario - 1))
                    hmax = CDbl(RecomStdParameter(eRecomStdParameter.hmax, vFOCUSScenario - 1))
                    ThetaR = CDbl(RecomStdParameter(eRecomStdParameter.VGthetaR, vFOCUSScenario - 1))
                    Alfa = CDbl(RecomStdParameter(eRecomStdParameter.VGalfa, vFOCUSScenario - 1))
                    n = CDbl(RecomStdParameter(eRecomStdParameter.VGn, vFOCUSScenario - 1))

                End If

                m_FOCUSScenario = vFOCUSScenario

            Catch ex As Exception

                log("Can't set FOCUS Scenario std. values" & vbCrLf &
                    ex.Message & vbCrLf & EOP)

            End Try


        End Set
    End Property

    ''' <summary>
    ''' "Filter slope for
    ''' each segment in m/m, ikw 
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Filter slope for " & vbCrLf &
                 "each segment in m/m, ikw")>
    Public Property SOA As Double

    ''' <summary>
    ''' Soil vertical saturated hydraulic
    ''' conductivity in the VFS in m/s, iso
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Soil vertical saturated hydraulic" & vbCrLf &
                 "conductivity in the VFS in m/s, iso ")>
    Public Property KS As Double

    ''' <summary>
    ''' Green-Ampt’s average suction at the
    ''' wetting front in m, iso 
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Green-Ampt’s average suction at the" & vbCrLf &
                 "wetting front in m, iso ")>
    Public Property SAV As Double

    ''' <summary>
    ''' Saturated soil water content
    ''' Theta s (OS) in m^3/m^3, iso 
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Saturated soil water content" & vbCrLf &
                 "Theta s (OS) in m^3/m^3, iso ")>
    Public Property ThetaS As Double

    ''' <summary>
    ''' Percentage of organic
    ''' carbon in sediment in %, iso
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Organic carbon in sediment in %, iso")>
    Public Property PCTOC As Double

    ''' <summary>
    ''' Percentage clay in sediment in % , iso
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Clay in sediment in % , iso and iwq")>
    Public Property PCTC As Double

    ''' <summary>
    ''' Bulk Density in g/cm^3 , isd
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Bulk Density in g/cm^3 , isd")>
    Public Property RHO As Double

    ''' <summary>
    ''' Field capacity in m^3/m^3 , iwq
    ''' Taken from FOCUS manual
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Field capacity in m^3/m^3 , iwq")>
    Public Property FC As Double

    ''' <summary>
    ''' Max water height in stream in m (std.~ 0.709m) , iso
    ''' Taken from presentation from Robin
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Max water height in stream in m (std.~ 0.709m) , iso")>
    Public Property hmax As Double

    ''' <summary>
    ''' Theta r, van Genuchten parameter , iso
    ''' Taken from Hypres
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Theta r, van Genuchten parameter , iso")>
    Public Property ThetaR As Double


    ''' <summary>
    ''' van Genuchten Alpha, parameter of the soil water retention curve , iso
    ''' Taken from Hypres
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Alpha, van Genuchten parameter , iso")>
    Public Property Alfa As Double

    ''' <summary>
    ''' n, van Genuchten parameter , iso
    ''' Taken from Hypres
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("n, van Genuchten parameter , iso")>
    Public Property n As Double

    ''' <summary>
    ''' m, van Genuchten parameter , iso
    ''' Taken from Hypres
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("m, van Genuchten parameter = 1-(1/n) , iso")>
    Public ReadOnly Property m As Double
        Get
            Try

                If n = 0 Then
                    Return 0
                Else
                    Return 1 - (1 / n)
                End If

            Catch ex As Exception
                Return -1
            End Try
        End Get
    End Property


End Class

Public Class StdProperties

    Public Sub New()

    End Sub

    Private m_WaterBody As eRWB = eRWB.Stream


    ''' <summary>
    ''' FOCUS waterbody
    ''' Stream (std): 100m*100m
    ''' Pond        : 30m *150m
    ''' </summary>
    <Description("FOCUS waterbody" & vbCrLf &
                 "Stream (std): 100m*100m" & vbCrLf &
                 "Pond        : 30m *150m")>
    <DefaultValue(eRWB.Stream)>
    Public Property WaterBody As eRWB
        Get
            Return m_WaterBody
        End Get
        Set(value As eRWB)

            If value = eRWB.Pond Then
                Me.FWIDTH = 30
            Else
                Me.FWIDTH = 100
            End If

        End Set
    End Property


    Private m_VL As Double = 5

    ''' <summary>
    ''' "Length in the direction of the flow in m
    ''' Buffer strip lenght, ikw
    ''' </summary>
    <Description("Length in the direction of the flow in m" & vbCrLf &
                 "Buffer strip lenght, ikw")>
    <DefaultValue(5)>
    <[ReadOnly](True)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property VL As Double
        Get
            Return m_VL
        End Get
        Set(value As Double)

            m_VL = value

            If Me.NodesCalcUser = eNodes.Calculated Then

                'base for n: buffer = 5 => n = 57
                m_N = CInt(Math.Round(value / 5 * 57, 0))

                'make sure n is an odd no
                If Math.IEEERemainder(m_N, 2) = 0 Then m_N += 1

                'limit n to 115 max.
                If m_N > 115 Then m_N = 115

            End If

        End Set
    End Property

    ''' <summary>
    ''' Effective flow width of the strip in m
    ''' perpendicular to the flow, ikw (std.=100)
    ''' </summary>
    <Description("Effective flow width of the strip in m" & vbCrLf &
                 "perpendicular to the flow, ikw (std.=100)")>
    <DefaultValue(100)>
    Public Property FWIDTH As Double = 100

    ''' <summary>
    ''' Filter Manning’s roughness n
    ''' for each segment in s/m^(1/3), ikw (std.=0.4)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Filter Manning’s roughness n " & vbCrLf &
                 "for each segment in s/m^(1/3), ikw (std.=0.4)")>
    <DefaultValue(0.4)>
    Public Property RNA As Double = 0.4


    ''' <summary>
    ''' Maximum surface storage (m, default 0)
    ''' </summary>
    ''' <value>Maximum surface storage (m, default 0)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Maximum surface storage" & vbCrLf &
                 "in m, iso (std.=0)")>
    <DefaultValue(0)>
    Public Property SM() As Double = 0


    ''' <summary>
    ''' Relative distance from the upper filter
    ''' edge where check for ponding is made, iso (std.=0.5)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Relative distance from the upper filter" & vbCrLf &
                 "edge where check for ponding is made, iso (std.=0.5)")>
    <DefaultValue(0.5)>
    Public Property SCHK As Double = 0.5

    ''' <summary>
    ''' Average spacing of 
    ''' grass stems in cm, igr (std.=1.63)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Average spacing of " & vbCrLf &
                 "grass stems in cm, igr (std.=1.63)")>
    <DefaultValue(1.63)>
    Public Property SS As Double = 1.63

    ''' <summary>
    ''' Filter media (grass) modified 
    ''' Manning’s roughness n in s/m^(1/3), igr (std.=0.012)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Filter media (grass) modified Manning’s" & vbCrLf &
                 "roughness vn in s/m^(1/3), igr (std.=0.012)")>
    <DefaultValue(0.012)>
    Public Property VN As Double = 0.012

    ''' <summary>
    ''' Filter grass height
    ''' in cm, igr (std.=10)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Filter grass height " & vbCrLf &
                 "in cm, igr (std.=10)")>
    <DefaultValue(10)>
    Public Property H As Double = 10

    ''' <summary>
    ''' Bare surface Manning’s n for sediment
    ''' inundated area in grass filter in s/m^(1/3), igr (std.=0.05)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Bare surface Manning’s n for sediment" & vbCrLf &
                 "inundated area in grass filter in s/m^(1/3), igr (std.=0.05)")>
    <DefaultValue(0.05)>
    Public Property VN2 As Double = 0.05

    ''' <summary>
    ''' Sediment particle size diameter
    ''' in cm, isd (std.=0.002)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Sediment particle size diameter" & vbCrLf &
                 "in cm, isd (std.=0.002)")>
    <DefaultValue(0.002)>
    Public Property DP As Double = 0.002

    ''' <summary>
    ''' Fraction of incoming sediment with
    ''' particle diameter >0.0037 cm, isd  (std.=0.04)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Fraction of incoming sediment with" & vbCrLf &
                 "particle diameter >0.0037 in cm, isd (std.=0.04)")>
    <DefaultValue(0.4)>
    Public Property COARSE As Double = 0.4

    ''' <summary>
    ''' Surface mixing layer thickness (cm)
    ''' </summary>
    ''' <value>Surface mixing layer thickness (cm)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Surface mixing layer thickness (cm, IWQ)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DisplayName("Mixing layer thickness")>
    <DefaultValue(2)>
    Public Property dgML As Double = 2

    Public Enum eShape
        Rectangle = 2
        Triangle = 3
    End Enum
   
    ''' <summary>
    ''' Hydrograph shape; Rectangle or Triangle
    ''' </summary>
    ''' <value> Hydrograph shape; Rectangle or Triangle</value>
    ''' <remarks></remarks>
    <Description("Hydrograph shape" & vbCrLf &
                 "Rectangle or Triangle, IRO")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DisplayName("Hydrograph shape")>
    <DefaultValue(eShape.Rectangle)>
    Public Property HydrographShape As eShape = eShape.Rectangle

    Public Enum eNodes
        Calculated
        UserDef
    End Enum

    Private m_NodesCalcUser As eNodes = eNodes.Calculated

    ''' <summary>
    '''Number of nodes set by user or calc. by 57/5*bufferlen
    ''' </summary>
    ''' <value> Calculated or UserDef</value>
    ''' <remarks></remarks>
    <Description("Number of Nodes" & vbCrLf &
                 "Number of nodes set by user or calc. by 57/5*bufferlen")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DisplayName("Nodes method")>
    <DefaultValue(eNodes.Calculated)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property NodesCalcUser As eNodes
        Get
            Return m_NodesCalcUser
        End Get
        Set(value As eNodes)

            m_NodesCalcUser = value

            If value = eNodes.Calculated Then
                VL = m_VL
            End If

        End Set
    End Property

    Private m_N As Integer = 57

    ''' <summary>
    ''' Number of nodes in the domain (integer) 
    ''' (must be an odd number for a quadratic finite element solution, 
    ''' but the program checks and corrects if needed). 
    ''' (57 recommended)
    ''' </summary>
    ''' <value>57 recommended</value>
    ''' <returns>Integer</returns>
    ''' <remarks></remarks>
    <Description("Number of nodes in the domain (integer, IKW)" & vbCrLf &
                 "(57 recommended for 5m bufferlenght, limits: 13 < N < 115")>
    <Browsable(True)>
    <DisplayName("N")>
    <[ReadOnly](False)>
    <DefaultValue(1)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property N() As Integer
        Get
            Return m_N
        End Get
        Set(value As Integer)

            If NodesCalcUser = eNodes.Calculated Then Exit Property

            If value > 115 Then
                m_N = 115
            ElseIf value < 13 Then
                m_N = 13
            Else
                m_N = value
            End If

        End Set
    End Property


    Private m_AreaCorrFac As Double = 2.22

    ''' <summary>
    ''' Area corr. fact. for erosion mass column
    ''' from 0.45ha (PRZM std.) to 1ha for streams 
    ''' (std  =2.22)
    ''' </summary>
    ''' <value>2.2 std.</value>
    ''' <returns>Double</returns>
    ''' <remarks>This was introduced because of an comment from S. Reichenberger</remarks>
    <Description("Area corr. fact. for erosion mass column" & vbCrLf &
                 "from 0.45ha (PRZM std.) to 1ha for streams, std. = 2.22")>
    <Browsable(True)>
    <DisplayName("AreaCorrFac")>
    <[ReadOnly](False)>
    <DefaultValue(2.22)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property AreaCorrFac() As Double
        Get
            Return m_AreaCorrFac
        End Get
        Set(value As Double)
            m_AreaCorrFac = value
        End Set
    End Property

    ''' <summary>
    ''' pesticide trapping 
    ''' </summary>
    Public Enum eIWQPRO

        Sabbagh_refitted = 1
        Sabbagh = 2
        Mechanistic_MassBalance = 3
        Empirical_Equation = 4

    End Enum

    Private m_IWQPRO As eIWQPRO = eIWQPRO.Mechanistic_MassBalance

    ''' <summary>
    ''' pesticide trapping equation
    ''' </summary>
    ''' <returns></returns>
    <Description("Pesticide Trapping Equation" & vbCrLf &
                 "std. = 3 Mechanistic_MassBalance")>
    <DefaultValue(CInt(eIWQPRO.Mechanistic_MassBalance))>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    Public Property IWQPRO As eIWQPRO
        Get
            Return m_IWQPRO
        End Get
        Set(value As eIWQPRO)
            m_IWQPRO = value
        End Set
    End Property

#Region "    Fitting Coefficients"

    <DefaultValue(0)>
    <Description("Fitting Coefficients for" & vbCrLf &
                 "delta P for IWQPRO = 1 = Sabbagh")>
    Public Property CSAB1 As Double = 0

    <DefaultValue(0)>
    <Description("Fitting Coefficients for" & vbCrLf &
                 "delta P for IWQPRO = 1 = Sabbagh")>
    Public Property CSAB2 As Double = 0

    <DefaultValue(0)>
    <Description("Fitting Coefficients for" & vbCrLf &
                 "delta P for IWQPRO = 1 = Sabbagh")>
    Public Property CSAB3 As Double = 0

    <DefaultValue(0)>
    <Description("Fitting Coefficients for" & vbCrLf &
                 "delta P for IWQPRO = 1 = Sabbagh")>
    Public Property CSAB4 As Double = 0

#End Region

    Private m_WaterTableDepth As Boolean = True

    ''' <summary>
    ''' Switch WTD on or off
    ''' </summary>
    ''' <value>true</value>
    <Description("Water Table Depth" & vbCrLf &
                 "on = true (std) or off = false")>
    <Browsable(True)>
    <DisplayName("Water Table Depth")>
    <[ReadOnly](False)>
    <DefaultValue(2.22)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property WaterTableDepth() As Boolean
        Get
            Return m_WaterTableDepth
        End Get
        Set(value As Boolean)
            m_WaterTableDepth = value
        End Set
    End Property


    Private m_d As Double = 0.0

    ''' <summary>
    ''' Overboard, distance to the top of the canal
    ''' at maximum stage to avoid flooding, std. 0m, iso 
    ''' </summary>
    ''' <value>0</value>
    ''' <returns>Double</returns>
    ''' <remarks>Water table depth parameter</remarks>
    <Description("Overboard, distance to the top of the canal" & vbCrLf &
                 "in meter at maximum stage to avoid flooding, std. 0m, iso")>
    <Browsable(True)>
    <DisplayName("d")>
    <[ReadOnly](False)>
    <DefaultValue(0.3)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property d() As Double
        Get
            Return m_d
        End Get
        Set(value As Double)
            m_d = value
        End Set
    End Property

    ''' <summary>
    ''' Soil water characteristic curve type with values
    ''' 1 = van Genuchten, iso 
    ''' </summary>
    ''' <value>1</value>
    ''' <returns>integer</returns>
    ''' <remarks>Water table depth parameter</remarks>
    <Description("Soil water characteristic curve type" & vbCrLf &
                 "1 = van Genuchten, iso")>
    <Browsable(True)>
    <DisplayName("ITHETATYPE")>
    <[ReadOnly](False)>
    <DefaultValue(1)>
    <RefreshProperties(RefreshProperties.All)>
    Public ReadOnly Property ITHETATYPE As Integer = 1


    ''' <summary>
    ''' Soil water characteristic curve type with values
    ''' 1 = van Genuchten, iso 
    ''' </summary>
    ''' <value>1</value>
    ''' <returns>integer</returns>
    ''' <remarks>Water table depth parameter</remarks>
    <Description("Unsaturated hydraulic conductivity curve type" & vbCrLf &
                 "1 = van Genuchten, iso")>
    <Browsable(True)>
    <DisplayName("IKUNSTYPE")>
    <[ReadOnly](False)>
    <DefaultValue(1)>
    <RefreshProperties(RefreshProperties.All)>
    Public ReadOnly Property IKUNSTYPE As Integer = 1

    ''' <summary>
    ''' Lower boundary condition, std. = 1
    ''' std. = 1 = Dupuis Forchheimer, iso
    ''' </summary>
    ''' <value>1</value>
    ''' <returns>integer</returns>
    ''' <remarks>Water table depth parameter</remarks>
    <Description("Lower boundary condition, std. = 1 " & vbCrLf &
                 "std. = 1 = Dupuis Forchheimer, iso")>
    <Browsable(True)>
    <DisplayName("IKUNSTYPE")>
    <[ReadOnly](False)>
    <DefaultValue(1)>
    <RefreshProperties(RefreshProperties.All)>
    Public ReadOnly Property ITWBDC As Integer = 1

    ''' <summary>
    ''' Ratio horizontal/vertical conductivity
    ''' std. = 1, iso
    ''' </summary>
    ''' <value>1</value>
    ''' <returns>integer</returns>
    ''' <remarks>Water table depth parameter</remarks>
    <Description("Ratio horizontal/vertical conductivity" & vbCrLf &
                 "std. = 1, iso")>
    <Browsable(True)>
    <DisplayName("IKUNSTYPE")>
    <[ReadOnly](False)>
    <DefaultValue(1)>
    <RefreshProperties(RefreshProperties.All)>
    Public ReadOnly Property RHV As Integer = 1

End Class

#End Region
