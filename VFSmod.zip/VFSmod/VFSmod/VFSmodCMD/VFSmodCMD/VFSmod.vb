﻿
Imports System.ComponentModel
Imports System.Xml.Serialization
Imports System.IO
Imports System.Windows.Forms

Imports VFSmodCMD.Common

Public Class VFSmod

    Public Sub New()

    End Sub

    Public Const vfsmFileName As String = "vfsm440.exe"


    Public Sub New(Swan2VFSmodGUIFilePath As String)

        getSwan2VFSmodGUIInfo(Swan2VFSmodGUIFilePath)

    End Sub

    Public Sub New(Swan2VFSmodGUIFilePath As String,
                   TOXSWArunInfoFilePath As String)

        getSwan2VFSmodGUIInfo(Swan2VFSmodGUIFilePath)
        getTOXSWArunInfo(TOXSWArunInfoFilePath)

    End Sub

    Public Sub getSwan2VFSmodGUIInfo(Swan2VFSmodGUIFilePath As String)

        'parse Swan2VFSmodGUI info
        deserializeSwan2VFSmodGUIXML(Swan2VFSmodGUIFilePath)

        'get ThetaI and FOCUSTemp data matrix
        initThetaIFocusTempWTD()

        With Swan2VFSmodGUI.Paths

            'parse ScenarioUserInput
            deserializeScenarioUserInputXML(.ScenarioUserInputFilePath)

            'get comp. data from ScenarioUserInput or from inp file
            With Me.ScenarioUserInput.CompoundProperties
                If .Kd = 0 AndAlso
                   .RateConstant = 0 Then
                    getCompoundDataFromINPFile(Swan2VFSmodGUI.Paths.inpFilePath)
                End If
            End With

            'get event data
            getPRZMOUTData(p2tFilePath:=.p2tFilePath,
                           ztsFilePath:=.ztsFilePath)

        End With

        'generate  vfsmod inp. files
        generateVFSmodInputFiles()

    End Sub

    Public Sub getTOXSWArunInfo(TOXSWArunFilePath As String)

        If TOXSWArunFilePath.ToUpper = "STD" Then
            log("Std. TOXSWA info used")
            Me.TOXSWArun = New TOXSWAInfo
        Else

            'parse TOXSWArun info
            Try

                TOXSWArunFilePath = Path.GetFullPath(TOXSWArunFilePath)

                log("De-Serialize 'TOXSWArun.xml' form " & TOXSWArunFilePath)
                Me.TOXSWArun = CType(LoadXML2Class(ClassType:=GetType(TOXSWAInfo),
                                                 XMLFileName:=TOXSWArunFilePath), 
                                     VFSmodCMD.TOXSWAInfo)
                log("De-Serialize 'TOXSWArun.xml' OK")
            Catch ex As Exception

                log("Can't De-Serialize TOXSWArun.xml")

                log("CMD-line argument: full path to Swan2VFSmodGUI.xml")
                log("                   " & CMDArgs(0))
                log("                   full path to TOXSWAInfo.xml")
                log("                   " & TOXSWArunFilePath)
                log(ex.Message)
                log(EOP)

            End Try

        End If

    End Sub

#Region "Properties"

    <Browsable(False)>
    Public Property PRZMOutData As New PRZMOutData

    <Browsable(False)>
    Public Property ScenarioUserInput As New ScenarioUserInput

    <Browsable(False)>
    Public Property VFSmodInputFileSets As New List(Of VFSmodInputFilesSet)

    <Browsable(False)>
    Public Property Swan2VFSmodGUI As New Swan2VFSmodGUI

    <Browsable(False)>
    Public Property VFSmodGUI2Swan As New VFSmodGUI2Swan

    <Browsable(False)>
    Public Property TOXSWArun As New TOXSWAInfo

#End Region

#Region "Methods"

#Region "Run vfsm.exe"

#Region "Prepare vfsm run"

    Public Sub initThetaIFocusTempWTD(Optional ThetaIDataFilePath As String = "",
                                      Optional FOCUSTempFilePath As String = "",
                                      Optional WTDFilePath As String = "")

        Dim DataFilePath As String = ""

        '*** ThetaIData ***

        If ThetaIDataFilePath = "" Then
            DataFilePath = Path.Combine(ExecPath, "ThetaIData.txt")
        Else
            DataFilePath = ThetaIDataFilePath
        End If


        'check no of entries in 'ThetaIData.txt'
        Try

            log("Read init. soil moist. from " & vbTab & DataFilePath)
            ThetaIData = File.ReadAllLines(DataFilePath)

            If ThetaIData.Count = 7306 Then
                log("Read init. soil moist. OK ")
            Else
                log("Wrong no of entries in " & DataFilePath)
                log(ThetaIData.Count & " entries, not 7306")
                log(EOP)
            End If

        Catch ex As Exception

            log("Can't read init. soil moist. from " &
                DataFilePath & vbCrLf &
                ex.Message & vbCrLf &
                EOP)

        End Try

        '*** FOCUSTemp ***

        If FOCUSTempFilePath = "" Then
            DataFilePath = Path.Combine(ExecPath, "FOCUSTemp.txt")
        Else
            DataFilePath = FOCUSTempFilePath
        End If

        'check no of entries in 'FOCUSTemp.txt'
        Try

            log("Read FOCUS temp. from " & vbTab & vbTab & DataFilePath)
            FOCUSTemp = File.ReadAllLines(DataFilePath)

            If FOCUSTemp.Count = 7306 Then
                log("Read FOCUS temp. OK ")
            Else
                log("Wrong no of entries in " & DataFilePath)
                log(FOCUSTemp.Count & " entries, not 7306")
                log(EOP)
            End If

        Catch ex As Exception

            log("Can't read FOCUS temp. from " &
            DataFilePath & vbCrLf &
            ex.Message & vbCrLf &
            EOP)

        End Try

        '*** Water Table Depth ***

        If WTDFilePath = "" Then
            DataFilePath = Path.Combine(ExecPath, "TOXSWAWaterDepths.txt")
        Else
            DataFilePath = FOCUSTempFilePath
        End If

        'check no of entries in 'FOCUSTemp.txt'
        Try

            log("Read Water Table Depths from " & vbTab & vbTab & DataFilePath)
            TOXSWAWaterDepths = File.ReadAllLines(DataFilePath)

            If TOXSWAWaterDepths.Count = 7306 Then
                log("Read Water Table Depths OK ")
            Else
                log("Wrong no of entries in " & DataFilePath)
                log(TOXSWAWaterDepths.Count & " entries, not 7306")
                log(EOP)
            End If

        Catch ex As Exception

            log("Can't read Water Table Depths from " &
            DataFilePath & vbCrLf &
            ex.Message & vbCrLf &
            EOP)

        End Try


    End Sub

    Public Sub deserializeSwan2VFSmodGUIXML(Swan2VFSmodGUIXMLFilePath As String)

        Try

            Swan2VFSmodGUIXMLFilePath = Path.GetFullPath(Swan2VFSmodGUIXMLFilePath)

            log("De-Serialize 'Swan2VFSmodGUI.xml' from " & Swan2VFSmodGUIXMLFilePath)
            Swan2VFSmodGUI = CType(LoadXML2Class(ClassType:=GetType(Swan2VFSmodGUI),
                                               XMLFileName:=Swan2VFSmodGUIXMLFilePath), 
                                   Swan2VFSmodGUI)
            log("De-Serialize 'Swan2VFSmodGUI.xml' OK")


            With Swan2VFSmodGUI.Paths

                'paths
                log("inpFilePath               : " & Path.GetFullPath(.inpFilePath))
                log("p2tFilePath               : " & Path.GetFullPath(.p2tFilePath))
                log("ztsFilePath               : " & Path.GetFullPath(.ztsFilePath))
                log("ScenarioUserInputFilePath : " & Path.GetFullPath(.ScenarioUserInputFilePath))
                log("VFSmodGUI2SwanPath        : " & Path.GetFullPath(.VFSmodGUI2SwanPath))

                Console.WriteLine("")
                Console.WriteLine("  *** Paths ***")
                Console.WriteLine("PRZM out path : " & Path.GetFullPath(Path.GetDirectoryName(.inpFilePath)))
                Console.WriteLine(" inp file     : " & Path.GetFileName(.inpFilePath))
                Console.WriteLine(" p2t file     : " & Path.GetFileName(.p2tFilePath))
                Console.WriteLine(" zts file     : " & Path.GetFileName(.ztsFilePath))
                Console.WriteLine("Working Dir   : " & Path.GetFullPath(.VFSmodGUI2SwanPath))
                Console.WriteLine("Scenario file : " & Path.GetFullPath(.ScenarioUserInputFilePath))

            End With

            With Swan2VFSmodGUI.GeneralInfo

                'general info
                log("BufferStripLen            : " & .BufferStripLen)
                log("ParMet                    : " & .ParMet.ToString)
                log("FOCUSScenario             : " & .FOCUSScenario.ToString)
                log("FOCUSWaterBody            : " & .FOCUSWaterBody.ToString)

                Console.WriteLine("")
                Console.WriteLine("  *** Parameter  *** ")
                Console.WriteLine("Buffer strip length (m)  : " & .BufferStripLen)
                Console.WriteLine("Parent or metabolite run : " & .ParMet.ToString)
                Console.WriteLine("FOCUS Scenario           : " & .FOCUSScenario.ToString)


            End With


        Catch ex As Exception

            log("Can't De-Serialize Swan2VFSmodGUIFile.xml" & vbCrLf &
                               Swan2VFSmodGUIXMLFilePath & vbCrLf &
                                ex.Message & vbCrLf & EOP)

        End Try

    End Sub

    Public Sub deserializeScenarioUserInputXML(Optional ScenarioUserInputFilePath As String = "")

        If ScenarioUserInputFilePath = "" Then
            ScenarioUserInputFilePath = Me.Swan2VFSmodGUI.Paths.ScenarioUserInputFilePath
        End If

        Try
            log("De-Serialize 'RXScenarioUserInput.xml' from " & ScenarioUserInputFilePath)
            ScenarioUserInput = CType(LoadXML2Class(ClassType:=GetType(ScenarioUserInput),
                                                  XMLFileName:=ScenarioUserInputFilePath), 
                                   ScenarioUserInput)
            log("De-Serialize 'RXScenarioUserInput.xml' OK")

        Catch ex As Exception

            log("Can't De-Serialize RXScenarioUserInput.xml" & vbCrLf &
                               ScenarioUserInputFilePath & vbCrLf &
                                ex.Message & vbCrLf & EOP)

        End Try

    End Sub

    Public Sub getCompoundDataFromINPFile(Optional inpFilePath As String = "")

        If inpFilePath = "" Then
            inpFilePath = Swan2VFSmodGUI.Paths.inpFilePath
        End If

        Me.ScenarioUserInput.CompoundProperties.getCompoundProperties(
            INPFileName:=inpFilePath,
                 ParMet:=Swan2VFSmodGUI.GeneralInfo.ParMet)

    End Sub

    Public Sub getPRZMOUTData(Optional p2tFilePath As String = "",
                              Optional ztsFilePath As String = "")

        Try
            If p2tFilePath = "" Then p2tFilePath = Path.GetFullPath(Swan2VFSmodGUI.Paths.p2tFilePath)
            If ztsFilePath = "" Then ztsFilePath = Path.GetFullPath(Swan2VFSmodGUI.Paths.ztsFilePath)
        Catch ex As Exception

            log("Error in p2t/zts filepath " & vbCrLf &
                ex.Message & vbCrLf &
                "p2t filepath : " & p2tFilePath & vbCrLf &
                "zts filepath : " & ztsFilePath & vbCrLf &
                EOP)

        End Try

        'get
        Try
            If File.Exists(p2tFilePath) AndAlso
               File.Exists(ztsFilePath) Then

                Me.PRZMOutData = New PRZMOutData(P2TFileName:=p2tFilePath,
                                                 ZTSFileName:=ztsFilePath,
                                               FOCUSScenario:=Me.Swan2VFSmodGUI.GeneralInfo.FOCUSScenario,
                                                 AreaCorrFac:=Me.ScenarioUserInput.StdValues.AreaCorrFac)


            End If
        Catch ex As Exception
            log("Error creating PRZMOutData from p2t/zts data" & vbCrLf &
                ex.Message & vbCrLf &
                "p2t filepath : " & p2tFilePath & vbCrLf &
                "zts filepath : " & ztsFilePath & vbCrLf &
                EOP)
        End Try


    End Sub

    Public Function generateVFSmodInputFiles() As List(Of VFSmodInputFilesSet)

        Me.ScenarioUserInput.StdValues.VL = Me.Swan2VFSmodGUI.GeneralInfo.BufferStripLen

        Try
            log("Generate VFSmod files")
            Me.VFSmodInputFileSets.Clear()

            For Each P2TEvent As P2TEvent In Me.PRZMOutData.P2TEventList


                'skip warmup years
                If P2TEvent.EventDate.Year < 1975 Then Continue For
                Me.VFSmodInputFileSets.Add(New VFSmodInputFilesSet(P2TEvent,
                                                                   Me.ScenarioUserInput))
            Next
            log("Generate VFSmod files OK (" & Me.VFSmodInputFileSets.Count & " Entries)")
        Catch ex As Exception
            log("Can't Generate VFSmod files" & vbCrLf &
                     ex.Message & vbCrLf & EOP)

        End Try

        Return Me.VFSmodInputFileSets

    End Function

#End Region

    <XmlIgnore()>
    Public Shared KillProcess As Boolean = False

    <XmlIgnore()>
    Public Minutes2KillProcess As Integer = 30

    <XmlIgnore()>
    Public myProcess As New Process

    Public dgPinLog As New List(Of String)

    Public Sub runVFSmod(Optional ZeroBuffer As Boolean = False,
                         Optional Delay As Integer = 500)

        Dim RunCounter As Integer = 0
        Dim CursorRow As Integer = 0
        Dim CursorPos As Integer = 0

        dgPinLog.Clear()

        'processinfo
        Dim myStartInfo As New ProcessStartInfo

        Dim RunTime As New TimeSpan
        Dim ConsoleRunInfo As String = ""
        Dim WaitCounter As Integer = 0


        'zip
        Dim my7zipStartInfo As New ProcessStartInfo
        Dim ZipAvaliable As Boolean = False
        Dim ZipPath As String = ""
        Dim TempFiles As String() = {}
        Dim yearZip As Boolean = False


        Dim CSVList As New List(Of String)
        Dim Sep As String = ","

        Dim ParMetEnding As String

        If Swan2VFSmodGUI.GeneralInfo.ParMet = eParMet.Parent Then
            ParMetEnding = "Par"
        Else
            ParMetEnding = "Met"
        End If

        CSVList.Add("EventDate (YYYYMMDD)" & Sep &
                    "Runoff inflow reduction frv (frac)" & Sep &
                    "Pesticide Reduction dP frf/fef (frac)" & Sep &
                    "Sediment Reduction dE fem (frac)" & Sep &
                    "EventDuration (h)" & Sep &
                    "Days2NextEvent (d)" & Sep &
                    "P2TRow" & Sep &
                    "RunOffVolume (mm/h)" & Sep &
                    "RunOffFlux (mg as/m2/h)" & Sep &
                    "ErosionMass (kg/h)" & Sep &
                    "ErosionFlux (mg as/m2/h)" & Sep &
                    "Precipitation (mm)" & Sep &
                    "Infiltration dQ (frac)" & Sep &
                    "ResidualMass (mg/m2)" & Sep &
                    "RunoffInflow (m3)" & Sep &
                    "SedimentInflow (Kg)" & Sep &
                    "PhaseDistribution Fph (-)" & Sep &
                    "hMax (m)" & Sep &
                    "TXW water depth (m)" & Sep &
                    "WTD (m)")

        Try

            File.AppendAllLines(path:=Path.Combine(Me.Swan2VFSmodGUI.Paths.VFSmodGUI2SwanPath,
                                            "VFSmod" & ParMetEnding & ".csv"),
                                contents:={CSVList.Last})

        Catch ex As Exception
            log(ex.Message)
        End Try


        log("Start VFSmod runs")


        dgPinLog.Add("Event x   : IWQ file : PRZM field output(Event x) + Residual mass(x-1) = dPin (mg/m) form owq file")
        dgPinLog.Add("Event x   : OWQ file, (1-dP)dPin = mo  = Residual mass(Event x)")
        dgPinLog.Add("Event x+1 : IWQ file : PRZM field output(Event x+1) + Residual mass(Event x) = dPin (mg/m) form owq file")
        dgPinLog.Add("Event x+1 : OWQ file, (1-dP)dPin = mo  =Residual mass(Event x)")
        dgPinLog.Add("")


        'test zip avaliable
        If File.Exists("C:\Program Files\7-Zip\7z.dll") AndAlso
           File.Exists("C:\Program Files\7-Zip\7z.exe") Then

            ZipAvaliable = True
            ZipPath = "C:\Program Files\7-Zip\7z.exe"
            log("7-zip avail. at 'C:\Program Files\7-Zip\7z.exe'")

        ElseIf File.Exists(Path.Combine(ExecPath, "7z.dll")) AndAlso
               File.Exists(Path.Combine(ExecPath, "7z.exe")) Then

            ZipAvaliable = True
            ZipPath = Path.GetFullPath(Path.Combine(ExecPath, "7z.exe"))
            log("7-zip avail. at '" & ZipPath & "'")

        Else
            ZipAvaliable = False
        End If

        'check files and paths
        With Swan2VFSmodGUI.Paths

            If .VFSmodGUI2SwanPath = "" Then

                Try

                    .VFSmodGUI2SwanPath = Path.Combine(ExecPath, "Output")
                    Directory.CreateDirectory(.VFSmodGUI2SwanPath)

                Catch ex As Exception

                    log("Can't create working directory " & vbCrLf &
                       .VFSmodGUI2SwanPath & vbCrLf &
                       ex.Message & vbCrLf &
                       EOP)

                End Try

            Else

                'check VFSmodGUI2SwanPath
                Try
                    .VFSmodGUI2SwanPath = Path.GetFullPath(.VFSmodGUI2SwanPath)
                Catch ex As Exception

                    log("Can't find/create working directory " & vbCrLf &
                    .VFSmodGUI2SwanPath & vbCrLf & ex.Message & vbCrLf & EOP)

                End Try

            End If

        End With


        'copy vfsm.exe to workingdir : new for pathnames with spaces
        Try

            File.Copy(sourceFileName:=Path.Combine(ExecPath, vfsmFileName),
                        destFileName:=Path.Combine(Swan2VFSmodGUI.Paths.VFSmodGUI2SwanPath, vfsmFileName),
                           overwrite:=True)

            log("Copy " & vfsmFileName & vbCrLf &
                " from :" & Path.Combine(ExecPath, vfsmFileName) & vbCrLf &
                " to   :" & Path.Combine(Swan2VFSmodGUI.Paths.VFSmodGUI2SwanPath, vfsmFileName) & vbCrLf &
                " OK")

        Catch ex As Exception
            log("Can't copy " & vfsmFileName & vbCrLf & ex.Message & vbCrLf & EOP)
        End Try


        With myStartInfo

            .WorkingDirectory = Swan2VFSmodGUI.Paths.VFSmodGUI2SwanPath
            If Not Directory.Exists(.WorkingDirectory) Then
                log("Can't find Working Directory " & vbCrLf & .WorkingDirectory & vbCrLf & EOP)
            Else
                log("Working Directory :  " & .WorkingDirectory)
            End If

            'new for pathnames with spaces
            .Arguments = "VFSmod.prj"
            .FileName = vfsmFileName

            If Not File.Exists(.FileName) Then
                log("Can't find VFSmod executable " & vbCrLf & .FileName & vfsmFileName & vbCrLf & EOP)
            End If

            'no vfsm.exe window on the screen
            If Environment.UserName.ToUpper = "PFMEY" Then
                .WindowStyle = ProcessWindowStyle.Normal
                .CreateNoWindow = True
            Else
                .WindowStyle = ProcessWindowStyle.Normal
                .CreateNoWindow = True
            End If

            .UseShellExecute = False

        End With

        If VFSmodInputFileSets.Count > 200 Then yearZip = True

        For Each VFSmodRun As VFSmodInputFilesSet In VFSmodInputFileSets

            '*******************  test  ****************************
            'If RunCounter < VFSmodInputFileSets.Count - 2 AndAlso RunCounter > 2 Then
            'RunCounter += 1
            'Me.VFSmodGUI2Swan.VFSmodResults.Add(New VFSmodResult)
            'Continue For
            'End If
            '*******************  test  ****************************

            'create runinfo string for console
            With PRZMOutData.P2TEventList(RunCounter)

                ConsoleRunInfo = Format(Now, "hh:mm:ss ") &
                                 Format(RunCounter + 1, "000") & " P2TRow = " & Format(.P2TRow, "0000") & " " &
                                 Format(.EventDate, "dd.MMM.yy ") &
                        "ROVol = " & Format(.EventDuration, "00") & "h * " & Format(.RunOffVolume, "0.000") & "mm || "
                Try

                    CursorRow = Console.CursorTop
                    Console.WriteLine("-------------------------------------------------------")
                    Console.WriteLine(" *** Runoff event info *** ")
                    Console.WriteLine("Run " & RunCounter + 1 & " of " & PRZMOutData.P2TEventList.Count)
                    Console.WriteLine("Event Data")
                    Console.WriteLine(" Date           : " & Format(.EventDate, "dd.MMM.yy"))
                    Console.WriteLine(" Duration       : " & .EventDuration & " h  ")
                    Console.WriteLine(" Precipitation  : " & .Precipitation & " mm    ")
                    Console.WriteLine(" Runoff ")
                    Console.WriteLine("  - Volume      : " & Format(.RunOffVolume, "0.000E+00") & " mm/h  ")
                    Console.WriteLine("  - Flux        : " & Format(.RunOffFlux, "0.000E+00") & " mg as/m2/h  ")
                    Console.WriteLine(" Erosion ")
                    Console.WriteLine(" -  Mass        : " & Format(.ErosionMass, "0.000E+00") & " kg/h  ")
                    Console.WriteLine("  - Flux        : " & Format(.ErosionFlux, "0.000E+00") & " mg as/m2/h   ")
                    Console.WriteLine("-------------------------------------------------------")
                    Console.WriteLine(" *** Process info *** ")

                Catch ex As Exception

                End Try


                'prepare vfsmod input files
                VFSmodInputFilesSet.clearOutputPath(myStartInfo.WorkingDirectory)


                VFSmodInputFileSets(RunCounter).IWQ.dgPinDescription.Add("-------------------------------------------------------")
                VFSmodInputFileSets(RunCounter).IWQ.dgPinDescription.Add(" *** Runoff event info *** ")
                VFSmodInputFileSets(RunCounter).IWQ.dgPinDescription.Add("Run " & RunCounter + 1 & " of " & PRZMOutData.P2TEventList.Count)
                VFSmodInputFileSets(RunCounter).IWQ.dgPinDescription.Add("Event Data")
                VFSmodInputFileSets(RunCounter).IWQ.dgPinDescription.Add(" Date           : " & Format(.EventDate, "dd.MMM.yy"))
                VFSmodInputFileSets(RunCounter).IWQ.dgPinDescription.Add(" P2T row        : " & .P2TRow)
                VFSmodInputFileSets(RunCounter).IWQ.dgPinDescription.Add(" Duration       : " & .EventDuration & " h  ")
                VFSmodInputFileSets(RunCounter).IWQ.dgPinDescription.Add(" Precipitation  : " & .Precipitation & " mm    ")
                VFSmodInputFileSets(RunCounter).IWQ.dgPinDescription.Add(" Runoff ")
                VFSmodInputFileSets(RunCounter).IWQ.dgPinDescription.Add("  - Volume      : " & Format(.RunOffVolume, "0.000E+00") & " mm/h  ")
                VFSmodInputFileSets(RunCounter).IWQ.dgPinDescription.Add("  - Flux        : " & Format(.RunOffFlux, "0.000E+00") & " mg as/m2/h  ")
                VFSmodInputFileSets(RunCounter).IWQ.dgPinDescription.Add(" Erosion ")
                VFSmodInputFileSets(RunCounter).IWQ.dgPinDescription.Add(" -  Mass        : " & Format(.ErosionMass, "0.000E+00") & " kg/h  ")
                VFSmodInputFileSets(RunCounter).IWQ.dgPinDescription.Add("  - Flux        : " & Format(.ErosionFlux, "0.000E+00") & " mg as/m2/h   ")
                VFSmodInputFileSets(RunCounter).IWQ.dgPinDescription.Add(" Tot. Mass      : " & Format(.EventDuration *
                                                                                                       (.ErosionFlux +
                                                                                                        .RunOffFlux), "0.000E+00") & " mg as/m2   ")
                VFSmodInputFileSets(RunCounter).IWQ.dgPinDescription.Add("-------------------------------------------------------")



                log("-------------------------------------------------------")
                log(" *** Runoff event info *** ")
                log("Run " & RunCounter + 1 & " of " & PRZMOutData.P2TEventList.Count)
                log("Event Data")
                log(" Date           : " & Format(.EventDate, "dd.MMM.yy"))
                log(" P2T row        : " & .P2TRow)
                log(" Duration       : " & .EventDuration & " h  ")
                log(" Precipitation  : " & .Precipitation & " mm    ")
                log(" Runoff ")
                log("  - Volume      : " & Format(.RunOffVolume, "0.000E+00") & " mm/h  ")
                log("  - Flux        : " & Format(.RunOffFlux, "0.000E+00") & " mg as/m2/h  ")
                log(" Erosion ")
                log(" -  Mass        : " & Format(.ErosionMass, "0.000E+00") & " kg/h  ")
                log("  - Flux        : " & Format(.ErosionFlux, "0.000E+00") & " mg as/m2/h   ")
                log(" Tot. Mass      : " & Format(.EventDuration *
                                                 (.ErosionFlux +
                                                 .RunOffFlux), "0.000E+00") & " mg as/m2   ")
                log("-------------------------------------------------------")

            End With

            If RunCounter = 0 Then

                'first event, write
                With VFSmodInputFileSets(RunCounter).IWQ


                    .dgPin = (PRZMOutData.P2TEventList(RunCounter).RunOffFlux + PRZMOutData.P2TEventList(RunCounter).ErosionFlux) *
                                                     PRZMOutData.P2TEventList(RunCounter).EventDuration

                    .dgPinDescription.Add("")
                    .dgPinDescription.Add(" First event, no residue mass from prev. event")
                    .dgPinDescription.Add(" dgPin(iwq) =  (Act. RunOffFlux + Act. ErosionFlux)")
                    .dgPinDescription.Add("                   * Event Duration")


                    .dgPinDescription.Add(" dgPin(iwq) =  (" &
                        (PRZMOutData.P2TEventList(RunCounter).RunOffFlux & " mg/m2/h").ToString.PadRight(
                            "Act. RunOffFlux".Length) & " + " &
                        (PRZMOutData.P2TEventList(RunCounter).ErosionFlux & " mg/m2/h)").ToString.PadRight(
                            "Act. RunOffFlux".Length))
                    .dgPinDescription.Add("                   * " &
                        PRZMOutData.P2TEventList(RunCounter).EventDuration.ToString & "h")
                    .dgPinDescription.Add(" dgPin(iwq) for event at " & PRZMOutData.P2TEventList(RunCounter).EventDate.ToShortDateString & " : " &
                                                                   .dgPin & " mg as/m2")

                    .dgPinDescription.Add(" write dgPin(iwq) to file " & Format(PRZMOutData.P2TEventList(RunCounter).EventDate, "yyMMdd") & ".iwq")
                    dgPinLog.AddRange(.dgPinDescription)

                End With

            End If

            'write all VFSmod input files to working directory
            VFSmodRun.writeAllFiles(myStartInfo.WorkingDirectory)

            Threading.Thread.Sleep(100)

            Try

                With myProcess

                    'run vfsm.exe VFSmod.prj
                    .StartInfo = myStartInfo

                    With .StartInfo

                        dgPinLog.Add(" Start vfsm.exe for event no " &
                                     RunCounter + 1 &
                                     "(" & PRZMOutData.P2TEventList(RunCounter).EventDate & ")")

                    End With

                    .Start()

                    Try
                        Console.WriteLine("  - ID          : " & .Id)
                        Console.Write("  - Runtime     : ")
                        CursorPos = Console.CursorLeft
                    Catch ex As Exception

                    End Try

                    Do Until .HasExited

                        Try
                            Console.Write(.UserProcessorTime.ToString)
                            Console.CursorLeft = CursorPos
                        Catch ex As Exception

                        End Try


                        'kill process if time (5min) is exceeded
                        If .UserProcessorTime.Minutes > Minutes2KillProcess OrElse KillProcess Then

                            log("VFSmod runtime > " & Minutes2KillProcess & "min, process is killed now")

                            Try
                                'kill process
                                myProcess.Kill()
                                'wait a bit
                                Threading.Thread.Sleep(Delay)
                                log("Process " & myProcess.Id & " killed OK" & vbCrLf & EOP)

                            Catch ex As Exception
                                log("Error killing Process " & myProcess.Id & vbCrLf & ex.Message & vbCrLf & EOP)
                            End Try

                        End If

                    Loop

                End With

            Catch ex As Exception
                log("Error running " & vfsmFileName & "  ID:" & myProcess.Id & vbCrLf & EOP)
            End Try


            'get process info
            'idiotenwarteschleife
            If ZeroBuffer Then

                If Environment.UserName.ToUpper <> "PFMEY" Then

                    WaitCounter = RunTime.Minutes + 5
                    Do While RunTime.Minutes < WaitCounter

                        Console.Write(RunTime.ToString)
                        Console.CursorLeft = CursorPos

                        RunTime = RunTime.Add(New TimeSpan(0, 0, 1))

                        Threading.Thread.Sleep(1000)

                    Loop

                Else

                    WaitCounter = RunTime.Seconds + 1
                    Do While RunTime.Seconds < WaitCounter

                        Console.Write(RunTime.ToString)
                        Console.CursorLeft = CursorPos

                        RunTime = RunTime.Add(New TimeSpan(0, 0, 1))

                        Threading.Thread.Sleep(100)

                    Loop

                End If

            End If

            'write runtime to screen
            RunTime = New TimeSpan(RunTime.Ticks + myProcess.TotalProcessorTime.Ticks)

            Try
                Console.WriteLine("")
                Console.WriteLine("  - Tot. Runtime: " & Format(RunTime.Hours, "00") & ":" &
                                                         Format(RunTime.Minutes, "00") & ":" &
                                                         Format(RunTime.Seconds, "00"))
            Catch ex As Exception

            End Try


            Threading.Thread.Sleep(100)

            'get results from owq file
            With Me.VFSmodGUI2Swan

                If ZeroBuffer Then
                    ''vollidioten unter uns
                    '.VFSmodResults.Add(New VFSmodResult)

                    'With .VFSmodResults.Last

                    '    .EventDate = PRZMOutData.P2TEventList(RunCounter).EventDate
                    '    .PesticideReduction = 0
                    '    .SedimentReduction = 0
                    '    .RunoffInflowReduction = 0
                    '    .SedimentInflow = 0
                    '    .RunoffInflow = 0
                    '    .ResidualMass = 0
                    '    .PhaseDistribution = 0

                    'End With

                    Me.VFSmodGUI2Swan.ErrorStdValue = 0

                End If

                .VFSmodResults.Add(.getVFSmodOWQResult(OWQFileName:=Path.Combine(myStartInfo.WorkingDirectory,
                                                                                "VFSmod.owq"),
                                                         EventDate:=VFSmodRun.IKW.EventDate))

                log("Infiltration        (dQ): " & .VFSmodResults.Last.Infiltration.ToString)
                log("Pesticide Reduction (dP): " & .VFSmodResults.Last.PesticideReduction.ToString)
                log("Runoff Inflow Reduction : " & .VFSmodResults.Last.RunoffInflowReduction.ToString)
                log("Sediment Reduction  (dE): " & .VFSmodResults.Last.SedimentReduction.ToString)

            End With

            PRZMOutData.P2TEventList(RunCounter).VFSmodResult = Me.VFSmodGUI2Swan.VFSmodResults.Last

            If RunCounter < VFSmodInputFileSets.Count - 1 Then

                'next event iwq file
                With VFSmodInputFileSets(RunCounter + 1).IWQ

                    .dgPinDescription.Clear()

                    With PRZMOutData.P2TEventList(RunCounter + 1)

                        VFSmodInputFileSets(RunCounter + 1).IWQ.dgPinDescription.Add("-------------------------------------------------------")
                        VFSmodInputFileSets(RunCounter + 1).IWQ.dgPinDescription.Add(" *** Runoff event info *** ")
                        VFSmodInputFileSets(RunCounter + 1).IWQ.dgPinDescription.Add("Run " & RunCounter + 2 & " of " & PRZMOutData.P2TEventList.Count)
                        VFSmodInputFileSets(RunCounter + 1).IWQ.dgPinDescription.Add("Event Data")
                        VFSmodInputFileSets(RunCounter + 1).IWQ.dgPinDescription.Add(" Date           : " & Format(.EventDate, "dd.MMM.yy"))
                        VFSmodInputFileSets(RunCounter + 1).IWQ.dgPinDescription.Add(" P2T row        : " & .P2TRow)
                        VFSmodInputFileSets(RunCounter + 1).IWQ.dgPinDescription.Add(" Duration       : " & .EventDuration & " h  ")
                        VFSmodInputFileSets(RunCounter + 1).IWQ.dgPinDescription.Add(" Precipitation  : " & .Precipitation & " mm    ")
                        VFSmodInputFileSets(RunCounter + 1).IWQ.dgPinDescription.Add(" Runoff ")
                        VFSmodInputFileSets(RunCounter + 1).IWQ.dgPinDescription.Add("  - Volume      : " & Format(.RunOffVolume, "0.000E+00") & " mm/h  ")
                        VFSmodInputFileSets(RunCounter + 1).IWQ.dgPinDescription.Add("  - Flux        : " & Format(.RunOffFlux, "0.000E+00") & " mg as/m2/h  ")
                        VFSmodInputFileSets(RunCounter + 1).IWQ.dgPinDescription.Add(" Erosion ")
                        VFSmodInputFileSets(RunCounter + 1).IWQ.dgPinDescription.Add(" -  Mass        : " & Format(.ErosionMass, "0.000E+00") & " kg/h  ")
                        VFSmodInputFileSets(RunCounter + 1).IWQ.dgPinDescription.Add("  - Flux        : " & Format(.ErosionFlux, "0.000E+00") & " mg as/m2/h   ")
                        VFSmodInputFileSets(RunCounter + 1).IWQ.dgPinDescription.Add(" Tot. Mass      : " & Format(.EventDuration *
                                                                                                               (.ErosionFlux +
                                                                                                                .RunOffFlux), "0.000E+00") & " mg as/m2   ")
                        VFSmodInputFileSets(RunCounter).IWQ.dgPinDescription.Add("-------------------------------------------------------")

                    End With

                    'ToDo iwq fluxes for next event

                    'Event x   : IWQ file : PRZM field output(Event x) + Residual mass(x-1) = dPin (mg/m) form owq file
                    'Event x   : OWQ file, (1-dP)dPin = mo  = Residual mass(Event x)
                    'Event x+1 : IWQ file : PRZM field output(Event x+1) + Residual mass(Event x) = dPin (mg/m) form owq file
                    'Event x+1 : OWQ file, (1-dP)dPin = mo  =Residual mass(Event x)


                    .dgPinDescription.Add("")
                    'Try
                    '    .dgPinDescription.Add("Next Event at   : " & PRZMOutData.P2TEventList(RunCounter + 2).EventDate.ToShortDateString)
                    'Catch ex As Exception

                    'End Try

                    .dgPinDescription.Add(" Pest. residue  : " & PRZMOutData.P2TEventList(RunCounter).VFSmodResult.ResidualMass & " mg/m2 from file " &
                                                                 Format(PRZMOutData.P2TEventList(RunCounter).EventDate, "yyMMdd") &
                                                                 ".owq (Run " & RunCounter + 1 & ")")


                    'dgPin = Prev. Event Residual mass +  (Act. RunOffFlux + Act. ErosionFlux) * Event Duration
                    .dgPin = Me.VFSmodGUI2Swan.VFSmodResults(RunCounter).ResidualMass +
                            ((PRZMOutData.P2TEventList(RunCounter + 1).RunOffFlux + PRZMOutData.P2TEventList(RunCounter + 1).ErosionFlux) *
                             PRZMOutData.P2TEventList(RunCounter + 1).EventDuration)

                    .dgPinDescription.Add("dgPin (iwq) =       Prev. Event Residual mass (from *.owq) + ")
                    .dgPinDescription.Add("              (Act. RunOffFlux + Act. ErosionFlux)")
                    .dgPinDescription.Add("                   * Event Duration")

                    .dgPinDescription.Add("dgPin (iwq) =       " &
                        (Me.VFSmodGUI2Swan.VFSmodResults(RunCounter).ResidualMass & " mg/m2").ToString.PadRight("Prev. Event Residual mass + ".Length))

                    .dgPinDescription.Add("              (" &
                        (PRZMOutData.P2TEventList(RunCounter + 1).RunOffFlux & " mg/m2/h").ToString.PadRight(
                            "Act. RunOffFlux".Length) & " + " &
                        (PRZMOutData.P2TEventList(RunCounter + 1).ErosionFlux & " mg/m2/h").ToString.PadRight(
                            "Act. RunOffFlux".Length))
                    .dgPinDescription.Add("                   * " &
                        PRZMOutData.P2TEventList(RunCounter + 1).EventDuration.ToString & "h")

                    .dgPinDescription.Add(" dgPin(iwq) for event at " & PRZMOutData.P2TEventList(RunCounter + 1).EventDate.ToShortDateString & " : " &
                                                               .dgPin & " mg as/m2")

                    .dgPinDescription.Add(" write dgPin(iwq) to file " & Format(PRZMOutData.P2TEventList(RunCounter + 1).EventDate, "yyMMdd") & ".iwq")


                    dgPinLog.AddRange(.dgPinDescription)
                    dgPinLog.Add("*********************************************************")

                End With

            End If

            'ToDo save results 2 xml
            Try

                SaveClass2XML(Class2Save:=PRZMOutData.P2TEventList(RunCounter),
                               ClassType:=GetType(P2TEvent),
                             XMLFileName:=Path.Combine(myStartInfo.WorkingDirectory, "VFSmod.xml"))


                File.WriteAllLines(Path.Combine(myStartInfo.WorkingDirectory, "dgPin.log"), dgPinLog.ToArray)

                With PRZMOutData.P2TEventList(RunCounter)

                    CSVList.Add(Format(.EventDate, "yyyyMMdd") & Sep &
                                .VFSmodResult.RunoffInflowReduction & Sep &
                                .VFSmodResult.PesticideReduction & Sep &
                                .VFSmodResult.SedimentReduction & Sep &
                                .EventDuration & Sep &
                                .Days2NextEvent & Sep &
                                .P2TRow & Sep &
                                .RunOffVolume & Sep &
                                .RunOffFlux & Sep &
                                .ErosionMass & Sep &
                                .ErosionFlux & Sep &
                                .Precipitation & Sep &
                                .VFSmodResult.Infiltration & Sep &
                                .VFSmodResult.ResidualMass & Sep &
                                .VFSmodResult.RunoffInflow & Sep &
                                .VFSmodResult.SedimentInflow & Sep &
                                .VFSmodResult.PhaseDistribution)

                    'CSVList.Add("EventDate (YYYYMMDD)" & Sep &
                    '"Runoff inflow reduction, frv (frac)" & Sep &
                    '"Pesticide Reduction dP, frf/fef (frac)" & Sep &
                    '"Sediment Reduction dE, fem (frac)" & Sep &
                    '"EventDuration (h)" & Sep &
                    '"Days2NextEvent (d)" & Sep &
                    '"P2TRow" & Sep &
                    '"RunOffVolume (mm/h)" & Sep &
                    '"RunOffFlux (mg as/m2/h)" & Sep &
                    '"ErosionMass (kg/h)" & Sep &
                    '"ErosionFlux (mg as/m2/h)" & Sep &
                    '"Precipitation (mm)" & Sep &
                    '"Infiltration dQ (frac)" & Sep &
                    '"ResidualMass (mg/m2)" & Sep &
                    '"RunoffInflow (m3)" & Sep &
                    '"SedimentInflow (Kg)" & Sep &
                    '"PhaseDistribution Fph (-)" & Sep &
                    '"hMax (m)" & Sep &
                    '"TXW water depth (m)" & Sep &
                    '"WTD (m)")

                End With

                With Me.VFSmodInputFileSets(RunCounter).ISO
                    CSVList(CSVList.Count - 1) &= Sep &
                        .hmax & Sep &
                        .TWD & Sep &
                        (.hmax + .d - .TWD)
                End With

                Try

                    File.AppendAllLines(path:=Path.Combine(Me.Swan2VFSmodGUI.Paths.VFSmodGUI2SwanPath,
                                            "VFSmod" & ParMetEnding & ".csv"),
                                contents:={CSVList.Last})

                Catch ex As Exception
                    log(ex.Message)
                End Try


            Catch ex1 As Exception

                Try

                    Threading.Thread.Sleep(500)
                    log("Write VFSmod P2TEvent xml file" & vbCrLf &
                        myStartInfo.WorkingDirectory & ".xml" & " at 2nd try!")
                    log(ex1.Message)

                    SaveClass2XML(Class2Save:=PRZMOutData.P2TEventList(RunCounter),
                                   ClassType:=GetType(P2TEvent),
                                 XMLFileName:=myStartInfo.WorkingDirectory & ".xml")

                Catch ex2 As Exception

                    log("Can't write VFSmod P2TEvent xml file" & vbCrLf &
                        myStartInfo.WorkingDirectory & ".xml" & vbCrLf &
                        ex2.Message & vbCrLf &
                        EOP)

                End Try

            End Try

            'zip or not
            If FullFeat AndAlso ZipAvaliable Then

                Dim myProcess As New Process

                With myProcess

                    With .StartInfo

                        .FileName = ZipPath
                        .CreateNoWindow = True
                        .WindowStyle = ProcessWindowStyle.Hidden
                        .WorkingDirectory = myStartInfo.WorkingDirectory

                    End With

                    Try
                        File.Delete(path:=myStartInfo.WorkingDirectory & "\" & VFSmodRun.IKW.TITLE & ".zip ")
                    Catch ex As Exception

                    End Try


                    Try

                        .StartInfo.Arguments = "a " & Chr(34) & myStartInfo.WorkingDirectory & "\" & VFSmodRun.IKW.TITLE & Chr(34) & ".zip " &
                                                       Chr(34) & myStartInfo.WorkingDirectory & "\VFSmod.i*" & Chr(34)
                        .Start()
                        .WaitForExit()
                        Threading.Thread.Sleep(100)

                        .StartInfo.Arguments = "a " & Chr(34) & myStartInfo.WorkingDirectory & "\" & VFSmodRun.IKW.TITLE & Chr(34) & ".zip " &
                                                       Chr(34) & myStartInfo.WorkingDirectory & "\VFSmod.o*" & Chr(34)
                        .Start()
                        .WaitForExit()
                        Threading.Thread.Sleep(100)

                        .StartInfo.Arguments = "a " & Chr(34) & myStartInfo.WorkingDirectory & "\" & VFSmodRun.IKW.TITLE & Chr(34) & ".zip " &
                                                       Chr(34) & myStartInfo.WorkingDirectory & "\VFSmod.prj" & Chr(34)
                        .Start()
                        .WaitForExit()
                        Threading.Thread.Sleep(100)

                        .StartInfo.Arguments = "a " & Chr(34) & myStartInfo.WorkingDirectory & "\" & VFSmodRun.IKW.TITLE & Chr(34) & ".zip " &
                                                       Chr(34) & myStartInfo.WorkingDirectory & "\VFSmod.xml" & Chr(34)
                        .Start()
                        .WaitForExit()
                        Threading.Thread.Sleep(100)

                    Catch ex As Exception
                        log("Error Zip " & VFSmodRun.IKW.TITLE & ".zip")
                    End Try

                End With

                Dim yearzipname As String = ""

                If RunCounter < VFSmodInputFileSets.Count Then


                    With myProcess.StartInfo

                        .FileName = ZipPath
                        .CreateNoWindow = True
                        .WindowStyle = ProcessWindowStyle.Hidden
                        .WorkingDirectory = myStartInfo.WorkingDirectory


                        yearzipname = Chr(34) & myStartInfo.WorkingDirectory & "\" & VFSmodRun.IKW.TITLE.Substring(0, 2) & Chr(34) & ".zip "

                        .Arguments = "a " & yearzipname &
                                     Chr(34) & myStartInfo.WorkingDirectory & "\" & VFSmodRun.IKW.TITLE & ".zip" & Chr(34)


                    End With

                    With myProcess
                        .Start()
                        .WaitForExit()
                    End With

                    Threading.Thread.Sleep(500)

                    File.Delete(path:=Path.Combine(path1:=myStartInfo.WorkingDirectory, path2:=VFSmodRun.IKW.TITLE & ".zip"))

                End If

            End If



            'clean up!
            VFSmodInputFilesSet.clearOutputPath(myStartInfo.WorkingDirectory)
            RunCounter += 1
            Try
                Console.CursorTop = CursorRow
            Catch ex As Exception

            End Try


        Next

        ' finaly clean up!
        VFSmodInputFilesSet.clearOutputPath(myStartInfo.WorkingDirectory)

        Try
            File.Delete(path:=Path.Combine(Swan2VFSmodGUI.Paths.VFSmodGUI2SwanPath, vfsmFileName))
        Catch ex As Exception
            log("Can't delete " & vfsmFileName & vbCrLf & ex.Message)
        End Try


        'write resuts to csv



        'For Each member As P2TEvent In Me.PRZMOutData.P2TEventList

        '    With member

        '        CSVList.Add(Format(.EventDate, "yyMMdd") & Sep &
        '                    .EventDuration & Sep &
        '                    .Days2NextEvent & Sep &
        '                    .P2TRow & Sep &
        '                    .RunOffVolume & Sep &
        '                    .RunOffFlux & Sep &
        '                    .ErosionMass & Sep &
        '                    .ErosionFlux & Sep &
        '                    .Precipitation & Sep &
        '                    .VFSmodResult.PesticideReduction & Sep &
        '                    .VFSmodResult.Infiltration & Sep &
        '                    .VFSmodResult.RunoffInflowReduction & Sep &
        '                    .VFSmodResult.SedimentReduction & Sep &
        '                    .VFSmodResult.ResidualMass & Sep &
        '                    .VFSmodResult.RunoffInflow & Sep &
        '                    .VFSmodResult.SedimentInflow & Sep &
        '                    .VFSmodResult.PhaseDistribution)

        '    End With

        '    With VFSmodInputFileSets(RunCounter).ISO
        '        CSVList(CSVList.Count - 1) &= Sep & .hmax & Sep & .TWD & Sep & .d
        '    End With

        '    File.AppendAllLines(path:=Path.Combine(Me.Swan2VFSmodGUI.Paths.VFSmodGUI2SwanPath,
        '                                    "VFSmod.csv"),
        '                        contents:={CSVList.Last})

        'Next

        'Try

        '    File.WriteAllLines(Path.Combine(Me.Swan2VFSmodGUI.Paths.VFSmodGUI2SwanPath,
        '                                    "VFSmod.csv"),
        '                       CSVList.ToArray)

        'Catch ex As Exception

        'End Try

    End Sub

#End Region

#Region "Run TOXSWA"


#Region "fill TOXSWArun class"

    Public Sub fillTOXSWArun()

        getWorkingDirectory()
        getOrigTXWFilepath()

        getMetFilePath()
        getNewP2TFilePath()

        getNewTXWFilePath()
        changeTXWFiles()

    End Sub

    Private Sub getWorkingDirectory()

        Dim Dummy As String() = {}

        If Me.TOXSWArun.WorkingDirectory = "" Then
            Me.TOXSWArun.WorkingDirectory = Me.Swan2VFSmodGUI.Paths.VFSmodGUI2SwanPath
        End If

        If Not Directory.Exists(Me.TOXSWArun.WorkingDirectory) Then

            Try

                Directory.CreateDirectory(Me.TOXSWArun.WorkingDirectory)
                log("TOXSWA working directory created")
                log(Path.GetFullPath(Me.TOXSWArun.WorkingDirectory))

            Catch ex As Exception

                log("Can't create TOXSWA working directory")
                log(Me.TOXSWArun.WorkingDirectory)
                log(EOP)

            End Try


            log("Can't find TOXSWA working directory")
            log(Me.TOXSWArun.WorkingDirectory)
            log(EOP)


        ElseIf Directory.GetFiles(Me.TOXSWArun.WorkingDirectory, "*").Count <> 0 Then

            'If MsgBox("Working Directory " & vbCrLf &
            '          Me.TOXSWArun.WorkingDirectory & vbCrLf &
            '          "not empty, clear directroy ?", vbYesNo) = MsgBoxResult.Yes Then

            '    Try

            '        Dummy = Directory.GetFiles(Me.TOXSWArun.WorkingDirectory, "*")

            '        For Each member As String In Dummy
            '            File.Delete(member)
            '        Next

            '    Catch ex As Exception

            '        log("Can't clear working directory " & vbCrLf &
            '            Me.TOXSWArun.WorkingDirectory & vbCrLf &
            '            ex.Message & vbCrLf &
            '            EOP)

            '    End Try

            '    log("Clear working directory OK")

            'End If

        End If

        log("TOXSWA working directory " & Path.GetFullPath(Me.TOXSWArun.WorkingDirectory))


    End Sub

    Private Sub getOrigTXWFilepath()


        Dim txwPre As String = ""
        Dim txwEnd As String = ""
        Dim txwPath As String = ""

        Dim txwArray As String() = {}

        With Me.Swan2VFSmodGUI.Paths

            'txw filepath defined by user?
            If Me.TOXSWArun.origTXWFilePath <> "" Then

                If Not File.Exists(Me.TOXSWArun.origTXWFilePath) Then
                    log("Can't find orig txw file")
                    log("txw filepath = " & Me.TOXSWArun.origTXWFilePath)
                    log(EOP)

                Else
                    log("user orig. txw filepath = " & Me.TOXSWArun.origTXWFilePath)
                    'Exit Sub
                End If

            Else

                If Not File.Exists(.inpFilePath) OrElse
                   Not File.Exists(.p2tFilePath) Then

                    log("No *.inp  or *.p2t path defined")
                    log("Can't create peth to orig. txw file")
                    log(EOP)

                End If

                'get TOXSWA directory from inp filepath
                'inppath = 'C:\SwashProjects\ProjectName\PRZM\Crop\RX-CC-.INP'
                'txwPath = 'C:\SwashProjects\ProjectName\PRZM\Crop'
                Me.TOXSWArun.origTXWFilePath = Path.GetDirectoryName(.inpFilePath)

                'txwPath = 'C:\SwashProjects\ProjectName\PRZM
                Me.TOXSWArun.origTXWFilePath = Path.GetDirectoryName(Me.TOXSWArun.origTXWFilePath)

                'txwPath = 'C:\SwashProjects\ProjectName\
                Me.TOXSWArun.origTXWFilePath = Path.GetDirectoryName(Me.TOXSWArun.origTXWFilePath)

                Me.TOXSWArun.origTXWFilePath = Path.Combine(Me.TOXSWArun.origTXWFilePath, "TOXSWA")

                If Not Me.TOXSWArun.origTXWFilePath.EndsWith("TOXSWA") OrElse Not Directory.Exists(Me.TOXSWArun.origTXWFilePath) Then

                    log("Can't find txw file path from inp file path")
                    log("inp filepath = " & .inpFilePath)
                    log("txw filepath = " & Me.TOXSWArun.origTXWFilePath)
                    log(EOP)

                End If

                'p2t file name  = '00013-C1.p2t'
                '00013-C2"
                txwPre = Path.GetFileNameWithoutExtension(.p2tFilePath)
                '00013'
                txwPre = txwPre.Substring(0, 5)

                Select Case Me.Swan2VFSmodGUI.GeneralInfo.FOCUSWaterBody

                    Case eRWB.Stream
                        txwEnd = "s_"

                    Case eRWB.Stream
                        txwEnd = "p_"

                End Select

                Select Case Me.Swan2VFSmodGUI.GeneralInfo.ParMet

                    Case eParMet.Parent
                        txwEnd &= "pa.txw"

                    Case eParMet.Metabolite
                        txwEnd &= "m1.txw"

                End Select

                Me.TOXSWArun.origTXWFilePath = Path.Combine(Me.TOXSWArun.origTXWFilePath, ".txw")

                If Not File.Exists(Me.TOXSWArun.origTXWFilePath) Then
                    log("Can't find txw file")
                    log(Me.TOXSWArun.origTXWFilePath)
                    log(EOP)
                Else
                    log("Auto-generated orig. txw file path from p2t & inp filepath")
                    log(Me.TOXSWArun.origTXWFilePath)
                End If

            End If

            With Me.TOXSWArun

                Try

                    If Not File.Exists(Path.Combine(.WorkingDirectory,
                                                    Path.GetFileName(.origTXWFilePath))) Then

                        File.Copy(sourceFileName:=.origTXWFilePath,
                                    destFileName:=Path.Combine(.WorkingDirectory,
                                                               Path.GetFileName(.origTXWFilePath)),
                                       overwrite:=True)

                        log("Copy orig. txw to working dir")
                        log(" Source : " & .origTXWFilePath)
                        log(" Target : " & Path.Combine(.WorkingDirectory,
                                                        Path.GetFileName(.origTXWFilePath)))




                    End If

                Catch ex As Exception

                    log("Can't copy orig. txw to working dir")
                    log(" Source : " & .origTXWFilePath)
                    log(" Target : " & Path.Combine(.WorkingDirectory,
                                                    Path.GetFileName(.origTXWFilePath)))
                    log(ex.Message)
                    log(EOP)

                End Try

            End With

        End With

    End Sub

    Private Sub getMetFilePath()

        With Me.TOXSWArun

            .TOXSWAmetFilePath =
                Path.Combine(
                    path1:=Path.GetDirectoryName(.TOXSWAexeFilePath),
                    path2:=Path.GetFileName(.TOXSWAmetFilePath))

            If .TOXSWAmetFilePath <> "" Then
                If Not File.Exists(.TOXSWAmetFilePath) Then

                    log("Can't find source TOXSWA met file")
                    log(.TOXSWAmetFilePath)

                Else

                    log("user met file: " & Path.GetFullPath(.TOXSWAmetFilePath))

                End If
            End If

            If Not File.Exists(.TOXSWAmetFilePath) Then

                .TOXSWAmetFilePath = TOXSWAmetFiles(Me.Swan2VFSmodGUI.GeneralInfo.FOCUSScenario - 1)
                .TOXSWAmetFilePath = Path.Combine(ExecPath, .TOXSWAmetFilePath)

            End If

            If Not File.Exists(.TOXSWAmetFilePath) Then

                log("Can't find source TOXSWA met file")
                log(.TOXSWAmetFilePath)
                log(EOP)

            Else

                log("Auto generated source TOXSWA met file path")
                log(" Source : " & Path.GetFullPath(.TOXSWAmetFilePath))

                Try

                    If Not File.Exists(Path.Combine(.WorkingDirectory,
                                                    Path.GetFileName(.TOXSWAmetFilePath))) Then

                        File.Copy(sourceFileName:=.TOXSWAmetFilePath,
                                    destFileName:=Path.Combine(.WorkingDirectory,
                                                               Path.GetFileName(.TOXSWAmetFilePath)), overwrite:=True)


                        log("Copy TOXSWA met file")
                        log(" Target : " & Path.Combine(.WorkingDirectory,
                                          Path.GetFileName(.TOXSWAmetFilePath)))

                        .TOXSWAmetFilePath =
                            Path.Combine(.WorkingDirectory,
                                         Path.GetFileName(.TOXSWAmetFilePath))

                        log("Reset TOXSWA met file path to ")
                        log(" Met    : " & Path.GetFullPath(.TOXSWAmetFilePath))

                    Else

                        log("Met file already exists")
                        log(" Met    : " & Path.GetFullPath(.TOXSWAmetFilePath))

                    End If

                Catch ex As Exception

                    log("Can't copy TOXSWA met file")
                    log(" Source : " & .TOXSWAmetFilePath)
                    log(" Target : " & Path.Combine(.WorkingDirectory,
                                      Path.GetFileName(.TOXSWAmetFilePath)))
                    log(ex.Message)
                    log(EOP)

                End Try

            End If

        End With

    End Sub

    Private Sub getNewP2TFilePath()

        With Me.TOXSWArun

            If .NewP2TFilePath = "" Then

                .NewP2TFilePath = Path.GetFileName(Me.Swan2VFSmodGUI.Paths.p2tFilePath)
                .NewP2TFilePath =
                    Path.Combine(.WorkingDirectory, .NewP2TFilePath)

                log("Auto generated new p2tfile path")
                log(.newTXWFilePath)

            End If

            If Not File.Exists(.NewP2TFilePath) Then

                Try

                    File.Copy(sourceFileName:=Me.Swan2VFSmodGUI.Paths.p2tFilePath,
                                destFileName:=Path.Combine(.WorkingDirectory,
                                                           Path.GetFileName(Me.Swan2VFSmodGUI.Paths.p2tFilePath)),
                                   overwrite:=True)

                    log("Copy orig p2t file")
                    log(" Source : " & Me.Swan2VFSmodGUI.Paths.p2tFilePath)
                    log(" Target : " & Path.Combine(.WorkingDirectory,
                                     Path.GetFileName(Me.Swan2VFSmodGUI.Paths.p2tFilePath)))

                Catch ex As Exception

                    log("Can't copy orig p2t file")
                    log(" Source : " & Me.Swan2VFSmodGUI.Paths.p2tFilePath)
                    log(" Target : " & Path.Combine(.WorkingDirectory,
                                     Path.GetFileName(Me.Swan2VFSmodGUI.Paths.p2tFilePath)))
                    log(ex.Message)
                    log(EOP)

                End Try

            Else
                log("p2t file already exists")
                log(" p2t    : " & Path.Combine(.WorkingDirectory,
                                   Path.GetFileName(Me.Swan2VFSmodGUI.Paths.p2tFilePath)))
            End If

        End With

    End Sub

    Private Sub getNewTXWFilePath()

        With Me.TOXSWArun

            If .newTXWFilePath = "" Then

                'swash 4
                .newTXWFilePath =
                      Path.Combine(Me.TOXSWArun.WorkingDirectory, Path.GetFileName(.origTXWFilePath))

            End If

            If Not File.Exists(.newTXWFilePath) Then

                Try

                    File.Copy(sourceFileName:=.origTXWFilePath,
                                destFileName:=.newTXWFilePath,
                                   overwrite:=True)

                    log("Copy new txw file")
                    log(" Source : " & .origTXWFilePath)
                    log(" Target : " & .newTXWFilePath)


                Catch ex As Exception

                    log("Can't new copy txw file")
                    log(" Source : " & .origTXWFilePath)
                    log(" Target : " & .newTXWFilePath)
                    log(ex.Message)
                    log(EOP)

                End Try

            Else
                log("new txw file already exists")
                log(" Txw    : " & .newTXWFilePath)
            End If


        End With

    End Sub

    Private Sub changeTXWFiles()

        Dim origTXWFilePath As String = ""
        Dim p2tFilepath As String = ""

       
        p2tFilepath = Path.Combine(Me.TOXSWArun.WorkingDirectory,
                                   Path.GetFileName(Me.Swan2VFSmodGUI.Paths.p2tFilePath))

        With TOXSWArun

            If Not File.Exists(.origTXWFilePath) Then

                log("Can't change txw settings")
                log("Orig. txw file not found : " & .origTXWFilePath)
                log(EOP)

            ElseIf Not File.Exists(.newTXWFilePath) Then

                log("Can't change txw settings")
                log("New txw file not found : " & .newTXWFilePath)
                log(EOP)

            ElseIf Not File.Exists(p2tFilepath) Then

                log("Can't change txw settings")
                log("Orig. p2t file not found : " & p2tFilepath)
                log(EOP)

            End If

            'change copy of orig. txw file
            'changeTXWfile(.origTXWFilePath, Path.GetFullPath(p2tFilepath))

            'change new txw file
            changeTXWfile(.newTXWFilePath, Path.GetFullPath(Me.TOXSWArun.NewP2TFilePath))

        End With

    End Sub

    Public Function changeTXWfile(Optional txwFilePath As String = "",
                                  Optional p2tFilePath As String = "") As Boolean


        Dim TempPath As String = ""
        Dim LineCounter As Integer = 0
        Dim AppCounter As Integer = 0
        Dim Drift As String = ""
        Dim RowArray As String() = {}
        Dim Temp As String() = {}
        Dim NewTXWFile As New List(Of String)

        If txwFilePath = "" Then txwFilePath = Me.TOXSWArun.newTXWFilePath

        log("Edit txw file")
        log(" TXW    : " & txwFilePath)

        Try
            NewTXWFile.Clear()
            NewTXWFile.AddRange(File.ReadAllLines(txwFilePath))
        Catch ex As Exception

            log("Can't create new txw file")
            log(txwFilePath)
            log(ex.Message)
            log(EOP)

        End Try

        If p2tFilePath = "" Then p2tFilePath = Me.TOXSWArun.NewP2TFilePath

        'Temp = Filter()

        'p2tFilePath = Replace(Expression:=p2tFilePath, Find:="_stream", Replacement:="")


        'swash 4
        'change path 2 p2t
        Do While Not NewTXWFile(LineCounter).Contains("    table Soil Substances")

            LineCounter += 1

            If LineCounter > NewTXWFile.Count - 5 Then

                log("Can't find p2t file path in txw file")
                log(EOP)

            End If

        Loop

        LineCounter += 1

        If p2tFilePath.Contains("-C2") Then LineCounter += 1

        log("Change p2t file path in txw file to " & Path.GetFileName(p2tFilePath))
            NewTXWFile(LineCounter) = Path.GetFileName(p2tFilePath)
            log(NewTXWFile(LineCounter))

            'kill drift
            LineCounter = 0
            Do While Not NewTXWFile(LineCounter).Contains("table Loadings")
                LineCounter += 1
                If LineCounter > NewTXWFile.Count - 5 Then

                    log("Can't find 'table Loadings' in txw file")
                    log(EOP)

                End If
            Loop
            LineCounter += 1

            log("Change drift entries")
            Do While Not NewTXWFile(LineCounter).Contains("end_table")

            If Me.TOXSWArun.newDriftEntries.First = " " OrElse
                   Me.TOXSWArun.newDriftEntries.First = "" Then
                    Drift = "0.0"
                ElseIf Me.TOXSWArun.newDriftEntries.First.ToUpper = "KEEP" Then

                    log("Keep drift entry")
                    log(NewTXWFile(LineCounter))
                    LineCounter += 1
                    Continue Do

                Else
                    Drift = Me.TOXSWArun.newDriftEntries(AppCounter)
                    AppCounter += 1
                End If


                NewTXWFile(LineCounter) = "30-Dec-1899    drift     " & Drift & "     0.0        100."

                log(NewTXWFile(LineCounter))
                LineCounter += 1

            Loop

        Try

            File.WriteAllLines(txwFilePath, NewTXWFile.ToArray)
            log("Write txw file to")
            log(" Txw    : " & Path.GetFullPath(txwFilePath))

        Catch ex As Exception

            log("Can't write txw file to")
            log(" Txw    : " & txwFilePath)
            log(ex.Message)
            log(EOP)

            Return False

        End Try

        Return True

    End Function

#End Region

    Public Sub runTOXSWA(Optional txwFilePath As String = "")

        Dim RunCounter As Integer = 0

        'processinfo
        Dim myStartInfo As New ProcessStartInfo
        Dim myProcess As New Process
        Dim CWAFileName As String = ""

        log("Start TOXSWA")

        'test toxswa_focus.exe avaliable
        If Not File.Exists(Me.TOXSWArun.TOXSWAexeFilePath) Then

            File.Copy(
            sourceFileName:=Path.Combine(
                path1:=Environment.CurrentDirectory,
                path2:="toxswa_focus.exe"),
            destFileName:=Path.Combine(
                path1:=TOXSWArun.WorkingDirectory,
                path2:="toxswa_focus.exe"))

            If Not File.Exists(Path.Combine(
                path1:=TOXSWArun.WorkingDirectory,
                path2:="toxswa_focus.exe")) Then
                log("Can't find toxswa_focus.exe at '" & Me.TOXSWArun.TOXSWAexeFilePath & "'")
                log(EOP)
            End If

        End If


        With myStartInfo

            'check files and paths

            If TOXSWArun.WorkingDirectory = "" Then
                .WorkingDirectory = Me.TOXSWArun.WorkingDirectory
            Else
                .WorkingDirectory = TOXSWArun.WorkingDirectory
            End If


            If Not Directory.Exists(.WorkingDirectory) Then
                log("Can't find Working Directory " & vbCrLf & Path.GetFullPath(.WorkingDirectory) & vbCrLf & EOP)
            Else
                log("Working Directory :  " & Path.GetFullPath(.WorkingDirectory))
            End If

            If txwFilePath = "" Then txwFilePath = Me.TOXSWArun.newTXWFilePath

            .Arguments = Path.GetFileNameWithoutExtension(txwFilePath)

            .FileName = Path.GetFullPath(Me.TOXSWArun.TOXSWAexeFilePath)

            'focus_toxswa.exe window on the screen
            .WindowStyle = ProcessWindowStyle.Normal
            .CreateNoWindow = False
            .UseShellExecute = False

        End With

        Try

            With myProcess

                .StartInfo = myStartInfo
                File.WriteAllLines(Path.Combine(.StartInfo.WorkingDirectory, "StartNewTXW.bat"),
                                               {.StartInfo.FileName & " " & .StartInfo.Arguments})
                .Start()
                log("Start new txw at    : " & .StartTime.ToShortTimeString)
                log(.StartInfo.FileName & " " & .StartInfo.Arguments)

            End With

        Catch ex As Exception

            log("Can't start new TOXSWA")
            log(ex.Message)

        End Try


    End Sub

#End Region

#End Region

End Class
