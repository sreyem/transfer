﻿
Imports System.ComponentModel
Imports System.Xml.Serialization
Imports System.IO

Imports VFSmodCMD.Common
Imports System.Windows.Forms


Public Class TOXSWAInfo

    Public Sub New()

    End Sub


    Public Property TOXSWAexeFilePath As String =
        Path.Combine(
        path1:=Environment.CurrentDirectory,
        path2:="toxswa_focus_3.exe")

    Public Property TOXSWAmetFilePath As String = Path.GetDirectoryName(TOXSWAexeFilePath)

    Private m_origTXWFilePath As String = ""

    Public Property origTXWFilePath As String
        Get
            Return m_origTXWFilePath
        End Get
        Set(value As String)

            If value = "" Then Exit Property

            If value.Contains("?") Then

                Dim myOFD As New OpenFileDialog

                With myOFD

                    .Reset()
                    .Title = "Select target txw file"


                    .CheckFileExists = True

                    .DefaultExt = "txw"
                    .Filter = "TOXSWA Parameter File|*.txw|" &
                              "All files (*.*)|*.*"
                    .FilterIndex = 0

                    If .ShowDialog = DialogResult.OK Then

                        If .FileName <> "" AndAlso File.Exists(.FileName) Then
                            value = .FileName
                        Else
                            Exit Property
                        End If

                    End If

                End With

            End If

            m_origTXWFilePath = value

        End Set
    End Property

    Public Property newTXWFilePath As String = ""


    Private m_WorkingDirectory As String = ""

    Public Property WorkingDirectory As String
        Get
            Return m_WorkingDirectory
        End Get
        Set(vWorkingDirectory As String)

            Dim myFBD As New FolderBrowserDialog

            If vWorkingDirectory = "" Then Exit Property

            If vWorkingDirectory.Contains("?") Then

                With myFBD

                    .Description = "Select path to TOXSWA working directory "

                    .ShowNewFolderButton = True


                    If .ShowDialog = DialogResult.OK Then
                        m_WorkingDirectory = .SelectedPath
                    End If

                End With

            Else

                Try
                    If Directory.Exists(Path.GetDirectoryName(Path.GetFullPath(vWorkingDirectory))) Then
                        m_WorkingDirectory = vWorkingDirectory
                    End If
                Catch ex As Exception
                    log(("Error in 'TOXSWA workingdir path': " & vbCrLf & ex.Message))
                    Throw New Exception
                End Try

            End If

        End Set
    End Property


    Public Property NewP2TFilePath As String = ""

    Public Property newDriftEntries As String() = {" "}

End Class
