﻿

Imports System.ComponentModel
Imports System.Xml.Serialization
Imports System.Windows.Forms
Imports System.IO

Imports VFSmodCMD.Common

Public Class Swan2VFSmodGUI

#Region "Constructor"

    Public Sub New()

    End Sub

    Public Sub New(Swan2VFSmodGUIFileName As String)

        Me.Swan2VFSmodGUIFileName = Swan2VFSmodGUIFileName
        readSwan2VFSmodGUIFile()

    End Sub

    <XmlIgnore()>
    Public Property Swan2VFSmodGUIFileName As String

    Public Sub readSwan2VFSmodGUIFile(Optional Swan2VFSmodGUIFileName As String = "")

        Dim TempSwan2VFSmodGUI As New Swan2VFSmodGUI

        If Swan2VFSmodGUIFileName <> "" Then
            Me.Swan2VFSmodGUIFileName = Swan2VFSmodGUIFileName
        End If

        Try

            TempSwan2VFSmodGUI = CType(LoadXML2Class(ClassType:=GetType(Swan2VFSmodGUI),
                                                   XMLFileName:=Swan2VFSmodGUIFileName), 
                                       Swan2VFSmodGUI)

            With TempSwan2VFSmodGUI.Paths

                'paths
                Me.Paths.inpFilePath = .inpFilePath
                log("inpFilePath               : " & .inpFilePath)
                Me.Paths.p2tFilePath = .p2tFilePath
                log("p2tFilePath               : " & .p2tFilePath)
                Me.Paths.ztsFilePath = .ztsFilePath
                log("ztsFilePath               : " & .ztsFilePath)
                Me.Paths.ScenarioUserInputFilePath = .ScenarioUserInputFilePath
                log("ScenarioUserInputFilePath : " & .ScenarioUserInputFilePath)
                Me.Paths.VFSmodGUI2SwanPath = .VFSmodGUI2SwanPath
                log("VFSmodGUI2SwanPath        : " & .VFSmodGUI2SwanPath)

            End With

            With TempSwan2VFSmodGUI.GeneralInfo

                'general info
                Me.GeneralInfo.BufferStripLen = .BufferStripLen
                log("BufferStripLen            : " & .BufferStripLen)
                Me.GeneralInfo.ParMet = .ParMet
                log("ParMet                    : " & .ParMet.ToString)
                Me.GeneralInfo.FOCUSScenario = .FOCUSScenario
                log("FOCUSScenario             : " & .FOCUSScenario.ToString)
                Me.GeneralInfo.FOCUSWaterBody = .FOCUSWaterBody
                log("FOCUSWaterBody            : " & .FOCUSWaterBody.ToString)

            End With


        Catch ex As Exception

            Throw New Exception("Can't de-serialize xml to 'Swan2VFSmodGUI'" & vbCrLf &
                                 Swan2VFSmodGUIFileName & vbCrLf &
                                 ex.Message & vbCrLf &
                                 EOP)
            End

        End Try

    End Sub

#End Region

#Region "Properties"

    Public Property Paths As New Paths

    Public Property GeneralInfo As New GeneralInfo

#End Region

End Class

Public Class Paths

    Public Sub New()

    End Sub

#Region "Paths"

    Private m_inpFilePath As String = ""

    ''' <summary>
    ''' Full path to PRZM input file (*.inp)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Category("Paths VFSmod IN")>
    <DisplayName("PRZM input file path")>
    <Description("Full path to PRZM input file (*.inp)")>
    Public Property inpFilePath As String
        Get
            Return m_inpFilePath
        End Get
        Set(vinpFilePath As String)

            If vinpFilePath = "" Then Exit Property

            If vinpFilePath.Contains("?") Then

                Dim myOFD As New OpenFileDialog

                With myOFD

                    .Reset()
                    .Title = " Select 'PRZM input' file ( std. 'RX-YY-.inp')"

                    .Multiselect = False
                    .CheckFileExists = True

                    .DefaultExt = "inp"
                    .Filter = "PRZM input file (*.inp)|*.inp|" &
                              "All files (*.*)|*.*"
                    .FilterIndex = 0

                    If .ShowDialog = DialogResult.OK Then
                        m_inpFilePath = .FileName
                    End If

                End With

            Else

                Try
                    If File.Exists(vinpFilePath) Then
                        m_inpFilePath = Path.GetFullPath(vinpFilePath)
                    End If
                Catch ex As Exception
                    log(("Error in 'inpFilePath': " & vbCrLf & ex.Message))
                    Throw New Exception
                End Try

            End If






        End Set
    End Property

    Private m_p2tFilePath As String = ""

    ''' <summary>
    ''' Full path to PRZM -> TOXSWA lateral input file (*.p2t)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Category("Paths VFSmod IN")>
    <DisplayName("PRZM -> TOXSWA file path")>
    <Description("Full path to PRZM -> TOXSWA" & vbCrLf &
                 "lateral input file (*.p2t)")>
    Public Property p2tFilePath As String
        Get
            Return m_p2tFilePath
        End Get
        Set(vp2tFilePath As String)

            If vp2tFilePath = "" Then Exit Property

            If vp2tFilePath.Contains("?") Then

                Dim myOFD As New OpenFileDialog

                With myOFD

                    .Reset()
                    .Title = " Select 'PRZM->TOXSWA file' file ( std. 'XXXXX-CY.P2T')"

                    .Multiselect = False
                    .CheckFileExists = True

                    .DefaultExt = "P2T"
                    .Filter = "PRZM->TOXSWA file (*.P2T)|*.P2T|" &
                              "All files (*.*)|*.*"
                    .FilterIndex = 0

                    If .ShowDialog = DialogResult.OK Then
                        m_p2tFilePath = .FileName
                    End If

                End With

            Else

                Try
                    If File.Exists(vp2tFilePath) Then
                        m_p2tFilePath = Path.GetFullPath(vp2tFilePath)
                    End If
                Catch ex As Exception
                    log(("Error in 'p2tFilePath': " & vbCrLf & ex.Message))
                    Throw New Exception
                End Try

            End If

        End Set
    End Property

    Private m_ztsFilePath As String = ""

    ''' <summary>
    ''' Full path to PRZM output file (*.zts)
    ''' </summary>
    ''' <value></value>
    ''' <returns>String</returns>
    ''' <remarks>
    ''' used to get the precipitation
    ''' </remarks>
    <Category("Paths VFSmod IN")>
    <DisplayName("PRZM output file path")>
    <Description("Full path to PRZM output file (*.zts)")>
    Public Property ztsFilePath As String
        Get
            Return m_ztsFilePath
        End Get
        Set(vztsFilePath As String)

            If vztsFilePath = "" Then Exit Property

            If vztsFilePath.Contains("?") Then

                Dim myOFD As New OpenFileDialog

                With myOFD

                    .Reset()
                    .Title = " Select 'PRZM output' file ( std. 'RX-YY-.zts')"

                    .Multiselect = False
                    .CheckFileExists = True

                    .DefaultExt = "ZTS"
                    .Filter = "PRZM output file (*.ZTS)|*.ZTS|" &
                              "All files (*.*)|*.*"
                    .FilterIndex = 0

                    If .ShowDialog = DialogResult.OK Then
                        m_ztsFilePath = .FileName
                    End If

                End With

            Else

                Try
                    If File.Exists(vztsFilePath) Then
                        m_ztsFilePath = Path.GetFullPath(vztsFilePath)
                    End If
                Catch ex As Exception
                    log(("Error in 'ztsFilePath': " & vbCrLf & ex.Message))
                    Throw New Exception
                End Try

            End If

        End Set

    End Property

    Private m_ScenarioUserInputFilePath As String = ""

    ''' <summary>
    ''' Full path to scenario user input file (RxUserInput.xml, x = 1-4)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Category("Paths VFSmod IN")>
    <Browsable(False)>
    <DisplayName("Scenario User Input file path")>
    <Description("Full path to scenario user input file" & vbCrLf &
                 "(RxUserInput.xml, x = 1-4)")>
    Public Property ScenarioUserInputFilePath As String
        Get
            Return m_ScenarioUserInputFilePath
        End Get
        Set(vScenarioUserInputFilePath As String)

            If vScenarioUserInputFilePath = "" Then Exit Property

            If vScenarioUserInputFilePath.Contains("?") Then

                Dim myOFD As New OpenFileDialog

                With myOFD

                    .Reset()
                    .Title = " Select 'Scenario user input' file (std. 'RxScenarioUserInput.xml')"

                    .Multiselect = False
                    .CheckFileExists = True

                    .DefaultExt = "xml"
                    .Filter = "XML files (*.xml)|*.xml|" &
                              "All files (*.*)|*.*"
                    .FilterIndex = 0

                    If .ShowDialog = DialogResult.OK Then
                        m_ScenarioUserInputFilePath = .FileName

                    End If

                End With

            Else

                Try
                    If File.Exists(vScenarioUserInputFilePath) Then
                        m_ScenarioUserInputFilePath = Path.GetFullPath(vScenarioUserInputFilePath)
                    End If
                Catch ex As Exception
                    log(("Error in 'ScenarioUserInputFilePath': " & vbCrLf & ex.Message))
                    Throw New Exception
                End Try

            End If

        End Set
    End Property

    Private m_VFSmodGUI2SwanPath As String = ""

    ''' <summary>
    ''' Full path to VFSmod result file (VFSmodGUI2Swan.xml)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Category("Paths VFSmod OUT")>
    <DisplayName("VFSmod result path")>
    <Description("Full path to VFSmod result directory" & vbCrLf &
                 "will be also the working directoy for vfsm.exe & focus_toxswa.exe")>
    Public Property VFSmodGUI2SwanPath As String
        Get
            Return m_VFSmodGUI2SwanPath
        End Get
        Set(vVFSmodGUI2SwanPath As String)

            If vVFSmodGUI2SwanPath = "" Then Exit Property

            If vVFSmodGUI2SwanPath.Contains("?") Then

                Dim myFBD As New FolderBrowserDialog

                With myFBD

                    .Description = "Select path to VFSmod result directory "

                    .ShowNewFolderButton = True

                    If .ShowDialog = DialogResult.OK Then
                        m_VFSmodGUI2SwanPath = .SelectedPath
                    End If

                End With

            Else

                Try
                    If Directory.Exists(Path.GetFullPath(vVFSmodGUI2SwanPath)) Then
                        m_VFSmodGUI2SwanPath = Path.GetFullPath(vVFSmodGUI2SwanPath)

                    Else
                        Try
                            Directory.CreateDirectory(Path.GetFullPath(vVFSmodGUI2SwanPath))
                            m_VFSmodGUI2SwanPath = Path.GetFullPath(vVFSmodGUI2SwanPath)

                            log("Can't find working directory, creation OK " & vbCrLf &
                                vVFSmodGUI2SwanPath)

                        Catch ex As Exception

                            log("Can't find/create working directory " & vbCrLf &
                            vVFSmodGUI2SwanPath & vbCrLf & ex.Message & vbCrLf & EOP)

                        End Try

                    End If

                Catch ex As Exception

                    Try
                        Directory.CreateDirectory(Path.GetFullPath(vVFSmodGUI2SwanPath))
                        m_VFSmodGUI2SwanPath = Path.GetFullPath(vVFSmodGUI2SwanPath)

                        log("Can't find working directory, creation OK " & vbCrLf &
                            vVFSmodGUI2SwanPath)

                    Catch ex2 As Exception

                        log("Can't find/create working directory " & vbCrLf &
                        vVFSmodGUI2SwanPath & vbCrLf & ex2.Message & vbCrLf & EOP)

                    End Try

                End Try

            End If

        End Set
    End Property

#End Region

End Class

Public Class GeneralInfo

    Public Sub New()

    End Sub


#Region "General Info"

    ''' <summary>
    ''' Buffer strip lenght in the direction of the flow (m)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <[ReadOnly](True)>
    <Category("General Info")>
    <DisplayName("Buffer strip lenght (m)")>
    <Description("Buffer strip lenght in the" & vbCrLf &
                 "direction of the flow (m)")>
    Public Property BufferStripLen As Double = 5


    ''' <summary>
    ''' Parent or metabolite run
    ''' </summary>
    ''' <value>
    ''' eParMet.Parent (std.))
    ''' eParMet.Metabolite
    ''' </value>
    ''' <returns>eParMet</returns>
    ''' <remarks>
    ''' used for parsing  PRZM inp file for 
    ''' rate const. and adsoroption
    ''' </remarks>
    <Category("General Info")>
    <DisplayName("Par/Met run")>
    <Description("Parent or metabolite run")>
    Public Property ParMet As eParMet = eParMet.Parent

    <Category("General Info")>
    <DisplayName("FOCUS Sccenario")>
    <Description("Used FOCUS RunOff Sccenario" & vbCrLf &
                 "R1-R4")>
    Public Property FOCUSScenario As eFOCUSScenarios = eFOCUSScenarios.R1

    ''' <summary>
    ''' Used FOCUS water body
    ''' </summary>
    ''' <value>
    ''' eRWB.Stream (std.))
    ''' eRWB.Pond
    ''' </value>
    ''' <returns>eRWB</returns>
    ''' <remarks>
    ''' used for p2t rebuild and 
    ''' (maybe) field geometry
    ''' </remarks>
    <Category("General Info")>
    <DisplayName("FOCUS water body")>
    <Description("Used FOCUS water body" & vbCrLf &
                 "Stream or pond")>
    <Browsable(False)>
    Public Property FOCUSWaterBody As eRWB = eRWB.Stream

#End Region


End Class
