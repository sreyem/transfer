﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Allgemeine Informationen über eine Assembly werden über die folgenden 
' Attribute gesteuert. Ändern Sie diese Attributwerte, um die Informationen zu ändern,
' die mit einer Assembly verknüpft sind.

' Die Werte der Assemblyattribute überprüfen

<Assembly: AssemblyTitle("VFSmodCMD")>
<Assembly: AssemblyDescription("CMD interface FOCUS<->VFSmod 4.4.0")>
<Assembly: AssemblyCompany("Bayer CropScience")> 
<Assembly: AssemblyProduct("VFSmodCMD")>
<Assembly: AssemblyCopyright("Copyright © Horatio Meyer 2014-2020")>
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'Die folgende GUID bestimmt die ID der Typbibliothek, wenn dieses Projekt für COM verfügbar gemacht wird
<Assembly: Guid("95296f2e-358f-47d9-94f2-995f43ab2c65")>

' Versionsinformationen für eine Assembly bestehen aus den folgenden vier Werten:
'
'      Hauptversion
'      Nebenversion 
'      Buildnummer
'      Revision
'
' Sie können alle Werte angeben oder die standardmäßigen Build- und Revisionsnummern 
' übernehmen, indem Sie "*" eingeben:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.2020.0514.0819")>
<Assembly: AssemblyFileVersion("1.2020.0514.0819")>
