﻿
Imports System.IO

Public Class Common

    Public Const Digits As Integer = 3
    Public Shared FullFeat As Boolean = True 'Environment.MachineName.ToUpper.StartsWith("ADEMON")

    Public Shared ExecPath As String = My.Application.Info.DirectoryPath

    Public Enum eICOFlag
        NoFeedback = 0
        Feedback = 1
    End Enum

    Public Enum eRWB
        Stream
        Pond
    End Enum

    Public Enum eP2TEntries

        DateAndTime
        RunoffVolume
        RunoffFlux
        ErosionMass
        ErosionFlux
        Infiltration
        ZTSPrec = 7

    End Enum

    Public Enum eSedimentparticleClass

        Clay = 1
        Silt_1
        SmallAggregate
        LargeAggregate
        Sand
        Silt_2
        UserSelected

    End Enum

    Public Enum eParMet
        Parent
        Metabolite
    End Enum

    Public Enum eFOCUSScenarios
        R1 = 1
        R2
        R3
        R4
        UserDefined
    End Enum

    Public Shared TOXSWAmetFiles As String() =
        {"Weiherbach.met",
         "Porto.met",
         "Bologna.met",
         "Roujan.met"}

    Public Enum eRecomStdParameter

        SOA
        KS
        SAV
        ThetaS
        PCTOC
        PCTC
        RHO
        FC
        hmax
        VGthetaR
        VGalfa
        VGn

    End Enum

    Public Shared RecomStdParameter As String(,) =
        {
        {"0.03", "0.05", "0.05", "0.05"},
        {"7.04e-07", "2.79e-6", "9.25e-7", "1.52e-6"},
        {"0.17", "0.11", "0.21", "0.22"},
        {"0.447", "0.403", "0.472", "0.420"},
        {"1.2", "4.0", "1.0", "0.6"},
        {"13", "14", "34", "25"},
        {"1.35", "1.15", "1.46", "1.52"},
        {"0.338", "0.36", "0.37", "0.26"},
        {"1.54", "1.702", "1.44", "2.18"},       'hmax
        {"0.065", "0.039", "0.079", "0.063"},       'theta r
        {"0.51", "2.67", "1.58", "2.11"},           'alfa
        {"1.6634", "1.4488", "1.4158", "1.3305"}    'n
        }

#Region "Value Positions in inp-file"

    Public Enum enumPos
        Row
        Col
        Len
    End Enum

    Public Enum enumParPos

        'field geometrie
        FieldArea
        FieldSlope
        FieldLenght
        SoilRoughness

        'texture data
        BulkDensity
        OrganicContent
        CompoundAdsorption
        Sand
        Clay

    End Enum

    Public Shared ParPos(,) As Integer = {{4, 28, 4}, _
                                   {4, 52, 4}, _
                                   {4, 59, 5}, _
                                   {10, 0, 4}, _
                                   {9, 19, 5}, _
                                   {11, 35, 5}, _
                                   {11, 43, 5}, _
                                   {12, 19, 5}, _
                                   {12, 27, 5}}

#End Region

#Region "Crops"

    Public Enum eCrops

        cereals_spring
        cereals_winter
        citrus
        cotton
        field_beans
        grass_alfalfa
        hops
        legumes
        maize
        oil_seed_rape_spring
        oil_seed_rape_winter
        olives
        pome_stone_fruit_early_applns
        pome_stone_fruit_late_applns
        potatoes
        soybeans
        sugar_beets
        sunflowers
        tobacco
        vegetables_bulb
        vegetables_fruiting
        vegetables_leafy
        vegetables_root
        vines_early_applns
        vines_late_applns
        NotDefined

    End Enum

    Public Shared Crop As String() =
     {
"Cereals, spring",
"Cereals, winter",
"Citrus",
"Cotton",
"Field beans",
"Grass / alfalfa",
"Hops",
"Legumes",
"Maize",
"Oil seed rape, spring",
"Oil seed rape, winter",
"Olives",
"Pome / stone fruit, early applns",
"Pome / stone fruit, late applns",
"Potatoes",
"Soybeans",
"Sugar beet",
"Sunflower",
"Tobacco",
"Vegetables, bulb",
"Vegetables, fruiting",
"Vegetables, leafy",
"Vegetables, root",
"Vines, early applns",
"Vines, late applns",
"Appln, aerial",
"Appln, hand (crop < 50 cm)",
"Appln, hand (crop > 50 cm)",
"No drift (incorp or seed trtmt)"
}

#End Region

#Region "ThetaI & WTD"

    Public Shared Property ThetaIData As String() = {}

    Public Shared Function getThetaI(TargetDate As Date,
                                     FOCUSScenario As eFOCUSScenarios) As Double

        Try
            Return Double.Parse(
                Filter(ThetaIData,
                             Format(TargetDate, "yyMMdd"),
                             True, CompareMethod.Text).First.Split(CChar(vbTab))(FOCUSScenario))
        Catch ex As Exception

            log("Can't get ThetaI for" & vbCrLf &
                " Date         : " & TargetDate & vbCrLf &
                " FOCUSScenario: " & FOCUSScenario & vbCrLf &
                ex.Message & vbCrLf &
                EOP)

            Return -99

        End Try

    End Function


#End Region

#Region "Water Table Depth"

    Public Shared Property TOXSWAWaterDepths As String() = {}

    Public Shared Function getTOXSWAWaterDepths(TargetDate As Date,
                                  FOCUSScenario As eFOCUSScenarios) As Double

        Try
            Return Double.Parse(
                Filter(TOXSWAWaterDepths,
                             Format(TargetDate, "yyMMdd"),
                             True, CompareMethod.Text).First.Split(CChar(vbTab))(FOCUSScenario))
        Catch ex As Exception

            log("Can't get WaterTableDepth for" & vbCrLf &
                " Date         : " & TargetDate & vbCrLf &
                " FOCUSScenario: " & FOCUSScenario & vbCrLf &
                ex.Message & vbCrLf &
                EOP)

            Return -99

        End Try

    End Function

#End Region

#Region "FOCUS Temperatures"

    Public Shared Property FOCUSTemp As String() = {}

    Public Shared Function getFOCUSTemp(TargetDate As Date, FOCUSScenario As eFOCUSScenarios) As Double

        Try
            Return Double.Parse(
                Filter(FOCUSTemp,
                             Format(TargetDate, "yyMMdd"),
                             True, CompareMethod.Text).First.Split(CChar(vbTab))(FOCUSScenario))
        Catch ex As Exception

            Throw New ArgumentException("Can't get FOCUS Temp. for" & vbCrLf &
                                        " Date         : " & TargetDate & vbCrLf &
                                        " FOCUSScenario: " & FOCUSScenario & vbCrLf &
                                        ex.Message)

        End Try

    End Function

#End Region

    Shared Sub ErrorCatcher(ByVal e As Exception, _
                   Optional ByVal Description As String = "")

        Dim ErrorList As New List(Of String)

        Dim ErrorLevel As Integer = 1
        Dim StackTraceArray As String() = {}
        Dim ErrorLineArray As String() = {}

        Dim Delimiter As String = ""
        Dim ModuleDelimiter As String = ""
        Dim RowDelimiter As String = ""
        Dim TargetAllignSpace As Integer = 15

        Try

            With ErrorList

                .Add(Description)

                'add local machine info
                .Add("Error occurs at " & Now.ToString)
                .Add("User is " & My.User.Name & " on " & _
                                  My.Computer.Name.ToString & " (" & _
                                  Environment.ProcessorCount.ToString & "CPUs)")

                .Add("Application " & My.Application.Info.Title.ToString & " v" & _
                                      My.Application.Info.Version.ToString)

                .Add(My.Computer.Info.OSFullName & " " & _
                     My.Computer.Info.OSVersion & " (" & My.Computer.Info.OSPlatform & ")")


                .Add("Directory " & Environment.CurrentDirectory.ToString)
                .Add(CStr(IIf(My.Computer.Network.IsAvailable, "Network is available", "Network is NOT available")))
                .Add("")


                .Add("ErrorMsg".PadRight(TargetAllignSpace) & ": " & e.Message.ToString)

                'check if german or english error msg
                If e.StackTrace.Contains("at ") Then

                    Delimiter = "at "
                    ModuleDelimiter = " in "
                    RowDelimiter = ":line"

                ElseIf e.StackTrace.Contains("bei ") Then

                    Delimiter = "bei "
                    ModuleDelimiter = " in "
                    RowDelimiter = ":Zeile"

                Else

                    .Add("Can't parse error msg!")
                    .Add("ErrorMsg".PadRight(TargetAllignSpace) & ": " & e.Message.ToString)
                    .Add("StackTrace")
                    .Add(e.StackTrace.ToString)

                End If

                StackTraceArray = Split(e.StackTrace, Delimiter)
                StackTraceArray = Filter(StackTraceArray, ModuleDelimiter)

                'parse each msg
                For Each ErrorLine As String In StackTraceArray

                    ErrorLineArray = Split(ErrorLine, ModuleDelimiter)
                    .Add("Module".PadRight(TargetAllignSpace) & ": " & Trim(ErrorLineArray.First))
                    ErrorLineArray = Split(ErrorLineArray.Last, RowDelimiter)
                    .Add("in".PadRight(TargetAllignSpace) & ": " & Trim(ErrorLineArray.First))
                    .Add("at row".PadRight(TargetAllignSpace) & ": " & Trim(Replace(ErrorLineArray.Last, ".", "")))

                Next

            End With

        Catch ex As Exception

            MsgBox(ex.Message & vbNewLine & e.StackTrace, _
                   MsgBoxStyle.Critical, _
                   "Unhandled Error")

        End Try


        Try

            'write to exec. directory
            File.WriteAllLines(Path.Combine(Environment.CurrentDirectory, "Error.txt"), ErrorList.ToArray)
            'display error msg as txt file with std. program ( normaly notepad)
            Process.Start(Path.Combine(Environment.CurrentDirectory, "Error.txt"))

        Catch ex As Exception

            'can't write txt file or can't start default editor
            MsgBox(Join(ErrorList.ToArray, vbNewLine), MsgBoxStyle.Critical, "Fatal Error")

        End Try

    End Sub

#Region "Log"

    Public Const EOP As String = "End of program"

    Public Shared LogFileName As String = ""

    Public Shared Sub resetLog()

        Try
            File.Delete(Path.Combine(Path.GetDirectoryName(Environment.CurrentDirectory),
                                             "log.txt"))

        Catch ex As Exception

        End Try

    End Sub

    Public Shared Property myLog As New List(Of String)

    Shared Property LogDateString As String = "hh:mm:ss"

    Shared Property rtblog As New System.Windows.Forms.RichTextBox

    <DebuggerStepThrough()>
    Shared Sub log(ByVal LogText As String)

        Dim LogEntry As String = " "

        If LogDateString <> "" Then
            LogEntry = Format(Now, LogDateString) & " "
        End If


        If LogFileName = "" Then
            LogFileName = Path.Combine(Path.GetDirectoryName(Environment.CurrentDirectory),
                                                         "log.txt")
            log("Log file = " & LogFileName)
        End If

        LogEntry &= LogText

        LogEntry = Replace(LogEntry, vbCrLf, vbCrLf & Format(Now, LogDateString) & " ")

        'Console.WriteLine(LogEntry)
        myLog.Add(LogEntry)


        Try
            rtblog.Lines = myLog.ToArray
        Catch ex As Exception

        End Try


        Try

            File.WriteAllLines(LogFileName, myLog.ToArray)

        Catch ex As Exception

            Console.WriteLine("Can't write to log file" & vbCrLf & LogFileName)

        End Try

        If LogEntry.Contains(EOP) Then

            Try
                Process.Start(LogFileName)
                End
            Catch ex As Exception

            End Try

        End If

    End Sub

#End Region




End Class
