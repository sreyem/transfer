﻿
Imports System.IO

Module ToolBox

#Region "Strings"

    Public Enum FirstOrLast
        First
        Last
    End Enum


    ''' <summary>
    ''' Returns then array index of a searchstring
    ''' </summary>
    ''' <param name="SearchString">
    ''' String to search for
    ''' </param>
    ''' <param name="StringArray">
    ''' StringArray to search
    ''' </param>
    ''' <returns>
    ''' Index as integer, if nothing found then it returns -1
    ''' </returns>
    ''' <remarks></remarks>
    <DebuggerStepThrough()>
    Public Function getIndex(ByVal SearchString As String, _
                             ByVal StringArray As String(), _
                    Optional ByVal FirstLast As FirstOrLast = FirstOrLast.First) As Integer

        SearchIndexString = SearchString

        If FirstLast = FirstOrLast.Last Then
            Return Array.FindLastIndex(StringArray, AddressOf getIndexHelper)
        Else
            Return Array.FindIndex(StringArray, AddressOf getIndexHelper)
        End If

    End Function

    Public SearchIndexString As String = ""
    <DebuggerStepThrough()>
    Private Function getIndexHelper(ByVal ActualLine As String) As Boolean

        If InStr(ActualLine, SearchIndexString) <> 0 OrElse _
           ActualLine.StartsWith(SearchIndexString) Then Return True Else Return False

    End Function

#End Region

#Region "XML Load/Save"

    <DebuggerStepThrough()>
    Public Sub SaveClass2XML(ByVal Class2Save As Object, _
                             ByVal ClassType As Type, _
                             ByVal XMLFileName As String)

        If Not Directory.Exists(Path.GetDirectoryName(XMLFileName)) Then _
            Throw New DirectoryNotFoundException("No valid XML Path")

        Try

            Dim mySerializer As Xml.Serialization.XmlSerializer = _
                            New Xml.Serialization.XmlSerializer(ClassType)

            Dim myWriter As IO.StreamWriter = _
                        New IO.StreamWriter(XMLFileName)

            mySerializer.Serialize(myWriter, Class2Save)
            myWriter.Close()

        Catch ex As Exception
            Throw (ex)
        End Try

    End Sub

    <DebuggerStepThrough()>
    Public Function LoadXML2Class(ByVal ClassType As Type, _
                                  ByVal XMLFileName As String) As Object

        Dim TargetClass As New Object

        Try

            Dim mySerializer As Xml.Serialization.XmlSerializer = _
                                    New Xml.Serialization.XmlSerializer(ClassType)

            ' To read the file, create a FileStream.
            Dim myFileStream As IO.FileStream = _
                            New IO.FileStream(XMLFileName, IO.FileMode.Open)

            ' Call the Deserialize method and cast to the object type.
            TargetClass = mySerializer.Deserialize(myFileStream)


            myFileStream.Close()

            Return TargetClass

        Catch ex As Exception
            Throw New ArgumentException(ex.Message)
        End Try

    End Function

#End Region

#Region "Misc"


    <DebuggerStepThrough()>
    Function NumberFormat(ByVal Number As Double,
                 Optional ByVal Digits As Integer = 4,
                 Optional ByVal Scientific As Boolean = False) As String


        Dim LowerLimit As Double
        Dim UpperLimit As Double

        Dim RoundingDigits As Integer = Digits
        Dim NumbersbeforDecPoint As Integer = 1

        Dim Formatstring As New System.Text.StringBuilder


        Try
            LowerLimit = Math.Pow(10, -(Digits - 1))
            UpperLimit = 1 / LowerLimit
        Catch ex As Exception
            Console.WriteLine("Number format error " & ex.Message)
            Return ""
        End Try


        'lower and upper bounds
        If Number < LowerLimit AndAlso Not Scientific Then

            If Digits < 5 Then
                Return "<" & (Math.Pow(10, -(Digits - 1))).ToString
            Else
                Return "<" & Format(Math.Pow(10, -(Digits - 1)), "0E+00")
            End If

        End If

        If Number > UpperLimit Then _
            Return Math.Round(Number, 0).ToString

        Formatstring.Append("0.")

        If Number < 1 Then
            RoundingDigits = Digits
        Else
            NumbersbeforDecPoint = 1 + CInt(Math.Floor(Math.Log10(Number)))
            RoundingDigits = Digits - NumbersbeforDecPoint
        End If

        Formatstring.Append("0"c, RoundingDigits)
        If Scientific Then
            Formatstring.Append("0E+00")
            Return Format(Number, Formatstring.ToString)
        End If


        Return Format(Math.Round(Number, RoundingDigits), Formatstring.ToString)


    End Function

#End Region



End Module
