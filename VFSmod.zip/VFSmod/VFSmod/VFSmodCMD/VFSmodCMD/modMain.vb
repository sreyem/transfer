﻿
Imports VFSmodCMD.Common
Imports System.IO

Module modMain


    Public CMDArgs As New List(Of String)

    Public VFSmod As New VFSmod

    Public ZeroBuffer As Boolean = False

    Sub Main()

        init()
        getCMDStartInfo()

        End

    End Sub


    Public Sub init()

        Try
            Console.SetWindowSize(90, 50)
        Catch ex As Exception

        End Try

        Console.Clear()


        Console.WriteLine("VFSmod v4.4.0  04/2018 by")
        'Console.WriteLine("-------------------------------------------------------")
        Console.WriteLine("        R.Munoz-Carpena          J.E. Parsons          ")
        Console.WriteLine("        U. of FL - USA           NCSU - USA            ")
        Console.WriteLine("        carpena@ufl.edu          john_parsons@ncsu.edu ")
        Console.WriteLine("-------------------------------------------------------")
        Console.WriteLine(My.Application.Info.Title & " v" &
                          My.Application.Info.Version.ToString & " by")
        'Console.WriteLine("-------------------------------------------------------")
        Console.WriteLine("        Bjoern Roepke            Horatio Meyer         ")
        Console.WriteLine("        Bayer CropScience        Bayer CropScience     ")
        Console.WriteLine("        Bjoern.Roepke@bayer.com  Horatio.Meyer@bayer.com")
        Console.WriteLine("--------------------------------------------------------")
        Console.WriteLine("Started on " & Format(Now, "dddd, dd.MMM.yy"))
        Console.WriteLine("        at " & Format(Now, "hh:mm:ss"))
        Console.WriteLine("        by " & Environment.UserName)
        Console.WriteLine("on machine " & Environment.MachineName & " (" & Environment.ProcessorCount & " CPUs)")
        Console.WriteLine("        OS " & Environment.OSVersion.VersionString)
        Console.WriteLine("-------------------------------------------------------")
        Console.WriteLine("-------------------------------------------------------")

        LogFileName = Path.Combine(ExecPath, "log.txt")


    End Sub

    Public Sub getCMDStartInfo()

        Try

            If CMDArgs.Count = 0 Then
                CMDArgs.AddRange(Environment.GetCommandLineArgs)
                CMDArgs.RemoveAt(0)
            End If


            If CMDArgs.Count <> 0 Then
                log("CMD-line run")
            Else
                log("VFSmodCMD v." & My.Application.Info.Version.ToString)
                log("No CMD parameter selected")
                log("Usage : VFSmodCMD.exe  " & Chr(34) & "Path to 'SWAN2VFSmodGUI.xml'" & Chr(34))


                CMDArgs.Clear()
                CMDArgs.Add(
                    Directory.GetFiles(
                    path:=Environment.CurrentDirectory,
                    searchPattern:="Swan2VFSmodGUI.xml").First)
                CMDArgs(0) = (InputBox(Prompt:="Full path to 'Swan2VFSmodGUI.xml'", DefaultResponse:=CMDArgs(0)))


                CMDArgs.Add(
                    Directory.GetFiles(
                    path:=Environment.CurrentDirectory,
                    searchPattern:="TOXSWArunInfo.xml").First)
                CMDArgs(1) = (InputBox(Prompt:="Full path to 'TOXSWArunInfo.xml'", DefaultResponse:=CMDArgs(1)))

                If Not File.Exists(CMDArgs(1)) Then CMDArgs.RemoveAt(1)


            End If

        Catch ex As Exception
            log("Error reading CMD parameter")
            log("Usage : VFSmodCMD.exe  " & Chr(34) & "Path to 'SWAN2VFSmodGUI.xml'" & Chr(34))
            log(ex.Message)
            End
        End Try

        If CMDArgs.Count = 1 Then

            StartVFSmodWithSwan2VFSmodGUI(CMDArgs(0))

        ElseIf CMDArgs.Count = 2 Then

            StartVFSmodWithSwan2VFSmodGUI(CMDArgs(0))
            createMittigationP2T()
            StartTOXSWA(CMDArgs(1))

        End If

        'save everything
        SaveClass2XML(VFSmod,
                         GetType(VFSmod),
                         Path.Combine(ExecPath, "VFSmodCMDSave.xml"))

    End Sub

    Public Sub StartVFSmodWithSwan2VFSmodGUI(Swan2VFSmodGUIFilePath As String)

        log("CMD-line argument: full path to Swan2VFSmodGUI.xml")
        log("                   " & Path.GetFullPath(Swan2VFSmodGUIFilePath))

        Try
            'setup VFSmod with 'Swan2VFSmodGUI.xml'
            VFSmod = New VFSmod(Swan2VFSmodGUIFilePath:=Path.GetFullPath(Swan2VFSmodGUIFilePath))

            'run VFSmod
            If VFSmod.Swan2VFSmodGUI.GeneralInfo.BufferStripLen = 0 Then
                VFSmod.runVFSmod(True)
            Else
                VFSmod.runVFSmod(False)
            End If

            'save interface file to SWAN
            SaveClass2XML(VFSmod.VFSmodGUI2Swan,
                                  GetType(VFSmodGUI2Swan),
                                  Path.Combine(VFSmod.Swan2VFSmodGUI.Paths.VFSmodGUI2SwanPath,
                                               "VFSmodGUI2Swan.xml"))
        Catch ex As Exception
            log("Error running VFSmod")
            log("CMD-line argument: full path to Swan2VFSmodGUI.xml")
            log("                   " & Path.GetFullPath(Swan2VFSmodGUIFilePath))
            log(ex.Message)
            log(EOP)
        End Try

    End Sub

    Public Sub restartVFSmod()

        If CMDArgs(0).Contains("VFSmodCMDSave") Then
            log("CMD-line argument: fullpath to VFSmodCMDSave.xml")
            log("                   " & Path.GetFullPath(CMDArgs(0)))

            Try
                log("De-Serialize 'VFSmod' from " & Path.GetFullPath(CMDArgs(0)))
                VFSmod = CType(LoadXML2Class(GetType(VFSmod), CMDArgs(0)), VFSmodCMD.VFSmod)
                log("De-Serialize 'VFSmod' OK ")
            Catch ex As Exception
                log("Error De-Serialize 'VFSmod' from " &
                    Path.GetFullPath(CMDArgs(0)) & vbCrLf &
                    ex.Message & vbCrLf & EOP)
            End Try

            VFSmod.fillTOXSWArun()
            VFSmod.PRZMOutData.rebuildP2T(VFSmodResults:=VFSmod.VFSmodGUI2Swan.VFSmodResults,
                                                     WB:=VFSmod.Swan2VFSmodGUI.GeneralInfo.FOCUSWaterBody)

            log("Write new p2t file")
            log(" P2T     : " & VFSmod.TOXSWArun.NewP2TFilePath)
            File.WriteAllLines(path:=VFSmod.TOXSWArun.NewP2TFilePath,
                           contents:=VFSmod.PRZMOutData.MitigationP2T)

            VFSmod.runTOXSWA()

        Else

            log("CMD-line argument: full path to Swan2VFSmodGUI.xml")
            log("                   " & CMDArgs(0))

            'setup VFSmod with 'Swan2VFSmodGUI.xml'
            VFSmod = New VFSmod(Swan2VFSmodGUIFilePath:=CMDArgs(0))
            'run VFSmod
            VFSmod.runVFSmod()
            'save interface file to SWAN
            SaveClass2XML(VFSmod.VFSmodGUI2Swan,
                                  GetType(VFSmodGUI2Swan),
                                  Path.Combine(VFSmod.Swan2VFSmodGUI.Paths.VFSmodGUI2SwanPath,
                                               "VFSmodGUI2Swan.xml"))

        End If

    End Sub

    Public Sub createMittigationP2T()

        CMDArgs(0) = Path.GetFullPath(CMDArgs(0))

        'log("full path to TOXSWAInfo.xml " & Path.GetFullPath(CMDArgs(1)))

        'VFSmod.getTOXSWArunInfo(CMDArgs(1))
        VFSmod.fillTOXSWArun()

        'create new p2t file
        VFSmod.PRZMOutData.rebuildP2T(VFSmodResults:=VFSmod.VFSmodGUI2Swan.VFSmodResults,
                                                 WB:=VFSmod.Swan2VFSmodGUI.GeneralInfo.FOCUSWaterBody)

        log("Write new p2t file")
        log(" P2T     : " & VFSmod.TOXSWArun.NewP2TFilePath)

        Try
            File.WriteAllLines(path:=VFSmod.TOXSWArun.NewP2TFilePath,
                           contents:=VFSmod.PRZMOutData.MitigationP2T)
        Catch ex As Exception

            log("Can't write new p2t file to : " & VFSmod.TOXSWArun.NewP2TFilePath)
            log(ex.Message)
            log(EOP)

        End Try


        ''run toxswa
        'Try
        '    VFSmod.runTOXSWA()
        'Catch ex As Exception

        'End Try



    End Sub


    Public Sub StartTOXSWA(TOXSWAInfoFilePath As String)

        Try
            If TOXSWAInfoFilePath.ToUpper <> "STD" Then
                TOXSWAInfoFilePath = Path.GetFullPath(TOXSWAInfoFilePath)
            End If
        Catch ex As Exception

            log("Error reading 'TOXSWAInfoFilePath'")
            log("CMD-line argument: full path to Swan2VFSmodGUI.xml")
            log("                   " & CMDArgs(0))
            log("                   full path to TOXSWAInfo.xml")
            log("                   " & TOXSWAInfoFilePath)
            log(ex.Message)
            log(EOP)

        End Try

        CMDArgs(0) = Path.GetFullPath(CMDArgs(0))

        log("full path to TOXSWAInfo.xml " & Path.GetFullPath(CMDArgs(1)))
        
        VFSmod.getTOXSWArunInfo(CMDArgs(1))
        VFSmod.fillTOXSWArun()

        'create new p2t file
        VFSmod.PRZMOutData.rebuildP2T(VFSmodResults:=VFSmod.VFSmodGUI2Swan.VFSmodResults,
                                                 WB:=VFSmod.Swan2VFSmodGUI.GeneralInfo.FOCUSWaterBody)

        log("Write new p2t file")
        log(" P2T     : " & VFSmod.TOXSWArun.NewP2TFilePath)

        Try
            File.WriteAllLines(path:=VFSmod.TOXSWArun.NewP2TFilePath,
                           contents:=VFSmod.PRZMOutData.MitigationP2T)
        Catch ex As Exception

            log("Can't write new p2t file to : " & VFSmod.TOXSWArun.NewP2TFilePath)
            log(ex.Message)
            log(EOP)

        End Try


        ''run toxswa
        'Try
        '    VFSmod.runTOXSWA()
        'Catch ex As Exception

        'End Try



    End Sub

End Module
