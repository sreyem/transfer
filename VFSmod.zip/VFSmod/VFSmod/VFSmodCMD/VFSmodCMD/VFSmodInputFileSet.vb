﻿
Imports System.ComponentModel
Imports System.Xml.Serialization
Imports System.IO

Imports VFSmodCMD.Common
Imports VFSmodCMD.ScenarioUserInput
Imports VFSmodCMD.ToolBox


'<DebuggerStepThrough()>
<Serializable()>
Public Class VFSmodInputFilesSet

    Public Sub New()

    End Sub

    Public Sub New(ByVal P2TEvent As P2TEvent,
                   ByVal UserInput As ScenarioUserInput)

        Me.P2TEvent = P2TEvent
        Me.ScenarioUserInput = UserInput


        Me.IKW = New IKW(Me.ScenarioUserInput, Me.P2TEvent)
        Me.ISO = New ISO(Me.ScenarioUserInput, P2TEvent)
        Me.IGR = New IGR(Me.ScenarioUserInput)
        Me.ISD = New ISD(Me.ScenarioUserInput, Me.P2TEvent)
        Me.IRN = New IRN(Me.P2TEvent)
        Me.IRO = New IRO(Me.ScenarioUserInput, Me.P2TEvent)
        Me.IWQ = New IWQ(Me.ScenarioUserInput, Me.P2TEvent)

    End Sub

#Region "Inputs"

    <XmlIgnore()>
    <Browsable(False)>
    Private Property P2TEvent As New P2TEvent

    <XmlIgnore()>
    <Browsable(False)>
    Private Property ScenarioUserInput As New ScenarioUserInput

#End Region

#Region "Properties"

    Private m_IKW As New IKW
    Private m_ISO As New ISO
    Private m_IGR As New IGR
    Private m_ISD As New ISD
    Private m_IRN As New IRN
    Private m_IRO As New IRO
    Private m_IWQ As New IWQ

    ''' <summary>
    ''' IKW Overland Flow Inputs
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Overland Flow Inputs")>
    <Browsable(True)>
    <DisplayName("IKW Overland Flow Inputs")>
    <[ReadOnly](False)>
    Public Property IKW() As IKW
        Get
            Return m_IKW
        End Get
        Set(ByVal vIKW As IKW)
            m_IKW = vIKW
        End Set
    End Property

    ''' <summary>
    ''' ISO Infiltration Soil Properties
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Infiltration Soil Properties")>
    <Browsable(True)>
    <DisplayName("ISO Infiltration Soil Properties")>
    <[ReadOnly](False)>
    Public Property ISO() As ISO
        Get
            Return m_ISO
        End Get
        Set(ByVal vISO As ISO)
            m_ISO = vISO
        End Set
    End Property

    ''' <summary>
    ''' IGR Buffer Vegetation Characteristics
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Buffer Vegetation Characteristics")>
    <Browsable(True)>
    <DisplayName("IGR Buffer Vegetation Characteristics")>
    <[ReadOnly](False)>
    Public Property IGR() As IGR
        Get
            Return m_IGR
        End Get
        Set(ByVal vIGR As IGR)
            m_IGR = vIGR
        End Set
    End Property

    ''' <summary>
    ''' ISD Incomming Sediment Characteristics
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Incomming Sediment Characteristics")>
    <Browsable(True)>
    <DisplayName("ISD Incomming Sediment Characteristics")>
    <[ReadOnly](False)>
    Public Property ISD() As ISD
        Get
            Return m_ISD
        End Get
        Set(ByVal vISD As ISD)
            m_ISD = vISD
        End Set
    End Property

    ''' <summary>
    ''' IRN Storm Hydrograph
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Storm Hydrograph")>
    <Browsable(True)>
    <DisplayName("IRN Storm Hydrograph")>
    <[ReadOnly](False)>
    Public Property IRN() As IRN
        Get
            Return m_IRN
        End Get
        Set(ByVal vIRN As IRN)
            m_IRN = vIRN
        End Set
    End Property

    ''' <summary>
    ''' IRO Storm Runoff Hydrograph
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Storm Runoff Hydrograph")>
    <Browsable(True)>
    <DisplayName("IRD Storm Runoff Hydrograph")>
    <[ReadOnly](False)>
    Public Property IRO() As IRO
        Get
            Return m_IRO
        End Get
        Set(ByVal vIRO As IRO)
            m_IRO = vIRO
        End Set
    End Property

    ''' <summary>
    ''' IWQ Water quality/transport submodel
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Water quality/transport submodel")>
    <Browsable(True)>
    <DisplayName("IWQ Water quality/transport submodel")>
    <[ReadOnly](False)>
    Public Property IWQ() As IWQ
        Get
            Return m_IWQ
        End Get
        Set(ByVal vIWQ As IWQ)
            m_IWQ = vIWQ
        End Set
    End Property


    Public ReadOnly Property PRJ As String()
        Get

            Return {
                 "ikw = VFSmod.ikw",
                 "iso = VFSmod.iso",
                 "igr = VFSmod.igr",
                 "isd = VFSmod.isd",
                 "irn = VFSmod.irn",
                 "iro = VFSmod.iro",
                 "iwq = VFSmod.iwq",
                 "og1 = VFSmod.og1",
                 "og2 = VFSmod.og2",
                 "ohy = VFSmod.ohy",
                 "osm = VFSmod.osm",
                 "owq = VFSmod.owq",
                 "osp = VFSmod.osp"
                   }

        End Get

    End Property

#End Region

#Region "Methods"

    Public Sub writeAllFiles(OutputPath As String,
                    Optional Delay As Integer = 500)

        Threading.Thread.Sleep(Delay)

        OutputPath &= "\VFSmod"

        Try
            SaveClass2XML(Class2Save:=P2TEvent,
                           ClassType:=GetType(P2TEvent),
                         XMLFileName:=OutputPath & ".xml")
        Catch ex1 As Exception
            Try

                Threading.Thread.Sleep(Delay * 3)
                log("Write VFSmod P2TEvent xml file" & vbCrLf & OutputPath & ".xml" & " at 2nd try!")
                log(ex1.Message)

                SaveClass2XML(Class2Save:=P2TEvent,
                               ClassType:=GetType(P2TEvent),
                             XMLFileName:=OutputPath & ".xml")

            Catch ex2 As Exception
                log("Can't write VFSmod P2TEvent xml file" & vbCrLf & OutputPath & ".xml" & vbCrLf & ex2.Message & vbCrLf & EOP)
            End Try

        End Try

        Try
            Console.WriteLine("Write " & OutputPath & ".ikw")
        Catch ex As Exception

        End Try


        Try
            File.WriteAllLines(OutputPath & ".ikw", Me.IKW.IKWfile)
        Catch ex1 As Exception
            Try

                Threading.Thread.Sleep(Delay * 3)
                log("Write VFSmod input file" & vbCrLf & OutputPath & ".ikw" & " at 2nd try!")
                log(ex1.Message)
                File.WriteAllLines(OutputPath & ".ikw", Me.IKW.IKWfile)

            Catch ex2 As Exception
                log("Can't write VFSmod input file" & vbCrLf & OutputPath & ".ikw" & vbCrLf & ex2.Message & vbCrLf & EOP)
            End Try

        End Try

        Try
            Console.WriteLine("Write ikw OK")
            Console.SetCursorPosition(0, Console.CursorTop - 2)

            Console.WriteLine("Write " & OutputPath & ".iso")
        Catch ex As Exception

        End Try


        Try
            File.WriteAllLines(OutputPath & ".iso", Me.ISO.ISOfile)
        Catch ex1 As Exception
            Try

                Threading.Thread.Sleep(Delay * 3)
                log("Write VFSmod input file" & vbCrLf & OutputPath & ".iso" & " at 2nd try!")
                log(ex1.Message)
                File.WriteAllLines(OutputPath & ".iso", Me.ISO.ISOfile)

            Catch ex2 As Exception
                log("Can't write VFSmod input file" & vbCrLf & OutputPath & ".iso" & vbCrLf & ex2.Message & vbCrLf & EOP)
            End Try

        End Try

        Try
            Console.WriteLine("Write iso OK")
            Console.SetCursorPosition(0, Console.CursorTop - 2)

            Console.WriteLine("Write " & OutputPath & ".igr")
        Catch ex As Exception

        End Try

        Try
            File.WriteAllLines(OutputPath & ".igr", Me.IGR.IGRfile)
        Catch ex1 As Exception
            Try

                Threading.Thread.Sleep(Delay * 3)
                log("Write VFSmod input file" & vbCrLf & OutputPath & ".igr" & " at 2nd try!")
                log(ex1.Message)
                File.WriteAllLines(OutputPath & ".igr", Me.IGR.IGRfile)

            Catch ex2 As Exception
                log("Can't write VFSmod input file" & vbCrLf & OutputPath & ".igr" & vbCrLf & ex2.Message & vbCrLf & EOP)
            End Try

        End Try

        Try
            Console.WriteLine("Write igr OK")
            Console.SetCursorPosition(0, Console.CursorTop - 2)

            Console.WriteLine("Write " & OutputPath & ".isd")
        Catch ex As Exception

        End Try

        Try
            File.WriteAllLines(OutputPath & ".isd", Me.ISD.ISDfile)
        Catch ex1 As Exception
            Try

                Threading.Thread.Sleep(Delay * 3)
                log("Write VFSmod input file" & vbCrLf & OutputPath & ".isd" & " at 2nd try!")
                log(ex1.Message)
                File.WriteAllLines(OutputPath & ".isd", Me.ISD.ISDfile)

            Catch ex2 As Exception
                log("Can't write VFSmod input file" & vbCrLf & OutputPath & ".isd" & vbCrLf & ex2.Message & vbCrLf & EOP)
            End Try

        End Try

        Try
            Console.WriteLine("Write isd OK")
            Console.SetCursorPosition(0, Console.CursorTop - 2)

            Console.WriteLine("Write " & OutputPath & ".irn")
        Catch ex As Exception

        End Try

        Try
            File.WriteAllLines(OutputPath & ".irn", Me.IRN.IRNfile)
        Catch ex1 As Exception
            Try

                Threading.Thread.Sleep(Delay * 3)
                log("Write VFSmod input file" & vbCrLf & OutputPath & ".irn" & " at 2nd try!")
                log(ex1.Message)
                File.WriteAllLines(OutputPath & ".irn", Me.IRN.IRNfile)

            Catch ex2 As Exception
                log("Can't write VFSmod input file" & vbCrLf & OutputPath & ".irn" & vbCrLf & ex2.Message & vbCrLf & EOP)
            End Try

        End Try

        Try
            Console.WriteLine("Write irn OK")
            Console.SetCursorPosition(0, Console.CursorTop - 2)

            Console.WriteLine("Write " & OutputPath & ".iro")
        Catch ex As Exception

        End Try


        Try
            File.WriteAllLines(OutputPath & ".iro", Me.IRO.IROfile)
        Catch ex1 As Exception
            Try

                Threading.Thread.Sleep(Delay * 3)
                log("Write VFSmod input file" & vbCrLf & OutputPath & ".iro" & " at 2nd try!")
                log(ex1.Message)
                File.WriteAllLines(OutputPath & ".iro", Me.IRO.IROfile)

            Catch ex2 As Exception
                log("Can't write VFSmod input file" & vbCrLf & OutputPath & ".iro" & vbCrLf & ex2.Message & vbCrLf & EOP)
            End Try

        End Try

        Try
            Console.WriteLine("Write iro OK")
            Console.SetCursorPosition(0, Console.CursorTop - 2)

            Console.WriteLine("Write " & OutputPath & ".iwq")
        Catch ex As Exception

        End Try


        Try
            File.WriteAllLines(OutputPath & ".iwq", Me.IWQ.IWQfile)
        Catch ex1 As Exception
            Try

                Threading.Thread.Sleep(Delay * 3)
                log("Write VFSmod input file" & vbCrLf & OutputPath & ".iwq" & " at 2nd try!")
                log(ex1.Message)
                File.WriteAllLines(OutputPath & ".iwq", Me.IWQ.IWQfile)

            Catch ex2 As Exception
                log("Can't write VFSmod input file" & vbCrLf & OutputPath & ".iwq" & vbCrLf & ex2.Message & vbCrLf & EOP)
            End Try

        End Try

        Try
            Console.WriteLine("Write iwq OK")
            Console.SetCursorPosition(0, Console.CursorTop - 2)

            Console.WriteLine("Write " & OutputPath & ".prj")
        Catch ex As Exception

        End Try


        Try
            File.WriteAllLines(OutputPath & ".prj", Me.PRJ)
        Catch ex1 As Exception
            Try

                Threading.Thread.Sleep(Delay * 3)
                log("Write VFSmod input file" & vbCrLf & OutputPath & ".prj" & " at 2nd try!")
                log(ex1.Message)
                File.WriteAllLines(OutputPath & ".prj", Me.PRJ)

            Catch ex2 As Exception
                log("Can't write VFSmod input file" & vbCrLf & OutputPath & ".prj" & vbCrLf & ex2.Message & vbCrLf & EOP)
            End Try

        End Try

        Try
            Console.WriteLine("Write iwq OK")
            Console.SetCursorPosition(0, Console.CursorTop - 1)
            Console.WriteLine("Write VFSmod input files OK")
            Console.SetCursorPosition(0, Console.CursorTop - 2)
            Console.WriteLine("                                                                                                                               ")
            Console.WriteLine("                                                                                                                               ")
            Console.SetCursorPosition(0, Console.CursorTop - 2)
        Catch ex As Exception

        End Try



    End Sub

    Public Shared Sub clearOutputPath(Path2Clear As String,
                            Optional Delay As Integer = 100)

        Dim OldFiles As New List(Of String)
        Dim ActFileName As String = ""

        If Path2Clear = "" OrElse Not Directory.Exists(Path2Clear) Then
            log("VFSmod result path not found" & vbCrLf & Path2Clear & vbCrLf & EOP)
        End If


        OldFiles.AddRange(Directory.GetFiles(Path2Clear, "VFSmod.i*"))
        OldFiles.AddRange(Directory.GetFiles(Path2Clear, "VFSmod.o*"))
        OldFiles.AddRange(Directory.GetFiles(Path2Clear, "VFSmod.prj"))
        OldFiles.AddRange(Directory.GetFiles(Path2Clear, "VFSmod.xml"))

        OldFiles.AddRange(Directory.GetFiles(Path2Clear, "*zip.tmp*"))

        For Each OldFile As String In OldFiles

            Try

                ActFileName = OldFile
                Threading.Thread.Sleep(Delay)
                File.Delete(ActFileName)

            Catch ex1 As Exception

                Try
                    Threading.Thread.Sleep(Delay * 10)
                    File.Delete(ActFileName)
                    log("Deleted " & ActFileName & " at snd try!" & ex1.Message)
                Catch ex2 As Exception
                    log("Can't delete old file" & vbCrLf & ex2.Message & vbCrLf & EOP)
                End Try

            End Try

        Next

    End Sub

#End Region

End Class

#Region "VFSmod input files"

''' <summary>
''' IKW Overland Flow Inputs
''' </summary>
''' <remarks></remarks>
<DebuggerStepThrough()>
<Serializable()>
<DisplayName("IKW Overland Flow Inputs")>
Public Class IKW

    Public Sub New()

    End Sub

    Public Sub New(UserInput As ScenarioUserInput,
                   P2TEvent As P2TEvent,
          Optional SaveRun As Boolean = False)

        Me.TITLE = Format(P2TEvent.EventDate, "yyMMdd")
        Me.EventDate = P2TEvent.EventDate

        With UserInput.StdValues

            Me.FWIDTH = .FWIDTH
            Me.VL = .VL
            Me.SX = .VL

            'base for n: buffer = 5 => n = 57

            If SaveRun Then
                Me.N = 57
            Else

                If .NodesCalcUser = StdProperties.eNodes.Calculated Then
                    Me.N = CInt(Math.Round(Me.VL / 5 * 57, 0))
                Else
                    Me.N = .N
                End If

                'make sure n is an odd no
                If Math.IEEERemainder(Me.N, 2) = 0 Then Me.N += 1

                'limit n to 115 max.
                If Me.N > 115 Then Me.N = 115

            End If

        End With

        With UserInput.ScenarioProperties
            Me.SOA = .SOA
        End With

    End Sub

#Region "Std. Parameters"

    Public Enum OutputElemental
        No
        Yes
    End Enum


    ''' <summary>
    ''' (Real) lenght of the strip (m)
    ''' </summary>
    ''' <value>(Real) Strip Lenght (m)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("(Real) X distance from the beginning on the filter, " & vbCrLf &
                 "in which the segment of uniform surface properties ends (SX=VL, m)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(5)>
    Public Property SX() As Double = 5

    ''' <summary>
    ''' Number of nodes in the domain (integer) 
    ''' (must be an odd number for a quadratic finite element solution, 
    ''' but the program checks and corrects if needed). 
    ''' (57 recommended)
    ''' </summary>
    ''' <value>57 recommended</value>
    ''' <returns>Integer</returns>
    ''' <remarks></remarks>
    <Description("Number of nodes in the domain (integer)" & vbCrLf &
                 "(must be an odd number for a quadratic finite element" & vbCrLf &
                 " solution, but the program checks and corrects if needed). " & vbCrLf &
                 "(57 recommended")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(57)>
    Public Property N() As Integer = 57


    ''' <summary>
    ''' Time-weight factor for the Crank-Nicholson solution 
    ''' (0.5 recommended)
    ''' </summary>
    ''' <value>0.5 recommended</value>
    ''' <returns>Decimal</returns>
    ''' <remarks></remarks>
    <Description("Time-weight factor for the Crank-Nicholson solution " & vbCrLf &
                 "(0.5 recommended)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0.5)>
    Public Property THETAW() As Double = 0.5


    ''' <summary>
    ''' Courant number for the calculation of time step from 0.5 - 0.8
    ''' (0.8 recommended)
    ''' </summary>
    ''' <value>0.8 recommended</value>
    ''' <returns>Decimal</returns>
    ''' <remarks></remarks>
    <Description("Courant number for the calculation of time" & vbCrLf &
                 "step from 0.5 - 0.8 " & vbCrLf &
                 "(0.8 recommended)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0.8)>
    Public Property CR() As Double = 0.8


    ''' <summary>
    ''' Maximum number of iterations allowed in the Picard loop 
    ''' </summary>
    ''' <value>350 recommended</value>
    ''' <returns>Integer</returns>
    ''' <remarks></remarks>
    <Description("Maximum number of iterations allowed in the Picard loop " & vbCrLf &
                 "(350 recommended)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(350)>
    Public Property MAXITER() As Integer = 350


    ''' <summary>
    ''' Number of nodal points over each element polynomial degree +1
    ''' </summary>
    ''' <value>3 recommended</value>
    ''' <returns>Integer</returns>
    ''' <remarks></remarks>
    <Description("Number of nodal points over each element " & vbCrLf &
                 "(polynomial degree +1, 3 recommended)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(3)>
    Public Property NPOL() As Integer = 3


    ''' <summary>
    ''' Flag to output elemental information (1) or not (0)
    ''' </summary>
    ''' <value>1 (true) recommended</value>
    ''' <returns>1 or 0</returns>
    ''' <remarks></remarks>
    <Description("Flag to output elemental information " & vbCrLf &
                 "(1=Yes or not 0=No, 1 recommended)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(OutputElemental.Yes)>
    Public Property IELOUT() As OutputElemental = OutputElemental.Yes


    ''' <summary>
    ''' Flag to choose the Petrov-Galerkin solution (1, default) or regular finite element (0)
    ''' </summary>
    ''' <value>1 recommended</value>
    ''' <returns>Integer</returns>
    ''' <remarks></remarks>
    <Description("Flag to choose the Petrov-Galerkin solution " & vbCrLf &
                 "(default (1, recom.) or regular (0) finite element")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(1)>
    Public Property KPG() As Integer = 1


    ''' <summary>
    ''' Number of segments with different surface properties (slope or roughness, 1 recommended)
    ''' </summary>
    ''' <value>1 recommended</value>
    ''' <returns>Integer</returns>
    ''' <remarks></remarks>
    <Description("Number of segments with different surface properties" & vbCrLf &
                 "(slope or roughness, 1 recommended)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(1)>
    Public Property NPROP() As Integer = 1


    '    	Manning’s n 	
    'Cover	                 Range	     Average
    'Bare sand	             0.01-0.013	 0.011
    'Bare clay-loam (eroded) 0.012-0.033 0.02
    'Fallow - no residue)	 0.006-0.16  0.05
    'Range (natural)	     0.01-0.32	 0.13
    'Range (natural)	     0.02-0.24	 0.1
    'Grass (bluegrass sod)	 0.39-0.63	 0.45
    'Short grass prairie	 0.10-0.20	 0.15
    'Dense grass (a)	     0.17-0.30	 0.24
    'Bermuda grass	         0.30-0.48	 0.41

    ''' <summary>
    ''' Filter Manning's roughness n for each segment (s/m^3, 0.4 recommended))
    ''' </summary>
    ''' <value>0.4 recommended</value>
    ''' <returns>Decimal</returns>
    ''' <remarks></remarks>
    <Description("Filter Manning's roughness n for each segment" & vbCrLf &
                 "(s/m^3, 0.4 recommended)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0.4)>
    Public Property RNA() As Double = 0.4

#End Region

#Region "User Input"

    <XmlIgnore()>
    Public Property EventDate As Date

    Private m_TITLE As String = "VFSmod"

    ''' <summary>
    ''' A label (max. 50 characters) to identify the program run
    ''' </summary>
    ''' <value>VFSmod</value>
    ''' <returns>String</returns>
    ''' <remarks></remarks>
    <Description("A label to identify the program run" & vbCrLf &
                 "(max. 50 characters)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue("VFSmod")>
    Public Property TITLE() As String
        Get
            Return m_TITLE
        End Get
        Set(vTITLE As String)

            If vTITLE.Length > 49 Then
                m_TITLE = vTITLE.Substring(0, 49)
            Else
                m_TITLE = vTITLE
            End If

        End Set
    End Property


    ''' <summary>
    ''' Buffer width perpendicular to the direction of the flow (m, std. =100)
    ''' </summary>
    ''' <value>Buffer width perpendicular to the direction of the flow (m)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Buffer width perpendicular to the direction of the flow (m)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(100)>
    Public Property FWIDTH() As Double = 100


    ''' <summary>
    ''' Length of the VFS in the direction of flow (m)
    ''' </summary>
    ''' <value>Length of the VFS in the direction of flow (m)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Length of the VFS in the direction of flow (m)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(5)>
    Public Property VL() As Double = 5



    ''' <summary>
    ''' Slope at each segment (mm/mm)
    ''' R1 = 3%, R2-R4 = 5%
    ''' </summary>
    ''' <value>Slope at each segment (mm/mm)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Slope at each segment (mm/mm)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0.05)>
    Public Property SOA() As Double = 0.05

#End Region

    '***** Example ******
    '        R3_5m()
    ' 100
    ' 5   57   .5   .8   350   3   1   1
    ' 1
    ' 5  0.10  0.05
    ' 1
    '-------------------------------------
    '        title()
    '        fwidth()
    ' vl n thetaw cr maxiter npol ielout kpg
    '       nprop()
    ' sx(iprop), rna(iprop), soa(iprop), iprop=1,nprop


    '***** Definition ***** 
    'TITLE	    a label (max. 50 characters) to identify the program run
    'FWIDTH	    width of the strip (m)
    'VL	        length of the filter strip  (m)                                           
    'N	        number of nodes in the domain (integer) (must be an odd number for a quadratic finite element solution, but the program checks and corrects if needed). Default 57
    'THETAW	    time-weight factor for the Crank-Nicholson solution (0.5 recommended)
    'CR	        Courant number for the calculation of time step from 0.5 - 0.8 (recommended). (See Tips on Running the Model Part a)
    'MAXITER	(integer) maximum number of iterations allowed in the Picard loop.                       
    'NPOL	    (integer) number of nodal points over each element (polynomial degree +1) [Recommended value=3] (See Tips on Running the Model Part b)    
    'IELOUT	    (integer) flag to output elemental information (1) or not (0)
    'KPG	    (integer) flag to choose the Petrov-Galerkin solution (1) or regular finite element (0) [Recommended value=1] (See Tips on Running the Model Part b)
    'NPROP	    (integer) number of segments with different surface properties (slope or roughness)
    'SX(I)= VL	(real) X distance from the beginning on the filter, in which the segment of uniform surface properties ends (m).
    'RNA(I)	    Manning’s roughness for each segment (s.m-1/3)
    'SOA(I)	    slope at each segment (unit fraction, i.e. no units)
    'New version  = 1 !

    ''' <summary>
    ''' Resulting 'IKW Overland Flow Inputs' file
    ''' </summary>
    Public ReadOnly Property IKWfile As String()
        Get

            Dim Result As New List(Of String)

            With Result

                .Add(" " & Me.TITLE)
                .Add(" " & Me.FWIDTH.ToString)
                .Add(Join({
                          " " &
                           Me.VL.ToString,
                           Me.N.ToString,
                           Me.THETAW.ToString,
                           Me.CR.ToString,
                           Me.MAXITER.ToString,
                           Me.NPOL.ToString,
                           CInt(Me.IELOUT).ToString,
                           Me.KPG.ToString
                          }))

                .Add(" " & Me.NPROP.ToString)

                .Add(Join({
                          " " &
                           Me.SX.ToString,
                           Me.RNA.ToString,
                           Me.SOA.ToString
                          }))

                'add flag for the new vfsmod version ;-))
                .Add(" " & 1)

                If FullFeat Then

                    .Add("------------------------------------------------------------------")
                    .Add(" " & Me.TITLE & " title, 50 chars max.!")
                    .Add(" " & Me.FWIDTH.ToString.PadLeft(Me.TITLE.Length) & " fwidth, std. = 100m (30m for pond)")

                    .Add(" vl  n thetaw  cr maxiter npol ielout kpg")
                    .Add(Me.VL.ToString.PadLeft(" vl".Length) &
                         Me.N.ToString.PadLeft("  n".Length) &
                         Me.THETAW.ToString.PadLeft(" thetaw".Length) &
                         Me.CR.ToString.PadLeft("  cr".Length) &
                         Me.MAXITER.ToString.PadLeft(" maxiter".Length) &
                         Me.NPOL.ToString.PadLeft(" npol".Length) &
                         Me.IELOUT.ToString.PadLeft(" ielout".Length) &
                         Me.KPG.ToString.PadLeft(" kpg".Length))
                    .Add(" nprop")
                    .Add(Me.NPROP.ToString.PadLeft(" nprop".Length))
                    .Add(" sx(iprop)  rna(iprop)  soa(iprop) ")
                    .Add(" sx=vl!" & Me.SX.ToString.PadLeft("  5".Length) &
                         Me.RNA.ToString.PadLeft("  rna(iprop)".Length) &
                         Me.SOA.ToString.PadLeft("  soa(iprop)".Length))
                    .Add(" Version")
                    .Add("       1")
                    .Add("-------------------------------------")
                    .Add("TITLE      a label (max. 50 characters) to identify the program run")
                    .Add("FWIDTH     width of the strip (m, std. = 100m, 30m for pond)")
                    .Add("VL         length of the filter strip (m), THE mitigation parameter ")
                    .Add("N          number of nodes in the domain (integer) ")
                    .Add("           must be an odd number for a quadratic finite element solution, default 57")
                    .Add("THETAW     time-weight factor for the Crank-Nicholson solution (0.5 recommended)")
                    .Add("CR         Courant number for the calculation of time step from 0.5 - 0.8 (recommended)")
                    .Add("MAXITER    (integer) maximum number of iterations allowed in the Picard loop.                       ")
                    .Add("NPOL       (integer) number of nodal points over each element (polynomial degree +1, recommended value=3)")
                    .Add("IELOUT     (integer) flag to output elemental information (1) or not (0)")
                    .Add("KPG        (integer) flag to choose the Petrov-Galerkin solution (1) or regular finite element (0), recommended value=1")
                    .Add("NPROP      (integer) number of segments with different surface properties (slope or roughness)")
                    .Add("SX(I) = VL (real) X distance from the beginning on the filter")
                    .Add("           in which the segment of uniform surface properties ends (m).")
                    .Add("RNA(I)     (SCENARIO, std  =0.4) Manning’s roughness for each segment (s.m-1/3)")
                    .Add("SOA(I)     (SCENARIO) slope at each segment (unit fraction, i.e. no units)")

                End If

            End With

            Return Result.ToArray

        End Get
    End Property

End Class

''' <summary>
''' ISO Infiltration Soil Properties
''' !!! Event independend !!!
''' </summary>
''' <remarks></remarks>
<DebuggerStepThrough()>
<Serializable()>
<DisplayName("ISO Infiltration Soil Properties")>
Public Class ISO

    Public Sub New()

    End Sub

    Public Sub New(UserInput As ScenarioUserInput,
                   P2TEvent As P2TEvent)

        With UserInput.StdValues

            Me.SM = .SM
            Me.SCHK = .SCHK
            Me.d = .d
            Me.WaterTableDepth = .WaterTableDepth

        End With

        With UserInput.ScenarioProperties

            Me.SAV = .SAV
            Me.Ks = .KS
            Me.ThetaS = .ThetaS

            Me.Alfa = .Alfa
            Me.hmax = .hmax
            Me.ThetaR = .ThetaR
            Me.n = .n

        End With

        Me.ThetaI = P2TEvent.ThetaI
        Me.TWD = P2TEvent.TWD


    End Sub

#Region "User Input"


    ''' <summary>
    ''' Green-Ampt’s average suction at wet front (m)
    ''' </summary>
    ''' <value>Green-Ampt’s average suction at wet front (m)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Suction at the wetting front (m, iso)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0)>
    Public Property SAV() As Double = 0

    ''' <summary>
    ''' Vertical saturated hydraulic conductivity (m/s)
    ''' </summary>
    ''' <value>Vertical saturated hydraulic conductivity (m/s)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Vertical saturated hydraulic conductivity (m/s)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0)>
    Public Property Ks() As Double = 0


    ''' <summary>
    ''' Saturated volumetric water content (m3/m3)
    ''' </summary>
    ''' <value>Saturated volumetric water content (m3/m3)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Saturated volumetric water content (m3/m3)" & vbCrLf &
                "calc: 1 - BulkDensity (g/cm3) / SedBulkDensity (g/cm3)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0)>
    Public Property ThetaS() As Double = 0


    ''' <summary>
    ''' Initial soil water content (m3/m3)
    ''' </summary>
    ''' <value>Initial soil water content (m3/m3)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Initial soil water content (m3/m3)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0)>
    Public Property ThetaI() As Double = 0

#End Region

#Region "Std. Parameters"


    ''' <summary>
    ''' Maximum surface storage (m, default 0)
    ''' </summary>
    ''' <value>Maximum surface storage (m, default 0)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Maximum surface storage" & vbCrLf &
                 "(m, default 0)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0)>
    Public Property SM() As Double = 0


    ''' <summary>
    ''' Relative distance from the upper filter edge
    ''' where the check for ponding conditions is made
    ''' (i.e. 1= end filter, 0.5= mid point, 0= beginning)
    ''' Beginning (0) recommended
    ''' </summary>
    ''' <value>Relative distance from the upper filter edge</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Relative distance from the upper filter edge" & vbCrLf &
                 "where the check for ponding conditions is made" & vbCrLf &
                 "(i.e. 1= end filter, 0.5= mid point, 0= beginning)" & vbCrLf &
                 "Beginning (0) recommended")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0)>
    Public Property SCHK() As Double = 0


    Private m_WaterTableDepth As Boolean = True

    ''' <summary>
    ''' Switch WTD on or off
    ''' </summary>
    ''' <value>true</value>
    <Description("Water Table Depth" & vbCrLf &
                 "on = true (std) or off = false")>
    <Browsable(True)>
    <DisplayName("Water Table Depth")>
    <[ReadOnly](False)>
    <DefaultValue(2.22)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property WaterTableDepth() As Boolean
        Get
            Return m_WaterTableDepth
        End Get
        Set(value As Boolean)
            m_WaterTableDepth = value
        End Set
    End Property


    Private m_d As Double = 0.3

    ''' <summary>
    ''' Overboard, distance to the top of the canal
    ''' at maximum stage to avoid flooding, std. 0.3m, iso 
    ''' </summary>
    ''' <value>0.3</value>
    ''' <returns>Double</returns>
    ''' <remarks>Water table depth parameter</remarks>
    <Description("Overboard, distance to the top of the canal" & vbCrLf &
                 "in meter at maximum stage to avoid flooding, std. 0.3m, iso")>
    <Browsable(True)>
    <DisplayName("d")>
    <[ReadOnly](False)>
    <DefaultValue(0.3)>
    <RefreshProperties(RefreshProperties.All)>
    Public Property d() As Double
        Get
            Return m_d
        End Get
        Set(value As Double)
            m_d = value
        End Set
    End Property


    ''' <summary>
    ''' water table depth (m)
    ''' </summary>
    ''' <returns></returns>
    <Description("TOXSWA water depth (m)")>
    Public Property TWD As Double = 0

    Public Enum eITHETA_KUNS_TYPE
        vanGenuchten = 1
        BrooksAndCorey = 2
        Gardners = 3
    End Enum

    ''' <summary>
    ''' unsaturated hydraulic conductivity curve type
    ''' </summary>
    ''' <returns></returns>
    <Description("Soil water characteristic curve type" & vbCrLf &
                 "1 = van Genuchten (std), 2 = Brooks and Corey and 3 = Gardner’s")>
    <DefaultValue(CInt(eITHETA_KUNS_TYPE.BrooksAndCorey))>
    Public ReadOnly Property ITHETATYPE As eITHETA_KUNS_TYPE = eITHETA_KUNS_TYPE.vanGenuchten

    ''' <summary>
    ''' unsaturated hydraulic conductivity curve type
    ''' </summary>
    ''' <returns></returns>
    <Description("Unsaturated hydraulic conductivity curve type" & vbCrLf &
                 "1 = van Genuchten (std), 2= Brooks and Corey and 3 = Gardner’")>
    <DefaultValue(CInt(eITHETA_KUNS_TYPE.BrooksAndCorey))>
    Public ReadOnly Property IKUNSTYPE As eITHETA_KUNS_TYPE = eITHETA_KUNS_TYPE.vanGenuchten

    <DefaultValue(1)>
    <Browsable(False)>
    Public ReadOnly Property ITWBC As Integer = 1

    <DefaultValue(1)>
    <Browsable(False)>
    Public ReadOnly Property RVH As Integer = 1

#End Region

#Region "WTD"


    ''' <summary>
    ''' Max water height in stream in m (std.~ 0.709m) , iso
    ''' Taken from presentation from Robin
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Max water height in stream in m (std.~ 0.709m) , iso")>
    Public Property hmax As Double

    ''' <summary>
    ''' Theta r, van Genuchten parameter , iso
    ''' Taken from Hypres
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Theta r, van Genuchten parameter , iso")>
    Public Property ThetaR As Double


    ''' <summary>
    ''' van Genuchten Alpha, parameter of the soil water retention curve , iso
    ''' Taken from Hypres
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Alpha, van Genuchten parameter , iso")>
    Public Property Alfa As Double

    ''' <summary>
    ''' n, van Genuchten parameter , iso
    ''' Taken from Hypres
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("n, van Genuchten parameter , iso")>
    Public Property n As Double

    ''' <summary>
    ''' m, van Genuchten parameter , iso
    ''' Taken from Hypres
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("m, van Genuchten parameter = 1-(1/n) , iso")>
    Public ReadOnly Property m As Double
        Get
            Try

                If n = 0 Then
                    Return 0
                Else
                    Return 1 - (1 / n)
                End If

            Catch ex As Exception
                Return -1
            End Try
        End Get
    End Property


#End Region


    '***** Example ******
    ' 1.33e-6  0.62  0.44905  0.37  .01   0
    '-------------------------------------
    ' Ks(m/s)   Sav(m)  Theta-s   Theta-i   Sm(m)   Schk(ponding ck)


    '***** Definition ***** 
    'Ks	        saturated hydraulic conductivity, Ks (m/s)
    'SAV        Green - Ampt's average suction at wet front(m)
    'Theta-s	saturated soil-water content,  (m3/m3)
    'Theta-i	initial soil-water content,  (m3/m3)
    'SM	        maximum surface storage (m)                                       
    'SCHK	    relative distance from de upper filter edge where 
    '           the check for ponding conditions is made 
    '           (i.e. 1= end filter, 0.5= mid point, 0= beginning)

    ''' <summary>
    ''' Resulting 'ISO Infiltration Soil Properties' file
    ''' </summary>
    Public ReadOnly Property ISOfile As String()
        Get

            Dim Result As New List(Of String)

            Dim WTD As Double = Double.NaN

            With Result

                .Add(Join({
                          " " &
                           Me.Ks.ToString.PadLeft("Scenario".Length),
                           Me.SAV.ToString.PadLeft("Scenario".Length),
                           Me.ThetaS.ToString.PadLeft("Scenario".Length),
                           Me.ThetaI.ToString.PadLeft(" Matrix".Length),
                           Me.SM.ToString.PadLeft("Sm(m)".Length),
                           Me.SCHK.ToString.PadLeft("Schk(ponding ck)".Length)
                          }))

                If Me.WaterTableDepth Then

                    WTD = Me.hmax + Me.d - Me.TWD
                    If WTD < 0 Then WTD = 0

                    .Add(" " & WTD.ToString.PadLeft("Scenario".Length))

                    .Add(Join({
                        " " &
                        CInt(Me.ITHETATYPE).ToString.PadLeft("Scenario".Length),
                        Me.ThetaR.ToString.PadLeft("Scenario".Length),
                        Me.Alfa.ToString.PadLeft("Scenario".Length),
                        Me.n.ToString.PadLeft(" Matrix".Length) & "    ",
                        Me.m.ToString("G5").PadLeft("Sm(m)".Length)
                        }))

                    .Add(" " & CInt(Me.IKUNSTYPE).ToString.PadLeft("Scenario".Length) &
                        Me.m.ToString("G5").PadLeft("Scenario".Length))
                    .Add(" " & Me.ITWBC.ToString.PadLeft("Scenario".Length) &
                        Me.RVH.ToString.PadLeft("Scenario".Length))

                End If

                .Add(" ")

                If FullFeat Then
                    .Add("------------------------------------------------------------------")
                    .Add("  Ks(m/s)   Sav(m)  Theta-s Theta-i Sm(m) Schk(ponding ck)")
                    .Add(" Scenario Scenario Scenario  Matrix" & Me.SM.ToString.PadLeft(" Sm(m)".Length) &
                                                                 Me.SCHK.ToString.PadLeft(" Schk(ponding ck)".Length))

                    .Add(" WTD")

                    .Add(Join({
                        "ITHETTYPE".ToString.PadLeft("Scenario".Length),
                        "ThetaR".ToString.PadLeft("Scenario".Length),
                        "Alfa".ToString.PadLeft("Scenario".Length),
                        "n".ToString.PadLeft(" Matrix".Length) & "    ",
                        "m".ToString.PadLeft("Sm(m)".Length)
                        }))

                    .Add("IKUNSTYPE".ToString.PadLeft("Scenario".Length) &
                      "m".ToString.PadLeft("Scenario".Length))
                    .Add(" " & "ITWBC".ToString.PadLeft("Scenario".Length) &
                        "RVH".ToString.PadLeft("Scenario".Length))

                    .Add("")
                    .Add(" Ks         saturated hydraulic conductivity (m/s, Scenario)")
                    .Add(" SAV        (Green - Ampt) 's average suction at wet front (m, Scenario)")
                    .Add(" Theta-s    saturated soil-water content,  (m3/m3, Scenario)")
                    .Add(" Theta-i    initial soil-water content (m3/m3, from data matrix)")
                    .Add(" SM         maximum surface storage (m, std. 0m)")
                    .Add(" SCHK       relative distance from the upper filter edge where")
                    .Add("            the check for ponding conditions is made ")
                    .Add("            (i.e. 1= end filter, 0.5= mid point, 0= beginning)")
                    .Add("            std. = 0.5 (mid point)")

                    .Add("Water table depth")
                    .Add("TOXSWA depth = " & Me.TWD & " m, data matrix")
                    .Add("Overboard d  = " & Me.d & " m, std. value")
                    .Add("h max        = " & Me.hmax & " m, Scenario")
                    .Add("WTD = hmax + d - TXW water depth = " &
                         hmax & " + " & d & " - " & TWD & " = " & (Me.hmax + Me.d - Me.TWD))
                    If (Me.hmax + Me.d - Me.TWD) < 0 Then
                        .Add("WTD < 0, set to 0!")
                    End If


                    .Add("ITHETATYPE  an integer to select the soil water characteristic curve type with values")
                    .Add("            1 = van Genuchten (std), 2 = Brooks and Corey and 3 = Gardner’s")
                    .Add("   van Genuchten ThetaR")
                    .Add("   van Genuchten Alfa")
                    .Add("   van Genuchten n")
                    .Add("   van Genuchten m")
                    .Add("IKUNSTYPE   select the unsaturated hydraulic conductivity curve type")
                    .Add("            1 = van Genuchten (std), 2 = Brooks and Corey and 3 = Gardner’s")
                    .Add("   van Genuchten m")
                    .Add("ITWBC        lower boundary conditions, std  = 1 Dupuis Forchheimer")
                    .Add("RVH          Ksh/ks ratio of horizontal to vertical conductivity, std. = 1")

                End If

            End With

            Return Result.ToArray

        End Get
    End Property

End Class

''' <summary>
''' IGR Buffer Vegetation Characteristics
''' !!! Event independend !!!
''' </summary>
''' <remarks></remarks>
<DebuggerStepThrough()>
<Serializable()>
Public Class IGR

    Public Sub New()

    End Sub

    Public Sub New(UserInput As ScenarioUserInput)

        With UserInput.StdValues

            Me.SS = .SS
            Me.VN = .VN
            Me.H = .H
            Me.VN2 = .VN2

        End With

    End Sub

#Region "Std. Parameters"


    ''' <summary>
    ''' Average spacing of grass stems (cm, std. = 1.63cm)
    ''' </summary>
    ''' <value>Spacing of the filter media elements (cm)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Average spacing Of grass stems (cm, std. = 1.63cm)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(1.63)>
    Public Property SS() As Double = 1.63

    ''' <summary>
    ''' Grass modified Manning’s n (s/cm^3, std. = 0.012)
    ''' </summary>
    ''' <value>Grass modified Manning’s n (s/cm^3, std. = 0.012)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Grass modified Manning's n (s/cm^3, std. = 0.012)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0.012)>
    Public Property VN() As Double = 0.012

    ''' <summary>
    ''' Filter grass height (cm, std. = 10cm)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Filter grass height (cm, std. = 10cm)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(10)>
    Public Property H() As Double = 10

    ''' <summary>
    ''' Bare surface Manning’s n for sediment inundated area in grass filter (s/cm^3, std. = 0.05)
    ''' </summary>
    ''' <value>Bare surface Manning’s n for sediment inundated area in grass filter (s/cm^3, std. = 0.05)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Bare surface Manning’s n for sediment" & vbCrLf &
                 "inundated area in grass filter (s/cm^3, std. = 0.05)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0.05)>
    Public Property VN2() As Double = 0.05

    ''' <summary>
    ''' Flag to feedback the change in slope and surface roughness at the sediment wedge for each time step
    ''' default no feedback = 0 
    ''' </summary>
    ''' <value></value>
    ''' <returns>Enum eICOFlag</returns>
    ''' <remarks></remarks>
    <Description("Flag to feedback the change in slope and " & vbCrLf &
                 "roughness at the sediment wedge for each time step, std. = NoFeedback")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(eICOFlag.NoFeedback)>
    Public Property ICO() As eICOFlag = eICOFlag.NoFeedback

#End Region

    '***** Example ******
    ' 1.5  0.012  13  0.10  0
    '-------------------------------------
    ' SS(cm)  Vn(s/cm^1/3)  H(cm)  Vn2(s/m^1/3)  ICO(0 or 1)


    '***** Definition ***** 
    'SS	            spacing of the filter media elements (cm)
    'VN 	        filter media (grass) Manning's nm (0.012 for cylindrical media) (s.cm-1/3)
    'H 	            filter media height (cm)
    'VN2 =IKW RNA	bare surface Manning's n for sediment inundated area and overland flow (s.m-1/3)
    'ICO 	        (integer) flag to feedback the change in slope and surface roughness at the 
    '                sediment wedge for each time step (0= no feedback; 1= feedback) 
    '               (See Tips on Running the Model Part f)

    ''' <summary>
    ''' Resulting 'IGR Buffer Vegetation Characteristics' file
    ''' </summary>
    Public ReadOnly Property IGRfile As String()
        Get

            Dim Result As New List(Of String)

            With Result

                .Add(Join({
                         Me.SS.ToString.PadLeft(" SS(cm)".Length) &
                         Me.VN.ToString.PadLeft("  Vn(s/cm^1/3)".Length) &
                         Me.H.ToString.PadLeft("  H(cm)".Length) &
                         Me.VN2.ToString.PadLeft("  Vn2(s/m^1/3)".Length) &
                         CInt(Me.ICO).ToString.PadLeft("  ICO(0 or 1)".Length)
                          }))

                If FullFeat Then
                    .Add("------------------------------------------------------------------")
                    .Add(" SS(cm)  Vn(s/cm^1/3)  H(cm)  Vn2(s/m^1/3)  ICO(0 or 1)")
                    .Add(" SS   spacing of the filter media elements (cm, std.=1.63cm)")
                    .Add(" VN   filter media (grass) Manning's nm (0.012 for cylindrical media) (s*cm-1/3)")
                    .Add(" H    filter media height (cm, std.=10cm)")
                    .Add(" VN2 = IKW RNA std. = 0.05 s*m-1/3 bare surface Manning's n for sediment inundated area and overland flow (s*m-1/3)")
                    .Add(" ICO  (integer) flag to feedback the change in slope and surface roughness at the sediment wedge")
                    .Add("      for each time step (0= no feedback; 1= feedback, std.=0)")

                End If

            End With

            Return Result.ToArray

        End Get
    End Property

End Class

''' <summary>
''' ISD Incomming Sediment Characteristics
''' </summary>
''' <remarks></remarks>
<DebuggerStepThrough()>
<Serializable()>
Public Class ISD

#Region "Constructors"

    Public Sub New()

    End Sub

    Public Sub New(UserInput As ScenarioUserInput,
                   P2TEvent As P2TEvent)

        With UserInput.StdValues

            Me.COARSE = .COARSE
            Me.DP = .DP

        End With

        Me.RHO = UserInput.ScenarioProperties.RHO
        Me.CI = P2TEvent.SedimentConcentration

    End Sub

#End Region

#Region "Std. Parameters"

    ''' <summary>
    '''Incoming sediment particle class according to the USDA (1975) particle classes
    ''' </summary>
    ''' <value>
    ''' Incoming sediment particle class according to the 
    ''' USDA (1975) particle classes std. = 7 (UserSelected)
    ''' </value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Incoming sediment particle class according" & vbCrLf &
                 "to the USDA (1975) particle classes")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(eSedimentparticleClass.UserSelected)>
    Public Property NPART() As eSedimentparticleClass = eSedimentparticleClass.UserSelected

    ''' <summary>
    ''' Fraction of particles from incoming sediment with diameter > 0.0037 cm
    ''' </summary>
    ''' <value>
    ''' Fraction of particles from incoming sediment with diameter > 0.0037 cm
    ''' std. = 0.4
    ''' </value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Fraction of particles from incoming" & vbCrLf &
                 "sediment with diameter > 0.0037 cm, std. = 0.4")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0.4)>
    Public Property COARSE() As Double = 0.4

    <XmlIgnore()>
    <Browsable(False)>
    Private Property RHO As Double

    ''' <summary>
    ''' Porosity of deposited sediment (fraction)
    ''' Calc: 1 - (BulkDensity/Sed. BulkDensity)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Porosity of deposited sediment (fraction) " & vbCrLf &
                 "Calc: 1 - (BulkDensity/Sed. BulkDensity)")>
    <Browsable(True)>
    <[ReadOnly](True)>
    Public ReadOnly Property POR() As Double
        Get
            Try
                Return 1 - (Me.RHO / Me.SG)
            Catch ex As Exception
                Throw New Exception("Can't calc. porosity of deposited sediment " & vbCrLf &
                                    "POR = 1 - (BulkDensity/Sed. BulkDensity)" & vbCrLf &
                                    "BulkDensity     = " & Me.RHO & vbCrLf &
                                    "Sed. part. size = " & Me.SG & vbCrLf & ex.Message)
            End Try

        End Get
    End Property

    ''' <summary>
    ''' Sediment particle size, diameter, d50 (cm), read only if NPART = 7
    ''' Default 0.0001
    ''' </summary>
    ''' <value></value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Sediment particle size, diameter, d50 (cm)" & vbCrLf &
                 "read only if NPART = 7 (std), default 0.0001")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(0.0001)>
    Public Property DP() As Double = 0.0001


    ''' <summary>
    ''' Sediment particle density, (g/cm3), read only if NPART = 7 
    ''' Default 2.65 g/cm3
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Sediment particle density, (g/cm3)" & vbCrLf & _
                 "read only if NPART = 7 (std), default 2.65 g/cm3")> _
    <Browsable(True)> _
    <[ReadOnly](False)> _
    <DefaultValue(2.65)>
    Public Property SG() As Double = 2.65



#End Region

#Region "From P2T DATA"

    ''' <summary>
    ''' Sed. concentration (g/cm3) = ErosionMass /( RunoffVolume * FieldArea * 10000)
    ''' </summary>
    ''' <value>Sed. concentration (g/cm3) = ErosionMass /( RunoffVolume * FieldArea * 10000)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Sed. concentration (g/cm3)" & vbCrLf &
                 "Sed. concentration = ErosionMass /( RunoffVolume * FieldArea * 10000)")>
    <Browsable(True)>
    <[ReadOnly](True)>
    <XmlIgnore()>
    Public Property CI() As Double

#End Region

    'NPART
    '   Particle cl.	Diam. range (cm) dp (cm)    Vf (cm/s)	ñs (cm3/s)
    '1	Clay	     <0.0002	         0.0002	    0.0004	    2.6
    '2	Silt (1)      0.0002 - 0.005	 0.001	    0.0094	    2.65
    '3	Small agg	   ----	             0.003	    0.0408	    1.8
    '4	Large agg	   ----	             0.03	    3.0625	    1.6
    '5	Sand	      0.0050 - 0.2	     0.02	    3.7431	    2.65
    '6	Silt (2)      0.0002 - 0.005	 0.0029	    0.0076	    2.65
    '7	User selected  ----	             DP	        model	    SG

    '***** Example ******
    ' 7  0.23  0.000194  0.45       Npart, Coarse, Ci(g/cm3), Por  
    ' 0.0001  2.65           Dp(cm), SG(g/cm3)

    '***** Definition ***** 
    'NPART          (integer) incoming sediment particle class according to the USDA (1975) particle classes:
    'COARSE = Sand	% of particles from incoming sediment with diameter > 0.0037 cm std. = 0.4 '
    '               (coarse fraction that will be routed through wedge) (unit fraction, i.e. 100% = 1.0).
    'CI	            Incoming flow sediment concentration (g/cm3)
    'POR	        Porosity of deposited sediment (unit fraction, i.e. 43.4% = 0.434)  1 - BulkDensity/Sed.BulkDensity)
    'DP	            Sediment particle size, diameter, d50 (cm), read only if NPART=7 Default 0.0001
    'SG	            Sediment particle density, (g/cm3), read only if NPART=7 Default 2.65 g/cm3

    ''' <summary>
    ''' Resulting 'ISD Incomming Sediment Characteristics' file
    ''' </summary>
    Public ReadOnly Property ISDfile As String()
        Get

            Dim Result As New List(Of String)

            With Result

                .Add(Join({
                          " " &
                           CInt(Me.NPART).ToString,
                           Me.COARSE.ToString,
                           NumberFormat(Me.CI, Digits, Scientific:=True),
                           NumberFormat(Me.POR, Digits, Scientific:=True)
                          }))

                If FullFeat Then
                    Result(.Count - 1) &= "   Npart, COARSE, CI, Por "
                End If

                .Add(Join({
                          " " &
                           Me.DP.ToString,
                           Me.SG.ToString
                          }))
                If FullFeat Then
                    Result(.Count - 1) &= "   DP, SG "
                    .Add("------------------------------------------------------------------")
                    .Add("NPART   (integer) incoming sediment particle class according to the USDA (1975) particle classes:")
                    .Add("COARSE  % of particles from incoming sediment with diameter > 0.0037 cm std. = 0.4 '")
                    .Add("        (coarse fraction that will be routed through wedge) (unit fraction, i.e. 100% = 1.0).")
                    .Add("CI      Incoming flow sediment concentration (g/cm3)")
                    .Add("POR     Porosity of deposited sediment (unit fraction, i.e. 43.4% = 0.434)  1 - BulkDensity/Sed.BulkDensity)")
                    .Add("DP      Sediment particle size, diameter, d50 (cm), read only if NPART=7 Default 0.0002")
                    .Add("SG      Sediment particle density, (g/cm3), read only if NPART=7 Default 2.65 g/cm3")
                End If

            End With

            Return Result.ToArray

        End Get
    End Property

End Class

''' <summary>
''' IRN Storm Hyetograph
''' </summary>
''' <remarks></remarks>
<DebuggerStepThrough()>
<Serializable()>
Public Class IRN

    Public Sub New()

    End Sub

    Public Sub New(P2TEvent As P2TEvent)

        Me.P2TEvent = P2TEvent

        With P2TEvent

            Me.RPEAK = .RainfallRate
            Me.EventEndTime = .EventEndTime

        End With

    End Sub

#Region "Properties"

    <XmlIgnore()>
    <Browsable(False)>
    Public Property P2TEvent As New P2TEvent


    ''' <summary>
    ''' Number of rainfall periods including period to end simulation
    ''' Default 2
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Number of rainfall periods including period to end simulation " & vbCrLf &
                 "Default 2")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DefaultValue(2)>
    Public Property NRAIN() As Integer = 2


    ''' <summary>
    ''' Rainfall rate (m/s) = Prec. /1000/(Duration * 3600)
    ''' </summary>
    ''' <value>Rainfall rate (m/s) = Prec. /1000/(Duration * 3600)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Rainfall rate (m/s)" & vbCrLf &
                 "Prec. /1000/(Duration * 3600)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DisplayName("Rainfall rate (m/s)")>
    <DefaultValue(0)>
    Public Property RPEAK() As Double



    ''' <summary>
    ''' Event end time = Event duration * 3600 (s)
    ''' </summary>
    ''' <value> Event end time = Event duration * 3600 (s)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Event end time (s)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DisplayName("Event end time (s)")>
    <DefaultValue(0)>
    Public Property EventEndTime() As Double

#End Region

    ''' <summary>
    ''' Resulting 'IRN Storm Hyetograph' file
    ''' </summary>
    Public ReadOnly Property IRNfile As String()
        Get

            Dim Result As New List(Of String)

            With Result

                .Add(Join({
                          " " &
                           Me.NRAIN.ToString.PadLeft(Me.EventEndTime.ToString.Length),
                           NumberFormat(Me.RPEAK, Digits, Scientific:=True)
                          }))

                If FullFeat Then
                    Result(.Count - 1) &= "       Nrain, Rpeak (m/s)"
                End If

                .Add(Join({
                          " " &
                           0.ToString.PadLeft(Me.EventEndTime.ToString.Length),
                          NumberFormat(Me.RPEAK, Digits, Scientific:=True)
                          }))

                .Add(Join({
                         " " &
                          Me.EventEndTime.ToString,
                          NumberFormat(Me.RPEAK, Digits, Scientific:=True)
                         }))

                If FullFeat Then

                    Result(.Count - 1) &= "       (" & Me.P2TEvent.EventDuration & " * 3600s)"
                    .Add("------------------------------------------------------------------")
                    .Add(" NRAIN      (integer) number of rainfall periods including period to end simulation Default 2")
                    .Add(" RPEAK      maximum rainfall intensity for the storm (m/s)")
                    .Add(" RAIN(I,J)  time (s) and rainfall rate o intensity (m/s) ")
                    .Add("            over the VFS for each period. The last time step corresponds with the desired simulation")
                    .Add("            time chosen by the user (typically coupled with a rainfall intensity of 0)")

                    .Add(" Rpeak (m/s) = Rainfall rate = PRCP (mm) / 1000 / (Duration * 3600)")
                    .Add(" Te          = End time (s)  = Duration * 3600")

                End If

            End With

            Return Result.ToArray

        End Get
    End Property

End Class

''' <summary>
''' IRO Storm Runoff Hydrograph
''' </summary>
''' <remarks></remarks>
<DebuggerStepThrough()>
<Serializable()>
Public Class IRO

    Public Sub New()

    End Sub

    Public Sub New(UserInput As ScenarioUserInput,
                   P2TEvent As P2TEvent,
          Optional SaveRun As Boolean = False)

        Me.P2TEvent = P2TEvent

        If SaveRun Then
            Me.HydrographShape = StdProperties.eShape.Triangle
        Else
            Me.HydrographShape = UserInput.StdValues.HydrographShape
        End If



        With P2TEvent
            Me.EventEndTime = .EventEndTime
            Me.TrianglePeakTime = .TrianglePeakTime
        End With

        'ToDo Pond??
        If UserInput.StdValues.WaterBody = eRWB.Pond Then

            Me.SLENGTH = 30
            Me.SWIDTH = 150

        Else

            Me.SLENGTH = 100
            Me.SWIDTH = 100

        End If

    End Sub

#Region "Properties"

    <XmlIgnore()>
    <Browsable(False)>
    Public Property P2TEvent As New P2TEvent

    <Browsable(True)>
    <[ReadOnly](False)>
    <RefreshProperties(RefreshProperties.All)>
    <DefaultValue(StdProperties.eShape.Rectangle)>
    Public Property HydrographShape As StdProperties.eShape = StdProperties.eShape.Rectangle

    ''' <summary>
    ''' Event end time = Event duration * 3600 (s)
    ''' </summary>
    ''' <value> Event end time = Event duration * 3600 (s)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Event end time (s)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DisplayName("Event end time (s)")>
    <DefaultValue(0)>
    Public Property EventEndTime() As Double = 0

    ''' <summary>
    ''' Triangle Peak Time = Event duration * 3600 (s) / 2.67
    ''' </summary>
    ''' <value> Triangle Peak Time = Event duration * 3600 (s) / 2.67</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Triangle peak time (s)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DisplayName("Triangle peak time (s)")>
    <DefaultValue(0)>
    Public Property TrianglePeakTime() As Double = 0


    ''' <summary>
    ''' Source area width (std. 100, m)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Source area width" & vbCrLf &
                 "(m, std. 100)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DisplayName("Source area width (m)")>
    <DefaultValue(100)>
    Public Property SWIDTH As Double = 100

    ''' <summary>
    ''' Source area width (std. 100, m)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Source area flow path length" & vbCrLf &
                 "(m, std. 100)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DisplayName("Source area length (m)")>
    <DefaultValue(100)>
    Public Property SLENGTH As Double = 100

    ''' <summary>
    ''' Number of time steps of the incoming field hydrograph
    ''' Rectangle = 2, Triangle = 3
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Number of time steps of the incoming field hydrograph" & vbCrLf &
                 "Rectangle = 2, Triangle = 3")>
    <Browsable(True)>
    <[ReadOnly](True)>
    <DefaultValue(2)>
    <RefreshProperties(RefreshProperties.All)>
    Public ReadOnly Property NBCROFF() As Integer
        Get
            Return Me.HydrographShape
        End Get
    End Property

    Private m_BCROPEAK As Double = 0

    ''' <summary>
    ''' Peak flow of the incoming field hydrograph (m3/s)
    ''' = RunoffVolume (mm / h) * A (ha) / 360
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Peak flow of the incoming field hydrograph (m3/s)" & vbCrLf &
                 "Rec = RunoffVolume (mm / h) * A (ha) / 360; Tri = Rec/2")>
    <Browsable(True)>
    <[ReadOnly](False)>
    Public ReadOnly Property BCROPEAK As Double
        Get

            If Me.HydrographShape = StdProperties.eShape.Rectangle Then
                Return P2TEvent.PeakRunoffRateRec
            Else
                Return P2TEvent.PeakRunoffRateTri

            End If

        End Get
    End Property

#End Region


    ''' <summary>
    ''' Resulting 'IRO Storm Runoff Hydrograph' file
    ''' </summary>
    Public ReadOnly Property IROfile As String()
        Get

            Dim Result As New List(Of String)

            With Result

                .Add(Join({
                           " " &
                               Me.SWIDTH.ToString,
                               Me.SLENGTH.ToString
                           }))

                If FullFeat Then
                    Result(.Count - 1) &= "                Swidth(m), Slength(m)"
                End If

                If Me.HydrographShape = StdProperties.eShape.Rectangle Then

                    'shape = rectangle
                    'always 2 events

                    '100 100       Swidth(m), Slength(m)
                    '    2 5.5694E-03       nbcroff, bcropeak(m3/s)      
                    '    0 5.5694E-03  
                    '86400 5.5694E-03       (24 * 3600s) 
                    '------------------------------------------------------------------ 

                    .Add(Join({
                                " " &
                                    Me.NBCROFF.ToString.PadLeft(Me.EventEndTime.ToString.Length),
                                    NumberFormat(Me.BCROPEAK, Digits, Scientific:=True)
                                }))

                    If FullFeat Then
                        Result(.Count - 1) &= "       nbcroff, bcropeak(m3/s)"
                    End If

                    .Add(Join({
                              " " &
                               0.ToString.PadLeft(Me.EventEndTime.ToString.Length),
                              NumberFormat(Me.BCROPEAK, Digits, Scientific:=True)
                              }))

                    .Add(Join({
                             " " &
                              Me.EventEndTime.ToString,
                              NumberFormat(Me.BCROPEAK, Digits, Scientific:=True)
                             }))

                Else

                    'shape = triangle
                    'always 3 events
                    'triangle peak: bcropeak  =2*bcropeak_rec
                    'triangle peak time = end time /2.67

                    '100 100       Swidth(m), Slength(m)      
                    '    3 1.1139E-02       nbcroff, bcropeak(m3/s)      
                    '    0 0  
                    '32360 1.1139E-02  
                    '86400 0                (24 * 3600s) 
                    '------------------------------------------------------------------

                    .Add(Join({
                               " " &
                                   Me.NBCROFF.ToString.PadLeft(Me.TrianglePeakTime.ToString.Length),
                                   NumberFormat(Me.BCROPEAK, Digits, Scientific:=True)
                               }))

                    If FullFeat Then
                        Result(.Count - 1) &= "       nbcroff, bcropeak(m3/s)"
                    End If

                    .Add(" " & 0.ToString.PadLeft(Me.TrianglePeakTime.ToString.Length) & " 0")

                    '.Add(Join({
                    '          " " &
                    '           0.ToString.PadLeft(Me.EventEndTime.ToString.Length),
                    '          NumberFormat(Me.BCROPEAK, Digits, Scientific:=True)
                    '          }))


                    .Add(Join({
                             " " &
                              Me.TrianglePeakTime.ToString,
                              NumberFormat(Me.BCROPEAK, Digits, Scientific:=True)
                             }))

                    If FullFeat Then
                        Result(.Count - 1) &= "       (" & Me.P2TEvent.EventDuration & " * 3600s / 2.67)"
                    End If


                    .Add(Join({
                             " " &
                              Me.EventEndTime.ToString,
                              "0"
                             }))




                End If
                If FullFeat Then
                    Result(.Count - 1) &= "                (" & Me.P2TEvent.EventDuration & " * 3600s)"

                    .Add("------------------------------------------------------------------")

                    .Add(" SWIDTH      Source area width (m)")
                    .Add(" SLENGTH     Source area flow path length (m)")
                    .Add(" NBCROFF     (integer) number of time steps of the incoming field hydrograph Default")
                    .Add("                            2 = rectangle; 3 = triangle")
                    .Add(" BCROPEAK    peak flow of the incoming field hydrograph (m3/s)")
                    .Add(" BCROFF(I,J) incoming field hydrograph: flow rate, time (s) vs. qin(m3/s).")

                    .Add(" ** Rectangle **")
                    .Add(" BCROPEAK(m3/s) = Peak Runoff rate = [RunoffVolume (mm/h) * (1 m/1000mm) * (1h/3600 sec)] * [A(ha) * (10000 m2/ha)]")
                    .Add(" BCROPEAK(m3/s) = RunoffVolume(mm/h) * A(ha) / 360")
                    .Add(" Te             = End time (s) = Duration * 3600")
                    .Add(" ** Triangle **")
                    .Add(" BCROPEAK_Rectangle(m3/s) * 2")
                    .Add(" Te             = Te_Rectangle / 2.67")

                End If

            End With

            Return Result.ToArray

        End Get
    End Property

End Class

''' <summary>
''' IWQ Water quality/transport submodel
''' </summary>
''' <remarks></remarks>
<DebuggerStepThrough()>
<Serializable()>
Public Class IWQ

    Public Sub New()

    End Sub

    Public Sub New(UserInput As ScenarioUserInput,
                   P2TEvent As P2TEvent)

        With UserInput

            Me.Kd = .CompoundProperties.Kd
            Me.dgHalfL = .CompoundProperties.DT50
            Me.FC = .ScenarioProperties.FC
            Me.PCTC = .ScenarioProperties.PCTC
            Me.FOCUSScenario = .ScenarioProperties.FOCUSScenario
            Me.dgML = .StdValues.dgML

            With .StdValues

                Me.IWQPRO = .IWQPRO

                If Me.IWQPRO = StdProperties.eIWQPRO.Sabbagh_refitted Then

                    Me.CSAB1 = .CSAB1
                    Me.CSAB2 = .CSAB2
                    Me.CSAB3 = .CSAB3
                    Me.CSAB4 = .CSAB4

                End If

            End With



        End With

        Me.ndgday = P2TEvent.Days2NextEvent
        Me.EventDate = P2TEvent.EventDate

    End Sub

#Region "Properties"

    <XmlIgnore()>
    <Browsable(False)>
    Public Property dgPinDescription As New List(Of String)

    ''' <summary>
    ''' Percentage clay in sediment in % , iso
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <Description("Clay in sediment in % , iso and iwq")>
    Public Property PCTC As Double

    ''' <summary>
    ''' Adsorption Kd (ml/g)
    ''' </summary>
    ''' <value>Adsorption Kd (ml/g)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Adsorption Kd (ml/g)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DisplayName("Kd (mL/g)")>
    <DefaultValue(0)>
    Public Property Kd() As Double

    ''' <summary>
    ''' Days to the previous event
    ''' </summary>
    ''' <value>Days to the previous event</value>
    ''' <returns>Integer</returns>
    ''' <remarks></remarks>
    <Description("Days to the previous event")>
    <Browsable(True)>
    <[ReadOnly](True)>
    <DisplayName("Days to prev. event")>
    <DefaultValue(0)>
    Public Property ndgday As Integer

    ''' <summary>
    ''' Date of the event
    ''' </summary>
    ''' <value>Date of the event</value>
    ''' <returns>Date</returns>
    ''' <remarks></remarks>
    <Description("Date of the event")>
    <Browsable(True)>
    <[ReadOnly](True)>
    <DisplayName("Date of the event")>
    <XmlIgnore()>
    Public Property EventDate() As Date

    ''' <summary>
    ''' FOCUS Scenario R1-R4
    ''' </summary>
    ''' <value>FOCUS Scenario R1-R4</value>
    ''' <returns>Enum eSoilSeries</returns>
    ''' <remarks></remarks>
    <Description("FOCUS Scenario R1-R4")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DisplayName("FOCUS Scenario R1-R4")>
    <XmlIgnore()>
    Public Property FOCUSScenario() As eFOCUSScenarios

    ''' <summary>
    ''' dgHalfL, pesticide half-life (days, at reference values of T and θ)
    ''' </summary>
    ''' <value>Pesticide half-life (days, at reference values of T and θ)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Pesticide half-life (d)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DisplayName("Pesticide half-life (d)")>
    <DefaultValue(0)>
    Public Property dgHalfL As Double


    ''' <summary>
    ''' FC, Top soil field capacity (m^3/m^3)
    ''' </summary>
    ''' <value>
    ''' This can be taken from EU FOCUS R1-R4
    ''' scenario parameters used by the PRZM model
    ''' </value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Top soil field capacity (m^3/m^3)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DisplayName("Field capacity (m^3/m^3)")>
    <DefaultValue(0)>
    Public Property FC As Double

    ''' <summary>
    ''' Pin, pesticide mass entering filter (μg/L)
    ''' </summary>
    ''' <value>Pin, pesticide mass entering filter (μg/L)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Pesticide mass entering (μg/L)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DisplayName("Pesticide mass entering (μg/L)")>
    <DefaultValue(0)>
    Public Property dgPin As Double

    ''' <summary>
    ''' Surface mixing layer thickness (cm)
    ''' </summary>
    ''' <value>Surface mixing layer thickness (cm)</value>
    ''' <returns>Double</returns>
    ''' <remarks></remarks>
    <Description("Surface mixing layer thickness (cm)")>
    <Browsable(True)>
    <[ReadOnly](False)>
    <DisplayName("Mixing layer thickness (cm)")>
    <DefaultValue(2)>
    <XmlIgnore()>
    Public Property dgML As Double

    '<XmlIgnore()>
    Public Property DateStrings As String()
    Public Property FOCUSTemperatures As String()
    Public Property ThetaI As String()



    Private m_IWQPRO As StdProperties.eIWQPRO = StdProperties.eIWQPRO.Mechanistic_MassBalance

    ''' <summary>
    ''' pesticide trapping equation
    ''' </summary>
    ''' <returns></returns>
    <Description("Pesticide Trapping Equation" & vbCrLf &
                 "std. = 3 Mechanistic_MassBalance")>
    <DefaultValue(CInt(StdProperties.eIWQPRO.Mechanistic_MassBalance))>
    <RefreshProperties(RefreshProperties.All)>
    <Browsable(True)>
    Public Property IWQPRO As StdProperties.eIWQPRO
        Get
            Return m_IWQPRO
        End Get
        Set(value As StdProperties.eIWQPRO)
            m_IWQPRO = value
        End Set
    End Property

#Region "    Fitting Coefficients"

    <DefaultValue(0)>
    <Description("Fitting Coefficients for" & vbCrLf &
                 "delta P for IWQPRO = 1 = Sabbagh")>
    Public Property CSAB1 As Double = 0

    <DefaultValue(0)>
    <Description("Fitting Coefficients for" & vbCrLf &
                 "delta P for IWQPRO = 1 = Sabbagh")>
    Public Property CSAB2 As Double = 0

    <DefaultValue(0)>
    <Description("Fitting Coefficients for" & vbCrLf &
                 "delta P for IWQPRO = 1 = Sabbagh")>
    Public Property CSAB3 As Double = 0

    <DefaultValue(0)>
    <Description("Fitting Coefficients for" & vbCrLf &
                 "delta P for IWQPRO = 1 = Sabbagh")>
    Public Property CSAB4 As Double = 0

#End Region


#End Region

    ''' <summary>
    ''' Resulting 'IWQ Water quality/transport submodel' file
    ''' </summary>
    Public ReadOnly Property IWQfile As String()
        Get

            Dim Result As New List(Of String)

            Dim DayTemps As New List(Of String)
            Dim ThetaITemp As New List(Of String)
            Dim DateTemp As New List(Of String)

            With Result

                .Add(" " & CInt(Me.IWQPRO).ToString)
                If FullFeat Then
                    Result(.Count - 1) = Result(.Count - 1).PadRight(30) & Me.IWQPRO.ToString
                End If


                .Add(Join({
                           " 0 " &
                               Me.Kd.ToString
                           }))

                If FullFeat Then
                    Result(.Count - 1) = Result(.Count - 1).PadRight(30) & " Kd proc.: 0= Kd(L/Kg); 1=Koc (Koc L/Kg) , %OC)"
                End If

                .Add(" " & Me.PCTC.ToString)
                If FullFeat Then
                    Result(.Count - 1) = Result(.Count - 1).PadRight(30) & " % Clay content in sediment"
                End If

                .Add(" 1")
                If FullFeat Then
                    Result(.Count - 1) = Result(.Count - 1).PadRight(30) & " IDG"
                End If


                .Add(Join({
                           " " &
                               Me.ndgday.ToString,
                               Me.dgHalfL.ToString,
                               Me.FC.ToString,
                               NumberFormat(Me.dgPin, Digits, Scientific:=True),
                               Me.dgML.ToString
                           }))

                If FullFeat Then
                    Result(.Count - 1) = Result(.Count - 1).PadRight(30) & " ndgday  dgHalfL(d) FC(m3/m3) dgPin(mg)  dgML(cm)"
                End If

                ReDim Me.FOCUSTemperatures(ndgday)
                ReDim Me.ThetaI(ndgday)

                For DayCounter As Integer = 0 To Me.ndgday - 1

                    DayTemps.Add(Common.getFOCUSTemp(Me.EventDate.AddDays(DayCounter), Me.FOCUSScenario).ToString.PadLeft("750101 ".Length))
                    ThetaITemp.Add(Common.getThetaI(Me.EventDate.AddDays(DayCounter), Me.FOCUSScenario).ToString.PadLeft("750101 ".Length))

                    DateTemp.Add(Format((Me.EventDate.AddDays(DayCounter)), " yyMMdd"))

                    Me.FOCUSTemperatures(DayCounter) = Format((Me.EventDate.AddDays(DayCounter)), "yyMMdd") & " " & DayTemps.Last

                Next

                'DayTemps.Reverse()
                'DateTemp.Reverse()
                'ThetaITemp.Reverse()

                DateStrings = DayTemps.ToArray
                FOCUSTemperatures = DayTemps.ToArray
                ThetaI = ThetaITemp.ToArray

                .Add(" " & Join(DayTemps.ToArray, " "))
                .Add(" " & Join(ThetaITemp.ToArray, " "))
                .Add("")
                .Add(" " & Join(DateTemp.ToArray, " "))

                If FullFeat Then
                    .Add("------------------------------------------------------------------")
                    .Add("IDG    : flag to calculate degradation (1, other ignore).")
                    .Add("ndgday : no. of days between events")
                    .Add("dgKref : kref, pesticide half-life (days)")
                    .Add("FC     : top soil field capacity (m3/m3). This can be taken from ")
                    .Add("         FOCUS R1-R4 scenario parameters used by the PRZM model")
                    .Add("dgPin  : Pin, pesticide mass entering filter (mg)")
                    .Add("dgML   : Surface mixing layer thickness (cm, std.=2cm)")
                    .Add("dgT(i) : T, daily air temperatures (C) for period between events")

                    Try
                        .AddRange(Me.dgPinDescription.ToArray)
                    Catch ex As Exception

                    End Try

                End If

            End With

            Return Result.ToArray

        End Get
    End Property

End Class

#End Region